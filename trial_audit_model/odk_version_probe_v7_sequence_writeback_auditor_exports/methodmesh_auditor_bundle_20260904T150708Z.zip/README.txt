METHODMESH AUDITOR-SAFE BUNDLE
================================

This ZIP is intentionally separate from the restricted verifier archive.

SAFE EXPORT POLICY
------------------
- No submission XML.
- No photographs or other submission attachments.
- No source_record_fields JSON.
- No old/new research values.
- No canonical research payload text.
- No MethodMesh full JSON copied from submissions.
- Changed research fields are represented by FIELD NAME / LABEL only.
- Operator-entered Central comment text is included intentionally as
  reason-for-change evidence.

The restricted archive remains at:
/Users/icrucrob/AndroidStudioProjects/MethodMesh/trial_audit_model/odk_version_probe_v7_sequence_writeback

Do not share the restricted archive unless an issue-specific inspection has
been authorised.

VERIFY
------
Unzip this package and run:

    python3 verify_bundle.py

The verifier checks file checksums, the evidence-derived Merkle tree, the daily
checkpoint hash, and the RFC3161 timestamp using bundled public TSA trust
material. It does not require ODK Central credentials.

Schema: methodmesh.auditor_export.v1
Generated: 2026-09-04T15:07:11.378740+00:00
