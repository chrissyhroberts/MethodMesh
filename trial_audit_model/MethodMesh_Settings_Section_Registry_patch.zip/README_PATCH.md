# MethodMesh Settings-section extension patch

This patch makes the existing Settings card extensible without changing its visual design.

## Files

Drop these files into the matching project paths:

- `app/src/main/java/com/example/methodmesh/ui/HomeScreen.kt`
- `app/src/main/java/com/example/methodmesh/modules/MethodMeshModule.kt`
- `app/src/main/java/com/example/methodmesh/settings/SettingsSectionSpec.kt`

`HomeScreen.kt` is based on the file supplied in this chat. `MethodMeshModule.kt` is based on the current `master` version inspected on 2026-09-04.

## What changes

The existing built-in Settings sections remain visually and behaviourally the same:

1. Display accessibility
2. Language packs
3. Device calibration
4. Device signals

`MethodMeshModule` gains one optional hook:

```kotlin
fun settingsSections(): List<SettingsSectionSpec> = emptyList()
```

`HomeScreen` renders those contributions using the same collapsible row style as the built-in sections.

## Example future module contribution

A future offline-resources module can add itself to Settings entirely from its own module folder:

```kotlin
import com.example.methodmesh.settings.SettingsSectionSpec

override fun settingsSections() = listOf(
    SettingsSectionSpec(
        id = "offline.resources",
        title = "Offline resources",
        order = 250,
        content = { OfflineResourcesSettingsScreen() }
    )
)
```

No subsequent edit to `HomeScreen.kt` is needed.

## Ordering

The current built-ins use:

- 100 Display accessibility
- 200 Language packs
- 300 Device calibration
- 400 Device signals

A section with `order = 250` therefore appears between Language packs and Device calibration.

## Validation

- The new `SettingsSectionSpec` and modified `MethodMeshModule` compile together against minimal MethodMesh/Compose-shaped stubs.
- The HomeScreen diff changes only the Settings section rendering plus one import.
- Module-contributed Settings section IDs are checked for uniqueness during module installation.
- Core + module section IDs are also checked when the Settings card is rendered.
