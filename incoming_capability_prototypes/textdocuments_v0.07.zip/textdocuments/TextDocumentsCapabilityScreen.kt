package com.example.methodmesh.modules.textdocuments

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.transport.workflow.ui.CapabilityCompletionMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.launch

object TextDocumentsCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextDocumentsMethod.ID
    override val title = "Text documents"
    override val description = "Create, open, edit and save text, Markdown, JSON and JSON Lines files."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val scope = rememberCoroutineScope()
        val repository = remember { TextDocumentRepository(appContext) }

        val suppliedText = contextValue(context, "document_text")
        val suppliedTitle = contextValue(context, "document_title").ifBlank { "document.txt" }
        val suppliedFormat = DocumentFormat.fromContract(contextValue(context, "document_format"))

        var currentUri by rememberSaveable { mutableStateOf<String?>(null) }
        var currentTitle by rememberSaveable { mutableStateOf(if (suppliedText.isNotEmpty()) suppliedTitle else "") }
        var currentFormatName by rememberSaveable { mutableStateOf(if (suppliedText.isNotEmpty()) suppliedFormat.contractValue else "") }
        var currentText by rememberSaveable { mutableStateOf(if (suppliedText.isNotEmpty()) suppliedText else "") }
        var currentWritable by rememberSaveable { mutableStateOf(false) }
        var editorOpen by rememberSaveable { mutableStateOf(suppliedText.isNotEmpty()) }
        var recentRevision by rememberSaveable { mutableStateOf(0) }
        var newMenuOpen by rememberSaveable { mutableStateOf(false) }
        var statusMessage by rememberSaveable { mutableStateOf<String?>(null) }
        var pendingSaveAsText by rememberSaveable { mutableStateOf<String?>(null) }
        var committedText by rememberSaveable { mutableStateOf<String?>(null) }
        var committedResult by remember { mutableStateOf<ExecutionResult?>(null) }

        val openDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                DocumentIo.retainAccess(
                    appContext,
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                scope.launch {
                    DocumentIo.read(appContext, uri).fold(
                        onSuccess = { document ->
                            currentUri = uri.toString()
                            currentTitle = document.title
                            currentFormatName = document.format.contractValue
                            currentText = document.text
                            currentWritable = true
                            editorOpen = true
                            committedText = null
                            committedResult = null
                            statusMessage = null
                            repository.remember(uri, document.title, document.format.mimeType)
                            recentRevision++
                        },
                        onFailure = { error ->
                            statusMessage = "Could not open document: ${error.message ?: "unknown error"}"
                        }
                    )
                }
            }
        }

        val saveAs = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { activityResult ->
            val uri = activityResult.data?.data
            val body = pendingSaveAsText
            pendingSaveAsText = null
            if (uri != null && body != null) {
                val flags = activityResult.data?.flags ?: 0
                DocumentIo.retainAccess(appContext, uri, flags)
                scope.launch {
                    DocumentIo.write(appContext, uri, body).fold(
                        onSuccess = {
                            val format = DocumentFormat.fromContract(currentFormatName)
                            currentUri = uri.toString()
                            currentTitle = DocumentIo.displayName(appContext, uri) ?: currentTitle
                            currentWritable = true
                            currentText = body
                            statusMessage = "Saved"
                            repository.remember(uri, currentTitle, format.mimeType)
                            recentRevision++
                        },
                        onFailure = { error ->
                            statusMessage = "Save failed: ${error.message ?: "unknown error"}"
                        }
                    )
                }
            }
        }

        fun openBuffer(title: String, format: DocumentFormat, text: String = "") {
            currentUri = null
            currentTitle = DocumentIo.ensureExtension(title, format)
            currentFormatName = format.contractValue
            currentText = text
            currentWritable = false
            editorOpen = true
            committedText = null
            committedResult = null
            statusMessage = null
        }

        fun requestSaveAs(body: String) {
            val format = DocumentFormat.fromContract(currentFormatName)
            pendingSaveAsText = body
            saveAs.launch(DocumentIo.createIntent(format, currentTitle))
        }

        fun commit(body: String) {
            val format = DocumentFormat.fromContract(currentFormatName)
            val request = As100TextDocumentsMethod.request(
                action = capabilityId,
                context = context.request.invocationContext.asMap(capabilityId) +
                    context.action.settings +
                    mapOf(
                        "document_text" to body,
                        "document_title" to currentTitle,
                        "document_format" to format.contractValue
                    ),
                signals = emptyList(),
                inputs = emptyList()
            )
            val result = As100TextDocumentsMethod.result(
                request,
                As100TextDocumentsMethod.success(body, currentTitle, format.contractValue),
                context.request.invocationContext
            )
            committedText = body
            committedResult = result
            statusMessage = "Committed"
            if (context.completionMode == CapabilityCompletionMode.AutomaticReturn) {
                onConfirmed(result)
            }
        }

        if (editorOpen) {
            DocumentSurface(
                title = currentTitle.ifBlank { "Document" },
                initialText = currentText,
                format = DocumentFormat.fromContract(currentFormatName),
                writable = currentWritable,
                committedText = committedText,
                statusMessage = statusMessage,
                onClose = {
                    editorOpen = false
                    if (context.completionMode == CapabilityCompletionMode.AutomaticReturn) onCancel()
                },
                onSave = { body ->
                    val uri = currentUri?.let(Uri::parse)
                    if (uri == null) {
                        requestSaveAs(body)
                    } else {
                        scope.launch {
                            DocumentIo.write(appContext, uri, body).fold(
                                onSuccess = {
                                    currentText = body
                                    statusMessage = "Saved"
                                    repository.remember(uri, currentTitle, DocumentFormat.fromContract(currentFormatName).mimeType)
                                    recentRevision++
                                },
                                onFailure = { error ->
                                    statusMessage = "Save failed: ${error.message ?: "unknown error"}"
                                }
                            )
                        }
                    }
                },
                onSaveAs = ::requestSaveAs,
                onCommit = ::commit,
                onDone = if (context.completionMode == CapabilityCompletionMode.ManualConfirmation) {
                    { committedResult?.let(onConfirmed) }
                } else null
            )
            return
        }

        val recent = remember(recentRevision) { repository.recent() }

        Surface(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("Text documents", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Create or open a local text document. JSON and JSON Lines remain untouched unless you edit them.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { onCancel() }) { Text("Close") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column {
                        Button(onClick = { newMenuOpen = true }) { Text("New document") }
                        DropdownMenu(expanded = newMenuOpen, onDismissRequest = { newMenuOpen = false }) {
                            DocumentFormat.values().forEach { format ->
                                DropdownMenuItem(
                                    text = { Text(format.label) },
                                    onClick = {
                                        newMenuOpen = false
                                        openBuffer("document.${format.extension}", format)
                                    }
                                )
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            openDocument.launch(
                                arrayOf(
                                    "text/plain",
                                    "text/markdown",
                                    "application/json",
                                    "application/x-ndjson",
                                    "application/jsonl"
                                )
                            )
                        }
                    ) { Text("Open file") }
                }

                OutlinedButton(onClick = {
                    val clipboard = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val clipText = clipboard.primaryClip?.takeIf { it.itemCount > 0 }
                        ?.getItemAt(0)?.coerceToText(appContext)?.toString().orEmpty()
                    openBuffer("clipboard.txt", DocumentFormat.TEXT, clipText)
                }) { Text("Create from clipboard") }

                statusMessage?.takeIf { it.isNotBlank() }?.let { message ->
                    Text(
                        message,
                        color = if (message.startsWith("Could not") || message.startsWith("Save failed")) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(Modifier.height(4.dp))
                Text("Recent", style = MaterialTheme.typography.titleMedium)

                if (recent.isEmpty()) {
                    Text("No recent documents.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    recent.forEach { document ->
                        Card(
                            Modifier.fillMaxWidth().clickable {
                                val uri = Uri.parse(document.uri)
                                scope.launch {
                                    DocumentIo.read(appContext, uri, document.mimeType).fold(
                                        onSuccess = { opened ->
                                            currentUri = uri.toString()
                                            currentTitle = opened.title
                                            currentFormatName = opened.format.contractValue
                                            currentText = opened.text
                                            currentWritable = true
                                            editorOpen = true
                                            committedText = null
                                            committedResult = null
                                            statusMessage = null
                                            repository.remember(uri, opened.title, opened.format.mimeType)
                                            recentRevision++
                                        },
                                        onFailure = { error ->
                                            repository.forget(document.uri)
                                            recentRevision++
                                            statusMessage = "Could not reopen ${document.title}: ${error.message ?: "access no longer available"}"
                                        }
                                    )
                                }
                            }
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text(document.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    DocumentFormat.detect(document.title, document.mimeType).label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun contextValue(context: CapabilityScreenContext, key: String): String =
    context.action.settings[key]
        ?: context.action.settings["input_$key"]
        ?: context.request.settings[key]
        ?: context.request.settings["input_$key"]
        ?: ""
