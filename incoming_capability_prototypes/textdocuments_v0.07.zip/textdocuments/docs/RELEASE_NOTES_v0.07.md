# Text documents v0.07

Runtime layout repair over v0.06.

- removes the internal capability workspace `LazyColumn` that was being measured inside MethodMesh's already-scrollable capability host and causing an infinite-height Compose crash;
- deliberately does not replace it with another vertical scroll container: the MethodMesh host owns scrolling for the workspace entry surface;
- keeps the document editor itself as the focused full-screen working surface;
- preserves external Android VIEW/EDIT handling, canonical `document.text.open`, Save vs Commit semantics, preset/protocol/ODK exposure, JSON/JSONL support, recent-document metadata and module-owned documentation.
