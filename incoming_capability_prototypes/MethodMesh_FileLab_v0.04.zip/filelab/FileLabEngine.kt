package com.example.methodmesh.modules.filelab

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.zip.ZipInputStream

object FileLabEngine {
    private const val PREFIX_LIMIT = 256 * 1024

    fun inspect(name: String, size: Long, open: () -> InputStream): FileInspection {
        val prefix = open().use { it.readNBytes(PREFIX_LIMIT) }
        val text = decodeTextPrefix(prefix)
        var match = FileSignatures.identify(prefix, name, text)
        val facts = mutableListOf<FileFact>()
        val warnings = mutableListOf<String>()
        val evidence = match.evidence.toMutableList()

        if (match.id == "zip") {
            val classified = SafeZipInspector.classify(open)
            match = FileSignatures.Match(classified.id, classified.name, classified.mime, classified.confidence)
            facts += classified.facts
            warnings += classified.warnings
            evidence += DetectionEvidence("container", classified.reason)
        }

        val specialist = SpecialistInspectors.inspect(match.id, prefix, name)
        facts += specialist.first
        warnings += specialist.second
        extensionMismatch(name, match.id)?.let(warnings::add)

        val (sha, countedSize) = open().use(::sha256AndSize)
        val effectiveSize = if (size > 0) size else countedSize
        if (effectiveSize > prefix.size && match.id in setOf("csv", "tsv", "adif", "vcf", "fasta", "fastq")) {
            warnings += "Structured counts are sampled from the first ${prefix.size} bytes, not the complete file."
        }
        val actions = buildList {
            add("share")
            add("hash.copy")
            if (ConversionGraph.from(match.id).isNotEmpty()) add("convert")
            if (match.id in setOf("epub", "mobi", "azw3", "pdf", "cbz")) add("read")
            if (match.id in setOf("zip", "cbz", "epub", "apk", "kmz", "docx", "xlsx", "xlsform", "pptx")) add("archive.inspect")
        }
        return FileInspection(
            displayName = name,
            formatId = match.id,
            formatName = match.name,
            mimeType = match.mime,
            confidence = match.confidence,
            sizeBytes = effectiveSize,
            sha256 = sha,
            facts = facts,
            warnings = warnings.distinct(),
            availableActions = actions,
            evidence = evidence.distinct(),
            sampledBytes = prefix.size,
            inspectionDepth = inspectionDepth(match.id)
        )
    }

    fun sha256(input: InputStream): String = sha256AndSize(input).first

    private fun sha256AndSize(input: InputStream): Pair<String, Long> {
        val md = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        var size = 0L
        while (true) {
            val count = input.read(buffer)
            if (count <= 0) break
            md.update(buffer, 0, count)
            size += count
        }
        return md.digest().joinToString("") { "%02x".format(it) } to size
    }

    private fun inspectionDepth(id: String): InspectionDepth = when (id) {
        "fits", "csv", "tsv", "adif", "vcf", "fasta", "sigmf", "elf" -> InspectionDepth.STRUCTURED
        "zip", "cbz", "epub", "apk", "docx", "xlsx", "xlsform", "pptx", "kmz" -> InspectionDepth.DEEP
        "pdf", "sqlite", "wav", "mobi", "azw3", "gpx", "kml" -> InspectionDepth.BASIC
        else -> InspectionDepth.RECOGNISED
    }

    private fun extensionMismatch(name: String, detected: String): String? {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isBlank()) return null
        val compatible = when (detected) {
            "jpeg" -> setOf("jpg", "jpeg")
            "tiff" -> setOf("tif", "tiff")
            "fits" -> setOf("fit", "fits", "fts")
            "sqlite" -> setOf("sqlite", "sqlite3", "db")
            "adif" -> setOf("adi", "adif")
            "xlsform" -> setOf("xlsx")
            "mobi" -> setOf("mobi", "prc")
            else -> setOf(detected)
        }
        return if (ext !in compatible && detected != "unknown") {
            "Filename extension .$ext does not match detected $detected content."
        } else null
    }

    private fun decodeTextPrefix(bytes: ByteArray): String? {
        if (bytes.isEmpty()) return ""
        if (bytes.size >= 2 && bytes[0] == 0xff.toByte() && bytes[1] == 0xfe.toByte()) {
            return bytes.copyOfRange(2, bytes.size).toString(Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xfe.toByte() && bytes[1] == 0xff.toByte()) {
            return bytes.copyOfRange(2, bytes.size).toString(Charsets.UTF_16BE)
        }
        if (bytes.size >= 3 && bytes[0] == 0xef.toByte() && bytes[1] == 0xbb.toByte() && bytes[2] == 0xbf.toByte()) {
            return bytes.copyOfRange(3, bytes.size).toString(Charsets.UTF_8)
        }
        val nulRate = bytes.count { it == 0.toByte() }.toDouble() / bytes.size
        if (nulRate > 0.02) return null
        return runCatching { bytes.toString(Charsets.UTF_8) }.getOrNull()
    }
}

internal object FileSignatures {
    data class Match(
        val id: String,
        val name: String,
        val mime: String?,
        val confidence: Int,
        val evidence: List<DetectionEvidence> = emptyList()
    )

    fun identify(prefix: ByteArray, name: String, textPrefix: String?): Match {
        fun starts(vararg b: Int) = prefix.size >= b.size && b.indices.all { prefix[it].toInt() and 0xff == b[it] }
        fun m(id: String, n: String, mime: String?, c: Int, why: String) =
            Match(id, n, mime, c, listOf(DetectionEvidence("content", why)))
        val lower = name.lowercase()
        val bookMobi = prefix.size >= 68 && runCatching { String(prefix, 60, 8, StandardCharsets.US_ASCII) == "BOOKMOBI" }.getOrDefault(false)
        return when {
            starts(0x25, 0x50, 0x44, 0x46) -> m("pdf", "PDF", "application/pdf", 100, "PDF magic bytes")
            starts(0x50, 0x4b, 0x03, 0x04) || starts(0x50, 0x4b, 0x05, 0x06) || starts(0x50, 0x4b, 0x07, 0x08) -> m("zip", "ZIP-family container", "application/zip", 98, "ZIP signature")
            starts(0x1f, 0x8b) -> m("gzip", "GZIP compressed data", "application/gzip", 100, "GZIP signature")
            starts(0x42, 0x5a, 0x68) -> m("bzip2", "BZip2 compressed data", "application/x-bzip2", 100, "BZip2 signature")
            starts(0xfd, 0x37, 0x7a, 0x58, 0x5a, 0x00) -> m("xz", "XZ compressed data", "application/x-xz", 100, "XZ signature")
            starts(0x53, 0x51, 0x4c, 0x69, 0x74, 0x65, 0x20, 0x66, 0x6f, 0x72, 0x6d, 0x61, 0x74, 0x20, 0x33, 0x00) -> m("sqlite", "SQLite 3 database", "application/vnd.sqlite3", 100, "SQLite header")
            starts(0x7f, 0x45, 0x4c, 0x46) -> m("elf", "ELF binary", "application/x-elf", 100, "ELF header")
            starts(0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a) -> m("png", "PNG image", "image/png", 100, "PNG signature")
            starts(0xff, 0xd8, 0xff) -> m("jpeg", "JPEG image", "image/jpeg", 100, "JPEG signature")
            starts(0x49, 0x49, 0x2a, 0x00) || starts(0x4d, 0x4d, 0x00, 0x2a) -> m("tiff", "TIFF image", "image/tiff", 100, "TIFF byte-order/magic")
            starts(0x52, 0x49, 0x46, 0x46) && prefix.size >= 12 && String(prefix, 8, 4, StandardCharsets.US_ASCII) == "WAVE" -> m("wav", "WAVE audio", "audio/wav", 100, "RIFF/WAVE signature")
            bookMobi -> m(if (lower.endsWith(".azw3")) "azw3" else "mobi", "Mobipocket/Kindle ebook", "application/x-mobipocket-ebook", 98, "BOOKMOBI header")
            prefix.size >= 9 && String(prefix, 0, 9, StandardCharsets.US_ASCII) == "SIMPLE  =" -> m("fits", "FITS astronomical data", "application/fits", 100, "FITS SIMPLE card")
            textPrefix?.trimStart()?.let { it.startsWith("<?xml") && it.contains("<gpx") } == true -> m("gpx", "GPX track/waypoint data", "application/gpx+xml", 97, "GPX XML root")
            textPrefix?.trimStart()?.let { it.startsWith("<?xml") && it.contains("<kml") } == true -> m("kml", "KML geospatial data", "application/vnd.google-earth.kml+xml", 97, "KML XML root")
            textPrefix?.startsWith("##fileformat=VCF") == true -> m("vcf", "Variant Call Format", "text/vcf", 100, "VCF fileformat header")
            textPrefix?.let { it.contains("<ADIF_VER:", ignoreCase = true) || it.contains("<CALL:", ignoreCase = true) } == true -> m("adif", "ADIF amateur-radio log", "text/plain", 95, "ADIF field tags")
            textPrefix?.trimStart()?.let { it.startsWith("<?xml") && (it.contains("<ADX", ignoreCase = true) || it.contains("<RECORDS", ignoreCase = true)) } == true -> m("adx", "ADIF XML amateur-radio log", "application/xml", 90, "ADX XML structure")
            textPrefix?.startsWith(">") == true -> m("fasta", "FASTA sequence data", "text/plain", 85, "FASTA record marker")
            lower.endsWith(".fastq") && textPrefix?.startsWith("@") == true -> Match("fastq", "FASTQ sequence data", "text/plain", 80, listOf(DetectionEvidence("extension+content", ".fastq plus @ record marker")))
            lower.endsWith(".sigmf-meta") && textPrefix?.trimStart()?.startsWith("{") == true -> Match("sigmf", "SigMF metadata", "application/json", 90, listOf(DetectionEvidence("extension+content", ".sigmf-meta JSON")))
            textPrefix?.trimStart()?.startsWith("{") == true || textPrefix?.trimStart()?.startsWith("[") == true -> m("json", "JSON", "application/json", 75, "JSON-like leading token")
            lower.endsWith(".adi") || lower.endsWith(".adif") -> Match("adif", "ADIF amateur-radio log", "text/plain", 70, listOf(DetectionEvidence("extension", "ADIF extension")))
            lower.endsWith(".adx") -> Match("adx", "ADIF XML amateur-radio log", "application/xml", 70, listOf(DetectionEvidence("extension", "ADX extension")))
            lower.endsWith(".csv") -> Match("csv", "CSV tabular data", "text/csv", 60, listOf(DetectionEvidence("extension", "CSV extension")))
            lower.endsWith(".tsv") -> Match("tsv", "TSV tabular data", "text/tab-separated-values", 60, listOf(DetectionEvidence("extension", "TSV extension")))
            else -> Match("unknown", "Unknown / generic file", null, 20, listOf(DetectionEvidence("fallback", "No recognised signature")))
        }
    }
}

internal object SafeZipInspector {
    data class Classification(
        val id: String,
        val name: String,
        val mime: String?,
        val confidence: Int,
        val facts: List<FileFact>,
        val warnings: List<String>,
        val reason: String
    )

    private const val ENTRY_LIMIT = 10_000
    private const val DECLARED_LIMIT = 4L * 1024 * 1024 * 1024
    private const val NESTED_ENTRY_LIMIT = 50
    private const val NESTED_READ_LIMIT = 4 * 1024 * 1024
    private const val TOTAL_NESTED_READ_LIMIT = 16 * 1024 * 1024

    fun classify(open: () -> InputStream): Classification = classify(open, depth = 0)

    private fun classify(open: () -> InputStream, depth: Int): Classification {
        val names = mutableListOf<String>()
        val nestedSummaries = mutableListOf<String>()
        var declared = 0L
        var entriesSeen = 0
        var nestedRead = 0
        var encryptionMetadata = false
        var epubMime: String? = null
        var workbookXml: String? = null

        open().use { raw ->
            ZipInputStream(raw).use { zip ->
                while (entriesSeen < ENTRY_LIMIT) {
                    val entry = zip.nextEntry ?: break
                    entriesSeen++
                    if (names.size < ENTRY_LIMIT) names += entry.name
                    if (entry.size > 0) declared = if (entry.size > Long.MAX_VALUE - declared) Long.MAX_VALUE else declared + entry.size
                    val lower = entry.name.lowercase()
                    if (lower == "meta-inf/encryption.xml") encryptionMetadata = true
                    if (!entry.isDirectory && lower == "mimetype") {
                        epubMime = readEntryBounded(zip, 128).toString(StandardCharsets.US_ASCII).trim()
                        continue
                    }
                    if (!entry.isDirectory && lower == "xl/workbook.xml") {
                        workbookXml = readEntryBounded(zip, 256 * 1024).toString(StandardCharsets.UTF_8)
                        continue
                    }
                    if (depth < 2 && !entry.isDirectory && nestedSummaries.size < NESTED_ENTRY_LIMIT && nestedRead < TOTAL_NESTED_READ_LIMIT &&
                        lower.matches(Regex(".*\\.(zip|cbz|epub|apk|kmz|docx|xlsx|pptx)$")) &&
                        (entry.size in 1..NESTED_READ_LIMIT.toLong() || entry.size < 0)
                    ) {
                        val remaining = (TOTAL_NESTED_READ_LIMIT - nestedRead).coerceAtMost(NESTED_READ_LIMIT)
                        val bytes = readEntryBounded(zip, remaining)
                        nestedRead += bytes.size
                        if (bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) {
                            val nested = runCatching { classify({ ByteArrayInputStream(bytes) }, depth + 1) }.getOrNull()
                            nested?.let { nestedSummaries += "${entry.name}: ${it.id}" }
                        }
                    }
                }
            }
        }

        val lower = names.map(String::lowercase)
        val files = names.filterNot { it.endsWith("/") }
        val imageFiles = files.count { it.lowercase().matches(Regex(".*\\.(jpg|jpeg|png|webp|gif)$")) }
        val workbookSheets = workbookXml.orEmpty().let { xml ->
            Regex("<sheet[^>]+name=\"([^\"]+)\"", RegexOption.IGNORE_CASE).findAll(xml)
                .map { it.groupValues[1].lowercase() }.toSet()
        }
        val looksLikeXlsForm = "survey" in workbookSheets && ("settings" in workbookSheets || "choices" in workbookSheets)
        val type = when {
            epubMime == "application/epub+zip" && lower.any { it == "meta-inf/container.xml" } -> Triple("epub", "EPUB ebook", "application/epub+zip")
            lower.any { it == "androidmanifest.xml" } -> Triple("apk", "Android APK", "application/vnd.android.package-archive")
            lower.any { it == "[content_types].xml" } && lower.any { it.startsWith("word/") } -> Triple("docx", "Office Open XML document", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
            lower.any { it == "[content_types].xml" } && lower.any { it.startsWith("xl/") } && looksLikeXlsForm -> Triple("xlsform", "XLSForm workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            lower.any { it == "[content_types].xml" } && lower.any { it.startsWith("xl/") } -> Triple("xlsx", "Office Open XML workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            lower.any { it == "[content_types].xml" } && lower.any { it.startsWith("ppt/") } -> Triple("pptx", "Office Open XML presentation", "application/vnd.openxmlformats-officedocument.presentationml.presentation")
            lower.any { it.endsWith(".kml") } -> Triple("kmz", "KMZ geospatial archive", "application/vnd.google-earth.kmz")
            files.isNotEmpty() && imageFiles >= 2 && imageFiles.toDouble() / files.size >= 0.80 -> Triple("cbz", "CBZ comic archive", "application/vnd.comicbook+zip")
            else -> Triple("zip", "ZIP archive", "application/zip")
        }
        val suspicious = names.filter { it.startsWith("/") || it.replace('\\', '/').split('/').any { part -> part == ".." } }
        val warnings = buildList {
            if (suspicious.isNotEmpty()) add("Archive contains ${suspicious.size} potentially unsafe paths; File Lab never extracts them by path.")
            if (entriesSeen >= ENTRY_LIMIT) add("Archive inventory stopped at $ENTRY_LIMIT entries.")
            if (declared >= DECLARED_LIMIT) add("Archive declares at least 4 GiB uncompressed content; conversion/extraction remains bounded.")
            if (encryptionMetadata) add("Archive contains encryption metadata; File Lab does not remove DRM or bypass protected resources.")
            if (nestedRead >= TOTAL_NESTED_READ_LIMIT) add("Nested archive inspection stopped at the ${TOTAL_NESTED_READ_LIMIT / (1024 * 1024)} MiB safety budget.")
        }
        val facts = mutableListOf(
            FileFact("Entries sampled", entriesSeen.toString()),
            FileFact("Files sampled", files.size.toString()),
            FileFact("Image files", imageFiles.toString()),
            FileFact("Declared uncompressed bytes", declared.toString())
        )
        if (workbookSheets.isNotEmpty()) facts += FileFact("Workbook sheets", workbookSheets.sorted().joinToString(", "))
        if (looksLikeXlsForm) facts += FileFact("XLSForm structure", "survey sheet with choices/settings metadata")
        if (nestedSummaries.isNotEmpty()) facts += FileFact("Nested archives", nestedSummaries.joinToString(" | "))
        return Classification(type.first, type.second, type.third, 98, facts, warnings, "ZIP member structure matches ${type.second}")
    }

    private fun readEntryBounded(input: InputStream, maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream(minOf(maxBytes, 64 * 1024))
        val buffer = ByteArray(32 * 1024)
        var total = 0
        while (total < maxBytes) {
            val n = input.read(buffer, 0, minOf(buffer.size, maxBytes - total))
            if (n <= 0) break
            out.write(buffer, 0, n)
            total += n
        }
        return out.toByteArray()
    }
}

internal object SpecialistInspectors {
    fun inspect(format: String, bytes: ByteArray, name: String): Pair<List<FileFact>, List<String>> = when (format) {
        "fits" -> fits(bytes)
        "adif" -> adif(bytes)
        "csv", "tsv" -> delimited(bytes, if (format == "tsv") '\t' else ',')
        "vcf" -> vcf(bytes)
        "fasta" -> fasta(bytes)
        "sigmf", "json" -> jsonHints(bytes, name)
        "elf" -> elf(bytes)
        "wav" -> wav(bytes)
        else -> emptyList<FileFact>() to emptyList()
    }

    private fun fits(bytes: ByteArray): Pair<List<FileFact>, List<String>> {
        val text = bytes.take(28_800).toByteArray().toString(StandardCharsets.US_ASCII)
        val cards = text.chunked(80).takeWhile { !it.startsWith("END") }
        fun card(key: String) = cards.firstOrNull { it.startsWith(key.padEnd(8)) }
            ?.substringAfter("=")?.substringBefore("/")?.trim()?.trim('\'')
        return listOfNotNull(
            card("BITPIX")?.let { FileFact("BITPIX", it) },
            card("NAXIS")?.let { FileFact("Axes", it) },
            card("NAXIS1")?.let { FileFact("Width", it) },
            card("NAXIS2")?.let { FileFact("Height", it) },
            card("OBJECT")?.let { FileFact("Object", it) },
            card("DATE-OBS")?.let { FileFact("Observation", it) },
            card("EXPTIME")?.let { FileFact("Exposure", it) },
            card("FILTER")?.let { FileFact("Filter", it) },
            card("TELESCOP")?.let { FileFact("Telescope", it) },
            card("INSTRUME")?.let { FileFact("Instrument", it) },
            card("CTYPE1")?.let { FileFact("WCS axis 1", it) },
            card("CTYPE2")?.let { FileFact("WCS axis 2", it) },
            card("CRVAL1")?.let { FileFact("WCS reference 1", it) },
            card("CRVAL2")?.let { FileFact("WCS reference 2", it) },
            FileFact("Header cards sampled", cards.size.toString())
        ) to emptyList()
    }

    private fun adif(bytes: ByteArray): Pair<List<FileFact>, List<String>> {
        val text = bytes.toString(StandardCharsets.UTF_8)
        val qsos = Regex("<EOR>", RegexOption.IGNORE_CASE).findAll(text).count()
        val calls = Regex("<CALL:[0-9]+[^>]*>([^<\\r\\n]+)", RegexOption.IGNORE_CASE).findAll(text).map { it.groupValues[1].trim() }.toSet()
        val bands = Regex("<BAND:[0-9]+[^>]*>([^<\\r\\n]+)", RegexOption.IGNORE_CASE).findAll(text).map { it.groupValues[1].trim() }.toSet()
        return listOf(FileFact("QSOs sampled", qsos.toString()), FileFact("Unique callsigns sampled", calls.size.toString()), FileFact("Bands sampled", bands.sorted().joinToString(", "))) to emptyList()
    }

    private fun delimited(bytes: ByteArray, delimiter: Char): Pair<List<FileFact>, List<String>> {
        val rows = parseDelimitedSample(bytes.toString(StandardCharsets.UTF_8), delimiter, 10_001)
        val columns = rows.firstOrNull()?.size ?: 0
        val malformed = rows.drop(1).count { it.size != columns }
        val warnings = buildList { if (malformed > 0) add("$malformed sampled rows have a different field count") }
        return listOf(
            FileFact("Columns", columns.toString()),
            FileFact("Rows sampled", (rows.size - 1).coerceAtLeast(0).toString()),
            FileFact("Delimiter", if (delimiter == '\t') "tab" else delimiter.toString())
        ) to warnings
    }

    private fun parseDelimitedSample(text: String, delimiter: Char, limit: Int): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val field = StringBuilder()
        var quoted = false
        var i = 0
        fun finishField() { row.add(field.toString()); field.setLength(0) }
        fun finishRow() { finishField(); rows.add(row); row = mutableListOf() }
        while (i < text.length && rows.size < limit) {
            val c = text[i]
            when {
                c == '"' && quoted && i + 1 < text.length && text[i + 1] == '"' -> { field.append('"'); i++ }
                c == '"' -> quoted = !quoted
                c == delimiter && !quoted -> finishField()
                (c == '\n' || c == '\r') && !quoted -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    if (field.isNotEmpty() || row.isNotEmpty()) finishRow()
                }
                else -> field.append(c)
            }
            i++
        }
        if (rows.size < limit && (field.isNotEmpty() || row.isNotEmpty())) finishRow()
        return rows
    }

    private fun vcf(bytes: ByteArray): Pair<List<FileFact>, List<String>> {
        val lines = bytes.toString(StandardCharsets.UTF_8).lineSequence().take(100_000).toList()
        val variants = lines.count { it.isNotBlank() && !it.startsWith("#") }
        val header = lines.firstOrNull { it.startsWith("#CHROM") }?.split('\t').orEmpty()
        return listOf(FileFact("Variants sampled", variants.toString()), FileFact("Samples", (header.size - 9).coerceAtLeast(0).toString())) to emptyList()
    }

    private fun fasta(bytes: ByteArray): Pair<List<FileFact>, List<String>> {
        val text = bytes.toString(StandardCharsets.UTF_8)
        val records = text.lineSequence().count { it.startsWith(">") }
        val residues = text.lineSequence().filterNot { it.startsWith(">") }.sumOf { it.trim().length }
        return listOf(FileFact("Sequences sampled", records.toString()), FileFact("Residues sampled", residues.toString())) to emptyList()
    }

    private fun jsonHints(bytes: ByteArray, name: String): Pair<List<FileFact>, List<String>> {
        val text = bytes.toString(StandardCharsets.UTF_8)
        if (!name.lowercase().endsWith(".sigmf-meta")) return emptyList<FileFact>() to emptyList()
        fun value(key: String) = Regex("\\\"${Regex.escape(key)}\\\"\\s*:\\s*(\\\"[^\\\"]*\\\"|[-+0-9.eE]+)")
            .find(text)?.groupValues?.get(1)?.trim('"')
        return listOfNotNull(
            value("core:sample_rate")?.let { FileFact("Sample rate", it) },
            value("core:frequency")?.let { FileFact("Centre frequency", it) },
            value("core:datatype")?.let { FileFact("Datatype", it) },
            value("core:description")?.let { FileFact("Description", it) }
        ) to emptyList()
    }

    private fun elf(bytes: ByteArray): Pair<List<FileFact>, List<String>> {
        if (bytes.size < 20) return emptyList<FileFact>() to listOf("Truncated ELF header")
        val bits = when (bytes[4].toInt()) { 1 -> "32-bit"; 2 -> "64-bit"; else -> "unknown" }
        val endian = when (bytes[5].toInt()) { 1 -> "little-endian"; 2 -> "big-endian"; else -> "unknown" }
        return listOf(FileFact("Class", bits), FileFact("Byte order", endian), FileFact("ABI", (bytes[7].toInt() and 0xff).toString())) to emptyList()
    }

    private fun wav(bytes: ByteArray): Pair<List<FileFact>, List<String>> {
        if (bytes.size < 44) return emptyList<FileFact>() to listOf("WAVE header is shorter than the standard 44-byte PCM header")
        fun le16(offset: Int) = (bytes[offset].toInt() and 0xff) or ((bytes[offset + 1].toInt() and 0xff) shl 8)
        fun le32(offset: Int) = (bytes[offset].toLong() and 0xff) or ((bytes[offset + 1].toLong() and 0xff) shl 8) or ((bytes[offset + 2].toLong() and 0xff) shl 16) or ((bytes[offset + 3].toLong() and 0xff) shl 24)
        return listOf(
            FileFact("Channels", le16(22).toString()),
            FileFact("Sample rate", le32(24).toString()),
            FileFact("Bits per sample", le16(34).toString())
        ) to emptyList()
    }
}

object ConversionGraph {
    private val routes = listOf(
        ConversionRoute("cbz", "pdf", lossless = false, notes = "Images are embedded into PDF pages."),
        ConversionRoute("pdf", "cbz", lossless = false, notes = "PDF pages are rasterised to JPEG.")
    )

    fun from(sourceFormat: String): List<ConversionRoute> = routes.filter { it.sourceFormat == sourceFormat }
    fun find(sourceFormat: String, targetFormat: String): ConversionRoute? = routes.firstOrNull { it.sourceFormat == sourceFormat && it.targetFormat == targetFormat }
}
