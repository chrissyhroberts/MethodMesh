# File Lab roadmap

This file separates intended scope from implemented scope. Nothing below is advertised by the v0.4 method descriptors or conversion graph unless explicitly marked implemented.

## Implemented now

- content-first universal inspection with SHA-256;
- bounded ZIP-family and nested-container inspection;
- structured metadata sampling for FITS, ADIF, CSV/TSV, VCF, FASTA, SigMF, ELF and WAVE;
- EPUB/APK/OOXML/KMZ/CBZ container recognition, including structural XLSForm recognition;
- MOBI/AZW3 BOOKMOBI recognition;
- reader hand-off preferring KOReader when installed;
- CBZ → PDF;
- PDF → CBZ.

## Next deep inspectors

Prioritise a few formats deeply rather than claiming broad shallow support:

1. FITS image preview, HDU inventory, histogram/stretch and WCS summary;
2. SigMF paired metadata/data inspection with bounded spectrum/waterfall preview;
3. ADIF/ADX and Cabrillo log statistics/validation;
4. GPX/KML/GeoJSON track/point summaries and map preview;
5. research data: deeper XLSForm validation/schema inspection plus Stata/SPSS/SAS/Parquet/Arrow schema inspection;
6. scientific containers: NetCDF/HDF5/GRIB metadata trees;
7. biomedical/genomics: DICOM, EDF/EDF+, FASTQ and richer VCF summaries;
8. engineering: STL/OBJ, Gerber and G-code previews.

## Conversion candidates

Candidate engines must be evaluated for Android packaging, licences, APK size, offline behaviour, security and deterministic output before routes are declared. Candidate families include:

- EPUB ↔ PDF and EPUB ↔ other DRM-free ebook containers;
- document/image conversion and PDF merge/split/reorder;
- audio conversion among WAV/FLAC/MP3/AAC/Opus/OGG/M4A, likely via a separately reviewed media engine;
- geospatial conversions such as GPX/KML/GeoJSON.

## Explicitly not in scope

DRM circumvention/decryption is not a File Lab conversion route. Protected-resource detection may be improved, but File Lab must not present access-control bypass as ordinary format conversion.
