# Inspect file

`file.inspect` identifies a file from content rather than trusting its extension, computes SHA-256, performs bounded container/specialist inspection and exposes the evidence behind the identification.

## Native lifecycle

The native screen is the file instrument itself:

1. choose a file, or receive a caller-supplied `source_uri`;
2. File Lab computes a **live working inspection**;
3. useful values such as format, filename, size, facts and SHA-256 are tap-to-copy;
4. choosing another file or re-inspecting changes only the working state;
5. **Commit inspection** freezes the canonical return payload;
6. dashboard/native use remains on the capability surface for post-Commit actions; external/ODK/protocol/schedule origins return through the shared launch-origin rules.

Working state is held with `rememberSaveable` as URI/name/serialized inspection state so ordinary activity recreation does not throw away the operator's work.

## Inputs

| Canonical input | Type | Required | Meaning |
|---|---|---:|---|
| `source_uri` | Android URI / ODK attachment projection | no | Existing caller-supplied file. When absent, native UI asks the user to choose a file. |
| `source_name` | text | no | Optional display-name hint. |

When ODK supplies the original file, File Lab does not gratuitously return a second copy. When MethodMesh acquires the source on ODK's behalf, `filelab_source_uri` returns the acquired file so the caller can own it as an attachment.

## Canonical returns

| Key | ODK type | Meaning |
|---|---|---|
| `filelab_inspection_summary` | text | Beef-first human summary. |
| `filelab_source_name` | text | Source display name. |
| `filelab_source_uri` | file | Acquired source attachment when MethodMesh picked the file; blank for caller-supplied input. |
| `filelab_format_id` | text | Stable detected format identifier. |
| `filelab_format_name` | text | Human-readable format name. |
| `filelab_mime_type` | text | Detected/derived MIME type when known. |
| `filelab_confidence` | integer/text | Detection confidence 0–100. |
| `filelab_size_bytes` | integer/text | Source size in bytes. |
| `filelab_sha256` | text | SHA-256 of the complete source bytes. |
| `filelab_inspection_depth` | text | `recognised`, `basic`, `structured` or `deep`. |
| `filelab_facts_json` | text/JSON | Format-specific facts. |
| `filelab_warnings_json` | text/JSON | Safety, mismatch and sampling warnings. |
| `filelab_evidence_json` | text/JSON | Why the detector selected the format. |
| `filelab_available_actions` | text | Pipe-separated native actions. |
| `filelab_inspected_time_iso` | text | Inspection time. |
| `filelab_inspect_status` | text | `succeeded` or `failed`. |
| `filelab_inspect_error` | text | Error text on failure. |

The shared MethodMesh transport additionally returns `methodmesh_status` and `methodmesh_full_json` on handled ODK FULL roundtrips.

## ODK Integration Card

### ODK INTEGRATION

**Capability:** Inspect file  
**Method ID:** `file.inspect`  
**Maturity:** Development  
**Connectivity:** Offline

### ODK INPUTS

`source_uri` is optional. The canonical showcase provides an optional ODK `file` question and passes it as `input_source_uri`. Leave it blank to ask MethodMesh to acquire the source interactively.

### INTENT CALL

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='file.inspect',input_source_uri=${source_file},input_payload_mode='FULL',return_mode='flat')
```

### MODIFIERS

| Modifier | Canonical example | Meaning |
|---|---|---|
| `input_payload_mode` | `FULL` | Requests complete structured/audit projection. |
| `return_mode` | `flat` | Projects canonical return fields into the calling group. |

The canonical example intentionally does **not** use `methodmesh_return_namespace`. Namespace composition is for user-authored multi-call forms, not the single-call showcase.

### RETURN FIELD PLACEMENT

`docs/example_odk_showcase_file_inspect.xlsx` contains exactly one MethodMesh invocation on `run_file_inspect` and uses unprefixed child names matching every declared return plus:

- `methodmesh_status`;
- `methodmesh_full_json`.

### FILE RETURN SEMANTICS

`filelab_source_uri` is a `file` child field. When MethodMesh acquired the source, the existing shared transport must put the `content://` URI in returned extras/ClipData with read grants so ODK imports the bytes as its own attachment. When ODK supplied `source_file`, `filelab_source_uri` is blank and no redundant duplicate is returned.

### RUNTIME CONTRACT

Interactive acquisition → live working inspection → Commit → frozen canonical payload. Cancel returns to the launch origin without committing. The source is read-only.
