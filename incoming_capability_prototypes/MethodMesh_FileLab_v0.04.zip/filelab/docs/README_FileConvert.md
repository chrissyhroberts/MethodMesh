# Convert file

`file.convert` converts only through routes that exist in the executable `ConversionGraph`. v0.4 implements CBZ → PDF and PDF → CBZ offline on-device.

## Native lifecycle

1. choose/receive a source file;
2. File Lab content-detects the source and shows only matching executable targets;
3. adjust route-specific controls where they are runtime inputs;
4. **Convert** creates a live working artefact without modifying the source;
5. inspect filename, size and SHA-256 and optionally open the output;
6. **Commit** freezes the canonical output payload;
7. shared post-Commit share/save and launch-origin handling apply.

Changing the source, target or raster settings invalidates the previous working output rather than silently committing stale bytes.

## Inputs

| Canonical input | Type | Required | Meaning |
|---|---|---:|---|
| `source_uri` | Android URI / ODK attachment projection | no | Source file. If absent, MethodMesh asks the user to choose it. |
| `source_name` | text | no | Optional display-name hint. |
| `target_format` | choice | yes for fixed/headless setup | `pdf` or `cbz`; the runtime rejects a target without an executable source→target route. |
| `max_dimension` | integer | no | PDF→CBZ maximum rendered page dimension; 256–12000 px, default 2400. |
| `jpeg_quality` | integer | no | PDF→CBZ JPEG quality 1–100, default 92. |

## Canonical returns

| Key | ODK type | Meaning |
|---|---|---|
| `filelab_conversion_summary` | text | Beef-first route/size summary. |
| `filelab_source_name` | text | Source display name. |
| `filelab_source_uri` | file | Acquired source attachment only when MethodMesh picked it. |
| `filelab_source_format` | text | Content-detected source format. |
| `filelab_target_format` | text | Executed target format. |
| `filelab_output_name` | text | Output filename. |
| `filelab_output_uri` | file | Converted file as a shareable `content://` URI. |
| `filelab_output_mime_type` | text | Output MIME type. |
| `filelab_output_size_bytes` | integer/text | Final bytes written. |
| `filelab_output_sha256` | text | SHA-256 of the final output bytes. |
| `filelab_conversion_warnings_json` | text/JSON | Route/lossiness notes. |
| `filelab_converted_time_iso` | text | Conversion time. |
| `filelab_convert_status` | text | `succeeded` or `failed`. |
| `filelab_convert_error` | text | Error text on failure. |

The shared MethodMesh transport additionally returns `methodmesh_status` and `methodmesh_full_json` on handled ODK FULL roundtrips.

## Safety limits

CBZ→PDF applies page-count, per-page extracted-byte, total extracted-byte and a 24-megapixel decoded-page bound. Archive entries are never extracted using member paths. PDF→CBZ bounds page count, rendered dimensions and JPEG quality. Failed conversions delete partial output files.

PDF→CBZ is lossy because pages are rasterised. CBZ→PDF preserves decoded page pixels but does not claim preservation of arbitrary archive metadata.

## ODK Integration Card

### ODK INTEGRATION

**Capability:** Convert file  
**Method ID:** `file.convert`  
**Maturity:** Development  
**Connectivity:** Offline

### ODK INPUTS

The canonical showcase supplies optional `source_file` plus target/raster controls. `source_file` may be left blank to use MethodMesh's native picker.

### INTENT CALL

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='file.convert',input_source_uri=${source_file},input_target_format=${target_format_input},input_max_dimension=${max_dimension_input},input_jpeg_quality=${jpeg_quality_input},input_payload_mode='FULL',return_mode='flat')
```

### MODIFIERS

| Modifier | Canonical example | Meaning |
|---|---|---|
| `input_payload_mode` | `FULL` | Requests complete structured/audit projection. |
| `return_mode` | `flat` | Projects canonical return fields into the calling group. |

The showcase is single-invocation and does not use `methodmesh_return_namespace`.

### RETURN FIELD PLACEMENT

`docs/example_odk_showcase_file_convert.xlsx` contains exactly one MethodMesh call under `run_file_convert`. Its child fields match every declared return plus `methodmesh_status` and `methodmesh_full_json`.

### FILE RETURN SEMANTICS

`filelab_output_uri` is a `file` child and is the primary useful return. The existing shared transport is responsible for ClipData/read grants so ODK imports the converted bytes as an attachment rather than storing a private MethodMesh URI. `filelab_source_uri` follows the same acquired-source rule as `file.inspect`.

### RUNTIME CONTRACT

Source selection/detection and conversion are working state. Commit freezes the exact final URI/name/size/hash payload. ODK persistence is caller-owned.
