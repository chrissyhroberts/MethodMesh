# File Lab v0.4 validation record

## Authority and interface review

- Reviewed against MethodMesh Master Book v1.22, especially Section 6, ODK parity, Definition of Done and the required 16-point final self-review.
- Current public MethodMesh `master` interfaces were inspected directly for `MethodMeshModule`, `As100Method`, `CapabilityScreenSpec`, `CapabilityScreenContext`, `CapabilityScreenScaffold` and `MethodSetting` before writing this handoff.
- Module is one clean `filelab/` handoff root. No app/repository wrapper or central UI special-case is included.

## Executable engine checks performed in the handoff environment

The pure Kotlin engine was compiled with `kotlinc 1.9.0` and a focused executable self-test passed:

- quoted CSV field parsing (`"a,b"` remains one field);
- complete-file SHA-256 generation;
- image-dominant ZIP classification as CBZ;
- FITS detection from raw `SIMPLE  =` header bytes even when later binary payload bytes are present;
- structural XLSForm recognition from workbook sheet metadata;
- strict EPUB recognition using the EPUB mimetype plus container structure;
- CBZ→PDF and PDF→CBZ routes present;
- unimplemented EPUB→PDF route absent.

The MethodMesh method/module layer and Android file/conversion helper were also compile-checked against small API-shaped stubs based on the inspected current interfaces. The full Compose screens were cross-checked against current repository screen/scaffold patterns. This handoff environment does not contain a full Android SDK/repository checkout, so `:app:assembleDebug` is **not claimed** here.

## Contract parity

- `file.inspect` and `file.convert` are each canonical `As100Method` objects.
- Both are exposed independently through `as100Methods()` and `capabilityScreens()`.
- Preset/protocol discovery derives from the same method metadata; conversion settings are exposed through `capabilitySettings()`.
- Both descriptors expose maturity/connectivity/interactive/core-return metadata.
- Dashboard aggregation is generic module metadata; no private dashboard-only implementation exists.

## Native interaction

- File selection/result work happens on capability-specific screens.
- Inspection/conversion output is **working state** until the operator presses Commit.
- Changing source/route/settings invalidates stale conversion commitment.
- Important displayed values are tap-to-copy.
- URI/name/serialized working output are held in `rememberSaveable` state.
- Shared scaffold owns origin-aware closeout and post-Commit actions.

## ODK/XLSForm

Canonical examples:

- `example_odk_showcase_file_inspect.xlsx`;
- `example_odk_showcase_file_convert.xlsx`.

Each workbook contains exactly one MethodMesh invocation, `input_payload_mode='FULL'`, `return_mode='flat'`, no canonical return namespace, all declared method return leaves, `methodmesh_status` and `methodmesh_full_json`. File-return leaves use XLSForm `file` type.

Workbook ZIP integrity and key sheet contents were checked after export. Pyxform/ODK Central/Kobo/device validation remains a repository/device integration check and is not falsely claimed here.

## Required final self-review

1. **Established contract removed/renamed?** No prior canonical File Lab method contract existed; v0.03 was an engine prototype. The new public IDs are `file.inspect` and `file.convert` and are documented consistently.
2. **Each capability direct without dashboard?** Yes; each has its own method and screen.
3. **Preset/protocol usable?** Yes; both are independent registered methods; conversion settings are declared.
4. **ODK every declared output?** Yes in the supplied single-call forms, subject to shared transport attachment machinery.
5. **XLSForms validate?** Structurally generated/inspected here; pyxform/provider/device validation remains outstanding and therefore maturity stays Development.
6. **Task-specific UI?** Yes: file picker + inspection bench; source/route conversion bench.
7. **Commit freezes canonical payload?** Yes; no `ExecutionResult` is exposed to the scaffold until Commit serialises the working values.
8. **Done/Cancel launch origin?** Delegated to current shared `CapabilityScreenScaffold`/host contract; no module override.
9. **Rotation/state restoration?** URI/name/settings/working/committed JSON are `rememberSaveable`; Android cache output persists across normal activity recreation.
10. **Tap-to-copy?** Yes for displayed useful values through module-owned `FileLabValue`.
11. **Remain on capability surface?** Yes; no module generic result activity/screen is introduced.
12. **`methodmesh_full_json` and attachments?** Forms capture the shared field; URI outputs are `content://` FileProvider values and `file` XLSForm leaves. Shared transport supplies ClipData/read grants.
13. **ODK Integration Card complete?** Yes in both capability READMEs.
14. **Exactly one maturity/connectivity tag?** Module/current descriptors: Development + Offline.
15. **Capability-specific shared-code changes?** None.
16. **One clean module folder?** Yes.
