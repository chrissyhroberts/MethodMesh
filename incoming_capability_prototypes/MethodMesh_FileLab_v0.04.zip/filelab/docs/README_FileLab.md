# File Lab

File Lab is MethodMesh's offline file laboratory: identify unfamiliar files by content, inspect safe metadata, fingerprint them, convert only through explicitly implemented routes, and hand readable files to a reader without changing the original.

**Module ID:** `filelab`  
**Version:** `0.4.0`  
**Maturity:** `DEVELOPMENT` (current host metadata string: `Development`)  
**Connectivity:** `OFFLINE` (current host metadata string: `Offline`)

## Canonical capabilities

| Capability | Method ID | Native UI | Presets | Protocols | ODK/XLSForm |
|---|---|---:|---:|---:|---:|
| Inspect file | `file.inspect` | yes | yes | yes | yes |
| Convert file | `file.convert` | yes | yes | yes | yes |

The dashboard is an aggregation surface only. Both methods remain independently discoverable through `FileLabModule.as100Methods()`, `capabilityScreens()` and `capabilitySettings()`.

## Implemented file knowledge

Content-first recognition includes PDF, ZIP-family containers, GZIP, BZip2, XZ, SQLite, ELF, PNG, JPEG, TIFF, WAVE, FITS, GPX, KML, VCF, FASTA, FASTQ, SigMF metadata, ADIF/ADX, CSV/TSV, JSON and Mobipocket/Kindle BOOKMOBI files. ZIP-family inspection further identifies EPUB, APK, DOCX, XLSX, **XLSForm workbooks**, PPTX, KMZ and image-dominant CBZ archives. XLSForm recognition is structural (workbook sheet metadata), not full form validation.

Structured inspection currently extracts bounded metadata for FITS (including common telescope/instrument/WCS header cards), ADIF, CSV/TSV, VCF, FASTA, SigMF, ELF and WAVE. ZIP-family inspection inventories bounded archive structure, caps nested inspection depth/budgets, and performs bounded nested-archive classification. Sampling is explicitly labelled; File Lab does not imply that prefix-derived counts cover the whole file.

## Reader hand-off

Readable formats can be opened from the inspector. File Lab prefers the installed KOReader package (`org.koreader.launcher`) and otherwise uses Android's normal `ACTION_VIEW` chooser. KOReader is **not bundled or embedded** in this module.

## DRM

File Lab does not remove DRM, defeat access controls or decrypt protected books. EPUB encryption metadata is reported as a warning. Protected-resource handling is outside this module's contract.

## Conversion graph

v0.4 has exactly two executable routes:

- CBZ → PDF;
- PDF → CBZ.

No EPUB, MOBI/AZW3, audio or other route is advertised by `ConversionGraph` until an actual converter exists.

## Privacy and persistence

Core work is local and offline. Source files are never modified. Temporary working files live under Android cache and conversion results are exposed through the existing MethodMesh `FileProvider` as `content://` URIs. Caller-owned systems such as ODK own the returned study attachment; File Lab does not create an additional research-record store merely because ODK invoked it.

See the capability-specific READMEs for exact contracts and ODK Integration Cards.
