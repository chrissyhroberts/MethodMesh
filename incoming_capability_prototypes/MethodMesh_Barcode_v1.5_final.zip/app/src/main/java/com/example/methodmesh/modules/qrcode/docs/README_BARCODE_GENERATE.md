# Barcode module — scan and create

**Canonical authority:** MethodMesh Master Book v1.20 (2026-09-12)  
**Module ID:** `barcode`  
**Maturity:** Production  
**Connectivity:** Offline

The historical module path/name is preserved. This refresh adds a second canonical capability without changing the established scanner contract:

- `barcode.scan` — code → exact payload evidence.
- `barcode.generate` — exact payload → scannable presentation.

## `barcode.generate`

### Product intent

This is a fast presentation tool, not a barcode database. The normal path is:

**paste/type → code appears immediately → present to another scanner**

The primary screen is capability-owned. A large, clean, black-on-white code surface dominates the upper screen. Payload and presentation controls sit below it. There is no generic intermediate settings screen and no separate generic results page.

QR is the default because it is broadly readable and can carry arbitrary text. Swipe left/right, use the arrow controls, tap a format pill, or press **Cycle** to move through formats that can encode the exact current payload.

### Exact-payload invariant

`barcode.generate` MUST NOT truncate, pad, reformat or otherwise mutate the supplied payload merely to make a symbology accept it. Incompatible formats are omitted from the available sequence. This is especially important for EAN/UPC formats.

Payload recognition is assistive only. Safe absolute HTTP/HTTPS payloads gain an explicit **Open link** action; common email, telephone, Wi-Fi, numeric and text payloads receive a compact descriptive label. Recognition never changes the encoded string.

### Working result and Commit

The visible code is the live working result. Editing the payload or changing format changes that working result in place.

**Commit** freezes:

- `barcode_payload`
- `barcode_format`
- generation timestamp/source and derived canonical metadata.

Automatic-return origins (ODK, protocol/schedule workflows) return the canonical result immediately after Commit. Direct native use remains on the capability with the committed code visible and exposes beef-first Copy/Share/Home plus explicit Edit. Edit deliberately returns to working state; a committed result is never silently mutated.

The payload card is tap-to-copy before and after Commit.

### Presentation mode

Tapping the code enters a deliberately sparse presentation mode:

- code fills the useful screen area;
- background remains white even in dark mode;
- brightness is raised;
- screen is kept awake;
- all editing controls disappear.

Tap anywhere to return. Window brightness/keep-awake state is restored on exit.

### MethodMesh mark

QR presentation carries the canonical MethodMesh mark automatically. There is no logo picker and no custom-logo state.

The mark uses the same geometry and colours as `res/drawable/ic_launcher_foreground.xml`; the generator does not introduce a second image asset. QR uses error-correction level H and a conservative central white clearance patch. The encoded payload is unchanged.

The mark is deliberately **QR-only**. Data Matrix, Aztec, PDF417 and linear barcodes remain pristine because presentation branding is subordinate to interoperability.

### Compatible formats

Initial presentation order:

`QR_CODE → CODE_128 → DATA_MATRIX → AZTEC → PDF_417 → CODE_39 → EAN_13 → EAN_8 → UPC_A → UPC_E`

ZXing encoding is used as the compatibility gate for the exact payload. **Cycle** advances only through compatible formats and stops when the operator edits the payload or manually changes format.

### Settings / inputs

| Key | Type | Default | Meaning |
|---|---|---|---|
| `barcode_payload` | Text | empty | Exact text to encode. |
| `barcode_format` | Choice | `QR_CODE` | Initial/selected presentation format. |
| `barcode_auto_cycle` | Boolean | `false` | Begin compatible-format cycling. |

Fixed preset settings are hidden from the native runtime UI through the shared `settingShouldBeShown` contract. Runtime inputs remain operator-editable.

### Outputs

| Output | Meaning |
|---|---|
| `barcode_payload` | Exact input payload; primary beef. |
| `barcode_payload_kind` | `text` or `url`. |
| `barcode_payload_url` | Exact safe absolute HTTP/HTTPS URL when applicable. |
| `barcode_format` | Committed presentation format. |
| `barcode_payload_sha256` | SHA-256 of exact payload. |
| `barcode_generated_time_iso` | Generation/Commit timestamp. |
| `barcode_source` | `methodmesh_generator` for native generation. |

`methodmesh_full_json` is supplied by the shared FULL projection rather than invented as a module output.

### Surface parity

`barcode.generate` is registered through the normal `MethodMeshModule` method/screen/settings path. The same canonical method ID and output contract therefore remain available to direct native use, Dashboard discovery, Presets, Protocols and ODK/XLSForm. No dashboard-only or ODK-only generator exists.

The module owns no barcode history. A reusable loyalty card/token should be represented by a Preset rather than a second storage model.

## `barcode.scan`

The existing `barcode.scan` ID, inputs, outputs, evidence recipe and scanner implementation are unchanged by this addition. Keep the existing `README_QrCode.md`, `VALIDATION.md`, attribution/notices and scanner XLSForms in the module.
