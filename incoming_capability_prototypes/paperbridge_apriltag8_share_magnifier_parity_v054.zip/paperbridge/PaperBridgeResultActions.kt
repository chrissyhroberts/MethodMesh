package com.example.methodmesh.modules.paperbridge

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.methodmesh.core.artifacts.AndroidArtifacts
import com.example.methodmesh.core.artifacts.ArtifactRef
import java.io.ByteArrayInputStream
import java.io.File
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.UUID

internal data class PaperBridgeShareAttachment(
    val name: String,
    val uri: String
)

internal data class PaperBridgeFilesSaveSummary(
    val collectionId: String,
    val fileCount: Int,
    val collectionLabel: String
)

/**
 * Native post-Commit result actions for Paper Bridge.
 *
 * Commit itself remains non-persistent. Share uses caller-readable content URIs;
 * Save copies the frozen result into the shared MethodMesh Files/ArtifactStore.
 */
internal object PaperBridgeResultActions {
    private val stamp = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss").withZone(ZoneOffset.UTC)

    fun share(
        context: Context,
        chooserTitle: String,
        text: String,
        attachments: List<PaperBridgeShareAttachment>,
        jsonText: String = ""
    ) {
        val unique = attachments
            .filter { it.uri.startsWith("content://") }
            .distinctBy { it.uri }
            .toMutableList()

        if (jsonText.isNotBlank()) {
            unique += PaperBridgeShareAttachment(
                name = "metadata.json",
                uri = temporaryJsonShareUri(context, jsonText).toString()
            )
        }

        val shareable = ArrayList(unique.map { Uri.parse(it.uri) })
        if (shareable.isEmpty() && text.isBlank()) {
            throw IllegalStateException("No shareable result.")
        }

        /*
         * Match the shared MethodMesh/Magnifier handoff exactly:
         *
         *   - one scalar EXTRA_TEXT = beef;
         *   - EXTRA_STREAM = one attachment;
         *   - EXTRA_STREAM ArrayList = multiple attachments;
         *   - FLAG_GRANT_READ_URI_PERMISSION.
         *
         * Do not put text in ClipData and do not use an EXTRA_TEXT array.
         * Those PaperBridge-specific experiments either duplicated the beef
         * per image or caused receivers to ignore it completely.
         */
        val intent = if (shareable.isEmpty()) {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
        } else if (shareable.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = mimeFor(context, shareable.first(), unique.first().name)
                putExtra(Intent.EXTRA_STREAM, shareable.first())
                if (text.isNotBlank()) putExtra(Intent.EXTRA_TEXT, text)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, shareable)
                if (text.isNotBlank()) putExtra(Intent.EXTRA_TEXT, text)
            }
        }.apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(
            Intent.createChooser(intent, chooserTitle)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    fun saveToFiles(
        context: Context,
        collectionLabel: String,
        textFileName: String,
        text: String,
        attachments: List<PaperBridgeShareAttachment>,
        jsonText: String = "",
        entryId: String? = null
    ): PaperBridgeFilesSaveSummary {
        val service = AndroidArtifacts.service(context)
        val collectionId = "paperbridge-${UUID.randomUUID()}"
        val stem = "Paper Bridge/${stamp.format(Instant.now())}_${safeSegment(collectionLabel).ifBlank { "result" }}"
        val created = mutableListOf<ArtifactRef>()

        fun createText(name: String, mime: String, value: String) {
            if (value.isBlank()) return
            created += service.createPersistent(
                name = "$stem/${safeFileName(name)}",
                mime = mime,
                input = ByteArrayInputStream(value.toByteArray(Charsets.UTF_8)),
                collectionId = collectionId,
                entryId = entryId
            )
        }

        try {
            createText(textFileName, "text/plain", text)
            createText("metadata.json", "application/json", jsonText)

            attachments
                .filter { it.uri.startsWith("content://") }
                .distinctBy { it.uri }
                .forEach { attachment ->
                    val uri = Uri.parse(attachment.uri)
                    val input = context.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Could not open ${attachment.name} for saving.")
                    input.use {
                        created += service.createPersistent(
                            name = "$stem/${safeFileName(attachment.name)}",
                            mime = mimeFor(context, uri, attachment.name),
                            input = it,
                            collectionId = collectionId,
                            entryId = entryId,
                            mediaId = UUID.randomUUID().toString()
                        )
                    }
                }

            if (created.isEmpty()) throw IllegalStateException("No result files were available to save.")
            return PaperBridgeFilesSaveSummary(collectionId, created.size, stem)
        } catch (error: Throwable) {
            created.asReversed().forEach { ref -> runCatching { service.delete(ref) } }
            throw error
        }
    }

    private fun temporaryJsonShareUri(context: Context, jsonText: String): Uri {
        val folder = File(
            context.cacheDir,
            "paperbridge_share/${System.currentTimeMillis()}"
        ).apply { mkdirs() }
        val file = File(folder, "metadata.json")
        file.writeText(jsonText, Charsets.UTF_8)
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    private fun mimeFor(context: Context, uri: Uri, name: String): String =
        context.contentResolver.getType(uri)?.takeIf { it.isNotBlank() }
            ?: when (name.substringAfterLast('.', "").lowercase()) {
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "webp" -> "image/webp"
                "json" -> "application/json"
                "yaml", "yml" -> "application/yaml"
                "zip" -> "application/zip"
                "pdf" -> "application/pdf"
                "txt" -> "text/plain"
                "csv" -> "text/csv"
                else -> "application/octet-stream"
            }

    private fun safeSegment(raw: String): String = raw
        .trim()
        .replace(Regex("[^A-Za-z0-9._-]+"), "_")
        .trim('_')
        .take(80)

    private fun safeFileName(raw: String): String {
        val cleaned = raw.substringAfterLast('/').trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_')
        return cleaned.ifBlank { "file" }.take(120)
    }
}
