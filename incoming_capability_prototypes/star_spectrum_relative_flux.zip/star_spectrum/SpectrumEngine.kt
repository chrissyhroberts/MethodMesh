package com.example.methodmesh.modules.star_spectrum

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

internal object SpectrumEngine {
    fun analyse(
        bitmap: Bitmap,
        startX: Double,
        startY: Double,
        endX: Double,
        endY: Double,
        settings: SpectrumAnalysisSettings,
        calibration: AppliedCalibration? = null
    ): SpectrumExtraction {
        require(bitmap.width > 2 && bitmap.height > 2) { "Image is too small for spectral extraction." }
        val dx = endX - startX
        val dy = endY - startY
        val length = hypot(dx, dy)
        require(length >= 24.0) { "Draw a longer line along the dispersed spectrum." }

        val ux = dx / length
        val uy = dy / length
        val nx = -uy
        val ny = ux
        val step = max(1.0, length / 4095.0)
        val sampleCount = (floor(length / step).toInt() + 1).coerceIn(24, 4096)
        val distances = DoubleArray(sampleCount) { min(length, it * step) }
        val raster = GrayRaster(bitmap)
        val ribbon = settings.ribbonHalfWidthPx.coerceIn(6, 160)
        val aperture = settings.apertureHalfWidthPx.coerceIn(1, ribbon - 2)
        val bgGap = settings.backgroundGapPx.coerceIn(1, max(1, ribbon - aperture - 1))

        val rawOffsets = DoubleArray(sampleCount)
        var previousOffset = 0.0
        val correctionConfidence = DoubleArray(sampleCount)
        for (i in distances.indices) {
            val s = distances[i]
            val baseX = startX + ux * s
            val baseY = startY + uy * s
            val profile = DoubleArray(ribbon * 2 + 1) { k ->
                val off = k - ribbon
                raster.sample(baseX + nx * off, baseY + ny * off)
            }
            val background = sidebandMedian(profile, ribbon, aperture, bgGap)
            val continuitySigma = max(4.0, ribbon / 3.0)
            var sumW = 0.0
            var sumWO = 0.0
            var peak = 0.0
            for (k in profile.indices) {
                val off = (k - ribbon).toDouble()
                val signal = max(0.0, profile[k] - background)
                val continuity = 0.30 + 0.70 * exp(-0.5 * ((off - previousOffset) / continuitySigma).pow(2.0))
                val w = signal.pow(1.25) * continuity
                sumW += w
                sumWO += w * off
                peak = max(peak, signal)
            }
            val candidate = if (sumW > 1e-6) sumWO / sumW else previousOffset
            val maxJump = max(3.0, ribbon * 0.28)
            val bounded = candidate.coerceIn(previousOffset - maxJump, previousOffset + maxJump).coerceIn(-ribbon * 0.9, ribbon * 0.9)
            rawOffsets[i] = bounded
            previousOffset = bounded
            correctionConfidence[i] = if (peak <= 0.0) 0.0 else (sumW / (peak + 1e-6)).coerceIn(0.0, ribbon * 2.0) / (ribbon * 2.0)
        }

        val offsets = movingAverage(rollingMedian(rawOffsets, 9), 7)
        val traceX = DoubleArray(sampleCount)
        val traceY = DoubleArray(sampleCount)
        for (i in distances.indices) {
            val s = distances[i]
            traceX[i] = startX + ux * s + nx * offsets[i]
            traceY[i] = startY + uy * s + ny * offsets[i]
        }

        val meanCorrection = offsets.map(::abs).average()
        val inBoundsFraction = traceX.indices.count { raster.inside(traceX[it], traceY[it], ribbon + 1) }.toDouble() / sampleCount
        val correctionPenalty = (meanCorrection / max(1.0, ribbon.toDouble())).coerceIn(0.0, 1.0)
        val traceQuality = (0.60 * inBoundsFraction + 0.25 * (1.0 - correctionPenalty) + 0.15 * correctionConfidence.average()).coerceIn(0.0, 1.0)
        val trace = SpectrumTrace(
            userStartX = startX,
            userStartY = startY,
            userEndX = endX,
            userEndY = endY,
            sampleX = traceX,
            sampleY = traceY,
            distancesPx = distances,
            traceQuality = traceQuality,
            meanAbsoluteCorrectionPx = meanCorrection,
            apertureHalfWidthPx = aperture,
            ribbonHalfWidthPx = ribbon
        )

        val profileRadius = min(ribbon, max(aperture + bgGap + 6, aperture * 3))
        val width = profileRadius * 2 + 1
        val profiles = Array(sampleCount) { DoubleArray(width) }
        val backgrounds = DoubleArray(sampleCount)
        val raw = DoubleArray(sampleCount)
        val backgroundSignal = DoubleArray(sampleCount)
        val sideNoise = DoubleArray(sampleCount)

        for (i in distances.indices) {
            val profile = profiles[i]
            for (k in profile.indices) {
                val off = k - profileRadius
                profile[k] = raster.sample(traceX[i] + nx * off, traceY[i] + ny * off)
            }
            val bg = sidebandMedian(profile, profileRadius, aperture, bgGap)
            backgrounds[i] = bg
            val side = mutableListOf<Double>()
            var central = 0.0
            var centralCount = 0
            for (k in profile.indices) {
                val off = k - profileRadius
                if (abs(off) <= aperture) {
                    central += profile[k]
                    centralCount++
                } else if (abs(off) >= min(profileRadius, aperture + bgGap)) {
                    side += profile[k]
                }
            }
            raw[i] = central
            backgroundSignal[i] = bg * centralCount
            sideNoise[i] = 1.4826 * mad(side.toDoubleArray(), median(side.toDoubleArray())) * sqrt(max(1, centralCount).toDouble())
        }

        val template = buildSpatialTemplate(profiles, backgrounds)
        val templatePeak = template.maxOrNull()?.coerceAtLeast(1e-9) ?: 1e-9
        val centralTemplateMass = template.indices
            .filter { abs(it - profileRadius) <= aperture }
            .sumOf { template[it] }
            .coerceAtLeast(1e-6)
        val templateCentroid = weightedCentroid(template, profileRadius)
        val templateWidth = weightedWidth(template, profileRadius, templateCentroid).coerceAtLeast(1.0)

        val corrected = DoubleArray(sampleCount)
        val contaminationFraction = DoubleArray(sampleCount)
        val contaminationProbability = DoubleArray(sampleCount)
        val valid = BooleanArray(sampleCount) { true }

        for (i in distances.indices) {
            val profile = profiles[i]
            val bg = backgrounds[i]
            val netCentral = max(0.0, raw[i] - backgroundSignal[i])
            val positive = DoubleArray(width) { k -> max(0.0, profile[k] - bg) }
            val ratios = mutableListOf<Double>()
            for (k in positive.indices) {
                if (template[k] >= templatePeak * 0.07) {
                    ratios += positive[k] / template[k].coerceAtLeast(1e-9)
                }
            }
            val fittedTotal = robustLowerMedian(ratios.toDoubleArray()).coerceAtLeast(0.0)
            val fittedCentral = fittedTotal * centralTemplateMass
            val residualPositive = positive.indices.sumOf { k -> max(0.0, positive[k] - fittedTotal * template[k]) }
            val observedPositive = positive.sum().coerceAtLeast(1e-6)
            val shapeResidualFraction = (residualPositive / observedPositive).coerceIn(0.0, 1.0)
            val excessCentralFraction = ((netCentral - fittedCentral) / max(netCentral, 1e-6)).coerceIn(0.0, 1.0)
            val centroid = weightedCentroid(positive, profileRadius)
            val observedWidth = weightedWidth(positive, profileRadius, centroid).coerceAtLeast(1.0)
            val centroidScore = (abs(centroid - templateCentroid) / max(2.0, aperture.toDouble())).coerceIn(0.0, 1.0)
            val widthScore = (abs(observedWidth - templateWidth) / max(2.0, templateWidth)).coerceIn(0.0, 1.0)
            val fraction = max(excessCentralFraction, shapeResidualFraction * 0.8).coerceIn(0.0, 1.0)
            val probability = (0.55 * fraction + 0.25 * shapeResidualFraction + 0.12 * centroidScore + 0.08 * widthScore).coerceIn(0.0, 1.0)

            contaminationFraction[i] = fraction
            contaminationProbability[i] = probability
            corrected[i] = if (probability >= 0.18 && fittedCentral.isFinite() && fittedCentral > 0.0) fittedCentral else netCentral
            valid[i] = !(probability >= 0.88 && fraction >= 0.45)
        }

        val cleanSignal = corrected.copyOf()
        interpolateInvalid(cleanSignal, valid)
        val continuumWindow = forceOdd(settings.continuumWindow.coerceIn(9, 401))
        val continuum = rollingMedian(cleanSignal, continuumWindow)
        val residual = DoubleArray(sampleCount) { cleanSignal[it] - continuum[it] }
        val spectralNoise = rollingMad(residual, max(11, continuumWindow / 2))
        val localNoise = DoubleArray(sampleCount) { i -> max(1e-6, max(sideNoise[i], spectralNoise[i])) }
        val localSnr = DoubleArray(sampleCount) { i -> abs(residual[i]) / localNoise[i] }

        val provisional = SpectrumExtraction(
            trace = trace,
            distancesPx = distances,
            raw = raw,
            background = backgroundSignal,
            corrected = corrected,
            contaminationFraction = contaminationFraction,
            contaminationProbability = contaminationProbability,
            valid = valid,
            localNoise = localNoise,
            localSnr = localSnr,
            continuum = continuum,
            residual = residual,
            features = emptyList(),
            calibration = calibration
        )
        val features = detectFeatures(provisional, settings)
        return provisional.copy(features = features)
    }

    fun fitCalibration(anchors: List<CalibrationAnchor>, requestedOrder: Int): CalibrationFit {
        val order = requestedOrder.coerceIn(1, 2)
        require(anchors.size >= order + 1) { "A polynomial of order $order needs at least ${order + 1} calibration anchors." }
        val n = order + 1
        val normal = Array(n) { DoubleArray(n) }
        val rhs = DoubleArray(n)
        for (anchor in anchors) {
            val powers = DoubleArray(n) { p -> anchor.distancePx.pow(p) }
            for (r in 0 until n) {
                rhs[r] += powers[r] * anchor.wavelengthNm
                for (c in 0 until n) normal[r][c] += powers[r] * powers[c]
            }
        }
        val coefficients = solveLinearSystem(normal, rhs)
        val predicted = anchors.map { anchor -> polynomial(coefficients, anchor.distancePx) }.toDoubleArray()
        val rms = sqrt(anchors.indices.map { i -> (predicted[i] - anchors[i].wavelengthNm).pow(2.0) }.average())
        return CalibrationFit(order, coefficients, rms, predicted)
    }

    fun calibrationForTarget(
        reference: SpectrumReference,
        targetWidthPx: Int,
        targetHeightPx: Int,
        registrationOffsetPx: Double = 0.0
    ): AppliedCalibration {
        val scaleX = targetWidthPx.toDouble() / reference.imageWidthPx.coerceAtLeast(1)
        val scaleY = targetHeightPx.toDouble() / reference.imageHeightPx.coerceAtLeast(1)
        val aspectPenalty = abs(scaleX - scaleY) / max(scaleX, scaleY).coerceAtLeast(1e-9)
        val scale = (scaleX + scaleY) / 2.0
        val rmsScore = exp(-reference.rmsNm.coerceAtLeast(0.0) / 2.0)
        val dimensionScore = exp(-aspectPenalty * 8.0)
        val confidence = (rmsScore * dimensionScore).coerceIn(0.0, 1.0)
        val warning = when {
            aspectPenalty > 0.03 -> "Image aspect ratio differs from the stored reference; wavelength calibration may be biased."
            abs(scale - 1.0) > 0.05 -> "Image dimensions differ from the stored reference; MethodMesh rescaled the pixel solution."
            else -> ""
        }
        return AppliedCalibration(reference, scale.coerceAtLeast(1e-6), registrationOffsetPx, confidence, warning)
    }

    private fun detectFeatures(extraction: SpectrumExtraction, settings: SpectrumAnalysisSettings): List<SpectralFeature> {
        if (extraction.residual.size < 9) return emptyList()
        val baseSigma = settings.detectionSigma.coerceIn(2.0, 10.0)
        val thresholds = listOf(max(2.0, baseSigma - 0.5), baseSigma, baseSigma + 0.5)
        val candidateSets = thresholds.map { threshold ->
            findCandidateIndices(extraction.residual, extraction.localNoise, extraction.valid, extraction.contaminationProbability, threshold, settings.detectionMode)
        }
        val primary = candidateSets[1]
        val tolerancePx = max(2.0, (extraction.distancesPx.lastOrNull() ?: 0.0) / extraction.distancesPx.size.coerceAtLeast(1) * 2.5)
        return primary.mapIndexed { ordinal, index ->
            val amplitude = extraction.residual[index]
            val type = if (amplitude >= 0.0) FeatureType.Emission else FeatureType.Absorption
            val prominence = localProminence(extraction.residual, index, type)
            val snr = abs(amplitude) / extraction.localNoise[index].coerceAtLeast(1e-6)
            val stability = candidateSets.count { set ->
                set.any { other -> abs(extraction.distancesPx[other] - extraction.distancesPx[index]) <= tolerancePx }
            }.toDouble() / candidateSets.size
            val fwhmPx = estimateFwhm(extraction.residual, extraction.distancesPx, index)
            val wavelength = extraction.wavelengthAt(index)
            val fwhmNm = extraction.calibration?.let { calibration ->
                fwhmPx * calibration.dispersionNmPerPx(extraction.distancesPx[index])
            }
            val normalizedSnr = (1.0 - exp(-max(0.0, snr - 1.0) / 3.0)).coerceIn(0.0, 1.0)
            val prominenceScore = (prominence / (abs(amplitude) + extraction.localNoise[index])).coerceIn(0.0, 1.0)
            val contaminationClean = 1.0 - extraction.contaminationProbability[index]
            val confidence = (0.42 * normalizedSnr + 0.28 * stability + 0.18 * prominenceScore + 0.12 * contaminationClean).coerceIn(0.0, 1.0)
            SpectralFeature(
                id = "F${ordinal + 1}",
                index = index,
                distancePx = extraction.distancesPx[index],
                wavelengthNm = wavelength,
                type = type,
                signal = extraction.corrected[index],
                continuum = extraction.continuum[index],
                amplitude = amplitude,
                prominence = prominence,
                fwhmPx = fwhmPx,
                fwhmNm = fwhmNm,
                snr = snr,
                stability = stability,
                contaminationProbability = extraction.contaminationProbability[index],
                confidence = confidence
            )
        }.sortedBy { it.distancePx }
    }

    private fun findCandidateIndices(
        residual: DoubleArray,
        noise: DoubleArray,
        valid: BooleanArray,
        contamination: DoubleArray,
        threshold: Double,
        mode: String
    ): List<Int> {
        val out = mutableListOf<Int>()
        val minSeparation = 3
        for (i in 2 until residual.size - 2) {
            if (!valid[i] || contamination[i] >= 0.80) continue
            val z = residual[i] / noise[i].coerceAtLeast(1e-6)
            val emission = mode != "absorption" && z >= threshold && residual[i] >= residual[i - 1] && residual[i] > residual[i + 1]
            val absorption = mode != "emission" && z <= -threshold && residual[i] <= residual[i - 1] && residual[i] < residual[i + 1]
            if (!emission && !absorption) continue
            if (out.isNotEmpty() && i - out.last() <= minSeparation) {
                val previous = out.last()
                if (abs(z) > abs(residual[previous] / noise[previous].coerceAtLeast(1e-6))) out[out.lastIndex] = i
            } else {
                out += i
            }
        }
        return out
    }

    private fun localProminence(residual: DoubleArray, index: Int, type: FeatureType): Double {
        val radius = 12
        val from = max(0, index - radius)
        val to = min(residual.lastIndex, index + radius)
        val left = if (index > from) residual.sliceArray(from until index) else doubleArrayOf(residual[index])
        val right = if (index < to) residual.sliceArray(index + 1..to) else doubleArrayOf(residual[index])
        return when (type) {
            FeatureType.Emission -> max(0.0, residual[index] - max(left.minOrNull() ?: 0.0, right.minOrNull() ?: 0.0))
            FeatureType.Absorption -> max(0.0, min(left.maxOrNull() ?: 0.0, right.maxOrNull() ?: 0.0) - residual[index])
        }
    }

    private fun estimateFwhm(residual: DoubleArray, distances: DoubleArray, index: Int): Double {
        val peak = residual[index]
        val half = peak / 2.0
        var left = index
        var right = index
        if (peak >= 0) {
            while (left > 0 && residual[left] > half) left--
            while (right < residual.lastIndex && residual[right] > half) right++
        } else {
            while (left > 0 && residual[left] < half) left--
            while (right < residual.lastIndex && residual[right] < half) right++
        }
        return max(0.0, distances[right] - distances[left])
    }

    private fun buildSpatialTemplate(profiles: Array<DoubleArray>, backgrounds: DoubleArray): DoubleArray {
        if (profiles.isEmpty()) return doubleArrayOf(1.0)
        val width = profiles[0].size
        val columns = Array(width) { mutableListOf<Double>() }
        val stride = max(1, profiles.size / 512)
        var i = 0
        while (i < profiles.size) {
            val positive = DoubleArray(width) { k -> max(0.0, profiles[i][k] - backgrounds[i]) }
            val total = positive.sum()
            if (total > 1e-6) {
                for (k in 0 until width) columns[k] += positive[k] / total
            }
            i += stride
        }
        val template = DoubleArray(width) { k -> median(columns[k].toDoubleArray()) }
        val smoothed = movingAverage(template, 3)
        val sum = smoothed.sum()
        if (sum <= 1e-9) {
            val centre = width / 2
            return DoubleArray(width) { k -> exp(-0.5 * ((k - centre) / max(1.5, width / 8.0)).pow(2.0)) }.let { values ->
                val total = values.sum(); DoubleArray(width) { values[it] / total }
            }
        }
        return DoubleArray(width) { smoothed[it] / sum }
    }

    private fun weightedCentroid(values: DoubleArray, centreIndex: Int): Double {
        val sum = values.sum()
        if (sum <= 1e-9) return 0.0
        return values.indices.sumOf { k -> values[k] * (k - centreIndex) } / sum
    }

    private fun weightedWidth(values: DoubleArray, centreIndex: Int, centroid: Double): Double {
        val sum = values.sum()
        if (sum <= 1e-9) return 1.0
        val variance = values.indices.sumOf { k ->
            val d = (k - centreIndex) - centroid
            values[k] * d * d
        } / sum
        return sqrt(max(variance, 1e-9))
    }

    private fun sidebandMedian(profile: DoubleArray, centreIndex: Int, aperture: Int, gap: Int): Double {
        val start = min(centreIndex, aperture + gap)
        val side = profile.indices.filter { abs(it - centreIndex) >= start }.map { profile[it] }.toDoubleArray()
        return if (side.isEmpty()) median(profile) else median(side)
    }

    private fun rollingMedian(values: DoubleArray, rawWindow: Int): DoubleArray {
        if (values.isEmpty()) return values
        val window = forceOdd(rawWindow.coerceAtLeast(3))
        val half = window / 2
        return DoubleArray(values.size) { i ->
            val from = max(0, i - half)
            val to = min(values.lastIndex, i + half)
            median(values.sliceArray(from..to))
        }
    }

    private fun rollingMad(values: DoubleArray, rawWindow: Int): DoubleArray {
        val window = forceOdd(rawWindow.coerceAtLeast(5))
        val half = window / 2
        return DoubleArray(values.size) { i ->
            val from = max(0, i - half)
            val to = min(values.lastIndex, i + half)
            val slice = values.sliceArray(from..to)
            val centre = median(slice)
            (1.4826 * mad(slice, centre)).coerceAtLeast(1e-6)
        }
    }

    private fun movingAverage(values: DoubleArray, rawWindow: Int): DoubleArray {
        if (values.isEmpty()) return values
        val window = forceOdd(rawWindow.coerceAtLeast(1))
        val half = window / 2
        return DoubleArray(values.size) { i ->
            val from = max(0, i - half)
            val to = min(values.lastIndex, i + half)
            var sum = 0.0
            for (j in from..to) sum += values[j]
            sum / (to - from + 1)
        }
    }

    private fun interpolateInvalid(values: DoubleArray, valid: BooleanArray) {
        for (i in values.indices) {
            if (valid[i]) continue
            var left = i - 1
            while (left >= 0 && !valid[left]) left--
            var right = i + 1
            while (right < values.size && !valid[right]) right++
            values[i] = when {
                left >= 0 && right < values.size -> {
                    val t = (i - left).toDouble() / (right - left)
                    values[left] * (1.0 - t) + values[right] * t
                }
                left >= 0 -> values[left]
                right < values.size -> values[right]
                else -> 0.0
            }
        }
    }

    private fun robustLowerMedian(values: DoubleArray): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.filter { it.isFinite() && it >= 0.0 }.sorted()
        if (sorted.isEmpty()) return 0.0
        val q = ((sorted.size - 1) * 0.45).roundToInt().coerceIn(0, sorted.lastIndex)
        return sorted[q]
    }

    private fun median(values: DoubleArray): Double {
        if (values.isEmpty()) return 0.0
        val sorted = values.filter { it.isFinite() }.sorted()
        if (sorted.isEmpty()) return 0.0
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
    }

    private fun mad(values: DoubleArray, centre: Double): Double = median(DoubleArray(values.size) { abs(values[it] - centre) })

    private fun forceOdd(value: Int): Int = if (value % 2 == 0) value + 1 else value

    private fun polynomial(coefficients: DoubleArray, x: Double): Double {
        var power = 1.0
        var out = 0.0
        for (coefficient in coefficients) {
            out += coefficient * power
            power *= x
        }
        return out
    }

    private fun solveLinearSystem(a: Array<DoubleArray>, b: DoubleArray): DoubleArray {
        val n = b.size
        val m = Array(n) { r -> DoubleArray(n + 1) { c -> if (c < n) a[r][c] else b[r] } }
        for (col in 0 until n) {
            var pivot = col
            for (r in col + 1 until n) if (abs(m[r][col]) > abs(m[pivot][col])) pivot = r
            require(abs(m[pivot][col]) > 1e-12) { "Calibration anchors do not span enough distinct pixel positions." }
            val tmp = m[col]; m[col] = m[pivot]; m[pivot] = tmp
            val divisor = m[col][col]
            for (c in col until n + 1) m[col][c] /= divisor
            for (r in 0 until n) {
                if (r == col) continue
                val factor = m[r][col]
                for (c in col until n + 1) m[r][c] -= factor * m[col][c]
            }
        }
        return DoubleArray(n) { m[it][n] }
    }

    private class GrayRaster(bitmap: Bitmap) {
        private val width = bitmap.width
        private val height = bitmap.height
        private val pixels = IntArray(width * height).also { bitmap.getPixels(it, 0, width, 0, 0, width, height) }

        fun inside(x: Double, y: Double, margin: Int = 0): Boolean =
            x >= margin && y >= margin && x < width - margin && y < height - margin

        fun sample(x: Double, y: Double): Double {
            if (x < 0.0 || y < 0.0 || x >= width - 1.0 || y >= height - 1.0) return 0.0
            val x0 = floor(x).toInt()
            val y0 = floor(y).toInt()
            val x1 = x0 + 1
            val y1 = y0 + 1
            val tx = x - x0
            val ty = y - y0
            val a = luminance(pixels[y0 * width + x0])
            val b = luminance(pixels[y0 * width + x1])
            val c = luminance(pixels[y1 * width + x0])
            val d = luminance(pixels[y1 * width + x1])
            val top = a * (1.0 - tx) + b * tx
            val bottom = c * (1.0 - tx) + d * tx
            return top * (1.0 - ty) + bottom * ty
        }

        private fun luminance(argb: Int): Double {
            /*
             * This is intentionally NOT display luminance.
             *
             * A stellar spectrum changes hue along the dispersion axis, so BT.709
             * perceptual weights (0.2126 R + 0.7152 G + 0.0722 B) manufacture a
             * large green-biased continuum shape. For spectral extraction we first
             * approximately undo sRGB/JPEG gamma, then sum the three linear-light
             * camera channels. The result is still relative image signal, not
             * radiometrically calibrated flux, but it preserves absorption structure
             * far better across colour transitions.
             */
            fun linearChannel(value: Int): Double {
                val s = value.coerceIn(0, 255) / 255.0
                return if (s <= 0.04045) {
                    s / 12.92
                } else {
                    ((s + 0.055) / 1.055).pow(2.4)
                }
            }

            val r = linearChannel(argb shr 16 and 0xff)
            val g = linearChannel(argb shr 8 and 0xff)
            val b = linearChannel(argb and 0xff)
            return (r + g + b) / 3.0
        }
    }
}
