package com.example.methodmesh.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import com.example.methodmesh.R
import com.example.methodmesh.core.scheduling.SchedulePlanRuntime
import com.example.methodmesh.core.scheduling.SchedulePlanStore
import com.example.methodmesh.core.scheduling.SchedulerDispatchActivity

class MethodMeshWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = ids.forEach { updateWidget(context, manager, it) }
    override fun onDeleted(context: Context, ids: IntArray) = ids.forEach { MethodMeshWidgetRepository.delete(context, it) }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) return
        val config = MethodMeshWidgetRepository.get(context, id) ?: return
        when (intent.action) {
            ACTION_WIDGET_TAP -> execute(context, MethodMeshWidgetTarget(config.targetType, config.targetId))
            ACTION_BUNDLE_TOGGLE -> MethodMeshWidgetRepository.setExpanded(context, id, !MethodMeshWidgetRepository.isExpanded(context, id))
            ACTION_BUNDLE_ITEM -> {
                val index = MethodMeshWidgetRepository.bundlePosition(context, id).coerceIn(0, (config.bundleTargets.size - 1).coerceAtLeast(0))
                config.bundleTargets.getOrNull(index)?.takeIf { MethodMeshWidgetRepository.targetExists(context, it) }?.let { execute(context, it) }
            }
            ACTION_BUNDLE_PREVIOUS, ACTION_BUNDLE_NEXT -> {
                if (config.bundleTargets.isNotEmpty()) {
                    val current = MethodMeshWidgetRepository.bundlePosition(context, id).coerceIn(0, config.bundleTargets.lastIndex)
                    val delta = if (intent.action == ACTION_BUNDLE_NEXT) 1 else -1
                    MethodMeshWidgetRepository.setBundlePosition(context, id, (current + delta + config.bundleTargets.size) % config.bundleTargets.size)
                }
            }
            else -> return
        }
        updateAll(context)
    }

    companion object {
        const val ACTION_WIDGET_TAP = "com.example.methodmesh.widgets.ACTION_WIDGET_TAP"
        const val ACTION_BUNDLE_TOGGLE = "com.example.methodmesh.widgets.ACTION_BUNDLE_TOGGLE"
        const val ACTION_BUNDLE_ITEM = "com.example.methodmesh.widgets.ACTION_BUNDLE_ITEM"
        const val ACTION_BUNDLE_PREVIOUS = "com.example.methodmesh.widgets.ACTION_BUNDLE_PREVIOUS"
        const val ACTION_BUNDLE_NEXT = "com.example.methodmesh.widgets.ACTION_BUNDLE_NEXT"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            manager.getAppWidgetIds(ComponentName(context, MethodMeshWidgetProvider::class.java)).forEach { updateWidget(context, manager, it) }
        }

        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val config = MethodMeshWidgetRepository.get(context, id)
            val views = if (config?.targetType == MethodMeshWidgetTargetType.BUNDLE && MethodMeshWidgetRepository.isExpanded(context, id)) {
                expandedBundleViews(context, id, config)
            } else {
                collapsedViews(context, id, config)
            }
            manager.updateAppWidget(id, views)
        }

        private fun collapsedViews(context: Context, id: Int, config: MethodMeshWidgetConfig?): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_methodmesh_trigger)
            if (config == null) {
                views.setTextViewText(R.id.widgetTitle, "MethodMesh")
                views.setTextViewText(R.id.widgetSubtitle, "Tap to set up")
                views.setOnClickPendingIntent(R.id.widgetRoot, configureIntent(context, id))
                return views
            }
            styleCollapsed(views, config)
            views.setTextViewText(R.id.widgetTitle, MethodMeshWidgetRepository.resolveTitle(context, config))
            views.setTextViewText(R.id.widgetSubtitle, MethodMeshWidgetRepository.resolveSubtitle(context, config))
            views.setTextViewText(R.id.widgetIcon, MethodMeshWidgetRepository.resolveIconKey(context, config).emoji)
            views.setOnClickPendingIntent(R.id.widgetRoot, if (config.targetType == MethodMeshWidgetTargetType.BUNDLE) bundleToggleIntent(context, id) else tapIntent(context, id))
            return views
        }

        private fun expandedBundleViews(context: Context, id: Int, config: MethodMeshWidgetConfig): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_methodmesh_bundle_expanded)
            styleExpanded(views, config)
            views.setTextViewText(R.id.bundleTitle, MethodMeshWidgetRepository.resolveTitle(context, config))
            views.setOnClickPendingIntent(R.id.bundleCollapse, bundleToggleIntent(context, id))
            if (config.bundleTargets.isEmpty()) {
                views.setTextViewText(R.id.bundleCurrent, "Empty bundle")
                views.setTextViewText(R.id.bundlePosition, "0 / 0")
                return views
            }
            val index = MethodMeshWidgetRepository.bundlePosition(context, id).coerceIn(0, config.bundleTargets.lastIndex)
            if (index != MethodMeshWidgetRepository.bundlePosition(context, id)) MethodMeshWidgetRepository.setBundlePosition(context, id, index)
            val target = config.bundleTargets[index]
            val name = MethodMeshWidgetRepository.resolveTargetName(context, target).ifBlank { "Unavailable item" }
            val icon = MethodMeshWidgetRepository.resolveTargetIconKey(context, target).emoji
            val subtitle = MethodMeshWidgetRepository.targetSubtitle(context, target)
            views.setTextViewText(R.id.bundleCurrent, "$icon\n$name\n$subtitle")
            views.setTextViewText(R.id.bundlePosition, "${index + 1} / ${config.bundleTargets.size}")
            if (MethodMeshWidgetRepository.targetExists(context, target)) views.setOnClickPendingIntent(R.id.bundleCurrent, bundleItemIntent(context, id))
            views.setOnClickPendingIntent(R.id.bundlePrevious, bundleNavigationIntent(context, id, ACTION_BUNDLE_PREVIOUS, 2))
            views.setOnClickPendingIntent(R.id.bundleNext, bundleNavigationIntent(context, id, ACTION_BUNDLE_NEXT, 3))
            return views
        }

        private fun backgroundResource(config: MethodMeshWidgetConfig): Int {
            val suffix = when (config.appearance) {
                MethodMeshWidgetAppearance.SOLID -> 0
                MethodMeshWidgetAppearance.GLASS -> 1
                MethodMeshWidgetAppearance.TRANSPARENT -> 2
            }
            return when (config.colour) {
                MethodMeshWidgetColour.TEAL -> intArrayOf(R.drawable.widget_bg_teal_solid, R.drawable.widget_bg_teal_glass, R.drawable.widget_bg_teal_transparent)[suffix]
                MethodMeshWidgetColour.BLUE -> intArrayOf(R.drawable.widget_bg_blue_solid, R.drawable.widget_bg_blue_glass, R.drawable.widget_bg_blue_transparent)[suffix]
                MethodMeshWidgetColour.PURPLE -> intArrayOf(R.drawable.widget_bg_purple_solid, R.drawable.widget_bg_purple_glass, R.drawable.widget_bg_purple_transparent)[suffix]
                MethodMeshWidgetColour.AMBER -> intArrayOf(R.drawable.widget_bg_amber_solid, R.drawable.widget_bg_amber_glass, R.drawable.widget_bg_amber_transparent)[suffix]
                MethodMeshWidgetColour.CORAL -> intArrayOf(R.drawable.widget_bg_coral_solid, R.drawable.widget_bg_coral_glass, R.drawable.widget_bg_coral_transparent)[suffix]
                MethodMeshWidgetColour.SLATE -> intArrayOf(R.drawable.widget_bg_slate_solid, R.drawable.widget_bg_slate_glass, R.drawable.widget_bg_slate_transparent)[suffix]
                MethodMeshWidgetColour.DARK -> intArrayOf(R.drawable.widget_bg_dark_solid, R.drawable.widget_bg_dark_glass, R.drawable.widget_bg_dark_transparent)[suffix]
            }
        }

        private fun foregroundColour(config: MethodMeshWidgetConfig): Int =
            if (config.colour == MethodMeshWidgetColour.DARK) Color.WHITE else 0xFF302A28.toInt()

        private fun styleCollapsed(views: RemoteViews, config: MethodMeshWidgetConfig) {
            views.setInt(R.id.widgetBackground, "setBackgroundResource", backgroundResource(config))
            val fg = foregroundColour(config)
            views.setTextColor(R.id.widgetTitle, fg)
            views.setTextColor(R.id.widgetSubtitle, fg)
        }

        private fun styleExpanded(views: RemoteViews, config: MethodMeshWidgetConfig) {
            views.setInt(R.id.widgetBackground, "setBackgroundResource", backgroundResource(config))
            val fg = foregroundColour(config)
            listOf(R.id.bundleTitle, R.id.bundleCollapse, R.id.bundleCurrent, R.id.bundlePrevious, R.id.bundlePosition, R.id.bundleNext).forEach { views.setTextColor(it, fg) }
        }

        private fun tapIntent(context: Context, id: Int) = broadcast(context, id, ACTION_WIDGET_TAP, 0)
        private fun bundleToggleIntent(context: Context, id: Int) = broadcast(context, id, ACTION_BUNDLE_TOGGLE, 1)
        private fun bundleItemIntent(context: Context, id: Int): PendingIntent = broadcast(context, id, ACTION_BUNDLE_ITEM, 4)
        private fun bundleNavigationIntent(context: Context, id: Int, action: String, salt: Int): PendingIntent = broadcast(context, id, action, salt)
        private fun broadcast(context: Context, id: Int, action: String, salt: Int): PendingIntent {
            val intent = Intent(context, MethodMeshWidgetProvider::class.java).setAction(action).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            return PendingIntent.getBroadcast(context, "methodmesh_widget_${id}_$salt".hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        private fun configureIntent(context: Context, id: Int): PendingIntent {
            val intent = Intent(context, MethodMeshWidgetConfigureActivity::class.java).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            return PendingIntent.getActivity(context, "methodmesh_widget_configure_$id".hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun execute(context: Context, target: MethodMeshWidgetTarget) = when (target.type) {
            MethodMeshWidgetTargetType.PRESET -> context.startActivity(Intent(context, SchedulerDispatchActivity::class.java).putExtra("preset_id", target.id).putExtra("transient_preset_run", true).putExtra("finish_to_launcher", true).putExtra("notification_kind", "widget").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            MethodMeshWidgetTargetType.PROTOCOL -> context.startActivity(Intent(context, SchedulerDispatchActivity::class.java).putExtra("protocol_id", target.id).putExtra("transient_protocol_run", true).putExtra("finish_to_launcher", true).putExtra("notification_kind", "widget").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            MethodMeshWidgetTargetType.SCHEDULE -> toggleSchedule(context, target.id)
            MethodMeshWidgetTargetType.BUNDLE -> Unit
        }
        private fun toggleSchedule(context: Context, id: String) {
            val plan = SchedulePlanStore.plan(context, id) ?: return
            val running = SchedulePlanStore.allInstances(context).filter { it.planId == plan.id && it.stoppedAt == null }
            if (running.isEmpty()) SchedulePlanRuntime.start(context, plan) else { running.forEach { SchedulePlanRuntime.cancel(context, it) }; SchedulePlanStore.removeInstancesForPlan(context, plan.id) }
        }
    }
}
