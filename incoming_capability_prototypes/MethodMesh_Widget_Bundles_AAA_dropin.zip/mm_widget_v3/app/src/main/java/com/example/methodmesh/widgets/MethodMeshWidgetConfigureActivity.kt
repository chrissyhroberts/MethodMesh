package com.example.methodmesh.widgets

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.protocols.ProtocolLibraryRepository
import com.example.methodmesh.ui.theme.MethodMeshTheme

class MethodMeshWidgetConfigureActivity : ComponentActivity() {
    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setResult(Activity.RESULT_CANCELED)
        appWidgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        setContent { MethodMeshTheme { ConfigureWidgetScreen(appWidgetId, { finish() }) {
            MethodMeshWidgetProvider.updateWidget(this, AppWidgetManager.getInstance(this), appWidgetId)
            setResult(Activity.RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)); finish()
        } } }
    }
}

private data class TargetChoice(val target: MethodMeshWidgetTarget, val name: String)

@Composable private fun ConfigureWidgetScreen(appWidgetId: Int, onCancel: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val existing = remember(appWidgetId) { MethodMeshWidgetRepository.get(context, appWidgetId) }
    val choices = remember {
        buildList {
            ProtocolLibraryRepository.presets(context).forEach { add(TargetChoice(MethodMeshWidgetTarget(MethodMeshWidgetTargetType.PRESET, it.id, it.name), it.name)) }
            ProtocolLibraryRepository.protocols(context).forEach { add(TargetChoice(MethodMeshWidgetTarget(MethodMeshWidgetTargetType.PROTOCOL, it.id, it.name), it.name)) }
            MethodMeshWidgetRepository.scheduleTargets(context).forEach { add(TargetChoice(MethodMeshWidgetTarget(MethodMeshWidgetTargetType.SCHEDULE, it.id, it.name), it.name)) }
        }
    }
    var targetType by rememberSaveable { mutableStateOf(existing?.targetType ?: MethodMeshWidgetTargetType.PRESET) }
    var selectedId by rememberSaveable { mutableStateOf(existing?.targetId.orEmpty()) }
    var label by rememberSaveable { mutableStateOf(existing?.label.orEmpty()) }
    var iconKey by rememberSaveable { mutableStateOf(existing?.iconKey ?: MethodMeshWidgetIconKey.AUTO) }
    var colour by rememberSaveable { mutableStateOf(existing?.colour ?: MethodMeshWidgetColour.TEAL) }
    var appearance by rememberSaveable { mutableStateOf(existing?.appearance ?: MethodMeshWidgetAppearance.SOLID) }
    var search by rememberSaveable { mutableStateOf("") }
    var bundleKeys by rememberSaveable { mutableStateOf(existing?.bundleTargets?.map { "${it.type}:${it.id}" } ?: emptyList()) }

    val singles = choices.filter { it.target.type == targetType && (search.isBlank() || it.name.contains(search, true)) }
    val selectedSingle = choices.firstOrNull { it.target.type == targetType && it.target.id == selectedId }
    val bundleTargets = bundleKeys.mapNotNull { key -> choices.firstOrNull { "${it.target.type}:${it.target.id}" == key }?.target }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (existing == null) "Add MethodMesh widget" else "Edit MethodMesh widget", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Single tools stay 1×1. Bundles are named covers that expand in place on the home screen.")
        OutlinedTextField(label, { label = it }, label = { Text(if (targetType == MethodMeshWidgetTargetType.BUNDLE) "Bundle name" else "Widget label") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().height(104.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(MethodMeshWidgetTargetType.entries) { type -> FilterChip(selected = targetType == type, onClick = { targetType = type; if (type != MethodMeshWidgetTargetType.BUNDLE && choices.none { it.target.type == type && it.target.id == selectedId }) selectedId = choices.firstOrNull { it.target.type == type }?.target?.id.orEmpty() }, label = { Text(if (type == MethodMeshWidgetTargetType.BUNDLE) "Bundle / stack" else type.name.lowercase().replaceFirstChar { it.uppercase() }) }) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { MethodMeshWidgetAppearance.entries.forEach { a -> FilterChip(appearance == a, { appearance = a }, { Text(a.title) }) } }
        Text("Icon", fontWeight = FontWeight.Bold)
        LazyVerticalGrid(columns = GridCells.Fixed(6), modifier = Modifier.fillMaxWidth().height(110.dp), verticalArrangement = Arrangement.spacedBy(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(MethodMeshWidgetIconKey.entries) { key -> Surface(Modifier.clickable { iconKey = key }, shape = RoundedCornerShape(10.dp), color = if (iconKey == key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha=.45f)) { Column(Modifier.padding(5.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(key.emoji); Text(key.title, style=MaterialTheme.typography.labelSmall, maxLines=1) } } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) { MethodMeshWidgetColour.entries.forEach { c -> Surface(Modifier.weight(1f).clickable { colour=c }, shape=RoundedCornerShape(50), color=Color(c.argb)) { Text(if(colour==c) "✓" else "●", Modifier.padding(vertical=8.dp), textAlign=androidx.compose.ui.text.style.TextAlign.Center, color=if(c==MethodMeshWidgetColour.DARK) Color.White else Color(0xFF302A28)) } } }
        OutlinedTextField(search, { search=it }, label={Text("Search tools")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
        if (targetType == MethodMeshWidgetTargetType.BUNDLE) {
            Text("Bundle contents · ${bundleKeys.size} selected", fontWeight=FontWeight.Bold)
            LazyColumn(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                items(choices.filter { search.isBlank() || it.name.contains(search,true) }, key={"${it.target.type}:${it.target.id}"}) { choice ->
                    val key="${choice.target.type}:${choice.target.id}"; val checked=key in bundleKeys
                    Card(Modifier.fillMaxWidth().clickable { bundleKeys = if(checked) bundleKeys-key else bundleKeys+key }) { Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment=Alignment.CenterVertically) { Checkbox(checked,{v->bundleKeys=if(v) bundleKeys+key else bundleKeys-key}); Column(Modifier.weight(1f)){Text(choice.name);Text(choice.target.type.name.lowercase().replaceFirstChar{it.uppercase()},style=MaterialTheme.typography.labelSmall)}; if(checked){ Row { IconButton(onClick={ val i=bundleKeys.indexOf(key); if(i>0){val m=bundleKeys.toMutableList(); val x=m.removeAt(i);m.add(i-1,x);bundleKeys=m}}){Text("↑")};IconButton(onClick={val i=bundleKeys.indexOf(key);if(i>=0&&i<bundleKeys.lastIndex){val m=bundleKeys.toMutableList();val x=m.removeAt(i);m.add(i+1,x);bundleKeys=m}}){Text("↓")} } } }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(6.dp)) { items(singles,key={it.target.id}) { choice -> Card(Modifier.fillMaxWidth().clickable{selectedId=choice.target.id}, colors=CardDefaults.cardColors(containerColor=if(selectedId==choice.target.id) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)){Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){RadioButton(selectedId==choice.target.id,{selectedId=choice.target.id});Text(choice.name)}} } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onCancel,Modifier.weight(1f)){Text("Cancel")}
            val valid = if(targetType==MethodMeshWidgetTargetType.BUNDLE) label.isNotBlank() && bundleTargets.isNotEmpty() else selectedId.isNotBlank()
            Button(onClick={
                val finalLabel = label.trim().ifBlank { selectedSingle?.name.orEmpty() }
                MethodMeshWidgetRepository.save(context, MethodMeshWidgetConfig(appWidgetId, finalLabel, targetType, if(targetType==MethodMeshWidgetTargetType.BUNDLE) "" else selectedId, iconKey, colour, appearance, if(targetType==MethodMeshWidgetTargetType.BUNDLE) bundleTargets else emptyList()))
                MethodMeshWidgetRepository.setExpanded(context, appWidgetId, false); onSaved()
            }, enabled=valid, modifier=Modifier.weight(1f)){Text(if(existing==null) "Add widget" else "Save")}
        }
    }
}
