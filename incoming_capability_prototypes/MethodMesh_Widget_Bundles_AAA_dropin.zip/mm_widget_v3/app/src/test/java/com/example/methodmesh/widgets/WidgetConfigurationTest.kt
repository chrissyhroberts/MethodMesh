package com.example.methodmesh.widgets

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class WidgetConfigurationTest {
    private fun decode(raw: String): MethodMeshWidgetConfig {
        val decoder = MethodMeshWidgetRepository::class.java.getDeclaredMethod("decode", JSONObject::class.java)
        decoder.isAccessible = true
        return decoder.invoke(MethodMeshWidgetRepository, JSONObject(raw)) as MethodMeshWidgetConfig
    }

    @Test fun `legacy widget keeps solid appearance`() {
        val c = decode("""{"appWidgetId":113,"label":"Compass","targetType":"PRESET","targetId":"saved-compass","iconKey":"COMPASS","colour":"TEAL"}""")
        assertEquals(MethodMeshWidgetAppearance.SOLID, c.appearance)
        assertEquals(MethodMeshWidgetTargetType.PRESET, c.targetType)
        assertEquals("saved-compass", c.targetId)
    }

    @Test fun `bundle preserves heterogeneous explicit order`() {
        val c = decode("""{"appWidgetId":7,"label":"Field tools","targetType":"BUNDLE","targetId":"","appearance":"GLASS","bundleTargets":[{"type":"SCHEDULE","id":"s1","fallbackLabel":"Rounds"},{"type":"PRESET","id":"p1","fallbackLabel":"Compass"},{"type":"PROTOCOL","id":"r1","fallbackLabel":"Survey"}]}""")
        assertEquals(MethodMeshWidgetTargetType.BUNDLE, c.targetType)
        assertEquals(MethodMeshWidgetAppearance.GLASS, c.appearance)
        assertEquals(listOf(MethodMeshWidgetTargetType.SCHEDULE, MethodMeshWidgetTargetType.PRESET, MethodMeshWidgetTargetType.PROTOCOL), c.bundleTargets.map { it.type })
    }

    @Test fun `invalid nested bundles and duplicate members are rejected during recovery`() {
        val c = decode("""{"appWidgetId":8,"targetType":"BUNDLE","bundleTargets":[{"type":"BUNDLE","id":"nested"},{"type":"PRESET","id":"p1"},{"type":"PRESET","id":"p1"},{"type":"PRESET","id":""}]}""")
        assertEquals(1, c.bundleTargets.size)
        assertEquals("p1", c.bundleTargets.single().id)
    }

    @Test fun `unknown appearance migrates to solid`() {
        val c = decode("""{"appWidgetId":9,"targetType":"PRESET","targetId":"coin","appearance":"UNKNOWN"}""")
        assertEquals(MethodMeshWidgetAppearance.SOLID, c.appearance)
    }
}
