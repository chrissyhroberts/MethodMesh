#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import shutil
from collections import defaultdict
from pathlib import Path

from doc_common import (
    Record, canonical_series_key, category_dir, classify, discover_module_dirs,
    is_doc_candidate, latest_in_series, read_text_preview, rel_posix, sha256_file,
    write_manifest,
)


def main() -> int:
    ap = argparse.ArgumentParser(description='Collect and triage MethodMesh documentation without modifying the repository.')
    ap.add_argument('--repo', default='.', help='MethodMesh repository root')
    ap.add_argument('--out', default='.methodmesh-doc-review', help='staging directory, relative to repo unless absolute')
    ap.add_argument('--fresh', action='store_true', help='replace an existing staging directory')
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    out = Path(args.out)
    if not out.is_absolute():
        out = repo / out
    if out.exists() and args.fresh:
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    sorted_root = out / 'sorted'
    if sorted_root.exists():
        shutil.rmtree(sorted_root)
    sorted_root.mkdir(parents=True)

    modules = discover_module_dirs(repo)
    candidates = [p for p in repo.rglob('*') if is_doc_candidate(p, repo)]
    candidates = [p for p in candidates if out not in p.parents]
    candidates.sort(key=lambda p: rel_posix(p, repo).lower())

    hashes: dict[str, str] = {}
    series: dict[str, list[Path]] = defaultdict(list)
    previews = {}
    initial = []
    for i, p in enumerate(candidates, 1):
        doc_id = f'DOC{i:05d}'
        h = sha256_file(p)
        preview = read_text_preview(p)
        previews[p] = preview
        cat, module, conf, reasons = classify(p, repo, modules, preview)
        initial.append((doc_id, p, h, cat, module, conf, reasons))
        series[canonical_series_key(p)].append(p)

    latest = {k: latest_in_series(v) for k, v in series.items()}
    records: list[Record] = []
    id_by_path = {p: doc_id for doc_id, p, *_ in initial}

    for doc_id, p, h, cat, module, conf, reasons in initial:
        duplicate_of = hashes.get(h, '')
        if not duplicate_of:
            hashes[h] = doc_id
        key = canonical_series_key(p)
        newest = latest.get(key)
        superseded_by = ''
        if newest and newest != p and len(series[key]) > 1:
            superseded_by = id_by_path[newest]
            # Strongly suggest C only for version/date siblings; leave exact module ownership intact if already well placed.
            cat = 'C'
            conf = max(conf, 0.82)
            reasons = reasons + [f'older member of a version/date series; newest is {rel_posix(newest, repo)}']
        if duplicate_of:
            cat = 'C'
            conf = max(conf, 0.90)
            reasons = reasons + [f'exact duplicate of {duplicate_of}']

        cat_name = category_dir(cat)
        if cat == 'B':
            target_dir = sorted_root / cat_name / (module or '_UNKNOWN_MODULE')
        else:
            target_dir = sorted_root / cat_name
        target_dir.mkdir(parents=True, exist_ok=True)
        staged = target_dir / f'{doc_id}__{p.name}'
        shutil.copy2(p, staged)

        records.append(Record(
            doc_id=doc_id,
            original_path=rel_posix(p, repo),
            staged_path=staged.relative_to(out).as_posix(),
            filename=p.name,
            extension=p.suffix.lower(),
            size_bytes=p.stat().st_size,
            sha256=h,
            suggested_category=cat,
            suggested_module=module,
            confidence=round(conf, 2),
            reasons=' | '.join(reasons),
            duplicate_of=duplicate_of,
            superseded_by=superseded_by,
        ))

    write_manifest(out / 'manifest.csv', records)

    counts = defaultdict(int)
    for r in records:
        counts[r.suggested_category] += 1
    review = out / 'REVIEW_INDEX.md'
    with review.open('w', encoding='utf-8') as f:
        f.write('# MethodMesh documentation review staging\n\n')
        f.write(f'Repository: `{repo}`  \n')
        f.write(f'Documents collected: **{len(records)}**  \n')
        f.write(f"Suggested A/project-wide: **{counts['A']}**  \n")
        f.write(f"Suggested B/module-owned: **{counts['B']}**  \n")
        f.write(f"Suggested C/archive/legacy: **{counts['C']}**  \n\n")
        f.write('## How to review\n\n')
        f.write('The repository has not been changed. Copies are under `sorted/`. Move a staged file between `A_PROJECT_WIDE`, `B_MODULE_OWNED/<module>`, and `C_ARCHIVE_LEGACY` to override the suggestion. Items in `REVIEW` must be resolved before apply. The stable `DOCxxxxx__` prefix lets the apply script recover the original path.\n\n')
        f.write('`manifest.csv` records original paths, hashes, inferred module ownership, duplicate/version relationships, confidence, and reasons. You may also edit its `decision`, `target_module`, `master_action`, `master_section`, and `notes` columns; explicit manifest decisions override folder placement.\n\n')
        f.write('## Safety\n\n')
        f.write('Generated/build trees are excluded so APK/intermediate copies of module documentation and ODK templates are not mistaken for source documentation. `apply_doc_plan.py` is dry-run by default and creates a backup manifest before any move.\n')

    print(f'Collected {len(records)} documentation candidates into {out}')
    print(f"A={counts['A']} B={counts['B']} C={counts['C']}")
    print(f'Review: {review}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
