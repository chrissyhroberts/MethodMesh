#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

from doc_common import extract_for_master, read_manifest
from apply_doc_plan import decisions_from_sorted

ID_RE = re.compile(r'^(DOC\d{5})__')


def normalize_para(p: str) -> str:
    return re.sub(r'\s+', ' ', p).strip().lower()


def split_paragraphs(text: str):
    return re.split(r'\n\s*\n', text.replace('\r\n', '\n'))


def score_source(name: str) -> tuple:
    n = name.lower()
    return (
        0 if 'master_book' in n or 'master book' in n else 1,
        0 if 'architecture' in n or 'standard' in n else 1,
        0 if 'module' in n and 'review' in n else 1,
        0 if 'odk' in n or 'xlsform' in n or 'kobo' in n else 1,
        0 if 'protocol' in n or 'preset' in n else 1,
        0 if 'ui' in n or 'ux' in n else 1,
        0 if 'roadmap' in n else 1,
        n,
    )


def main() -> int:
    ap = argparse.ArgumentParser(description='Assemble all reviewed A/project-wide sources into one provenance-preserving Master Book working source.')
    ap.add_argument('--repo', default='.')
    ap.add_argument('--review', default='.methodmesh-doc-review')
    ap.add_argument('--output', default='docs/MethodMesh_Master_Book_CONSOLIDATION_WORKING.md')
    ap.add_argument('--no-exact-dedupe', action='store_true', help='do not remove exact duplicate paragraphs across sources')
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    review = Path(args.review)
    if not review.is_absolute():
        review = repo / review
    output = Path(args.output)
    if not output.is_absolute():
        output = repo / output

    records = {r.doc_id: r for r in read_manifest(review / 'manifest.csv')}
    folder_decisions = decisions_from_sorted(review)
    selected = []
    for doc_id, r in records.items():
        category, _ = folder_decisions.get(doc_id, ('', ''))
        if r.decision.strip().upper() in {'A', 'B', 'C'}:
            category = r.decision.strip().upper()
        if category == 'A' and r.master_action.strip().lower() != 'skip':
            selected.append(r)
    selected.sort(key=lambda r: score_source(r.filename))

    output.parent.mkdir(parents=True, exist_ok=True)
    seen = set()
    with output.open('w', encoding='utf-8') as f:
        f.write('# MethodMesh Master Book — consolidation working source\n\n')
        f.write('> Generated from reviewed project-wide documentation. This is an editorial working source, not automatically a normative release. Source markers and hashes are intentionally retained until the final Master Book has been reviewed.\n\n')
        f.write('## Source register\n\n')
        f.write('| ID | Original path | SHA-256 | Action | Section hint |\n|---|---|---|---|---|\n')
        for r in selected:
            f.write(f'| {r.doc_id} | `{r.original_path}` | `{r.sha256[:16]}…` | {r.master_action} | {r.master_section or "—"} |\n')
        f.write('\n---\n\n')

        for r in selected:
            src = repo / r.original_path
            staged = review / r.staged_path
            path = src if src.exists() else staged
            text = extract_for_master(path)
            paras = split_paragraphs(text)
            kept = []
            for p in paras:
                key = normalize_para(p)
                if not key:
                    continue
                if not args.no_exact_dedupe and len(key) > 80 and key in seen:
                    continue
                if len(key) > 80:
                    seen.add(key)
                kept.append(p.strip())
            body = '\n\n'.join(kept)
            f.write(f'<!-- BEGIN SOURCE {r.doc_id} | {r.original_path} | sha256={r.sha256} -->\n')
            f.write(f'## Source: {r.filename}\n\n')
            if r.master_section:
                f.write(f'**Editorial section hint:** {r.master_section}\n\n')
            f.write(body)
            f.write(f'\n\n<!-- END SOURCE {r.doc_id} -->\n\n---\n\n')

    print(f'Assembled {len(selected)} project-wide sources into {output}')
    print('Next step: editorially merge/reconcile this working source into the normative Master Book, then use apply_doc_plan.py --master-final ... to finalize and archive superseded project-wide source docs.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
