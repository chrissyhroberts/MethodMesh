# MethodMesh Documentation Consolidator

A deliberately conservative toolkit for turning a repository with documentation scattered everywhere into one maintainable documentation model:

- **A — project-wide:** material that belongs in the single MethodMesh Master Book.
- **B — module-owned:** material that belongs under the relevant module's `docs/` directory.
- **C — archive/legacy:** superseded, duplicate, irrelevant, archival, or ResearchOS/RIL legacy material.

The toolkit is designed around the current MethodMesh repository shape: Android sources under `app/src/main/java/com/example/methodmesh/`, individual modules under `modules/<module>/`, and module-owned READMEs, validation notes, roadmaps, XLSForms and related files under module `docs/` directories.

## Why this is two-stage

Classification and editorial consolidation are not the same problem. A script can safely discover, hash, copy, de-duplicate, identify versions, infer module ownership, and move approved files. It should **not silently rewrite architectural doctrine** based on heuristics.

The workflow therefore creates a reviewable corpus first, then assembles approved project-wide material into one provenance-preserving Master Book working source. The final semantic reconciliation can then be reviewed before old project-wide documents are archived.

## 1. Collect everything

From the MethodMesh repository root:

```bash
python3 path/to/methodmesh_documentation_consolidator/collect_docs.py --repo . --fresh
```

This creates:

```text
.methodmesh-doc-review/
├── manifest.csv
├── REVIEW_INDEX.md
└── sorted/
    ├── A_PROJECT_WIDE/
    ├── B_MODULE_OWNED/
    │   └── <module>/
    ├── C_ARCHIVE_LEGACY/
    └── REVIEW/
```

The source repository is not modified. Every collected file is a copy with a stable `DOCxxxxx__` prefix. Build/generated directories are excluded deliberately so generated APK/intermediate copies do not swamp the review.

### What it understands

The collector uses path, filename and lightweight content heuristics to recognize:

- existing `modules/<module>/docs/...` ownership;
- misplaced documents whose filename uniquely identifies a known module;
- project-wide architecture, Master Book, standards, UI/UX, ODK/XLSForm/Kobo, protocol, preset, integration and roadmap material;
- explicit ResearchOS / RIL / legacy / archive material;
- exact duplicates by SHA-256;
- older siblings in a version/date series;
- module-owned XLSForm examples and related docs artifacts.

Suggestions are deliberately reviewable. Low-confidence material is not meant to be trusted blindly.

## 2. Review/sort

You can review in either of two ways.

**Folder workflow:** move the staged `DOCxxxxx__...` copy into the correct A/B/C directory. For B, put it under `B_MODULE_OWNED/<module>/`.

**Manifest workflow:** edit `manifest.csv`. Set `decision` to `A`, `B`, or `C`; for B set `target_module` if necessary. Explicit manifest decisions override folder placement.

Useful optional columns:

- `master_action`: `merge` (default) or `skip`;
- `master_section`: an editorial section hint for the later Master Book merge;
- `notes`: reviewer notes.

## 3. Preview repository reorganization

```bash
python3 path/to/methodmesh_documentation_consolidator/apply_doc_plan.py \
  --repo . \
  --review .methodmesh-doc-review
```

This is a **dry run**. It prints every proposed move and refuses to proceed if anything remains unresolved.

Group B targets become:

```text
app/src/main/java/com/example/methodmesh/modules/<module>/docs/<filename>
```

Group C targets become a date-stamped tree under:

```text
docs/archive/YYYYMMDD_documentation_consolidation/<original-path>
```

A documents are retained until a finalized Master Book exists.

## 4. Assemble all A material into one Master Book working source

```bash
python3 path/to/methodmesh_documentation_consolidator/assemble_master.py \
  --repo . \
  --review .methodmesh-doc-review
```

Default output:

```text
docs/MethodMesh_Master_Book_CONSOLIDATION_WORKING.md
```

The assembler:

- includes every approved A source unless `master_action=skip`;
- puts the existing Master Book/architecture material first;
- extracts text from Markdown/text/HTML/DOCX directly;
- extracts PDFs when `pypdf` or `pdftotext` is available;
- preserves a source register, original path and SHA-256 for provenance;
- removes exact repeated long paragraphs by default;
- retains explicit source boundaries so conflicting generations can be editorially reconciled rather than silently mixed.

This working source is intentionally **not declared normative automatically**. It is the single packet from which the next Master Book release can be written and checked.

## 5. Apply B/C reorganization

After reviewing the dry run:

```bash
python3 path/to/methodmesh_documentation_consolidator/apply_doc_plan.py \
  --repo . \
  --review .methodmesh-doc-review \
  --apply \
  --mode move
```

The script writes an apply log and keeps the review manifest as a provenance ledger. Name collisions with different content are fatal instead of being overwritten.

## 6. Finalize the single-document model

Once the working source has been editorially consolidated into a reviewed final Markdown Master Book:

```bash
python3 path/to/methodmesh_documentation_consolidator/apply_doc_plan.py \
  --repo . \
  --review .methodmesh-doc-review \
  --master-final /path/to/MethodMesh_Master_Book_v1.06.md \
  --archive-project-sources \
  --apply \
  --mode move
```

This installs the final document at:

```text
docs/MethodMesh_Master_Book.md
```

and archives the now-superseded A source documents only **after** the final Master Book has been supplied.

## Safety properties

- discovery never modifies source files;
- generated/build/intermediate directories are excluded;
- apply is dry-run by default;
- unresolved decisions block apply;
- SHA-256 is recorded for every item;
- exact duplicates and version siblings are surfaced;
- collisions never overwrite different content;
- A-source archival requires an explicit final Master Book;
- a prior canonical Master Book is backed up before replacement;
- every apply produces a machine-readable log;
- already-correct module docs are no-ops;
- no deployed XLSForm `form_id` or workbook content is modified by this documentation tool.

## Recommended repository end state

```text
docs/
├── MethodMesh_Master_Book.md        # only normative project-wide documentation
└── archive/                         # historical project-wide material

app/src/main/java/com/example/methodmesh/modules/
└── <module>/
    └── docs/                        # module-specific README, validation, XLSForms, local roadmap notes
```

The aim is that future project-wide doctrine is edited in exactly one place, while module-local implementation/documentation remains physically with the module it describes.
