#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import re
import shutil
from pathlib import Path

from doc_common import discover_module_dirs, read_manifest, rel_posix, sha256_file

ID_RE = re.compile(r'^(DOC\d{5})__')


def decisions_from_sorted(review_root: Path) -> dict[str, tuple[str, str]]:
    result = {}
    sorted_root = review_root / 'sorted'
    for p in sorted_root.rglob('*'):
        if not p.is_file():
            continue
        m = ID_RE.match(p.name)
        if not m:
            continue
        doc_id = m.group(1)
        rel = p.relative_to(sorted_root)
        parts = rel.parts
        if not parts:
            continue
        if parts[0] == 'A_PROJECT_WIDE':
            result[doc_id] = ('A', '')
        elif parts[0] == 'C_ARCHIVE_LEGACY':
            result[doc_id] = ('C', '')
        elif parts[0] == 'B_MODULE_OWNED':
            module = parts[1] if len(parts) >= 3 else ''
            result[doc_id] = ('B', module)
        elif parts[0] == 'REVIEW':
            result[doc_id] = ('', '')
    return result


def copy_or_move(src: Path, dst: Path, mode: str) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.resolve() == dst.resolve():
        return
    if dst.exists():
        if sha256_file(src) == sha256_file(dst):
            if mode == 'move':
                src.unlink()
            return
        raise RuntimeError(f'Collision: {dst} already exists with different content')
    if mode == 'copy':
        shutil.copy2(src, dst)
    else:
        shutil.move(str(src), str(dst))


def main() -> int:
    ap = argparse.ArgumentParser(description='Apply a reviewed MethodMesh documentation plan. Dry-run unless --apply is supplied.')
    ap.add_argument('--repo', default='.')
    ap.add_argument('--review', default='.methodmesh-doc-review')
    ap.add_argument('--mode', choices=['copy', 'move'], default='move', help='action used when --apply is supplied')
    ap.add_argument('--apply', action='store_true', help='perform changes; otherwise print plan only')
    ap.add_argument('--archive-root', default='docs/archive')
    ap.add_argument('--master-final', help='optional finalized Master Book file to install as docs/MethodMesh_Master_Book.md')
    ap.add_argument('--archive-project-sources', action='store_true', help='archive A-source originals; requires --master-final')
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    review = Path(args.review)
    if not review.is_absolute():
        review = repo / review
    records = read_manifest(review / 'manifest.csv')
    folder_decisions = decisions_from_sorted(review)
    modules = discover_module_dirs(repo)
    archive_root = repo / args.archive_root / dt.datetime.now().strftime('%Y%m%d_documentation_consolidation')

    plan = []
    unresolved = []
    for r in records:
        category, folder_module = folder_decisions.get(r.doc_id, ('', ''))
        if r.decision.strip().upper() in {'A', 'B', 'C'}:
            category = r.decision.strip().upper()
        module = r.target_module.strip() or folder_module or r.suggested_module
        src = repo / r.original_path
        if category == 'B':
            if not module:
                unresolved.append(f'{r.doc_id}: B requires target module')
                continue
            if module not in modules:
                unresolved.append(f'{r.doc_id}: unknown target module {module!r}')
                continue
            dst = modules[module] / 'docs' / src.name
            plan.append((r, category, src, dst, 'module documentation'))
        elif category == 'C':
            dst = archive_root / r.original_path
            plan.append((r, category, src, dst, 'archive/legacy'))
        elif category == 'A':
            if args.archive_project_sources:
                if not args.master_final:
                    unresolved.append('--archive-project-sources requires --master-final')
                    continue
                dst = archive_root / 'project_wide_sources' / r.original_path
                plan.append((r, category, src, dst, 'project-wide source archived after Master Book finalization'))
            else:
                plan.append((r, category, src, src, 'project-wide source retained pending Master Book finalization'))
        else:
            unresolved.append(f'{r.doc_id}: unresolved category')

    if unresolved:
        print('Cannot apply: unresolved items exist:')
        for x in unresolved[:100]:
            print('  -', x)
        if len(unresolved) > 100:
            print(f'  ... {len(unresolved)-100} more')
        return 2

    print('Documentation reorganization plan')
    print('APPLY' if args.apply else 'DRY RUN')
    for r, cat, src, dst, why in plan:
        action = 'KEEP' if src.resolve() == dst.resolve() else args.mode.upper()
        print(f'{r.doc_id} [{cat}] {action}: {rel_posix(src, repo)} -> {rel_posix(dst, repo)} ({why})')

    if not args.apply:
        print('\nNo repository files changed. Re-run with --apply after reviewing this plan.')
        return 0

    backup = review / f'apply_backup_{dt.datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    shutil.copy2(review / 'manifest.csv', backup)
    change_log = []
    for r, cat, src, dst, why in plan:
        if not src.exists():
            change_log.append({'doc_id': r.doc_id, 'status': 'missing_source', 'source': str(src)})
            continue
        if src.resolve() != dst.resolve():
            copy_or_move(src, dst, args.mode)
        change_log.append({'doc_id': r.doc_id, 'category': cat, 'source': str(src), 'target': str(dst), 'mode': args.mode, 'reason': why})

    if args.master_final:
        mf = Path(args.master_final).resolve()
        if not mf.exists():
            raise FileNotFoundError(mf)
        canonical = repo / 'docs' / 'MethodMesh_Master_Book.md'
        canonical.parent.mkdir(parents=True, exist_ok=True)
        if canonical.exists() and sha256_file(canonical) != sha256_file(mf):
            prior = archive_root / 'prior_master' / canonical.name
            prior.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(canonical, prior)
        shutil.copy2(mf, canonical)
        change_log.append({'status': 'master_installed', 'source': str(mf), 'target': str(canonical)})

    log_path = review / f'apply_log_{dt.datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
    log_path.write_text(json.dumps(change_log, indent=2), encoding='utf-8')
    print(f'Applied. Log: {log_path}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
