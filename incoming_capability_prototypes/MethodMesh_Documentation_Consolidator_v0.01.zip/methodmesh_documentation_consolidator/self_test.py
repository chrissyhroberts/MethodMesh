#!/usr/bin/env python3
from __future__ import annotations
import csv
import subprocess
import tempfile
from pathlib import Path


def main():
    here = Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory() as td:
        repo = Path(td) / 'repo'
        mod = repo / 'app/src/main/java/com/example/methodmesh/modules/gamedeck'
        (mod / 'docs').mkdir(parents=True)
        (mod / 'GameDeckModule.kt').write_text('class GameDeckModule')
        (mod / 'docs/README_GameDeck.md').write_text('# GameDeck\nModule documentation')
        (repo / '000_MethodMesh_Master_Book_v1.03.md').write_text('# MethodMesh Master Book\nArchitecture standard')
        (repo / '001_GameDeck_GameLab_Specification_v0.01.md').write_text('# GameDeck spec old')
        (repo / '001_GameDeck_GameLab_Specification_v0.02.md').write_text('# GameDeck spec new')
        (repo / 'ResearchOS_legacy.md').write_text('# ResearchOS\nResearch Intent Language legacy notes')
        build = repo / 'app/build/generated'
        build.mkdir(parents=True)
        (build / 'README_generated.md').write_text('must be excluded')

        subprocess.check_call(['python3', str(here/'collect_docs.py'), '--repo', str(repo), '--fresh'])
        mf = repo / '.methodmesh-doc-review/manifest.csv'
        rows = list(csv.DictReader(mf.open()))
        names = {r['filename']: r for r in rows}
        assert 'README_generated.md' not in names
        assert names['README_GameDeck.md']['suggested_category'] == 'B'
        assert names['000_MethodMesh_Master_Book_v1.03.md']['suggested_category'] == 'A'
        assert names['ResearchOS_legacy.md']['suggested_category'] == 'C'
        assert names['001_GameDeck_GameLab_Specification_v0.02.md']['suggested_category'] == 'B'
        assert names['001_GameDeck_GameLab_Specification_v0.01.md']['suggested_category'] == 'C'
        subprocess.check_call(['python3', str(here/'assemble_master.py'), '--repo', str(repo)])
        assert (repo/'docs/MethodMesh_Master_Book_CONSOLIDATION_WORKING.md').exists()
    print('Self-test passed')

if __name__ == '__main__':
    main()
