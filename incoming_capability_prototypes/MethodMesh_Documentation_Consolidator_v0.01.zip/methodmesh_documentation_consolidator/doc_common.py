#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Optional
from xml.etree import ElementTree as ET

TEXT_EXTS = {'.md', '.markdown', '.qmd', '.rst', '.adoc', '.tex'}
DOC_EXTS = TEXT_EXTS | {'.pdf', '.docx', '.odt', '.rtf', '.html', '.htm'}
CONTEXT_EXTS = {'.txt', '.xlsx', '.xls', '.xml', '.json', '.yaml', '.yml', '.csv', '.png', '.jpg', '.jpeg', '.webp', '.svg'}
SPECIAL_NAMES = {'readme', 'license', 'licence', 'notice', 'changelog', 'contributing', 'authors'}
EXCLUDED_DIRS = {
    '.git', '.gradle', '.idea', '.vscode', '.venv', 'venv', 'node_modules',
    'build', 'dist', 'out', 'target', 'intermediates', 'generated', '__pycache__',
    '.documentation_review', 'documentation_review', '.methodmesh-doc-review',
}
DOCISH_PARTS = {'docs', 'doc', 'documentation', 'manual', 'manuals', 'handbook', 'spec', 'specs', 'architecture', 'design', 'guides', 'guide'}
PROJECT_KEYWORDS = {
    'methodmesh', 'master book', 'architecture', 'standard', 'standards', 'roadmap',
    'module review', 'review manual', 'integration', 'ui', 'ux', 'protocol', 'preset',
    'odk', 'kobo', 'xlsform', 'scheduler', 'widget', 'capability contract', 'developer',
}
LEGACY_KEYWORDS = {
    'researchos', 'research os', 'research operating system', 'research intent language',
    'ril_', 'ril ', 'legacy', 'deprecated', 'obsolete', 'superseded', 'archive', 'archival',
}

VERSION_RE = re.compile(r'(?i)(?:^|[_\- .])v(\d+(?:\.\d+){0,4})(?:$|[_\- .])')
DATE_RE = re.compile(r'(?<!\d)(20\d{2})[-_]?([01]\d)[-_]?([0-3]\d)(?!\d)')


def norm_token(s: str) -> str:
    return re.sub(r'[^a-z0-9]+', '', s.lower())


def rel_posix(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def parse_version(name: str) -> tuple[int, ...]:
    m = VERSION_RE.search(name)
    if not m:
        return ()
    try:
        return tuple(int(x) for x in m.group(1).split('.'))
    except ValueError:
        return ()


def canonical_series_key(path: Path) -> str:
    stem = path.stem.lower()
    stem = VERSION_RE.sub(' ', stem)
    stem = DATE_RE.sub(' ', stem)
    stem = re.sub(r'(?i)\b(copy|final|draft|old|new|latest|rev(?:ision)?\s*\d*)\b', ' ', stem)
    stem = re.sub(r'\(\d+\)$', ' ', stem)
    stem = re.sub(r'[^a-z0-9]+', '_', stem).strip('_')
    return f'{stem}{path.suffix.lower()}'


def is_excluded(path: Path, root: Path) -> bool:
    try:
        parts = path.resolve().relative_to(root.resolve()).parts
    except Exception:
        parts = path.parts
    return any(part in EXCLUDED_DIRS for part in parts)


def docish_context(path: Path, root: Path) -> bool:
    rel = path.resolve().relative_to(root.resolve())
    parts = {p.lower() for p in rel.parts[:-1]}
    if parts & DOCISH_PARTS:
        return True
    name = path.stem.lower()
    return any(k in name for k in ('readme', 'roadmap', 'manual', 'handbook', 'spec', 'architecture', 'design', 'validation', 'guide', 'master_book', 'master book', 'odk', 'xlsform'))


def is_doc_candidate(path: Path, root: Path) -> bool:
    if not path.is_file() or is_excluded(path, root):
        return False
    name_l = path.name.lower()
    stem_l = path.stem.lower()
    ext = path.suffix.lower()
    if stem_l in SPECIAL_NAMES or any(name_l.startswith(x + '.') for x in SPECIAL_NAMES):
        return True
    if ext in DOC_EXTS:
        if ext in {'.pdf', '.docx', '.odt', '.rtf'}:
            return True
        return ext != '.html' or docish_context(path, root)
    if ext in CONTEXT_EXTS:
        if ext == '.txt':
            return docish_context(path, root) or len(path.resolve().relative_to(root.resolve()).parts) == 1
        if ext in {'.xlsx', '.xls', '.xml'} and name_l.startswith('example_odk'):
            return True
        return docish_context(path, root)
    return False


def discover_module_dirs(root: Path) -> dict[str, Path]:
    candidates = [
        root / 'app/src/main/java/com/example/methodmesh/modules',
        root / 'modules',
    ]
    module_root = next((p for p in candidates if p.is_dir()), None)
    result: dict[str, Path] = {}
    if module_root:
        for p in sorted(module_root.iterdir()):
            if p.is_dir() and not p.name.startswith('.'):
                result[p.name] = p
    return result


def infer_module_owner(path: Path, root: Path, modules: dict[str, Path]) -> tuple[str, str]:
    rp = path.resolve()
    for name, mdir in modules.items():
        try:
            rp.relative_to(mdir.resolve())
            return name, 'path is inside module directory'
        except Exception:
            pass
    # Generic docs folder whose parent owns a Module.kt.
    for parent in path.parents:
        if parent == root or parent.parent == parent:
            break
        if parent.name.lower() == 'docs':
            owner_dir = parent.parent
            if any(owner_dir.glob('*Module.kt')):
                return owner_dir.name, 'docs folder belongs to directory containing *Module.kt'
    # Root-level or misplaced docs that clearly name one module.
    token = norm_token(path.stem)
    matches = [m for m in modules if norm_token(m) and norm_token(m) in token]
    if len(matches) == 1:
        return matches[0], 'filename uniquely names a known module'
    return '', ''


def read_text_preview(path: Path, limit: int = 200_000) -> str:
    ext = path.suffix.lower()
    try:
        if ext in TEXT_EXTS | {'.txt', '.csv', '.json', '.yaml', '.yml', '.xml', '.html', '.htm'}:
            return path.read_text(encoding='utf-8', errors='replace')[:limit]
        if ext == '.docx':
            with zipfile.ZipFile(path) as zf:
                data = zf.read('word/document.xml')
            root = ET.fromstring(data)
            out = []
            for elem in root.iter():
                if elem.tag.endswith('}t') and elem.text:
                    out.append(elem.text)
                elif elem.tag.endswith('}p'):
                    out.append('\n')
            return ' '.join(out)[:limit]
        if ext == '.pdf':
            try:
                import pypdf  # type: ignore
                reader = pypdf.PdfReader(str(path))
                text = '\n'.join((p.extract_text() or '') for p in reader.pages[:20])
                return text[:limit]
            except Exception:
                pdftotext = shutil.which('pdftotext')
                if pdftotext:
                    proc = subprocess.run([pdftotext, str(path), '-'], capture_output=True, text=True, timeout=30)
                    if proc.returncode == 0:
                        return proc.stdout[:limit]
    except Exception:
        pass
    return ''


def content_legacy_score(text: str) -> int:
    t = text.lower()
    score = 0
    for k in LEGACY_KEYWORDS:
        if k in t:
            score += min(3, t.count(k))
    return score


def classify(path: Path, root: Path, modules: dict[str, Path], preview: str) -> tuple[str, str, float, list[str]]:
    rel = rel_posix(path, root)
    rel_l = rel.lower()
    name_l = path.name.lower()
    owner, owner_reason = infer_module_owner(path, root, modules)
    reasons: list[str] = []

    if owner:
        reasons.append(owner_reason)
        return 'B', owner, 0.98 if '/modules/' in '/' + rel_l else 0.82, reasons

    if any(k in rel_l for k in ('/archive/', '/legacy/', '/deprecated/', '/obsolete/')):
        reasons.append('path explicitly indicates archive/legacy/deprecated material')
        return 'C', '', 0.98, reasons

    legacy_name = any(k.replace(' ', '') in norm_token(name_l) for k in ('researchos', 'research intent language')) or name_l.startswith('ril_')
    legacy_content = content_legacy_score(preview)
    if legacy_name:
        reasons.append('filename strongly indicates ResearchOS/RIL legacy material')
        return 'C', '', 0.95, reasons
    if legacy_content >= 5 and 'methodmesh' not in preview.lower()[:10_000]:
        reasons.append('content is dominated by ResearchOS/RIL/legacy terminology')
        return 'C', '', 0.78, reasons

    text_l = (name_l + '\n' + preview[:40_000]).lower()
    hits = [k for k in PROJECT_KEYWORDS if k in text_l]
    if hits:
        reasons.append('project-wide terminology: ' + ', '.join(sorted(hits)[:8]))
        return 'A', '', min(0.96, 0.68 + 0.03 * len(hits)), reasons

    if len(path.resolve().relative_to(root.resolve()).parts) == 1:
        reasons.append('root-level documentation with no module owner')
        return 'A', '', 0.65, reasons

    reasons.append('documentation candidate with no clear module or legacy ownership; project-wide is only a low-confidence suggestion')
    return 'A', '', 0.45, reasons


def latest_in_series(paths: list[Path]) -> Optional[Path]:
    if not paths:
        return None
    def score(p: Path):
        v = parse_version(p.name)
        date = DATE_RE.search(p.name)
        d = tuple(int(x) for x in date.groups()) if date else ()
        try:
            mt = p.stat().st_mtime
        except OSError:
            mt = 0.0
        return (1 if v else 0, v, 1 if d else 0, d, mt, p.name.lower())
    return max(paths, key=score)

@dataclass
class Record:
    doc_id: str
    original_path: str
    staged_path: str
    filename: str
    extension: str
    size_bytes: int
    sha256: str
    suggested_category: str
    suggested_module: str
    confidence: float
    reasons: str
    duplicate_of: str = ''
    superseded_by: str = ''
    decision: str = ''
    target_module: str = ''
    master_action: str = 'merge'
    master_section: str = ''
    notes: str = ''

MANIFEST_FIELDS = list(Record.__dataclass_fields__.keys())


def write_manifest(path: Path, records: list[Record]) -> None:
    with path.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=MANIFEST_FIELDS)
        w.writeheader()
        for r in records:
            w.writerow(asdict(r))


def read_manifest(path: Path) -> list[Record]:
    out = []
    with path.open(newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            row['size_bytes'] = int(row['size_bytes'])
            row['confidence'] = float(row['confidence'])
            out.append(Record(**row))
    return out


def category_dir(category: str) -> str:
    return {'A': 'A_PROJECT_WIDE', 'B': 'B_MODULE_OWNED', 'C': 'C_ARCHIVE_LEGACY'}.get(category, 'REVIEW')


def extract_for_master(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in TEXT_EXTS | {'.txt', '.csv', '.json', '.yaml', '.yml', '.xml'}:
        return path.read_text(encoding='utf-8', errors='replace')
    if ext in {'.html', '.htm'}:
        raw = path.read_text(encoding='utf-8', errors='replace')
        raw = re.sub(r'(?is)<script.*?</script>|<style.*?</style>', ' ', raw)
        raw = re.sub(r'(?s)<[^>]+>', '\n', raw)
        return html.unescape(raw)
    if ext == '.docx':
        return read_text_preview(path, limit=10_000_000)
    if ext == '.pdf':
        text = read_text_preview(path, limit=10_000_000)
        if text:
            return text
        return '[PDF text extraction unavailable on this machine. Keep this source for editorial review.]'
    return f'[Binary/non-text source retained separately: {path.name}]'
