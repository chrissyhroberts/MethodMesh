package com.example.methodmesh.modules.signals

internal data class SignalFskProfile(
    val id: String,
    val label: String,
    val markHz: Double,
    val spaceHz: Double,
    val bitMs: Int
)

internal object SignalFskProfiles {
    val audible: List<SignalFskProfile> = listOf(
        SignalFskProfile("A", "A · balanced · 1.2/2.2 kHz · 60 ms", 1200.0, 2200.0, 60),
        SignalFskProfile("B", "B · tolerant · 1.0/1.8 kHz · 80 ms", 1000.0, 1800.0, 80),
        SignalFskProfile("C", "C · fast test · 1.6/2.6 kHz · 40 ms", 1600.0, 2600.0, 40),
        SignalFskProfile("D", "D · slow/radio · 2.2/3.4 kHz · 120 ms", 2200.0, 3400.0, 120)
    )

    // Many phone speakers/microphones roll off sharply above ~15-16 kHz. These
    // profiles deliberately step upward from a device-friendly high-audio pair
    // instead of assuming 18-19 kHz is usable.
    val highBand: List<SignalFskProfile> = listOf(
        SignalFskProfile("A", "A · 12/13 kHz · 100 ms", 12000.0, 13000.0, 100),
        SignalFskProfile("B", "B · 13/14 kHz · 120 ms", 13000.0, 14000.0, 120),
        SignalFskProfile("C", "C · 14/15 kHz · 140 ms", 14000.0, 15000.0, 140),
        SignalFskProfile("D", "D · 15/16 kHz · 160 ms", 15000.0, 16000.0, 160)
    )

    fun list(ultrasonic: Boolean): List<SignalFskProfile> = if (ultrasonic) highBand else audible

    fun matching(ultrasonic: Boolean, markHz: Double, spaceHz: Double, bitMs: Int): SignalFskProfile? =
        list(ultrasonic).firstOrNull {
            kotlin.math.abs(it.markHz - markHz) < 1.0 &&
                kotlin.math.abs(it.spaceHz - spaceHz) < 1.0 &&
                it.bitMs == bitMs
        }
}
