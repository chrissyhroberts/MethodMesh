package com.example.methodmesh.modules.signals

import kotlin.math.max

object MorseCodec {
    private val encodeMap: Map<Char, String> = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '/' to "-..-.",
        '=' to "-...-", '+' to ".-.-.", '-' to "-....-", '(' to "-.--.", ')' to "-.--.-",
        ':' to "---...", ';' to "-.-.-.", '@' to ".--.-."
    )
    private val decodeMap = encodeMap.entries.associate { (k, v) -> v to k }

    sealed interface Element {
        data class Mark(val symbol: Char, val units: Int, val sourceChar: Char) : Element
        data class Gap(val units: Int, val kind: GapKind) : Element
    }

    enum class GapKind { ELEMENT, LETTER, WORD, LOOP }

    fun encode(text: String): String = text
        .uppercase()
        .trim()
        .split(Regex("\\s+"))
        .joinToString(" / ") { word ->
            word.mapNotNull { encodeMap[it] }.joinToString(" ")
        }

    fun decode(notation: String): String = notation
        .trim()
        .split(Regex("\\s*/\\s*"))
        .joinToString(" ") { word ->
            word.trim().split(Regex("\\s+")).mapNotNull { decodeMap[it] }.joinToString("")
        }

    /**
     * Build one framed Morse transmission. A deliberately unmistakable twelve-unit
     * sync mark precedes the payload. It is not a Morse character: receivers use
     * it only to establish a message boundary so repeated cycles refine one best
     * guess instead of being concatenated.
     */
    fun timeline(text: String, loopGapUnits: Int = 10, includeStartSignal: Boolean = true): List<Element> {
        val words = text.uppercase().trim().split(Regex("\\s+")).filter(String::isNotBlank)
        val out = mutableListOf<Element>()
        if (words.isNotEmpty() && includeStartSignal) {
            out += Element.Mark('^', 12, '^')
            out += Element.Gap(3, GapKind.LETTER)
        }
        words.forEachIndexed { wordIndex, word ->
            val supported = word.filter { encodeMap.containsKey(it) }
            supported.forEachIndexed { charIndex, char ->
                val code = encodeMap.getValue(char)
                code.forEachIndexed { markIndex, mark ->
                    out += Element.Mark(mark, if (mark == '.') 1 else 3, char)
                    if (markIndex < code.lastIndex) out += Element.Gap(1, GapKind.ELEMENT)
                }
                if (charIndex < supported.lastIndex) out += Element.Gap(3, GapKind.LETTER)
            }
            if (wordIndex < words.lastIndex) out += Element.Gap(7, GapKind.WORD)
        }
        if (out.isNotEmpty() && loopGapUnits > 0) out += Element.Gap(loopGapUnits, GapKind.LOOP)
        return out
    }

    fun dotDurationMs(wpm: Int): Long = (1200.0 / max(1, wpm)).toLong().coerceAtLeast(20L)

    fun decodeMark(durationMs: Long, dotMs: Long): Char? = when {
        durationMs < dotMs * 0.35 -> null
        durationMs < dotMs * 2.0 -> '.'
        durationMs < dotMs * 5.0 -> '-'
        else -> null
    }

    fun gapKind(durationMs: Long, dotMs: Long): GapKind = when {
        durationMs >= dotMs * 6 -> GapKind.WORD
        durationMs >= dotMs * 2 -> GapKind.LETTER
        else -> GapKind.ELEMENT
    }

    fun decodeSymbols(symbols: List<String>): String = symbols.mapNotNull { decodeMap[it] }.joinToString("")
}

/** Majority-vote consensus across repeated copies of the same Morse message. */
class MorseRepeatConsensus {
    data class Result(val text: String, val copies: Int, val confidence: Double)

    private val copies = mutableListOf<String>()

    fun reset() = copies.clear()

    fun add(text: String): Result {
        val normalized = text.trim()
        if (normalized.isNotBlank()) copies += normalized
        return result()
    }

    fun preview(current: String): Result {
        val all = if (current.trim().isBlank()) copies.toList() else copies + current.trim()
        return vote(all)
    }

    fun result(): Result = vote(copies)

    private fun vote(values: List<String>): Result {
        if (values.isEmpty()) return Result("", 0, 0.0)
        if (values.size == 1) return Result(values.first(), 1, 1.0)
        val maxLen = values.maxOf { it.length }
        val out = StringBuilder()
        var winningVotes = 0
        var totalVotes = 0
        for (i in 0 until maxLen) {
            val votes = linkedMapOf<Char, Int>()
            values.forEach { text ->
                if (i < text.length) votes[text[i]] = (votes[text[i]] ?: 0) + 1
            }
            if (votes.isEmpty()) continue
            val winner = votes.entries.maxWithOrNull(compareBy<Map.Entry<Char, Int>> { it.value }.thenBy { it.key })!!
            out.append(winner.key)
            winningVotes += winner.value
            totalVotes += votes.values.sum()
        }
        return Result(out.toString().trim(), values.size, if (totalVotes == 0) 0.0 else winningVotes.toDouble() / totalVotes)
    }
}

/** Stateful transition-based decoder shared by camera-luma, microphone and legacy lux receivers. */
class MorseTimingDecoder(
    initialDotMs: Long = 120L,
    private val autoTiming: Boolean = true,
    private val minimumDotMs: Long = 20L,
    private val maximumDotMs: Long = 2000L
) {
    data class Snapshot(
        val decodedText: String,
        val currentSymbols: String,
        val dotMs: Long,
        val pulsesSeen: Int,
        val quality: String,
        val completedCopies: Int = 0,
        val consensusConfidence: Double = 0.0,
        val framed: Boolean = false
    )

    private val minDot = minimumDotMs.coerceAtLeast(20L)
    private val maxDot = maximumDotMs.coerceAtLeast(minDot)
    private var dotMs = initialDotMs.coerceIn(minDot, maxDot)
    private var currentState = false
    private var lastTransitionMs: Long? = null
    private val pulseDurations = mutableListOf<Long>()
    private val dotEstimates = mutableListOf<Long>()
    private val currentSymbols = StringBuilder()
    private val currentMessage = StringBuilder()
    private var pulses = 0
    private val consensus = MorseRepeatConsensus()
    private var framed = false

    fun reset(nowMs: Long? = null) {
        currentState = false
        lastTransitionMs = nowMs
        pulseDurations.clear()
        dotEstimates.clear()
        currentSymbols.clear()
        currentMessage.clear()
        consensus.reset()
        pulses = 0
        framed = false
    }

    fun update(isOn: Boolean, timestampMs: Long): Snapshot {
        val last = lastTransitionMs
        if (last == null) {
            currentState = isOn
            lastTransitionMs = timestampMs
            return snapshot()
        }
        if (isOn == currentState) return snapshot()

        val duration = (timestampMs - last).coerceAtLeast(1L)
        if (currentState) {
            // Twelve Morse units is an explicit MethodMesh message-start beacon.
            // Keep the tolerance intentionally broad: this signal is meant to be
            // more conspicuous than an ordinary dash and to survive auto-timing drift.
            if (duration >= dotMs * 6 && duration <= dotMs * 22) {
                startFrame()
                if (autoTiming) {
                    val estimate = (duration / 12L).coerceIn(minDot, maxDot)
                    dotMs = estimate
                    dotEstimates += estimate
                }
            } else {
                MorseCodec.decodeMark(duration, dotMs)?.let { symbol ->
                    currentSymbols.append(symbol)
                    pulseDurations += duration
                    dotEstimates += if (symbol == '-') (duration / 3L).coerceAtLeast(1L) else duration
                    pulses++
                    if (autoTiming) updateDotEstimate()
                }
            }
        } else {
            when {
                duration >= dotMs * 9 -> {
                    flushLetter()
                    // Long quiet remains a useful fallback boundary for manually
                    // keyed Morse that does not contain the MethodMesh start beacon.
                    submitCopy()
                }
                duration >= dotMs * 6 -> {
                    flushLetter()
                    if (currentMessage.isNotEmpty() && currentMessage.last() != ' ') currentMessage.append(' ')
                }
                duration >= dotMs * 2 -> flushLetter()
                else -> Unit
            }
        }
        currentState = isOn
        lastTransitionMs = timestampMs
        return snapshot()
    }

    fun flush(timestampMs: Long): Snapshot {
        val last = lastTransitionMs
        if (last != null && !currentState) {
            val duration = timestampMs - last
            if (duration >= dotMs * 2) flushLetter()
            if (duration >= dotMs * 9) submitCopy()
        } else if (currentState && last != null) {
            val duration = (timestampMs - last).coerceAtLeast(1L)
            if (duration >= dotMs * 6 && duration <= dotMs * 22) {
                startFrame()
            } else {
                MorseCodec.decodeMark(duration, dotMs)?.let { symbol ->
                    currentSymbols.append(symbol)
                    pulses++
                }
                flushLetter()
            }
        }
        return snapshot()
    }

    private fun startFrame() {
        flushLetter()
        submitCopy()
        currentSymbols.clear()
        currentMessage.clear()
        framed = true
    }

    private fun submitCopy() {
        val text = currentMessage.toString().trim()
        if (text.isNotBlank()) consensus.add(text)
        currentMessage.clear()
    }

    private fun flushLetter() {
        if (currentSymbols.isEmpty()) return
        val char = MorseCodec.decode(currentSymbols.toString())
        if (char.isNotBlank()) currentMessage.append(char)
        currentSymbols.clear()
    }

    private fun updateDotEstimate() {
        if (dotEstimates.size < 3) return
        val recent = dotEstimates.takeLast(24).sorted()
        val median = recent[recent.size / 2]
        if (median in minDot..maxDot) dotMs = ((dotMs * 3 + median) / 4).coerceIn(minDot, maxDot)
    }

    private fun snapshot(): Snapshot {
        val completed = consensus.result()
        val voted = consensus.preview(currentMessage.toString())
        val quality = when {
            pulses < 3 && completed.copies == 0 -> if (framed) "START locked • acquiring timing" else "Waiting for START / Morse"
            completed.copies >= 2 -> "Best guess from ${completed.copies} cycles • ${(completed.confidence * 100).toInt()}% vote confidence"
            completed.copies == 1 -> "1 complete cycle • ${(voted.confidence * 100).toInt()}% current confidence"
            pulseDurations.isEmpty() -> "Waiting"
            else -> "Tracking ~${dotMs} ms dot"
        }
        return Snapshot(
            decodedText = voted.text,
            currentSymbols = currentSymbols.toString(),
            dotMs = dotMs,
            pulsesSeen = pulses,
            quality = quality,
            completedCopies = completed.copies,
            consensusConfidence = if (completed.copies > 0) completed.confidence else voted.confidence,
            framed = framed
        )
    }
}
