package com.example.methodmesh.modules

import android.content.Context

/** A module-owned, object-bound home-screen projection. */
data class ModuleWidgetTarget(
    val id: String,
    val capabilityId: String,
    val title: String,
    val subtitle: String = "",
    val iconKey: String = "tool",
    val objectId: String = ""
)

data class ModuleWidgetAction(
    val id: String,
    val label: String
)

data class ModuleWidgetSnapshot(
    val title: String,
    val subtitle: String,
    val iconKey: String = "tool",
    val actions: List<ModuleWidgetAction> = emptyList()
)

data class ModuleWidgetInvocation(
    val capabilityId: String,
    val settings: Map<String, String> = emptyMap()
)

interface ModuleWidgetSurfaceProvider {
    fun widgetTargets(context: Context): List<ModuleWidgetTarget> = emptyList()
    fun widgetSnapshot(context: Context, targetId: String): ModuleWidgetSnapshot? = null
    fun widgetInvocation(context: Context, targetId: String): ModuleWidgetInvocation? = null
    fun performWidgetAction(context: Context, targetId: String, actionId: String): Boolean = false
}
