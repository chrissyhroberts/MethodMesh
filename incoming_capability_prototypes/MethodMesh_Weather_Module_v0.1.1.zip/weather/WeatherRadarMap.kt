package com.example.methodmesh.modules.weather

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.PropertyFactory.rasterOpacity
import org.maplibre.android.style.layers.RasterLayer
import org.maplibre.android.style.sources.RasterSource
import org.maplibre.android.style.sources.TileSet

private const val WEATHER_MAP_STYLE = "https://tiles.openfreemap.org/styles/liberty"
private const val WEATHER_RADAR_SOURCE = "methodmesh-weather-radar-source"
private const val WEATHER_RADAR_LAYER = "methodmesh-weather-radar-layer"

@Composable
internal fun WeatherRadarMap(
    latitude: Double,
    longitude: Double,
    tileTemplate: String,
    zoom: Double,
    modifier: Modifier = Modifier
) {
    Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                MapView(context).apply {
                    onCreate(null)
                    getMapAsync { map ->
                        map.uiSettings.isCompassEnabled = false
                        map.uiSettings.isLogoEnabled = false
                        map.uiSettings.isAttributionEnabled = true
                        map.uiSettings.setAllGesturesEnabled(true)
                        map.setStyle(Style.Builder().fromUri(WEATHER_MAP_STYLE)) { style ->
                            addRadar(style, tileTemplate)
                        }
                        map.cameraPosition = CameraPosition.Builder()
                            .target(LatLng(latitude, longitude))
                            .zoom(zoom.coerceIn(1.0, 7.0))
                            .build()
                    }
                    tag = tileTemplate
                    onResume()
                }
            },
            update = { view ->
                view.getMapAsync { map ->
                    if (view.tag != tileTemplate) {
                        view.tag = tileTemplate
                        map.setStyle(Style.Builder().fromUri(WEATHER_MAP_STYLE)) { style ->
                            addRadar(style, tileTemplate)
                        }
                    }
                }
            }
        )
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.White, 10f, c)
            drawCircle(Color(0xFF176B52), 6f, c)
            drawLine(Color.White, Offset(c.x - 18f, c.y), Offset(c.x + 18f, c.y), 2f)
            drawLine(Color.White, Offset(c.x, c.y - 18f), Offset(c.x, c.y + 18f), 2f)
        }
    }
}

private fun addRadar(style: Style, tileTemplate: String) {
    if (tileTemplate.isBlank()) return
    val tileSet = TileSet("2.2.0", tileTemplate).apply {
        maxZoom = 7f
        minZoom = 0f
    }
    style.addSource(RasterSource(WEATHER_RADAR_SOURCE, tileSet, 256))
    style.addLayer(
        RasterLayer(WEATHER_RADAR_LAYER, WEATHER_RADAR_SOURCE)
            .withProperties(rasterOpacity(0.72f))
    )
}
