# Speaker separation / attribution

## Implemented behaviour

Live Stream Translation does not infer speaker identity.

When speaker tagging is enabled, the operator chooses `Speaker 1`, `Speaker 2`, etc. (or `?`) using quick chips. The selected label is attached to the next final recognition segment.

This is deliberate. The Android SpeechRecognizer and ML Kit Speech Recognition APIs used by this module do not expose a reliable on-device diarisation contract suitable for research-data attribution. Pitch/loudness or timing heuristics are not used because a confident-looking but wrong speaker assignment is worse than an explicit unknown.

## Streaming mode

The new streaming working phrase also does not acquire a speculative speaker identity. The current speaker chip is an operator annotation; only final recognition segments enter the committed transcript.

## Provider boundary

Recognition-engine provenance is already recorded per final segment (`recognition_engine` and `recognition_engine_detail`). A future diarisation-capable provider could populate a speaker identity through a separately defined and reviewed contract without changing the stable meeting-translation method IDs.

Google Cloud Speech-to-Text can provide server-side features beyond the on-device ML Kit API and is a candidate for future evaluation, but it is not implemented here and would require an explicit ONLINE_ONLY/privacy/credential design review.
