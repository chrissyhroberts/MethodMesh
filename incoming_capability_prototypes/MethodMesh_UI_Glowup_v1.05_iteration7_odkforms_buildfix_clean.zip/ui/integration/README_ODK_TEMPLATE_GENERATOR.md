# ODK/Kobo template asset generator

The ODK Forms screen runs inside the APK. Module `docs/` folders are source files and are **not automatically packaged by Android**. Therefore the module-owned XLSForms must be projected into Android assets at build time.

## Source of truth

The generator scans every module:

```text
src/main/java/com/example/methodmesh/modules/<module>/docs/**/*.xlsx
```

It includes canonical `example_odk*.xlsx` workbooks and, as a safety net, other `.xlsx` files that structurally look like XLSForms (`survey` plus `settings`/`choices` sheets). A module may own one form or many.

## Output packaged into the APK

```text
src/main/assets/methodmesh/odk_templates/index.json
src/main/assets/methodmesh/odk_templates/<module>/<form>.xlsx
```

## One-time build integration

The `ui/` folder alone cannot mutate Gradle configuration. Install the hook once from the **app-module root** (where `build.gradle.kts` lives):

```bash
python3 src/main/java/com/example/methodmesh/ui/integration/install_odk_form_build_hook.py
```

Equivalent manual line in `build.gradle.kts`:

```kotlin
apply(from = "src/main/java/com/example/methodmesh/ui/integration/odk-template-assets.gradle.kts")
```

After that every app build regenerates the catalogue before Android merges assets. You can also force it explicitly:

```bash
./gradlew generateMethodMeshOdkTemplateAssets
```

A successful task prints the number of templates and module owners discovered. If the ODK Forms page says the catalogue is missing, this build hook has not yet been applied to the app module or the app has not been rebuilt since installation.
