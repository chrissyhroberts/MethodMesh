package com.example.methodmesh.modules.media

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private fun copy(context: Context, label: String, value: String) {
    if (value.isBlank()) return
    context.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText(label, value))
    Toast.makeText(context, "Copied $label", Toast.LENGTH_SHORT).show()
}

@Composable
private fun MediaHero(
    eyebrow: String,
    title: String,
    subtitle: String,
    accent: String = ""
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            eyebrow.uppercase(Locale.ROOT),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (accent.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(accent, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String = "") {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (subtitle.isNotBlank()) {
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MediaToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable { onCheckedChange(!checked) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.fillMaxWidth(0.82f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun MediaResultLine(
    title: String,
    meta: String,
    selected: Boolean,
    badge: String = "",
    onClick: () -> Unit
) {
    val bg = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = bg,
        tonalElevation = if (selected) 2.dp else 0.dp
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.size(42.dp).background(
                    if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Text(if (selected) "✓" else "•", color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(Modifier.fillMaxWidth(0.78f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (meta.isNotBlank()) Text(meta, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (badge.isNotBlank()) {
                Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(badge, Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun InlineSuccess(
    eyebrow: String,
    title: String,
    subtitle: String,
    onCopy: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(eyebrow.uppercase(Locale.ROOT), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(
            title,
            modifier = if (onCopy != null) Modifier.fillMaxWidth().clickable(onClick = onCopy) else Modifier.fillMaxWidth(),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        if (subtitle.isNotBlank()) Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        actions()
    }
}

object MediaCatalogueSearchCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MediaCatalogueSearchMethod.ID
    override val title = "Media catalogue"
    override val description = "Search the local catalogue. Included-only is deliberately the default."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val initial = context.action.settings
        var query by rememberSaveable { mutableStateOf(initial["query"].orEmpty()) }
        var providers by rememberSaveable { mutableStateOf(initial["providers"].orEmpty()) }
        var mediaType by rememberSaveable { mutableStateOf(initial["media_type"].orEmpty().ifBlank { "any" }) }
        var includedOnly by rememberSaveable { mutableStateOf(initial["included_only"]?.toBooleanStrictOrNull() ?: true) }
        var allowAds by rememberSaveable { mutableStateOf(initial["allow_free_with_ads"]?.toBooleanStrictOrNull() ?: false) }
        var excludeAddons by rememberSaveable { mutableStateOf(initial["exclude_addons"]?.toBooleanStrictOrNull() ?: true) }
        var genre by rememberSaveable { mutableStateOf(initial["genre"].orEmpty()) }
        var language by rememberSaveable { mutableStateOf(initial["language"].orEmpty()) }
        var maxRuntime by rememberSaveable { mutableStateOf(initial["max_runtime_minutes"].orEmpty()) }
        var results by remember { mutableStateOf<List<MediaCatalogueItem>>(emptyList()) }
        var selectedId by rememberSaveable { mutableStateOf("") }
        var searched by rememberSaveable { mutableStateOf(false) }
        var error by rememberSaveable { mutableStateOf("") }

        fun settings() = initial + mapOf(
            "query" to query, "providers" to providers, "media_type" to mediaType,
            "included_only" to includedOnly.toString(), "allow_free_with_ads" to allowAds.toString(),
            "exclude_addons" to excludeAddons.toString(), "genre" to genre, "language" to language,
            "max_runtime_minutes" to maxRuntime, "limit" to "100"
        )

        LaunchedEffect(query, providers, mediaType, includedOnly, allowAds, excludeAddons, genre, language, maxRuntime) {
            context.onSettingsChanged(settings())
        }

        fun runSearch() {
            error = ""
            searched = true
            results = runCatching { MediaCatalogueRepository(androidContext).search(MediaSearchSpec.from(settings())) }
                .onFailure { error = it.message ?: "Search failed." }
                .getOrDefault(emptyList())
            if (selectedId !in results.map { it.workId }) selectedId = ""
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MediaHero(
                eyebrow = "Explore",
                title = "Find something worth watching",
                subtitle = "Search your entire local catalogue — not a provider recommendation carousel.",
                accent = if (includedOnly) "Only things available without paying extra" else "All availability layers"
            )

            OutlinedTextField(query, { query = it }, label = { Text("Search") }, placeholder = { Text("Title, creator, genre…") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("any", "movie", "series", "book", "music").forEach { type ->
                    FilterChip(selected = mediaType == type, onClick = { mediaType = type }, label = { Text(type.replaceFirstChar { it.uppercase() }) })
                }
            }

            SectionTitle("Where", "Leave blank to search every service in the imported catalogue.")
            OutlinedTextField(providers, { providers = it }, label = { Text("Services") }, placeholder = { Text("Netflix, Prime Video, Disney+") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

            HorizontalDivider()
            SectionTitle("Availability", "The useful defaults are already selected.")
            MediaToggle("Included without extra payment", "Hide rental and purchase offers.", includedOnly) { includedOnly = it }
            MediaToggle("Exclude add-on channels", "Do not count a provider channel as part of the base subscription.", excludeAddons) { excludeAddons = it }
            MediaToggle("Allow free with ads", "Include ad-supported services alongside subscription-included titles.", allowAds) { allowAds = it }

            HorizontalDivider()
            SectionTitle("Refine")
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(genre, { genre = it }, label = { Text("Genre") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(language, { language = it }, label = { Text("Language") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            OutlinedTextField(maxRuntime, { maxRuntime = it.filter(Char::isDigit) }, label = { Text("Maximum runtime (minutes)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(onClick = ::runSearch, modifier = Modifier.fillMaxWidth()) { Text("Search catalogue") }

            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            if (searched && error.isBlank()) {
                Text(
                    if (results.isEmpty()) "No matches" else "${results.size} matches",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                if (results.isEmpty()) Text("Try widening the service, runtime or entitlement filters.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            results.take(40).forEach { item ->
                val selected = item.workId == selectedId
                val access = item.accessType.wire.replace('_', ' ')
                val meta = listOfNotNull(
                    item.year?.toString(),
                    item.provider.takeIf { it.isNotBlank() },
                    access.takeIf { it.isNotBlank() },
                    item.runtimeMinutes?.let { "$it min" }
                ).joinToString(" · ")
                MediaResultLine(
                    title = item.title,
                    meta = meta,
                    selected = selected,
                    badge = if (item.accessType == MediaAccessType.SubscriptionIncluded || item.accessType == MediaAccessType.Free) "Included" else "",
                    onClick = { selectedId = if (selected) "" else item.workId }
                )
                if (selected) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { copy(androidContext, "media title", item.title) }) { Text("Copy title") }
                        OutlinedButton(onClick = {
                            MediaCatalogueRepository(androidContext).setState(
                                workId = item.workId, title = item.title, mediaType = item.mediaType,
                                creator = item.creator, year = item.year, favourite = true,
                                externalUri = item.externalUri
                            )
                            Toast.makeText(androidContext, "Added to favourites", Toast.LENGTH_SHORT).show()
                        }) { Text("☆ Favourite") }
                    }
                    Button(onClick = {
                        val selectedSettings = settings() + ("work_id" to item.workId)
                        val req = As100MediaCatalogueSearchMethod.request(
                            action = context.action.canonicalId,
                            context = context.request.invocationContext.asMap(context.action.canonicalId) + selectedSettings,
                            signals = emptyList(), inputs = emptyList()
                        )
                        onConfirmed(As100MediaCatalogueSearchMethod.executeWithAndroidContext(req, androidContext, selectedSettings))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Use ${item.title}") }
                }
            }
        }
    }
}

object MediaCatalogueImportCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MediaCatalogueImportMethod.ID
    override val title = "Import media catalogue"
    override val description = "Import a downloaded CSV or JSON catalogue into offline storage."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        var status by rememberSaveable { mutableStateOf("Ready for a CSV or JSON catalogue") }
        var replace by rememberSaveable { mutableStateOf(context.action.settings["import_mode"] != "merge") }
        var pendingResult by remember { mutableStateOf<ExecutionResult?>(null) }

        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri == null) return@rememberLauncherForActivityResult
            status = "Importing…"
            runCatching {
                val name = uri.lastPathSegment.orEmpty().lowercase(Locale.ROOT)
                val repo = MediaCatalogueRepository(androidContext)
                androidContext.contentResolver.openInputStream(uri)?.use { input ->
                    if (name.endsWith(".csv")) repo.importCsv(input, replace) else repo.importJson(input, replace)
                } ?: error("Could not open selected file.")
            }.onSuccess { summary ->
                val req = As100MediaCatalogueImportMethod.request(
                    action = context.action.canonicalId,
                    context = context.request.invocationContext.asMap(context.action.canonicalId) + context.action.settings,
                    signals = emptyList(), inputs = emptyList()
                )
                pendingResult = As100MediaCatalogueImportMethod.resultForSummary(req, summary)
                status = "${summary.inserted} imported · ${summary.total} catalogue rows"
                if (context.submitsImmediately) pendingResult?.let(onConfirmed)
            }.onFailure { status = "Import failed · ${it.message ?: "invalid catalogue"}" }
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            MediaHero("Catalogue", "Bring the whole shelf offline", "Import a provider catalogue once, then search it locally without opening streaming apps.")

            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("CSV or JSON", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("title · provider · region · access_type", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Year, type, genre, language, runtime, price and links are optional.", style = MaterialTheme.typography.bodySmall)
                }
            }

            MediaToggle(
                "Refresh matching service + region",
                "Replace existing rows for the service/region pairs contained in this file.",
                replace
            ) { replace = it }

            Button(onClick = { launcher.launch(arrayOf("text/csv", "application/json", "text/plain", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (pendingResult == null) "Choose catalogue file" else "Import another catalogue")
            }

            pendingResult?.takeIf { !context.submitsImmediately }?.let { result ->
                val fields = OutputFormatter.fields(result, includeProvenance = false)
                HorizontalDivider()
                InlineSuccess(
                    eyebrow = "Catalogue updated",
                    title = fields[MediaFields.VALUE]?.toString().orEmpty().ifBlank { status },
                    subtitle = "Your searchable local catalogue is ready.",
                    onCopy = { copy(androidContext, "catalogue import result", fields[MediaFields.VALUE]?.toString().orEmpty()) }
                ) {
                    Button(onClick = { onConfirmed(result) }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
                }
            } ?: Text(status, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

object MediaCaptureCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MediaCaptureMethod.ID
    override val title = "Capture media"
    override val description = "Capture a work now; classify it now or leave it in the inbox."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val initial = context.action.settings
        var type by rememberSaveable { mutableStateOf(initial["media_type"].orEmpty().ifBlank { "other" }) }
        var title by rememberSaveable { mutableStateOf(initial["title"].orEmpty()) }
        var creator by rememberSaveable { mutableStateOf(initial["creator"].orEmpty()) }
        var year by rememberSaveable { mutableStateOf(initial["year"].orEmpty()) }
        var className by rememberSaveable { mutableStateOf(initial["class"].orEmpty().ifBlank { "inbox" }) }
        var tags by rememberSaveable { mutableStateOf(initial["tags"].orEmpty()) }
        var notes by rememberSaveable { mutableStateOf(initial["notes"].orEmpty()) }
        var observedText by rememberSaveable { mutableStateOf(initial["observed_text"].orEmpty()) }
        var committed by remember { mutableStateOf<ExecutionResult?>(null) }

        fun values() = initial + mapOf(
            "media_type" to type, "title" to title, "creator" to creator, "year" to year,
            "class" to className, "tags" to tags, "notes" to notes, "observed_text" to observedText,
            "capture_method" to initial["capture_method"].orEmpty().ifBlank { "manual" }
        )

        LaunchedEffect(type, title, creator, year, className, tags, notes, observedText) { context.onSettingsChanged(values()) }

        val frozen = committed
        if (frozen != null && !context.submitsImmediately) {
            val fields = OutputFormatter.fields(frozen, includeProvenance = false)
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                MediaHero("Saved", fields[MediaFields.TITLE]?.toString().orEmpty(), "Now part of your MethodMesh media library.")
                val detail = listOf(fields[MediaFields.CREATOR], fields[MediaFields.CLASS]).map { it?.toString().orEmpty() }.filter { it.isNotBlank() }.joinToString(" · ")
                if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.titleMedium)
                Text("Tap the title to copy it.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.clickable { copy(androidContext, "media title", fields[MediaFields.TITLE]?.toString().orEmpty()) })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { committed = null }) { Text("Edit") }
                    Button(onClick = { onConfirmed(frozen) }) { Text("Done") }
                }
            }
            return
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MediaHero("Capture", "Keep the thing you just found", "Book, film, programme, song, album or anything else worth remembering.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("book", "movie", "series", "music", "album", "other").forEach { v -> FilterChip(type == v, { type = v }, { Text(v.replaceFirstChar { it.uppercase() }) }) }
            }
            OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(creator, { creator = it }, label = { Text("Author / artist / creator") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(year, { year = it.filter(Char::isDigit).take(4) }, label = { Text("Year") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

            SectionTitle("Put it somewhere")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("inbox", "want", "current", "done", "favourite").forEach { v -> FilterChip(className == v, { className = v }, { Text(v.replaceFirstChar { it.uppercase() }) }) }
            }

            SectionTitle("Optional detail", "Raw observed/OCR text remains separate from resolved metadata.")
            OutlinedTextField(tags, { tags = it }, label = { Text("Tags") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            OutlinedTextField(observedText, { observedText = it }, label = { Text("Observed / OCR text") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

            Button(onClick = {
                val req = As100MediaCaptureMethod.request(
                    action = context.action.canonicalId,
                    context = context.request.invocationContext.asMap(context.action.canonicalId) + values(), signals = emptyList(), inputs = emptyList()
                )
                val result = As100MediaCaptureMethod.executeWithAndroidContext(req, androidContext, values())
                val fields = OutputFormatter.fields(result, includeProvenance = false)
                if (fields[MediaFields.ERROR]?.toString().orEmpty().isBlank()) {
                    if (context.submitsImmediately) onConfirmed(result) else committed = result
                } else {
                    Toast.makeText(androidContext, fields[MediaFields.ERROR]?.toString().orEmpty(), Toast.LENGTH_LONG).show()
                }
            }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save to library") }
        }
    }
}

object MediaLibraryCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MediaLibraryListMethod.ID
    override val title = "Media library"
    override val description = "Browse MethodMesh favourites, watchlist and watched titles by service and availability."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        var mode by rememberSaveable { mutableStateOf(context.action.settings["mode"].orEmpty().ifBlank { "favourites" }) }
        var provider by rememberSaveable { mutableStateOf(context.action.settings["provider"].orEmpty()) }
        var includedOnly by rememberSaveable { mutableStateOf(context.action.settings["included_only"]?.toBooleanStrictOrNull() ?: false) }
        var items by remember { mutableStateOf<List<MediaPersonalItem>>(emptyList()) }
        var selectedWorkId by rememberSaveable { mutableStateOf("") }

        fun refresh() {
            items = MediaCatalogueRepository(androidContext).listPersonal(mode, provider, includedOnly, 250)
            if (selectedWorkId !in items.map { it.workId }) selectedWorkId = ""
        }

        LaunchedEffect(mode, provider, includedOnly) {
            context.onSettingsChanged(mapOf("mode" to mode, "provider" to provider, "included_only" to includedOnly.toString(), "limit" to "250"))
            refresh()
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MediaHero(
                "Your library",
                when (mode) { "watchlist" -> "What you want to watch"; "watched" -> "What you've watched"; else -> "Your favourites" },
                "Your list belongs to MethodMesh, not to any streaming account.",
                accent = if (provider.isBlank()) "All services" else provider
            )

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("favourites", "watchlist", "watched").forEach { v ->
                    FilterChip(mode == v, { mode = v }, { Text(when(v) { "favourites" -> "Favourites"; "watchlist" -> "Watchlist"; else -> "Watched" }) })
                }
            }
            OutlinedTextField(provider, { provider = it }, label = { Text("Service") }, placeholder = { Text("All services") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            MediaToggle("Available without paying extra", "Only show saved titles currently included in the selected service.", includedOnly) { includedOnly = it }

            HorizontalDivider()
            Text("${items.size} ${if (items.size == 1) "title" else "titles"}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (items.isEmpty()) {
                Text("Nothing here yet. Save something from catalogue search or capture.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            items.take(80).forEach { item ->
                val selected = selectedWorkId == item.workId
                val availability = listOf(item.provider, item.accessType.replace('_', ' '), item.year?.toString().orEmpty()).filter { it.isNotBlank() }.joinToString(" · ")
                val badge = when {
                    item.watched -> "Watched"
                    item.watchlist -> "Watchlist"
                    item.favourite -> "Favourite"
                    else -> ""
                }
                MediaResultLine(item.title, availability, selected, badge) { selectedWorkId = if (selected) "" else item.workId }
                if (selected) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            MediaCatalogueRepository(androidContext).setState(workId = item.workId, title = item.title, mediaType = item.mediaType, creator = item.creator, year = item.year, favourite = !item.favourite)
                            refresh()
                        }) { Text(if (item.favourite) "★ Favourite" else "☆ Favourite") }
                        OutlinedButton(onClick = {
                            MediaCatalogueRepository(androidContext).setState(workId = item.workId, title = item.title, mediaType = item.mediaType, creator = item.creator, year = item.year, watchlist = !item.watchlist)
                            refresh()
                        }) { Text(if (item.watchlist) "✓ Watchlist" else "+ Watchlist") }
                    }
                    Button(onClick = {
                        val reqSettings = mapOf("mode" to mode, "provider" to provider, "included_only" to includedOnly.toString())
                        val req = As100MediaLibraryListMethod.request(action = context.action.canonicalId, context = context.request.invocationContext.asMap(context.action.canonicalId) + reqSettings, signals = emptyList(), inputs = emptyList())
                        onConfirmed(As100MediaLibraryListMethod.executeWithAndroidContext(req, androidContext, reqSettings))
                    }, modifier = Modifier.fillMaxWidth()) { Text("Use this shelf") }
                }
            }
        }
    }
}

object MediaLibraryStateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MediaLibraryStateMethod.ID
    override val title = "Media state"
    override val description = "Set MethodMesh favourite, watchlist and watched state for a title."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val initial = context.action.settings
        var title by rememberSaveable { mutableStateOf(initial["title"].orEmpty()) }
        var creator by rememberSaveable { mutableStateOf(initial["creator"].orEmpty()) }
        var workId by rememberSaveable { mutableStateOf(initial["work_id"].orEmpty()) }
        var favourite by rememberSaveable { mutableStateOf(initial["favourite"]?.toBooleanStrictOrNull() ?: false) }
        var watchlist by rememberSaveable { mutableStateOf(initial["watchlist"]?.toBooleanStrictOrNull() ?: false) }
        var watched by rememberSaveable { mutableStateOf(initial["watched"]?.toBooleanStrictOrNull() ?: false) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun values() = initial + mapOf("title" to title, "creator" to creator, "work_id" to workId, "favourite" to favourite.toString(), "watchlist" to watchlist.toString(), "watched" to watched.toString())
        LaunchedEffect(title, creator, workId, favourite, watchlist, watched) { context.onSettingsChanged(values()) }

        val frozen = result
        if (frozen != null && !context.submitsImmediately) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                MediaHero("Updated", title, "Your MethodMesh media state has been saved.")
                Text(listOf(if (favourite) "★ Favourite" else "", if (watchlist) "✓ Watchlist" else "", if (watched) "✓ Watched" else "").filter { it.isNotBlank() }.joinToString("   "), style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { result = null }) { Text("Edit") }
                    Button(onClick = { onConfirmed(frozen) }) { Text("Done") }
                }
            }
            return
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            MediaHero("Personal state", "Make it yours", "Favourite it, keep it for later, or mark it watched.")
            OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(creator, { creator = it }, label = { Text("Creator") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            HorizontalDivider()
            MediaToggle("Favourite", "A title you particularly like or want to keep prominent.", favourite) { favourite = it }
            MediaToggle("Watchlist", "Something you intend to watch later.", watchlist) { watchlist = it }
            MediaToggle("Watched", "Keep it in history without removing other states.", watched) { watched = it }
            Button(onClick = {
                val req = As100MediaLibraryStateMethod.request(action = context.action.canonicalId, context = context.request.invocationContext.asMap(context.action.canonicalId) + values(), signals = emptyList(), inputs = emptyList())
                val r = As100MediaLibraryStateMethod.executeWithAndroidContext(req, androidContext, values())
                if (context.submitsImmediately) onConfirmed(r) else result = r
            }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save") }
        }
    }
}

object MediaAudioIdentifyCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MediaAudioIdentifyMethod.ID
    override val title = "What's this song?"
    override val description = "Listen briefly through the microphone and identify ambient music. No Spotify or media-service sign-in."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val scope = rememberCoroutineScope()
        var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(androidContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
        var tokenDraft by rememberSaveable { mutableStateOf("") }
        var showTokenSetup by rememberSaveable { mutableStateOf(!MediaAudioDiscovery.hasToken(androidContext)) }
        var listening by rememberSaveable { mutableStateOf(false) }
        var identifying by rememberSaveable { mutableStateOf(false) }
        var status by rememberSaveable { mutableStateOf("Ready") }
        var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
        var clipPath by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val sampleSeconds = (context.action.settings["sample_seconds"]?.toIntOrNull() ?: 10).coerceIn(5, 20)

        DisposableEffect(Unit) {
            onDispose {
                MediaAudioDiscovery.stopRecorder(recorder)
                clipPath.takeIf { it.isNotBlank() }?.let { java.io.File(it).delete() }
            }
        }

        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            hasPermission = granted || ContextCompat.checkSelfPermission(androidContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) status = "Microphone permission denied"
        }

        fun identifyClip(file: java.io.File) {
            identifying = true
            status = "Matching audio…"
            scope.launch {
                val attempt = runCatching { withContext(Dispatchers.IO) { MediaAudioDiscovery.identify(androidContext, file) } }
                file.delete(); clipPath = ""; identifying = false
                attempt.onSuccess { match ->
                    val req = As100MediaAudioIdentifyMethod.request(action = context.action.canonicalId, context = context.request.invocationContext.asMap(context.action.canonicalId) + mapOf("sample_seconds" to sampleSeconds.toString()), signals = emptyList(), inputs = emptyList())
                    result = As100MediaAudioIdentifyMethod.resultForMatch(req, match, sampleSeconds)
                    status = if (match.matched) "Matched" else "No match — try again closer to the source"
                    if (context.submitsImmediately) result?.let(onConfirmed)
                }.onFailure { status = it.message ?: "Audio identification failed" }
            }
        }

        fun startListen() {
            if (!hasPermission) { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO); return }
            if (!MediaAudioDiscovery.hasToken(androidContext)) { showTokenSetup = true; status = "Audio discovery service needs configuring"; return }
            result = null
            val file = MediaAudioDiscovery.newClipFile(androidContext); clipPath = file.absolutePath
            runCatching { MediaAudioDiscovery.startRecorder(file) }.onSuccess { r ->
                recorder = r; listening = true; status = "Listening…"
                scope.launch {
                    delay(sampleSeconds * 1000L)
                    if (listening) {
                        MediaAudioDiscovery.stopRecorder(recorder); recorder = null; listening = false
                        identifyClip(file)
                    }
                }
            }.onFailure { file.delete(); clipPath = ""; status = it.message ?: "Could not start microphone" }
        }

        val currentResult = result
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (currentResult != null && !context.submitsImmediately) {
                val fields = OutputFormatter.fields(currentResult, includeProvenance = false)
                val matchedTitle = fields[MediaFields.TITLE]?.toString().orEmpty()
                val artist = fields[MediaFields.CREATOR]?.toString().orEmpty()
                val album = fields[MediaFields.ALBUM]?.toString().orEmpty()
                MediaHero("Found it", matchedTitle.ifBlank { "No match" }, artist.ifBlank { status }, accent = album)
                if (matchedTitle.isNotBlank()) {
                    Text("Tap the title to copy", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.clickable { copy(androidContext, "identified song", fields[MediaFields.VALUE]?.toString().orEmpty()) })
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val wid = fields[MediaFields.WORK_ID]?.toString().orEmpty()
                            MediaCatalogueRepository(androidContext).setState(workId = wid, title = matchedTitle, mediaType = "music", creator = artist, favourite = true, externalUri = fields[MediaFields.SONG_LINK]?.toString().orEmpty())
                            Toast.makeText(androidContext, "Added to favourites", Toast.LENGTH_SHORT).show()
                        }) { Text("☆ Favourite") }
                        OutlinedButton(onClick = { result = null; status = "Ready" }) { Text("Listen again") }
                    }
                }
                Button(onClick = { onConfirmed(currentResult) }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            } else {
                MediaHero("Listen", "What's this song?", "Hold the phone near whatever is playing. No media-account sign-in, ever.", accent = "$sampleSeconds second sample")

                Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                    Surface(
                        modifier = Modifier.size(if (listening) 150.dp else 132.dp).clickable(enabled = !identifying) {
                            if (listening) {
                                val file = clipPath.takeIf { it.isNotBlank() }?.let { java.io.File(it) }
                                MediaAudioDiscovery.stopRecorder(recorder); recorder = null; listening = false
                                if (file != null) identifyClip(file)
                            } else startListen()
                        },
                        shape = CircleShape,
                        color = if (listening) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer,
                        tonalElevation = 6.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(if (listening) "●" else "♪", style = MaterialTheme.typography.displayMedium, color = if (listening) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer)
                                Text(if (listening) "Listening" else if (identifying) "Matching…" else "Tap to listen", fontWeight = FontWeight.Bold, color = if (listening) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                        }
                    }
                }
                Text(status, modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

                HorizontalDivider()
                OutlinedButton(onClick = { showTokenSetup = !showTokenSetup }, modifier = Modifier.fillMaxWidth()) { Text(if (showTokenSetup) "Hide service setup" else "Audio identification service") }
                if (showTokenSetup) {
                    SectionTitle("Audio identification", "AudD is the default adapter. This credential belongs to MethodMesh, not to Spotify or another personal account.")
                    OutlinedTextField(tokenDraft, { tokenDraft = it }, label = { Text("AudD API token") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { MediaAudioDiscovery.clearToken(androidContext); tokenDraft = ""; status = "Service credential cleared" }) { Text("Clear") }
                        Button(onClick = { MediaAudioDiscovery.saveToken(androidContext, tokenDraft); tokenDraft = ""; showTokenSetup = false; status = "Ready" }, enabled = tokenDraft.isNotBlank()) { Text("Save locally") }
                    }
                    Text("Never exported to presets, protocols, ODK or result payloads.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
