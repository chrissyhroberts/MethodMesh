package com.example.methodmesh.modules.time_tools

object TimeToolsContract {
    const val COUNTDOWN = "time.countdown"
    const val STOPWATCH = "time.stopwatch"
    const val INTERVAL = "time.interval"
    const val UNTIL = "time.until"
    const val ELAPSED = "time.elapsed"
    const val DURATION_CALCULATE = "time.duration.calculate"

    val methodIds = listOf(COUNTDOWN, STOPWATCH, INTERVAL, UNTIL, ELAPSED, DURATION_CALCULATE)

    object Input {
        const val LABEL = "input_label"
        const val DURATION_MS = "input_duration_ms"
        const val TARGET_TIMESTAMP = "input_target_timestamp"
        const val ANCHOR_TIMESTAMP = "input_anchor_timestamp"
        const val DAY_OFFSET = "input_day_offset"
        const val LOCAL_TIME = "input_local_time"
        const val ZONE_ID = "input_zone_id"
        const val NOTIFY_ONGOING = "input_notify_ongoing"
        const val LOCK_SCREEN = "input_lock_screen"
        const val ALERT_SOUND = "input_alert_sound"
        const val ALERT_VIBRATION = "input_alert_vibration"
        const val ALERT_LIGHTS = "input_alert_lights"
        const val ALERT_HIGH_PRIORITY = "input_alert_high_priority"
    }

    object Output {
        const val TIMER_ID = "timer_id"
        const val FORMATTED_DURATION = "formatted_duration"
        const val DURATION_MS = "duration_ms"
        const val STARTED_AT = "started_at"
        const val COMPLETED_AT = "completed_at"
        const val COMPLETION_STATUS = "completion_status"
        const val TARGET_TIMESTAMP = "target_timestamp"
        const val EXACT_ALERT_SCHEDULED = "exact_alert_scheduled"
        const val METHODMESH_FULL_JSON = "methodmesh_full_json"
    }
}
