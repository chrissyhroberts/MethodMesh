package com.example.methodmesh.modules.time_tools.notifications

import android.content.Context
import android.os.Build
import com.example.methodmesh.modules.time_tools.timing.AlertProfile

/**
 * Small durable store for timers that must survive process death/reboot.
 * It intentionally stores only timer scheduling/control state, not MethodMesh result archives.
 */
class ActiveTimerStore(context: Context) {
    private val storageContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        context.applicationContext.createDeviceProtectedStorageContext()
    } else {
        context.applicationContext
    }
    private val prefs = storageContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun put(record: ActiveTimerRecord) {
        val p = PREFIX + record.id + "."
        prefs.edit()
            .putString(p + "kind", record.kind.name)
            .putString(p + "label", record.label)
            .putLong(p + "startedWallClockMs", record.startedWallClockMs)
            .apply {
                if (record.targetWallClockMs != null) putLong(p + "targetWallClockMs", record.targetWallClockMs)
                else remove(p + "targetWallClockMs")
                if (record.startedElapsedRealtimeMs != null) putLong(p + "startedElapsedRealtimeMs", record.startedElapsedRealtimeMs)
                else remove(p + "startedElapsedRealtimeMs")
                if (record.targetElapsedRealtimeMs != null) putLong(p + "targetElapsedRealtimeMs", record.targetElapsedRealtimeMs)
                else remove(p + "targetElapsedRealtimeMs")
            }
            .putBoolean(p + "sound", record.alertProfile.sound)
            .putBoolean(p + "vibration", record.alertProfile.vibration)
            .putBoolean(p + "lights", record.alertProfile.lights)
            .putBoolean(p + "showOnLockScreen", record.alertProfile.showOnLockScreen)
            .putBoolean(p + "showFullContentOnLockScreen", record.alertProfile.showFullContentOnLockScreen)
            .putBoolean(p + "highPriority", record.alertProfile.highPriority)
            .putBoolean(p + "ongoingNotification", record.ongoingNotification)
            .putBoolean(p + "ongoingLockScreen", record.ongoingLockScreen)
            .putBoolean(p + "completionAlert", record.completionAlert)
            .putString(p + "zoneId", record.zoneId)
            .putString(p + "payloadJson", record.payloadJson)
            .putStringSet(KEY_IDS, (prefs.getStringSet(KEY_IDS, emptySet()) ?: emptySet()) + record.id)
            .apply()
    }

    fun get(id: String): ActiveTimerRecord? {
        val p = PREFIX + id + "."
        val kind = prefs.getString(p + "kind", null)?.let { runCatching { ActiveTimerKind.valueOf(it) }.getOrNull() } ?: return null
        val label = prefs.getString(p + "label", null) ?: "Timer"
        val startedWallClockMs = prefs.getLong(p + "startedWallClockMs", Long.MIN_VALUE)
        if (startedWallClockMs == Long.MIN_VALUE) return null
        return ActiveTimerRecord(
            id = id,
            kind = kind,
            label = label,
            startedWallClockMs = startedWallClockMs,
            targetWallClockMs = prefs.getOptionalLong(p + "targetWallClockMs"),
            startedElapsedRealtimeMs = prefs.getOptionalLong(p + "startedElapsedRealtimeMs"),
            targetElapsedRealtimeMs = prefs.getOptionalLong(p + "targetElapsedRealtimeMs"),
            alertProfile = AlertProfile(
                sound = prefs.getBoolean(p + "sound", true),
                vibration = prefs.getBoolean(p + "vibration", true),
                lights = prefs.getBoolean(p + "lights", true),
                showOnLockScreen = prefs.getBoolean(p + "showOnLockScreen", true),
                showFullContentOnLockScreen = prefs.getBoolean(p + "showFullContentOnLockScreen", false),
                highPriority = prefs.getBoolean(p + "highPriority", true)
            ),
            ongoingNotification = prefs.getBoolean(p + "ongoingNotification", true),
            ongoingLockScreen = prefs.getBoolean(p + "ongoingLockScreen", true),
            completionAlert = prefs.getBoolean(p + "completionAlert", true),
            zoneId = prefs.getString(p + "zoneId", null),
            payloadJson = prefs.getString(p + "payloadJson", null)
        )
    }

    fun all(): List<ActiveTimerRecord> =
        (prefs.getStringSet(KEY_IDS, emptySet()) ?: emptySet()).mapNotNull(::get)

    fun remove(id: String) {
        val ids = (prefs.getStringSet(KEY_IDS, emptySet()) ?: emptySet()) - id
        val p = PREFIX + id + "."
        val editor = prefs.edit().putStringSet(KEY_IDS, ids)
        prefs.all.keys.filter { it.startsWith(p) }.forEach(editor::remove)
        editor.apply()
    }

    private fun android.content.SharedPreferences.getOptionalLong(key: String): Long? =
        if (contains(key)) getLong(key, 0L) else null

    companion object {
        private const val PREFS = "methodmesh_time_tools_active_timers"
        private const val KEY_IDS = "ids"
        private const val PREFIX = "timer."
    }
}
