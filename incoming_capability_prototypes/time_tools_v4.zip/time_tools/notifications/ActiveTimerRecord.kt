package com.example.methodmesh.modules.time_tools.notifications

import com.example.methodmesh.modules.time_tools.timing.AlertProfile

enum class ActiveTimerKind { COUNTDOWN, STOPWATCH, INTERVAL, UNTIL }

data class ActiveTimerRecord(
    val id: String,
    val kind: ActiveTimerKind,
    val label: String,
    val startedWallClockMs: Long,
    val targetWallClockMs: Long? = null,
    val startedElapsedRealtimeMs: Long? = null,
    val targetElapsedRealtimeMs: Long? = null,
    val alertProfile: AlertProfile = AlertProfile(),
    val ongoingNotification: Boolean = true,
    val ongoingLockScreen: Boolean = true,
    val completionAlert: Boolean = true,
    val zoneId: String? = null,
    val payloadJson: String? = null
)
