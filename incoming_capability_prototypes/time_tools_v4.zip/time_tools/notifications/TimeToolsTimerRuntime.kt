package com.example.methodmesh.modules.time_tools.notifications

import android.content.Context
import android.os.SystemClock
import com.example.methodmesh.modules.time_tools.timing.AlertProfile
import java.time.Instant
import java.time.ZoneId
import java.util.UUID

/**
 * Android runtime bridge used by capability screens/preset launchers. It is independent of
 * the MethodMesh dashboard: any direct capability/preset/protocol/widget invocation can call
 * the same methods.
 */
class TimeToolsTimerRuntime(context: Context) {
    data class StartResult(
        val timerId: String,
        val targetTimestamp: String?,
        val exactAlertScheduled: Boolean?,
        val diagnostic: String? = null
    )

    private val appContext = context.applicationContext
    private val store = ActiveTimerStore(appContext)
    private val scheduler = TimerAlarmScheduler(appContext)
    private val notifications = TimerNotificationManager(appContext)

    fun startCountdown(
        durationMs: Long,
        label: String = "Countdown",
        alertProfile: AlertProfile = AlertProfile(),
        showOngoing: Boolean = true,
        ongoingLockScreen: Boolean = true
    ): StartResult {
        require(durationMs > 0)
        val id = UUID.randomUUID().toString()
        val nowWall = System.currentTimeMillis()
        val nowElapsed = SystemClock.elapsedRealtime()
        val record = ActiveTimerRecord(
            id = id,
            kind = ActiveTimerKind.COUNTDOWN,
            label = label,
            startedWallClockMs = nowWall,
            targetWallClockMs = nowWall + durationMs,
            startedElapsedRealtimeMs = nowElapsed,
            targetElapsedRealtimeMs = nowElapsed + durationMs,
            alertProfile = alertProfile,
            ongoingNotification = showOngoing,
            ongoingLockScreen = ongoingLockScreen,
            completionAlert = true
        )
        return activate(record)
    }

    fun startStopwatch(
        label: String = "Stopwatch",
        showOngoing: Boolean = true,
        ongoingLockScreen: Boolean = true
    ): StartResult {
        val id = UUID.randomUUID().toString()
        val record = ActiveTimerRecord(
            id = id,
            kind = ActiveTimerKind.STOPWATCH,
            label = label,
            startedWallClockMs = System.currentTimeMillis(),
            startedElapsedRealtimeMs = SystemClock.elapsedRealtime(),
            ongoingNotification = showOngoing,
            ongoingLockScreen = ongoingLockScreen,
            completionAlert = false
        )
        store.put(record)
        notifications.showOngoing(record)
        return StartResult(id, null, null)
    }

    fun startUntil(
        target: Instant,
        label: String = "Timer",
        zoneId: String = ZoneId.systemDefault().id,
        alertProfile: AlertProfile = AlertProfile(),
        showOngoing: Boolean = true,
        ongoingLockScreen: Boolean = true
    ): StartResult {
        require(target.isAfter(Instant.now())) { "Target must be in the future" }
        val id = UUID.randomUUID().toString()
        val record = ActiveTimerRecord(
            id = id,
            kind = ActiveTimerKind.UNTIL,
            label = label,
            startedWallClockMs = System.currentTimeMillis(),
            targetWallClockMs = target.toEpochMilli(),
            alertProfile = alertProfile,
            ongoingNotification = showOngoing,
            ongoingLockScreen = ongoingLockScreen,
            completionAlert = true,
            zoneId = zoneId
        )
        return activate(record)
    }

    fun startInterval(
        totalDurationMs: Long,
        label: String = "Interval timer",
        alertProfile: AlertProfile = AlertProfile(),
        showOngoing: Boolean = true,
        ongoingLockScreen: Boolean = true
    ): StartResult {
        require(totalDurationMs > 0)
        val id = UUID.randomUUID().toString()
        val nowWall = System.currentTimeMillis()
        val nowElapsed = SystemClock.elapsedRealtime()
        val record = ActiveTimerRecord(
            id = id,
            kind = ActiveTimerKind.INTERVAL,
            label = label,
            startedWallClockMs = nowWall,
            targetWallClockMs = nowWall + totalDurationMs,
            startedElapsedRealtimeMs = nowElapsed,
            targetElapsedRealtimeMs = nowElapsed + totalDurationMs,
            alertProfile = alertProfile,
            ongoingNotification = showOngoing,
            ongoingLockScreen = ongoingLockScreen,
            completionAlert = true
        )
        return activate(record)
    }

    fun cancel(timerId: String) {
        scheduler.cancel(timerId)
        notifications.cancelOngoing(timerId)
        store.remove(timerId)
    }

    fun refreshOngoing(timerId: String) {
        store.get(timerId)?.let(notifications::showOngoing)
    }

    private fun activate(record: ActiveTimerRecord): StartResult {
        store.put(record)
        notifications.showOngoing(record)
        val scheduled = scheduler.schedule(record)
        return StartResult(
            timerId = record.id,
            targetTimestamp = record.targetWallClockMs?.let { Instant.ofEpochMilli(it).toString() },
            exactAlertScheduled = scheduled.exact,
            diagnostic = scheduled.diagnostic
        )
    }
}
