package com.example.methodmesh.modules.time_tools.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class TimerAlertReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_TIMER_DUE) return
        val id = intent.getStringExtra(EXTRA_TIMER_ID) ?: return
        val store = ActiveTimerStore(context)
        val record = store.get(id) ?: return
        TimerNotificationManager(context).apply {
            cancelOngoing(id)
            showDue(record)
        }
        store.remove(id)
    }

    companion object {
        const val ACTION_TIMER_DUE = "com.example.methodmesh.modules.time_tools.TIMER_DUE"
        const val EXTRA_TIMER_ID = "timer_id"
    }
}
