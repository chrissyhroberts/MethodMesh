package com.example.methodmesh.modules.time_tools.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock

/** Re-post and re-schedule durable timers after reboot/package replacement/time changes. */
class TimerRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action !in SUPPORTED_ACTIONS) return
        val store = ActiveTimerStore(context)
        val scheduler = TimerAlarmScheduler(context)
        val notifications = TimerNotificationManager(context)
        val nowWall = System.currentTimeMillis()
        val nowElapsed = SystemClock.elapsedRealtime()
        val rebootLike = intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        val civilTimeChanged = intent.action == Intent.ACTION_TIME_CHANGED || intent.action == Intent.ACTION_TIMEZONE_CHANGED

        for (original in store.all()) {
            var record = original

            if (record.kind == ActiveTimerKind.COUNTDOWN || record.kind == ActiveTimerKind.INTERVAL) {
                if (rebootLike) {
                    // elapsedRealtime resets across boot. Reconstruct remaining time from the
                    // persisted wall target; device-off time counts toward the countdown.
                    val remaining = (record.targetWallClockMs ?: nowWall) - nowWall
                    if (remaining > 0) {
                        record = record.copy(targetElapsedRealtimeMs = nowElapsed + remaining)
                        store.put(record)
                    }
                } else if (civilTimeChanged && record.targetElapsedRealtimeMs != null) {
                    // Preserve monotonic countdown semantics when the civil clock changes, and
                    // adjust only the display/persistence wall target used by the notification.
                    val remaining = (record.targetElapsedRealtimeMs - nowElapsed).coerceAtLeast(0L)
                    record = record.copy(targetWallClockMs = nowWall + remaining)
                    store.put(record)
                }
            } else if (record.kind == ActiveTimerKind.STOPWATCH && civilTimeChanged && record.startedElapsedRealtimeMs != null) {
                val elapsed = (nowElapsed - record.startedElapsedRealtimeMs).coerceAtLeast(0L)
                record = record.copy(startedWallClockMs = nowWall - elapsed)
                store.put(record)
            }

            val targetWall = record.targetWallClockMs
            val targetElapsed = record.targetElapsedRealtimeMs
            val due = when {
                record.kind == ActiveTimerKind.COUNTDOWN || record.kind == ActiveTimerKind.INTERVAL ->
                    targetElapsed != null && targetElapsed <= nowElapsed
                record.kind == ActiveTimerKind.UNTIL -> targetWall != null && targetWall <= nowWall
                else -> false
            }

            if (due) {
                notifications.cancelOngoing(record.id)
                notifications.showDue(record)
                store.remove(record.id)
            } else {
                if (record.kind != ActiveTimerKind.STOPWATCH && (rebootLike || record.kind == ActiveTimerKind.UNTIL)) {
                    scheduler.schedule(record)
                }
                notifications.showOngoing(record)
            }
        }
    }

    companion object {
        private val SUPPORTED_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED
        )
    }
}
