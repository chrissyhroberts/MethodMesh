package com.example.methodmesh.modules.time_tools.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

class TimerAlarmScheduler(private val context: Context) {
    data class ScheduleResult(val exact: Boolean, val diagnostic: String? = null)

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(record: ActiveTimerRecord): ScheduleResult {
        val pending = pendingIntent(record.id)
        val elapsedTarget = record.targetElapsedRealtimeMs
        val wallTarget = record.targetWallClockMs
        if (elapsedTarget == null && wallTarget == null) return ScheduleResult(false, "Timer has no target")

        val alarmType = if (elapsedTarget != null) AlarmManager.ELAPSED_REALTIME_WAKEUP else AlarmManager.RTC_WAKEUP
        val triggerAt = elapsedTarget ?: wallTarget!!

        return if (canScheduleExact()) {
            alarmManager.setExactAndAllowWhileIdle(alarmType, triggerAt, pending)
            ScheduleResult(true)
        } else {
            alarmManager.setAndAllowWhileIdle(alarmType, triggerAt, pending)
            ScheduleResult(false, "Exact-alarm access unavailable; scheduled approximately")
        }
    }

    fun cancel(timerId: String) {
        alarmManager.cancel(pendingIntent(timerId))
    }

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    private fun pendingIntent(timerId: String): PendingIntent {
        val intent = Intent(context, TimerAlertReceiver::class.java)
            .setAction(TimerAlertReceiver.ACTION_TIMER_DUE)
            .putExtra(TimerAlertReceiver.EXTRA_TIMER_ID, timerId)
        return PendingIntent.getBroadcast(
            context,
            timerId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
