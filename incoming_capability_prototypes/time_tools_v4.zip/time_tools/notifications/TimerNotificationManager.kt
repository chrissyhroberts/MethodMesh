package com.example.methodmesh.modules.time_tools.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import com.example.methodmesh.modules.time_tools.timing.AlertProfile
import kotlin.math.abs

/**
 * Owns the two notification surfaces for active timers:
 * 1. silent ongoing live state (countdown/count-up), visible on lock screen when requested;
 * 2. independently configurable due/completion alert.
 *
 * Uses Android platform notification APIs only; no Compose/lifecycle/AndroidX dependency.
 * Android notification-channel settings remain user-controlled and may override requested
 * sound/vibration/light behaviour.
 */
class TimerNotificationManager(private val context: Context) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun showOngoing(record: ActiveTimerRecord) {
        if (!record.ongoingNotification || !notificationsAllowed()) return
        ensureOngoingChannel()
        manager.notify(notificationId(record.id), buildOngoing(record))
    }

    fun showDue(record: ActiveTimerRecord) {
        if (!record.completionAlert || !notificationsAllowed()) return
        val channelId = ensureAlertChannel(record.alertProfile)
        val builder = newBuilder(channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(record.label)
            .setContentText("Timer due")
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(if (record.alertProfile.highPriority) Notification.PRIORITY_HIGH else Notification.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(contentIntent())
            .setVisibility(
                when {
                    !record.alertProfile.showOnLockScreen -> Notification.VISIBILITY_SECRET
                    record.alertProfile.showFullContentOnLockScreen -> Notification.VISIBILITY_PUBLIC
                    else -> Notification.VISIBILITY_PRIVATE
                }
            )

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            if (record.alertProfile.sound) {
                builder.setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                )
            }
            if (record.alertProfile.vibration) builder.setVibrate(longArrayOf(0, 250, 200, 500))
            if (record.alertProfile.lights) builder.setLights(0xFFFFFFFF.toInt(), 700, 700)
        }

        manager.notify(notificationId(record.id) + DUE_OFFSET, builder.build())
    }

    fun cancelOngoing(timerId: String) {
        manager.cancel(notificationId(timerId))
    }

    private fun buildOngoing(record: ActiveTimerRecord): Notification {
        val builder = newBuilder(ONGOING_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(record.label)
            .setCategory(Notification.CATEGORY_STOPWATCH)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_LOW)
            .setContentIntent(contentIntent())
            .setVisibility(if (record.ongoingLockScreen) Notification.VISIBILITY_PUBLIC else Notification.VISIBILITY_SECRET)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setGroupAlertBehavior(Notification.GROUP_ALERT_SUMMARY)
        } else {
            @Suppress("DEPRECATION")
            builder.setSound(null).setVibrate(longArrayOf(0L))
        }

        when (record.kind) {
            ActiveTimerKind.STOPWATCH -> builder
                .setContentText("Running")
                .setWhen(record.startedWallClockMs)
                .setUsesChronometer(true)

            ActiveTimerKind.COUNTDOWN, ActiveTimerKind.INTERVAL, ActiveTimerKind.UNTIL -> {
                val targetWall = record.targetWallClockMs
                if (targetWall != null) {
                    builder
                        .setContentText("Remaining")
                        .setWhen(targetWall)
                        .setUsesChronometer(true)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) builder.setChronometerCountDown(true)
                } else {
                    builder.setContentText("Running")
                }
            }
        }
        return builder.build()
    }

    private fun ensureOngoingChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (manager.getNotificationChannel(ONGOING_CHANNEL) != null) return
        manager.createNotificationChannel(
            NotificationChannel(ONGOING_CHANNEL, "Active timers", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Ongoing MethodMesh timer status"
                setSound(null, null)
                enableVibration(false)
                enableLights(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    private fun ensureAlertChannel(profile: AlertProfile): String {
        val id = "time_tools_alert_${profile.stableKey()}"
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return id
        if (manager.getNotificationChannel(id) != null) return id

        val importance = if (profile.highPriority) NotificationManager.IMPORTANCE_HIGH else NotificationManager.IMPORTANCE_DEFAULT
        val channel = NotificationChannel(id, "Timer alerts", importance).apply {
            description = "MethodMesh timer completion and due alerts"
            enableVibration(profile.vibration)
            enableLights(profile.lights)
            if (profile.lights) lightColor = 0xFFFFFFFF.toInt()
            lockscreenVisibility = when {
                !profile.showOnLockScreen -> Notification.VISIBILITY_SECRET
                profile.showFullContentOnLockScreen -> Notification.VISIBILITY_PUBLIC
                else -> Notification.VISIBILITY_PRIVATE
            }
            if (profile.sound) {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                setSound(
                    uri,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            } else {
                setSound(null, null)
            }
        }
        manager.createNotificationChannel(channel)
        return id
    }

    private fun newBuilder(channelId: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(appContext, channelId)
        else @Suppress("DEPRECATION") Notification.Builder(appContext)

    private fun contentIntent(): PendingIntent? {
        val launch = appContext.packageManager.getLaunchIntentForPackage(appContext.packageName) ?: return null
        launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            appContext,
            0,
            launch,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun notificationsAllowed(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !manager.areNotificationsEnabled()) return false
        return Build.VERSION.SDK_INT < 33 || appContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    private fun notificationId(timerId: String): Int = abs(timerId.hashCode()).let { if (it <= 0) 1 else it }

    companion object {
        private const val ONGOING_CHANNEL = "time_tools_active"
        private const val DUE_OFFSET = 100_000_000
    }
}
