package com.example.methodmesh.modules.time_tools

/*
 * METHODMESH INTEGRATION ADAPTER
 *
 * This file deliberately contains the thin repository-facing layer. The timing engine,
 * durable alarm runtime and notification system elsewhere in this folder are concrete.
 * Wire these descriptors to the repository's current MethodMeshModule / Method / MethodSetting
 * constructors when admitted.
 *
 * Required invariant: all six method IDs remain independently discoverable. The dashboard
 * is an optional launcher, never the execution API. Notification/lock-screen behaviour is
 * available whichever surface starts the capability: dashboard, direct native, preset,
 * protocol, schedule/widget or ODK.
 */
object TimeToolsModuleDefinition {
    const val moduleId = "time_tools"
    const val displayName = "Time Tools"
    const val status = "Development"
    const val iconKey = "tool"

    data class MethodDescriptor(
        val id: String,
        val title: String,
        val description: String,
        val coreOutputs: List<String>,
        val supportsPresets: Boolean = true,
        val supportsProtocols: Boolean = true,
        val supportsOdk: Boolean = true,
        val supportsPersistentNotification: Boolean = false
    )

    val methods = listOf(
        MethodDescriptor(TimeToolsContract.COUNTDOWN, "Countdown", "Count down a duration with durable due alert and live lock-screen status.", listOf("timer_id", "formatted_duration", "duration_ms", "completion_status", "exact_alert_scheduled"), supportsPersistentNotification = true),
        MethodDescriptor(TimeToolsContract.STOPWATCH, "Stopwatch", "Measure elapsed time with optional laps and live lock-screen count-up.", listOf("timer_id", "formatted_duration", "duration_ms", "lap_count", "laps_json"), supportsPersistentNotification = true),
        MethodDescriptor(TimeToolsContract.INTERVAL, "Interval timer", "Run labelled timed phases and repeated cycles with transition/completion alerts.", listOf("timer_id", "formatted_duration", "completed_cycles", "configured_cycles", "completion_status"), supportsPersistentNotification = true),
        MethodDescriptor(TimeToolsContract.UNTIL, "Until", "Count down to a wall-clock instant or anchor+day-offset+local-time target with durable alert.", listOf("timer_id", "formatted_duration", "remaining_ms", "target_timestamp", "exact_alert_scheduled"), supportsPersistentNotification = true),
        MethodDescriptor(TimeToolsContract.ELAPSED, "Elapsed time", "Calculate elapsed time between timestamps.", listOf("formatted_duration", "duration_ms", "start_timestamp", "end_timestamp")),
        MethodDescriptor(TimeToolsContract.DURATION_CALCULATE, "Duration calculator", "Add or subtract durations.", listOf("formatted_duration", "duration_ms"))
    )
}
