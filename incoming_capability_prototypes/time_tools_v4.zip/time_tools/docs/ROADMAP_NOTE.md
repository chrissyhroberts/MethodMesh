# Time Tools roadmap

Development admission priorities:

- Bind `TimeToolsModuleDefinition` to the repository's current `MethodMeshModule`/descriptor/`MethodSetting` API.
- Add repository-standard result/closeout adapters for all six capabilities.
- Connect capability/preset launchers to `TimeToolsTimerRuntime` so notification/alarm semantics are identical across dashboard, direct native, preset, protocol, schedule/widget and ODK surfaces.
- Add polished module-owned configuration screens for interval programme editing, target-time selection, anchor+day-offset presets and alert profiles.
- Wire copy/share/save actions to generic MethodMesh result actions.
- Validate widget-launched Done -> Android desktop and app-launched Done -> MethodMesh dashboard.
- Align `example_odk_time_tools.xlsx` intent declaration syntax to a current known-good MethodMesh XLSForm before Production promotion.
- Add repository-native instrumentation tests for AlarmManager delivery, reboot restoration, notification permission denial and lock-screen notification rendering.
- Decide whether MethodMesh wants a generic app-level route to Android's “Alarms & reminders” special access screen when an exact timer is requested and permission is unavailable. This should be a generic platform improvement, not Time Tools-specific shared UI logic.
- Consider a foreground service only for future interaction patterns that genuinely require continuous app execution. The current live notification countdown/count-up uses the system notification chronometer and durable AlarmManager trigger, avoiding a days-long foreground service solely to redraw a clock.

Do not solve any of these by adding Time Tools-specific logic to shared MethodMesh UI.
