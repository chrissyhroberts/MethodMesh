# Time Tools validation checklist

## Core timing

- Countdown uses monotonic elapsed time for duration measurement.
- Stopwatch uses monotonic elapsed time.
- Wall-clock/timezone changes do not alter active elapsed-duration measurement.
- Pause duration is excluded correctly.
- Lap totals and lap deltas remain internally consistent.
- Interval phase boundaries and cycle counts are correct.
- `time.until` target calculation uses timezone-aware civil-time semantics.
- DST boundary cases are tested.
- Anchor + day offset + local time resolves to the documented calendar date and target instant.

## Notifications

- Starting countdown posts an ongoing countdown notification when enabled.
- Starting stopwatch posts an ongoing count-up notification when enabled.
- Ongoing notification remains visible after leaving MethodMesh.
- Ongoing notification is visible on the lock screen when requested.
- System chronometer visibly updates without app UI polling.
- Countdown/until completion removes ongoing notification and posts due alert.
- Sound on/off behaviour is requested correctly.
- Vibration on/off behaviour is requested correctly.
- Notification-light on/off behaviour is requested correctly where device hardware/system UI supports it.
- High-priority due alert behaves as expected without using full-screen intent by default.
- Android notification-channel user overrides are respected.
- Missing Android 13+ notification permission fails cleanly without crashing.

## Long-horizon scheduling

- Future target persists across process death.
- Future target is restored after device reboot.
- Future target is restored after package replacement.
- Wall-clock/timezone changes cause future target alarm/notification to be recalculated/re-posted as appropriate.
- Exact-alarm access available: `exact_alert_scheduled=true`.
- Exact-alarm access unavailable: approximate fallback is scheduled and `exact_alert_scheduled=false` with a diagnostic.
- Cancelled timer cancels AlarmManager PendingIntent, removes ongoing notification and deletes operational timer record.
- Completed timer deletes operational timer record after due notification is posted.

## MethodMesh surfaces

For each timer-capable method verify identical runtime semantics when started from:

- capability list/direct native run;
- Time Tools dashboard;
- saved preset;
- preset widget;
- protocol step;
- schedule where relevant;
- ODK/XLSForm grouped intent call.

The dashboard must not be required for any of these.

## Preset regression case

Create a preset with:

- method: `time.until`
- anchor: launch time/runtime
- day offset: 15
- local time: 21:00
- timezone: Europe/London
- ongoing notification: on
- lock screen: on
- due sound: on
- due vibration: on
- due notification light: on

Launch from a generic MethodMesh preset widget. Verify that:

1. the resolved target timestamp is returned;
2. the persistent ongoing notification appears immediately;
3. the lock screen shows the live remaining time;
4. MethodMesh can be closed without losing the timer;
5. the target survives reboot;
6. the due alert fires according to the exact/approximate scheduling status returned by Android.

Also test offset 14 for workflows whose domain convention calls the anchor “day 1” and target “day 15”; the timer module must not silently conflate ordinal day labels with elapsed-day offsets.

## Visual/native checks added in v4

- Countdown circular display updates from authoritative timer state, not a decrementing UI counter.
- Stopwatch refreshes the visible hundredths while running without defining timing state.
- Countdown offers +1:00 while configured/running/paused.
- Quick-start duration chips only alter a configured timer.
- Native renderers use Android framework Views only and add no Compose/ViewModel/JUnit dependency.
- Dashboard tiles launch canonical method IDs; they are not alternate implementations.
- Ongoing system notification remains the background/lock-screen timing surface.
