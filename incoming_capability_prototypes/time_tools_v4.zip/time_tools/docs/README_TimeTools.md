# MethodMesh Time Tools

Status: **Development**

Time Tools provides six independently addressable MethodMesh timing capabilities:

- `time.countdown`
- `time.stopwatch`
- `time.interval`
- `time.until`
- `time.elapsed`
- `time.duration.calculate`

The module dashboard is only a native convenience surface. Presets, protocols, schedules/widgets and ODK invoke the constituent methods directly through ordinary MethodMesh discovery and transport.

## Core product behaviour

- Offline-first. No network is required.
- Countdown and stopwatch duration measurement uses Android monotonic elapsed realtime, not civil time.
- `time.until` intentionally uses wall-clock / timezone semantics because its target is a civil instant.
- Active timers can expose an **ongoing system notification** showing a live countdown/count-up. The notification can be visible on the lock screen and does not depend on a MethodMesh screen remaining open.
- Due/completion alerts are independently configurable for sound, vibration, notification light, lock-screen visibility and high-priority presentation. Android notification-channel/user settings remain authoritative and can override app requests.
- Long-horizon future timers are persisted and scheduled through `AlarmManager`; they are restored after reboot/package replacement.
- User-facing exact alerts use exact alarms where Android grants exact-alarm access. The runtime returns `exact_alert_scheduled=false` with a diagnostic when it must fall back to approximate delivery.
- UI ticks render timing state; they do not define timing state.
- Primary native outputs are beef-first and directly copy/shareable.
- Audit/detail JSON is optional and secondary.
- Cancellation is distinct from successful completion.
- Fixed preset configuration should be hidden when the preset runs.

## Timer notification model

There are two distinct surfaces:

1. **Ongoing timer state** — normally silent. Shows current countdown/count-up and may be visible on the lock screen.
2. **Due/completion alert** — optional alert with sound, vibration, light and high-priority presentation according to the preset/capability settings and Android channel settings.

The system notification chronometer is used for live count-up/countdown display so the visible time continues to update even when the app UI is not rendering.

### Notification settings

Timer-capable methods can expose these generic settings/inputs:

- `input_notify_ongoing`
- `input_lock_screen`
- `input_alert_sound`
- `input_alert_vibration`
- `input_alert_lights`
- `input_alert_high_priority`

These belong to the capability/module contract, not to shared MethodMesh UI special cases.

## Example: anchor + future day + local time

A saved preset can represent a long-running future alert without storing a hard-coded calendar date.

Example workflow:

1. On an event day, the user launches a preset from a MethodMesh widget.
2. The launch instant becomes `input_anchor_timestamp`.
3. The preset specifies `input_day_offset=15`, `input_local_time=21:00` and (optionally) `input_zone_id=Europe/London`.
4. `time.until` resolves the absolute target using timezone-aware `java.time` semantics.
5. MethodMesh persists the active timer, posts the ongoing countdown notification, and schedules the due alert.
6. At the target instant, the ongoing notification is replaced by the configured due alert.

This pattern is generic: it can represent medication reminders, incubation deadlines, follow-ups, observation windows, maintenance intervals, or any other user-requested future timer. The timing module does not encode domain-specific medical or research semantics.

### Day-offset semantics

`input_day_offset=N` means **N calendar days after the anchor date in the selected timezone**, at `input_local_time`. If a workflow instead means “cycle day N” where the anchor is cycle day 1, the preset author should encode the corresponding offset explicitly (for example cycle day 15 is normally an offset of 14 calendar days from cycle day 1). The module does not silently reinterpret this distinction.

## Methods

### `time.countdown`
Inputs/settings: duration, optional label, ongoing notification, lock-screen visibility, completion sound, vibration, notification light, priority.
Core outputs: `timer_id`, `formatted_duration`, `duration_ms`, `requested_duration_ms`, `actual_elapsed_ms`, `completion_status`, `exact_alert_scheduled`.

### `time.stopwatch`
Runtime controls: start, pause/resume, lap, stop, cancel.
Optional ongoing system notification shows live count-up on the lock screen.
Core outputs: `timer_id`, `formatted_duration`, `duration_ms`, `lap_count`, `laps_json`.

### `time.interval`
Inputs: ordered labelled phases with positive durations; cycle count; notification policy. Phase transitions may alert where configured; the active notification displays current timer status.
Core outputs: `timer_id`, `formatted_duration`, `completed_cycles`, `configured_cycles`, `completed_phases`, `completion_status`.

### `time.until`
Inputs may be either:

- absolute `input_target_timestamp`, or
- `input_anchor_timestamp` + `input_day_offset` + `input_local_time` + optional `input_zone_id`.

The device timezone is the native default. Target calculation uses real timezone/DST rules.
Core outputs: `timer_id`, `target_timestamp`, `formatted_duration`, `remaining_ms`, `completion_status`, `exact_alert_scheduled`.

### `time.elapsed`
Inputs: `start_timestamp`, `end_timestamp` as ISO-8601 instants.
Core outputs: `formatted_duration`, `duration_ms`, `start_timestamp`, `end_timestamp`.

### `time.duration.calculate`
Inputs: duration A, duration B, operation (`add`/`subtract`).
Core outputs: `formatted_duration`, `duration_ms`.

## Native dashboard

`TimeToolsDashboardScreen` launches the six method IDs. It must never be the only route to the functions and must not contain duplicate private implementations.

## Presets and widgets

Presets may fix all notification/timing policy while leaving the anchor/runtime event implicit. A generic MethodMesh widget can therefore start a preset directly without opening the Time Tools dashboard.

Examples:

- Tea 4m — countdown, sound+vibration on completion.
- Incubation 10m — countdown with persistent lock-screen timer.
- Observation 15m — countdown with silent completion.
- Future day/time reminder — anchor at launch, offset N calendar days, due at configured local time.

## Protocols

Methods behave as ordinary protocol steps and close using the shared MethodMesh closeout contract. Example: `barcode.scan -> time.stopwatch -> document.scan`.

A long-horizon timer started inside a protocol should return a started/scheduled payload rather than blocking the protocol activity for days. Its eventual notification is an Android timer event, not a requirement to keep the protocol UI alive.

## ODK/XLSForm

ODK supplies inputs and receives core return fields plus optional `methodmesh_full_json`. ODK must not be routed through the dashboard or native configuration flow. MethodMesh should not archive ODK timing results merely because it handled the roundtrip.

The included XLSForm now demonstrates `time.until` with anchor/day-offset/local-time and notification settings in addition to stopwatch/countdown examples. The repository's exact external-intent URI syntax still needs alignment with a current known-good MethodMesh form during admission.

## Android runtime components

`notifications/` contains:

- `ActiveTimerStore` — minimal durable operational state only;
- `TimerAlarmScheduler` — exact/inexact AlarmManager scheduling;
- `TimerNotificationManager` — ongoing chronometer + due alerts;
- `TimerAlertReceiver` — handles due events;
- `TimerRestoreReceiver` — restores schedules/notifications after reboot, package replacement and civil-time/timezone changes;
- `TimeToolsTimerRuntime` — common runtime entry point usable from every MethodMesh launch surface.

This is operational state required to deliver an active timer, not a MethodMesh result archive. Completed/cancelled timer records are removed.

## Manifest integration

See `ANDROID_MANIFEST_SNIPPET.xml`. Host-app admission requires notification, vibration, exact-alarm and boot-receiver declarations. Android 13+ also requires runtime notification permission before notifications can be shown. Exact-alarm access may require the user to grant “Alarms & reminders” special access depending on target/version/policy.

The module deliberately does **not** use full-screen intents by default. They are intrusive and should be reserved for explicit alarm-clock-grade use cases, not ordinary timers/reminders.

## Repository adapter

`TimeToolsModule.kt` intentionally isolates the MethodMesh-facing binding. Wire it to the repository's current `MethodMeshModule`, descriptor and `MethodSetting` constructors while preserving all six method IDs and the new generic notification settings.

## Third-party dependencies

None. The notification/runtime implementation uses Android platform APIs only and does not introduce Compose, lifecycle-viewmodel, coroutines, JUnit or AndroidX notification dependencies.

## Native visual design (v4)

Time Tools now ships module-owned Android View renderers for the high-frequency native surfaces. They intentionally use only Android framework Views and drawing primitives: no Compose, lifecycle-viewmodel-compose, Material Components, or AndroidX UI dependency is introduced by the module.

The design direction is inspired by the clarity of the current Pixel Clock without cloning it: dark restrained surfaces, large circular time readouts, strong state hierarchy, generous touch targets, and a small number of obvious actions.

Countdown intentionally retains the classic **+1:00** action during an active timer. It also exposes -1:00 and +0:10 adjustments and quick-start durations before launch. The large circular timer is the primary object; settings and audit detail remain subordinate.

The stopwatch uses the same visual language, with a large central elapsed-time readout and lap history below. Active timers continue to surface through the persistent system notification/lock-screen chronometer even when the MethodMesh screen is not visible.

`TimeToolsDashboardView` is only an optional launcher. Its tiles emit the canonical method IDs and do not own timer execution. Presets, protocols, widgets and ODK continue to call the individual capabilities directly.
