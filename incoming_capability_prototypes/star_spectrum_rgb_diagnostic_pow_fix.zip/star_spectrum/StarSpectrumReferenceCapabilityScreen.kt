package com.example.methodmesh.modules.star_spectrum

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.methodmesh.core.crypto.Digests
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.settings.SettingsState
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.ReturnMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.Locale
import java.util.UUID

object StarSpectrumReferenceCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100StarSpectrumReferenceMethod.ID
    override val title = "Create spectrum reference"
    override val description = "Trace an A-type reference star, place known Balmer-line anchors on its extracted spectrum, fit a wavelength solution, and keep that calibration for future observations."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val scope = rememberCoroutineScope()
        val definitions = remember { StarSpectrumModule.capabilitySettings()[capabilityId].orEmpty() }
        val settings = remember(context.action.settings) {
            SettingsState(definitions) { key, value -> context.onSettingsChanged(mapOf(key to value.toString())) }
                .also { initialiseSpectrumSettings(it, definitions, context) }
        }

        val initialSourceUri = contextInput(context, "source_image_uri")
        var sourceUri by rememberSaveable { mutableStateOf(initialSourceUri) }
        var sourceOrigin by rememberSaveable { mutableStateOf(if (initialSourceUri.isBlank()) "methodmesh" else "caller") }
        var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
        var sourceError by rememberSaveable { mutableStateOf<String?>(null) }
        var referenceName by rememberSaveable { mutableStateOf(settings.getString("reference_name").ifBlank { "A-star reference" }) }
        var starName by rememberSaveable { mutableStateOf(settings.getString("star_name")) }
        var spectralType by rememberSaveable { mutableStateOf(settings.getString("spectral_type").ifBlank { "A0V" }) }
        var polynomialOrder by rememberSaveable { mutableIntStateOf(settings.getString("polynomial_order").toIntOrNull()?.coerceIn(1, 2) ?: 2) }
        var ribbonWidth by rememberSaveable { mutableIntStateOf(settings.getInt("ribbon_half_width_px").coerceAtLeast(6)) }
        var apertureWidth by rememberSaveable { mutableIntStateOf(settings.getInt("aperture_half_width_px").coerceAtLeast(1)) }
        var backgroundGap by rememberSaveable { mutableIntStateOf(settings.getInt("background_gap_px").coerceAtLeast(1)) }
        var traceStartX by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var traceStartY by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var traceEndX by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var traceEndY by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var showEndpointPicker by rememberSaveable { mutableStateOf(false) }
        var openPickerWhenImageLoads by rememberSaveable { mutableStateOf(false) }
        var extraction by remember { mutableStateOf<SpectrumExtraction?>(null) }
        var anchorsJson by rememberSaveable {
            mutableStateOf(contextInput(context, "calibration_anchors_json").takeIf { it.trim().startsWith("[") } ?: "[]")
        }
        var selectedBalmerLabel by rememberSaveable { mutableStateOf("Hα") }
        var selectedChartIndex by rememberSaveable { mutableIntStateOf(-1) }
        var extractionError by rememberSaveable { mutableStateOf<String?>(null) }
        var isExtracting by rememberSaveable { mutableStateOf(false) }
        var showAdvanced by rememberSaveable { mutableStateOf(false) }
        var committedValuesJson by rememberSaveable { mutableStateOf("") }
        var shouldRestoreExtraction by rememberSaveable { mutableStateOf(false) }

        val trace = if (traceStartX.isFinite() && traceStartY.isFinite() && traceEndX.isFinite() && traceEndY.isFinite()) {
            TraceSelection(traceStartX, traceStartY, traceEndX, traceEndY)
        } else null
        val anchors = remember(anchorsJson) { parseAnchors(anchorsJson) }
        val fit = remember(anchorsJson, polynomialOrder) {
            runCatching { SpectrumEngine.fitCalibration(anchors, polynomialOrder) }.getOrNull()
        }

        fun updateTrace(value: TraceSelection?) {
            if (value == null) {
                traceStartX = Float.NaN; traceStartY = Float.NaN; traceEndX = Float.NaN; traceEndY = Float.NaN
            } else {
                traceStartX = value.startX; traceStartY = value.startY; traceEndX = value.endX; traceEndY = value.endY
            }
            extraction = null
            shouldRestoreExtraction = false
            committedValuesJson = ""
        }

        fun updateAnchors(values: List<CalibrationAnchor>) {
            anchorsJson = JSONArray().apply { values.sortedBy { it.distancePx }.forEach { put(it.toJson()) } }.toString()
            settings.setString("calibration_anchors_json", anchorsJson)
            context.onSettingsChanged(mapOf("calibration_anchors_json" to anchorsJson))
            committedValuesJson = ""
        }

        fun executionFor(json: String): ExecutionResult? {
            if (json.isBlank()) return null
            val obj = JSONObject(json)
            val values = buildMap<String, String> { obj.keys().forEach { key -> put(key, obj.optString(key, "")) } }
            val request = As100StarSpectrumReferenceMethod.request(
                action = capabilityId,
                context = context.request.invocationContext.asMap(capabilityId) + values,
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100StarSpectrumReferenceMethod.result(request, values, context.request.invocationContext)
        }

        val committedResult = remember(committedValuesJson, context.request.invocationContext) { executionFor(committedValuesJson) }
        val isCommitted = committedResult != null

        val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                SpectrumImageIO.takePersistableReadPermission(appContext, uri)
                sourceUri = uri.toString()
                sourceOrigin = "methodmesh"
                context.onSettingsChanged(mapOf("source_image_uri" to sourceUri))
                sourceError = null
                updateTrace(null)
                updateAnchors(emptyList())
                openPickerWhenImageLoads = true
            }
        }

        LaunchedEffect(sourceUri) {
            sourceBitmap = null
            if (sourceUri.isBlank()) return@LaunchedEffect
            sourceError = null
            runCatching { withContext(Dispatchers.IO) { SpectrumImageIO.decode(appContext, sourceUri) } }
                .onSuccess { sourceBitmap = it }
                .onFailure { sourceError = it.message ?: "Could not open the reference-star image." }
        }

        DisposableEffect(sourceBitmap) {
            val bitmap = sourceBitmap
            onDispose { bitmap?.takeUnless { it.isRecycled }?.recycle() }
        }

        LaunchedEffect(sourceBitmap, openPickerWhenImageLoads) {
            if (sourceBitmap != null && openPickerWhenImageLoads) {
                openPickerWhenImageLoads = false
                kotlinx.coroutines.delay(250)
                showEndpointPicker = true
            }
        }

        sourceBitmap?.let { bitmap ->
            if (showEndpointPicker) {
                SpectrumEndpointPickerDialog(
                    bitmap = bitmap,
                    initialTrace = trace,
                    onDismiss = { showEndpointPicker = false },
                    onSelected = { selected ->
                        updateTrace(selected)
                        showEndpointPicker = false
                    }
                )
            }
        }

        fun extractReference(restoring: Boolean = false) {
            val bitmap = sourceBitmap ?: run { extractionError = "Choose a reference-star image first."; return }
            val line = trace ?: run { extractionError = "Select the reference RED and VIOLET endpoints first."; return }
            if (line.length < 24f) { extractionError = "The selected endpoints are too close together."; return }
            if (isExtracting) return
            isExtracting = true
            extractionError = null
            val analysisSettings = SpectrumAnalysisSettings(
                ribbonHalfWidthPx = ribbonWidth,
                apertureHalfWidthPx = minOf(apertureWidth, maxOf(1, ribbonWidth - 2)),
                backgroundGapPx = minOf(backgroundGap, maxOf(1, ribbonWidth - apertureWidth - 1)),
                continuumWindow = 101,
                detectionSigma = 3.5,
                detectionMode = "absorption"
            )
            scope.launch {
                runCatching {
                    withContext(Dispatchers.Default) {
                        SpectrumEngine.analyse(
                            bitmap,
                            line.startX.toDouble(), line.startY.toDouble(),
                            line.endX.toDouble(), line.endY.toDouble(),
                            analysisSettings,
                            calibration = null
                        )
                    }
                }.onSuccess {
                    extraction = it
                    shouldRestoreExtraction = true
                }.onFailure {
                    extractionError = it.message ?: "Could not extract the reference spectrum."
                    if (!restoring) shouldRestoreExtraction = false
                }
                isExtracting = false
            }
        }

        LaunchedEffect(sourceBitmap, shouldRestoreExtraction, extraction) {
            if (sourceBitmap != null && shouldRestoreExtraction && extraction == null && trace != null && !isExtracting) extractReference(true)
        }

        fun commitReference() {
            val bitmap = sourceBitmap ?: return
            val line = trace ?: return
            val spectrum = extraction ?: return
            val calibrationFit = fit ?: run { extractionError = "Place enough wavelength anchors to fit this calibration model."; return }
            val id = "sref-${UUID.randomUUID()}"
            val created = Instant.now().toString()
            val reference = SpectrumReference(
                id = id,
                name = referenceName.ifBlank { starName.ifBlank { "A-star reference" } },
                starName = starName,
                spectralType = spectralType.ifBlank { "A0V" },
                createdTimeIso = created,
                imageWidthPx = bitmap.width,
                imageHeightPx = bitmap.height,
                traceStartX = line.startX.toDouble(),
                traceStartY = line.startY.toDouble(),
                traceEndX = line.endX.toDouble(),
                traceEndY = line.endY.toDouble(),
                polynomialOrder = calibrationFit.order,
                coefficients = calibrationFit.coefficients,
                rmsNm = calibrationFit.rmsNm,
                anchors = anchors,
                validMinDistancePx = anchors.minOf { it.distancePx },
                validMaxDistancePx = anchors.maxOf { it.distancePx },
                notes = "Created locally by MethodMesh Star spectrum analyser"
            )
            SpectrumReferenceRepository.save(appContext, reference)
            val sourceReturnFile = if (sourceOrigin == "methodmesh") {
                runCatching { SpectrumImageIO.copyOriginalToCache(appContext, sourceUri, "methodmesh_star_spectrum_reference_source") }.getOrNull()
            } else null
            val sourceReturnUri = sourceReturnFile?.let { FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", it).toString() }.orEmpty()
            val midpoint = (reference.validMinDistancePx + reference.validMaxDistancePx) / 2.0
            val values = linkedMapOf(
                StarSpectrumReferenceFields.STATUS to "succeeded",
                StarSpectrumReferenceFields.ID to reference.id,
                StarSpectrumReferenceFields.SOURCE_IMAGE_URI to sourceReturnUri,
                StarSpectrumReferenceFields.SOURCE_IMAGE_SHA256 to sourceReturnFile?.let { Digests.sha256Hex(it.readBytes()) }.orEmpty(),
                StarSpectrumReferenceFields.NAME to reference.name,
                StarSpectrumReferenceFields.STAR_NAME to reference.starName,
                StarSpectrumReferenceFields.SPECTRAL_TYPE to reference.spectralType,
                StarSpectrumReferenceFields.ANCHOR_COUNT to reference.anchors.size.toString(),
                StarSpectrumReferenceFields.POLYNOMIAL_ORDER to reference.polynomialOrder.toString(),
                StarSpectrumReferenceFields.COEFFICIENTS_JSON to JSONArray().apply { reference.coefficients.forEach(::put) }.toString(),
                StarSpectrumReferenceFields.RMS_NM to reference.rmsNm.toString(),
                StarSpectrumReferenceFields.DISPERSION_NM_PER_PX to reference.derivative(midpoint).toString(),
                StarSpectrumReferenceFields.WAVELENGTH_MIN_NM to reference.wavelength(reference.validMinDistancePx).toString(),
                StarSpectrumReferenceFields.WAVELENGTH_MAX_NM to reference.wavelength(reference.validMaxDistancePx).toString(),
                StarSpectrumReferenceFields.TRACE_QUALITY to spectrum.trace.traceQuality.toString(),
                StarSpectrumReferenceFields.CREATED_TIME_ISO to reference.createdTimeIso,
                StarSpectrumReferenceFields.REFERENCE_JSON to reference.toJson().toString(),
                StarSpectrumReferenceFields.ERROR to ""
            )
            committedValuesJson = JSONObject(values as Map<*, *>).toString()
            val result = executionFor(committedValuesJson)
            if (context.submitsImmediately && result != null) onConfirmed(result)
        }

        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SpectrumToolHeader(
                title = title,
                subtitle = "Store your own instrument/reference-star wavelength solution once; reuse it offline on later observations",
                committed = isCommitted,
                canGoBack = context.stepNumber > 1,
                onBack = onBack,
                onCancel = onCancel
            )

            if (!isCommitted) {
                SpectrumSection("1 · Reference observation", "A-type stars are convenient because the Balmer absorption series gives strong visible anchors. Use the same camera/grating geometry you plan to reuse.") {
                    if (context.settingShouldBeShown("source_image_uri")) {
                        Button(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (sourceUri.isBlank()) "Upload reference photo" else "Replace reference photo")
                        }
                    }
                    sourceError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    if (sourceUri.isNotBlank()) Text(sourceUri.substringAfterLast('/'), style = MaterialTheme.typography.bodySmall)
                    if (context.settingShouldBeShown("reference_name")) {
                        OutlinedTextField(
                            value = referenceName,
                            onValueChange = { referenceName = it; settings.setString("reference_name", it); context.onSettingsChanged(mapOf("reference_name" to it)) },
                            label = { Text("Reference name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                    if (context.settingShouldBeShown("star_name")) {
                        OutlinedTextField(
                            value = starName,
                            onValueChange = { starName = it; settings.setString("star_name", it); context.onSettingsChanged(mapOf("star_name" to it)) },
                            label = { Text("Star name") },
                            placeholder = { Text("e.g. Vega") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                    if (context.settingShouldBeShown("spectral_type")) {
                        OutlinedTextField(
                            value = spectralType,
                            onValueChange = { spectralType = it; settings.setString("spectral_type", it); context.onSettingsChanged(mapOf("spectral_type" to it)) },
                            label = { Text("Spectral type") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }

                sourceBitmap?.let { bitmap ->
                    SpectrumSection("2 · Spectrum endpoints", "The photo opens full screen. Tap the repeatable RED endpoint, then tap the VIOLET endpoint. No line drawing is required.") {
                        SpectrumImageSurface(
                            bitmap = bitmap,
                            trace = trace,
                            onSelectEndpoints = { showEndpointPicker = true },
                            ribbonHalfWidthPx = ribbonWidth,
                            extraction = extraction
                        )
                    }
                }

                SpectrumSection("3 · Extract reference spectrum") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showAdvanced = !showAdvanced }, modifier = Modifier.weight(1f)) { Text(if (showAdvanced) "Hide controls" else "Tune trace") }
                        Button(onClick = { extractReference(false) }, enabled = sourceBitmap != null && trace != null && !isExtracting, modifier = Modifier.weight(1f)) {
                            Text(if (isExtracting) "Extracting…" else "Extract")
                        }
                    }
                    if (showAdvanced) {
                        Text("Search ribbon  $ribbonWidth px", style = MaterialTheme.typography.labelLarge)
                        Slider(value = ribbonWidth.toFloat(), onValueChange = { ribbonWidth = it.toInt().coerceIn(6, 120); settings.setInt("ribbon_half_width_px", ribbonWidth); context.onSettingsChanged(mapOf("ribbon_half_width_px" to ribbonWidth.toString())); extraction = null; shouldRestoreExtraction = false }, valueRange = 6f..120f)
                        Text("Extraction aperture  ±$apertureWidth px", style = MaterialTheme.typography.labelLarge)
                        Slider(value = apertureWidth.toFloat(), onValueChange = { apertureWidth = it.toInt().coerceIn(1, maxOf(1, ribbonWidth - 2)); settings.setInt("aperture_half_width_px", apertureWidth); context.onSettingsChanged(mapOf("aperture_half_width_px" to apertureWidth.toString())); extraction = null; shouldRestoreExtraction = false }, valueRange = 1f..minOf(30f, maxOf(2f, ribbonWidth - 2f)))
                        Text("Background gap  $backgroundGap px", style = MaterialTheme.typography.labelLarge)
                        Slider(value = backgroundGap.toFloat(), onValueChange = { backgroundGap = it.toInt().coerceIn(1, 30); settings.setInt("background_gap_px", backgroundGap); context.onSettingsChanged(mapOf("background_gap_px" to backgroundGap.toString())); extraction = null; shouldRestoreExtraction = false }, valueRange = 1f..30f)
                    }
                    extractionError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }

                extraction?.let { spectrum ->
                    sourceBitmap?.let { bitmap ->
                        SpectrumSection(
                            "4 · Extracted spectrum appearance",
                            "A horizontal photographic strip made from the optimised extraction aperture. It is shown in conventional VIOLET → RED order."
                        ) {
                            ExtractedSpectrumStrip(
                                bitmap = bitmap,
                                extraction = spectrum,
                                apertureHalfWidthPx = apertureWidth
                            )
                        }
                    }

                    SpectrumSection(
                        "5 · Extracted spectrum trace",
                        "This is the spectrum produced by the extraction itself. It appears before any wavelength calibration or Balmer anchors are added."
                    ) {
                        SpectrumTracePreview(
                            extraction = spectrum
                        )
                    }

                    sourceBitmap?.let { bitmap ->
                        SpectrumSection(
                            "6 · RGB line diagnostic",
                            "Inspect the combined signal and the red, green and blue camera channels separately. This helps distinguish a real local absorption dip from a colour-channel handover."
                        ) {
                            RgbChannelDiagnostic(
                                bitmap = bitmap,
                                extraction = spectrum,
                                apertureHalfWidthPx = apertureWidth,
                                backgroundGapPx = backgroundGap,
                                anchors = anchors
                            )
                        }
                    }

                    SpectrumSection(
                        "7 · Place wavelength anchors",
                        "Place Hα, Hβ, Hγ and Hδ on their absorption troughs. Every placed Balmer line stays visible, so the finished chart shows all four anchors. Tap a Balmer chip to select the line you want to place or revise. Relative flux preserves the broad image-derived envelope; switch to Line finder to divide out that continuum for precise Balmer trough placement. Use the RGB diagnostic above to confirm which channel actually contains the local dip. Pinch/pan to zoom; press-and-hold then drag for magnified fine placement."
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HydrogenBalmerLines.standard
                                .sortedByDescending { it.wavelengthNm }
                                .forEach { line ->
                                    val placed = anchors.any { it.label == line.label }
                                    FilterChip(
                                        selected = selectedBalmerLabel == line.label,
                                        onClick = { selectedBalmerLabel = line.label },
                                        label = {
                                            Text(
                                                "${line.label} ${"%.1f".format(Locale.US, line.wavelengthNm)}" +
                                                    if (placed) " ✓" else ""
                                            )
                                        }
                                    )
                                }
                        }

                        BalmerAnchorChart(
                            extraction = spectrum,
                            anchors = anchors,
                            activeLabel = selectedBalmerLabel,
                            onPlaceIndex = { index ->
                                selectedChartIndex = index
                                val line = HydrogenBalmerLines.standard.first { it.label == selectedBalmerLabel }
                                val updated = anchors.filterNot { it.label == line.label } + CalibrationAnchor(
                                    distancePx = spectrum.distancesPx[index],
                                    wavelengthNm = line.wavelengthNm,
                                    label = line.label
                                )
                                updateAnchors(updated)

                                val ordered = listOf("Hα", "Hβ", "Hγ", "Hδ")
                                val current = ordered.indexOf(line.label)
                                if (current >= 0) {
                                    val nextUnplaced = ordered
                                        .drop(current + 1)
                                        .firstOrNull { candidate -> updated.none { it.label == candidate } }
                                    if (nextUnplaced != null) selectedBalmerLabel = nextUnplaced
                                }
                            }
                        )

                        anchors.sortedByDescending { it.wavelengthNm }.forEach { anchor ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "${anchor.label}  %.2f nm · %.1f px".format(
                                        Locale.US,
                                        anchor.wavelengthNm,
                                        anchor.distancePx
                                    ),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = { selectedBalmerLabel = anchor.label }) {
                                        Text("Fine tune")
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            updateAnchors(anchors.filterNot { it.label == anchor.label })
                                            selectedBalmerLabel = anchor.label
                                        }
                                    ) { Text("Remove") }
                                }
                            }
                        }
                    }

                    SpectrumSection("8 · Wavelength model") {
                        if (context.settingShouldBeShown("polynomial_order")) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = polynomialOrder == 1, onClick = { polynomialOrder = 1; settings.setString("polynomial_order", "1"); context.onSettingsChanged(mapOf("polynomial_order" to "1")); committedValuesJson = "" }, label = { Text("Linear") })
                                FilterChip(selected = polynomialOrder == 2, onClick = { polynomialOrder = 2; settings.setString("polynomial_order", "2"); context.onSettingsChanged(mapOf("polynomial_order" to "2")); committedValuesJson = "" }, label = { Text("Quadratic") })
                            }
                        }
                        if (fit == null) {
                            Text("Add ${polynomialOrder + 1} or more distinct anchors to fit this model.")
                        } else {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                MetricTile("Anchors", anchors.size.toString(), modifier = Modifier.weight(1f))
                                MetricTile("RMS", "%.3f nm".format(Locale.US, fit.rmsNm), modifier = Modifier.weight(1f))
                            }
                            Text(
                                "λ = " + fit.coefficients.mapIndexed { index, value ->
                                    when (index) { 0 -> "%.5f".format(Locale.US, value); 1 -> "%+.7f·p".format(Locale.US, value); else -> "%+.10f·p²".format(Locale.US, value) }
                                }.joinToString(" "),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Button(onClick = ::commitReference, modifier = Modifier.fillMaxWidth()) { Text("Commit reference") }
                        }
                    }
                }
            } else {
                val obj = JSONObject(committedValuesJson)
                val referenceId = obj.optString(StarSpectrumReferenceFields.ID)
                val referenceJson = obj.optString(StarSpectrumReferenceFields.REFERENCE_JSON)
                SpectrumSection("Reference saved", "This calibration is now in the local Reference Spectra Library and will appear automatically in future Star spectrum analyser runs.") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile("Reference", obj.optString(StarSpectrumReferenceFields.NAME), modifier = Modifier.weight(1f))
                        MetricTile("RMS", obj.optDouble(StarSpectrumReferenceFields.RMS_NM).let { "%.3f nm".format(Locale.US, it) }, modifier = Modifier.weight(1f))
                    }
                    MetricTile("Reference ID", referenceId, copyValue = referenceId, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(onClick = { copyToClipboard(appContext, "Spectrum reference JSON", referenceJson) }, modifier = Modifier.fillMaxWidth()) { Text("Copy reference JSON") }
                    val fullJson = committedResult?.let { OutputFormatter.format(it, ReturnMode.Json, includeProvenance = true, payloadMode = OutputFormatter.PayloadMode.FULL) }.orEmpty()
                    OutlinedButton(onClick = { copyToClipboard(appContext, "MethodMesh full JSON", fullJson) }, enabled = fullJson.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Copy full JSON") }
                    Button(onClick = { committedResult?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
                }
            }
        }
    }
}

private fun parseAnchors(raw: String): List<CalibrationAnchor> = runCatching {
    val array = JSONArray(raw.ifBlank { "[]" })
    (0 until array.length()).map { CalibrationAnchor.fromJson(array.getJSONObject(it)) }
}.getOrDefault(emptyList())
