# UI iteration notes — 2026-09-07

This pass deliberately separates immediate UI work from framework work.

## Implemented now

- restored the dashboard hero hierarchy: **MethodMesh** with **Do Stuff** as the small relevance line;
- removed the `Collect · calculate · commit` slogan;
- removed the dashboard Library block: the drawer already owns navigation, so the dashboard is reserved for search and active work;
- Android Back now returns any top-level MethodMesh section to Dashboard before the system is allowed to leave the app;
- added a first-class **ODK forms** destination mirroring Capabilities/Presets by module;
- added searchable ODK template UI with Share/Save actions against a generated asset index;
- dashboard search can surface ODK templates as well as capabilities, presets and protocols;
- upgraded deterministic search ranking with a small plain-English synonym layer;
- further reduced global corner radii.

## Designed, not falsely presented as complete

- module-to-asset build projection for ODK XLSForm templates;
- Android notification/status/overlay/Quick Settings surface contract;
- module-owned tags and future local semantic search;
- typed protocol pipes with safe transform nodes and a later Scratch-like editor.

The next repository-level pass should implement the generic contracts/build tooling above rather than placing one-off behaviour in `HomeScreen.kt`.

## Iteration 4 — ODK Central rapid testing and destructive-action safety

- Added Settings → ODK Central connection UI.
- Central password is transient; only an encrypted bearer session is retained.
- ODK Forms checkboxes now deploy/update/publish and assign a selected test App User.
- Unticking revokes the test App User assignment without deleting the remote form.
- Added `Sync checked` and local SHA-256 deployment tracking.
- Added explicit remote Central removal with submission-aware confirmation.
- Added a shared destructive confirmation component.
- Preset deletion now confirms and reports protocol references.
- Registered-device deletion now confirms.
- Offline language-pack removal now confirms.
- Scheduler deletion still lives in the shared scheduler component outside the supplied `ui/` package; that component must adopt the same confirmation contract at repository integration time.

## Iteration 5 — Central password handling + real module form projection

- Central password field now keeps `KeyboardType.Password` even while the user reveals the value, so IMEs such as Gboard are not told that the input is normal composing text.
- Added a restrained eye / eye-off control directly on the password field.
- Password reveal state resets after successful login and disconnect; the password itself is still never persisted.
- ODK template catalogue now explicitly supports one-to-many module ownership: every `docs/example_odk*.xlsx` becomes its own record.
- Runtime module labels resolve against `MethodMeshModuleRegistry` so the forms library mirrors the canonical module names used by Capabilities and Presets.
- Added `formVersion` and `sourceRelativePath` catalogue metadata and made both searchable.
- Added a dependency-free generator that reads XLSForm `settings` metadata and projects module-owned XLSForms into Android assets.
- Included a one-line Gradle build hook (`ui/integration/odk-template-assets.gradle.kts`) so `preBuild` can regenerate the ODK template catalogue automatically from all module `docs/example_odk*.xlsx` files.

## Iteration 6 — dual ODK Central / KoboToolbox rapid-test routes

- Added a second server connection under Settings → KoboToolbox.
- Kobo password is transient; the Kobo API token is encrypted at rest and reused for API calls.
- Reused the shared password field, including eye/eye-off and permanent password-mode IME semantics, for both Central and Kobo login.
- ODK Forms now gives each XLSForm independent **ODK** and **Kobo** deployment controls.
- ODK checkbox semantics remain App User assignment/revocation on Central.
- Kobo checkbox semantics are deploy/activate versus deactivate, preserving the remote project and submissions when unticked.
- Added independent `Sync ODK` and `Sync Kobo` actions.
- Added separately confirmed permanent remote removal actions for Central and Kobo.
- Kept Share/Save tied to the module-owned local XLSForm rather than either server copy.
- Added `XLSFORM_SERVER_PROVIDERS.md` to keep future collection clients/providers adapter-based; Survey123 is explicitly left as a future invocation/provider adapter rather than folded into the ODK contract.
