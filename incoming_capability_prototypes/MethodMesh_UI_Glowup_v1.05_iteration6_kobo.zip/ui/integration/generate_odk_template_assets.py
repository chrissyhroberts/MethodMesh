#!/usr/bin/env python3
"""Generate MethodMesh's packaged ODK design-template catalogue.

Source of truth:
  src/main/java/com/example/methodmesh/modules/<module>/docs/example_odk*.xlsx

The generator deliberately emits one catalogue entry per XLSForm. A module may own one
form or many. It also understands additional docs directories under the MethodMesh source
root (for example core/scheduling/docs) so framework-owned examples can be projected too.

No third-party Python packages are required. XLSForm settings metadata is read directly
from the XLSX ZIP/XML structure when available.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Iterable
from xml.etree import ElementTree as ET

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL_DOC = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_REL_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"


def _cell_column(ref: str) -> str:
    match = re.match(r"([A-Za-z]+)", ref or "")
    return match.group(1).upper() if match else ""


def _shared_strings(zf: zipfile.ZipFile) -> list[str]:
    try:
        root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    result: list[str] = []
    for si in root.findall(f"{{{NS_MAIN}}}si"):
        # Rich-text shared strings may contain several <t> nodes.
        result.append("".join(t.text or "" for t in si.iter(f"{{{NS_MAIN}}}t")))
    return result


def _settings_sheet_path(zf: zipfile.ZipFile) -> str | None:
    try:
        workbook = ET.fromstring(zf.read("xl/workbook.xml"))
        rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    except (KeyError, ET.ParseError):
        return None

    rel_map = {
        rel.attrib.get("Id", ""): rel.attrib.get("Target", "")
        for rel in rels.findall(f"{{{NS_REL_PKG}}}Relationship")
    }
    for sheet in workbook.findall(f".//{{{NS_MAIN}}}sheet"):
        if sheet.attrib.get("name", "").strip().lower() != "settings":
            continue
        rid = sheet.attrib.get(f"{{{NS_REL_DOC}}}id", "")
        target = rel_map.get(rid, "")
        if not target:
            return None
        target_path = PurePosixPath(target)
        if str(target_path).startswith("/"):
            return str(target_path).lstrip("/")
        return str(PurePosixPath("xl") / target_path)
    return None


def _sheet_rows(zf: zipfile.ZipFile, sheet_path: str) -> list[dict[str, str]]:
    shared = _shared_strings(zf)
    try:
        root = ET.fromstring(zf.read(sheet_path))
    except (KeyError, ET.ParseError):
        return []
    rows: list[dict[str, str]] = []
    for row in root.findall(f".//{{{NS_MAIN}}}row"):
        values: dict[str, str] = {}
        for cell in row.findall(f"{{{NS_MAIN}}}c"):
            col = _cell_column(cell.attrib.get("r", ""))
            if not col:
                continue
            cell_type = cell.attrib.get("t", "")
            value = ""
            if cell_type == "inlineStr":
                value = "".join(t.text or "" for t in cell.iter(f"{{{NS_MAIN}}}t"))
            else:
                vnode = cell.find(f"{{{NS_MAIN}}}v")
                raw = vnode.text if vnode is not None and vnode.text is not None else ""
                if cell_type == "s" and raw.isdigit():
                    index = int(raw)
                    value = shared[index] if 0 <= index < len(shared) else raw
                else:
                    value = raw
            values[col] = value.strip()
        if values:
            rows.append(values)
    return rows


def xlsform_settings(path: Path) -> dict[str, str]:
    try:
        with zipfile.ZipFile(path) as zf:
            sheet_path = _settings_sheet_path(zf)
            if not sheet_path:
                return {}
            rows = _sheet_rows(zf, sheet_path)
    except (zipfile.BadZipFile, OSError):
        return {}

    # Find the first row that looks like an XLSForm settings header, then map the
    # next non-empty row beneath it. This tolerates harmless blank leading rows.
    for i, header_row in enumerate(rows):
        header_by_col = {col: value.strip() for col, value in header_row.items() if value.strip()}
        lowered = {value.lower() for value in header_by_col.values()}
        if not ({"form_id", "form_title", "version"} & lowered):
            continue
        for data_row in rows[i + 1 :]:
            mapped = {
                header_by_col[col].strip().lower(): data_row.get(col, "").strip()
                for col in header_by_col
            }
            if any(mapped.values()):
                return mapped
    return {}


def slug(value: str, fallback: str = "item") -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("._-")
    return cleaned or fallback


def humanize(value: str) -> str:
    text = re.sub(r"[._-]+", " ", value).strip()
    return " ".join(word[:1].upper() + word[1:] for word in text.split()) or "Other"


def form_name_from_file(path: Path) -> str:
    stem = path.stem
    stem = re.sub(r"^example_odk[_ .-]*", "", stem, flags=re.I)
    return humanize(stem)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class SourceForm:
    module_id: str
    module_name: str
    path: Path
    relative_path: str


def discover(source_root: Path, include_all_xlsx: bool) -> list[SourceForm]:
    modules_root = source_root / "modules"
    found: list[SourceForm] = []

    if modules_root.is_dir():
        for module_dir in sorted(p for p in modules_root.iterdir() if p.is_dir()):
            docs = module_dir / "docs"
            if not docs.is_dir():
                continue
            for form in sorted(docs.glob("*.xlsx")):
                if form.name.startswith("~$"):
                    continue
                if not include_all_xlsx and not form.name.lower().startswith("example_odk"):
                    continue
                found.append(
                    SourceForm(
                        module_id=module_dir.name,
                        module_name=humanize(module_dir.name),
                        path=form,
                        relative_path=form.relative_to(source_root).as_posix(),
                    )
                )

    # Framework-owned docs can also carry a valid example (e.g. scheduler). Scan
    # outside modules, but explicitly skip UI docs and anything already captured.
    captured = {item.path.resolve() for item in found}
    for docs in sorted(p for p in source_root.rglob("docs") if p.is_dir()):
        if modules_root in docs.parents or docs == modules_root:
            continue
        if "ui" in docs.parts:
            continue
        for form in sorted(docs.glob("*.xlsx")):
            if form.resolve() in captured or form.name.startswith("~$"):
                continue
            if not include_all_xlsx and not form.name.lower().startswith("example_odk"):
                continue
            owner = docs.parent.name
            found.append(
                SourceForm(
                    module_id=owner,
                    module_name=humanize(owner),
                    path=form,
                    relative_path=form.relative_to(source_root).as_posix(),
                )
            )
    return sorted(found, key=lambda item: (item.module_id.lower(), item.path.name.lower()))


def build_entry(item: SourceForm, asset_path: str) -> dict:
    settings = xlsform_settings(item.path)
    file_fallback = form_name_from_file(item.path)
    display_name = settings.get("form_title", "").strip() or file_fallback
    form_id = settings.get("form_id", "").strip()
    version = settings.get("version", "").strip()
    stable_id = f"{slug(item.module_id)}.{slug(item.path.stem)}"
    return {
        "id": stable_id,
        "moduleId": item.module_id,
        # Runtime UI resolves this from MethodMeshModuleRegistry when possible.
        "moduleName": item.module_name,
        "displayName": display_name,
        "description": "",
        "sourceFileName": item.path.name,
        "sourceRelativePath": item.relative_path,
        "centralFormId": form_id or stable_id,
        "formVersion": version,
        "assetPath": asset_path,
        "sha256": sha256(item.path),
        "capabilityIds": [],
        "tags": [],
    }


def generate(source_root: Path, assets_root: Path, include_all_xlsx: bool) -> tuple[int, int]:
    forms = discover(source_root, include_all_xlsx)
    catalog_root = assets_root / "methodmesh" / "odk_templates"
    if catalog_root.exists():
        shutil.rmtree(catalog_root)
    catalog_root.mkdir(parents=True, exist_ok=True)

    entries: list[dict] = []
    per_module: dict[str, int] = {}
    for item in forms:
        target_dir = catalog_root / slug(item.module_id)
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / item.path.name
        shutil.copy2(item.path, target)
        asset_path = target.relative_to(assets_root).as_posix()
        entries.append(build_entry(item, asset_path))
        per_module[item.module_id] = per_module.get(item.module_id, 0) + 1

    index = {
        "schema": "methodmesh.odk_template_index.v2",
        "generatedFrom": source_root.as_posix(),
        "templateCount": len(entries),
        "moduleCount": len(per_module),
        "templates": entries,
    }
    (catalog_root / "index.json").write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return len(entries), len(per_module)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source-root",
        type=Path,
        default=Path("src/main/java/com/example/methodmesh"),
        help="MethodMesh Java/Kotlin package root containing modules/",
    )
    parser.add_argument(
        "--assets-root",
        type=Path,
        default=Path("src/main/assets"),
        help="Android assets root into which methodmesh/odk_templates is generated",
    )
    parser.add_argument(
        "--all-xlsx",
        action="store_true",
        help="Include every XLSX in docs/ rather than canonical example_odk*.xlsx files only",
    )
    args = parser.parse_args(argv)
    source_root = args.source_root.resolve()
    assets_root = args.assets_root.resolve()
    if not source_root.is_dir():
        parser.error(f"source root does not exist: {source_root}")
    assets_root.mkdir(parents=True, exist_ok=True)
    count, modules = generate(source_root, assets_root, args.all_xlsx)
    print(f"Generated {count} ODK template(s) from {modules} owner(s) into {assets_root / 'methodmesh/odk_templates'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
