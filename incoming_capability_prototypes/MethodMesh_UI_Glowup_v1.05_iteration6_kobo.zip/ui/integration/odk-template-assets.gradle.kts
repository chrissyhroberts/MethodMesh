// MethodMesh ODK design-template projection.
// Apply once from the app-module build.gradle.kts:
// apply(from = "src/main/java/com/example/methodmesh/ui/integration/odk-template-assets.gradle.kts")

val methodMeshOdkGenerator = layout.projectDirectory.file(
    "src/main/java/com/example/methodmesh/ui/integration/generate_odk_template_assets.py"
)
val methodMeshOdkSourceRoot = layout.projectDirectory.dir("src/main/java/com/example/methodmesh")
val methodMeshOdkAssetsRoot = layout.projectDirectory.dir("src/main/assets")

val generateMethodMeshOdkTemplateAssets = tasks.register<Exec>("generateMethodMeshOdkTemplateAssets") {
    group = "methodmesh"
    description = "Projects module-owned docs/example_odk*.xlsx files into the ODK Forms asset catalogue."

    inputs.files(
        fileTree(methodMeshOdkSourceRoot) {
            include("**/docs/example_odk*.xlsx")
        }
    )
    inputs.file(methodMeshOdkGenerator)
    outputs.dir(methodMeshOdkAssetsRoot.dir("methodmesh/odk_templates"))

    commandLine(
        "python3",
        methodMeshOdkGenerator.asFile.absolutePath,
        "--source-root", methodMeshOdkSourceRoot.asFile.absolutePath,
        "--assets-root", methodMeshOdkAssetsRoot.asFile.absolutePath
    )
}

// configureEach works whether preBuild already exists when this script is applied or
// is registered later by the Android Gradle plugin.
tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(generateMethodMeshOdkTemplateAssets)
}
