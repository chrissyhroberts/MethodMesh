# ODK template asset generator

`generate_odk_template_assets.py` projects the forms already owned by modules into the packaged ODK Forms library.

It scans:

```text
src/main/java/com/example/methodmesh/modules/<module>/docs/example_odk*.xlsx
```

and creates **one catalogue record per XLSForm**. A module can therefore contribute one form, six forms, or twenty forms without any extra registration. Framework-owned `docs/example_odk*.xlsx` files outside `modules/` (for example scheduling) are also included.

Run from the app-module root:

```bash
python3 src/main/java/com/example/methodmesh/ui/integration/generate_odk_template_assets.py
```

Output:

```text
src/main/assets/methodmesh/odk_templates/index.json
src/main/assets/methodmesh/odk_templates/<module>/<form>.xlsx
```

The generator reads `form_title`, `form_id` and `version` from the XLSForm `settings` sheet when available. It uses only the Python standard library; `openpyxl` is not required. The UI resolves the human module display name from `MethodMeshModuleRegistry`, so folder IDs do not have to be presentation-ready.

The generated asset directory is a projection. The module `docs/` copy remains authoritative and should be the file edited by module authors.

## Build hook

A build hook is included as `odk-template-assets.gradle.kts`. Add this **one line** to the app-module `build.gradle.kts`:

```kotlin
apply(from = "src/main/java/com/example/methodmesh/ui/integration/odk-template-assets.gradle.kts")
```

That registers `generateMethodMeshOdkTemplateAssets` and makes `preBuild` depend on it. The task watches every `**/docs/example_odk*.xlsx`, so adding a second or tenth form to a module automatically updates the catalogue on the next build.

The generator currently writes its projection to `src/main/assets/methodmesh/odk_templates` so no Android source-set change is required. Treat that directory as generated output; module `docs/` remains authoritative.
