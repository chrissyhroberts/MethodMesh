package com.example.methodmesh.ui.odk

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.methodmesh.modules.MethodMeshModuleRegistry
import com.example.methodmesh.ui.components.MethodMeshDestructiveConfirmation
import com.example.methodmesh.ui.odkcentral.OdkCentralClient
import com.example.methodmesh.ui.odkcentral.OdkCentralConnectionRepository
import com.example.methodmesh.ui.odkcentral.OdkCentralDeploymentStore
import com.example.methodmesh.ui.odkcentral.OdkCentralProfile
import com.example.methodmesh.ui.odkcentral.OdkCentralSessionStore
import com.example.methodmesh.ui.kobo.KoboClient
import com.example.methodmesh.ui.kobo.KoboConnectionRepository
import com.example.methodmesh.ui.kobo.KoboDeploymentStore
import com.example.methodmesh.ui.kobo.KoboProfile
import com.example.methodmesh.ui.kobo.KoboSessionStore
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
private const val INDEX_ASSET = "methodmesh/odk_templates/index.json"

data class OdkTemplateDescriptor(
    val id: String,
    val moduleId: String,
    val moduleName: String,
    val displayName: String,
    val description: String,
    val assetPath: String,
    val sourceFileName: String,
    val centralFormId: String,
    val formVersion: String,
    val sourceRelativePath: String,
    val capabilityIds: List<String>,
    val tags: List<String>
)

object OdkTemplateCatalog {
    fun load(context: Context): List<OdkTemplateDescriptor> = runCatching {
        val moduleNames = runCatching {
            MethodMeshModuleRegistry.all().associate { it.moduleId to it.displayName }
        }.getOrDefault(emptyMap())
        val json = context.assets.open(INDEX_ASSET).bufferedReader().use { it.readText() }
        val root = JSONObject(json)
        val templates = root.optJSONArray("templates") ?: JSONArray()
        buildList {
            for (i in 0 until templates.length()) {
                val item = templates.optJSONObject(i) ?: continue
                val assetPath = item.optString("assetPath")
                if (assetPath.isBlank()) continue
                val moduleId = item.optString("moduleId").ifBlank { "other" }
                add(
                    OdkTemplateDescriptor(
                        id = item.optString("id").ifBlank { assetPath },
                        moduleId = moduleId,
                        moduleName = moduleNames[moduleId]
                            ?: item.optString("moduleName").ifBlank { humanizeModuleId(moduleId) },
                        displayName = item.optString("displayName").ifBlank {
                            displayNameFromFilename(item.optString("sourceFileName").ifBlank { assetPath.substringAfterLast('/') })
                        },
                        description = item.optString("description"),
                        assetPath = assetPath,
                        sourceFileName = item.optString("sourceFileName").ifBlank { assetPath.substringAfterLast('/') },
                        centralFormId = item.optString("centralFormId"),
                        formVersion = item.optString("formVersion"),
                        sourceRelativePath = item.optString("sourceRelativePath"),
                        capabilityIds = item.optJSONArray("capabilityIds").stringList(),
                        tags = item.optJSONArray("tags").stringList()
                    )
                )
            }
        }.sortedWith(compareBy<OdkTemplateDescriptor> { it.moduleName.lowercase() }.thenBy { it.displayName.lowercase() })
    }.getOrDefault(emptyList())

    fun searchScore(template: OdkTemplateDescriptor, query: String): Int {
        val normalizedQuery = normalize(query)
        if (normalizedQuery.isBlank()) return 0
        val corpus = normalize(
            listOf(
                template.displayName,
                template.moduleName,
                template.moduleId,
                template.description,
                template.sourceFileName,
                template.centralFormId,
                template.formVersion,
                template.sourceRelativePath,
                template.capabilityIds.joinToString(" "),
                template.tags.joinToString(" "),
                "ODK Kobo KoboCollect XLSForm form design template collection"
            ).joinToString(" ")
        )
        var score = if (corpus.contains(normalizedQuery)) 100 else 0
        normalizedQuery.split(' ').filter { it.length > 1 }.forEach { token ->
            if (corpus.contains(token)) score += 25
        }
        return score
    }

    fun share(context: Context, template: OdkTemplateDescriptor): Result<Unit> = runCatching {
        val file = materialize(context, template)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = XLSX_MIME
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri(template.displayName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Share ODK design template"))
    }

    fun saveTo(context: Context, template: OdkTemplateDescriptor, destination: Uri): Result<Unit> = runCatching {
        context.assets.open(template.assetPath).use { input ->
            context.contentResolver.openOutputStream(destination)?.use { output ->
                input.copyTo(output)
            } ?: error("Could not open destination")
        }
    }

    private fun materialize(context: Context, template: OdkTemplateDescriptor): File {
        val dir = File(context.cacheDir, "odk_templates").apply { mkdirs() }
        val safeName = template.sourceFileName.ifBlank { "${template.id}.xlsx" }
        val file = File(dir, safeName)
        context.assets.open(template.assetPath).use { input -> file.outputStream().use { input.copyTo(it) } }
        return file
    }

    private fun normalize(value: String): String = value.lowercase().replace(Regex("[^a-z0-9+]+"), " ").trim()

    private fun humanizeModuleId(moduleId: String): String = moduleId
        .replace('_', ' ')
        .replace('-', ' ')
        .trim()
        .split(' ')
        .filter { it.isNotBlank() }
        .joinToString(" ") { word -> word.replaceFirstChar { c -> c.uppercase() } }
        .ifBlank { "Other" }

    private fun displayNameFromFilename(filename: String): String = filename
        .substringAfterLast('/')
        .removeSuffix(".xlsx")
        .removePrefix("example_odk_")
        .replace('.', ' ')
        .replace('_', ' ')
        .trim()
        .split(' ')
        .filter { it.isNotBlank() }
        .joinToString(" ") { word -> word.replaceFirstChar { c -> c.uppercase() } }

    private fun JSONArray?.stringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) optString(i).takeIf { it.isNotBlank() }?.let(::add)
        }
    }
}

private data class PendingCentralRemoval(
    val template: OdkTemplateDescriptor,
    val submissions: Int
)

private data class PendingKoboRemoval(
    val template: OdkTemplateDescriptor,
    val submissions: Int
)

@Composable
fun OdkTemplateLibrary(initialQuery: String = "") {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val templates = remember { OdkTemplateCatalog.load(context) }
    var query by rememberSaveable { mutableStateOf(initialQuery) }
    var pendingSave by remember { mutableStateOf<OdkTemplateDescriptor?>(null) }
    var pendingCentralRemoval by remember { mutableStateOf<PendingCentralRemoval?>(null) }
    var pendingKoboRemoval by remember { mutableStateOf<PendingKoboRemoval?>(null) }
    var status by rememberSaveable { mutableStateOf<String?>(null) }
    var busyKey by rememberSaveable { mutableStateOf<String?>(null) }
    var deploymentRevision by remember { mutableIntStateOf(0) }

    val centralProfile = remember(deploymentRevision) { OdkCentralConnectionRepository.load(context) }
    val centralSession = remember(deploymentRevision) { OdkCentralSessionStore.load(context) }
    val koboProfile = remember(deploymentRevision) { KoboConnectionRepository.load(context) }
    val koboSession = remember(deploymentRevision) { KoboSessionStore.load(context) }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(XLSX_MIME)) { uri ->
        val template = pendingSave
        pendingSave = null
        if (uri != null && template != null) {
            status = OdkTemplateCatalog.saveTo(context, template, uri).fold(
                onSuccess = { "Saved ${template.displayName}." },
                onFailure = { "Save failed: ${it.message ?: "storage error"}" }
            )
        }
    }

    LaunchedEffect(initialQuery) {
        if (initialQuery.isNotBlank()) query = initialQuery
    }

    val trimmed = query.trim()
    val filtered = remember(templates, trimmed) {
        if (trimmed.isBlank()) templates else templates
            .map { it to OdkTemplateCatalog.searchScore(it, trimmed) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .map { it.first }
    }
    val grouped = filtered.groupBy { it.moduleName }.toSortedMap()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ODK forms", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Module-owned XLSForm design templates.",
                    modifier = Modifier.padding(top = 4.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (centralProfile.isConfigured && centralSession != null) {
                Text(
                    "Sync ODK",
                    modifier = Modifier.clickable(enabled = busyKey == null) {
                        scope.launch {
                            val checked = templates.filter { template ->
                                centralProfile.deployment(context, template)?.assignedAppUserId == centralProfile.appUserId
                            }
                            if (checked.isEmpty()) {
                                status = "No forms are enabled for ${centralProfile.appUserName}."
                                return@launch
                            }
                            busyKey = "central:__all__"
                            var successes = 0
                            var failure: String? = null
                            checked.forEach { template ->
                                runCatching { OdkCentralClient.deployAndAssign(context, centralProfile, centralSession.token, template) }
                                    .onSuccess { successes += 1 }
                                    .onFailure { if (failure == null) failure = "${template.displayName}: ${it.message}" }
                            }
                            busyKey = null
                            deploymentRevision += 1
                            status = failure ?: "Synced $successes ODK form${if (successes == 1) "" else "s"}."
                        }
                    }.padding(vertical = 8.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (koboProfile.isConfigured && koboSession != null) {
                if (centralProfile.isConfigured && centralSession != null) Spacer(Modifier.width(14.dp))
                Text(
                    "Sync Kobo",
                    modifier = Modifier.clickable(enabled = busyKey == null) {
                        scope.launch {
                            val checked = templates.filter { template -> koboProfile.deployment(context, template)?.active == true }
                            if (checked.isEmpty()) {
                                status = "No forms are enabled for KoboCollect."
                                return@launch
                            }
                            busyKey = "kobo:__all__"
                            var successes = 0
                            var failure: String? = null
                            checked.forEach { template ->
                                runCatching { KoboClient.deploy(context, koboProfile, koboSession.token, template) }
                                    .onSuccess { successes += 1 }
                                    .onFailure { if (failure == null) failure = "${template.displayName}: ${it.message}" }
                            }
                            busyKey = null
                            deploymentRevision += 1
                            status = failure ?: "Synced $successes Kobo form${if (successes == 1) "" else "s"}."
                        }
                    }.padding(vertical = 8.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        when {
            centralProfile.isConfigured && centralSession != null && koboProfile.isConfigured && koboSession != null -> Text(
                "Rapid testing is connected to ODK Central and KoboToolbox. Enable either route independently for each XLSForm.",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            centralProfile.isConfigured && centralSession != null -> Text(
                "ODK Central is connected. Configure Settings → KoboToolbox to test the same forms in KoboCollect too.",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            koboProfile.isConfigured && koboSession != null -> Text(
                "KoboToolbox is connected. Configure Settings → ODK Central to test the same forms against Central too.",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            else -> Text(
                "Configure ODK Central and/or KoboToolbox in Settings to deploy these local templates for rapid testing.",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
            singleLine = true,
            placeholder = { Text("Search forms") }
        )

        if (templates.isEmpty()) {
            Text(
                "No ODK design templates are packaged in this build.",
                modifier = Modifier.padding(top = 18.dp),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "The build catalogue should scan every module docs folder for example_odk*.xlsx; one module may contribute one form or many. Expected index: $INDEX_ASSET.",
                modifier = Modifier.padding(top = 4.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            return@Column
        }

        Text(
            if (filtered.size == 1) "1 form" else "${filtered.size} forms",
            modifier = Modifier.padding(top = 8.dp),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (filtered.isEmpty()) {
            Text(
                "No forms match this search.",
                modifier = Modifier.padding(top = 18.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            grouped.forEach { (moduleName, moduleTemplates) ->
                var expanded by rememberSaveable("odk-template-module:$moduleName") { mutableStateOf(false) }
                val show = expanded || trimmed.isNotBlank()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(moduleName, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${moduleTemplates.size} form${if (moduleTemplates.size == 1) "" else "s"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(if (show) "−" else "+", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))

                if (show) {
                    moduleTemplates.forEach { template ->
                        val centralDeployment = remember(deploymentRevision, centralProfile, template.id) {
                            centralProfile.deployment(context, template)
                        }
                        val koboDeployment = remember(deploymentRevision, koboProfile, template.id) {
                            koboProfile.deployment(context, template)
                        }
                        val centralChecked = centralProfile.isConfigured && centralDeployment?.assignedAppUserId == centralProfile.appUserId
                        val koboChecked = koboProfile.isConfigured && koboDeployment?.active == true
                        val localDigest = remember(template.id) {
                            runCatching { OdkCentralClient.localDigest(context, template) }.getOrDefault("")
                        }
                        val centralUpdate = centralDeployment != null && localDigest.isNotBlank() && centralDeployment.localSha256 != localDigest
                        val koboUpdate = koboDeployment != null && localDigest.isNotBlank() && koboDeployment.localSha256 != localDigest
                        val centralBusy = busyKey == "central:${template.id}" || busyKey == "central:__all__"
                        val koboBusy = busyKey == "kobo:${template.id}" || busyKey == "kobo:__all__"

                        Column(Modifier.fillMaxWidth().padding(start = 4.dp, top = 11.dp, bottom = 11.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(template.displayName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    val subtitle = template.description.ifBlank {
                                        template.capabilityIds.joinToString(", ").ifBlank { template.sourceFileName }
                                    }
                                    Text(
                                        subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "Share",
                                    modifier = Modifier.clickable {
                                        status = OdkTemplateCatalog.share(context, template).fold(
                                            onSuccess = { null },
                                            onFailure = { "Share failed: ${it.message ?: "provider error"}" }
                                        )
                                    }.padding(vertical = 8.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.width(14.dp))
                                Text(
                                    "Save",
                                    modifier = Modifier.clickable {
                                        pendingSave = template
                                        saveLauncher.launch(template.sourceFileName)
                                    }.padding(vertical = 8.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth().padding(top = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProviderToggle(
                                    label = "ODK",
                                    checked = centralChecked,
                                    enabled = centralProfile.isConfigured && centralSession != null && !centralBusy && busyKey == null,
                                    statusText = when {
                                        centralBusy -> "syncing"
                                        centralChecked && centralUpdate -> "update"
                                        centralChecked -> centralProfile.appUserName.ifBlank { "on" }
                                        centralDeployment != null -> "off"
                                        else -> "local"
                                    },
                                    attention = centralUpdate,
                                    onCheckedChange = { enable ->
                                        if (centralSession == null || !centralProfile.isConfigured) {
                                            status = "Configure Settings → ODK Central first."
                                        } else {
                                            scope.launch {
                                                busyKey = "central:${template.id}"
                                                status = if (enable) "Deploying ${template.displayName} to ODK Central…" else "Revoking ODK test access…"
                                                runCatching {
                                                    if (enable) OdkCentralClient.deployAndAssign(context, centralProfile, centralSession.token, template)
                                                    else OdkCentralClient.revokeTesterAccess(context, centralProfile, centralSession.token, template)
                                                }.onSuccess {
                                                    deploymentRevision += 1
                                                    status = if (enable) {
                                                        "${template.displayName} is available to ${centralProfile.appUserName} in ODK Collect."
                                                    } else {
                                                        "${template.displayName} is no longer available to ${centralProfile.appUserName}."
                                                    }
                                                }.onFailure { status = "ODK Central sync failed: ${it.message ?: "request error"}" }
                                                busyKey = null
                                            }
                                        }
                                    }
                                )
                                Spacer(Modifier.width(20.dp))
                                ProviderToggle(
                                    label = "Kobo",
                                    checked = koboChecked,
                                    enabled = koboProfile.isConfigured && koboSession != null && !koboBusy && busyKey == null,
                                    statusText = when {
                                        koboBusy -> "syncing"
                                        koboChecked && koboUpdate -> "update"
                                        koboChecked -> "KoboCollect"
                                        koboDeployment != null -> "inactive"
                                        else -> "local"
                                    },
                                    attention = koboUpdate,
                                    onCheckedChange = { enable ->
                                        if (koboSession == null || !koboProfile.isConfigured) {
                                            status = "Configure Settings → KoboToolbox first."
                                        } else {
                                            scope.launch {
                                                busyKey = "kobo:${template.id}"
                                                status = if (enable) "Deploying ${template.displayName} to KoboToolbox…" else "Removing ${template.displayName} from KoboCollect…"
                                                runCatching {
                                                    if (enable) KoboClient.deploy(context, koboProfile, koboSession.token, template)
                                                    else KoboClient.deactivate(context, koboProfile, koboSession.token, template)
                                                }.onSuccess {
                                                    deploymentRevision += 1
                                                    status = if (enable) {
                                                        "${template.displayName} is active in KoboCollect."
                                                    } else {
                                                        "${template.displayName} is inactive in KoboCollect; the remote project and submissions are preserved."
                                                    }
                                                }.onFailure { status = "Kobo sync failed: ${it.message ?: "request error"}" }
                                                busyKey = null
                                            }
                                        }
                                    }
                                )
                            }

                            if ((centralDeployment != null && centralSession != null) || (koboDeployment != null && koboSession != null)) {
                                Row(Modifier.fillMaxWidth().padding(top = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                                    if (centralDeployment != null && centralSession != null) {
                                        Text(
                                            "Remove from Central",
                                            modifier = Modifier.clickable(enabled = busyKey == null) {
                                                scope.launch {
                                                    busyKey = "central:${template.id}"
                                                    val count = runCatching {
                                                        OdkCentralClient.remoteSubmissionCount(context, centralProfile, centralSession.token, template)
                                                    }.getOrDefault(0)
                                                    busyKey = null
                                                    pendingCentralRemoval = PendingCentralRemoval(template, count)
                                                }
                                            }.padding(vertical = 6.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                    if (centralDeployment != null && centralSession != null && koboDeployment != null && koboSession != null) {
                                        Spacer(Modifier.width(18.dp))
                                    }
                                    if (koboDeployment != null && koboSession != null) {
                                        Text(
                                            "Remove from Kobo",
                                            modifier = Modifier.clickable(enabled = busyKey == null) {
                                                scope.launch {
                                                    busyKey = "kobo:${template.id}"
                                                    val count = runCatching {
                                                        KoboClient.remoteSubmissionCount(context, koboProfile, koboSession.token, template)
                                                    }.getOrDefault(0)
                                                    busyKey = null
                                                    pendingKoboRemoval = PendingKoboRemoval(template, count)
                                                }
                                            }.padding(vertical = 6.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                    }
                }
            }
        }

        status?.let {
            Spacer(Modifier.height(12.dp))
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = if (it.contains("failed", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
        }
    }

    pendingCentralRemoval?.let { pending ->
        val currentSession = centralSession
        MethodMeshDestructiveConfirmation(
            title = "Remove from ODK Central?",
            objectName = pending.template.displayName,
            consequence = buildString {
                append("The remote form will be moved to Central Trash. The local MethodMesh XLSForm template is kept.")
                if (pending.submissions > 0) append("\n\nThis form currently has ${pending.submissions} submission${if (pending.submissions == 1) "" else "s"}.")
            },
            confirmLabel = "Remove",
            onDismiss = { pendingCentralRemoval = null },
            onConfirm = {
                pendingCentralRemoval = null
                if (currentSession != null) {
                    scope.launch {
                        busyKey = "central:${pending.template.id}"
                        runCatching { OdkCentralClient.removeRemoteForm(context, centralProfile, currentSession.token, pending.template) }
                            .onSuccess {
                                deploymentRevision += 1
                                status = "Removed ${pending.template.displayName} from ODK Central."
                            }
                            .onFailure { status = "Central removal failed: ${it.message ?: "request error"}" }
                        busyKey = null
                    }
                }
            }
        )
    }

    pendingKoboRemoval?.let { pending ->
        val currentSession = koboSession
        MethodMeshDestructiveConfirmation(
            title = "Remove from KoboToolbox?",
            objectName = pending.template.displayName,
            consequence = buildString {
                append("The remote KoboToolbox project will be deleted. The local MethodMesh XLSForm template is kept. Untick Kobo instead if you only want to remove it from KoboCollect while preserving the remote project.")
                if (pending.submissions > 0) append("\n\nThis project currently reports ${pending.submissions} submission${if (pending.submissions == 1) "" else "s"}.")
            },
            confirmLabel = "Remove",
            onDismiss = { pendingKoboRemoval = null },
            onConfirm = {
                pendingKoboRemoval = null
                if (currentSession != null) {
                    scope.launch {
                        busyKey = "kobo:${pending.template.id}"
                        runCatching { KoboClient.removeRemote(context, koboProfile, currentSession.token, pending.template) }
                            .onSuccess {
                                deploymentRevision += 1
                                status = "Removed ${pending.template.displayName} from KoboToolbox."
                            }
                            .onFailure { status = "Kobo removal failed: ${it.message ?: "request error"}" }
                        busyKey = null
                    }
                }
            }
        )
    }
}

@Composable
private fun ProviderToggle(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    statusText: String,
    attention: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, enabled = enabled, onCheckedChange = onCheckedChange)
        Column(Modifier.padding(start = 2.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Text(
                statusText,
                style = MaterialTheme.typography.labelSmall,
                color = if (attention) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun OdkCentralProfile.deployment(context: Context, template: OdkTemplateDescriptor) =
    projectId?.let { project ->
        OdkCentralDeploymentStore.get(
            context,
            OdkCentralConnectionRepository.normalizeServerUrl(serverUrl),
            project,
            template.id
        )
    }

private fun KoboProfile.deployment(context: Context, template: OdkTemplateDescriptor) =
    KoboDeploymentStore.get(
        context,
        KoboConnectionRepository.normalizeServerUrl(serverUrl),
        template.id
    )
