package com.example.methodmesh.ui.kobo

import android.content.Context
import android.util.Base64
import com.example.methodmesh.ui.odk.OdkTemplateDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.time.Instant
import java.util.UUID

class KoboApiException(val statusCode: Int, message: String) : IllegalStateException(message)

object KoboClient {
    private const val XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    suspend fun login(serverUrl: String, username: String, password: String): KoboSession = withContext(Dispatchers.IO) {
        val server = KoboConnectionRepository.normalizeServerUrl(serverUrl)
        val credentials = Base64.encodeToString("${username.trim()}:$password".toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val json = requestJson(
            server, "GET", "/token/?format=json",
            authorization = "Basic $credentials"
        )
        KoboSession(json.getString("token"))
    }

    suspend fun currentUser(serverUrl: String, token: String): JSONObject = withContext(Dispatchers.IO) {
        requestJson(KoboConnectionRepository.normalizeServerUrl(serverUrl), "GET", "/me/", token = token)
    }

    suspend fun deploy(
        context: Context,
        profile: KoboProfile,
        token: String,
        template: OdkTemplateDescriptor
    ): KoboTemplateDeployment = withContext(Dispatchers.IO) {
        val server = KoboConnectionRepository.normalizeServerUrl(profile.serverUrl)
        val bytes = context.assets.open(template.assetPath).use { it.readBytes() }
        val digest = sha256(bytes)
        var existing = KoboDeploymentStore.get(context, server, template.id)

        if (existing != null && !assetExists(server, token, existing.assetUid)) {
            KoboDeploymentStore.remove(context, server, template.id)
            existing = null
        }

        val uid = if (existing == null) {
            importXlsForm(server, token, template.sourceFileName, bytes, destination = null)
        } else {
            if (existing.localSha256 != digest) {
                importXlsForm(
                    server,
                    token,
                    template.sourceFileName,
                    bytes,
                    destination = "/api/v2/assets/${existing.assetUid}/"
                )
            }
            existing.assetUid
        }

        val asset = requestJson(server, "GET", "/api/v2/assets/$uid/?format=json", token = token)
        val versionId = asset.optString("version_id")
        val fields = linkedMapOf("active" to "true")
        if (versionId.isNotBlank()) fields["version_id"] = versionId
        requestForm(server, "POST", "/api/v2/assets/$uid/deployment/?format=json", token, fields)

        KoboTemplateDeployment(
            serverUrl = server,
            templateId = template.id,
            assetUid = uid,
            localSha256 = digest,
            active = true,
            lastSyncedAt = Instant.now().toString()
        ).also { KoboDeploymentStore.put(context, it) }
    }

    suspend fun deactivate(
        context: Context,
        profile: KoboProfile,
        token: String,
        template: OdkTemplateDescriptor
    ): KoboTemplateDeployment? = withContext(Dispatchers.IO) {
        val server = KoboConnectionRepository.normalizeServerUrl(profile.serverUrl)
        val existing = KoboDeploymentStore.get(context, server, template.id) ?: return@withContext null
        requestForm(
            server, "POST", "/api/v2/assets/${existing.assetUid}/deployment/?format=json", token,
            linkedMapOf("active" to "false")
        )
        existing.copy(active = false, lastSyncedAt = Instant.now().toString()).also {
            KoboDeploymentStore.put(context, it)
        }
    }

    suspend fun removeRemote(
        context: Context,
        profile: KoboProfile,
        token: String,
        template: OdkTemplateDescriptor
    ) = withContext(Dispatchers.IO) {
        val server = KoboConnectionRepository.normalizeServerUrl(profile.serverUrl)
        val existing = KoboDeploymentStore.get(context, server, template.id)
            ?: error("This template is not mapped to a KoboToolbox project on this server.")
        request(server, "DELETE", "/api/v2/assets/${existing.assetUid}/", token = token)
        KoboDeploymentStore.remove(context, server, template.id)
    }

    suspend fun remoteSubmissionCount(
        context: Context,
        profile: KoboProfile,
        token: String,
        template: OdkTemplateDescriptor
    ): Int = withContext(Dispatchers.IO) {
        val server = KoboConnectionRepository.normalizeServerUrl(profile.serverUrl)
        val existing = KoboDeploymentStore.get(context, server, template.id) ?: return@withContext 0
        runCatching {
            requestJson(server, "GET", "/api/v2/assets/${existing.assetUid}/?format=json", token = token)
                .optInt("deployment__submission_count", 0)
        }.getOrDefault(0)
    }

    fun localDigest(context: Context, template: OdkTemplateDescriptor): String =
        context.assets.open(template.assetPath).use { sha256(it.readBytes()) }

    private fun assetExists(server: String, token: String, uid: String): Boolean = runCatching {
        requestJson(server, "GET", "/api/v2/assets/$uid/?format=json", token = token)
        true
    }.getOrElse { error ->
        if (error is KoboApiException && error.statusCode == 404) false else throw error
    }

    private suspend fun importXlsForm(
        server: String,
        token: String,
        filename: String,
        bytes: ByteArray,
        destination: String?
    ): String {
        val parts = mutableListOf(
            MultipartPart.Field("library", "false"),
            MultipartPart.File("file", filename.ifBlank { "methodmesh_form.xlsx" }, XLSX_MIME, bytes)
        )
        destination?.let { parts += MultipartPart.Field("destination", it) }
        val started = requestMultipart(server, "POST", "/api/v2/imports/", token, parts)
        val importUid = started.optString("uid").ifBlank { error("Kobo import did not return an import UID.") }

        repeat(40) {
            val state = requestJson(server, "GET", "/api/v2/imports/$importUid/", token = token)
            when (state.optString("status").lowercase()) {
                "complete", "completed", "success" -> {
                    return extractAssetUid(state) ?: destination?.trim('/')?.substringAfterLast('/')
                        ?: error("Kobo import completed but no asset UID was returned.")
                }
                "failed", "error" -> {
                    val message = state.optString("error").ifBlank { state.optString("message") }
                    throw KoboApiException(422, message.ifBlank { "Kobo XLSForm import failed." })
                }
            }
            delay(500)
        }
        throw KoboApiException(408, "Kobo XLSForm import did not finish in time.")
    }

    private fun extractAssetUid(root: JSONObject): String? {
        root.optString("asset_uid").takeIf(String::isNotBlank)?.let { return it }
        root.optString("uid").takeIf { it.isNotBlank() && root.optString("status").isBlank() }?.let { return it }
        val messages = root.optJSONObject("messages")
        val arrays = listOf("created", "updated", "modified")
        arrays.forEach { key ->
            val arr = messages?.optJSONArray(key) ?: return@forEach
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                item.optString("uid").takeIf(String::isNotBlank)?.let { return it }
            }
        }
        return null
    }

    private sealed class MultipartPart {
        data class Field(val name: String, val value: String) : MultipartPart()
        data class File(val name: String, val filename: String, val contentType: String, val bytes: ByteArray) : MultipartPart()
    }

    private fun requestMultipart(
        server: String,
        method: String,
        path: String,
        token: String,
        parts: List<MultipartPart>
    ): JSONObject {
        val boundary = "----MethodMesh${UUID.randomUUID().toString().replace("-", "")}" 
        val crlf = "\r\n"
        val body = ByteArrayOutputStream().apply {
            parts.forEach { part ->
                write("--$boundary$crlf".toByteArray())
                when (part) {
                    is MultipartPart.Field -> {
                        write("Content-Disposition: form-data; name=\"${part.name}\"$crlf$crlf".toByteArray())
                        write(part.value.toByteArray())
                        write(crlf.toByteArray())
                    }
                    is MultipartPart.File -> {
                        write("Content-Disposition: form-data; name=\"${part.name}\"; filename=\"${part.filename.replace("\"", "")}\"$crlf".toByteArray())
                        write("Content-Type: ${part.contentType}$crlf$crlf".toByteArray())
                        write(part.bytes)
                        write(crlf.toByteArray())
                    }
                }
            }
            write("--$boundary--$crlf".toByteArray())
        }.toByteArray()
        return requestJson(
            server, method, path, token = token, body = body,
            contentType = "multipart/form-data; boundary=$boundary"
        )
    }

    private fun requestForm(
        server: String,
        method: String,
        path: String,
        token: String,
        fields: Map<String, String>
    ): JSONObject {
        val body = fields.entries.joinToString("&") {
            "${urlEncode(it.key)}=${urlEncode(it.value)}"
        }.toByteArray(Charsets.UTF_8)
        return requestJson(
            server, method, path, token = token, body = body,
            contentType = "application/x-www-form-urlencoded"
        )
    }

    private fun requestJson(
        server: String,
        method: String,
        path: String,
        token: String? = null,
        authorization: String? = null,
        body: ByteArray? = null,
        contentType: String? = null
    ): JSONObject {
        val text = request(server, method, path, token, authorization, body, contentType)
        return if (text.isBlank()) JSONObject().put("success", true) else JSONObject(text)
    }

    private fun request(
        server: String,
        method: String,
        path: String,
        token: String? = null,
        authorization: String? = null,
        body: ByteArray? = null,
        contentType: String? = null
    ): String {
        val base = KoboConnectionRepository.normalizeServerUrl(server)
        val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15_000
            readTimeout = 60_000
            setRequestProperty("Accept", "application/json")
            when {
                !authorization.isNullOrBlank() -> setRequestProperty("Authorization", authorization)
                !token.isNullOrBlank() -> setRequestProperty("Authorization", "Token $token")
            }
            contentType?.let { setRequestProperty("Content-Type", it) }
            if (body != null) {
                doOutput = true
                setFixedLengthStreamingMode(body.size)
            }
        }
        body?.let { connection.outputStream.use { out -> out.write(it) } }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        connection.disconnect()
        if (status !in 200..299) {
            val message = runCatching {
                val root = JSONObject(text)
                root.optString("detail").ifBlank {
                    root.optString("message").ifBlank { root.optString("error") }
                }
            }.getOrNull().orEmpty().ifBlank { "KoboToolbox request failed ($status)." }
            throw KoboApiException(status, message)
        }
        return text
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(bytes)
        .joinToString("") { "%02x".format(it) }

    private fun urlEncode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
}
