# Paper Bridge colour-authored templates

Paper Bridge can be authored with an ordinary `.xlsx` workbook and a deliberately annotated paper template. ODK is optional: the workbook only needs the standard XLSForm-style `survey` and `choices` sheets and the fixed subset below.

## Workbook contract

`survey` must contain `type`, `name`, and `label`; `required` and `constraint` are optional. Supported `type` values are:

- `text`
- `integer`
- `decimal`
- `barcode`
- `select_one <list_name>`
- `select_multiple <list_name>`

`choices` must contain `list_name`, `name`, and `label` for choice lists. `settings` is optional; when present, Paper Bridge reads `form_id`, `form_title`, and `version`.

Question matching is performed against `survey.label`, not the variable name. Choice matching is performed against `choices.label`; the corresponding `name` is the value returned at runtime.

## Fixed colour syntax

The authoring template uses sRGB colours as a design-time annotation language:

| Meaning | Hex |
| --- | --- |
| Scalar question envelope (`text`, `integer`, `decimal`) | `#D81B60` |
| `select_one` question envelope | `#00897B` |
| `select_multiple` question envelope | `#EF6C00` |
| Barcode/QR question envelope | `#5E35B1` |
| Select option/answer label text | `#1565C0` |
| Question text | `#000000` |
| Runtime response boxes / mark geometry | `#000000` |

The coloured envelope encloses the complete question: its black question stem and the black response region(s). For select questions, answer-option text is blue while the actual tick boxes remain black.

Bold text is recommended in the authoring template because it improves design-time OCR. The production paper form does **not** need bold text or these colours. It may use any visual style, including colour, because runtime Paper Bridge reads only the saved ROI geometry after registration.

## Automatic authoring pass

When both the registered paper template and workbook are present, the designer can run the colour analysis automatically. It:

1. finds the fixed-colour question envelopes;
2. classifies each envelope by question type;
3. OCRs black question text inside each envelope;
4. compares that text with compatible `survey.label` values;
5. detects black response rectangles inside the envelope;
6. for select questions, OCRs blue option text and compares it with `choices.label`;
7. wires high-confidence question/choice matches to the corresponding response ROI;
8. leaves ambiguous or unmatched regions available for manual linking.

The authoring colour is never consulted during completed-form extraction.

## Runtime and handwritten text

Completed forms are acquired through ML Kit, registered to the four target centres, cropped to that target-centre rectangle and resized to canonical dimensions. Extraction then uses only the saved ROIs.

Free text (`text`) always requires operator confirmation before Commit. The review card shows the cropped paper ROI beside the editable OCR proposal. Integer and decimal OCR can be eligible for auto-accept only when explicitly enabled and the candidate passes the declared constraints.

## Portable backup

Saving a design produces:

- `*.paperbridge.json` — canonical machine definition;
- `*.paperbridge.yaml` — fixed-profile YAML mirror containing the canonical restore payload;
- `*.template.png` — canonical target-centre authoring image;
- `*.mapping.png` — annotated field/choice mapping;
- `*.paperbridge.zip` — portable bundle containing all four files.

The JSON, fixed-profile YAML, or portable ZIP can be copied to another device and imported. The bundle contains no participant response data.
