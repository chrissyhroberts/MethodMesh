package com.example.methodmesh.modules.paperbridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

internal data class PaperBridgeRecentActivity(
    val scanTimeIso: String,
    val templateId: String,
    val templateVersion: String,
    val templateTitle: String,
    val fieldCount: Int,
    val autoAcceptedCount: Int,
    val reviewedCount: Int
)

/**
 * Small module-owned workspace index for the native Paper Bridge dashboard.
 *
 * This is deliberately not a questionnaire data store. It persists only:
 *  - paper template manifests selected/imported by the operator; and
 *  - non-identifying activity metadata used by the dashboard.
 *
 * Committed field values and participant identifiers are never written here.
 * ODK/calling workflows remain responsible for instance persistence/submission.
 */
internal object PaperBridgeWorkspace {
    private const val PREFS = "paperbridge_workspace_v1"
    private const val KEY_TEMPLATES = "templates_json"
    private const val KEY_ACTIVE = "active_template_key"
    private const val KEY_RECENT = "recent_activity_json"
    private const val MAX_RECENT = 8

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun templateKey(template: PaperTemplate): String = "${template.templateId}::${template.version}"

    fun isBundled(template: PaperTemplate): Boolean = PaperBridgeBuiltInExamples.isDemo(template)

    fun templates(context: Context): List<PaperTemplate> {
        val demo = PaperTemplate.parse(PaperTemplateSamples.DEMO_MANIFEST_JSON)
        val raw = prefs(context).getString(KEY_TEMPLATES, "[]").orEmpty()
        var migratedAny = false
        val migratedRaw = mutableListOf<String>()
        val custom = runCatching {
            val array = JSONArray(raw.ifBlank { "[]" })
            (0 until array.length()).mapNotNull { index ->
                array.optString(index).takeIf(String::isNotBlank)?.let { manifest ->
                    val migrated = normalizeManifest(manifest)
                    migratedRaw += migrated
                    if (migrated != manifest) migratedAny = true
                    runCatching { PaperTemplate.parse(migrated) }.getOrNull()
                }
            }
        }.getOrDefault(emptyList())
        if (migratedAny) {
            val migratedArray = JSONArray().apply { migratedRaw.forEach { put(it) } }
            prefs(context).edit().putString(KEY_TEMPLATES, migratedArray.toString()).apply()
        }
        return (listOf(demo) + custom)
            .distinctBy(::templateKey)
            .sortedWith(compareBy<PaperTemplate> { if (isBundled(it)) 0 else 1 }.thenBy { it.title.lowercase() })
    }

    fun activeTemplateJson(context: Context): String {
        val all = templates(context)
        val activeKey = prefs(context).getString(KEY_ACTIVE, null)
        return all.firstOrNull { templateKey(it) == activeKey }?.rawJson
            ?: all.first().rawJson
    }

    fun saveAndActivateTemplate(context: Context, manifestJson: String): PaperTemplate {
        val parsed = PaperTemplate.parse(normalizeManifest(manifestJson))
        if (!isBundled(parsed)) {
            val existing = templates(context).filterNot(::isBundled).toMutableList()
            val key = templateKey(parsed)
            val replaced = existing.map { if (templateKey(it) == key) parsed else it }.toMutableList()
            if (replaced.none { templateKey(it) == key }) replaced += parsed
            val array = JSONArray().apply { replaced.forEach { put(it.rawJson) } }
            prefs(context).edit().putString(KEY_TEMPLATES, array.toString()).apply()
        }
        prefs(context).edit().putString(KEY_ACTIVE, templateKey(parsed)).apply()
        return parsed
    }

    fun activateTemplate(context: Context, template: PaperTemplate) {
        prefs(context).edit().putString(KEY_ACTIVE, templateKey(template)).apply()
    }

    fun removeTemplate(context: Context, template: PaperTemplate) {
        if (isBundled(template)) return
        val remaining = templates(context)
            .filterNot(::isBundled)
            .filterNot { templateKey(it) == templateKey(template) }
        val array = JSONArray().apply { remaining.forEach { put(it.rawJson) } }
        val edit = prefs(context).edit().putString(KEY_TEMPLATES, array.toString())
        if (prefs(context).getString(KEY_ACTIVE, null) == templateKey(template)) {
            val demo = PaperTemplate.parse(PaperTemplateSamples.DEMO_MANIFEST_JSON)
            edit.putString(KEY_ACTIVE, templateKey(demo))
        }
        edit.apply()
    }

    /**
     * Early Paper Bridge development builds normalised ROI coordinates to the physical
     * page edge. The corrected model uses the rectangle between registration-target
     * centres. Migrate only persisted workspace templates that do not already declare
     * the new frame; method IDs and field names remain unchanged.
     */
    fun normalizeManifest(raw: String): String = runCatching {
        val root = JSONObject(raw)
        if (root.optString("coordinate_frame") == "anchor_centres") return@runCatching raw
        val anchors = root.optJSONObject("anchors")
        val targetArray = anchors?.optJSONArray("targets")
        val targets = if (targetArray != null && targetArray.length() == 4) {
            (0 until 4).map { i ->
                val p = targetArray.getJSONArray(i)
                p.getDouble(0) to p.getDouble(1)
            }
        } else {
            PaperAnchorSpec().targets.map { it.first.toDouble() to it.second.toDouble() }
        }
        val left = targets.minOf { it.first }
        val right = targets.maxOf { it.first }
        val top = targets.minOf { it.second }
        val bottom = targets.maxOf { it.second }
        val width = right - left
        val height = bottom - top
        if (width <= 0.0 || height <= 0.0) return@runCatching raw

        fun migrateRoi(array: JSONArray) {
            if (array.length() != 4) return
            fun x(value: Double) = ((value - left) / width).coerceIn(0.0, 1.0)
            fun y(value: Double) = ((value - top) / height).coerceIn(0.0, 1.0)
            val l = x(array.getDouble(0))
            val t = y(array.getDouble(1))
            val r = x(array.getDouble(2))
            val b = y(array.getDouble(3))
            if (r > l && b > t) {
                array.put(0, l); array.put(1, t); array.put(2, r); array.put(3, b)
            }
        }

        val fields = root.optJSONArray("fields") ?: JSONArray()
        for (i in 0 until fields.length()) {
            val field = fields.optJSONObject(i) ?: continue
            field.optJSONArray("roi")?.let(::migrateRoi)
            val options = field.optJSONArray("options") ?: continue
            for (j in 0 until options.length()) {
                options.optJSONObject(j)?.optJSONArray("roi")?.let(::migrateRoi)
            }
        }
        root.put("coordinate_frame", "anchor_centres")
        root.toString()
    }.getOrDefault(raw)

    fun recordCommit(
        context: Context,
        template: PaperTemplate,
        scanTimeIso: String,
        fieldCount: Int,
        autoAcceptedCount: Int,
        reviewedCount: Int
    ) {
        val entry = JSONObject()
            .put("scan_time_iso", scanTimeIso)
            .put("template_id", template.templateId)
            .put("template_version", template.version)
            .put("template_title", template.title)
            .put("field_count", fieldCount)
            .put("auto_accepted_count", autoAcceptedCount)
            .put("reviewed_count", reviewedCount)
        val previous = prefs(context).getString(KEY_RECENT, "[]").orEmpty()
        val output = JSONArray().put(entry)
        runCatching {
            val old = JSONArray(previous.ifBlank { "[]" })
            for (index in 0 until minOf(old.length(), MAX_RECENT - 1)) output.put(old.get(index))
        }
        prefs(context).edit().putString(KEY_RECENT, output.toString()).apply()
    }

    fun recent(context: Context): List<PaperBridgeRecentActivity> {
        val raw = prefs(context).getString(KEY_RECENT, "[]").orEmpty()
        return runCatching {
            val array = JSONArray(raw.ifBlank { "[]" })
            (0 until minOf(array.length(), MAX_RECENT)).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                PaperBridgeRecentActivity(
                    scanTimeIso = item.optString("scan_time_iso"),
                    templateId = item.optString("template_id"),
                    templateVersion = item.optString("template_version"),
                    templateTitle = item.optString("template_title"),
                    fieldCount = item.optInt("field_count", 0),
                    autoAcceptedCount = item.optInt("auto_accepted_count", 0),
                    reviewedCount = item.optInt("reviewed_count", 0)
                )
            }
        }.getOrDefault(emptyList())
    }

    fun clearRecent(context: Context) {
        prefs(context).edit().remove(KEY_RECENT).apply()
    }
}
