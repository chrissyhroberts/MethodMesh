# Star spectrum analyser

**Module:** `star_spectrum`  
**Capability:** `astronomy.spectrum.analyse`  
**Version:** `0.1.0`  
**Maturity:** `DEVELOPMENT`  
**Connectivity:** `OFFLINE`

## Purpose

`astronomy.spectrum.analyse` turns a raster astronomical image containing a slitless stellar spectrum into a traced, background-corrected and contamination-aware one-dimensional spectrum.

The operator draws only an approximate line over the dispersed spectrum. MethodMesh then searches within a ribbon around that line, optimises the spatial trace, estimates local background from sidebands, models the target's cross-dispersion profile, identifies likely point-source/field-star contamination, extracts corrected intensity, optionally applies a previously saved wavelength solution, detects emission and/or absorption features, and exports the result.

The capability is intentionally an **analysis instrument**, not an automatic stellar-classification or elemental-identification system.

## Canonical surfaces

The capability contract is declared once in `StarSpectrumAnalyseMethod.kt` and `StarSpectrumModule.kt`.

It remains independently addressable through:

- direct native capability use;
- the generic MethodMesh dashboard presence;
- presets;
- protocols and protocol pipes;
- schedules/widgets when authored to show this interactive capability;
- ODK/XLSForm through the normal MethodMesh Android-intent roundtrip.

There is no dashboard-only implementation and no shared-shell special case.

## Native workflow

The native screen is one continuous tool surface.

1. Choose a spectrum image, or accept an image URI supplied by the caller.
2. Select an optional saved wavelength reference.
3. Pinch/zoom and pan the image.
4. Tap **Draw trace** and drag roughly along the dispersed spectrum.
5. MethodMesh displays the trace-search ribbon.
6. Tap **Analyse**.
7. The same screen displays the optimised trace, likely contaminants, extracted spectrum, quality metrics and detected features.
8. Adjust extraction/detection settings and re-run while the result is still working state.
9. Tap **Commit analysis** to freeze the canonical payload.
10. In committed state, Share, Save, copy the feature list, optionally include full JSON, then Done.

The screen deliberately does not navigate to a generic result page after analysis or Commit.

## Image interaction

The image surface supports:

- pinch zoom up to 8×;
- pan by drag when not drawing a trace;
- a dedicated draw/redraw mode so one-finger trace placement is unambiguous;
- reset view;
- display of the user's original line;
- display of the trace-search ribbon;
- display of the optimised trace after analysis;
- orange spatial-contamination markers;
- yellow detected-feature markers.

Trace coordinates are stored in source-image pixel coordinates, not screen coordinates, so zoom/pan do not alter the scientific geometry.

## 2-D extraction model

The analyser intentionally keeps the two-dimensional image model until after contamination assessment.

For each sample along the approximate line it:

1. samples the cross-dispersion intensity profile within the user-defined search ribbon;
2. estimates local background from outer sidebands;
3. calculates a background-subtracted weighted centroid;
4. constrains abrupt centroid jumps;
5. applies robust rolling median and moving-average smoothing;
6. produces the optimised spatial trace.

The extraction stage then builds a robust median target-star cross-dispersion template from many columns of the spectrum.

At each spectral position it compares the observed spatial profile with that template. Excess positive residual, centroid displacement and abnormal width contribute to a `contamination_probability` and `contamination_fraction`.

For modest contamination the target amplitude is estimated from the uncontaminated/template-consistent part of the spatial profile. Severely contaminated samples are marked `valid=false`; they are not silently represented as trustworthy target measurements.

This approach is designed for the user's stated failure mode: an unrelated line-of-sight star or other point source crossing the target spectrum at only a narrow set of wavelength positions.

## Intensity semantics

The exported signal is **relative detector/image intensity**.

JPEG/PNG/WebP pixel values must not be described as calibrated photon counts. Compression, gamma/tone curves, demosaicing, white balance and other camera processing can alter proportionality between incident photons and stored pixel values.

A future FITS/raw-linear path can support stronger photometric semantics. The v0.1 interface therefore labels its amplitude generically as signal/intensity and records this limitation in `spectrum_intensity_semantics` and metadata JSON.

## Background and contamination outputs

Every row of the spectrum CSV retains:

- raw aperture signal;
- estimated background signal;
- contamination-corrected target signal;
- fitted continuum;
- continuum residual;
- local noise estimate;
- local S/N;
- contamination fraction;
- contamination probability;
- validity flag.

Downstream R analysis can therefore choose whether to exclude, down-weight or model contaminated points rather than receiving only a cosmetically cleaned curve.

## Wavelength calibration

A run may use a reference created by `astronomy.spectrum.reference.create`.

The stored reference contains the user's own pixel-to-wavelength polynomial, calibration anchors, source image dimensions and calibration RMS. The target run applies the stored solution after accounting for image-dimension scaling and the per-observation `registration_offset_px`.

If the target/reference aspect ratio differs materially, MethodMesh reduces calibration confidence and exposes a warning rather than silently treating the reference as exact.

A blank `reference_id` is valid. The spectrum then remains in distance/pixel coordinates.

## Feature detection

Feature detection is performed on the continuum-subtracted spectrum.

- continuum: rolling robust median;
- local spectral noise: rolling MAD × 1.4826, combined conservatively with extraction-sideband noise;
- candidate type: local emission maxima and/or absorption minima;
- threshold: configurable local sigma threshold;
- stability: candidate persistence across `threshold - 0.5σ`, `threshold`, and `threshold + 0.5σ`;
- confidence: weighted combination of S/N, prominence, multi-threshold stability and low contamination.

`confidence` is **not** a literal ROC probability and is not an elemental-identification probability. It is a bounded feature-stability/evidence score.

No automatic atomic/molecular identification is performed in v0.1.

## Settings / runtime inputs

| Key | Type | Default | Meaning |
|---|---|---:|---|
| `source_image_uri` | text | blank | Optional caller-supplied image URI. Blank opens the native picker. |
| `reference_id` | text | blank | Saved wavelength reference; blank means pixel coordinates. |
| `registration_offset_px` | float | 0 | Per-observation shift applied to the saved reference solution. |
| `ribbon_half_width_px` | int | 28 | Half-width of trace search ribbon. |
| `aperture_half_width_px` | int | 5 | Half-width of central extraction aperture. |
| `background_gap_px` | int | 4 | Gap before background sidebands. |
| `continuum_window` | int | 51 | Robust continuum window in samples. |
| `detection_sigma` | float | 3.5 | Feature significance threshold. |
| `detection_mode` | choice | `both` | `both`, `emission`, or `absorption`. |

Preset-fixed settings are not presented as editable runtime configuration. Operational image manipulation and trace placement remain part of the interactive measurement.

## Canonical outputs

### Primary beef

| Field | Normally shown | Description |
|---|---:|---|
| `spectrum_annotated_image_uri` | yes | Marked-up source image with user trace, optimised trace, contamination markers and detected feature markers. |
| `spectrum_data_uri` | yes | Analysis-ready CSV containing one row per spectral sample. |
| `spectrum_features_uri` | yes | CSV containing one row per detected feature. |
| `spectrum_features_text` | yes | Human-readable detected-feature list. |
| `spectrum_feature_count` | yes | Number of detected features. |

### Contractually available detail

| Field | Description |
|---|---|
| `spectrum_source_image_uri` | Conditional source attachment. Populated only when MethodMesh acquired the source image rather than receiving it from the caller. |
| `spectrum_source_image_sha256` | SHA-256 of the conditional returned source attachment. |
| `spectrum_metadata_uri` | Domain metadata JSON artefact for the analysis. |
| `spectrum_annotated_image_sha256` | SHA-256 of the annotated PNG bytes. |
| `spectrum_data_sha256` | SHA-256 of the spectrum CSV bytes. |
| `spectrum_features_sha256` | SHA-256 of the feature CSV bytes. |
| `spectrum_features_json` | Structured detected-feature array. |
| `spectrum_reference_id` | Saved reference ID used for calibration, if any. |
| `spectrum_reference_name` | Human name of reference used. |
| `spectrum_calibration_rms_nm` | Stored reference calibration RMS. |
| `spectrum_calibration_confidence` | Target/reference geometry + RMS confidence score. |
| `spectrum_calibration_warning` | Geometry/rescaling warning if applicable. |
| `spectrum_wavelength_min_nm` / `spectrum_wavelength_max_nm` | Calibrated wavelength range; blank if uncalibrated. |
| `spectrum_trace_quality` | Bounded quality score for trace geometry/signal support. |
| `spectrum_trace_mean_correction_px` | Mean distance between user estimate and refined trace. |
| `spectrum_mean_snr` | Mean local residual S/N diagnostic. |
| `spectrum_contaminated_fraction` | Fraction of spectral samples with contamination probability ≥ 0.5. |
| `spectrum_source_width_px` / `spectrum_source_height_px` | Decoded analysis dimensions. |
| `spectrum_intensity_semantics` | Explicit relative-intensity caveat. |
| `spectrum_metadata_json` | Module-owned structured metadata. |
| `spectrum_status` | `succeeded` / `failed`. |
| `spectrum_error` | Failure diagnostic. |

Shared transport adds `methodmesh_full_json` when FULL output is requested.

## CSV schema

`spectrum_data_uri` contains:

```text
index,distance_px,trace_x_px,trace_y_px,wavelength_nm,
raw_signal,background_signal,corrected_signal,continuum,residual,
local_noise,local_snr,contamination_fraction,contamination_probability,
valid,is_feature,feature_id
```

`spectrum_features_uri` contains:

```text
feature_id,index,distance_px,wavelength_nm,type,signal,continuum,
amplitude,prominence,fwhm_px,fwhm_nm,snr,stability,
contamination_probability,confidence
```

Both are ordinary UTF-8 CSVs designed for direct import into R/Python.

## ODK Integration Card

### Method

`astronomy.spectrum.analyse`

### Canonical call

The supplied showcase intentionally asks MethodMesh to acquire the source file interactively:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='astronomy.spectrum.analyse',
  input_payload_mode='FULL',
  return_mode='flat'
)
```

A user-authored form may instead supply any declared setting through the normal `input_<key>` mapping.

### Return semantics

The showcase captures:

- `methodmesh_status`;
- `spectrum_status`;
- `spectrum_source_image_uri` as an image attachment because MethodMesh acquires it in this showcase;
- `spectrum_annotated_image_uri` as an image attachment;
- `spectrum_data_uri` as a file attachment;
- `spectrum_features_uri` as a file attachment;
- `spectrum_metadata_uri` as a file attachment;
- feature/calibration/quality scalar returns;
- `methodmesh_full_json`.

If ODK supplied the source image itself, `spectrum_source_image_uri` remains blank so MethodMesh does not return a gratuitous duplicate.

### Workbook

`docs/example_odk_showcase_astronomy_spectrum_analyse.xlsx`

The workbook contains exactly one MethodMesh invocation, uses canonical unprefixed return fields and does not use `methodmesh_return_namespace`.

## Persistence

Analysis runs are transient by default.

Generated source-copy/annotated/CSV/JSON files live in MethodMesh cache as transport sources. Explicit Save/Export persists copies to Downloads. ODK receives the applicable attachments through the shared transport layer.

The analysis capability does not silently create its own results database.

## Offline / privacy

Fully offline. No astronomical image, pixel data, spectrum, reference name or derived feature is sent to a network service.

## Dependencies

Uses Android/Jetpack components already present in MethodMesh plus Kotlin/Java standard APIs:

- Jetpack Compose / Material 3;
- Android raster bitmap APIs;
- Android Storage Access Framework;
- existing MethodMesh `FileProvider`, `Digests`, canonical runtime and output/export infrastructure.

No new Maven library is introduced by v0.1.

## v0.1 limitations

- Raster image import only; FITS/raw-linear import is future work.
- Calibration reuse assumes substantially stable camera/grating geometry and a repeatable trace origin; `registration_offset_px` handles simple longitudinal shifts, not arbitrary affine/distortion changes.
- Spatial contaminant correction is a robust template model, not full multi-source PSF deblending.
- No atmospheric extinction correction, instrumental response correction, heliocentric/barycentric velocity correction, redshift fitting or line identification.
- Feature confidence is an internal evidence/stability score rather than a calibrated posterior probability.

See `VALIDATION.md` for current validation status.
