package com.example.methodmesh.modules.capturenotes

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityCompletionMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

private fun configured(context: CapabilityScreenContext, key: String, fallback: String = ""): String =
    context.action.settings[key] ?: context.action.settings["input_$key"] ?: fallback

private fun runCaptureMethod(
    method: As100Method,
    context: CapabilityScreenContext,
    settings: Map<String, String>
): ExecutionResult = method.execute(
    request = method.request(
        action = method.id,
        context = context.request.invocationContext.asMap(method.id) + context.action.settings + settings
    ),
    transport = context.request.source
)

private fun preview(result: ExecutionResult?): Map<String, Any?> =
    result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty()

object ChecklistCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ChecklistMethod.ID
    override val title = "Checklist"
    override val description = "Create and work with multiple persistent checklists."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var refresh by remember { mutableIntStateOf(0) }
        var selectedId by rememberSaveable { mutableStateOf(configured(context, "checklist_id")) }
        var titleText by rememberSaveable { mutableStateOf(configured(context, "title", "Checklist")) }
        var itemText by rememberSaveable { mutableStateOf(configured(context, "item_text", configured(context, "items"))) }
        val incomingOperation = configured(context, "operation", "open")
        val automaticExecution = context.completionMode == CapabilityCompletionMode.AutomaticReturn

        LaunchedEffect(automaticExecution, incomingOperation, context.action.settings) {
            if (automaticExecution) {
                val execution = runCaptureMethod(As100ChecklistMethod, context, context.action.settings)
                result = execution
                onConfirmed(execution)
            }
        }
        if (automaticExecution) return

        val checklists = remember(refresh) { CaptureNotesStore.all(CaptureArtifactType.CHECKLIST) }
        val selected = checklists.firstOrNull { it.id == selectedId } ?: checklists.firstOrNull()
        if (selectedId.isBlank() && selected != null) selectedId = selected.id

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = preview(result),
            onBack = onBack,
            onRetry = { result = null },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text("Your checklists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (checklists.isEmpty()) Text("No saved checklists yet.")
            checklists.forEach { artifact ->
                OutlinedButton(onClick = { selectedId = artifact.id }, modifier = Modifier.fillMaxWidth()) {
                    Text("${if (artifact.id == selectedId) "✓ " else ""}${artifact.title} · ${artifact.completedCount}/${artifact.items.size}")
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(titleText, { titleText = it }, label = { Text("New checklist title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(itemText, { itemText = it }, label = { Text("Item / one item per line") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    result = runCaptureMethod(As100ChecklistMethod, context, mapOf("operation" to "create", "title" to titleText, "items" to itemText))
                    selectedId = preview(result)["checklist_id"]?.toString().orEmpty()
                    itemText = ""
                    refresh++
                }, modifier = Modifier.weight(1f)) { Text("New") }
                Button(onClick = {
                    if (selectedId.isNotBlank() && itemText.isNotBlank()) {
                        result = runCaptureMethod(As100ChecklistMethod, context, mapOf("operation" to "add_items", "checklist_id" to selectedId, "item_text" to itemText))
                        itemText = ""
                        refresh++
                    }
                }, enabled = selectedId.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Add") }
            }
            selected?.let { artifact ->
                Spacer(Modifier.height(12.dp))
                Text(artifact.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("ID ${artifact.id} · revision ${artifact.revision}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                artifact.items.forEach { item ->
                    OutlinedButton(
                        onClick = {
                            result = runCaptureMethod(As100ChecklistMethod, context, mapOf("operation" to "toggle_item", "checklist_id" to artifact.id, "item_id" to item.id))
                            refresh++
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("${if (item.completed) "☑" else "☐"} ${item.text}") }
                }
                Button(onClick = {
                    result = runCaptureMethod(As100ChecklistMethod, context, mapOf("operation" to "read", "checklist_id" to artifact.id))
                }, modifier = Modifier.fillMaxWidth()) { Text("Commit current checklist") }
            }
        }
    }
}

object TextNoteCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextNoteMethod.ID
    override val title = "Text notes"
    override val description = "Create and edit multiple persistent plain-text notes/files."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var refresh by remember { mutableIntStateOf(0) }
        var selectedId by rememberSaveable { mutableStateOf(configured(context, "text_note_id")) }
        var titleText by rememberSaveable { mutableStateOf(configured(context, "title", "Text note")) }
        var body by rememberSaveable { mutableStateOf(configured(context, "text")) }
        val incomingOperation = configured(context, "operation", "open")
        val automaticExecution = context.completionMode == CapabilityCompletionMode.AutomaticReturn
        LaunchedEffect(automaticExecution, incomingOperation, context.action.settings) {
            if (automaticExecution) {
                val execution = runCaptureMethod(As100TextNoteMethod, context, context.action.settings)
                result = execution
                onConfirmed(execution)
            }
        }
        if (automaticExecution) return

        val notes = remember(refresh) { CaptureNotesStore.all(CaptureArtifactType.TEXT) }
        val selected = if (incomingOperation == "create" && selectedId.isBlank()) null
            else notes.firstOrNull { it.id == selectedId } ?: notes.firstOrNull()
        LaunchedEffect(selected?.id) {
            if (selected != null && (selectedId.isBlank() || selected.id == selectedId)) {
                selectedId = selected.id
                titleText = selected.title
                body = selected.body
            }
        }
        CapabilityScreenScaffold(title, capabilityId, context, context.stepNumber > 1, result, preview(result), onBack, { result = null }, { result?.let(onConfirmed) }, onCancel) {
            Text("Text files / notes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            notes.forEach { note ->
                OutlinedButton(onClick = { selectedId = note.id; titleText = note.title; body = note.body }, modifier = Modifier.fillMaxWidth()) {
                    Text("${if (note.id == selectedId) "✓ " else ""}${note.title}")
                }
            }
            OutlinedTextField(titleText, { titleText = it }, label = { Text("Title / file name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(body, { body = it }, label = { Text("Text") }, modifier = Modifier.fillMaxWidth(), minLines = 6)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    result = runCaptureMethod(As100TextNoteMethod, context, mapOf("operation" to "create", "title" to titleText, "text" to body, "file_name" to titleText))
                    selectedId = preview(result)["text_note_id"]?.toString().orEmpty(); refresh++
                }, modifier = Modifier.weight(1f)) { Text("Save new") }
                Button(onClick = {
                    if (selectedId.isNotBlank()) {
                        result = runCaptureMethod(As100TextNoteMethod, context, mapOf("operation" to "replace", "text_note_id" to selectedId, "text" to body))
                        if (titleText.isNotBlank()) runCaptureMethod(As100TextNoteMethod, context, mapOf("operation" to "rename", "text_note_id" to selectedId, "title" to titleText))
                        refresh++
                    }
                }, enabled = selectedId.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Update") }
            }
            if (selectedId.isNotBlank()) {
                Button(onClick = { result = runCaptureMethod(As100TextNoteMethod, context, mapOf("operation" to "read", "text_note_id" to selectedId)) }, modifier = Modifier.fillMaxWidth()) { Text("Commit current note") }
            }
        }
    }
}

object PostItCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PostItMethod.ID
    override val title = "Post-it notes"
    override val description = "Short persistent notes designed for pinning and widgets."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var refresh by remember { mutableIntStateOf(0) }
        var selectedId by rememberSaveable { mutableStateOf(configured(context, "postit_id")) }
        var titleText by rememberSaveable { mutableStateOf(configured(context, "title", "Post-it")) }
        var body by rememberSaveable { mutableStateOf(configured(context, "text")) }
        val incomingOperation = configured(context, "operation", "open")
        val automaticExecution = context.completionMode == CapabilityCompletionMode.AutomaticReturn
        LaunchedEffect(automaticExecution, incomingOperation, context.action.settings) {
            if (automaticExecution) {
                val execution = runCaptureMethod(As100PostItMethod, context, context.action.settings)
                result = execution
                onConfirmed(execution)
            }
        }
        if (automaticExecution) return
        val notes = remember(refresh) { CaptureNotesStore.all(CaptureArtifactType.POST_IT) }
        val selected = notes.firstOrNull { it.id == selectedId }
        CapabilityScreenScaffold(title, capabilityId, context, context.stepNumber > 1, result, preview(result), onBack, { result = null }, { result?.let(onConfirmed) }, onCancel) {
            notes.forEach { note ->
                OutlinedButton(onClick = { selectedId = note.id; titleText = note.title; body = note.body }, modifier = Modifier.fillMaxWidth()) { Text("${if (note.id == selectedId) "✓ " else ""}${note.title}") }
            }
            OutlinedTextField(titleText, { titleText = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(body, { body = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = {
                    result = runCaptureMethod(As100PostItMethod, context, mapOf("operation" to "create", "title" to titleText, "text" to body, "pinned" to "true"))
                    selectedId = preview(result)["postit_id"]?.toString().orEmpty(); refresh++
                }, modifier = Modifier.weight(1f)) { Text("New") }
                Button(onClick = {
                    if (selectedId.isNotBlank()) {
                        result = runCaptureMethod(As100PostItMethod, context, mapOf("operation" to "replace", "postit_id" to selectedId, "text" to body)); refresh++
                    }
                }, enabled = selectedId.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Update") }
            }
            selected?.let { Text("Revision ${it.revision}", style = MaterialTheme.typography.labelSmall) }
        }
    }
}

object JsonReaderCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100JsonReaderMethod.ID
    override val title = "Pretty JSON"
    override val description = "Validate and inspect formatted JSON."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var raw by rememberSaveable { mutableStateOf(configured(context, "json", configured(context, "text"))) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        LaunchedEffect(context.completionMode, raw) {
            if (context.completionMode == CapabilityCompletionMode.AutomaticReturn && raw.isNotBlank()) {
                val execution = runCaptureMethod(As100JsonReaderMethod, context, mapOf("json" to raw))
                result = execution
                onConfirmed(execution)
            }
        }
        CapabilityScreenScaffold(title, capabilityId, context, context.stepNumber > 1, result, preview(result), onBack, { result = null }, { result?.let(onConfirmed) }, onCancel) {
            OutlinedTextField(raw, { raw = it }, label = { Text("JSON") }, modifier = Modifier.fillMaxWidth(), minLines = 8)
            Button(onClick = { result = runCaptureMethod(As100JsonReaderMethod, context, mapOf("json" to raw)) }, modifier = Modifier.fillMaxWidth()) { Text("Pretty-print") }
            preview(result)["json_pretty"]?.toString()?.takeIf { it.isNotBlank() }?.let { pretty ->
                Card(modifier = Modifier.fillMaxWidth()) { Text(pretty, modifier = Modifier.padding(12.dp), fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

object NotesLibraryCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100NotesLibraryMethod.ID
    override val title = "Notes & Capture library"
    override val description = "Search all persistent notes, checklists and captures."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var query by rememberSaveable { mutableStateOf(configured(context, "query")) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val type = configured(context, "type")
        val automaticExecution = context.completionMode == CapabilityCompletionMode.AutomaticReturn
        LaunchedEffect(automaticExecution, query, type) {
            if (automaticExecution) {
                val execution = runCaptureMethod(As100NotesLibraryMethod, context, mapOf("query" to query, "type" to type))
                result = execution
                onConfirmed(execution)
            }
        }
        if (automaticExecution) return
        val matches = remember(query, result) { CaptureNotesStore.search(query) }
        CapabilityScreenScaffold(title, capabilityId, context, context.stepNumber > 1, result, preview(result), onBack, { result = null }, { result?.let(onConfirmed) }, onCancel) {
            OutlinedTextField(query, { query = it }, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { result = runCaptureMethod(As100NotesLibraryMethod, context, mapOf("query" to query)) }, modifier = Modifier.fillMaxWidth()) { Text("Search / commit") }
            matches.forEach { artifact ->
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(artifact.title, fontWeight = FontWeight.Bold)
                        Text("${artifact.type.wire} · r${artifact.revision}", style = MaterialTheme.typography.labelSmall)
                        val snippet = if (artifact.type == CaptureArtifactType.CHECKLIST) artifact.items.joinToString(" · ") { it.text } else artifact.body
                        if (snippet.isNotBlank()) Text(snippet.take(180))
                    }
                }
            }
        }
    }
}
