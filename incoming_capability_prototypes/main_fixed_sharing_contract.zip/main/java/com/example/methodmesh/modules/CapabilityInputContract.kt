package com.example.methodmesh.modules

import android.content.Context

/** Semantic kinds used by the generic Android share/import router. */
enum class CapabilityInputValueType {
    TEXT,
    JSON,
    FILE,
    IMAGE,
    AUDIO
}

enum class CapabilityInputProbe {
    NONE,
    JSON
}

data class SharedCapabilityInput(
    val mimeType: String,
    val text: String = "",
    val subject: String = "",
    val uriStrings: List<String> = emptyList(),
    val fileNames: List<String> = emptyList(),
    val sourcePackage: String = ""
) {
    val extensions: Set<String>
        get() = fileNames.mapNotNull { name ->
            name.substringAfterLast('.', missingDelimiterValue = "")
                .trim()
                .lowercase()
                .takeIf { it.isNotBlank() }
        }.toSet()
}

data class CapabilityInputContract(
    val id: String,
    val capabilityId: String,
    val title: String,
    val acceptedMimeTypes: Set<String> = emptySet(),
    val acceptedExtensions: Set<String> = emptySet(),
    val valueTypes: Set<CapabilityInputValueType> = emptySet(),
    val probe: CapabilityInputProbe = CapabilityInputProbe.NONE,
    val priority: Int = 0
)

data class CapabilityInputTarget(
    val id: String,
    val title: String,
    val subtitle: String = "",
    val operation: String,
    val objectId: String = ""
)

data class CapabilityInputInvocation(
    val capabilityId: String,
    val settings: Map<String, String>
)

/**
 * Optional module-owned extension of the generic share/import contract.
 *
 * The shell only matches payload metadata and asks the owning module for target
 * objects and a canonical capability invocation. It never contains module IDs,
 * object schemas, or mutation rules.
 */
interface CapabilityInputHandler {
    fun inputContracts(): List<CapabilityInputContract> = emptyList()

    fun inputTargets(
        context: Context,
        contract: CapabilityInputContract,
        input: SharedCapabilityInput
    ): List<CapabilityInputTarget> = emptyList()

    fun inputInvocation(
        context: Context,
        contract: CapabilityInputContract,
        target: CapabilityInputTarget,
        input: SharedCapabilityInput
    ): CapabilityInputInvocation? = null
}

internal fun CapabilityInputContract.matches(input: SharedCapabilityInput): Boolean {
    val mime = input.mimeType.lowercase().trim()
    val mimeMatches = acceptedMimeTypes.isEmpty() || acceptedMimeTypes.any { pattern ->
        when {
            pattern == "*/*" -> true
            pattern.endsWith("/*") -> mime.startsWith(pattern.substringBefore('/').lowercase() + "/")
            else -> pattern.equals(mime, ignoreCase = true)
        }
    }
    val extensionMatches = acceptedExtensions.isEmpty() || input.extensions.any { extension -> extension in acceptedExtensions.map { it.lowercase() } }
    val probeMatches = when (probe) {
        CapabilityInputProbe.NONE -> true
        CapabilityInputProbe.JSON -> runCatching {
            val value = input.text.trim()
            value.isNotBlank() && (value.startsWith("{") || value.startsWith("[")) &&
                if (value.startsWith("{")) org.json.JSONObject(value) != null else org.json.JSONArray(value) != null
        }.getOrDefault(false)
    }
    return (mimeMatches || extensionMatches) && probeMatches
}
