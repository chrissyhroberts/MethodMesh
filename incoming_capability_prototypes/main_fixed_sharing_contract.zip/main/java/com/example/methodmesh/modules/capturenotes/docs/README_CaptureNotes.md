# MethodMesh Notes & Capture

`capturenotes` provides persistent, addressable everyday objects that remain callable through the normal MethodMesh capability contract.

## Public capabilities

- `notes.checklist` — create/read/mutate multiple checklists. Stable checklist IDs and item IDs permit ODK, presets, protocols, schedules, native UI and widgets to address the same object.
- `notes.text` — create/read/append/replace/rename/delete multiple plain-text notes/files.
- `notes.json.read` — validate and pretty-print JSON locally.
- `notes.audio` — record natively, import and persist audio-note attachments through the canonical capability contract.
- `notes.postit` — create/read/append/replace/pin/unpin multiple short persistent notes.
- `notes.sketch` — draw natively, import and persist sketch/image attachments through the canonical capability contract.
- `notes.library.search` — enumerate/search persistent Notes & Capture objects.

## Persistent object contract

Persistent objects carry a stable object ID and monotonically increasing `revision`. Checklist items also carry stable item IDs. Mutations may supply `expected_revision`; if it does not match, the mutation fails instead of silently overwriting newer state.

A checklist is therefore not owned by a particular surface. For example:

1. ODK calls `notes.checklist` with `operation=create` and receives `checklist_id`.
2. A home-screen capability widget is configured against that `checklist_id`.
3. A preset calls `operation=add_item` against the same ID.
4. A protocol or schedule calls `operation=set_item_state` for a stable `item_id`.
5. The widget refreshes from the same store and immediately reflects the mutation.

## Checklist operations

`create`, `read`, `add_item`, `add_items`, `set_item_state`, `toggle_item`, `update_item`, `remove_item`, `rename`, `clear_completed`, `delete`.

Key inputs: `checklist_id`, `title`, `items`, `item_id`, `item_text`, `completed`, `expected_revision`.

Key outputs: `checklist_id`, `checklist_revision`, `checklist_title`, `checklist_items_json`, `checklist_total_items`, `checklist_completed_items`, `checklist_remaining_items`, `affected_item_id`, plus the shared Notes fields and `methodmesh_full_json` on external closeout.

## Text-note operations

`create`, `read`, `append`, `replace`, `rename`, `delete`.

Key inputs: `text_note_id`, `title`, `text`, `file_name`, `mime_type`, `separator`, `expected_revision`.

## Android Share / import

The exported `ShareRouterActivity` accepts Android `SEND`, `SEND_MULTIPLE` and `VIEW` for text, JSON, images and audio. `VIEW` covers “Open with MethodMesh” for files while `SEND` covers WhatsApp/browser/file-manager sharing. The generic router asks discovered modules for compatible input contracts and target objects; it contains no checklist/note IDs itself.

For a WhatsApp text message, Notes & Capture can offer destinations such as:

- New checklist
- each existing checklist — add the message as an item
- New text note
- each existing text note/file — append the message
- New post-it
- each existing post-it — append the message
- Pretty JSON reader when the text parses as JSON

Selecting an existing destination executes the same canonical method used by ODK/presets/protocols/schedules.

## Widgets

The generic widget system now permits module-owned `CAPABILITY` targets. Notes & Capture exposes each checklist, pinned post-it and text note as a separately bindable widget target. Widget snapshots are read from the canonical store.

Checklist widgets expose up to three current items as direct toggle actions. A mutation from ODK/preset/protocol/schedule calls the same store and triggers `MethodMeshWidgetProvider.updateAll`, so the widget does not maintain a copy of checklist state.

## Persistence semantics

External callers mutate persistent state only when they explicitly invoke a persistent operation. `notes.json.read` is non-persistent. Attachments shared into audio/sketch are copied into MethodMesh app storage rather than retaining a short-lived source URI grant. Native Audio Note records AAC/M4A through the microphone; native Sketch Note captures touch strokes and commits a PNG through the same canonical methods used by external callers.
