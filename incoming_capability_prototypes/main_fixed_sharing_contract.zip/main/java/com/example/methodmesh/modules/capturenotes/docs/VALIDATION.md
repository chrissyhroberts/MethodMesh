# Validation

The source-only `main/` archive does not contain the Gradle wrapper/project, so full Android compilation cannot be performed from this package alone.

Required integration checks in the complete project:

1. Discover `CaptureNotesModule` and verify all seven public method IDs are unique.
2. Build the app and run architecture/module-contract tests.
3. Validate each XLSForm through the repository ODK template generator and, where available, pyxform/ODK Validate.
4. Android share: share WhatsApp text to an existing checklist and existing text note; verify canonical revision increments.
5. ODK: create checklist, add an item by returned `checklist_id`, then check that item using its `item_id`.
6. Widget: pin the checklist as a capability widget; repeat the ODK/preset mutation and verify the widget refreshes without reconfiguration.
7. Concurrency: submit a stale `expected_revision` and verify the mutation fails rather than overwriting current state.
