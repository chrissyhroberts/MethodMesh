package com.example.methodmesh.modules.capturenotes

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

enum class CaptureArtifactType(val wire: String) {
    CHECKLIST("checklist"),
    TEXT("text"),
    POST_IT("postit"),
    AUDIO("audio"),
    SKETCH("sketch");

    companion object {
        fun fromWire(value: String): CaptureArtifactType = entries.firstOrNull { it.wire == value } ?: TEXT
    }
}

data class ChecklistItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val completed: Boolean = false,
    val createdAtIso: String = Instant.now().toString(),
    val updatedAtIso: String = createdAtIso
) {
    fun toJson() = JSONObject()
        .put("id", id)
        .put("text", text)
        .put("completed", completed)
        .put("created_at", createdAtIso)
        .put("updated_at", updatedAtIso)

    companion object {
        fun fromJson(root: JSONObject) = ChecklistItem(
            id = root.optString("id").ifBlank { UUID.randomUUID().toString() },
            text = root.optString("text"),
            completed = root.optBoolean("completed", false),
            createdAtIso = root.optString("created_at").ifBlank { Instant.now().toString() },
            updatedAtIso = root.optString("updated_at").ifBlank { Instant.now().toString() }
        )
    }
}

data class CaptureArtifact(
    val id: String = UUID.randomUUID().toString(),
    val type: CaptureArtifactType,
    val title: String,
    val body: String = "",
    val fileName: String = "",
    val mimeType: String = "text/plain",
    val items: List<ChecklistItem> = emptyList(),
    val pinned: Boolean = false,
    val source: String = "native",
    val revision: Long = 1L,
    val createdAtIso: String = Instant.now().toString(),
    val updatedAtIso: String = createdAtIso
) {
    val completedCount: Int get() = items.count { it.completed }
    val remainingCount: Int get() = items.size - completedCount

    fun toJson() = JSONObject()
        .put("id", id)
        .put("type", type.wire)
        .put("title", title)
        .put("body", body)
        .put("file_name", fileName)
        .put("mime_type", mimeType)
        .put("items", JSONArray().apply { items.forEach { put(it.toJson()) } })
        .put("pinned", pinned)
        .put("source", source)
        .put("revision", revision)
        .put("created_at", createdAtIso)
        .put("updated_at", updatedAtIso)

    companion object {
        fun fromJson(root: JSONObject): CaptureArtifact {
            val itemArray = root.optJSONArray("items") ?: JSONArray()
            val parsedItems = buildList {
                for (index in 0 until itemArray.length()) {
                    itemArray.optJSONObject(index)?.let { add(ChecklistItem.fromJson(it)) }
                }
            }
            return CaptureArtifact(
                id = root.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = CaptureArtifactType.fromWire(root.optString("type")),
                title = root.optString("title"),
                body = root.optString("body"),
                fileName = root.optString("file_name"),
                mimeType = root.optString("mime_type").ifBlank { "text/plain" },
                items = parsedItems,
                pinned = root.optBoolean("pinned", false),
                source = root.optString("source").ifBlank { "native" },
                revision = root.optLong("revision", 1L),
                createdAtIso = root.optString("created_at").ifBlank { Instant.now().toString() },
                updatedAtIso = root.optString("updated_at").ifBlank { Instant.now().toString() }
            )
        }
    }
}
