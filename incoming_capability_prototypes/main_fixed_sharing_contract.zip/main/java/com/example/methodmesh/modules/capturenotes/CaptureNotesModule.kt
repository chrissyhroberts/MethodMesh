package com.example.methodmesh.modules.capturenotes

import android.content.Context
import com.example.methodmesh.modules.CapabilityInputContract
import com.example.methodmesh.modules.CapabilityInputInvocation
import com.example.methodmesh.modules.CapabilityInputProbe
import com.example.methodmesh.modules.CapabilityInputTarget
import com.example.methodmesh.modules.CapabilityInputValueType
import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.ModuleExample
import com.example.methodmesh.modules.ModuleWidgetAction
import com.example.methodmesh.modules.ModuleWidgetInvocation
import com.example.methodmesh.modules.ModuleWidgetSnapshot
import com.example.methodmesh.modules.ModuleWidgetTarget
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.modules.SharedCapabilityInput
import com.example.methodmesh.settings.MethodSetting

object CaptureNotesModule : MethodMeshModule {
    override val moduleId = "capturenotes"
    override val displayName = "Notes & Capture"
    override val summary = "Persistent checklists, text notes, post-its, JSON inspection, audio notes and sketch notes with share-in and widgets."
    override val iconKey = "text"

    override fun initialise(context: Context) {
        CaptureNotesStore.initialise(context)
    }

    override fun as100Methods() = listOf(
        As100ChecklistMethod,
        As100TextNoteMethod,
        As100JsonReaderMethod,
        As100AudioNoteMethod,
        As100PostItMethod,
        As100SketchNoteMethod,
        As100NotesLibraryMethod
    )

    override fun rilBindings() = listOf(
        RilBinding("manage checklist", As100ChecklistMethod.ID, "Create, read or mutate an addressable checklist"),
        RilBinding("edit text note", As100TextNoteMethod.ID, "Create, read or mutate a plain-text note/file"),
        RilBinding("read json", As100JsonReaderMethod.ID, "Validate and pretty-print JSON"),
        RilBinding("capture audio note", As100AudioNoteMethod.ID, "Create or import an audio note"),
        RilBinding("manage post-it", As100PostItMethod.ID, "Create or mutate a persistent post-it"),
        RilBinding("capture sketch note", As100SketchNoteMethod.ID, "Create or import a sketch note"),
        RilBinding("search notes library", As100NotesLibraryMethod.ID, "Search persistent Notes & Capture objects")
    )

    override fun capabilityScreens() = listOf(
        ChecklistCapabilityScreen,
        TextNoteCapabilityScreen,
        JsonReaderCapabilityScreen,
        AudioNoteCapabilityScreen,
        PostItCapabilityScreen,
        SketchNoteCapabilityScreen,
        NotesLibraryCapabilityScreen
    )

    override fun capabilitySettings(): Map<String, List<MethodSetting>> = mapOf(
        As100ChecklistMethod.ID to listOf(
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "create", choices = listOf("create", "read", "add_item", "add_items", "set_item_state", "toggle_item", "update_item", "remove_item", "rename", "clear_completed", "delete")),
            MethodSetting.TextSetting("checklist_id", "Checklist ID", description = "Stable object ID returned when a checklist is created.", defaultValue = ""),
            MethodSetting.TextSetting("title", "Title", defaultValue = "Checklist"),
            MethodSetting.TextSetting("items", "Items", description = "One item per line.", defaultValue = ""),
            MethodSetting.TextSetting("item_id", "Item ID", defaultValue = ""),
            MethodSetting.TextSetting("item_text", "Item text", defaultValue = ""),
            MethodSetting.BooleanSetting("completed", "Completed", defaultValue = true),
            MethodSetting.TextSetting("expected_revision", "Expected revision", description = "Optional optimistic-concurrency guard.", defaultValue = "")
        ),
        As100TextNoteMethod.ID to listOf(
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "create", choices = listOf("create", "read", "append", "replace", "rename", "delete")),
            MethodSetting.TextSetting("text_note_id", "Text note ID", defaultValue = ""),
            MethodSetting.TextSetting("title", "Title", defaultValue = "Text note"),
            MethodSetting.TextSetting("text", "Text", defaultValue = ""),
            MethodSetting.TextSetting("file_name", "File name", defaultValue = ""),
            MethodSetting.TextSetting("mime_type", "MIME type", defaultValue = "text/plain"),
            MethodSetting.TextSetting("separator", "Append separator", defaultValue = "\\n"),
            MethodSetting.TextSetting("expected_revision", "Expected revision", defaultValue = "")
        ),
        As100PostItMethod.ID to listOf(
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "create", choices = listOf("create", "read", "append", "replace", "pin", "unpin", "rename", "delete")),
            MethodSetting.TextSetting("postit_id", "Post-it ID", defaultValue = ""),
            MethodSetting.TextSetting("title", "Title", defaultValue = "Post-it"),
            MethodSetting.TextSetting("text", "Text", defaultValue = ""),
            MethodSetting.BooleanSetting("pinned", "Pinned", defaultValue = true),
            MethodSetting.TextSetting("expected_revision", "Expected revision", defaultValue = "")
        ),
        As100JsonReaderMethod.ID to listOf(
            MethodSetting.TextSetting("json", "JSON", defaultValue = "")
        ),
        As100AudioNoteMethod.ID to listOf(
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "create", choices = listOf("create", "import", "read", "delete")),
            MethodSetting.TextSetting("audio_note_id", "Audio note ID", defaultValue = ""),
            MethodSetting.TextSetting("title", "Title", defaultValue = "Audio note"),
            MethodSetting.TextSetting("uri", "Audio URI", defaultValue = ""),
            MethodSetting.TextSetting("file_name", "File name", defaultValue = ""),
            MethodSetting.TextSetting("mime_type", "MIME type", defaultValue = "audio/*")
        ),
        As100SketchNoteMethod.ID to listOf(
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "create", choices = listOf("create", "import", "read", "delete")),
            MethodSetting.TextSetting("sketch_note_id", "Sketch note ID", defaultValue = ""),
            MethodSetting.TextSetting("title", "Title", defaultValue = "Sketch note"),
            MethodSetting.TextSetting("uri", "Image URI", defaultValue = ""),
            MethodSetting.TextSetting("file_name", "File name", defaultValue = ""),
            MethodSetting.TextSetting("mime_type", "MIME type", defaultValue = "image/png")
        ),
        As100NotesLibraryMethod.ID to listOf(
            MethodSetting.TextSetting("query", "Search", defaultValue = ""),
            MethodSetting.ChoiceSetting("type", "Type", defaultValue = "", choices = listOf("", "checklist", "text", "postit", "audio", "sketch"))
        )
    )

    override fun inputContracts() = listOf(
        CapabilityInputContract(
            id = "capturenotes.checklist.text",
            capabilityId = As100ChecklistMethod.ID,
            title = "Checklist",
            acceptedMimeTypes = setOf("text/plain", "text/markdown"),
            acceptedExtensions = setOf("txt", "md"),
            valueTypes = setOf(CapabilityInputValueType.TEXT),
            priority = 80
        ),
        CapabilityInputContract(
            id = "capturenotes.text.text",
            capabilityId = As100TextNoteMethod.ID,
            title = "Text note / file",
            acceptedMimeTypes = setOf("text/plain", "text/markdown", "application/json"),
            acceptedExtensions = setOf("txt", "md", "json", "csv", "log"),
            valueTypes = setOf(CapabilityInputValueType.TEXT, CapabilityInputValueType.FILE),
            priority = 70
        ),
        CapabilityInputContract(
            id = "capturenotes.postit.text",
            capabilityId = As100PostItMethod.ID,
            title = "Post-it",
            acceptedMimeTypes = setOf("text/plain"),
            valueTypes = setOf(CapabilityInputValueType.TEXT),
            priority = 60
        ),
        CapabilityInputContract(
            id = "capturenotes.json.text",
            capabilityId = As100JsonReaderMethod.ID,
            title = "Pretty JSON reader",
            acceptedMimeTypes = setOf("application/json", "text/plain"),
            acceptedExtensions = setOf("json"),
            valueTypes = setOf(CapabilityInputValueType.JSON),
            probe = CapabilityInputProbe.JSON,
            priority = 100
        ),
        CapabilityInputContract(
            id = "capturenotes.audio.import",
            capabilityId = As100AudioNoteMethod.ID,
            title = "Audio note",
            acceptedMimeTypes = setOf("audio/*"),
            valueTypes = setOf(CapabilityInputValueType.AUDIO),
            priority = 90
        ),
        CapabilityInputContract(
            id = "capturenotes.sketch.import",
            capabilityId = As100SketchNoteMethod.ID,
            title = "Sketch note",
            acceptedMimeTypes = setOf("image/*"),
            valueTypes = setOf(CapabilityInputValueType.IMAGE),
            priority = 90
        )
    )

    override fun inputTargets(context: Context, contract: CapabilityInputContract, input: SharedCapabilityInput): List<CapabilityInputTarget> = when (contract.capabilityId) {
        As100ChecklistMethod.ID -> listOf(
            CapabilityInputTarget("new", "New checklist", "Create a checklist from the shared text", "create")
        ) + CaptureNotesStore.all(CaptureArtifactType.CHECKLIST).map { artifact ->
            CapabilityInputTarget("checklist:${artifact.id}", artifact.title, "Add as item · ${artifact.completedCount}/${artifact.items.size} complete", "add_item", artifact.id)
        }
        As100TextNoteMethod.ID -> listOf(
            CapabilityInputTarget("new", "New text note", "Create a new text file/note", "create")
        ) + CaptureNotesStore.all(CaptureArtifactType.TEXT).map { artifact ->
            CapabilityInputTarget("text:${artifact.id}", artifact.title, "Append to ${artifact.fileName.ifBlank { "note" }}", "append", artifact.id)
        }
        As100PostItMethod.ID -> listOf(
            CapabilityInputTarget("new", "New post-it", "Create a pinned note", "create")
        ) + CaptureNotesStore.all(CaptureArtifactType.POST_IT).map { artifact ->
            CapabilityInputTarget("postit:${artifact.id}", artifact.title, "Append to existing post-it", "append", artifact.id)
        }
        As100JsonReaderMethod.ID -> listOf(CapabilityInputTarget("json", "Open in pretty JSON reader", "Inspect without changing the source", "open"))
        As100AudioNoteMethod.ID -> listOf(CapabilityInputTarget("audio", "Save as new audio note", "Copy into MethodMesh Notes & Capture", "import"))
        As100SketchNoteMethod.ID -> listOf(CapabilityInputTarget("sketch", "Save as new sketch note", "Import image into MethodMesh", "import"))
        else -> emptyList()
    }

    override fun inputInvocation(
        context: Context,
        contract: CapabilityInputContract,
        target: CapabilityInputTarget,
        input: SharedCapabilityInput
    ): CapabilityInputInvocation? {
        val title = input.subject.trim().ifBlank { input.fileNames.firstOrNull().orEmpty().substringBeforeLast('.').ifBlank { "Shared capture" } }
        val firstUri = input.uriStrings.firstOrNull().orEmpty()
        val firstName = input.fileNames.firstOrNull().orEmpty()
        return when (contract.capabilityId) {
            As100ChecklistMethod.ID -> CapabilityInputInvocation(
                As100ChecklistMethod.ID,
                buildMap {
                    put("operation", target.operation)
                    put("title", title.ifBlank { "Shared checklist" })
                    put("item_text", input.text)
                    put("items", input.text)
                    if (target.objectId.isNotBlank()) put("checklist_id", target.objectId)
                }
            )
            As100TextNoteMethod.ID -> CapabilityInputInvocation(
                As100TextNoteMethod.ID,
                buildMap {
                    put("operation", target.operation)
                    put("title", title.ifBlank { "Shared text" })
                    put("text", input.text)
                    put("file_name", firstName)
                    put("mime_type", input.mimeType.ifBlank { "text/plain" })
                    if (target.objectId.isNotBlank()) put("text_note_id", target.objectId)
                }
            )
            As100PostItMethod.ID -> CapabilityInputInvocation(
                As100PostItMethod.ID,
                buildMap {
                    put("operation", target.operation)
                    put("title", title.ifBlank { "Shared post-it" })
                    put("text", input.text)
                    if (target.objectId.isNotBlank()) put("postit_id", target.objectId)
                }
            )
            As100JsonReaderMethod.ID -> CapabilityInputInvocation(As100JsonReaderMethod.ID, mapOf("json" to input.text))
            As100AudioNoteMethod.ID -> CapabilityInputInvocation(
                As100AudioNoteMethod.ID,
                mapOf("operation" to "import", "title" to title.ifBlank { "Shared audio" }, "uri" to firstUri, "file_name" to firstName, "mime_type" to input.mimeType)
            )
            As100SketchNoteMethod.ID -> CapabilityInputInvocation(
                As100SketchNoteMethod.ID,
                mapOf("operation" to "import", "title" to title.ifBlank { "Shared image" }, "uri" to firstUri, "file_name" to firstName, "mime_type" to input.mimeType)
            )
            else -> null
        }
    }

    override fun widgetTargets(context: Context): List<ModuleWidgetTarget> = buildList {
        add(ModuleWidgetTarget("capturenotes:quick:text", As100TextNoteMethod.ID, "Quick text note", "Create a new note", "document"))
        add(ModuleWidgetTarget("capturenotes:quick:audio", As100AudioNoteMethod.ID, "Quick audio note", "Tap to record", "audio"))
        add(ModuleWidgetTarget("capturenotes:quick:postit", As100PostItMethod.ID, "Quick post-it", "Create a pinned note", "text"))
        add(ModuleWidgetTarget("capturenotes:library", As100NotesLibraryMethod.ID, "Notes & Capture", "Open the capture library", "document"))
        CaptureNotesStore.all(CaptureArtifactType.CHECKLIST).forEach { artifact ->
            add(ModuleWidgetTarget("capturenotes:checklist:${artifact.id}", As100ChecklistMethod.ID, artifact.title, "${artifact.completedCount}/${artifact.items.size} complete", "checklist", artifact.id))
        }
        CaptureNotesStore.all(CaptureArtifactType.POST_IT).filter { it.pinned }.forEach { artifact ->
            add(ModuleWidgetTarget("capturenotes:postit:${artifact.id}", As100PostItMethod.ID, artifact.title, artifact.body.take(72), "text", artifact.id))
        }
        CaptureNotesStore.all(CaptureArtifactType.TEXT).forEach { artifact ->
            add(ModuleWidgetTarget("capturenotes:text:${artifact.id}", As100TextNoteMethod.ID, artifact.title, artifact.body.lineSequence().firstOrNull().orEmpty().take(72), "document", artifact.id))
        }
    }

    override fun widgetSnapshot(context: Context, targetId: String): ModuleWidgetSnapshot? {
        when (targetId) {
            "capturenotes:quick:text" -> return ModuleWidgetSnapshot("Quick text note", "Tap to create a new note", "document")
            "capturenotes:quick:audio" -> return ModuleWidgetSnapshot("Quick audio note", "Tap to record", "audio")
            "capturenotes:quick:postit" -> return ModuleWidgetSnapshot("Quick post-it", "Tap to create a pinned note", "text")
            "capturenotes:library" -> return ModuleWidgetSnapshot("Notes & Capture", "${CaptureNotesStore.all().size} saved objects", "document")
        }
        val objectId = targetId.substringAfterLast(':', missingDelimiterValue = "")
        val artifact = CaptureNotesStore.get(objectId) ?: return null
        val subtitle = when (artifact.type) {
            CaptureArtifactType.CHECKLIST -> "${artifact.completedCount}/${artifact.items.size} complete · r${artifact.revision}"
            CaptureArtifactType.POST_IT, CaptureArtifactType.TEXT -> artifact.body.replace('\n', ' ').take(80)
            else -> artifact.fileName.ifBlank { artifact.type.wire }
        }
        val actions = if (artifact.type == CaptureArtifactType.CHECKLIST) {
            artifact.items.take(3).map { item ->
                ModuleWidgetAction(
                    id = "toggle:${item.id}",
                    label = "${if (item.completed) "☑" else "☐"} ${item.text}"
                )
            }
        } else {
            emptyList()
        }
        return ModuleWidgetSnapshot(
            title = artifact.title,
            subtitle = subtitle,
            iconKey = when (artifact.type) {
                CaptureArtifactType.CHECKLIST -> "checklist"
                CaptureArtifactType.POST_IT -> "text"
                CaptureArtifactType.TEXT -> "document"
                CaptureArtifactType.AUDIO -> "audio"
                CaptureArtifactType.SKETCH -> "image"
            },
            actions = actions
        )
    }

    override fun performWidgetAction(context: Context, targetId: String, actionId: String): Boolean {
        val objectId = targetId.substringAfterLast(':', missingDelimiterValue = "")
        val artifact = CaptureNotesStore.get(objectId) ?: return false
        if (artifact.type != CaptureArtifactType.CHECKLIST || !actionId.startsWith("toggle:")) return false
        val itemId = actionId.removePrefix("toggle:")
        return runCatching {
            CaptureNotesStore.toggleChecklistItem(objectId, itemId)
            true
        }.getOrDefault(false)
    }

    override fun widgetInvocation(context: Context, targetId: String): ModuleWidgetInvocation? {
        when (targetId) {
            "capturenotes:quick:text" -> return ModuleWidgetInvocation(As100TextNoteMethod.ID, mapOf("operation" to "create"))
            "capturenotes:quick:audio" -> return ModuleWidgetInvocation(As100AudioNoteMethod.ID, mapOf("operation" to "create"))
            "capturenotes:quick:postit" -> return ModuleWidgetInvocation(As100PostItMethod.ID, mapOf("operation" to "create"))
            "capturenotes:library" -> return ModuleWidgetInvocation(As100NotesLibraryMethod.ID)
        }
        val objectId = targetId.substringAfterLast(':', missingDelimiterValue = "")
        val artifact = CaptureNotesStore.get(objectId) ?: return null
        return when (artifact.type) {
            CaptureArtifactType.CHECKLIST -> ModuleWidgetInvocation(As100ChecklistMethod.ID, mapOf("operation" to "open", "checklist_id" to artifact.id))
            CaptureArtifactType.POST_IT -> ModuleWidgetInvocation(As100PostItMethod.ID, mapOf("operation" to "open", "postit_id" to artifact.id))
            CaptureArtifactType.TEXT -> ModuleWidgetInvocation(As100TextNoteMethod.ID, mapOf("operation" to "open", "text_note_id" to artifact.id))
            CaptureArtifactType.AUDIO -> ModuleWidgetInvocation(As100AudioNoteMethod.ID, mapOf("operation" to "open", "audio_note_id" to artifact.id))
            CaptureArtifactType.SKETCH -> ModuleWidgetInvocation(As100SketchNoteMethod.ID, mapOf("operation" to "open", "sketch_note_id" to artifact.id))
        }
    }

    override fun examples() = listOf(
        ModuleExample("Create field checklist", "WHAT; manage checklist; RESULT; return checklist_id, checklist_items_json, methodmesh_full_json; format json", "operation=create; title=Field checklist"),
        ModuleExample("Append shared text", "WHAT; edit text note; RESULT; return text_note_id, text_note_body; format json", "operation=append with a stable text_note_id"),
        ModuleExample("Tick checklist item", "WHAT; manage checklist; RESULT; return checklist_id, checklist_items_json; format json", "operation=set_item_state with checklist_id and item_id")
    )
}
