package com.example.methodmesh.modules.capturenotes

import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

private const val VERSION = "0.1.0"

abstract class CaptureNotesMethod(
    final override val id: String,
    name: String,
    description: String,
    inputs: List<String>,
    outputs: List<String>
) : As100Method {
    final override val ref = ArchitectureRef(ArchitectureId(id), "Method", name)
    final override val descriptor = MethodDescriptor(
        id = ArchitectureId(id),
        methodType = MethodObjectType.Workflow,
        name = name,
        version = VERSION,
        description = description,
        inputs = inputs,
        outputs = outputs,
        graphOutputs = listOf(id),
        parameters = mapOf("category" to "Notes & Capture", "status" to "Development")
    )
    final override val contract = MethodContract(
        method = ref,
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Entity, KnowledgeObjectType.Observation),
        producedFields = outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    final override fun request(
        action: String,
        context: Map<String, String>,
        signals: List<Signal>,
        inputs: List<ArchitectureRef>
    ) = As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    final override fun execute(
        request: ExecutionRequest,
        settingsState: SettingsState?,
        transport: String?
    ): ExecutionResult {
        val invocation = InvocationContext.from(request.context)
        val outcome = runCatching { executeOperation(request.context, transport.orEmpty()) }
        val values = outcome.getOrElse { error ->
            linkedMapOf(
                "notes_status" to "failed",
                "notes_operation" to operation(request.context),
                "notes_error" to (error.message ?: error.javaClass.simpleName),
                "notes_updated_at" to Instant.now().toString()
            )
        }
        val succeeded = values["notes_status"] != "failed"
        val entity = values["notes_object_id"]?.takeIf { it.isNotBlank() }?.let { objectId ->
            Entity(
                id = ArchitectureId("notes-object:$objectId"),
                entityType = values["notes_object_type"].orEmpty().ifBlank { "CaptureArtifact" },
                attributes = mapOf("object_id" to objectId),
                temporalContext = request.temporalContext
            )
        }
        val provenance = ProvenanceContext("methodmesh.capture_notes", id, VERSION)
        val observation = Observation(
            phenomenon = id,
            values = values,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        val transformation = Transformation(
            action = id,
            method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (succeeded) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request = request,
            status = if (succeeded) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOfNotNull(entity),
            observations = listOf(observation),
            transformations = listOf(transformation),
            diagnostics = if (succeeded) emptyMap() else mapOf("notes_error" to values["notes_error"].orEmpty())
        ).withInvocationContext(invocation)
    }

    protected fun operation(settings: Map<String, String>, fallback: String = "read"): String =
        (settings["operation"] ?: settings["input_operation"] ?: fallback).trim().lowercase()

    protected fun setting(settings: Map<String, String>, key: String, fallback: String = ""): String =
        settings[key] ?: settings["input_$key"] ?: fallback

    protected fun expectedRevision(settings: Map<String, String>): Long? =
        setting(settings, "expected_revision").trim().toLongOrNull()

    protected fun source(transport: String): String = transport.ifBlank { "native" }

    protected fun common(artifact: CaptureArtifact, operation: String): LinkedHashMap<String, String> = linkedMapOf(
        "notes_status" to "succeeded",
        "notes_operation" to operation,
        "notes_object_id" to artifact.id,
        "notes_object_type" to artifact.type.wire,
        "notes_title" to artifact.title,
        "notes_revision" to artifact.revision.toString(),
        "notes_updated_at" to artifact.updatedAtIso,
        "notes_error" to ""
    )

    protected abstract fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String>
}

object As100ChecklistMethod : CaptureNotesMethod(
    id = ID,
    name = "Checklist",
    description = "Create, read and mutate persistent addressable checklists and checklist items.",
    inputs = listOf("operation", "checklist_id", "title", "items", "item_id", "item_text", "completed", "expected_revision"),
    outputs = listOf(
        "notes_status", "notes_operation", "notes_object_id", "notes_object_type", "notes_title", "notes_revision", "notes_updated_at", "notes_error",
        "checklist_id", "checklist_revision", "checklist_title", "checklist_items_json", "checklist_total_items", "checklist_completed_items", "checklist_remaining_items", "affected_item_id"
    )
) {
    const val ID = "notes.checklist"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val op = operation(settings, "create")
        val id = setting(settings, "checklist_id", setting(settings, "object_id"))
        val revision = expectedRevision(settings)
        var affectedItemId = setting(settings, "item_id")
        val artifact = when (op) {
            "create" -> CaptureNotesStore.createChecklist(
                title = setting(settings, "title", "Checklist"),
                itemTexts = parseItems(setting(settings, "items", setting(settings, "item_text"))),
                source = source(transport)
            )
            "read", "open" -> requireNotNull(CaptureNotesStore.get(id)) { "Checklist not found." }
            "add_item", "add_items" -> {
                val before = requireNotNull(CaptureNotesStore.get(id)) { "Checklist not found." }
                val texts = parseItems(setting(settings, "item_text", setting(settings, "items")))
                val updated = CaptureNotesStore.addChecklistItems(id, texts, revision)
                affectedItemId = updated.items.drop(before.items.size).firstOrNull()?.id.orEmpty()
                updated
            }
            "set_item_state" -> CaptureNotesStore.setChecklistItemState(
                id,
                setting(settings, "item_id").also { require(it.isNotBlank()) { "item_id is required." } },
                setting(settings, "completed", "true").toBooleanStrictOrNull() ?: false,
                revision
            )
            "toggle_item" -> CaptureNotesStore.toggleChecklistItem(
                id,
                setting(settings, "item_id").also { require(it.isNotBlank()) { "item_id is required." } },
                revision
            )
            "update_item" -> CaptureNotesStore.updateChecklistItem(
                id,
                setting(settings, "item_id").also { require(it.isNotBlank()) { "item_id is required." } },
                setting(settings, "item_text"),
                revision
            )
            "remove_item" -> CaptureNotesStore.removeChecklistItem(
                id,
                setting(settings, "item_id").also { require(it.isNotBlank()) { "item_id is required." } },
                revision
            )
            "rename" -> CaptureNotesStore.rename(id, setting(settings, "title"), revision)
            "clear_completed" -> CaptureNotesStore.clearCompleted(id, revision)
            "delete" -> {
                CaptureNotesStore.delete(id, revision)
                CaptureArtifact(id = id, type = CaptureArtifactType.CHECKLIST, title = "Deleted", revision = (revision ?: 0L) + 1L)
            }
            else -> error("Unsupported checklist operation: $op")
        }
        require(op == "delete" || artifact.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        return common(artifact, op).apply {
            put("checklist_id", artifact.id)
            put("checklist_revision", artifact.revision.toString())
            put("checklist_title", artifact.title)
            put("checklist_items_json", JSONArray().apply { artifact.items.forEach { put(it.toJson()) } }.toString())
            put("checklist_total_items", artifact.items.size.toString())
            put("checklist_completed_items", artifact.completedCount.toString())
            put("checklist_remaining_items", artifact.remainingCount.toString())
            put("affected_item_id", affectedItemId)
        }
    }

    private fun parseItems(raw: String): List<String> = raw
        .replace("\\n", "\n")
        .split('\n', '|')
        .map { it.trim().removePrefix("- [ ]").removePrefix("- [x]").removePrefix("- [X]").trim() }
        .filter { it.isNotBlank() }
}

object As100TextNoteMethod : CaptureNotesMethod(
    id = ID,
    name = "Text note",
    description = "Create, read and mutate persistent plain-text notes/files.",
    inputs = listOf("operation", "text_note_id", "title", "text", "file_name", "mime_type", "separator", "expected_revision"),
    outputs = listOf(
        "notes_status", "notes_operation", "notes_object_id", "notes_object_type", "notes_title", "notes_revision", "notes_updated_at", "notes_error",
        "text_note_id", "text_note_revision", "text_note_title", "text_note_body", "text_note_file_name", "text_note_mime_type"
    )
) {
    const val ID = "notes.text"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val op = operation(settings, "create")
        val id = setting(settings, "text_note_id", setting(settings, "object_id"))
        val revision = expectedRevision(settings)
        val artifact = when (op) {
            "create" -> CaptureNotesStore.createText(
                title = setting(settings, "title", "Text note"),
                body = setting(settings, "text"),
                fileName = setting(settings, "file_name"),
                mimeType = setting(settings, "mime_type", "text/plain"),
                source = source(transport)
            )
            "read", "open" -> requireNotNull(CaptureNotesStore.get(id)) { "Text note not found." }
            "append" -> CaptureNotesStore.appendText(id, setting(settings, "text"), decodeSeparator(setting(settings, "separator", "\\n")), revision)
            "replace" -> CaptureNotesStore.replaceText(id, setting(settings, "text"), revision)
            "rename" -> CaptureNotesStore.rename(id, setting(settings, "title"), revision)
            "delete" -> {
                CaptureNotesStore.delete(id, revision)
                CaptureArtifact(id = id, type = CaptureArtifactType.TEXT, title = "Deleted", revision = (revision ?: 0L) + 1L)
            }
            else -> error("Unsupported text-note operation: $op")
        }
        require(op == "delete" || artifact.type == CaptureArtifactType.TEXT) { "Object is not a text note." }
        return common(artifact, op).apply {
            put("text_note_id", artifact.id)
            put("text_note_revision", artifact.revision.toString())
            put("text_note_title", artifact.title)
            put("text_note_body", artifact.body)
            put("text_note_file_name", artifact.fileName)
            put("text_note_mime_type", artifact.mimeType)
        }
    }

    private fun decodeSeparator(value: String): String = value.replace("\\n", "\n").replace("\\t", "\t")
}

object As100PostItMethod : CaptureNotesMethod(
    id = ID,
    name = "Post-it note",
    description = "Create and mutate persistent pinned short notes.",
    inputs = listOf("operation", "postit_id", "title", "text", "pinned", "separator", "expected_revision"),
    outputs = listOf(
        "notes_status", "notes_operation", "notes_object_id", "notes_object_type", "notes_title", "notes_revision", "notes_updated_at", "notes_error",
        "postit_id", "postit_revision", "postit_title", "postit_text", "postit_pinned"
    )
) {
    const val ID = "notes.postit"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val op = operation(settings, "create")
        val id = setting(settings, "postit_id", setting(settings, "object_id"))
        val revision = expectedRevision(settings)
        val artifact = when (op) {
            "create" -> CaptureNotesStore.createPostIt(
                title = setting(settings, "title", "Post-it"),
                body = setting(settings, "text"),
                pinned = setting(settings, "pinned", "true").toBooleanStrictOrNull() ?: true,
                source = source(transport)
            )
            "read", "open" -> requireNotNull(CaptureNotesStore.get(id)) { "Post-it not found." }
            "append" -> CaptureNotesStore.appendText(id, setting(settings, "text"), setting(settings, "separator", " ").replace("\\n", "\n"), revision)
            "replace" -> CaptureNotesStore.replaceText(id, setting(settings, "text"), revision)
            "pin" -> CaptureNotesStore.setPinned(id, true, revision)
            "unpin" -> CaptureNotesStore.setPinned(id, false, revision)
            "rename" -> CaptureNotesStore.rename(id, setting(settings, "title"), revision)
            "delete" -> {
                CaptureNotesStore.delete(id, revision)
                CaptureArtifact(id = id, type = CaptureArtifactType.POST_IT, title = "Deleted", revision = (revision ?: 0L) + 1L)
            }
            else -> error("Unsupported post-it operation: $op")
        }
        require(op == "delete" || artifact.type == CaptureArtifactType.POST_IT) { "Object is not a post-it." }
        return common(artifact, op).apply {
            put("postit_id", artifact.id)
            put("postit_revision", artifact.revision.toString())
            put("postit_title", artifact.title)
            put("postit_text", artifact.body)
            put("postit_pinned", artifact.pinned.toString())
        }
    }
}

object As100JsonReaderMethod : CaptureNotesMethod(
    id = ID,
    name = "JSON reader",
    description = "Validate, pretty-print and inspect JSON locally.",
    inputs = listOf("json", "text"),
    outputs = listOf("notes_status", "notes_operation", "notes_updated_at", "notes_error", "json_pretty", "json_compact", "json_root_type", "json_valid")
) {
    const val ID = "notes.json.read"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val raw = setting(settings, "json", setting(settings, "text")).trim()
        require(raw.isNotBlank()) { "JSON input is required." }
        val (pretty, compact, type) = if (raw.startsWith("[")) {
            val value = JSONArray(raw)
            Triple(value.toString(2), value.toString(), "array")
        } else {
            val value = JSONObject(raw)
            Triple(value.toString(2), value.toString(), "object")
        }
        return linkedMapOf(
            "notes_status" to "succeeded",
            "notes_operation" to "read",
            "notes_updated_at" to Instant.now().toString(),
            "notes_error" to "",
            "json_pretty" to pretty,
            "json_compact" to compact,
            "json_root_type" to type,
            "json_valid" to "true"
        )
    }
}

object As100AudioNoteMethod : CaptureNotesMethod(
    id = ID,
    name = "Audio note",
    description = "Register or return an audio note artifact. Native recording supplies the resulting URI to this canonical method.",
    inputs = listOf("operation", "title", "uri", "file_name", "mime_type"),
    outputs = listOf("notes_status", "notes_operation", "notes_object_id", "notes_object_type", "notes_title", "notes_revision", "notes_updated_at", "notes_error", "audio_note_id", "audio_uri", "audio_file_name", "audio_mime_type")
) {
    const val ID = "notes.audio"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val op = operation(settings, "create")
        val id = setting(settings, "audio_note_id", setting(settings, "object_id"))
        val artifact = when (op) {
            "create", "import" -> CaptureNotesStore.createAttachment(
                CaptureArtifactType.AUDIO,
                setting(settings, "title", "Audio note"),
                setting(settings, "uri").also { require(it.isNotBlank()) { "Audio URI is required." } },
                setting(settings, "file_name"),
                setting(settings, "mime_type", "audio/*"),
                source(transport)
            )
            "read", "open" -> requireNotNull(CaptureNotesStore.get(id)) { "Audio note not found." }
            "delete" -> {
                CaptureNotesStore.delete(id, expectedRevision(settings))
                CaptureArtifact(id = id, type = CaptureArtifactType.AUDIO, title = "Deleted")
            }
            else -> error("Unsupported audio-note operation: $op")
        }
        return common(artifact, op).apply {
            put("audio_note_id", artifact.id)
            put("audio_uri", artifact.body)
            put("audio_file_name", artifact.fileName)
            put("audio_mime_type", artifact.mimeType)
        }
    }
}

object As100SketchNoteMethod : CaptureNotesMethod(
    id = ID,
    name = "Sketch note",
    description = "Register or return a sketch/image note artifact. Native drawing supplies the resulting URI to this canonical method.",
    inputs = listOf("operation", "title", "uri", "file_name", "mime_type"),
    outputs = listOf("notes_status", "notes_operation", "notes_object_id", "notes_object_type", "notes_title", "notes_revision", "notes_updated_at", "notes_error", "sketch_note_id", "sketch_uri", "sketch_file_name", "sketch_mime_type")
) {
    const val ID = "notes.sketch"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val op = operation(settings, "create")
        val id = setting(settings, "sketch_note_id", setting(settings, "object_id"))
        val artifact = when (op) {
            "create", "import" -> CaptureNotesStore.createAttachment(
                CaptureArtifactType.SKETCH,
                setting(settings, "title", "Sketch note"),
                setting(settings, "uri").also { require(it.isNotBlank()) { "Sketch URI is required." } },
                setting(settings, "file_name"),
                setting(settings, "mime_type", "image/png"),
                source(transport)
            )
            "read", "open" -> requireNotNull(CaptureNotesStore.get(id)) { "Sketch note not found." }
            "delete" -> {
                CaptureNotesStore.delete(id, expectedRevision(settings))
                CaptureArtifact(id = id, type = CaptureArtifactType.SKETCH, title = "Deleted")
            }
            else -> error("Unsupported sketch-note operation: $op")
        }
        return common(artifact, op).apply {
            put("sketch_note_id", artifact.id)
            put("sketch_uri", artifact.body)
            put("sketch_file_name", artifact.fileName)
            put("sketch_mime_type", artifact.mimeType)
        }
    }
}

object As100NotesLibraryMethod : CaptureNotesMethod(
    id = ID,
    name = "Notes library",
    description = "Search and enumerate persistent Notes & Capture objects.",
    inputs = listOf("query", "type"),
    outputs = listOf("notes_status", "notes_operation", "notes_updated_at", "notes_error", "notes_library_count", "notes_library_json")
) {
    const val ID = "notes.library.search"

    override fun executeOperation(settings: Map<String, String>, transport: String): LinkedHashMap<String, String> {
        val typeRaw = setting(settings, "type").trim()
        val type = CaptureArtifactType.entries.firstOrNull { it.wire == typeRaw }
        val matches = CaptureNotesStore.search(setting(settings, "query"), type)
        val json = JSONArray().apply { matches.forEach { put(it.toJson()) } }.toString()
        return linkedMapOf(
            "notes_status" to "succeeded",
            "notes_operation" to "search",
            "notes_updated_at" to Instant.now().toString(),
            "notes_error" to "",
            "notes_library_count" to matches.size.toString(),
            "notes_library_json" to json
        )
    }
}
