package com.example.methodmesh.modules.capturenotes

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.media.MediaRecorder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityCompletionMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.io.File
import kotlin.math.max

private fun mediaConfigured(context: CapabilityScreenContext, key: String, fallback: String = ""): String =
    context.action.settings[key] ?: context.action.settings["input_$key"] ?: fallback

private fun mediaPreview(result: ExecutionResult?): Map<String, Any?> =
    result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty()

@Suppress("DEPRECATION")
private fun startAudioRecorder(file: File): MediaRecorder = MediaRecorder().apply {
    setAudioSource(MediaRecorder.AudioSource.MIC)
    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
    setAudioEncodingBitRate(128_000)
    setAudioSamplingRate(44_100)
    setOutputFile(file.absolutePath)
    prepare()
    start()
}

private fun stopAudioRecorder(recorder: MediaRecorder?) {
    if (recorder == null) return
    runCatching { recorder.stop() }
    runCatching { recorder.reset() }
    runCatching { recorder.release() }
}

object AudioNoteCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100AudioNoteMethod.ID
    override val title = "Audio note"
    override val description = "Record, import and persist addressable audio notes."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var titleText by rememberSaveable { mutableStateOf(mediaConfigured(context, "title", "Audio note")) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
        var recording by remember { mutableStateOf(false) }
        var clipPath by remember { mutableStateOf("") }
        var status by rememberSaveable { mutableStateOf("Ready") }
        var hasPermission by remember {
            mutableStateOf(ContextCompat.checkSelfPermission(androidContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
        }
        val incomingUri = mediaConfigured(context, "uri")
        val incomingOperation = mediaConfigured(context, "operation", "create")
        val automaticExecution = context.completionMode == CapabilityCompletionMode.AutomaticReturn

        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            hasPermission = granted || ContextCompat.checkSelfPermission(androidContext, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) status = "Microphone permission denied"
        }

        DisposableEffect(Unit) {
            onDispose { stopAudioRecorder(recorder) }
        }

        LaunchedEffect(automaticExecution, incomingOperation, incomingUri, context.action.settings) {
            // Import/read/delete can execute headlessly. A create without a URI is intentionally interactive.
            if (automaticExecution && (incomingOperation != "create" || incomingUri.isNotBlank())) {
                val execution = runCaptureMethod(As100AudioNoteMethod, context, context.action.settings)
                result = execution
                onConfirmed(execution)
            }
        }
        if (automaticExecution && (incomingOperation != "create" || incomingUri.isNotBlank())) return

        fun commitClip(file: File) {
            val uri = FileProvider.getUriForFile(androidContext, "${androidContext.packageName}.fileprovider", file)
            val execution = runCaptureMethod(
                As100AudioNoteMethod,
                context,
                mapOf(
                    "operation" to "import",
                    "title" to titleText,
                    "uri" to uri.toString(),
                    "file_name" to file.name,
                    "mime_type" to "audio/mp4"
                )
            )
            result = execution
            status = "Saved"
            if (context.completionMode == CapabilityCompletionMode.AutomaticReturn || context.submitsImmediately) onConfirmed(execution)
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = mediaPreview(result),
            onBack = onBack,
            onRetry = { result = null; status = "Ready" },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            OutlinedTextField(titleText, { titleText = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text(status, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        if (!hasPermission) {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        } else if (!recording) {
                            val file = File.createTempFile("methodmesh-audio-note-", ".m4a", androidContext.cacheDir)
                            runCatching { startAudioRecorder(file) }
                                .onSuccess { active -> recorder = active; clipPath = file.absolutePath; recording = true; status = "Recording…" }
                                .onFailure { file.delete(); status = it.message ?: "Could not start recording" }
                        }
                    },
                    enabled = !recording,
                    modifier = Modifier.weight(1f)
                ) { Text(if (hasPermission) "Record" else "Allow microphone") }
                Button(
                    onClick = {
                        if (recording) {
                            stopAudioRecorder(recorder); recorder = null; recording = false
                            val file = File(clipPath)
                            if (file.exists() && file.length() > 0L) commitClip(file) else status = "Recording was empty"
                        }
                    },
                    enabled = recording,
                    modifier = Modifier.weight(1f)
                ) { Text("Stop & save") }
            }
            val audioId = mediaPreview(result)["audio_note_id"]?.toString().orEmpty()
            if (audioId.isNotBlank()) Text("Audio note ID: $audioId", style = MaterialTheme.typography.labelSmall)
        }
    }
}

private data class SketchStroke(val points: MutableList<Offset> = mutableListOf())

object SketchNoteCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SketchNoteMethod.ID
    override val title = "Sketch note"
    override val description = "Draw a quick sketch and persist it as an addressable PNG note."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var titleText by rememberSaveable { mutableStateOf(mediaConfigured(context, "title", "Sketch note")) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var canvasSize by remember { mutableStateOf(IntSize.Zero) }
        val strokes = remember { mutableStateListOf<SketchStroke>() }
        var strokeVersion by remember { mutableStateOf(0) }
        val incomingUri = mediaConfigured(context, "uri")
        val incomingOperation = mediaConfigured(context, "operation", "create")
        val automaticExecution = context.completionMode == CapabilityCompletionMode.AutomaticReturn

        LaunchedEffect(automaticExecution, incomingOperation, incomingUri, context.action.settings) {
            // Existing/imported image notes can execute headlessly; drawing a new note is interactive.
            if (automaticExecution && (incomingOperation != "create" || incomingUri.isNotBlank())) {
                val execution = runCaptureMethod(As100SketchNoteMethod, context, context.action.settings)
                result = execution
                onConfirmed(execution)
            }
        }
        if (automaticExecution && (incomingOperation != "create" || incomingUri.isNotBlank())) return

        fun saveSketch() {
            val width = max(canvasSize.width, 640)
            val height = max(canvasSize.height, 640)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = AndroidCanvas(bitmap)
            canvas.drawColor(AndroidColor.WHITE)
            val sx = width.toFloat() / max(canvasSize.width, 1)
            val sy = height.toFloat() / max(canvasSize.height, 1)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = AndroidColor.BLACK
                style = Paint.Style.STROKE
                strokeWidth = 6f * ((sx + sy) / 2f)
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            strokes.forEach { stroke ->
                val pts = stroke.points
                if (pts.size == 1) {
                    canvas.drawPoint(pts[0].x * sx, pts[0].y * sy, paint)
                } else if (pts.size > 1) {
                    val path = android.graphics.Path().apply {
                        moveTo(pts.first().x * sx, pts.first().y * sy)
                        pts.drop(1).forEach { lineTo(it.x * sx, it.y * sy) }
                    }
                    canvas.drawPath(path, paint)
                }
            }
            val file = File.createTempFile("methodmesh-sketch-note-", ".png", androidContext.cacheDir)
            file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            val uri = FileProvider.getUriForFile(androidContext, "${androidContext.packageName}.fileprovider", file)
            val execution = runCaptureMethod(
                As100SketchNoteMethod,
                context,
                mapOf("operation" to "import", "title" to titleText, "uri" to uri.toString(), "file_name" to file.name, "mime_type" to "image/png")
            )
            result = execution
            if (context.completionMode == CapabilityCompletionMode.AutomaticReturn || context.submitsImmediately) onConfirmed(execution)
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = mediaPreview(result),
            onBack = onBack,
            onRetry = { result = null },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            OutlinedTextField(titleText, { titleText = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(360.dp)
                    .background(Color.White)
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { point -> strokes.add(SketchStroke(mutableListOf(point))); strokeVersion++ },
                            onDrag = { change, _ -> strokes.lastOrNull()?.points?.add(change.position); strokeVersion++; change.consume() }
                        )
                    }
            ) {
                Canvas(Modifier.matchParentSize()) {
                    @Suppress("UNUSED_VARIABLE") val invalidate = strokeVersion
                    strokes.forEach { stroke ->
                        val pts = stroke.points
                        if (pts.size == 1) drawCircle(Color.Black, radius = 3f, center = pts[0])
                        if (pts.size > 1) {
                            for (i in 1 until pts.size) {
                                drawLine(Color.Black, pts[i - 1], pts[i], strokeWidth = 6f, cap = StrokeCap.Round)
                            }
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { if (strokes.isNotEmpty()) { strokes.removeAt(strokes.lastIndex); strokeVersion++ } }, enabled = strokes.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Undo") }
                OutlinedButton(onClick = { strokes.clear(); strokeVersion++ }, enabled = strokes.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Clear") }
                Button(onClick = ::saveSketch, enabled = strokes.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Save") }
            }
            val sketchId = mediaPreview(result)["sketch_note_id"]?.toString().orEmpty()
            if (sketchId.isNotBlank()) Text("Sketch note ID: $sketchId", style = MaterialTheme.typography.labelSmall)
        }
    }
}
