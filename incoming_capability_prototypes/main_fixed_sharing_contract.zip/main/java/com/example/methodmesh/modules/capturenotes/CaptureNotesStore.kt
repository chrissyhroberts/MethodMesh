package com.example.methodmesh.modules.capturenotes

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.methodmesh.widgets.MethodMeshWidgetProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant

object CaptureNotesStore {
    @Volatile private var appContext: Context? = null
    private val lock = Any()

    fun initialise(context: Context) {
        appContext = context.applicationContext
        root().mkdirs()
    }

    fun isInitialised(): Boolean = appContext != null

    fun all(type: CaptureArtifactType? = null): List<CaptureArtifact> = synchronized(lock) {
        readAll().filter { type == null || it.type == type }.sortedByDescending { it.updatedAtIso }
    }

    fun search(query: String, type: CaptureArtifactType? = null): List<CaptureArtifact> {
        val q = query.trim().lowercase()
        return all(type).filter { artifact ->
            q.isBlank() || artifact.title.lowercase().contains(q) || artifact.body.lowercase().contains(q) ||
                artifact.items.any { it.text.lowercase().contains(q) }
        }
    }

    fun get(id: String): CaptureArtifact? = synchronized(lock) { readAll().firstOrNull { it.id == id } }

    fun createChecklist(title: String, itemTexts: List<String>, source: String = "native"): CaptureArtifact = synchronized(lock) {
        val now = Instant.now().toString()
        val artifact = CaptureArtifact(
            type = CaptureArtifactType.CHECKLIST,
            title = title.trim().ifBlank { "Checklist" },
            items = itemTexts.map { it.trim() }.filter { it.isNotBlank() }.map { ChecklistItem(text = it, createdAtIso = now, updatedAtIso = now) },
            source = source,
            createdAtIso = now,
            updatedAtIso = now
        )
        saveNew(artifact)
    }

    fun createText(
        title: String,
        body: String,
        fileName: String = "",
        mimeType: String = "text/plain",
        source: String = "native"
    ): CaptureArtifact = synchronized(lock) {
        val now = Instant.now().toString()
        val safeTitle = title.trim().ifBlank { fileName.trim().ifBlank { "Text note" } }
        val artifact = CaptureArtifact(
            type = CaptureArtifactType.TEXT,
            title = safeTitle,
            body = body,
            fileName = fileName,
            mimeType = mimeType.ifBlank { "text/plain" },
            source = source,
            createdAtIso = now,
            updatedAtIso = now
        )
        saveNew(artifact)
    }

    fun createPostIt(title: String, body: String, pinned: Boolean = true, source: String = "native"): CaptureArtifact = synchronized(lock) {
        val now = Instant.now().toString()
        val artifact = CaptureArtifact(
            type = CaptureArtifactType.POST_IT,
            title = title.trim().ifBlank { "Post-it" },
            body = body,
            pinned = pinned,
            source = source,
            createdAtIso = now,
            updatedAtIso = now
        )
        saveNew(artifact)
    }

    fun createAttachment(
        type: CaptureArtifactType,
        title: String,
        uri: String,
        fileName: String,
        mimeType: String,
        source: String
    ): CaptureArtifact = synchronized(lock) {
        require(type == CaptureArtifactType.AUDIO || type == CaptureArtifactType.SKETCH)
        val context = requireNotNull(appContext) { "CaptureNotesStore is not initialised." }
        val now = Instant.now().toString()
        val sourceUri = Uri.parse(uri)
        val suffix = fileName.substringAfterLast('.', missingDelimiterValue = "").takeIf { it.isNotBlank() }
            ?: if (type == CaptureArtifactType.AUDIO) "audio" else "png"
        val attachmentRoot = File(root(), "attachments").apply { mkdirs() }
        val target = File(attachmentRoot, "${java.util.UUID.randomUUID()}.$suffix")
        context.contentResolver.openInputStream(sourceUri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Shared attachment could not be opened.")
        val localUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", target).toString()
        val artifact = CaptureArtifact(
            type = type,
            title = title.trim().ifBlank { if (type == CaptureArtifactType.AUDIO) "Audio note" else "Sketch note" },
            body = localUri,
            fileName = fileName.ifBlank { target.name },
            mimeType = mimeType,
            source = source,
            createdAtIso = now,
            updatedAtIso = now
        )
        saveNew(artifact)
    }

    fun addChecklistItems(id: String, texts: List<String>, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, now ->
        require(current.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        val additions = texts.map { it.trim() }.filter { it.isNotBlank() }.map { ChecklistItem(text = it, createdAtIso = now, updatedAtIso = now) }
        current.copy(items = current.items + additions)
    }

    fun setChecklistItemState(id: String, itemId: String, completed: Boolean, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, now ->
        require(current.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        require(current.items.any { it.id == itemId }) { "Checklist item not found." }
        current.copy(items = current.items.map { item ->
            if (item.id == itemId) item.copy(completed = completed, updatedAtIso = now) else item
        })
    }

    fun toggleChecklistItem(id: String, itemId: String, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, now ->
        require(current.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        require(current.items.any { it.id == itemId }) { "Checklist item not found." }
        current.copy(items = current.items.map { item ->
            if (item.id == itemId) item.copy(completed = !item.completed, updatedAtIso = now) else item
        })
    }

    fun updateChecklistItem(id: String, itemId: String, text: String, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, now ->
        require(current.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        require(text.isNotBlank()) { "Checklist item text is required." }
        require(current.items.any { it.id == itemId }) { "Checklist item not found." }
        current.copy(items = current.items.map { item -> if (item.id == itemId) item.copy(text = text.trim(), updatedAtIso = now) else item })
    }

    fun removeChecklistItem(id: String, itemId: String, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, _ ->
        require(current.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        require(current.items.any { it.id == itemId }) { "Checklist item not found." }
        current.copy(items = current.items.filterNot { it.id == itemId })
    }

    fun clearCompleted(id: String, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, _ ->
        require(current.type == CaptureArtifactType.CHECKLIST) { "Object is not a checklist." }
        current.copy(items = current.items.filterNot { it.completed })
    }

    fun appendText(id: String, text: String, separator: String = "\n", expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, _ ->
        require(current.type == CaptureArtifactType.TEXT || current.type == CaptureArtifactType.POST_IT) { "Object does not accept text." }
        val combined = when {
            current.body.isBlank() -> text
            text.isBlank() -> current.body
            else -> current.body + separator + text
        }
        current.copy(body = combined)
    }

    fun replaceText(id: String, text: String, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, _ ->
        require(current.type == CaptureArtifactType.TEXT || current.type == CaptureArtifactType.POST_IT) { "Object does not accept text." }
        current.copy(body = text)
    }

    fun rename(id: String, title: String, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, _ ->
        require(title.isNotBlank()) { "Title is required." }
        current.copy(title = title.trim())
    }

    fun setPinned(id: String, pinned: Boolean, expectedRevision: Long? = null): CaptureArtifact = mutate(id, expectedRevision) { current, _ ->
        current.copy(pinned = pinned)
    }

    fun delete(id: String, expectedRevision: Long? = null): Boolean = synchronized(lock) {
        val artifacts = readAll().toMutableList()
        val index = artifacts.indexOfFirst { it.id == id }
        require(index >= 0) { "Object not found." }
        expectedRevision?.let { expected -> require(artifacts[index].revision == expected) { "Revision conflict." } }
        artifacts.removeAt(index)
        writeAll(artifacts)
        notifyWidgets()
        true
    }

    private fun mutate(id: String, expectedRevision: Long?, transform: (CaptureArtifact, String) -> CaptureArtifact): CaptureArtifact = synchronized(lock) {
        val artifacts = readAll().toMutableList()
        val index = artifacts.indexOfFirst { it.id == id }
        require(index >= 0) { "Object not found." }
        val before = artifacts[index]
        expectedRevision?.let { expected -> require(before.revision == expected) { "Revision conflict: expected $expected, found ${before.revision}." } }
        val now = Instant.now().toString()
        val after = transform(before, now).copy(revision = before.revision + 1L, updatedAtIso = now)
        artifacts[index] = after
        writeAll(artifacts)
        notifyWidgets()
        after
    }

    private fun saveNew(artifact: CaptureArtifact): CaptureArtifact {
        val artifacts = readAll().toMutableList()
        artifacts += artifact
        writeAll(artifacts)
        notifyWidgets()
        return artifact
    }

    private fun readAll(): List<CaptureArtifact> {
        val file = indexFile()
        if (!file.exists()) return emptyList()
        val array = runCatching { JSONArray(file.readText()) }.getOrElse { return emptyList() }
        return buildList {
            for (index in 0 until array.length()) {
                array.optJSONObject(index)?.let { root -> runCatching { CaptureArtifact.fromJson(root) }.getOrNull()?.let(::add) }
            }
        }
    }

    private fun writeAll(values: List<CaptureArtifact>) {
        val file = indexFile()
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(JSONArray().apply { values.forEach { put(it.toJson()) } }.toString(2))
        if (file.exists()) file.delete()
        require(temp.renameTo(file)) { "Could not save Notes & Capture library." }
    }

    private fun root(): File = File(requireNotNull(appContext) { "CaptureNotesStore is not initialised." }.filesDir, "methodmesh/capture_notes")
    private fun indexFile(): File = File(root(), "artifacts.json")

    private fun notifyWidgets() {
        appContext?.let { context -> runCatching { MethodMeshWidgetProvider.updateAll(context) } }
    }
}
