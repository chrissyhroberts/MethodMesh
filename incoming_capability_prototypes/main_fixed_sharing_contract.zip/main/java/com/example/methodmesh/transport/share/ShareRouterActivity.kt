package com.example.methodmesh.transport.share

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.ResearchRuntime
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.runtime.As100MethodRegistry
import com.example.methodmesh.modules.CapabilityInputContract
import com.example.methodmesh.modules.CapabilityInputInvocation
import com.example.methodmesh.modules.CapabilityInputTarget
import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.MethodMeshModuleRegistry
import com.example.methodmesh.modules.SharedCapabilityInput
import com.example.methodmesh.modules.matches
import com.example.methodmesh.transport.android.IntentRouterActivity
import com.example.methodmesh.ui.theme.MethodMeshTheme

private val TEXT_EXTENSIONS = setOf("txt", "md", "markdown", "csv", "log", "json")

class ShareRouterActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = parseSharedInput(intent)
        val matches = buildMatches(shared)
        if (matches.isEmpty()) {
            Toast.makeText(this, "MethodMesh has no compatible capability for this shared item.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (matches.size == 1) {
            handleChoice(shared, matches.single())
            return
        }
        setContent {
            MethodMeshTheme {
                ShareTargetChooser(
                    shared = shared,
                    matches = matches,
                    onChoose = { match -> handleChoice(shared, match) },
                    onCancel = { finish() }
                )
            }
        }
    }

    private fun buildMatches(input: SharedCapabilityInput): List<ShareTargetMatch> =
        MethodMeshModuleRegistry.all().flatMap { module ->
            module.inputContracts()
                .filter { it.matches(input) }
                .sortedByDescending { it.priority }
                .flatMap { contract ->
                    module.inputTargets(this, contract, input).map { target ->
                        ShareTargetMatch(module, contract, target)
                    }
                }
        }.sortedWith(compareByDescending<ShareTargetMatch> { it.contract.priority }.thenBy { it.contract.title }.thenBy { it.target.title })

    private fun handleChoice(input: SharedCapabilityInput, match: ShareTargetMatch) {
        val invocation = match.module.inputInvocation(this, match.contract, match.target, input)
        if (invocation == null) {
            Toast.makeText(this, "This destination could not accept the shared item.", Toast.LENGTH_LONG).show()
            return
        }
        if (match.contract.capabilityId == "notes.json.read" && match.target.operation == "open") {
            launchInteractive(invocation)
            finish()
            return
        }
        runCatching {
            val method = As100MethodRegistry.require(invocation.capabilityId)
            val invocationContext = InvocationContext(caller = "android_share")
            val result = method.execute(
                request = method.request(
                    action = invocation.capabilityId,
                    context = invocationContext.asMap(invocation.capabilityId) + invocation.settings
                ),
                transport = "android_share"
            )
            ResearchRuntime.session.record(result)
            require(result.status.name == "Succeeded") {
                result.diagnostics.values.firstOrNull().orEmpty().ifBlank { "Capability returned ${result.status}." }
            }
            result
        }.onSuccess {
            Toast.makeText(this, "Saved to ${match.target.title}", Toast.LENGTH_SHORT).show()
            finish()
        }.onFailure { error ->
            Toast.makeText(this, error.message ?: "Share failed.", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchInteractive(invocation: CapabilityInputInvocation) {
        startActivity(Intent(this, IntentRouterActivity::class.java).apply {
            putExtra("method_id", invocation.capabilityId)
            putExtra("caller", "android_share")
            putExtra("input_methodmesh_native_preset_run", "true")
            invocation.settings.forEach { (key, value) -> putExtra("input_$key", value) }
        })
    }

    @Suppress("DEPRECATION")
    private fun parseSharedInput(source: Intent): SharedCapabilityInput {
        val subject = source.getStringExtra(Intent.EXTRA_SUBJECT).orEmpty()
        val textExtra = source.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString().orEmpty()
        val uris = when (source.action) {
            Intent.ACTION_SEND_MULTIPLE -> source.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
            else -> listOfNotNull(source.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: source.data)
        }
        val names = uris.map { displayName(it) }
        val extensions = names.mapNotNull { name ->
            name.substringAfterLast('.', missingDelimiterValue = "").lowercase().takeIf(String::isNotBlank)
        }
        val uriMime = uris.firstOrNull()?.let { uri -> runCatching { contentResolver.getType(uri) }.getOrNull() }.orEmpty()
        val mime = source.type.orEmpty().ifBlank { uriMime }.ifBlank { mimeForExtension(extensions.firstOrNull().orEmpty()) }.ifBlank { "application/octet-stream" }
        val textLike = mime.startsWith("text/") || mime == "application/json" || extensions.any { it in TEXT_EXTENSIONS }
        val textFromUri = if (textExtra.isBlank() && textLike) {
            uris.map(::readTextSafely).filter(String::isNotBlank).joinToString("\n")
        } else ""
        val sourcePackage = source.`package`.orEmpty().ifBlank { referrer?.host.orEmpty() }
        return SharedCapabilityInput(
            mimeType = mime,
            text = textExtra.ifBlank { textFromUri },
            subject = subject,
            uriStrings = uris.map(Uri::toString),
            fileNames = names,
            sourcePackage = sourcePackage
        )
    }

    private fun mimeForExtension(extension: String): String = when (extension.lowercase()) {
        "txt", "log" -> "text/plain"
        "md", "markdown" -> "text/markdown"
        "csv" -> "text/csv"
        "json" -> "application/json"
        else -> ""
    }

    private fun readTextSafely(uri: Uri): String = runCatching {
        contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
            val buffer = CharArray(1_000_000)
            val count = reader.read(buffer)
            if (count <= 0) "" else String(buffer, 0, count)
        }.orEmpty()
    }.getOrDefault("")

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "file") return uri.lastPathSegment.orEmpty()
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) cursor.getString(0).orEmpty() else uri.lastPathSegment.orEmpty()
        } catch (_: Exception) {
            uri.lastPathSegment.orEmpty()
        } finally {
            cursor?.close()
        }
    }
}

data class ShareTargetMatch(
    val module: MethodMeshModule,
    val contract: CapabilityInputContract,
    val target: CapabilityInputTarget
)

@Composable
private fun ShareTargetChooser(
    shared: SharedCapabilityInput,
    matches: List<ShareTargetMatch>,
    onChoose: (ShareTargetMatch) -> Unit,
    onCancel: () -> Unit
) {
    var filter by remember { mutableStateOf("") }
    val visible = matches.filter { match ->
        filter.isBlank() || match.contract.title.contains(filter, ignoreCase = true) || match.target.title.contains(filter, ignoreCase = true)
    }
    Surface(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Share to MethodMesh", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            val descriptor = shared.fileNames.firstOrNull().orEmpty().ifBlank { shared.text.replace('\n', ' ').take(90) }
            if (descriptor.isNotBlank()) Text(descriptor, style = MaterialTheme.typography.bodyMedium)
            if (matches.size > 8) {
                androidx.compose.material3.OutlinedTextField(
                    value = filter,
                    onValueChange = { filter = it },
                    label = { Text("Find destination") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
            visible.groupBy { it.contract.title }.forEach { (group, groupMatches) ->
                Text(group, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                groupMatches.forEach { match ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onChoose(match) },
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(match.target.title, fontWeight = FontWeight.Bold)
                            if (match.target.subtitle.isNotBlank()) Text(match.target.subtitle, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth()) {
                androidx.compose.material3.OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
            }
        }
    }
}
