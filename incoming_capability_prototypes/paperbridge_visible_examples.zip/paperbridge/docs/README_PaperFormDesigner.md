# Paper Bridge visual designer — `paper.form.design`

The designer is the canonical authoring surface for paper templates. Study teams should not normally hand-edit `methodmesh.paper.v1` JSON.

## Fast path

1. Open **Paper Bridge → Design a form**.
2. Choose the blank questionnaire PDF/image.
3. Import the corresponding XLSForm.
4. Tap a field and drag its answer region on the page.
5. For single/multiple choice fields, tap each ODK choice and draw the matching tick box.
6. Fix all red design errors.
7. Use **Test with completed page**.
8. **Save Paper Bridge form**.

The saved form is immediately available to `paper.form.transcribe` and becomes the active native Paper Bridge form.

## What XLSForm import provides

For compatible rows the designer imports:

- variable name and label;
- paper recognition type;
- required state;
- `select_one` / `select_multiple` choice values and labels;
- simple `regex(., '…')` constraints;
- simple numeric lower/upper bounds.

Compatible ODK types are `text`, `integer`, `decimal`, `select_one`, `select_multiple` and `barcode`. Other rows are skipped with a warning. The XLSForm remains authoritative for constraints that the designer cannot safely reduce.

## Error detection

Save is blocked for structural errors: missing anchors, missing regions, invalid or duplicate variable names, reserved `paper_`/`methodmesh_` names, missing choice mappings, out-of-page/inverted boxes, anchor-zone intrusion and substantial overlaps. Very small regions are warnings because they are likely to be fragile in real photographs.

Testing uses the actual Paper Bridge rectification + ML Kit/OMR extraction path; it is not a mock preview.

## Bundled fixture

Use `example_paper_form_for_designer.pdf` together with `example_odk_showcase_paper_form_transcribe.xlsx`. They share six fields and cover every currently supported recognition family.

### Pan and zoom

The design canvas uses the same document-viewport discipline as MethodMesh Digital Signing: the page opens fitted at 1×, **Navigate** supports drag-to-pan and pinch-to-zoom up to 16×, and **Fit** restores the whole page. Region drawing is performed in normalized page coordinates after inverting the active viewport transform, so a box means the same thing whether it was drawn at 1× or 12×. Choosing a field/choice enters **Draw box** mode; after a successful draw the canvas returns to **Navigate** automatically.

## Built-in example

Paper Bridge ships with a ready-to-use example form. The canonical source files remain in this module's `docs/` directory:

- `example_paper_form_for_designer.pdf` — anchored blank paper questionnaire;
- `example_odk_showcase_paper_form_transcribe.xlsx` — matching XLSForm;
- `example_template_manifest.json` — generated Paper Bridge mapping;
- `example_paper_form_for_designer.png` — documentation preview.

The Android runtime does not assume `docs/` is an APK asset directory. Therefore the exact PDF/XLSX bytes are embedded in `PaperBridgeBuiltInExamples.kt` and materialised into app-private storage on first use. The example appears in **Form setup** automatically and is the fallback active form on a clean install. Opening it in Designer automatically loads both its paper PDF and ODK schema. The built-in example is immutable: Designer opens it as an editable copy with a new form ID so experimental changes cannot silently replace the shipped fixture.
