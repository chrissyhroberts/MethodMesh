package com.example.methodmesh.modules.signals

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/** High-rate accelerometer vibration envelope for phone-to-surface tabletop transfer. */
class SignalSurfaceReceiverEngine(private val appContext: Context) : SensorEventListener {
    data class Window(
        val timestampMs: Long,
        val vibrationRms: Double,
        val samples: Int
    )

    private val running = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var manager: SensorManager? = null
    private var previous: FloatArray? = null
    private var windowStartNs: Long = 0L
    private var sum2 = 0.0
    private var count = 0
    private var callback: ((Window) -> Unit)? = null
    private var errorCallback: ((String) -> Unit)? = null

    fun start(onWindow: (Window) -> Unit, onError: (String) -> Unit): Boolean {
        if (!running.compareAndSet(false, true)) return true
        val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (sensorManager == null || accelerometer == null) {
            running.set(false)
            onError("No accelerometer is available for tabletop reception.")
            return false
        }
        manager = sensorManager
        callback = onWindow
        errorCallback = onError
        previous = null
        windowStartNs = 0L
        sum2 = 0.0
        count = 0
        val ok = sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_FASTEST)
        if (!ok) {
            running.set(false)
            onError("The accelerometer could not be started.")
        }
        return ok
    }

    fun stop() {
        running.set(false)
        manager?.unregisterListener(this)
        manager = null
        callback = null
        errorCallback = null
        previous = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (!running.get() || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val current = event.values
        val prev = previous
        previous = current.copyOf()
        if (prev == null || current.size < 3 || prev.size < 3) return
        val dx = current[0] - prev[0]
        val dy = current[1] - prev[1]
        val dz = current[2] - prev[2]
        val delta = sqrt((dx * dx + dy * dy + dz * dz).toDouble())
        if (windowStartNs == 0L) windowStartNs = event.timestamp
        sum2 += delta * delta
        count++
        val elapsedNs = event.timestamp - windowStartNs
        if (elapsedNs >= 10_000_000L) {
            val rms = sqrt(sum2 / count.coerceAtLeast(1))
            val window = Window(System.currentTimeMillis(), rms, count)
            sum2 = 0.0
            count = 0
            windowStartNs = event.timestamp
            mainHandler.post { if (running.get()) callback?.invoke(window) }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
