# Drop-in

Copy this folder to:

`app/src/main/java/com/example/methodmesh/modules/display/`

No shared/core source edit is intended. MethodMesh module discovery should find `DisplayModule` through the normal module contract.

Then run:

```bash
./gradlew :app:compileDebugKotlin :app:testDebugUnitTest
```

Smoke-test all five capabilities, a fixed Preset, an Ask-when-run Preset, a two-step Protocol, and the bundled ODK showcase before promoting maturity beyond Development.
