# MethodMesh Display

**Module ID:** `display`  
**Module version:** 0.1.0  
**Maturity:** Development  
**Normative authority:** MethodMesh Master Book v1.29 FINAL (2026-09-23)

Display turns the current Android device into a temporary across-the-room information display while keeping the capability contract target-neutral for later physical screens and signs.

## Canonical capabilities

| Method | Purpose |
|---|---|
| `display.static` | One large static message until Stop |
| `display.marquee` | Continuously scrolling message |
| `display.board` | Multi-line information board |
| `display.code` | Maximum-emphasis short code or number |
| `display.sequence` | Timed newline-separated message sequence |

All five methods are independently callable through Capabilities, Presets, Protocols and the normal external/ODK transport. The module dashboard is therefore not a private implementation surface.

## Native interaction

The normal workflow is **compose -> SHOW -> live display -> STOP -> committed result -> Done**. The display itself is the working instrument. While showing, the screen stays awake and may temporarily request full brightness. One tap reveals/hides a translucent live-control strip.

Live controls deliberately do not require leaving presentation mode:

- **A− / A+** decrease/increase text size;
- pinch changes text size continuously;
- **Fit** returns to the default fitted scale;
- **Rotate** rotates content by 90° through 0/90/180/270° independently of Android auto-rotate;
- marquee exposes **Slower / Faster** and Pause/Resume;
- sequences expose Pause/Resume;
- **STOP** freezes the actual final presentation settings and commits the canonical result.

Android Back cancels an uncommitted presentation rather than falsely reporting it as completed.

## Display target abstraction

v0.1 implements `local_screen` only. `display_target` is nevertheless explicit in the result contract. The method IDs describe display semantics rather than Android rendering technology, so future secondary displays, MethodMesh Devices, ESP32 matrices, browser displays or network signs can implement additional targets without replacing the canonical methods.

## Inputs

Common: `text`, `alignment`, `content_rotation`, `text_scale`, `high_brightness`.

Marquee adds `speed` and `direction`. Sequence adds `duration_seconds` and `loop`; one nonblank input line is one message.

All declared settings participate in the standard MethodMesh fixed-vs-runtime Preset mechanism. Runtime settings remain visible when the caller marks them Ask when run; fixed settings may be hidden by the host through `settingShouldBeShown`.

## Canonical outputs

`display_status`, `display_result`, `display_mode`, `display_text`, `display_target`, `display_alignment`, `display_content_rotation`, `display_text_scale`, `display_speed`, `display_direction`, `display_duration_seconds`, `display_loop`, `display_started_time_iso`, `display_stopped_time_iso`, `display_elapsed_ms`, `display_audit_json`, `display_error`.

`display_result` is the compact human-readable beef and equals the displayed message text. The canonical FULL execution envelope remains supplied by MethodMesh infrastructure as `methodmesh_full_json` when requested.

## ODK / external workflow

Display is inherently interactive when the requested target is the phone screen:

```text
ODK / Enketo / external caller
  -> display.*
  -> full-screen presentation
  -> operator STOP
  -> canonical result
  -> caller
```

The external caller owns closeout after Commit. MethodMesh must not strand the operator on a generic result page or create an extra local archive merely because the capability was externally invoked.

A representative grouped call is conceptually:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='display.static',
  input_text=${message},
  input_content_rotation='0',
  input_text_scale='1.0',
  input_high_brightness='true',
  input_payload_mode='FULL',
  return_mode='flat'
)
```

## Safety and accessibility

The initial module does not implement rapid flashing/strobing. Marquee speed is bounded. Controls remain touch-sized and horizontally scroll rather than being compressed to microscopic controls. Content rotation is explicit so a phone placed on a table can present text to a person opposite the operator.

## State and persistence

Editable configuration and active presentation settings use saveable UI state. Display does not maintain a durable message archive. A committed execution is returned through the normal MethodMesh lifecycle; explicit Save/Share behaviour remains owned by shared result infrastructure.

## Future extension seam

External display support should add a target/provider layer beneath these method contracts, not create parallel methods such as `esp32.showText` or `cast.showText`. Device discovery, trust, transport and provisioning belong to the MethodMesh Devices architecture; Display owns the presentation semantics.
