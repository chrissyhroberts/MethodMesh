# Display module validation and review

## Pass A — architecture

- Self-contained module-owned implementation; no core patch required.
- Five stable canonical method IDs with matching native capability screens.
- Same method inventory feeds direct use, Presets, Protocols and external/ODK execution.
- Explicit module and capability version/maturity metadata.
- `local_screen` is an output target value, not embedded in the method IDs.

## Pass B — native UX

- Full-screen black presentation surface prioritises across-room legibility.
- Screen is kept awake only while presentation is active.
- Optional temporary high brightness restores the prior window brightness on disposal.
- Live A−/A+, pinch resize, Fit and 90° rotation are available without leaving the display.
- Marquee speed/direction and sequence timing are capability-specific rather than global UI clutter.
- Back cancels; STOP commits.
- Working configuration is not silently mutated after Commit.

## Pass C — lifecycle and outputs

- STOP records start/stop ISO timestamps and monotonic elapsed duration.
- Final live scale/rotation/speed settings are frozen into the result.
- External automatic-return uses the supplied `onConfirmed` callback.
- No module-local output archive is created.
- Output fields are declared once and remain transport-projectable.

## Pass D — safety / robustness review

Revision changes made after the first implementation pass:

1. corrected `MethodObjectType` to a currently supported enum value (`Workflow`);
2. corrected `FloatSetting` literals to Float values matching the current host signature;
3. moved Box-only alignment to the Box call site;
4. made the live control row horizontally scrollable rather than shrinking touch targets;
5. wired `high_brightness` through the actual presentation path and restore logic;
6. retained cancellation semantics on Android Back instead of treating Back as successful completion.

## Build status

The implementation was written against current `master` host signatures inspected from `MethodMeshModule.kt`, `MethodSetting.kt`, current capability-screen patterns and current method/result patterns. A complete Android/Gradle build was not runnable in this execution environment because the repository/Android SDK is not mounted locally. The module should therefore receive the normal project build (`./gradlew :app:compileDebugKotlin :app:testDebugUnitTest`) after drop-in.

The example XLSForm is a module-owned showcase of the five canonical method contracts. It should receive the project's normal XLSForm validation/deployment test before Production maturity.
