package com.example.methodmesh.modules.display

import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONObject
import java.time.Instant

object DisplayFields {
    const val STATUS = "display_status"
    const val RESULT = "display_result"
    const val MODE = "display_mode"
    const val TEXT = "display_text"
    const val TARGET = "display_target"
    const val ALIGNMENT = "display_alignment"
    const val ROTATION = "display_content_rotation"
    const val TEXT_SCALE = "display_text_scale"
    const val SPEED = "display_speed"
    const val DIRECTION = "display_direction"
    const val DURATION_SECONDS = "display_duration_seconds"
    const val LOOP = "display_loop"
    const val STARTED_TIME_ISO = "display_started_time_iso"
    const val STOPPED_TIME_ISO = "display_stopped_time_iso"
    const val ELAPSED_MS = "display_elapsed_ms"
    const val AUDIT_JSON = "display_audit_json"
    const val ERROR = "display_error"
    val outputs = listOf(STATUS, RESULT, MODE, TEXT, TARGET, ALIGNMENT, ROTATION, TEXT_SCALE, SPEED, DIRECTION,
        DURATION_SECONDS, LOOP, STARTED_TIME_ISO, STOPPED_TIME_ISO, ELAPSED_MS, AUDIT_JSON, ERROR)
}

sealed class DisplayMethod(
    final override val id: String,
    val mode: String,
    val title: String,
    val help: String,
    val defaultText: String,
) : As100Method {
    private val methodVersion = "0.1.0"
    final override val ref = ArchitectureRef(ArchitectureId(id), "Method", title)
    final override val descriptor = MethodDescriptor(
        id = ArchitectureId(id), methodType = MethodObjectType.Workflow, name = title, version = methodVersion,
        description = help, outputs = DisplayFields.outputs, graphOutputs = listOf(id),
        parameters = mapOf("category" to "Development", "status" to "Development", "interaction" to "interactive")
    )
    final override val contract = MethodContract(method = ref, producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation), producedFields = descriptor.outputs, producedGraphOutputs = descriptor.graphOutputs)
    final override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    /** Headless execution records the requested display specification. Actual local-screen presentation is interactive. */
    final override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult {
        val values = values(request.context, startedIso = "", stoppedIso = Instant.now().toString(), elapsedMs = 0L)
        return result(request, values, InvocationContext.from(request.context))
    }

    fun values(settings: Map<String, String>, startedIso: String, stoppedIso: String, elapsedMs: Long): Map<String, String> {
        val text = (settings["text"] ?: settings["input_text"] ?: defaultText).trim()
        if (text.isBlank()) return failure(settings, "Message must not be blank.")
        val alignment = settings.value("alignment", "center")
        val rotation = settings.value("content_rotation", "0").toIntOrNull()?.let { ((it % 360) + 360) % 360 } ?: 0
        val scale = settings.value("text_scale", "1.0").toFloatOrNull()?.coerceIn(0.25f, 4f) ?: 1f
        val speed = settings.value("speed", "1.0").toFloatOrNull()?.coerceIn(0.25f, 4f) ?: 1f
        val direction = settings.value("direction", "left")
        val duration = settings.value("duration_seconds", "3").toIntOrNull()?.coerceIn(1, 300) ?: 3
        val loop = settings.value("loop", "true").toBooleanStrictOrNull() ?: true
        val audit = JSONObject().put("method_id", id).put("method_version", methodVersion).put("mode", mode)
            .put("target", "local_screen").put("text", text).put("alignment", alignment).put("content_rotation", rotation)
            .put("text_scale", scale).put("speed", speed).put("direction", direction).put("duration_seconds", duration)
            .put("loop", loop).put("started_time_iso", startedIso).put("stopped_time_iso", stoppedIso).put("elapsed_ms", elapsedMs)
        return linkedMapOf(
            DisplayFields.STATUS to "succeeded", DisplayFields.RESULT to text, DisplayFields.MODE to mode, DisplayFields.TEXT to text,
            DisplayFields.TARGET to "local_screen", DisplayFields.ALIGNMENT to alignment, DisplayFields.ROTATION to rotation.toString(),
            DisplayFields.TEXT_SCALE to scale.toString(), DisplayFields.SPEED to if (mode == "marquee") speed.toString() else "",
            DisplayFields.DIRECTION to if (mode == "marquee") direction else "", DisplayFields.DURATION_SECONDS to if (mode == "sequence") duration.toString() else "",
            DisplayFields.LOOP to if (mode == "sequence") loop.toString() else "", DisplayFields.STARTED_TIME_ISO to startedIso,
            DisplayFields.STOPPED_TIME_ISO to stoppedIso, DisplayFields.ELAPSED_MS to elapsedMs.toString(), DisplayFields.AUDIT_JSON to audit.toString(), DisplayFields.ERROR to ""
        )
    }

    private fun failure(settings: Map<String, String>, error: String) = DisplayFields.outputs.associateWith { "" }.toMutableMap().apply {
        this[DisplayFields.STATUS] = "failed"; this[DisplayFields.MODE] = mode; this[DisplayFields.TEXT] = settings.value("text", "")
        this[DisplayFields.TARGET] = "local_screen"; this[DisplayFields.ERROR] = error
    }

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[DisplayFields.STATUS] == "succeeded"
        val provenance = ProvenanceContext("methodmesh.display", id, methodVersion)
        val observation = Observation(phenomenon = id, subject = null, values = values, temporalContext = request.temporalContext, provenance = provenance)
        val entity = Entity(ArchitectureId("DisplayPresentation:${System.currentTimeMillis()}"), "DisplayPresentation", temporalContext = request.temporalContext)
        val transformation = Transformation(action = id, method = ref, outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, temporalContext = request.temporalContext, provenance = provenance)
        return As100ExecutionEngine.complete(request, if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOf(entity), observations = listOf(observation), transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf(DisplayFields.ERROR to values[DisplayFields.ERROR].orEmpty())).withInvocationContext(invocation)
    }

    private fun Map<String, String>.value(key: String, default: String) = this[key] ?: this["input_$key"] ?: default
}

object StaticDisplayMethod : DisplayMethod("display.static", "static", "Static sign", "Show one large full-screen message until stopped.", "HELLO WORLD") { const val ID = "display.static" }
object MarqueeDisplayMethod : DisplayMethod("display.marquee", "marquee", "Scrolling marquee", "Scroll a large message continuously across the screen.", "HELLO WORLD") { const val ID = "display.marquee" }
object BoardDisplayMethod : DisplayMethod("display.board", "board", "Message board", "Show a multi-line message fitted to the screen.", "PLEASE WAIT\nWE WILL BE WITH YOU SHORTLY") { const val ID = "display.board" }
object CodeDisplayMethod : DisplayMethod("display.code", "code", "Code / number", "Show a short code or number at maximum readable size.", "A123") { const val ID = "display.code" }
object SequenceDisplayMethod : DisplayMethod("display.sequence", "sequence", "Message sequence", "Show newline-separated messages in a timed sequence.", "PLEASE WAIT\nROOM 3\nTHANK YOU") { const val ID = "display.sequence" }
object DisplayMethods { val all = listOf(StaticDisplayMethod, MarqueeDisplayMethod, BoardDisplayMethod, CodeDisplayMethod, SequenceDisplayMethod) }
