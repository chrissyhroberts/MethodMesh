package com.example.methodmesh.modules.display

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

/** Local and future external signage/display capabilities. */
object DisplayModule : MethodMeshModule {
    override val moduleId = "display"
    override val displayName = "Display"
    override val version = "0.1.0"
    override val summary = "Full-screen signs, scrolling marquees, message boards, codes and timed message sequences."
    override val iconKey = "display"

    override fun as100Methods() = DisplayMethods.all

    override fun capabilityScreens() = DisplayMethods.all.map { DisplayCapabilityScreen(it) }

    override fun rilBindings() = listOf(
        RilBinding("show sign", StaticDisplayMethod.ID, "Show a large static full-screen message"),
        RilBinding("show message", StaticDisplayMethod.ID, "Show a large static full-screen message"),
        RilBinding("scroll message", MarqueeDisplayMethod.ID, "Scroll a large message across the screen"),
        RilBinding("show message board", BoardDisplayMethod.ID, "Show a large multi-line message board"),
        RilBinding("show code", CodeDisplayMethod.ID, "Show a very large number or short code"),
        RilBinding("show message sequence", SequenceDisplayMethod.ID, "Show a timed sequence of messages")
    )

    override fun capabilitySettings() = DisplayMethods.all.associate { method ->
        method.id to buildList {
            add(MethodSetting.TextSetting("text", if (method.id == SequenceDisplayMethod.ID) "Messages (one per line)" else "Message", defaultValue = method.defaultText))
            add(MethodSetting.ChoiceSetting("alignment", "Alignment", defaultValue = "center", choices = listOf("start", "center", "end")))
            add(MethodSetting.ChoiceSetting("content_rotation", "Content rotation", defaultValue = "0", choices = listOf("0", "90", "180", "270")))
            add(MethodSetting.FloatSetting("text_scale", "Initial text scale", defaultValue = 1f, minimum = 0.25f, maximum = 4f))
            add(MethodSetting.BooleanSetting("high_brightness", "Use high brightness while showing", defaultValue = true))
            if (method.id == MarqueeDisplayMethod.ID) {
                add(MethodSetting.FloatSetting("speed", "Marquee speed", defaultValue = 1f, minimum = 0.25f, maximum = 4f))
                add(MethodSetting.ChoiceSetting("direction", "Direction", defaultValue = "left", choices = listOf("left", "right")))
            }
            if (method.id == SequenceDisplayMethod.ID) {
                add(MethodSetting.IntSetting("duration_seconds", "Seconds per message", defaultValue = 3, minimum = 1, maximum = 300))
                add(MethodSetting.BooleanSetting("loop", "Loop sequence", defaultValue = true))
            }
        }
    }
}
