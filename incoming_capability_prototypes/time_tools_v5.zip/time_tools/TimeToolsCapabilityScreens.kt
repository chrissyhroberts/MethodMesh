package com.example.methodmesh.modules.time_tools

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.modules.time_tools.countdown.CountdownCapabilityScreen
import com.example.methodmesh.modules.time_tools.countdown.CountdownCapabilityView
import com.example.methodmesh.modules.time_tools.interval.IntervalCapability
import com.example.methodmesh.modules.time_tools.notifications.TimeToolsTimerRuntime
import com.example.methodmesh.modules.time_tools.stopwatch.StopwatchCapabilityScreen
import com.example.methodmesh.modules.time_tools.stopwatch.StopwatchCapabilityView
import com.example.methodmesh.modules.time_tools.timing.AlertProfile
import com.example.methodmesh.modules.time_tools.timing.TimeFormatting
import com.example.methodmesh.modules.time_tools.until.UntilTimeCapability
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.time.Instant
import java.time.ZoneId
import kotlinx.coroutines.delay

/**
 * Host adapters for the module-owned timer surfaces.
 *
 * These are deliberately separate from the optional Time Tools dashboard. They register
 * canonical capability IDs directly with MethodMesh so dashboard, presets, protocols and
 * external/ODK launches all resolve the same capability contract.
 */
object CountdownMethodMeshCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100CountdownMethod.ID
    override val title = "Countdown"
    override val description = "Count down a duration with quick adjustments and a clear completion result."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val initialDuration = context.action.settings.longValue("duration_ms")?.coerceAtLeast(1_000L) ?: 300_000L
        var generation by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        val controller = remember(generation, initialDuration) { CountdownCapabilityScreen(initialDuration) }
        var result by remember(generation) { mutableStateOf<ExecutionResult?>(null) }

        LaunchedEffect(controller, context.startsImmediately) {
            if (context.startsImmediately && controller.uiState().canStart) controller.start()
            var lastDuration = -1L
            while (result == null) {
                val state = controller.uiState()
                if (state.requestedDurationMs != lastDuration) {
                    lastDuration = state.requestedDurationMs
                    context.onSettingsChanged(mapOf("duration_ms" to state.requestedDurationMs.toString()))
                }
                controller.resultPayload()?.let { payload ->
                    val request = As100CountdownMethod.request(
                        action = context.action.canonicalId,
                        context = context.request.invocationContext.asMap(context.action.canonicalId) +
                            context.action.settings + mapOf("duration_ms" to state.requestedDurationMs.toString()),
                        signals = emptyList(),
                        inputs = emptyList()
                    )
                    result = As100CountdownMethod.result(
                        request,
                        As100CountdownMethod.successfulValues(payload),
                        context.request.invocationContext
                    )
                }
                delay(100L)
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { generation += 1; result = null },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = {
                controller.cancel()
                onCancel()
            }
        ) {
            AndroidView(
                factory = { androidContext -> CountdownCapabilityView(androidContext, controller) },
                update = { it.render() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

object StopwatchMethodMeshCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100StopwatchMethod.ID
    override val title = "Stopwatch"
    override val description = "Measure elapsed time and laps with an explicit Stop/Commit boundary."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        var generation by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        val controller = remember(generation) { StopwatchCapabilityScreen() }
        var result by remember(generation) { mutableStateOf<ExecutionResult?>(null) }

        LaunchedEffect(controller, context.startsImmediately) {
            if (context.startsImmediately && controller.uiState().canStart) controller.start()
            while (result == null) {
                controller.resultPayload()?.let { payload ->
                    val request = As100StopwatchMethod.request(
                        action = context.action.canonicalId,
                        context = context.request.invocationContext.asMap(context.action.canonicalId) + context.action.settings,
                        signals = emptyList(),
                        inputs = emptyList()
                    )
                    result = As100StopwatchMethod.result(
                        request,
                        As100StopwatchMethod.successfulValues(payload),
                        context.request.invocationContext
                    )
                }
                delay(80L)
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { generation += 1; result = null },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = {
                controller.cancel()
                onCancel()
            }
        ) {
            AndroidView(
                factory = { androidContext -> StopwatchCapabilityView(androidContext, controller) },
                update = { it.render() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

object UntilMethodMeshCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100UntilMethod.ID
    override val title = "Until"
    override val description = "Schedule a durable countdown to an absolute target or anchor + day offset + local time."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val runtime = remember { TimeToolsTimerRuntime(androidContext) }
        var targetMode by rememberSaveable { mutableStateOf(context.action.settings.stringValue("target_mode") ?: "absolute") }
        var targetTimestamp by rememberSaveable { mutableStateOf(context.action.settings.stringValue("target_timestamp").orEmpty()) }
        var anchorTimestamp by rememberSaveable { mutableStateOf(context.action.settings.stringValue("anchor_timestamp").orEmpty()) }
        var dayOffset by rememberSaveable { mutableStateOf(context.action.settings.stringValue("day_offset") ?: "0") }
        var localTime by rememberSaveable { mutableStateOf(context.action.settings.stringValue("local_time") ?: "21:00") }
        var zoneId by rememberSaveable { mutableStateOf(context.action.settings.stringValue("zone_id").orEmpty()) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("Ready") }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun currentSettings() = mapOf(
            "target_mode" to targetMode,
            "target_timestamp" to targetTimestamp,
            "anchor_timestamp" to anchorTimestamp,
            "day_offset" to dayOffset,
            "local_time" to localTime,
            "zone_id" to zoneId
        )

        fun schedule() {
            val settings = currentSettings()
            runCatching {
                val resolvedZone = zoneId.ifBlank { ZoneId.systemDefault().id }
                val target = if (targetMode == "anchor_offset_local_time") {
                    UntilTimeCapability.daysAfterAnchorAtLocalTime(
                        anchorTimestamp = anchorTimestamp.ifBlank { Instant.now().toString() },
                        dayOffset = dayOffset.toIntOrNull() ?: 0,
                        localTime = localTime,
                        zoneId = resolvedZone
                    )
                } else {
                    targetTimestamp.ifBlank { error("Enter a target timestamp") }
                }
                val snapshot = UntilTimeCapability.execute(target)
                val started = runtime.startUntil(
                    target = Instant.parse(target),
                    label = context.action.settings.stringValue("label").orEmpty().ifBlank { "Timer" },
                    zoneId = resolvedZone,
                    alertProfile = context.action.settings.alertProfile(),
                    showOngoing = context.action.settings.boolValue("notify_ongoing", true),
                    ongoingLockScreen = context.action.settings.boolValue("lock_screen", true)
                )
                val core = snapshot.toMutableMap().apply {
                    this[TimeToolsFields.TIMER_ID] = started.timerId
                    this[TimeToolsFields.EXACT_ALERT_SCHEDULED] = started.exactAlertScheduled
                    this[TimeToolsFields.COMPLETION_STATUS] = "scheduled"
                }
                val request = As100UntilMethod.request(
                    action = context.action.canonicalId,
                    context = context.request.invocationContext.asMap(context.action.canonicalId) + context.action.settings + settings,
                    signals = emptyList(),
                    inputs = emptyList()
                )
                result = As100UntilMethod.result(
                    request,
                    As100UntilMethod.successfulValues(core),
                    context.request.invocationContext
                )
                status = started.diagnostic ?: "Scheduled"
            }.onFailure { error ->
                status = error.message ?: "Unable to schedule timer"
            }
        }

        LaunchedEffect(currentSettings()) { context.onSettingsChanged(currentSettings()) }
        LaunchedEffect(context.startsImmediately, context.action.settings) {
            if (context.startsImmediately && !launched) {
                launched = true
                schedule()
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { result = null; schedule() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text("Target mode", style = MaterialTheme.typography.labelLarge)
            Button(
                onClick = { targetMode = if (targetMode == "absolute") "anchor_offset_local_time" else "absolute" },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (targetMode == "absolute") "Absolute timestamp" else "Anchor + day offset + local time") }
            Spacer(Modifier.height(8.dp))
            if (targetMode == "absolute") {
                OutlinedTextField(targetTimestamp, { targetTimestamp = it }, label = { Text("Target ISO timestamp") }, modifier = Modifier.fillMaxWidth())
            } else {
                OutlinedTextField(anchorTimestamp, { anchorTimestamp = it }, label = { Text("Anchor timestamp (blank = now)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(dayOffset, { dayOffset = it.filter(Char::isDigit) }, label = { Text("Day offset") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(localTime, { localTime = it }, label = { Text("Local time (HH:MM)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(zoneId, { zoneId = it }, label = { Text("Timezone (blank = device)") }, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = ::schedule, modifier = Modifier.fillMaxWidth()) { Text("Start timer") }
            Text(status, style = MaterialTheme.typography.bodySmall)
        }
    }
}

object IntervalMethodMeshCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100IntervalMethod.ID
    override val title = "Interval timer"
    override val description = "Run a repeated two-phase interval programme."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val runtime = remember { TimeToolsTimerRuntime(androidContext) }
        var aLabel by rememberSaveable { mutableStateOf(context.action.settings.stringValue("phase_a_label") ?: "Work") }
        var aMs by rememberSaveable { mutableStateOf(context.action.settings.stringValue("phase_a_duration_ms") ?: "60000") }
        var bLabel by rememberSaveable { mutableStateOf(context.action.settings.stringValue("phase_b_label") ?: "Rest") }
        var bMs by rememberSaveable { mutableStateOf(context.action.settings.stringValue("phase_b_duration_ms") ?: "60000") }
        var cycles by rememberSaveable { mutableStateOf(context.action.settings.stringValue("cycles") ?: "1") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("Ready") }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun currentSettings() = mapOf(
            "phase_a_label" to aLabel,
            "phase_a_duration_ms" to aMs,
            "phase_b_label" to bLabel,
            "phase_b_duration_ms" to bMs,
            "cycles" to cycles
        )

        fun start() {
            runCatching {
                val count = cycles.toIntOrNull()?.coerceAtLeast(1) ?: 1
                val first = aMs.toLongOrNull()?.coerceAtLeast(1_000L) ?: 60_000L
                val second = bMs.toLongOrNull()?.coerceAtLeast(1_000L) ?: 60_000L
                val program = IntervalCapability.buildProgram(listOf(aLabel, bLabel), listOf(first, second), count)
                val total = program.totalDurationMs
                val started = runtime.startInterval(
                    totalDurationMs = total,
                    label = context.action.settings.stringValue("label").orEmpty().ifBlank { "Interval timer" },
                    alertProfile = context.action.settings.alertProfile(),
                    showOngoing = context.action.settings.boolValue("notify_ongoing", true),
                    ongoingLockScreen = context.action.settings.boolValue("lock_screen", true)
                )
                val core = linkedMapOf<String, Any?>(
                    TimeToolsFields.FORMATTED_DURATION to TimeFormatting.duration(total),
                    TimeToolsFields.DURATION_MS to total,
                    TimeToolsFields.CONFIGURED_CYCLES to count,
                    TimeToolsFields.COMPLETED_CYCLES to 0,
                    TimeToolsFields.CURRENT_PHASE to aLabel,
                    TimeToolsFields.COMPLETION_STATUS to "scheduled",
                    TimeToolsFields.TIMER_ID to started.timerId,
                    TimeToolsFields.EXACT_ALERT_SCHEDULED to started.exactAlertScheduled
                )
                val request = As100IntervalMethod.request(
                    action = context.action.canonicalId,
                    context = context.request.invocationContext.asMap(context.action.canonicalId) + context.action.settings + currentSettings(),
                    signals = emptyList(),
                    inputs = emptyList()
                )
                result = As100IntervalMethod.result(request, As100IntervalMethod.successfulValues(core), context.request.invocationContext)
                status = started.diagnostic ?: "Started"
            }.onFailure { status = it.message ?: "Unable to start interval timer" }
        }

        LaunchedEffect(currentSettings()) { context.onSettingsChanged(currentSettings()) }
        LaunchedEffect(context.startsImmediately, context.action.settings) {
            if (context.startsImmediately && !launched) {
                launched = true
                start()
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
            onBack = onBack,
            onRetry = { result = null; start() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            OutlinedTextField(aLabel, { aLabel = it }, label = { Text("First phase") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(aMs, { aMs = it.filter(Char::isDigit) }, label = { Text("First duration (ms)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(bLabel, { bLabel = it }, label = { Text("Second phase") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(bMs, { bMs = it.filter(Char::isDigit) }, label = { Text("Second duration (ms)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cycles, { cycles = it.filter(Char::isDigit) }, label = { Text("Cycles") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Button(onClick = ::start, modifier = Modifier.fillMaxWidth()) { Text("Start intervals") }
            Text(status, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun Map<String, String>.stringValue(key: String): String? =
    (this[key] ?: this["input_$key"])?.takeIf { it.isNotBlank() }

private fun Map<String, String>.longValue(key: String): Long? = stringValue(key)?.toLongOrNull()

private fun Map<String, String>.boolValue(key: String, default: Boolean): Boolean =
    stringValue(key)?.toBooleanStrictOrNull() ?: default

private fun Map<String, String>.alertProfile(): AlertProfile = AlertProfile(
    sound = boolValue("alert_sound", true),
    vibration = boolValue("alert_vibration", true),
    lights = boolValue("alert_lights", true),
    showOnLockScreen = boolValue("lock_screen", true),
    highPriority = boolValue("alert_high_priority", true)
)
