package com.example.methodmesh.modules.time_tools

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

/**
 * First-class MethodMesh registration for the Time Tools module.
 *
 * IMPORTANT: the module index generator discovers objects whose source file ends in
 * `Module.kt` and whose declaration is `object <Name>Module : ...`.  Keep this object
 * as the canonical module entry point; do not replace it with a passive definition DTO.
 */
object TimeToolsModule : MethodMeshModule {
    override val moduleId = "time_tools"
    override val displayName = "Time Tools"
    override val summary = "Countdowns, stopwatches, interval timing, target-time timers and duration calculations."
    override val iconKey = "schedule"

    override fun as100Methods() = listOf(
        As100CountdownMethod,
        As100StopwatchMethod,
        As100IntervalMethod,
        As100UntilMethod,
        As100ElapsedMethod,
        As100DurationCalculateMethod
    )

    override fun rilBindings() = listOf(
        RilBinding("start countdown", As100CountdownMethod.ID, "Start a countdown timer"),
        RilBinding("start stopwatch", As100StopwatchMethod.ID, "Start a stopwatch"),
        RilBinding("start interval timer", As100IntervalMethod.ID, "Start an interval timer"),
        RilBinding("count down until", As100UntilMethod.ID, "Count down to a target time"),
        RilBinding("calculate elapsed time", As100ElapsedMethod.ID, "Calculate elapsed time between timestamps"),
        RilBinding("calculate duration", As100DurationCalculateMethod.ID, "Add or subtract durations")
    )

    /*
     * These are canonical capability screens, independent of the optional Time Tools
     * dashboard. Elapsed-time and duration arithmetic are intentionally simple enough to use
     * the repository's generic capability surface; all six methods remain independently
     * registered for presets, protocols and external/ODK execution.
     */
    override fun capabilityScreens() = listOf(
        CountdownMethodMeshCapabilityScreen,
        StopwatchMethodMeshCapabilityScreen,
        IntervalMethodMeshCapabilityScreen,
        UntilMethodMeshCapabilityScreen
    )

    override fun capabilitySettings() = mapOf(
        As100CountdownMethod.ID to countdownSettings(),
        As100StopwatchMethod.ID to stopwatchSettings(),
        As100IntervalMethod.ID to intervalSettings(),
        As100UntilMethod.ID to untilSettings(),
        As100ElapsedMethod.ID to elapsedSettings(),
        As100DurationCalculateMethod.ID to durationCalculatorSettings()
    )

    private fun commonNotificationSettings(includeDueAlert: Boolean = true): List<MethodSetting> = buildList {
        add(MethodSetting.TextSetting(
            id = "label",
            label = "Timer label",
            description = "Optional human-readable label shown with the timer.",
            group = "Display",
            defaultValue = ""
        ))
        add(MethodSetting.BooleanSetting(
            id = "notify_ongoing",
            label = "Show ongoing notification",
            description = "Show the active timer as a persistent notification.",
            group = "Notifications",
            defaultValue = true
        ))
        add(MethodSetting.BooleanSetting(
            id = "lock_screen",
            label = "Show on lock screen",
            description = "Allow the ongoing timer status to be visible on the lock screen, subject to Android notification settings.",
            group = "Notifications",
            defaultValue = true
        ))
        if (includeDueAlert) {
            add(MethodSetting.BooleanSetting(
                id = "alert_sound",
                label = "Sound when due",
                group = "Due alert",
                defaultValue = true
            ))
            add(MethodSetting.BooleanSetting(
                id = "alert_vibration",
                label = "Vibrate when due",
                group = "Due alert",
                defaultValue = true
            ))
            add(MethodSetting.BooleanSetting(
                id = "alert_lights",
                label = "Notification light when due",
                description = "Used where the device and Android notification channel support a notification light.",
                group = "Due alert",
                defaultValue = true
            ))
            add(MethodSetting.BooleanSetting(
                id = "alert_high_priority",
                label = "High-priority due alert",
                group = "Due alert",
                defaultValue = true
            ))
        }
    }

    private fun countdownSettings(): List<MethodSetting> = listOf(
        MethodSetting.IntSetting(
            id = "duration_ms",
            label = "Duration",
            description = "Countdown duration in milliseconds. The purpose-built timer UI presents human-friendly minute/second controls.",
            group = "Timer",
            defaultValue = 300_000,
            minimum = 1_000,
            maximum = 86_400_000,
            step = 1_000,
            unit = "ms"
        )
    ) + commonNotificationSettings()

    private fun stopwatchSettings(): List<MethodSetting> = commonNotificationSettings(includeDueAlert = false)

    private fun intervalSettings(): List<MethodSetting> = listOf(
        MethodSetting.TextSetting(
            id = "phase_a_label",
            label = "First phase label",
            group = "Intervals",
            defaultValue = "Work"
        ),
        MethodSetting.IntSetting(
            id = "phase_a_duration_ms",
            label = "First phase duration",
            group = "Intervals",
            defaultValue = 60_000,
            minimum = 1_000,
            maximum = 86_400_000,
            step = 1_000,
            unit = "ms"
        ),
        MethodSetting.TextSetting(
            id = "phase_b_label",
            label = "Second phase label",
            group = "Intervals",
            defaultValue = "Rest"
        ),
        MethodSetting.IntSetting(
            id = "phase_b_duration_ms",
            label = "Second phase duration",
            group = "Intervals",
            defaultValue = 60_000,
            minimum = 1_000,
            maximum = 86_400_000,
            step = 1_000,
            unit = "ms"
        ),
        MethodSetting.IntSetting(
            id = "cycles",
            label = "Cycles",
            group = "Intervals",
            defaultValue = 1,
            minimum = 1,
            maximum = 10_000,
            step = 1
        )
    ) + commonNotificationSettings()

    private fun untilSettings(): List<MethodSetting> = listOf(
        MethodSetting.ChoiceSetting(
            id = "target_mode",
            label = "Target mode",
            description = "Use an absolute timestamp or calculate a local clock time a number of calendar days after an anchor.",
            group = "Target",
            defaultValue = "absolute",
            choices = listOf("absolute", "anchor_offset_local_time")
        ),
        MethodSetting.TextSetting(
            id = "target_timestamp",
            label = "Target timestamp",
            description = "ISO-8601 instant used in absolute mode.",
            group = "Target",
            defaultValue = ""
        ),
        MethodSetting.TextSetting(
            id = "anchor_timestamp",
            label = "Anchor timestamp",
            description = "ISO-8601 instant used as day zero for offset mode. A preset/widget may supply the launch instant at runtime.",
            group = "Target",
            defaultValue = ""
        ),
        MethodSetting.IntSetting(
            id = "day_offset",
            label = "Day offset",
            group = "Target",
            defaultValue = 0,
            minimum = 0,
            maximum = 3650,
            step = 1,
            unit = "days"
        ),
        MethodSetting.TextSetting(
            id = "local_time",
            label = "Local time",
            description = "24-hour HH:MM local clock time, for example 21:00.",
            group = "Target",
            defaultValue = "21:00"
        ),
        MethodSetting.TextSetting(
            id = "zone_id",
            label = "Timezone",
            description = "Optional IANA timezone such as Europe/London. Blank uses the device timezone.",
            group = "Target",
            defaultValue = ""
        )
    ) + commonNotificationSettings()

    private fun elapsedSettings(): List<MethodSetting> = listOf(
        MethodSetting.TextSetting(
            id = "start_timestamp",
            label = "Start timestamp",
            description = "ISO-8601 instant.",
            defaultValue = ""
        ),
        MethodSetting.TextSetting(
            id = "end_timestamp",
            label = "End timestamp",
            description = "ISO-8601 instant.",
            defaultValue = ""
        )
    )

    private fun durationCalculatorSettings(): List<MethodSetting> = listOf(
        MethodSetting.IntSetting(
            id = "a_ms",
            label = "First duration",
            defaultValue = 0,
            minimum = 0,
            maximum = Int.MAX_VALUE,
            step = 1,
            unit = "ms"
        ),
        MethodSetting.IntSetting(
            id = "b_ms",
            label = "Second duration",
            defaultValue = 0,
            minimum = 0,
            maximum = Int.MAX_VALUE,
            step = 1,
            unit = "ms"
        ),
        MethodSetting.ChoiceSetting(
            id = "operation",
            label = "Operation",
            defaultValue = "add",
            choices = listOf("add", "subtract")
        )
    )
}
