# Repository integration notes

The module no longer assumes Compose, lifecycle ViewModel, coroutines, JUnit or AndroidX notification APIs.

The module is now bound directly to the current MethodMesh module/runtime interfaces:

- `TimeToolsModule : MethodMeshModule` is discoverable by the generated module index;
- all six canonical `As100Method` objects are registered independently;
- countdown, stopwatch, interval and until have module-owned `CapabilityScreenSpec` adapters;
- elapsed-time and duration arithmetic can use the generic capability surface;
- settings are exposed through `MethodSetting` for presets and runtime-input policy.

Repository admission still requires merging the declarations in `ANDROID_MANIFEST_SNIPPET.xml` into the app manifest so durable alarms/notifications and reboot restoration are available.

## Generic MethodSetting mapping

Expose these notification settings on timer-capable methods (`time.countdown`, `time.stopwatch`, `time.interval`, `time.until`):

- Boolean: ongoing notification
- Boolean: show on lock screen
- Boolean: due sound
- Boolean: due vibration
- Boolean: due notification light
- Boolean: high-priority due notification

For `time.until`, also expose:

- target mode: absolute timestamp OR anchor+offset+local-time
- runtime/fixed anchor policy
- integer day offset
- local time
- optional timezone

A preset started from a widget must call the same capability method/runtime directly. Do not route widget execution through `TimeToolsDashboardScreen`.

## Exact alarms

The runtime checks `AlarmManager.canScheduleExactAlarms()` on Android 12+. If unavailable, it uses `setAndAllowWhileIdle()` and reports approximate scheduling. The host settings/runtime surface should provide a generic way to open Android's Alarms & reminders special-access screen when a user requires exact delivery; do not claim an exact alert when access is absent.

## Lock-screen privacy

Ongoing timers default to public time/label visibility because their purpose is glanceable timing. For sensitive labels, presets can disable lock-screen display or use a generic label. Due alerts default to private lock-screen content unless explicitly configured otherwise.
