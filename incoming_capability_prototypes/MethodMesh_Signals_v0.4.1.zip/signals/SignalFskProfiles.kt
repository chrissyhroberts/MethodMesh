package com.example.methodmesh.modules.signals

internal data class SignalFskProfile(
    val id: String,
    val label: String,
    val markHz: Double,
    val spaceHz: Double,
    val bitMs: Int
)

internal object SignalFskProfiles {
    val audible: List<SignalFskProfile> = listOf(
        SignalFskProfile("A", "A · 1.2/2.2 kHz", 1200.0, 2200.0, 60),
        SignalFskProfile("B", "B · 1.0/1.8 kHz", 1000.0, 1800.0, 80),
        SignalFskProfile("C", "C · 1.6/2.6 kHz", 1600.0, 2600.0, 60),
        SignalFskProfile("D", "D · 2.2/3.4 kHz", 2200.0, 3400.0, 80)
    )

    val highBand: List<SignalFskProfile> = listOf(
        SignalFskProfile("A", "A · 15/16 kHz", 15000.0, 16000.0, 100),
        SignalFskProfile("B", "B · 16/17 kHz", 16000.0, 17000.0, 100),
        SignalFskProfile("C", "C · 17/18 kHz", 17000.0, 18000.0, 120),
        SignalFskProfile("D", "D · 18/19 kHz", 18000.0, 19000.0, 120)
    )

    fun list(ultrasonic: Boolean): List<SignalFskProfile> = if (ultrasonic) highBand else audible

    fun matching(ultrasonic: Boolean, markHz: Double, spaceHz: Double, bitMs: Int): SignalFskProfile? =
        list(ultrasonic).firstOrNull {
            kotlin.math.abs(it.markHz - markHz) < 1.0 &&
                kotlin.math.abs(it.spaceHz - spaceHz) < 1.0 &&
                it.bitMs == bitMs
        }
}
