package com.example.methodmesh.modules.signals

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import kotlin.math.roundToInt

object SignalFskTransmitCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalFskTransmitMethod.id
    override val title = "Audio FSK transmitter"
    override val description = "Send an error-corrected packet through air or a walkie-talkie audio path."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        AudioFskTransmitUi(context, onBack, onConfirmed, onCancel, ultrasonic = false)
}

object SignalUltrasonicTransmitCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalUltrasonicTransmitMethod.id
    override val title = "Near-ultrasonic transmitter"
    override val description = "Experimentally send an error-corrected packet near the upper end of phone audio bandwidth."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        AudioFskTransmitUi(context, onBack, onConfirmed, onCancel, ultrasonic = true)
}

@Composable
private fun AudioFskTransmitUi(
    context: CapabilityScreenContext,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    ultrasonic: Boolean
) {
    val androidContext = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings = context.action.settings
    val defaultMark = if (ultrasonic) 15000.0 else 1200.0
    val defaultSpace = if (ultrasonic) 16000.0 else 2200.0
    val defaultBit = if (ultrasonic) 100 else 60

    var payload by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("payload", "Hello from MethodMesh")) }
    var robustness by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("robustness", "robust")) }
    var markHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("mark_hz", defaultMark.toString()).toDoubleOrNull()?.coerceIn(200.0, 22000.0) ?: defaultMark) }
    var spaceHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("space_hz", defaultSpace.toString()).toDoubleOrNull()?.coerceIn(200.0, 22000.0) ?: defaultSpace) }
    var bitMs by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("bit_ms", defaultBit.toString()).toIntOrNull()?.let { ((it + 5) / 10 * 10).coerceIn(20, 250) } ?: defaultBit) }
    var pttLeadMs by rememberSaveable(context.action.canonicalId) { mutableStateOf(if (ultrasonic) 0 else settings.signalSetting("ptt_lead_ms", "120").toIntOrNull()?.coerceIn(0, 5000) ?: 120) }
    var repeatCount by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("repeat_count", "2").toIntOrNull()?.coerceIn(1, 20) ?: 2) }
    var messageId by rememberSaveable(context.action.canonicalId) { mutableStateOf(SignalPacketCodec.newMessageId()) }
    var sending by remember { mutableStateOf(false) }
    var cyclesCompleted by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
    var currentProgress by rememberSaveable(context.action.canonicalId) { mutableStateOf("Ready") }
    var status by rememberSaveable(context.action.canonicalId) { mutableStateOf(if (ultrasonic) "Experimental: test the channel on the actual phone pair before relying on it." else "Place the phone speaker near the radio microphone, or use direct acoustic phone-to-phone transfer.") }
    var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
    var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var txJob by remember { mutableStateOf<Job?>(null) }
    val continueFlag = remember { AtomicBoolean(false) }

    // Smaller source shards keep intentionally slow acoustic packets to a manageable duration.
    val encodedAttempt = remember(payload, robustness, messageId) {
        runCatching {
            SignalPacketCodec.encodeText(
                payload,
                SignalPacketCodec.Robustness.from(robustness),
                shardBytes = 48,
                messageId = messageId
            )
        }
    }
    val encoded = encodedAttempt.getOrNull()

    LaunchedEffect(payload, robustness, markHz, spaceHz, bitMs, pttLeadMs, repeatCount) {
        val values = mutableMapOf(
            "payload" to payload,
            "robustness" to robustness,
            "mark_hz" to markHz.roundToInt().toString(),
            "space_hz" to spaceHz.roundToInt().toString(),
            "bit_ms" to bitMs.toString(),
            "repeat_count" to repeatCount.toString()
        )
        if (!ultrasonic) values["ptt_lead_ms"] = pttLeadMs.toString()
        context.onSettingsChanged(values)
    }

    LaunchedEffect(Unit) {
        if (!sending && (status.startsWith("Transmitting", ignoreCase = true) || currentProgress.startsWith("Cycle", ignoreCase = true))) {
            status = if (cyclesCompleted > 0)
                "Transmission paused after screen recreation; $cyclesCompleted complete cycle(s) retained."
            else
                "Transmission paused after screen recreation. Start again when ready."
            currentProgress = "Ready"
        }
    }

    fun stop(userRequested: Boolean = true) {
        continueFlag.set(false)
        txJob?.cancel()
        txJob = null
        sending = false
        if (userRequested) status = if (cyclesCompleted > 0) "Stopped after $cyclesCompleted complete cycle(s)." else "Stopped."
    }

    fun start() {
        val packet = encoded
        if (packet == null || packet.frames.isEmpty()) {
            error = encodedAttempt.exceptionOrNull()?.message ?: "Message could not be encoded."
            return
        }
        if (kotlin.math.abs(markHz - spaceHz) < 80.0) {
            error = "Choose carrier frequencies at least 80 Hz apart."
            return
        }
        stop(userRequested = false)
        error = ""
        cyclesCompleted = 0
        sending = true
        continueFlag.set(true)
        status = if (ultrasonic) "Transmitting high-frequency FSK…" else "Transmitting. Keep PTT held if using a walkie-talkie."
        txJob = scope.launch(Dispatchers.IO) {
            runCatching {
                SignalAudioOutput.playFskFramesBlocking(
                    frames = packet.frames,
                    markHz = markHz,
                    spaceHz = spaceHz,
                    bitMs = bitMs,
                    pttLeadMs = pttLeadMs,
                    cycles = repeatCount,
                    onProgress = { cycle, frame, total ->
                        scope.launch {
                            currentProgress = "Cycle $cycle / $repeatCount • frame $frame / $total"
                            cyclesCompleted = if (frame == total) cycle else (cycle - 1).coerceAtLeast(0)
                        }
                    },
                    shouldContinue = { continueFlag.get() }
                )
            }.onSuccess {
                scope.launch {
                    if (continueFlag.get()) {
                        cyclesCompleted = repeatCount
                        status = "Transmission complete."
                    }
                    sending = false
                    continueFlag.set(false)
                }
            }.onFailure { failure ->
                scope.launch {
                    error = failure.message ?: "Audio transmission failed."
                    sending = false
                    continueFlag.set(false)
                }
            }
        }
    }

    fun commit() {
        val packet = encoded
        if (packet == null || cyclesCompleted <= 0) {
            error = "Complete at least one full transmission cycle before Commit."
            return
        }
        stop(userRequested = false)
        val values = if (ultrasonic) {
            mapOf(
                SignalUltrasonicTransmitFields.RESULT to payload,
                SignalUltrasonicTransmitFields.PAYLOAD to payload,
                SignalUltrasonicTransmitFields.MESSAGE_ID to packet.messageId,
                SignalUltrasonicTransmitFields.FRAME_COUNT to packet.frames.size.toString(),
                SignalUltrasonicTransmitFields.MARK_HZ to markHz.roundToInt().toString(),
                SignalUltrasonicTransmitFields.SPACE_HZ to spaceHz.roundToInt().toString(),
                SignalUltrasonicTransmitFields.BIT_MS to bitMs.toString(),
                SignalUltrasonicTransmitFields.ROBUSTNESS to robustness,
                SignalUltrasonicTransmitFields.CYCLES to cyclesCompleted.toString(),
                SignalUltrasonicTransmitFields.STATUS to "sent",
                SignalUltrasonicTransmitFields.ERROR to ""
            )
        } else {
            mapOf(
                SignalFskTransmitFields.RESULT to payload,
                SignalFskTransmitFields.PAYLOAD to payload,
                SignalFskTransmitFields.MESSAGE_ID to packet.messageId,
                SignalFskTransmitFields.FRAME_COUNT to packet.frames.size.toString(),
                SignalFskTransmitFields.MARK_HZ to markHz.roundToInt().toString(),
                SignalFskTransmitFields.SPACE_HZ to spaceHz.roundToInt().toString(),
                SignalFskTransmitFields.BIT_MS to bitMs.toString(),
                SignalFskTransmitFields.PTT_LEAD_MS to pttLeadMs.toString(),
                SignalFskTransmitFields.ROBUSTNESS to robustness,
                SignalFskTransmitFields.CYCLES to cyclesCompleted.toString(),
                SignalFskTransmitFields.STATUS to "sent",
                SignalFskTransmitFields.ERROR to ""
            )
        }
        committedJson = fieldsJson(values)
        status = "Committed."
        val method = if (ultrasonic) As100SignalUltrasonicTransmitMethod else As100SignalFskTransmitMethod
        val result = signalResult(method, context, values)
        if (context.submitsImmediately) onConfirmed(result)
    }

    DisposableEffect(Unit) { onDispose { stop(userRequested = false) } }

    val committedFields = fieldsFromJson(committedJson)
    val method = if (ultrasonic) As100SignalUltrasonicTransmitMethod else As100SignalFskTransmitMethod
    val committedResult = remember(committedJson) { committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(method, context, it) } }
    val committedFullJson = remember(committedJson) { fullJson(committedResult) }
    val resultKey = if (ultrasonic) SignalUltrasonicTransmitFields.RESULT else SignalFskTransmitFields.RESULT
    val messageIdKey = if (ultrasonic) SignalUltrasonicTransmitFields.MESSAGE_ID else SignalFskTransmitFields.MESSAGE_ID
    val frameCountKey = if (ultrasonic) SignalUltrasonicTransmitFields.FRAME_COUNT else SignalFskTransmitFields.FRAME_COUNT
    val cyclesKey = if (ultrasonic) SignalUltrasonicTransmitFields.CYCLES else SignalFskTransmitFields.CYCLES
    val markKey = if (ultrasonic) SignalUltrasonicTransmitFields.MARK_HZ else SignalFskTransmitFields.MARK_HZ
    val spaceKey = if (ultrasonic) SignalUltrasonicTransmitFields.SPACE_HZ else SignalFskTransmitFields.SPACE_HZ
    val bitKey = if (ultrasonic) SignalUltrasonicTransmitFields.BIT_MS else SignalFskTransmitFields.BIT_MS

    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val accent = if (ultrasonic) SignalViolet else SignalCyan
        val railMin = if (ultrasonic) 14000.0 else 200.0
        val railMax = if (ultrasonic) 22000.0 else 8000.0
        SignalInstrumentPanel(
            kicker = if (ultrasonic) "EXPERIMENTAL HIGH-BAND MODEM" else "MMS/1 ACOUSTIC / RADIO MODEM",
            title = if (ultrasonic) "Near-ultrasonic transmitter" else "Audio FSK transmitter",
            accent = accent,
            badge = if (sending) "On air" else "Standby"
        ) {
            Text(
                payload.ifBlank { "—" },
                color = SignalText,
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth().clickable(enabled = payload.isNotBlank()) { copySignalValue(androidContext, "message", payload) }
            )
            SignalCarrierRail(markHz, spaceHz, railMin, railMax, accent)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignalTelemetryTile("BIT", "$bitMs ms", accent, Modifier.weight(1f))
                SignalTelemetryTile("FRAMES", (encoded?.frames?.size ?: 0).toString(), accent, Modifier.weight(1f))
                SignalTelemetryTile("CYCLES", cyclesCompleted.toString(), accent, Modifier.weight(1f))
            }
            Text(if (sending) currentProgress else status, color = SignalMuted, style = MaterialTheme.typography.bodySmall)
            Text(
                if (ultrasonic)
                    "High-frequency response is device-specific. This mode is not guaranteed inaudible."
                else
                    "Radio path: hold PTT before Transmit; the lead carrier gives squelch/VOX time to open.",
                color = SignalMuted,
                style = MaterialTheme.typography.labelSmall
            )
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { if (sending) stop() else start() }, enabled = encoded != null, modifier = Modifier.weight(1f)) { Text(if (sending) "Stop" else "Transmit") }
            Button(onClick = ::commit, enabled = cyclesCompleted > 0, modifier = Modifier.weight(1f)) { Text(if (committedResult == null) "Commit" else "Recommit") }
        }

        if (committedResult != null && !context.submitsImmediately) {
            SignalCommittedCard(
                title = "Committed transmission",
                primaryLabel = "message",
                primaryValue = committedFields[resultKey].orEmpty(),
                fields = listOf(
                    "Message ID" to committedFields[messageIdKey].orEmpty(),
                    "Frames" to committedFields[frameCountKey].orEmpty(),
                    "Cycles" to committedFields[cyclesKey].orEmpty(),
                    "Mark Hz" to committedFields[markKey].orEmpty(),
                    "Space Hz" to committedFields[spaceKey].orEmpty(),
                    "Bit ms" to committedFields[bitKey].orEmpty()
                ),
                status = exportStatus,
                onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                onShare = { exportStatus = shareSignalText(androidContext, "Share signal payload", committedFields[resultKey].orEmpty()) ?: "" },
                onSave = { exportStatus = saveSignalText(androidContext, if (ultrasonic) "near_ultrasonic_transmission" else "audio_fsk_transmission", committedFields[resultKey].orEmpty(), committedFullJson) },
                onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, if (ultrasonic) "near_ultrasonic_transmission" else "audio_fsk_transmission", committedFields[resultKey].orEmpty(), committedFullJson) } }
            )
        }

        AudioFskTransmitSettings(
            context = context,
            ultrasonic = ultrasonic,
            sending = sending,
            payload = payload,
            onPayload = { payload = it; cyclesCompleted = 0; messageId = SignalPacketCodec.newMessageId() },
            robustness = robustness,
            onRobustness = { robustness = it; cyclesCompleted = 0; messageId = SignalPacketCodec.newMessageId() },
            markHz = markHz,
            onMarkHz = { markHz = it; cyclesCompleted = 0 },
            spaceHz = spaceHz,
            onSpaceHz = { spaceHz = it; cyclesCompleted = 0 },
            bitMs = bitMs,
            onBitMs = { bitMs = it; cyclesCompleted = 0 },
            pttLeadMs = pttLeadMs,
            onPttLeadMs = { pttLeadMs = it; cyclesCompleted = 0 },
            repeatCount = repeatCount,
            onRepeatCount = { repeatCount = it; cyclesCompleted = 0 }
        )

        encodedAttempt.exceptionOrNull()?.message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        if (committedResult == null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun AudioFskTransmitSettings(
    context: CapabilityScreenContext,
    ultrasonic: Boolean,
    sending: Boolean,
    payload: String,
    onPayload: (String) -> Unit,
    robustness: String,
    onRobustness: (String) -> Unit,
    markHz: Double,
    onMarkHz: (Double) -> Unit,
    spaceHz: Double,
    onSpaceHz: (Double) -> Unit,
    bitMs: Int,
    onBitMs: (Int) -> Unit,
    pttLeadMs: Int,
    onPttLeadMs: (Int) -> Unit,
    repeatCount: Int,
    onRepeatCount: (Int) -> Unit
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Packet & channel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Matched channel profile", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SignalFskProfiles.list(ultrasonic).forEach { profile ->
                    val selected = SignalFskProfiles.matching(ultrasonic, markHz, spaceHz, bitMs)?.id == profile.id
                    FilterChip(
                        selected = selected,
                        enabled = !sending,
                        onClick = { onMarkHz(profile.markHz); onSpaceHz(profile.spaceHz); onBitMs(profile.bitMs) },
                        label = { Text(profile.id) }
                    )
                }
            }
            Text(SignalFskProfiles.matching(ultrasonic, markHz, spaceHz, bitMs)?.label ?: "Custom tuning", style = MaterialTheme.typography.bodySmall)
            if (context.settingShouldBeShown("payload")) OutlinedTextField(payload, onPayload, enabled = !sending, modifier = Modifier.fillMaxWidth(), label = { Text("Message") })
            if (context.settingShouldBeShown("robustness")) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("fast", "robust", "extreme").forEach { item -> FilterChip(selected = robustness == item, enabled = !sending, onClick = { onRobustness(item) }, label = { Text(item.replaceFirstChar { it.uppercase() }) }) }
                }
            }
            if (context.settingShouldBeShown("mark_hz")) {
                Text("Mark: ${markHz.roundToInt()} Hz")
                Slider(markHz.toFloat(), { onMarkHz(if (ultrasonic) ((it / 50f).roundToInt() * 50f).toDouble() else ((it / 10f).roundToInt() * 10f).toDouble()) }, enabled = !sending, valueRange = if (ultrasonic) 14000f..22000f else 200f..8000f)
            }
            if (context.settingShouldBeShown("space_hz")) {
                Text("Space: ${spaceHz.roundToInt()} Hz")
                Slider(spaceHz.toFloat(), { onSpaceHz(if (ultrasonic) ((it / 50f).roundToInt() * 50f).toDouble() else ((it / 10f).roundToInt() * 10f).toDouble()) }, enabled = !sending, valueRange = if (ultrasonic) 14000f..22000f else 200f..8000f)
            }
            if (context.settingShouldBeShown("bit_ms")) {
                Text("Bit duration: $bitMs ms")
                Slider(bitMs.toFloat(), { onBitMs((it.roundToInt() / 10 * 10).coerceIn(20, 250)) }, enabled = !sending, valueRange = 20f..250f)
            }
            if (!ultrasonic && context.settingShouldBeShown("ptt_lead_ms")) {
                Text("PTT / squelch lead: $pttLeadMs ms")
                Slider(pttLeadMs.toFloat(), { onPttLeadMs((it.roundToInt() / 100 * 100).coerceIn(0, 5000)) }, enabled = !sending, valueRange = 0f..5000f)
            }
            if (context.settingShouldBeShown("repeat_count")) {
                Text("Complete cycles: $repeatCount")
                Slider(repeatCount.toFloat(), { onRepeatCount(it.roundToInt().coerceIn(1, 20)) }, enabled = !sending, valueRange = 1f..20f, steps = 18)
            }
        }
    }
}

object SignalFskReceiveCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalFskReceiveMethod.id
    override val title = "Audio FSK receiver"
    override val description = "Recover MMS/1 packets from audible two-tone FSK, including walkie-talkie audio."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        AudioFskReceiveUi(context, onBack, onConfirmed, onCancel, ultrasonic = false)
}

object SignalUltrasonicReceiveCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalUltrasonicReceiveMethod.id
    override val title = "Near-ultrasonic receiver"
    override val description = "Experimentally recover MMS/1 packets from high-frequency two-tone FSK."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        AudioFskReceiveUi(context, onBack, onConfirmed, onCancel, ultrasonic = true)
}

@Composable
private fun AudioFskReceiveUi(
    context: CapabilityScreenContext,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    ultrasonic: Boolean
) {
    val androidContext = LocalContext.current
    val settings = context.action.settings
    val defaultMark = if (ultrasonic) 15000.0 else 1200.0
    val defaultSpace = if (ultrasonic) 16000.0 else 2200.0
    val defaultBit = if (ultrasonic) 100 else 60
    val defaultMin = if (ultrasonic) -50.0 else -40.0

    var markHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("mark_hz", defaultMark.toString()).toDoubleOrNull() ?: defaultMark) }
    var spaceHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("space_hz", defaultSpace.toString()).toDoubleOrNull() ?: defaultSpace) }
    var bitMs by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("bit_ms", defaultBit.toString()).toIntOrNull()?.let { ((it + 5) / 10 * 10).coerceIn(20, 250) } ?: defaultBit) }
    var minimumDbfs by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("minimum_dbfs", defaultMin.toString()).toDoubleOrNull()?.coerceIn(-90.0, 0.0) ?: defaultMin) }
    var listening by remember { mutableStateOf(false) }
    var frameStoreJson by rememberSaveable(context.action.canonicalId) { mutableStateOf("[]") }
    var physicalRejected by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
    var status by rememberSaveable(context.action.canonicalId) { mutableStateOf(if (ultrasonic) "Experimental receiver. Calibrate frequency response on the actual phone pair first." else "Start listening; audible packets may arrive directly or from a radio speaker.") }
    var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var levelText by rememberSaveable(context.action.canonicalId) { mutableStateOf("—") }
    var dominantTone by rememberSaveable(context.action.canonicalId) { mutableStateOf("—") }
    var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
    var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var audioGranted by remember { mutableStateOf(fskHasPermission(androidContext, Manifest.permission.RECORD_AUDIO)) }

    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        audioGranted = granted || fskHasPermission(androidContext, Manifest.permission.RECORD_AUDIO)
        if (!audioGranted) error = "Microphone permission is required for FSK reception."
    }
    val engine = remember(androidContext) { SignalFskReceiverEngine(androidContext) }
    val clockDecoder = remember { FskClockRecoveryDecoder(bitMs) }
    var clockTelemetry by remember { mutableStateOf(clockDecoder.telemetry()) }
    var spectrumBins by remember { mutableStateOf(emptyList<Float>()) }
    var spectrumMinHz by remember { mutableStateOf(if (ultrasonic) 14000.0 else 200.0) }
    var spectrumMaxHz by remember { mutableStateOf(if (ultrasonic) 22000.0 else 8000.0) }
    var spectrumPeakHz by remember { mutableStateOf(0.0) }
    var confidenceDb by remember { mutableStateOf(0.0) }

    fun storedFrames(raw: String = frameStoreJson): MutableList<String> = runCatching {
        val array = JSONArray(raw)
        MutableList(array.length()) { index -> array.optString(index) }
    }.getOrDefault(mutableListOf())

    fun collectorFrom(raw: String = frameStoreJson): SignalFrameCollector = SignalFrameCollector().also { collector -> storedFrames(raw).forEach(collector::offer) }
    val collectorState = remember(frameStoreJson) { collectorFrom().state() }

    LaunchedEffect(Unit) {
        if (!listening && status.startsWith("Listening", ignoreCase = true)) {
            status = if (collectorState.requiredRank > 0)
                "Reception paused after screen recreation; ${collectorState.rank} / ${collectorState.requiredRank} retained shards."
            else
                "Reception paused after screen recreation. Start listening again."
        }
    }

    fun stop(userRequested: Boolean = true) {
        engine.stop()
        listening = false
        dominantTone = "—"
        if (userRequested) status = if (collectorState.requiredRank > 0) "Paused at ${collectorState.rank} / ${collectorState.requiredRank} shards. Complete frames are retained." else "Paused."
    }

    fun acceptFrame(raw: String) {
        val parsed = SignalPacketCodec.parse(raw)
        if (!parsed.valid) {
            physicalRejected++
            return
        }
        val frames = storedFrames()
        if (raw !in frames) frames += raw
        val json = JSONArray().also { a -> frames.forEach(a::put) }.toString()
        frameStoreJson = json
        val state = collectorFrom(json).state()
        status = when {
            state.complete -> "Message recovered. CRC verified${if (state.recoveredMissingSources > 0) "; ${state.recoveredMissingSources} missing shard(s) reconstructed" else ""}."
            state.requiredRank > 0 -> "Collecting ${state.rank} / ${state.requiredRank} independent shards."
            else -> "Acquiring MMS/1…"
        }
        if (state.complete) stop(userRequested = false)
    }

    fun start() {
        if (!audioGranted) {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (kotlin.math.abs(markHz - spaceHz) < 80.0) {
            error = "Choose carrier frequencies at least 80 Hz apart."
            return
        }
        error = ""
        clockDecoder.setBitMs(bitMs)
        clockDecoder.reset()
        clockTelemetry = clockDecoder.telemetry()
        spectrumBins = emptyList()
        spectrumPeakHz = 0.0
        confidenceDb = 0.0
        listening = true
        status = if (collectorState.requiredRank > 0) "Listening — retained ${collectorState.rank} / ${collectorState.requiredRank} shards." else "Listening for FSK sync…"
        engine.start(
            markHz = markHz,
            spaceHz = spaceHz,
            minimumDbfs = minimumDbfs,
            onWindow = { window ->
                levelText = "${"%.1f".format(Locale.US, window.dbfs)} dBFS • ${window.audioSource}"
                dominantTone = when (window.tone) { true -> "MARK"; false -> "SPACE"; null -> "—" }
                confidenceDb = window.decisionConfidenceDb
                window.spectrum?.let { values ->
                    spectrumBins = values.toList()
                    spectrumMinHz = window.spectrumMinHz
                    spectrumMaxHz = window.spectrumMaxHz
                    spectrumPeakHz = window.peakHz
                }
                clockDecoder.feed(window.tone).forEach(::acceptFrame)
                clockTelemetry = clockDecoder.telemetry()
                physicalRejected = maxOf(physicalRejected, clockTelemetry.invalidLengths)
            },
            onError = { error = it; listening = false }
        )
    }

    fun reset() {
        stop(userRequested = false)
        frameStoreJson = "[]"
        physicalRejected = 0
        committedJson = null
        exportStatus = ""
        status = "Receiver reset."
        error = ""
    }

    fun invalidateWorkingReception() {
        stop(userRequested = false)
        frameStoreJson = "[]"
        physicalRejected = 0
        clockDecoder.setBitMs(bitMs)
        clockTelemetry = clockDecoder.telemetry()
        spectrumBins = emptyList()
        spectrumPeakHz = 0.0
        confidenceDb = 0.0
        dominantTone = "—"
        levelText = "—"
        status = "Receiver tuning changed; working evidence was cleared. Use the same A/B/C/D profile on both phones, then listen again. Any committed result remains frozen."
        error = ""
    }

    fun commit() {
        val state = collectorFrom().state()
        val text = state.text.orEmpty()
        if (!state.complete || text.isBlank()) {
            error = "The message is not yet recoverable. Keep listening for more frames."
            return
        }
        stop(userRequested = false)
        val values = if (ultrasonic) {
            mapOf(
                SignalUltrasonicReceiveFields.RESULT to text,
                SignalUltrasonicReceiveFields.MESSAGE_ID to state.messageId.orEmpty(),
                SignalUltrasonicReceiveFields.FRAMES_ACCEPTED to state.acceptedFrames.toString(),
                SignalUltrasonicReceiveFields.FRAMES_REJECTED to (state.rejectedFrames + physicalRejected).toString(),
                SignalUltrasonicReceiveFields.RECOVERED_MISSING to state.recoveredMissingSources.toString(),
                SignalUltrasonicReceiveFields.CRC_VERIFIED to state.messageCrcVerified.toString(),
                SignalUltrasonicReceiveFields.MARK_HZ to markHz.roundToInt().toString(),
                SignalUltrasonicReceiveFields.SPACE_HZ to spaceHz.roundToInt().toString(),
                SignalUltrasonicReceiveFields.BIT_MS to bitMs.toString(),
                SignalUltrasonicReceiveFields.STATUS to "received",
                SignalUltrasonicReceiveFields.ERROR to ""
            )
        } else {
            mapOf(
                SignalFskReceiveFields.RESULT to text,
                SignalFskReceiveFields.MESSAGE_ID to state.messageId.orEmpty(),
                SignalFskReceiveFields.FRAMES_ACCEPTED to state.acceptedFrames.toString(),
                SignalFskReceiveFields.FRAMES_REJECTED to (state.rejectedFrames + physicalRejected).toString(),
                SignalFskReceiveFields.RECOVERED_MISSING to state.recoveredMissingSources.toString(),
                SignalFskReceiveFields.CRC_VERIFIED to state.messageCrcVerified.toString(),
                SignalFskReceiveFields.MARK_HZ to markHz.roundToInt().toString(),
                SignalFskReceiveFields.SPACE_HZ to spaceHz.roundToInt().toString(),
                SignalFskReceiveFields.BIT_MS to bitMs.toString(),
                SignalFskReceiveFields.STATUS to "received",
                SignalFskReceiveFields.ERROR to ""
            )
        }
        committedJson = fieldsJson(values)
        status = "Committed."
        val method = if (ultrasonic) As100SignalUltrasonicReceiveMethod else As100SignalFskReceiveMethod
        val result = signalResult(method, context, values)
        if (context.submitsImmediately) onConfirmed(result)
    }

    LaunchedEffect(markHz, spaceHz, bitMs, minimumDbfs) {
        context.onSettingsChanged(
            mapOf(
                "mark_hz" to markHz.roundToInt().toString(),
                "space_hz" to spaceHz.roundToInt().toString(),
                "bit_ms" to bitMs.toString(),
                "minimum_dbfs" to minimumDbfs.toString()
            )
        )
    }

    DisposableEffect(Unit) { onDispose { engine.stop() } }

    val committedFields = fieldsFromJson(committedJson)
    val method = if (ultrasonic) As100SignalUltrasonicReceiveMethod else As100SignalFskReceiveMethod
    val committedResult = remember(committedJson) { committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(method, context, it) } }
    val committedFullJson = remember(committedJson) { fullJson(committedResult) }
    val resultKey = if (ultrasonic) SignalUltrasonicReceiveFields.RESULT else SignalFskReceiveFields.RESULT
    val messageIdKey = if (ultrasonic) SignalUltrasonicReceiveFields.MESSAGE_ID else SignalFskReceiveFields.MESSAGE_ID
    val recoveredKey = if (ultrasonic) SignalUltrasonicReceiveFields.RECOVERED_MISSING else SignalFskReceiveFields.RECOVERED_MISSING
    val crcKey = if (ultrasonic) SignalUltrasonicReceiveFields.CRC_VERIFIED else SignalFskReceiveFields.CRC_VERIFIED
    val markKeyRx = if (ultrasonic) SignalUltrasonicReceiveFields.MARK_HZ else SignalFskReceiveFields.MARK_HZ
    val spaceKeyRx = if (ultrasonic) SignalUltrasonicReceiveFields.SPACE_HZ else SignalFskReceiveFields.SPACE_HZ
    val bitKeyRx = if (ultrasonic) SignalUltrasonicReceiveFields.BIT_MS else SignalFskReceiveFields.BIT_MS

    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        val accent = if (ultrasonic) SignalViolet else SignalCyan
        val railMin = if (ultrasonic) 14000.0 else 200.0
        val railMax = if (ultrasonic) 22000.0 else 8000.0
        SignalInstrumentPanel(
            kicker = if (ultrasonic) "EXPERIMENTAL HIGH-BAND RECEIVER" else "MMS/1 ACOUSTIC / RADIO RECEIVER",
            title = if (ultrasonic) "Near-ultrasonic receiver" else "Audio FSK receiver",
            accent = accent,
            badge = when { collectorState.complete -> "Recovered"; listening -> dominantTone.takeUnless { it == "—" } ?: "Listening"; else -> "Paused" }
        ) {
            Text(
                collectorState.text?.ifBlank { null } ?: if (collectorState.requiredRank > 0) "${collectorState.rank} / ${collectorState.requiredRank} SHARDS" else "WAITING FOR PACKET",
                color = if (collectorState.text.isNullOrBlank()) SignalMuted else SignalText,
                style = MaterialTheme.typography.headlineSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.fillMaxWidth().clickable(enabled = collectorState.text?.isNotBlank() == true) { copySignalValue(androidContext, "received text", collectorState.text.orEmpty()) }
            )
            if (collectorState.requiredRank > 0) SignalProgressTrack(collectorState.rank.toFloat() / collectorState.requiredRank.toFloat(), accent)
            SignalCarrierRail(markHz, spaceHz, railMin, railMax, accent)
            SignalSpectrumView(spectrumBins, spectrumMinHz, spectrumMaxHz, markHz, spaceHz, accent)
            Text("Spectrum confirms what the microphone is actually hearing. Amber = MARK target, cyan = SPACE target.", color = SignalMuted, style = MaterialTheme.typography.labelSmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignalTelemetryTile("PEAK", if (spectrumPeakHz > 0) "${spectrumPeakHz.roundToInt()} Hz" else "—", accent, Modifier.weight(1f))
                SignalTelemetryTile("TONE CONF", "${"%.1f".format(Locale.US, confidenceDb)} dB", accent, Modifier.weight(1f))
                SignalTelemetryTile("BIT", "$bitMs ms", accent, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignalTelemetryTile("CLOCK", if (clockTelemetry.clockLocked) "LOCK" else "search", accent, Modifier.weight(1f))
                SignalTelemetryTile("SYNC", clockTelemetry.syncDetections.toString(), accent, Modifier.weight(1f))
                SignalTelemetryTile("FRAMES", clockTelemetry.physicalFrames.toString(), accent, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SignalTelemetryTile("ACCEPTED", collectorState.acceptedFrames.toString(), accent, Modifier.weight(1f))
                SignalTelemetryTile("REJECTED", (collectorState.rejectedFrames + physicalRejected).toString(), accent, Modifier.weight(1f))
                SignalTelemetryTile("MMS", if (collectorState.requiredRank > 0) "${collectorState.rank}/${collectorState.requiredRank}" else "—", accent, Modifier.weight(1f))
            }
            Text(levelText, color = SignalMuted, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            if (ultrasonic) Text("No decoded frames can mean phone bandwidth, not protocol failure.", color = SignalMuted, style = MaterialTheme.typography.labelSmall)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { if (listening) stop() else start() }, modifier = Modifier.weight(1f)) { Text(if (listening) "Pause" else "Start listening") }
            Button(onClick = ::commit, enabled = collectorState.complete, modifier = Modifier.weight(1f)) { Text(if (committedResult == null) "Commit" else "Recommit") }
            OutlinedButton(onClick = ::reset) { Text("Reset") }
        }

        if (committedResult != null && !context.submitsImmediately) {
            SignalCommittedCard(
                title = "Committed reception",
                primaryLabel = "received text",
                primaryValue = committedFields[resultKey].orEmpty(),
                fields = listOf(
                    "Message ID" to committedFields[messageIdKey].orEmpty(),
                    "Recovered missing" to committedFields[recoveredKey].orEmpty(),
                    "CRC verified" to committedFields[crcKey].orEmpty(),
                    "Mark Hz" to committedFields[markKeyRx].orEmpty(),
                    "Space Hz" to committedFields[spaceKeyRx].orEmpty(),
                    "Bit ms" to committedFields[bitKeyRx].orEmpty()
                ),
                status = exportStatus,
                onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                onShare = { exportStatus = shareSignalText(androidContext, "Share recovered signal", committedFields[resultKey].orEmpty()) ?: "" },
                onSave = { exportStatus = saveSignalText(androidContext, if (ultrasonic) "near_ultrasonic_reception" else "audio_fsk_reception", committedFields[resultKey].orEmpty(), committedFullJson) },
                onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, if (ultrasonic) "near_ultrasonic_reception" else "audio_fsk_reception", committedFields[resultKey].orEmpty(), committedFullJson) } }
            )
        }

        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Receiver tuning", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Use the same profile on both phones", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SignalFskProfiles.list(ultrasonic).forEach { profile ->
                        val selected = SignalFskProfiles.matching(ultrasonic, markHz, spaceHz, bitMs)?.id == profile.id
                        FilterChip(selected = selected, enabled = !listening, onClick = {
                            if (!selected) { markHz = profile.markHz; spaceHz = profile.spaceHz; bitMs = profile.bitMs; invalidateWorkingReception() }
                        }, label = { Text(profile.id) })
                    }
                }
                Text(SignalFskProfiles.matching(ultrasonic, markHz, spaceHz, bitMs)?.label ?: "Custom tuning", style = MaterialTheme.typography.bodySmall)
                if (context.settingShouldBeShown("mark_hz")) {
                    Text("Mark: ${markHz.roundToInt()} Hz")
                    Slider(markHz.toFloat(), { next -> val snapped = if (ultrasonic) ((next / 50f).roundToInt() * 50f).toDouble() else ((next / 10f).roundToInt() * 10f).toDouble(); if (snapped != markHz) { markHz = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = if (ultrasonic) 14000f..22000f else 200f..8000f)
                }
                if (context.settingShouldBeShown("space_hz")) {
                    Text("Space: ${spaceHz.roundToInt()} Hz")
                    Slider(spaceHz.toFloat(), { next -> val snapped = if (ultrasonic) ((next / 50f).roundToInt() * 50f).toDouble() else ((next / 10f).roundToInt() * 10f).toDouble(); if (snapped != spaceHz) { spaceHz = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = if (ultrasonic) 14000f..22000f else 200f..8000f)
                }
                if (context.settingShouldBeShown("bit_ms")) {
                    Text("Bit duration: $bitMs ms")
                    Slider(bitMs.toFloat(), { next -> val snapped = (next.roundToInt() / 10 * 10).coerceIn(20, 250); if (snapped != bitMs) { bitMs = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = 20f..250f)
                }
                if (context.settingShouldBeShown("minimum_dbfs")) {
                    Text("Minimum level: ${"%.0f".format(Locale.US, minimumDbfs)} dBFS")
                    Slider(minimumDbfs.toFloat(), { next -> val snapped = next.roundToInt().coerceIn(-90, 0).toDouble(); if (snapped != minimumDbfs) { minimumDbfs = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = -90f..0f)
                }
            }
        }

        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (committedResult == null) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }
    }
}

private fun fskHasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
