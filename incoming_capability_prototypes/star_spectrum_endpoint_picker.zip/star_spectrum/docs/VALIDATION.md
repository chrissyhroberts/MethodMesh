# Validation and self-review — Star spectrum analyser v0.1.0

Date: 2026-09-16

Status: **Development**. This handoff has been reviewed against MethodMesh Master Book v1.22 and current `master` interfaces inspected through the connected MethodMesh repository. It has not been promoted to Production.

## Pass A — contract correctness

- [x] One module entry point: `StarSpectrumModule`.
- [x] Two independently callable capabilities remain explicit rather than being hidden inside one dashboard:
  - `astronomy.spectrum.analyse`
  - `astronomy.spectrum.reference.create`
- [x] Both capabilities are exposed through `as100Methods()`, `capabilityScreens()`, `capabilitySettings()` and RIL bindings.
- [x] No shared `HomeScreen`, navigation, dashboard or framework special case is required.
- [x] Both method descriptors explicitly declare Development maturity and Offline connectivity.
- [x] Canonical outputs are declared once in each method field object.
- [x] ODK source-return semantics are implemented conditionally: if MethodMesh acquires an input image on behalf of the caller, a MethodMesh-owned cache copy is returned as an attachment field; if the caller supplied the source URI, that return field is blank.
- [x] Analysis exports annotated PNG, full spectrum CSV, detected-feature CSV and metadata JSON as real FileProvider-backed artefacts.
- [x] Both canonical ODK showcases contain exactly one MethodMesh invocation and request FULL payload.
- [x] No `methodmesh_return_namespace` is used in canonical showcases.
- [x] Reference persistence occurs only in the explicit reference-creation capability and only at Commit.

## Pass B — interaction quality

- [x] Custom capability-specific screens; no generic settings-form workflow.
- [x] Image-first workflow with pinch zoom and pan.
- [x] Dedicated trace-draw mode and visible search ribbon.
- [x] Analysis is an explicit expensive operation, but its working result appears on the same tool screen.
- [x] Working/current result remains editable until Commit.
- [x] Commit freezes the canonical payload; committed state is rendered on the same screen rather than forcing a generic result page.
- [x] Committed analysis exposes Share, Save bundle, copy feature list and optional FULL JSON.
- [x] Result metric tiles and feature rows are tap-to-copy with confirmation.
- [x] Reference screen exposes graphical anchor placement rather than raw pixel-position text boxes.
- [x] Native UI never presents internal content URIs as the useful result.
- [x] Technical/JSON material remains secondary.

## Pass C — field robustness

- [x] Image coordinates are independent of view zoom/pan.
- [x] Source URI, trace coordinates, reference selection, major control values and Commit JSON use `rememberSaveable` where practical.
- [x] A lost in-memory bitmap/extraction can be reconstructed from the retained source URI and trace after ordinary recreation.
- [x] Imported document URIs request persistable read permission where available.
- [x] Large raster images are downsampled to a maximum decoded dimension of 4096 px for bounded phone memory use.
- [x] File outputs are cache-backed and exposed through the existing MethodMesh FileProvider.
- [x] Reference writes use a temporary file then rename/replace pattern.
- [x] Analysis does not create a hidden persistent result database.
- [x] Invalid/high-contamination spectral samples are exported explicitly rather than silently represented as clean observations.

## Algorithm review

### Trace optimisation

The trace-search implementation was separately smoke-checked against the supplied example star-field JPEG using an equivalent local numerical prototype. With a deliberately approximate line along the visible spectrum, the optimised centroid correction remained within about ±7 px and mean absolute correction was about 1 px in that test. This is an algorithm-design smoke check, not an Android/Kotlin integration test.

### Contaminant rejection

The implementation models the target cross-dispersion spatial profile before collapsing to one dimension. It uses robust profile-template amplitude fitting and exports both contamination probability and validity. This is preferable to trying to infer field-star contamination after the image has already been reduced to a 1-D spectrum.

The v0.1 model is intentionally conservative: severely contaminated samples are flagged invalid rather than being filled with invented signal.

### Feature confidence

Feature confidence is based on local robust S/N, prominence, persistence across neighbouring sigma thresholds and low contamination. Documentation explicitly avoids describing the score as a literal ROC probability.

## Build/test status

A full `./gradlew :app:testDebugUnitTest :app:assembleDebug` could not be run in this handoff environment because the complete MethodMesh Android checkout/Gradle dependency graph is not mounted locally. The module was written against the current repository interfaces inspected during this turn, including:

- `MethodMeshModule` auto-discovery;
- current `MethodSetting` constructors;
- current `CapabilityScreenSpec` / `CapabilityScreenContext` contract;
- current `As100Method` / `As100ExecutionEngine` pattern;
- existing MethodMesh `FileProvider`, `Digests`, `OutputFormatter` and Downloads export infrastructure.

### Required admission checks

Before Production or merge confidence is claimed:

1. place this folder at `app/src/main/java/com/example/methodmesh/modules/star_spectrum/`;
2. run `./gradlew :app:testDebugUnitTest :app:assembleDebug`;
3. exercise both native capabilities on a phone-sized device;
4. rotate/recreate during image selection, tracing, working-result and committed states;
5. verify pinch/pan + trace mapping on portrait and landscape source images;
6. validate both XLSForms with the repository's XLSForm validation path;
7. run both ODK → MethodMesh → ODK roundtrips and confirm all file returns import as attachments;
8. confirm caller-supplied source images are not duplicated back to ODK;
9. confirm MethodMesh-acquired source images are returned to ODK;
10. test reference reuse with the same optical setup across repeated A-star/target observations;
11. compare wavelength calibration and extracted profiles against a trusted spectroscopy workflow such as BASS on representative data;
12. only then consider promotion beyond Development.

## Deliberate v0.1 boundaries

- no FITS/raw-linear decoder;
- no automatic line/species identification;
- no atmospheric or instrument-response correction;
- no full multi-source PSF deblender;
- no claim that raster-image intensity is calibrated photon count;
- no network dependency.
