# Third-party notices — Star spectrum analyser

Version 0.1.0 introduces no module-specific third-party library, online service or external dataset.

The implementation uses Android platform APIs, Jetpack Compose / Material 3 and existing MethodMesh runtime infrastructure already governed by the parent application's dependency and licence notices.

The built-in Hα/Hβ/Hγ/Hδ wavelength shortcuts are standard physical reference values represented as small factual constants, not a copied third-party database.

No image or derived spectrum is sent to a remote provider.
