# Paper Bridge visual designer — `paper.form.design`

Paper Bridge treats a paper layout as a named reusable **schema**. The native designer opens through the Schema Library rather than dropping directly into a random form. User schemas can be created, opened, renamed, duplicated, deleted, exported and restored. The bundled example is a staged tutorial rather than a pre-wired finished schema.

## Normal authoring workflow

1. Open **Paper Bridge → Schemas**.
2. Create a schema and give it a name, or open **Example — learn Paper Bridge**.
3. Import an ordinary Excel/XLSForm-style workbook with `survey` and `choices` sheets.
4. Import the blank/colour-authored paper PNG or PDF **without QR fiducials**. The author supplies the form artwork only.
5. For a new schema, Paper Bridge assigns a short schema key and **automatically prepares a separate printable QR4 version** of the form. The imported artwork is preserved unchanged as the canonical content; it is not destructively edited.
6. Press **AUTO DETECT**. Paper Bridge detects colour-authored question regions or ordinary printed response boxes, OCR-matches question labels against `survey.label`, matches select option labels against `choices.label`, and proposes ROI linkages.
7. Resolve highlighted queries in **EDIT**. Manual **+ BOX** exists only for regions automatic detection cannot find.
8. Use the persistent lifecycle: **SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE**.
9. The saved schema exports JSON/YAML, canonical/mapping images, a printable QR-prepared form, and a portable `.paperbridge.zip` backup.

## QR4 registration — default for new schemas

New Paper Bridge schemas use four schema-specific QR fiducials by default. Payloads are:

- `PB:<schema-key>:TL`
- `PB:<schema-key>:TR`
- `PB:<schema-key>:BR`
- `PB:<schema-key>:BL`

The QR **centres** define the canonical analysis rectangle. They do not contain participant data. The short schema key distinguishes one paper schema from another and allows a wrong-schema sheet to fail closed instead of being silently registered.

Paper Bridge generates the QR fiducials itself; authors do not need to add them to the source artwork. The generated `*.prepared-form.png` is the version to print/use for blank and completed runtime forms. The original imported artwork remains the authoring source.

The current default places QR centres near the four page corners at approximately 5.5%/94.5% of the prepared page. QR size is deliberately large enough to retain a proper quiet zone and survive ordinary printing/camera capture. The centre-to-centre crop is resized to the schema's canonical dimensions before any ROI is read.

If an imported form already contains the four exact QR payloads for the schema, Paper Bridge detects them and recovers the canonical centre-to-centre canvas instead of adding a second set.

Existing older schemas without QR registration remain supported as **legacy bullseye4** schemas. Bullseye detection is retained for compatibility, not as the preferred authoring route.

## Colour-assisted authoring

For new forms, the fixed colour syntax in `README_Colour_Authoring.md` is preferred:

- solid magenta: scalar (`text`, `integer`, `decimal`);
- solid teal: `select_one`;
- solid orange: `select_multiple`;
- solid violet: `barcode`;
- solid lime: `image`;
- blue text: select-option labels;
- black: question text and response geometry.

Colour is used only to learn schema semantics. The production form may be monochrome or use any colours because runtime transcription reads only stored ROIs after registration.

Question matching uses the printed question text against **`survey.label`**, not the variable name. Choice matching uses printed option text against **`choices.label`** and stores the corresponding `choices.name` as the returned value. Compatible type is always part of matching, and uncertain matches remain explicit queries rather than being silently accepted.

## Excel workbook contract

Paper Bridge does not require ODK. Any `.xlsx` using the supported XLSForm-style structure can define the data schema.

`survey` requires `type`, `name`, `label`; `required` and `constraint` are optional. Supported types are:

- `text`
- `integer`
- `decimal`
- `select_one <list_name>`
- `select_multiple <list_name>`
- `barcode`
- `image`

`choices` uses `list_name`, `name`, `label`. Optional `settings` may provide `form_id`, `form_title`, and `version`.

## Canvas interaction

The designer is a fixed full-screen workspace. Its minimalist strip across the top of the paper viewport contains **NAV · AUTO DETECT · + BOX · EDIT · − · zoom · + · FIT**.

- **NAV** exclusively owns pinch-to-zoom and drag-to-pan.
- **EDIT** owns tap selection, move and corner-resize.
- Overlay labels use the same page transform as their ROI, so they remain attached while panning/zooming instead of accumulating against the viewport boundary.
- Overlapping boxes select the smallest region under the tap.

The lower pane contains field/linkage information and scrolls independently from the paper canvas.

## Lifecycle

The designer lifecycle is explicit:

**SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE**

Saving persists the current named schema without closing it. `TEST EMPTY` verifies that an unfilled production form does not create false response values. `TEST DATA` exercises the same acquisition/registration/extraction pipeline on a completed sheet. Editing the mapping after a test makes the schema dirty and requires another save/test cycle before Finalise.

`image` fields are not considered false-positive merely because their ROI crop exists on a blank form: the image attachment represents the declared region itself.

## Portable outputs

Saving a QR4 schema produces:

- `*.paperbridge.json` — canonical schema definition;
- `*.paperbridge.yaml` — fixed-profile human-readable backup;
- `*.template.png` — canonical centre-to-centre authoring canvas;
- `*.prepared-form.png` — printable page with the four QR4 fiducials;
- `*.mapping.png` — annotated ROI/linkage image;
- `*.paperbridge.zip` — portable backup containing the above artifacts.

The design method additionally returns `paper_design_prepared_form_image` when QR4 preparation is available.

A restored bundle stores `template.png` as an already-canonical source; it is never registered a second time.

## Built-in tutorial

The example appears in the Schema Library as **Example — learn Paper Bridge** and begins unresolved. Opening it shows the **QR-free colour-authored source form** and matching workbook. QR fiducials are generated later by Paper Bridge for the prepared blank/filled test sheets; they are not part of the authoring input. The intended exercise is:

1. **AUTO DETECT**;
2. inspect detected ROIs and proposed question/choice matches;
3. resolve any highlighted queries;
4. **SAVE SCHEMA**;
5. **TEST EMPTY** using the bundled blank production form;
6. **TEST DATA** using the bundled completed form;
7. **FINALISE**.

The tutorial includes text, integer, decimal, single-choice OMR, multiple-choice OMR, barcode and image-region capture. It can be reset and repeated.


### Test diagnostics

Schema-test status is shown directly under the lifecycle controls. QR decode failures therefore remain visible while the scan workspace is on screen. New schemas use larger QR4 fiducials and the decoder retries enlarged/filtered/binary views for low-resolution or screen-photographed forms. TEST EMPTY treats weak OMR activity as a baseline warning while preserving a blocking failure for strong apparent marks.
