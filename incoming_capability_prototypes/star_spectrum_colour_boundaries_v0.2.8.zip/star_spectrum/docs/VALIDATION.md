# Validation and self-review — Star spectrum analyser v0.2.8

Date: 2026-09-17

Status: **Development**. This handoff remains a Development module and must not be presented as a validated scientific pipeline.

## MethodMesh contract review

- [x] One module entry point: `StarSpectrumModule`.
- [x] Two independently callable capabilities remain explicit:
  - `astronomy.spectrum.analyse`
  - `astronomy.spectrum.reference.create`
- [x] Both capabilities remain exposed through module-owned methods, screens, settings and RIL bindings.
- [x] Working results remain editable until Commit.
- [x] Commit remains the finalisation boundary.
- [x] Analysis exports annotated PNG, spectrum CSV, detected-feature CSV and metadata JSON.
- [x] Canonical ODK showcases remain single-invocation examples using FULL payload.
- [x] Reference persistence remains local/offline and occurs only at explicit reference Commit.

## Extraction-method revision

The original experimental template-amplitude extractor has been replaced as the primary science path.

The current engine follows the standard astronomical sequence used by Horne-style optimal-extraction packages:

1. refine the user-provided RED → VIOLET geometry with a robust quadratic trace fit;
2. rectify a 2-D ribbon around that fitted trace;
3. estimate a sigma-clipped two-sided local background independently at each dispersion sample;
4. retain a simple background-subtracted boxcar extraction;
5. estimate an empirical cross-dispersion spatial profile in dispersion bins and interpolate it smoothly;
6. run iterative variance-weighted Horne-style optimal extraction;
7. reject the strongest spatial-profile outlier in each column per iteration when it exceeds the residual threshold;
8. preserve rejection fractions, optimal variance proxy, boxcar flux and optimal flux in outputs.

For processed JPEG/PNG input, the uncertainty image cannot be detector-calibrated. The engine therefore uses an explicitly documented empirical relative variance proxy. The resulting spectrum is image-derived relative signal, not calibrated photon flux.

## Visual quality audit

Both native capabilities now expose the intermediate 2-D products after extraction:

1. rectified trace;
2. two-sided background model;
3. background-subtracted ribbon;
4. unit-normalized empirical spatial-profile weights;
5. fitted 2-D target model (`optimal flux × spatial profile`);
6. signed `data − fitted model` residual with rejected pixels overlaid;
7. cleaned/rejected-pixel view;
8. boxcar-versus-optimal 1-D comparison.

This is intended to make extraction failure visible rather than hiding all processing behind one final curve.

## Local implementation checks completed in this handoff

- [x] `SpectrumEngine.kt` and `SpectrumModels.kt` compile with a minimal Kotlin/JVM stub harness for Android Bitmap and JSON classes.
- [x] New extraction diagnostics are wired into the analysis model.
- [x] CSV export now preserves boxcar signal, optimal signal, optimal variance and per-column rejection fraction.
- [x] Metadata records extraction method, trace-fit RMS, rejected-pixel fraction, iteration count and variance semantics.
- [x] Reference calibration uses the Horne-optimally extracted 1-D spectrum as the primary Balmer placement surface.
- [x] Existing RED/VIOLET endpoint picker and horizontal photographic spectrum strip are retained.

## Required Android admission checks

A full Android Gradle build cannot be completed in this isolated handoff environment. Before merge or scientific use:

1. replace the module folder and run `./gradlew :app:compileDebugKotlin :app:assembleDebug`;
2. exercise reference extraction on the supplied stellar JPEG and inspect every QA stage;
3. confirm the rectified target is horizontal and centred;
4. confirm side-band stars are absent from the background model after clipping;
5. confirm rejected pixels correspond to visibly inconsistent crossings/hot pixels rather than the target core;
6. compare boxcar and optimal traces;
7. verify RED/VIOLET pan/zoom and three-second lock behaviour is unchanged;
8. place Balmer anchors on the optimal-extraction Line finder view;
9. compare wavelength calibration against BASS or another trusted spectroscopy workflow;
10. repeat with an uncompressed/raw source before judging absolute spectral shape;
11. validate both XLSForms and ODK round trips;
12. only then consider promotion beyond Development.

## Deliberate boundaries

- no FITS/raw-linear decoder yet;
- no detector gain/read-noise calibration for JPEG/PNG;
- no automatic elemental/species identification;
- no atmospheric or instrument-response correction;
- no HST-style forward contamination model requiring direct imaging and instrument calibration files;
- no claim that processed raster intensity is calibrated stellar flux;
- no network dependency.

- [x] QA UI exposes the iterative residual rejection threshold used by the extractor.

## Iterative profile-refinement revision

- [x] Empirical spatial profile is re-estimated from surviving pixels during the Horne loop.
- [x] Rejection remains at the declared 5σ threshold; it is not loosened to force a cleaner-looking model.
- [x] QA exposes signed residual and standardized residual z-map separately.
- [x] QA reports fractions above 3σ and 5σ, maximum absolute standardized residual, and profile-update count.
- [x] Trace fitting, rectification and two-sided background logic were intentionally left unchanged in this revision.


## Local compile check for v0.2.8

- [x] `SpectrumModels.kt` + `SpectrumEngine.kt` compile successfully with Kotlin/JVM 1.9 using minimal Android Bitmap and JSON stubs after the iterative-profile revision.
- [x] No lowering of the 5σ rejection threshold was introduced.
- [x] Trace fitting, rectification and two-sided background code remain unchanged from the prior QA build.
- [ ] Full Android/Compose Gradle compilation still needs to be run in the MethodMesh app project.


## v0.2.8 fixed-scale z-map QA

- [x] Standardized residual image is displayed on a fixed −5σ to +5σ scale.
- [x] `|z| ≥ 3σ`, `|z| ≥ 5σ`, and actually rejected pixels use distinct overlays.
- [x] Raw signed residual remains auto-scaled for subtle-structure inspection.
- [x] No extraction or rejection mathematics changed in this revision.

## Reliable line-finder revision

- [x] Horne extraction engine is unchanged in this revision.
- [x] Low-signal samples are masked from continuum normalization rather than divided by near-zero values.
- [x] Line-finder continuum uses a broad high-percentile upper envelope.
- [x] Line-finder UI exposes reliable-sample coverage.
- [x] Two or more anchors generate provisional positions for unplaced Balmer lines.
- [x] Provisional positions are never committed automatically.
- [x] Active predicted Balmer lines receive a local zoomed trough picker with explicit commit.
- [ ] Full Android/Compose Gradle compilation remains to be run in the MethodMesh app project.

## Balmer pattern-assistance revision

- [x] Horne extraction, trace fit, background model and residual rejection are unchanged.
- [x] Candidate troughs are taken only from reliable line-finder samples.
- [x] Candidate pairs are matched against known Balmer-line pairs to generate provisional linear hypotheses.
- [x] Up to three deduplicated hypotheses are ranked by pattern support; none is auto-selected.
- [x] Hypothesis predictions are provisional gold guides only.
- [x] Two confirmed anchors supersede any selected pattern hypothesis.
- [x] Local predicted-line refinement uses an independent shoulder-based continuum.
- [x] Reference Commit requires at least three explicitly confirmed Balmer anchors.
- [x] Quadratic calibration still requires at least three anchors by construction.
- [ ] Full Android/Compose Gradle compilation remains to be run in the MethodMesh app project.

## Global spectral-geometry prior

- [x] Pattern hypotheses are rejected if the Balmer series is compressed into a small part of the selected visible trace.
- [x] Hα is constrained to the RED-side portion of the trace and Hδ to the VIOLET-side portion.
- [x] Implied whole-trace wavelength span is constrained by a deliberately broad visible-spectrum plausibility range.
- [x] Hypothesis ranking includes an explicit geometry score alongside local trough support.
- [x] Geometry diagnostics are shown to the user in each hypothesis card.
- [x] Horne extraction and line-finder normalization are unchanged in this revision.

## Chromatic wavelength bootstrap revision

- [x] RGB colour is used only as a coarse wavelength prior, never as the committed wavelength solution.
- [x] Chromaticity removes overall brightness before matching.
- [x] Dark/desaturated colour samples are down-weighted.
- [x] Observed VIOLET → RED colour is aligned monotonically to an approximate visible spectral-colour locus.
- [x] Candidate endpoint ranges are searched rather than assuming exact 400/700 nm endpoints.
- [x] The UI shows observed and ideal aligned colour strips plus approximate wavelength ticks.
- [x] Balmer local-refinement windows can be opened from chromatic predictions before any anchors are confirmed.
- [x] Two confirmed anchors supersede the chromatic prior for subsequent predictions.
- [x] Three confirmed Balmer anchors remain mandatory before Reference Commit.
- [x] Horne extraction and its QA diagnostics are unchanged in this revision.
- [ ] Full Android/Compose Gradle compilation remains to be run in the MethodMesh app project.

- [x] Automatic chromatic Balmer guide positions are gated off when chromatic fit quality is <25% or useful colour coverage is <15%; weak mappings remain visible for QA only.

## Colour-transition boundary revision

- [x] RED/VIOLET endpoint selection remains mandatory and unchanged.
- [x] Optional RED/YELLOW, YELLOW/GREEN, GREEN/BLUE and BLUE/VIOLET boundaries can be placed before extraction/calibration.
- [x] Boundary picker reuses the established full-screen hold/magnifier/deadband/manual-coordinate interaction.
- [x] Selected landmark coordinates are held in saveable working state and survive ordinary recomposition/rotation.
- [x] Landmark wavelength values are broad soft priors, not exact wavelength calibration points.
- [x] Landmarks are projected onto the optimised trace and incorporated into the monotonic chromatic DTW objective.
- [x] Chromatic QA displays observed/ideal boundary positions and reports boundary agreement.
- [x] Two or more consistent landmarks can rescue a weak RGB-only bootstrap; poor agreement remains gated.
- [x] Confirmed Balmer anchors supersede colour-derived guide positions.
- [x] Horne extraction engine and its QA diagnostics are unchanged.
- [ ] Full Android/Compose Gradle compilation remains to be run in the MethodMesh app project.
