package com.example.methodmesh.modules.display

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.graphics.ImageDecoder
import android.graphics.drawable.Animatable as AndroidAnimatable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.view.WindowManager
import android.widget.ImageView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.security.MessageDigest
import java.time.Instant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs

class DisplayCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = DisplayShowMethod.ID
    override val title = DisplayShowMethod.title
    override val description = DisplayShowMethod.help

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        DisplayUi(context, onBack, onConfirmed, onCancel)
    }
}

@Composable
private fun DisplayUi(
    context: CapabilityScreenContext,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit
) {
    val androidContext = LocalContext.current
    fun initial(key: String, fallback: String) =
        context.action.settings[key] ?: context.action.settings["input_$key"] ?: fallback

    var contentKind by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("content_kind", "text")) }
    var text by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("text", DisplayShowMethod.DEFAULT_TEXT)) }
    var mediaUri by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("media_uri", "")) }
    var mediaMime by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("media_mime", "")) }
    var mediaSha256 by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("media_sha256", "")) }
    var motion by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("motion", "still")) }
    var theme by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("theme", "white_on_black")) }
    var alignment by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("alignment", "center")) }
    var rotation by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("content_rotation", "0").toIntOrNull() ?: 0) }
    var autoFit by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("auto_fit", "true").toBoolean()) }
    var textScale by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("text_scale", "1.0").toFloatOrNull() ?: 1f) }
    var speed by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("speed", "1.0").toFloatOrNull() ?: 1f) }
    var direction by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("direction", "left")) }
    var highBrightness by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("high_brightness", "true").toBoolean()) }
    var showing by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
    var startedIso by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var startedElapsed by rememberSaveable(context.action.canonicalId) { mutableStateOf(0L) }
    var autoStarted by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
    var committed by remember { mutableStateOf<ExecutionResult?>(null) }
    var committedPreview by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                androidContext.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            mediaUri = uri.toString()
            mediaMime = androidContext.contentResolver.getType(uri).orEmpty()
            contentKind = "media"
        }
    }

    LaunchedEffect(mediaUri) {
        mediaSha256 = if (mediaUri.isBlank()) {
            ""
        } else {
            withContext(Dispatchers.IO) { sha256ForUri(androidContext, mediaUri) }
        }
    }

    fun settings() = context.action.settings + mapOf(
        "content_kind" to contentKind,
        "text" to text,
        "media_uri" to mediaUri,
        "media_mime" to mediaMime,
        "media_sha256" to mediaSha256,
        "motion" to motion,
        "theme" to theme,
        "alignment" to alignment,
        "content_rotation" to rotation.toString(),
        "auto_fit" to autoFit.toString(),
        "text_scale" to textScale.toString(),
        "speed" to speed.toString(),
        "direction" to direction,
        "high_brightness" to highBrightness.toString()
    )

    fun contentReady() = when (contentKind) {
        "media" -> mediaUri.isNotBlank()
        else -> text.isNotBlank()
    }

    fun startDisplay() {
        if (!contentReady()) return
        startedIso = Instant.now().toString()
        startedElapsed = android.os.SystemClock.elapsedRealtime()
        showing = true
    }

    fun finishDisplay(commit: Boolean) {
        showing = false
        if (!commit || startedIso.isBlank()) return
        val stopped = Instant.now().toString()
        val elapsed = (android.os.SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(0L)
        val values = DisplayShowMethod.values(
            settings = settings(),
            startedIso = startedIso,
            stoppedIso = stopped,
            elapsedMs = elapsed,
            completionReason = "stopped_by_operator"
        )
        val request = DisplayShowMethod.request(
            DisplayShowMethod.ID,
            context.request.invocationContext.asMap(DisplayShowMethod.ID) + settings() + values,
            emptyList(),
            emptyList()
        )
        committedPreview = values
        committed = DisplayShowMethod.result(request, values, context.request.invocationContext)
    }

    LaunchedEffect(context.startsImmediately, autoStarted, committed, contentKind, text, mediaUri) {
        if (context.startsImmediately && !autoStarted && committed == null && contentReady()) {
            autoStarted = true
            startDisplay()
        }
    }

    LaunchedEffect(contentKind) {
        if (contentKind == "media" && motion == "scroll") motion = "still"
    }

    LaunchedEffect(motion) {
        if (motion == "flash" && speed > 2f) speed = 2f
    }

    CapabilityScreenScaffold(
        title = DisplayShowMethod.title,
        capabilityId = DisplayShowMethod.ID,
        context = context,
        canGoBack = context.stepNumber > 1,
        capturedResult = committed,
        resultPreview = committedPreview,
        onBack = onBack,
        onRetry = {
            committed = null
            committedPreview = emptyMap()
            autoStarted = false
        },
        onConfirm = { committed?.let(onConfirmed) },
        onCancel = {
            if (showing) finishDisplay(false)
            onCancel()
        }
    ) {
        if (committed == null) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (context.settingShouldBeShown("content_kind")) {
                    ChoiceRow("Content", contentKind, listOf("text", "media")) { contentKind = it }
                }

                if (contentKind == "text") {
                    if (context.settingShouldBeShown("text")) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { text = it },
                            label = { Text("Message / emoji") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                } else {
                    if (context.settingShouldBeShown("media_uri")) {
                        Button(
                            onClick = { mediaPicker.launch(arrayOf("image/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (mediaUri.isBlank()) "Choose image / GIF" else "Choose different image / GIF") }
                    }
                    if (mediaUri.isNotBlank()) {
                        Text(
                            text = mediaUri.substringAfterLast('/'),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                DisplayPreview(
                    contentKind = contentKind,
                    text = text,
                    mediaUri = mediaUri,
                    theme = theme
                )

                if (context.settingShouldBeShown("motion")) {
                    val motions = if (contentKind == "media") listOf("still", "flash", "pulse") else listOf("still", "scroll", "flash", "pulse")
                    ChoiceRow("Motion", if (motion in motions) motion else "still", motions) { motion = it }
                }
                if (context.settingShouldBeShown("theme")) {
                    ChoiceRow(
                        "Appearance",
                        theme,
                        listOf("white_on_black", "black_on_white", "black_on_yellow", "neon", "rainbow", "pride", "fabulous")
                    ) { theme = it }
                }
                if (contentKind == "text" && context.settingShouldBeShown("alignment")) {
                    ChoiceRow("Alignment", alignment, listOf("start", "center", "end")) { alignment = it }
                }
                if (context.settingShouldBeShown("content_rotation")) {
                    ChoiceRow("Rotation", rotation.toString(), listOf("0", "90", "180", "270")) {
                        rotation = it.toIntOrNull() ?: 0
                    }
                }
                if (contentKind == "text" && context.settingShouldBeShown("auto_fit")) {
                    ChoiceRow("Sizing", if (autoFit) "fit" else "manual", listOf("fit", "manual")) {
                        autoFit = it == "fit"
                    }
                }
                if (contentKind == "text" && !autoFit && context.settingShouldBeShown("text_scale")) {
                    Stepper(
                        "Text size",
                        textScale,
                        { textScale = (textScale - .25f).coerceAtLeast(.25f) },
                        { textScale = (textScale + .25f).coerceAtMost(4f) }
                    )
                }
                if (motion != "still" && context.settingShouldBeShown("speed")) {
                    val maxSpeed = if (motion == "flash") 2f else 4f
                    Stepper(
                        if (motion == "flash") "Flash rate (Hz, max 2)" else "Motion speed",
                        speed,
                        { speed = (speed - .25f).coerceAtLeast(.25f) },
                        { speed = (speed + .25f).coerceAtMost(maxSpeed) }
                    )
                }
                if (motion == "scroll" && context.settingShouldBeShown("direction")) {
                    ChoiceRow("Scroll direction", direction, listOf("left", "right")) { direction = it }
                }
                if (context.settingShouldBeShown("high_brightness")) {
                    ChoiceRow("Brightness", if (highBrightness) "high" else "normal", listOf("high", "normal")) {
                        highBrightness = it == "high"
                    }
                }

                Button(
                    enabled = contentReady(),
                    onClick = { startDisplay() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("SHOW") }
            }
        }
    }

    if (showing) {
        FullScreenDisplay(
            contentKind = contentKind,
            text = text,
            mediaUri = mediaUri,
            alignment = alignment,
            rotation = rotation,
            autoFit = autoFit,
            textScale = textScale,
            motion = motion,
            speed = speed,
            direction = direction,
            theme = theme,
            highBrightness = highBrightness,
            onScale = {
                autoFit = false
                textScale = it
            },
            onFit = { autoFit = true },
            onRotation = { rotation = it },
            onSpeed = { speed = it },
            onStop = { finishDisplay(true) },
            onCancel = { finishDisplay(false) }
        )
    }
}

@Composable
private fun DisplayPreview(
    contentKind: String,
    text: String,
    mediaUri: String,
    theme: String
) {
    val palette = paletteFor(theme)
    Card(Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .displayBackground(palette)
                .padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            if (contentKind == "media") {
                if (mediaUri.isBlank()) {
                    Text("Choose an image, GIF or animated WebP", color = palette.foreground, textAlign = TextAlign.Center)
                } else {
                    MediaContent(mediaUri, Modifier.fillMaxSize())
                }
            } else {
                Text(
                    text = text.ifBlank { "Your message" },
                    color = palette.foreground,
                    style = MaterialTheme.typography.headlineMedium,
                    textAlign = TextAlign.Center,
                    maxLines = 4
                )
            }
        }
    }
}

@Composable
private fun FullScreenDisplay(
    contentKind: String,
    text: String,
    mediaUri: String,
    alignment: String,
    rotation: Int,
    autoFit: Boolean,
    textScale: Float,
    motion: String,
    speed: Float,
    direction: String,
    theme: String,
    highBrightness: Boolean,
    onScale: (Float) -> Unit,
    onFit: () -> Unit,
    onRotation: (Int) -> Unit,
    onSpeed: (Float) -> Unit,
    onStop: () -> Unit,
    onCancel: () -> Unit
) {
    val view = LocalView.current
    val activity = LocalContext.current.findActivity()
    var controls by rememberSaveable { mutableStateOf(true) }
    var paused by rememberSaveable { mutableStateOf(false) }
    val palette = paletteFor(theme)

    DisposableEffect(activity, view, highBrightness) {
        val window = activity?.window
        val oldBrightness = window?.attributes?.screenBrightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        view.keepScreenOn = true
        if (highBrightness) {
            window?.attributes = window?.attributes?.also { it.screenBrightness = 1f }
        }
        window?.decorView?.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        onDispose {
            view.keepScreenOn = false
            window?.attributes = window?.attributes?.also { it.screenBrightness = oldBrightness }
            window?.decorView?.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }

    LaunchedEffect(controls) {
        if (controls) {
            delay(3000)
            controls = false
        }
    }

    BackHandler { onCancel() }

    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .displayBackground(palette)
                .clipToBounds()
                .pointerInput(Unit) { detectTapGestures { controls = !controls } }
                .pointerInput(contentKind, textScale) {
                    if (contentKind == "text") {
                        detectTransformGestures { _, _, zoom, _ ->
                            onScale((textScale * zoom).coerceIn(.25f, 4f))
                        }
                    }
                }
        ) {
            DisplayContent(
                contentKind = contentKind,
                text = text,
                mediaUri = mediaUri,
                alignment = alignment,
                rotation = rotation,
                autoFit = autoFit,
                textScale = textScale,
                motion = motion,
                speed = speed,
                direction = direction,
                paused = paused,
                palette = palette
            )

            if (controls) {
                LiveControls(
                    contentKind = contentKind,
                    motion = motion,
                    scale = textScale,
                    rotation = rotation,
                    speed = speed,
                    paused = paused,
                    onScale = onScale,
                    onFit = onFit,
                    onRotation = onRotation,
                    onSpeed = onSpeed,
                    onPause = { paused = !paused },
                    onStop = onStop,
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }
}

@Composable
private fun DisplayContent(
    contentKind: String,
    text: String,
    mediaUri: String,
    alignment: String,
    rotation: Int,
    autoFit: Boolean,
    textScale: Float,
    motion: String,
    speed: Float,
    direction: String,
    paused: Boolean,
    palette: DisplayPalette
) {
    val transition = rememberInfiniteTransition(label = "display-effect")
    val flashHz = speed.coerceIn(.25f, 2f)
    val alpha = when {
        paused -> 1f
        motion == "flash" -> {
            val value by transition.animateFloat(
                initialValue = 1f,
                targetValue = 0.05f,
                animationSpec = infiniteRepeatable(
                    animation = tween((500f / flashHz).toInt().coerceAtLeast(250), easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "flash-alpha"
            )
            value
        }
        motion == "pulse" -> {
            val value by transition.animateFloat(
                initialValue = 1f,
                targetValue = 0.5f,
                animationSpec = infiniteRepeatable(
                    animation = tween((900f / speed.coerceIn(.25f, 4f)).toInt().coerceAtLeast(225)),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "pulse-alpha"
            )
            value
        }
        else -> 1f
    }

    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val quarterTurn = rotation % 180 != 0
        val viewport = Modifier
            .width(if (quarterTurn) maxHeight else maxWidth)
            .height(if (quarterTurn) maxWidth else maxHeight)
            .graphicsLayer(rotationZ = rotation.toFloat(), alpha = alpha)

        if (contentKind == "media") {
            Box(viewport.padding(20.dp), contentAlignment = Alignment.Center) {
                MediaContent(mediaUri, Modifier.fillMaxSize())
            }
        } else if (motion == "scroll") {
            ScrollingText(
                text = text,
                direction = direction,
                speed = speed,
                paused = paused,
                palette = palette,
                textScale = textScale,
                modifier = viewport
            )
        } else {
            FittedText(
                text = text,
                alignment = alignment,
                autoFit = autoFit,
                textScale = textScale,
                palette = palette,
                modifier = viewport.padding(22.dp)
            )
        }
    }
}

@Composable
private fun FittedText(
    text: String,
    alignment: String,
    autoFit: Boolean,
    textScale: Float,
    palette: DisplayPalette,
    modifier: Modifier = Modifier
) {
    val align = when (alignment) {
        "start" -> TextAlign.Start
        "end" -> TextAlign.End
        else -> TextAlign.Center
    }
    var fittedSp by remember(text, autoFit, textScale) { mutableStateOf(if (autoFit) 600f else 92f * textScale) }
    val fontSp = if (autoFit) fittedSp else 92f * textScale

    Box(modifier, contentAlignment = Alignment.Center) {
        Text(
            text = text,
            style = TextStyle(
                color = palette.foreground,
                fontSize = fontSp.sp,
                fontWeight = FontWeight.Bold,
                textAlign = align,
                shadow = palette.shadow
            ),
            onTextLayout = { result ->
                if (autoFit && (result.didOverflowWidth || result.didOverflowHeight) && fittedSp > 18f) {
                    fittedSp = (fittedSp * 0.82f).coerceAtLeast(18f)
                }
            },
            modifier = Modifier.widthIn(max = 1600.dp)
        )
    }
}

@Composable
private fun ScrollingText(
    text: String,
    direction: String,
    speed: Float,
    paused: Boolean,
    palette: DisplayPalette,
    textScale: Float,
    modifier: Modifier = Modifier
) {
    var containerWidth by remember { mutableStateOf(0) }
    var textWidth by remember { mutableStateOf(0) }
    val offset = remember { Animatable(0f) }
    val left = direction != "right"
    val fontSize = (104f * textScale).coerceIn(26f, 360f)

    LaunchedEffect(containerWidth, textWidth, direction, speed, paused, text) {
        if (containerWidth <= 0 || textWidth <= 0) return@LaunchedEffect
        if (paused) {
            offset.stop()
            return@LaunchedEffect
        }
        val start = if (left) containerWidth.toFloat() else -textWidth.toFloat()
        val end = if (left) -textWidth.toFloat() else containerWidth.toFloat()
        val low = minOf(start, end)
        val high = maxOf(start, end)
        if (offset.value !in low..high) offset.snapTo(start)
        while (true) {
            val fullDistance = abs(end - start).coerceAtLeast(1f)
            val remaining = abs(end - offset.value)
            val fullDuration = (9000f / speed.coerceIn(.25f, 4f)).toInt().coerceAtLeast(1000)
            val duration = (fullDuration * (remaining / fullDistance)).toInt().coerceAtLeast(100)
            offset.animateTo(end, animationSpec = tween(duration, easing = LinearEasing))
            offset.snapTo(start)
        }
    }

    Box(
        modifier
            .clipToBounds()
            .onGloballyPositioned { containerWidth = it.size.width },
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            maxLines = 1,
            softWrap = false,
            style = TextStyle(
                color = palette.foreground,
                fontSize = fontSize.sp,
                fontWeight = FontWeight.Bold,
                shadow = palette.shadow
            ),
            modifier = Modifier
                .onGloballyPositioned { textWidth = it.size.width }
                .graphicsLayer(translationX = offset.value)
        )
    }
}

@Composable
private fun MediaContent(uriText: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val drawable = remember(uriText) { loadMediaDrawable(context, uriText) }

    DisposableEffect(drawable) {
        (drawable as? AndroidAnimatable)?.start()
        onDispose { (drawable as? AndroidAnimatable)?.stop() }
    }

    if (drawable == null) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text("Unable to open media", color = Color.White)
        }
        return
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
            }
        },
        update = { imageView -> imageView.setImageDrawable(drawable) }
    )
}

@Composable
private fun LiveControls(
    contentKind: String,
    motion: String,
    scale: Float,
    rotation: Int,
    speed: Float,
    paused: Boolean,
    onScale: (Float) -> Unit,
    onFit: () -> Unit,
    onRotation: (Int) -> Unit,
    onSpeed: (Float) -> Unit,
    onPause: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(start = 12.dp, end = 12.dp, bottom = 18.dp),
        color = Color.Black.copy(alpha = .78f)
    ) {
        Row(
            Modifier
                .padding(10.dp)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (contentKind == "text") {
                OutlinedButton(onClick = { onScale((scale - .15f).coerceAtLeast(.25f)) }) { Text("A−") }
                OutlinedButton(onClick = { onScale((scale + .15f).coerceAtMost(4f)) }) { Text("A+") }
                OutlinedButton(onClick = onFit) { Text("Fit") }
            }
            OutlinedButton(onClick = { onRotation((rotation + 90) % 360) }) { Text("Rotate") }
            if (motion != "still") {
                val maxSpeed = if (motion == "flash") 2f else 4f
                OutlinedButton(onClick = { onSpeed((speed - .25f).coerceAtLeast(.25f)) }) { Text("Slower") }
                OutlinedButton(onClick = { onSpeed((speed + .25f).coerceAtMost(maxSpeed)) }) { Text("Faster") }
                OutlinedButton(onClick = onPause) { Text(if (paused) "Resume" else "Pause") }
            }
            Button(onClick = onStop) { Text("STOP") }
        }
    }
}

@Composable
private fun ChoiceRow(
    label: String,
    selected: String,
    choices: List<String>,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            choices.forEach { choice ->
                if (choice == selected) {
                    Button(onClick = { onSelect(choice) }) { Text(pretty(choice)) }
                } else {
                    OutlinedButton(onClick = { onSelect(choice) }) { Text(pretty(choice)) }
                }
            }
        }
    }
}

@Composable
private fun Stepper(
    label: String,
    value: Float,
    down: () -> Unit,
    up: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$label: ${if (value % 1f == 0f) value.toInt() else value}")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = down) { Text("−") }
            OutlinedButton(onClick = up) { Text("+") }
        }
    }
}

private data class DisplayPalette(
    val background: Color,
    val foreground: Color,
    val brush: Brush? = null,
    val shadow: Shadow? = null
)

private fun paletteFor(theme: String): DisplayPalette = when (theme) {
    "black_on_white" -> DisplayPalette(Color.White, Color.Black)
    "black_on_yellow" -> DisplayPalette(Color(0xFFFFE600), Color.Black)
    "neon" -> DisplayPalette(
        background = Color.Black,
        foreground = Color(0xFF00FFFF),
        shadow = Shadow(Color(0xFFFF00FF), blurRadius = 18f)
    )
    "rainbow" -> DisplayPalette(
        background = Color.Black,
        foreground = Color.White,
        brush = Brush.linearGradient(
            listOf(
                Color(0xFFE53935), Color(0xFFFF9800), Color(0xFFFFEB3B),
                Color(0xFF43A047), Color(0xFF1E88E5), Color(0xFF8E24AA)
            )
        ),
        shadow = Shadow(Color.Black, blurRadius = 12f)
    )
    "pride" -> DisplayPalette(
        background = Color.Black,
        foreground = Color.White,
        brush = Brush.verticalGradient(
            listOf(
                Color(0xFFE40303), Color(0xFFFF8C00), Color(0xFFFFED00),
                Color(0xFF008026), Color(0xFF24408E), Color(0xFF732982)
            )
        ),
        shadow = Shadow(Color.Black, blurRadius = 14f)
    )
    "fabulous" -> DisplayPalette(
        background = Color(0xFF24002E),
        foreground = Color.White,
        brush = Brush.linearGradient(
            listOf(Color(0xFFFF1493), Color(0xFF7B2CFF), Color(0xFF00E5FF), Color(0xFFFFD700))
        ),
        shadow = Shadow(Color(0xFFFF00FF), blurRadius = 20f)
    )
    else -> DisplayPalette(Color.Black, Color.White)
}

private fun Modifier.displayBackground(palette: DisplayPalette): Modifier {
    val base = background(palette.background)
    return palette.brush?.let { base.background(it) } ?: base
}

private fun loadMediaDrawable(context: Context, uriText: String): Drawable? {
    if (uriText.isBlank()) return null
    val uri = runCatching { Uri.parse(uriText) }.getOrNull() ?: return null
    return runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            ImageDecoder.decodeDrawable(ImageDecoder.createSource(context.contentResolver, uri))
        } else {
            @Suppress("DEPRECATION")
            context.contentResolver.openInputStream(uri)?.use { Drawable.createFromStream(it, uri.toString()) }
        }
    }.getOrNull()
}

private fun sha256ForUri(context: Context, uriText: String): String {
    val uri = runCatching { Uri.parse(uriText) }.getOrNull() ?: return ""
    return runCatching {
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        } ?: return@runCatching ""
        digest.digest().joinToString("") { byte -> "%02x".format(byte) }
    }.getOrDefault("")
}

private fun pretty(value: String) = value
    .replace('_', ' ')
    .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
