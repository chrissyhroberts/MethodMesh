# MethodMesh Display

**Module ID:** `display`  
**Module version:** 0.2.0  
**Maturity:** Development

Display turns the current Android device into an across-the-room sign, status surface or deliberately expressive visual display.

## Canonical capability

There is one method only:

`display.show`

The module deliberately does **not** expose separate static, marquee, board, code or sequence methods. Those were presentation variants of the same action and added unnecessary capability surface area.

A multi-line message is simply text containing line breaks. A giant code is simply short text that auto-fits. A marquee is `motion=scroll`. A flashing sign is `motion=flash`. Emoji are normal Unicode content and scale with the rest of the message.

## Content

`display.show` accepts:

- `content_kind=text` — text, numbers, symbols and emoji;
- `content_kind=media` — an Android `content://` URI for a local image, GIF or animated WebP.

Local media selection uses Android's document picker and retains read permission where Android grants it. On Android 9/API 28 and later, animated GIF/WebP rendering uses the platform `ImageDecoder`; API 27 receives the platform drawable fallback and may therefore show only a static frame for formats whose animation is not supported there.

The canonical result records the supplied media URI, MIME type and SHA-256 when the source can be read.

## Motion

`motion` is one of:

- `still`
- `scroll`
- `flash`
- `pulse`

Scrolling supports left/right direction and live speed changes. Pause preserves the current marquee position rather than jumping back to the centre.

`flash` is deliberately hard-capped at **2 Hz**, even if a caller supplies a larger speed value. This keeps the requested flashing behaviour away from common rapid-strobe frequencies while still requiring appropriate judgement for photosensitive users. `pulse` is a gentler opacity animation.

Media uses still, flash or pulse; scrolling is intentionally text-only.

## Appearance

Built-in appearance values are:

- `white_on_black`
- `black_on_white`
- `black_on_yellow`
- `neon`
- `rainbow`
- `pride`
- `fabulous`

The first three are practical high-visibility sign styles. The remainder deliberately allow the same MethodMesh capability to function as a celebration, event, welcome or expressive surface without creating novelty-only methods.

Presentation styling does not change the canonical method identity.

## Native interaction

The normal workflow is:

**configure -> SHOW -> live display -> STOP -> Commit/result**

The full-screen presentation:

- keeps the screen awake;
- can temporarily request maximum brightness;
- auto-fits text by default;
- supports manual A− / A+ resizing and pinch resizing;
- supports 0/90/180/270-degree content rotation independently of Android auto-rotate;
- supports live motion speed adjustment and pause/resume;
- auto-hides the control rail after three seconds;
- reveals controls again with a tap;
- keeps the control rail above the Android navigation/gesture region with additional bottom clearance;
- commits only when **STOP** is used;
- treats Android Back as cancellation of the uncommitted presentation.

`Fit` returns text to automatic fitting. Manual resizing turns automatic fitting off until Fit is selected again.

## Presets, protocols and external calls

All launch paths call the same `display.show` method. There is no dashboard-only or transport-only implementation.

Representative settings:

- `content_kind`
- `text`
- `media_uri`
- `motion`
- `theme`
- `alignment`
- `content_rotation`
- `auto_fit`
- `text_scale`
- `speed`
- `direction`
- `high_brightness`

Fixed preset values may be hidden by the host; Ask-when-run values remain available through the normal shared MethodMesh settings contract.

External/ODK launches with all required settings fixed may start presentation immediately. STOP creates the canonical result, after which the normal shared automatic-return lifecycle returns to the caller.

## Canonical outputs

The method emits:

- `display_status`
- `display_result`
- `display_content_kind`
- `display_text`
- `display_media_uri`
- `display_media_mime`
- `display_media_sha256`
- `display_target`
- `display_motion`
- `display_theme`
- `display_alignment`
- `display_content_rotation`
- `display_auto_fit`
- `display_text_scale`
- `display_speed`
- `display_direction`
- `display_high_brightness`
- `display_started_time_iso`
- `display_stopped_time_iso`
- `display_elapsed_ms`
- `display_completion_reason`
- `display_audit_json`
- `display_error`

The MethodMesh transport may additionally provide `methodmesh_full_json` according to the normal payload contract.

## Target abstraction

v0.2 renders to `local_screen` only. `display_target` remains explicit so that later renderers can address HDMI/secondary Android displays, browser surfaces, Cast targets, ESP32 signs, e-ink or other trusted MethodMesh Devices without multiplying the canonical method surface.

The architectural seam remains:

`display.show request -> presentation model -> renderer -> target`

The semantic action is stable; rendering technology is replaceable.
