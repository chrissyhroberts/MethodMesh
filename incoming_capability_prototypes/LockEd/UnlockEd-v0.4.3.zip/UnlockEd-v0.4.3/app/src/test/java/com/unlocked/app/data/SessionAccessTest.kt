package com.unlocked.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionAccessTest {
    private val pkg = "example.target"

    @Test fun authorizedSessionGetsAtLeastOneMinuteGrace() {
        SessionAccess.clearAll(pkg)
        SessionAccess.authorizeLaunch(pkg)
        assertTrue(SessionAccess.isLaunchAuthorized(pkg))
        SessionAccess.endSession(pkg, nowElapsedMillis = 1_000L, graceMillis = 60_000L)
        assertFalse(SessionAccess.isLaunchAuthorized(pkg))
        assertTrue(SessionAccess.resumeFromGrace(pkg, 60_999L))
    }

    @Test fun graceExpires() {
        SessionAccess.clearAll(pkg)
        SessionAccess.authorizeLaunch(pkg)
        SessionAccess.endSession(pkg, nowElapsedMillis = 1_000L, graceMillis = 60_000L)
        assertFalse(SessionAccess.resumeFromGrace(pkg, 61_001L))
    }

    @Test fun unauthorisedCandidateDoesNotCreateGrace() {
        SessionAccess.clearAll(pkg)
        SessionAccess.endSession(pkg, nowElapsedMillis = 1_000L, graceMillis = 60_000L)
        assertFalse(SessionAccess.resumeFromGrace(pkg, 2_000L))
    }
}
