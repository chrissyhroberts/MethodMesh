package com.unlocked.app.data

/**
 * In-process launch/session authorization.
 *
 * A successful UnlockEd decision authorizes the whole app launch. When the user genuinely leaves
 * the target app, that authorization becomes a short re-entry grace period instead of disappearing
 * immediately. This prevents app-switching/Recents from creating a new gate every few seconds.
 */
object SessionAccess {
    private val activeAuthorizations = mutableSetOf<String>()
    private val reopen = mutableSetOf<String>()
    private val graceUntilElapsed = mutableMapOf<String, Long>()

    @Synchronized
    fun authorizeLaunch(packageName: String) {
        activeAuthorizations += packageName
        reopen += packageName
        graceUntilElapsed.remove(packageName)
    }

    /** Promote a still-valid grace period back into an active session. */
    @Synchronized
    fun resumeFromGrace(packageName: String, nowElapsedMillis: Long): Boolean {
        val until = graceUntilElapsed[packageName] ?: return false
        if (nowElapsedMillis > until) {
            graceUntilElapsed.remove(packageName)
            return false
        }
        activeAuthorizations += packageName
        return true
    }

    @Synchronized
    fun isLaunchAuthorized(packageName: String): Boolean = packageName in activeAuthorizations

    /**
     * End a genuine foreground session. Authorized sessions receive re-entry grace; un-authorized
     * candidate events do not create grace.
     */
    @Synchronized
    fun endSession(packageName: String, nowElapsedMillis: Long, graceMillis: Long) {
        val wasAuthorized = activeAuthorizations.remove(packageName)
        reopen.remove(packageName)
        if (wasAuthorized) {
            graceUntilElapsed[packageName] = nowElapsedMillis + graceMillis.coerceAtLeast(60_000L)
        }
    }

    @Synchronized fun consumeReopen(packageName: String): Boolean = reopen.remove(packageName)

    @Synchronized
    fun clearAll(packageName: String) {
        activeAuthorizations.remove(packageName)
        reopen.remove(packageName)
        graceUntilElapsed.remove(packageName)
    }
}
