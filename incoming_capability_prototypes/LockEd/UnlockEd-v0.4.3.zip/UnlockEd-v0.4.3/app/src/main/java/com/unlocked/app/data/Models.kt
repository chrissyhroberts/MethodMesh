package com.unlocked.app.data

enum class AnswerMode {
    TYPED,
    MULTIPLE_CHOICE
}

enum class GateType {
    NONE,
    LEARNING,
    BIOMETRIC
}

enum class LearningPreset {
    CUSTOM_TIMES_TABLES,
    YEAR_1_2,
    YEAR_3_4,
    YEAR_5_6,
    YEAR_7_9,
    GCSE_FOUNDATION,
    GCSE_HIGHER
}

enum class OverrideFriction {
    HOLD,
    SPEAK,
    HOLD_AND_SPEAK
}

data class AppRule(
    val packageName: String,
    val awarenessEnabled: Boolean = true,
    val gateType: GateType = GateType.LEARNING,
    val questionsPerGate: Int = 3,
    val earnedUsageMinutes: Int = 15,
    val wrongAnswerDelaySeconds: Int = 10,
    val answerMode: AnswerMode = AnswerMode.TYPED,
    val learningPreset: LearningPreset = LearningPreset.CUSTOM_TIMES_TABLES,
    val tables: Set<Int> = (2..12).toSet(),
    val dailyTimeTargetMinutes: Int = 0,
    val dailyOpenTarget: Int = 0,
    val sessionTargetMinutes: Int = 0,
    val quietHoursEnabled: Boolean = false,
    val quietStartMinutes: Int = 22 * 60 + 30,
    val quietEndMinutes: Int = 7 * 60,
    val overrideFriction: OverrideFriction = OverrideFriction.SPEAK,
    val overridePhrase: String = "I am choosing to override the break I set for myself",
    val holdSeconds: Int = 15,
    val reentryGraceSeconds: Int = 60
)

// Compatibility name retained so older call sites/tests can migrate incrementally.
typealias GatedAppRule = AppRule

data class UsageSnapshot(
    val todayMillis: Long = 0L,
    val opensToday: Int = 0,
    val lastOpenedEpochMillis: Long = 0L,
    val lastClosedEpochMillis: Long = 0L,
    val lastSessionMillis: Long = 0L,
    val opensThisHour: Int = 0
)
