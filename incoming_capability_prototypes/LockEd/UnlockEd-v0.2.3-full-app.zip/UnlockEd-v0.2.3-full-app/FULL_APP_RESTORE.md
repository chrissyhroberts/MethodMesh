# UnlockEd v0.2.3 – full app restore

This release repairs the v0.2.2 packaging error in which only `MainActivity.kt` was included in the source archive while the manifest still referenced the missing app-gate implementation.

Restored source components:
- `accessibility/AppGateService.kt`
- `apps/InstalledAppsRepository.kt`
- `challenge/QuizSession.kt`
- `challenge/TimesTableEngine.kt`
- `data/Clock.kt`
- `data/Models.kt`
- `data/ParentPinStore.kt`
- `data/RuleStore.kt`
- `data/UsageLedger.kt`
- `gate/GateActivity.kt`

Also fixed Android 9–12 compatibility for the screen-off broadcast receiver registration.

Build matrix remains AGP 9.3.0 / Gradle 9.5.0 / JDK 17.
