package com.unlocked.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.unlocked.app.apps.InstalledAppsRepository
import com.unlocked.app.data.AndroidMonotonicClock
import com.unlocked.app.data.RuleStore
import com.unlocked.app.data.UsageLedger
import com.unlocked.app.gate.GateActivity

class AppGateService : AccessibilityService() {
    private lateinit var rules: RuleStore
    private lateinit var usage: UsageLedger
    private lateinit var apps: InstalledAppsRepository

    private val handler = Handler(Looper.getMainLooper())
    private var lastForegroundPackage: String? = null
    private var expiryRunnable: Runnable? = null

    // Debounces only the short interval between startActivity() and GateActivity becoming visible.
    // It is cleared as soon as UnlockEd itself is observed, so Recents cannot bypass the gate.
    private var gateLaunchPendingFor: String? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                settleCurrentUsage()
                cancelExpiryCheck()
                lastForegroundPackage = null
                gateLaunchPendingFor = null
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        rules = RuleStore(this)
        usage = UsageLedger(this)
        apps = InstalledAppsRepository(this)
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::rules.isInitialized) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return

        // Ignore transient windows such as keyboards and permission controllers. Gated apps are
        // selected from launchable apps, so this remains sufficient for the v0.x product model.
        if (!apps.isUserForegroundCandidate(packageName)) return

        handleForegroundPackage(packageName)
    }

    private fun handleForegroundPackage(packageName: String) {
        val now = AndroidMonotonicClock.nowMillis()
        val previous = lastForegroundPackage

        if (previous != null && previous != packageName && rules.ruleFor(previous) != null) {
            usage.stopUsing(previous, now)
        }

        if (previous != packageName) {
            cancelExpiryCheck()
            lastForegroundPackage = packageName
        }

        if (packageName == this.packageName) {
            // The gate is now visibly up; future attempts to return to the target must gate again.
            gateLaunchPendingFor = null
            return
        }

        if (packageName in apps.essentialPackages()) {
            gateLaunchPendingFor = null
            return
        }

        val rule = rules.ruleFor(packageName) ?: run {
            gateLaunchPendingFor = null
            return
        }

        val remaining = usage.remainingMillis(packageName, now)
        if (remaining <= 0L) {
            usage.clear(packageName)
            showGate(packageName)
            return
        }

        gateLaunchPendingFor = null
        usage.startUsing(packageName, now)
        scheduleExpiry(packageName, remaining)
    }

    private fun scheduleExpiry(packageName: String, remainingMillis: Long) {
        cancelExpiryCheck()
        expiryRunnable = Runnable {
            if (lastForegroundPackage == packageName && rules.ruleFor(packageName) != null) {
                usage.stopUsing(packageName)
                usage.clear(packageName)
                showGate(packageName)
            }
        }.also { handler.postDelayed(it, remainingMillis.coerceAtLeast(250L)) }
    }

    private fun cancelExpiryCheck() {
        expiryRunnable?.let(handler::removeCallbacks)
        expiryRunnable = null
    }

    private fun settleCurrentUsage() {
        val packageName = lastForegroundPackage ?: return
        if (::rules.isInitialized && rules.ruleFor(packageName) != null) {
            usage.stopUsing(packageName)
        }
    }

    private fun showGate(packageName: String) {
        if (gateLaunchPendingFor == packageName) return
        gateLaunchPendingFor = packageName

        val intent = Intent(this, GateActivity::class.java).apply {
            putExtra(GateActivity.EXTRA_TARGET_PACKAGE, packageName)
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        }

        runCatching { startActivity(intent) }
            .onFailure {
                gateLaunchPendingFor = null
                // Fail safely: if Android/OEM refuses the gate activity, leave the selected social
                // app rather than silently granting unrestricted access. Core device apps are never
                // routed through this branch.
                performGlobalAction(GLOBAL_ACTION_HOME)
            }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        cancelExpiryCheck()
        settleCurrentUsage()
        runCatching { unregisterReceiver(screenReceiver) }
        super.onDestroy()
    }
}
