package com.unlocked.app.speech

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechPhraseMatcherTest {
    private val phrase = "I am choosing to open Instagram even though I decided not to"

    @Test fun exactPhrasePasses() = assertTrue(SpeechPhraseMatcher.matches(phrase, phrase))

    @Test fun commonContractionAndMinorMishearingPasses() = assertTrue(
        SpeechPhraseMatcher.matches(phrase, "I'm choosing to open Instagram although I decided not to")
    )

    @Test fun punctuationAndHomophoneLikeErrorPasses() = assertTrue(
        SpeechPhraseMatcher.matches(phrase, "I am choosing to open instagram even though i decided not too")
    )

    @Test fun unrelatedSpeechDoesNotPass() = assertFalse(
        SpeechPhraseMatcher.matches(phrase, "open it now please")
    )

    @Test fun anyCloseRecognizerCandidateCanPass() = assertTrue(
        SpeechPhraseMatcher.matches(phrase, listOf("something unrelated", "I am choosing to open Instagram even though I decided not to"))
    )
}
