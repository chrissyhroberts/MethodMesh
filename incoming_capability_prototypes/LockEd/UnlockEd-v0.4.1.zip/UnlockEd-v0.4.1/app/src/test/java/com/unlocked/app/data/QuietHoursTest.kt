package com.unlocked.app.data

import java.time.ZoneId
import java.time.ZonedDateTime
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuietHoursTest {
    private val zone = ZoneId.of("Europe/London")
    private val rule = AppRule("test", quietHoursEnabled = true, quietStartMinutes = 22 * 60 + 30, quietEndMinutes = 7 * 60)

    @Test fun overnightWindowIncludesLateNightAndEarlyMorning() {
        assertTrue(QuietHours.isActive(rule, at(23, 0), zone))
        assertTrue(QuietHours.isActive(rule, at(6, 59), zone))
        assertFalse(QuietHours.isActive(rule, at(12, 0), zone))
    }

    private fun at(hour: Int, minute: Int): Long = ZonedDateTime.of(2026, 9, 6, hour, minute, 0, 0, zone).toInstant().toEpochMilli()
}
