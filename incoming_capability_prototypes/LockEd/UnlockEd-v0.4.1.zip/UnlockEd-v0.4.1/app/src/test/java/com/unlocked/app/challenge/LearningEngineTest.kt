package com.unlocked.app.challenge

import com.unlocked.app.data.LearningPreset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningEngineTest {
    @Test fun everyPresetGeneratesUsableIntegerQuestions() {
        LearningPreset.entries.forEach { preset ->
            repeat(200) {
                val q = LearningEngine.next(preset, (2..12).toSet())
                assertTrue(q.prompt.isNotBlank())
                val choices = LearningEngine.distractors(q)
                assertEquals(4, choices.toSet().size)
                assertTrue(q.answer in choices)
            }
        }
    }
}
