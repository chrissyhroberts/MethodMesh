package com.unlocked.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class UsageMathTest {
    @Test
    fun inactiveAllowanceDoesNotDecay() {
        assertEquals(900_000L, UsageMath.remaining(900_000L, null, 99_000_000L))
    }

    @Test
    fun foregroundTimeIsSubtractedExactly() {
        assertEquals(840_000L, UsageMath.remaining(900_000L, 1_000L, 61_000L))
    }

    @Test
    fun allowanceStopsAtZero() {
        assertEquals(0L, UsageMath.remaining(30_000L, 1_000L, 90_000L))
    }

    @Test
    fun monotonicResetCannotCreateOrDestroyAllowance() {
        assertEquals(900_000L, UsageMath.remaining(900_000L, 50_000L, 10_000L))
    }
}
