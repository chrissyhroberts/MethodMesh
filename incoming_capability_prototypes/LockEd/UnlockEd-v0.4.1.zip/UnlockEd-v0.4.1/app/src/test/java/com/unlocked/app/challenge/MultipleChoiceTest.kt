package com.unlocked.app.challenge

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MultipleChoiceTest {
    @Test
    fun choicesContainCorrectAnswerAndAreDistinct() {
        for (left in 2..12) {
            for (right in 2..12) {
                val question = TimesTableQuestion(left, right)
                val answers = MultipleChoice.answersFor(question)
                assertEquals(4, answers.size)
                assertEquals(4, answers.toSet().size)
                assertTrue(question.answer in answers)
                assertTrue(answers.all { it > 0 })
            }
        }
    }
}
