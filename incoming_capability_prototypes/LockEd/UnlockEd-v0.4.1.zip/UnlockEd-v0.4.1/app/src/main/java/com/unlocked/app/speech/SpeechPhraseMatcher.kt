package com.unlocked.app.speech

import java.text.Normalizer
import kotlin.math.max

object SpeechPhraseMatcher {
    private val filler = setOf("uh", "um", "erm", "ah", "like", "please")
    private val substitutions = mapOf(
        "im" to "i am",
        "ive" to "i have",
        "ill" to "i will",
        "id" to "i would",
        "dont" to "do not",
        "cant" to "cannot",
        "wont" to "will not",
        "isnt" to "is not",
        "wasnt" to "was not",
        "didnt" to "did not"
    )

    fun matches(expected: String, heardCandidates: List<String>): Boolean =
        heardCandidates.any { matches(expected, it) }

    fun matches(expected: String, heard: String): Boolean {
        val a = tokens(expected)
        val b = tokens(heard)
        if (a.isEmpty() || b.isEmpty()) return false

        val expectedJoined = a.joinToString(" ")
        val heardJoined = b.joinToString(" ")
        if (expectedJoined == heardJoined) return true

        val wordOverlap = multisetOverlap(a, b).toDouble() / max(a.size, b.size).toDouble()
        val editSimilarity = 1.0 - levenshtein(expectedJoined, heardJoined).toDouble() /
            max(expectedJoined.length, heardJoined.length).coerceAtLeast(1).toDouble()

        val threshold = when {
            a.size <= 3 -> 0.86
            a.size <= 6 -> 0.76
            else -> 0.66
        }
        return max(wordOverlap, editSimilarity) >= threshold ||
            (a.size >= 7 && wordOverlap >= 0.58 && editSimilarity >= 0.55)
    }

    fun normalize(text: String): String = tokens(text).joinToString(" ")

    private fun tokens(text: String): List<String> {
        var value = Normalizer.normalize(text.lowercase(), Normalizer.Form.NFKD)
            .replace(Regex("\\p{M}+"), "")
            .replace('’', '\'')
            .replace(Regex("[^a-z0-9' ]+"), " ")
            .replace("'", "")
            .replace(Regex("\\s+"), " ")
            .trim()
        substitutions.forEach { (from, to) ->
            value = value.replace(Regex("\\b${Regex.escape(from)}\\b"), to)
        }
        return value.split(' ').filter { it.isNotBlank() && it !in filler }
    }

    private fun multisetOverlap(a: List<String>, b: List<String>): Int {
        val counts = b.groupingBy { it }.eachCount().toMutableMap()
        var overlap = 0
        for (word in a) {
            val remaining = counts[word] ?: 0
            if (remaining > 0) {
                overlap++
                counts[word] = remaining - 1
            }
        }
        return overlap
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1)
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(current[j] + 1, previous[j + 1] + 1, previous[j] + cost)
            }
            previous = current
        }
        return previous[b.length]
    }
}
