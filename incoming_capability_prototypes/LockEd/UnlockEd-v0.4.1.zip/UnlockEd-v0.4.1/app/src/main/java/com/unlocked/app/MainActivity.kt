package com.unlocked.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.unlocked.app.apps.InstalledAppsRepository
import com.unlocked.app.apps.LaunchableApp
import com.unlocked.app.data.AnswerMode
import com.unlocked.app.data.AppRule
import com.unlocked.app.data.GateType
import com.unlocked.app.data.LearningPreset
import com.unlocked.app.data.OverrideFriction
import com.unlocked.app.data.ParentPinStore
import com.unlocked.app.data.RuleStore
import com.unlocked.app.data.SelfControlStore
import com.unlocked.app.data.UsageHistoryStore
import com.unlocked.app.data.UsageLedger
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId

class MainActivity : ComponentActivity() {
    private val authenticatedState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ParentEntry(
                    context = this,
                    authenticated = authenticatedState.value,
                    onAuthenticated = { authenticatedState.value = true },
                    openAccessibilitySettings = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                )
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) authenticatedState.value = false
    }
}

@Composable
private fun ParentEntry(context: Context, authenticated: Boolean, onAuthenticated: () -> Unit, openAccessibilitySettings: () -> Unit) {
    val pinStore = remember { ParentPinStore(context) }
    var hasPin by remember { mutableStateOf(pinStore.hasPin()) }
    when {
        !hasPin -> PinSetupScreen { pin ->
            pinStore.setPin(pin).also { if (it) { hasPin = true; onAuthenticated() } }
        }
        !authenticated -> PinUnlockScreen { pin -> pinStore.verify(pin).also { if (it) onAuthenticated() } }
        else -> UnlockEdHome(context, openAccessibilitySettings)
    }
}

@Composable
private fun PinSetupScreen(onSetPin: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("UnlockEd", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Create a settings PIN", style = MaterialTheme.typography.titleLarge)
            Text("This protects your UnlockEd rules and commitments from casual changes.")
            Spacer(Modifier.height(24.dp))
            PinField("PIN (4–8 digits)", pin) { pin = it }
            Spacer(Modifier.height(12.dp))
            PinField("Confirm PIN", confirm) { confirm = it }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                error = when {
                    !ParentPinStore.isValidPin(pin) -> "Use 4–8 digits."
                    pin != confirm -> "PINs do not match."
                    !onSetPin(pin) -> "Could not save the PIN."
                    else -> null
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Set PIN") }
        }
    }
}

@Composable
private fun PinUnlockScreen(onVerify: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("UnlockEd settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            PinField("Settings PIN", pin) { pin = it }
            if (error) Text("Incorrect PIN.", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { if (!onVerify(pin)) { error = true; pin = "" } }, enabled = ParentPinStore.isValidPin(pin), modifier = Modifier.fillMaxWidth()) { Text("Open settings") }
        }
    }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(8)) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
    )
}

@Composable
private fun UnlockEdHome(context: Context, openAccessibilitySettings: () -> Unit) {
    val ruleStore = remember { RuleStore(context) }
    val usageLedger = remember { UsageLedger(context) }
    val history = remember { UsageHistoryStore(context) }
    val selfControl = remember { SelfControlStore(context) }
    val appRepo = remember { InstalledAppsRepository(context) }
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var configured by remember { mutableStateOf(ruleStore.configuredPackages()) }
    var disclosureAccepted by remember { mutableStateOf(false) }
    var editingPackage by remember { mutableStateOf<String?>(null) }
    var timeTick by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) { apps = appRepo.launchableApps() }
    LaunchedEffect(Unit) { while (true) { timeTick = System.currentTimeMillis(); delay(1_000) } }

    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("UnlockEd", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Notice. Choose. Continue deliberately.", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(16.dp))

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("App awareness service", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(if (isAccessibilityServiceEnabled(context)) "Enabled." else "Disabled. Enable it after reading the disclosure below.")
                    Spacer(Modifier.height(8.dp))
                    Text("UnlockEd uses Accessibility window-change events only to know when a configured app becomes visible. It does not retrieve window content, read messages, inspect text fields, or record the screen.")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = disclosureAccepted, onCheckedChange = { disclosureAccepted = it })
                        Text("I understand and consent to this use of Accessibility events.")
                    }
                    Button(onClick = openAccessibilitySettings, enabled = disclosureAccepted) { Text("Open Accessibility settings") }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Apps", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Everything is unrestricted unless you configure it. Core device apps stay excluded.")
            Spacer(Modifier.height(8.dp))

            LazyColumn(Modifier.fillMaxSize()) {
                items(apps, key = { it.packageName }) { app ->
                    val enabled = app.packageName in configured
                    val rule = ruleStore.ruleFor(app.packageName)
                    val activeBlock = selfControl.activeBlockUntil(app.packageName, timeTick)
                    AppRuleRow(
                        app = app,
                        configured = enabled,
                        rule = rule,
                        remainingMillis = if (enabled && rule?.gateType == GateType.LEARNING) usageLedger.remainingMillis(app.packageName) else 0L,
                        todayMillis = if (enabled) history.snapshot(app.packageName).todayMillis else 0L,
                        opensToday = if (enabled) history.snapshot(app.packageName).opensToday else 0,
                        activeBlockUntil = activeBlock,
                        editing = editingPackage == app.packageName,
                        onEditToggle = { editingPackage = if (editingPackage == app.packageName) null else app.packageName },
                        onRuleChange = { updated -> ruleStore.saveRule(updated); configured = ruleStore.configuredPackages() },
                        onConfiguredChange = { shouldConfigure ->
                            if (shouldConfigure) {
                                ruleStore.saveRule(AppRule(packageName = app.packageName))
                                editingPackage = app.packageName
                            } else {
                                ruleStore.setConfigured(app.packageName, false)
                                usageLedger.clear(app.packageName)
                                selfControl.clearBlock(app.packageName)
                                if (editingPackage == app.packageName) editingPackage = null
                            }
                            configured = ruleStore.configuredPackages()
                        },
                        onBreak = { duration -> selfControl.setBlockFor(app.packageName, duration) },
                        onClearBreak = { selfControl.clearBlock(app.packageName) }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun AppRuleRow(
    app: LaunchableApp,
    configured: Boolean,
    rule: AppRule?,
    remainingMillis: Long,
    todayMillis: Long,
    opensToday: Int,
    activeBlockUntil: Long?,
    editing: Boolean,
    onEditToggle: () -> Unit,
    onRuleChange: (AppRule) -> Unit,
    onConfiguredChange: (Boolean) -> Unit,
    onBreak: (Long) -> Unit,
    onClearBreak: () -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(app.label, fontWeight = FontWeight.SemiBold)
                if (configured) {
                    val r = rule ?: AppRule(app.packageName)
                    Text(summary(r), style = MaterialTheme.typography.bodySmall)
                    Text("Today: ${formatDuration(todayMillis)} · $opensToday opens", style = MaterialTheme.typography.bodySmall)
                    if (r.gateType == GateType.LEARNING) Text(if (remainingMillis > 0) "Learning reward remaining: ${formatRemaining(remainingMillis)}" else "Learning gate due on next use", style = MaterialTheme.typography.bodySmall)
                    activeBlockUntil?.let { Text("Break active until ${formatClock(it)}", fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodySmall) }
                } else Text("No UnlockEd rule", style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = configured, onCheckedChange = onConfiguredChange)
        }

        if (configured) {
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onEditToggle) { Text(if (editing) "Done" else "Configure") }
                if (activeBlockUntil != null) Button(onClick = onClearBreak) { Text("Cancel break") }
            }
        }
        if (configured && editing) {
            Spacer(Modifier.height(12.dp))
            RuleEditor(rule ?: AppRule(app.packageName), onRuleChange, onBreak)
        }
    }
}

@Composable
private fun RuleEditor(rule: AppRule, onRuleChange: (AppRule) -> Unit, onBreak: (Long) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Section("Awareness")
            ToggleLine("Show a usage splash before opening", rule.awarenessEnabled) { onRuleChange(rule.copy(awarenessEnabled = it)) }
            Text("Voluntary targets never block the app.", style = MaterialTheme.typography.bodySmall)
            Text("Daily time target", fontWeight = FontWeight.Medium)
            ChoiceChips(listOf(0, 30, 45, 60, 90, 120), rule.dailyTimeTargetMinutes, { if (it == 0) "Off" else "$it min" }) { onRuleChange(rule.copy(dailyTimeTargetMinutes = it)) }
            Text("Daily opening target", fontWeight = FontWeight.Medium)
            ChoiceChips(listOf(0, 5, 10, 15, 20, 30), rule.dailyOpenTarget, { if (it == 0) "Off" else it.toString() }) { onRuleChange(rule.copy(dailyOpenTarget = it)) }
            Text("Session target", fontWeight = FontWeight.Medium)
            ChoiceChips(listOf(0, 10, 15, 20, 30, 45), rule.sessionTargetMinutes, { if (it == 0) "Off" else "$it min" }) { onRuleChange(rule.copy(sessionTargetMinutes = it)) }

            Section("Gate")
            EnumChips(GateType.entries.toList(), rule.gateType, ::gateLabel) { onRuleChange(rule.copy(gateType = it)) }

            if (rule.gateType == GateType.LEARNING) {
                Section("Learning")
                Text("Level", fontWeight = FontWeight.Medium)
                EnumChips(LearningPreset.entries.toList(), rule.learningPreset, ::presetLabel) { onRuleChange(rule.copy(learningPreset = it)) }
                Text("Questions needed", fontWeight = FontWeight.Medium)
                ChoiceChips(listOf(1, 2, 3, 5, 10), rule.questionsPerGate, Int::toString) { onRuleChange(rule.copy(questionsPerGate = it)) }
                Text("Foreground-use reward", fontWeight = FontWeight.Medium)
                ChoiceChips(listOf(5, 10, 15, 20, 30, 45, 60), rule.earnedUsageMinutes, { "$it min" }) { onRuleChange(rule.copy(earnedUsageMinutes = it)) }
                Text("Wrong-answer delay", fontWeight = FontWeight.Medium)
                ChoiceChips(listOf(3, 5, 10, 15, 20, 30), rule.wrongAnswerDelaySeconds, { "${it}s" }) { onRuleChange(rule.copy(wrongAnswerDelaySeconds = it)) }
                Text("Answer mode", fontWeight = FontWeight.Medium)
                EnumChips(AnswerMode.entries.toList(), rule.answerMode, { if (it == AnswerMode.TYPED) "Type" else "Multiple choice" }) { onRuleChange(rule.copy(answerMode = it)) }
            }

            Section("Take a break now")
            Text("A break is a real self-lock. It can still be overridden using your chosen tedium.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onBreak(15 * 60_000L) }) { Text("15m") }
                Button(onClick = { onBreak(30 * 60_000L) }) { Text("30m") }
                Button(onClick = { onBreak(60 * 60_000L) }) { Text("1h") }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onBreak(2 * 60 * 60_000L) }) { Text("2h") }
                Button(onClick = { onBreak(untilTomorrowMorningMillis()) }) { Text("Until morning") }
            }

            Section("Quiet hours")
            ToggleLine("Use a repeating daily self-lock", rule.quietHoursEnabled) { onRuleChange(rule.copy(quietHoursEnabled = it)) }
            if (rule.quietHoursEnabled) {
                Text("Schedule", fontWeight = FontWeight.Medium)
                QuietPresetChips(rule, onRuleChange)
            }

            Section("Override tedium")
            EnumChips(OverrideFriction.entries.toList(), rule.overrideFriction, ::overrideLabel) { onRuleChange(rule.copy(overrideFriction = it)) }
            if (rule.overrideFriction != OverrideFriction.SPEAK) {
                Text("Hold duration", fontWeight = FontWeight.Medium)
                ChoiceChips(listOf(5, 10, 15, 20, 30), rule.holdSeconds, { "${it}s" }) { onRuleChange(rule.copy(holdSeconds = it)) }
            }
            if (rule.overrideFriction != OverrideFriction.HOLD) {
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = rule.overridePhrase,
                    onValueChange = { onRuleChange(rule.copy(overridePhrase = it.take(180))) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Phrase to say aloud") },
                    supportingText = { Text("Matching is intentionally tolerant. The phrase is friction, not authentication.") }
                )
            }
        }
    }
}

@Composable private fun Section(title: String) { Spacer(Modifier.height(16.dp)); Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)) }

@Composable
private fun ToggleLine(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun ChoiceChips(values: List<Int>, selected: Int, label: (Int) -> String, onSelect: (Int) -> Unit) {
    Column { values.chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { value -> FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label(value)) }) } } } }
}

@Composable
private fun <T> EnumChips(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column { values.chunked(3).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { value -> FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(label(value)) }) } } } }
}

@Composable
private fun QuietPresetChips(rule: AppRule, onRuleChange: (AppRule) -> Unit) {
    val presets = listOf(Triple("22:30–07:00", 22 * 60 + 30, 7 * 60), Triple("23:00–07:00", 23 * 60, 7 * 60), Triple("00:00–08:00", 0, 8 * 60))
    Column { presets.forEach { (label, start, end) -> FilterChip(selected = rule.quietStartMinutes == start && rule.quietEndMinutes == end, onClick = { onRuleChange(rule.copy(quietStartMinutes = start, quietEndMinutes = end)) }, label = { Text(label) }) } }
}

private fun summary(rule: AppRule): String {
    val parts = mutableListOf<String>()
    if (rule.awarenessEnabled) parts += "awareness"
    parts += when (rule.gateType) { GateType.NONE -> "no gate"; GateType.LEARNING -> "learning"; GateType.BIOMETRIC -> "biometric" }
    if (rule.quietHoursEnabled) parts += "quiet hours"
    return parts.joinToString(" • ")
}

private fun gateLabel(type: GateType) = when (type) { GateType.NONE -> "None"; GateType.LEARNING -> "Learning"; GateType.BIOMETRIC -> "Biometric" }
private fun presetLabel(preset: LearningPreset) = when (preset) {
    LearningPreset.CUSTOM_TIMES_TABLES -> "Times tables"
    LearningPreset.YEAR_1_2 -> "Years 1–2"
    LearningPreset.YEAR_3_4 -> "Years 3–4"
    LearningPreset.YEAR_5_6 -> "Years 5–6"
    LearningPreset.YEAR_7_9 -> "Years 7–9"
    LearningPreset.GCSE_FOUNDATION -> "GCSE Foundation"
    LearningPreset.GCSE_HIGHER -> "GCSE Higher"
}
private fun overrideLabel(value: OverrideFriction) = when (value) { OverrideFriction.HOLD -> "Hold"; OverrideFriction.SPEAK -> "Speak"; OverrideFriction.HOLD_AND_SPEAK -> "Hold + speak" }
private fun formatRemaining(millis: Long): String { val s = (millis.coerceAtLeast(0) + 999) / 1000; return if (s >= 60) "${s / 60}m ${s % 60}s" else "${s}s" }
private fun formatDuration(millis: Long): String { val m = millis.coerceAtLeast(0) / 60_000; return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m" }
private fun formatClock(epochMillis: Long): String = java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(epochMillis))

private fun untilTomorrowMorningMillis(now: Long = System.currentTimeMillis()): Long {
    val zone = ZoneId.systemDefault()
    val zoned = Instant.ofEpochMilli(now).atZone(zone)
    var target = zoned.toLocalDate().atTime(7, 0).atZone(zone)
    if (!target.isAfter(zoned)) target = target.plusDays(1)
    return (target.toInstant().toEpochMilli() - now).coerceAtLeast(60_000L)
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val manager = context.getSystemService(AccessibilityManager::class.java) ?: return false
    return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { info ->
        val service = info.resolveInfo.serviceInfo
        service.packageName == context.packageName && service.name == "${context.packageName}.accessibility.AppGateService"
    }
}
