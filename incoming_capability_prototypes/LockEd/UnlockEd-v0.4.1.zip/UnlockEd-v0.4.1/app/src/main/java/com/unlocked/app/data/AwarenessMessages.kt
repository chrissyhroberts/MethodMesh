package com.unlocked.app.data

import java.util.concurrent.TimeUnit
import kotlin.random.Random

object AwarenessMessages {
    fun choose(appLabel: String, snapshot: UsageSnapshot, rule: AppRule, nowEpochMillis: Long = System.currentTimeMillis()): String {
        val candidates = mutableListOf<String>()
        val todayMinutes = TimeUnit.MILLISECONDS.toMinutes(snapshot.todayMillis)
        if (snapshot.opensToday > 0) candidates += "You’ve opened $appLabel ${snapshot.opensToday} ${if (snapshot.opensToday == 1) "time" else "times"} today."
        if (todayMinutes > 0) candidates += "$appLabel today: ${formatDuration(snapshot.todayMillis)}."
        if (snapshot.lastClosedEpochMillis > 0L) {
            val ago = (nowEpochMillis - snapshot.lastClosedEpochMillis).coerceAtLeast(0L)
            if (ago < 2L * 60L * 60L * 1000L) candidates += "You last left $appLabel ${formatAgo(ago)} ago."
        }
        if (snapshot.lastSessionMillis >= 60_000L) candidates += "Your last session lasted ${formatDuration(snapshot.lastSessionMillis)}."
        if (snapshot.opensThisHour >= 3) candidates += "This is visit ${snapshot.opensThisHour} to $appLabel this hour."
        if (rule.dailyTimeTargetMinutes > 0) {
            val targetMs = rule.dailyTimeTargetMinutes * 60_000L
            val remaining = (targetMs - snapshot.todayMillis).coerceAtLeast(0L)
            candidates += if (snapshot.todayMillis < targetMs) {
                "${formatDuration(remaining)} left to stay within today’s ${rule.dailyTimeTargetMinutes}-minute target."
            } else {
                "You’re ${formatDuration(snapshot.todayMillis - targetMs)} beyond today’s ${rule.dailyTimeTargetMinutes}-minute target."
            }
        }
        if (rule.dailyOpenTarget > 0) {
            val remaining = rule.dailyOpenTarget - snapshot.opensToday
            candidates += if (remaining >= 0) "$remaining opens left within today’s target." else "You’re ${-remaining} opens beyond today’s target."
        }
        if (rule.sessionTargetMinutes > 0 && snapshot.lastSessionMillis > 0L) {
            val targetMs = rule.sessionTargetMinutes * 60_000L
            candidates += if (snapshot.lastSessionMillis <= targetMs) {
                "Your last session stayed within your ${rule.sessionTargetMinutes}-minute session target."
            } else {
                "Your last session was ${formatDuration(snapshot.lastSessionMillis - targetMs)} longer than your session target."
            }
        }
        return candidates.randomOrNull() ?: "Opening $appLabel."
    }

    private fun formatAgo(ms: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
        return when {
            minutes < 1 -> "less than a minute"
            minutes < 60 -> "$minutes min"
            else -> "${minutes / 60}h ${minutes % 60}m"
        }
    }

    fun formatDuration(ms: Long): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(ms.coerceAtLeast(0L))
        return if (minutes < 60) "$minutes min" else "${minutes / 60}h ${minutes % 60}m"
    }
}
