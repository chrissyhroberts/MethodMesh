package com.unlocked.app.data

import android.content.Context

class RuleStore(context: Context) {
    private val prefs = context.getSharedPreferences("unlocked_rules", Context.MODE_PRIVATE)

    fun configuredPackages(): Set<String> {
        val configured = prefs.getStringSet(KEY_CONFIGURED_PACKAGES, null)
        if (configured != null) return configured.toSet()

        // v0.3 migration: every previously gated package becomes a configured Learning rule.
        val legacy = (prefs.getStringSet(KEY_LEGACY_GATED_PACKAGES, emptySet()) ?: emptySet()).toSet()
        if (legacy.isNotEmpty()) {
            prefs.edit().putStringSet(KEY_CONFIGURED_PACKAGES, legacy).apply()
        }
        return legacy
    }

    fun gatedPackages(): Set<String> = configuredPackages().filterTo(mutableSetOf()) {
        ruleFor(it)?.gateType != GateType.NONE
    }

    fun setConfigured(packageName: String, configured: Boolean) {
        val next = configuredPackages().toMutableSet().apply {
            if (configured) add(packageName) else remove(packageName)
        }
        prefs.edit().putStringSet(KEY_CONFIGURED_PACKAGES, next).apply()
    }

    // v0.3 compatibility. Disabling removes the whole UnlockEd rule; enabling creates Learning.
    fun setGated(packageName: String, gated: Boolean) {
        if (gated) saveRule(ruleFor(packageName) ?: AppRule(packageName = packageName))
        else setConfigured(packageName, false)
    }

    fun ruleFor(packageName: String): AppRule? {
        if (packageName !in configuredPackages()) return null
        return AppRule(
            packageName = packageName,
            awarenessEnabled = prefs.getBoolean("aw_$packageName", true),
            gateType = parseEnum(prefs.getString("g_$packageName", null), GateType.LEARNING),
            questionsPerGate = prefs.getInt("q_$packageName", 3).coerceIn(1, 20),
            earnedUsageMinutes = prefs.getInt("m_$packageName", 15).coerceIn(1, 240),
            wrongAnswerDelaySeconds = prefs.getInt("d_$packageName", 10).coerceIn(1, 60),
            answerMode = parseEnum(prefs.getString("a_$packageName", null), AnswerMode.TYPED),
            learningPreset = parseEnum(prefs.getString("lp_$packageName", null), LearningPreset.CUSTOM_TIMES_TABLES),
            tables = parseTables(prefs.getString("t_$packageName", DEFAULT_TABLES) ?: DEFAULT_TABLES),
            dailyTimeTargetMinutes = prefs.getInt("dt_$packageName", 0).coerceIn(0, 1440),
            dailyOpenTarget = prefs.getInt("do_$packageName", 0).coerceIn(0, 500),
            sessionTargetMinutes = prefs.getInt("st_$packageName", 0).coerceIn(0, 1440),
            quietHoursEnabled = prefs.getBoolean("qh_$packageName", false),
            quietStartMinutes = prefs.getInt("qs_$packageName", 22 * 60 + 30).coerceIn(0, 1439),
            quietEndMinutes = prefs.getInt("qe_$packageName", 7 * 60).coerceIn(0, 1439),
            overrideFriction = parseEnum(prefs.getString("of_$packageName", null), OverrideFriction.SPEAK),
            overridePhrase = prefs.getString("op_$packageName", DEFAULT_OVERRIDE_PHRASE)
                ?.trim()?.take(180).orEmpty().ifBlank { DEFAULT_OVERRIDE_PHRASE },
            holdSeconds = prefs.getInt("oh_$packageName", 15).coerceIn(5, 30)
        )
    }

    fun saveRule(rule: AppRule) {
        val safeTables = rule.tables.filter { it in 1..20 }.toSet().ifEmpty { (2..12).toSet() }
        setConfigured(rule.packageName, true)
        prefs.edit()
            .putBoolean("aw_${rule.packageName}", rule.awarenessEnabled)
            .putString("g_${rule.packageName}", rule.gateType.name)
            .putInt("q_${rule.packageName}", rule.questionsPerGate.coerceIn(1, 20))
            .putInt("m_${rule.packageName}", rule.earnedUsageMinutes.coerceIn(1, 240))
            .putInt("d_${rule.packageName}", rule.wrongAnswerDelaySeconds.coerceIn(1, 60))
            .putString("a_${rule.packageName}", rule.answerMode.name)
            .putString("lp_${rule.packageName}", rule.learningPreset.name)
            .putString("t_${rule.packageName}", safeTables.sorted().joinToString(","))
            .putInt("dt_${rule.packageName}", rule.dailyTimeTargetMinutes.coerceIn(0, 1440))
            .putInt("do_${rule.packageName}", rule.dailyOpenTarget.coerceIn(0, 500))
            .putInt("st_${rule.packageName}", rule.sessionTargetMinutes.coerceIn(0, 1440))
            .putBoolean("qh_${rule.packageName}", rule.quietHoursEnabled)
            .putInt("qs_${rule.packageName}", rule.quietStartMinutes.coerceIn(0, 1439))
            .putInt("qe_${rule.packageName}", rule.quietEndMinutes.coerceIn(0, 1439))
            .putString("of_${rule.packageName}", rule.overrideFriction.name)
            .putString("op_${rule.packageName}", rule.overridePhrase.trim().take(180).ifBlank { DEFAULT_OVERRIDE_PHRASE })
            .putInt("oh_${rule.packageName}", rule.holdSeconds.coerceIn(5, 30))
            .apply()
    }

    private inline fun <reified T : Enum<T>> parseEnum(raw: String?, fallback: T): T =
        runCatching { enumValueOf<T>(raw ?: fallback.name) }.getOrDefault(fallback)

    private fun parseTables(raw: String): Set<Int> = raw
        .split(',')
        .mapNotNull { it.toIntOrNull() }
        .filter { it in 1..20 }
        .toSet()
        .ifEmpty { (2..12).toSet() }

    companion object {
        private const val KEY_CONFIGURED_PACKAGES = "configured_packages"
        private const val KEY_LEGACY_GATED_PACKAGES = "gated_packages"
        private val DEFAULT_TABLES = (2..12).joinToString(",")
        const val DEFAULT_OVERRIDE_PHRASE = "I am choosing to override the break I set for myself"
    }
}
