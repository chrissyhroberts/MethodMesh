package com.unlocked.app.data

/** Pure usage-time arithmetic kept separate so the clock behaviour can be unit tested. */
object UsageMath {
    fun remaining(storedMillis: Long, activeSinceMillis: Long?, nowMillis: Long): Long {
        val stored = storedMillis.coerceAtLeast(0L)
        val activeSince = activeSinceMillis ?: return stored
        if (nowMillis < activeSince) return stored // monotonic epoch reset/reboot
        return (stored - (nowMillis - activeSince)).coerceAtLeast(0L)
    }
}
