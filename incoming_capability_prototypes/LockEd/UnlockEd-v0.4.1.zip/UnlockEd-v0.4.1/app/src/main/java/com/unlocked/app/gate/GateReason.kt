package com.unlocked.app.gate

enum class GateReason {
    AWARENESS,
    LEARNING,
    BIOMETRIC,
    SELF_BLOCK,
    QUIET_HOURS
}
