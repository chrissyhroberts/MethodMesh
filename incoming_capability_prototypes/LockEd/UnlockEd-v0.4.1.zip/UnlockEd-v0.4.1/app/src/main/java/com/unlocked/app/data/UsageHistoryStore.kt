package com.unlocked.app.data

import android.content.Context
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class UsageHistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("unlocked_usage_history", Context.MODE_PRIVATE)

    fun recordOpen(packageName: String, nowEpochMillis: Long = System.currentTimeMillis()) {
        rollDay(packageName, nowEpochMillis)
        val opens = prefs.getInt("opens_$packageName", 0) + 1
        val hourStart = nowEpochMillis / HOUR_MS
        val storedHour = prefs.getLong("hour_$packageName", -1L)
        val hourOpens = if (storedHour == hourStart) prefs.getInt("hour_opens_$packageName", 0) + 1 else 1
        prefs.edit()
            .putInt("opens_$packageName", opens)
            .putLong("last_open_$packageName", nowEpochMillis)
            .putLong("hour_$packageName", hourStart)
            .putInt("hour_opens_$packageName", hourOpens)
            .apply()
    }

    fun startSession(packageName: String, nowElapsedMillis: Long, nowEpochMillis: Long = System.currentTimeMillis()) {
        rollDay(packageName, nowEpochMillis)
        if (prefs.getLong("active_elapsed_$packageName", -1L) < 0L) {
            prefs.edit()
                .putLong("active_elapsed_$packageName", nowElapsedMillis)
                .putLong("active_epoch_$packageName", nowEpochMillis)
                .apply()
        }
    }

    fun stopSession(packageName: String, nowElapsedMillis: Long, nowEpochMillis: Long = System.currentTimeMillis()) {
        rollDay(packageName, nowEpochMillis)
        val start = prefs.getLong("active_elapsed_$packageName", -1L)
        if (start < 0L) return
        val delta = if (nowElapsedMillis >= start) nowElapsedMillis - start else 0L
        val today = prefs.getLong("today_ms_$packageName", 0L) + delta
        prefs.edit()
            .putLong("today_ms_$packageName", today)
            .putLong("last_session_$packageName", delta)
            .putLong("last_close_$packageName", nowEpochMillis)
            .putLong("active_elapsed_$packageName", -1L)
            .remove("active_epoch_$packageName")
            .apply()
    }

    fun snapshot(packageName: String, nowElapsedMillis: Long = android.os.SystemClock.uptimeMillis(), nowEpochMillis: Long = System.currentTimeMillis()): UsageSnapshot {
        rollDay(packageName, nowEpochMillis)
        val active = prefs.getLong("active_elapsed_$packageName", -1L)
        val activeDelta = if (active >= 0L && nowElapsedMillis >= active) nowElapsedMillis - active else 0L
        val hourStart = nowEpochMillis / HOUR_MS
        return UsageSnapshot(
            todayMillis = prefs.getLong("today_ms_$packageName", 0L) + activeDelta,
            opensToday = prefs.getInt("opens_$packageName", 0),
            lastOpenedEpochMillis = prefs.getLong("last_open_$packageName", 0L),
            lastClosedEpochMillis = prefs.getLong("last_close_$packageName", 0L),
            lastSessionMillis = prefs.getLong("last_session_$packageName", 0L),
            opensThisHour = if (prefs.getLong("hour_$packageName", -1L) == hourStart) prefs.getInt("hour_opens_$packageName", 0) else 0
        )
    }

    private fun rollDay(packageName: String, nowEpochMillis: Long) {
        val day = dayKey(nowEpochMillis)
        if (prefs.getString("day_$packageName", null) == day) return
        prefs.edit()
            .putString("day_$packageName", day)
            .putLong("today_ms_$packageName", 0L)
            .putInt("opens_$packageName", 0)
            .putInt("hour_opens_$packageName", 0)
            .putLong("hour_$packageName", -1L)
            .putLong("active_elapsed_$packageName", -1L)
            .apply()
    }

    private fun dayKey(epochMillis: Long): String =
        Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ISO_DATE)

    companion object { private const val HOUR_MS = 60L * 60L * 1000L }
}
