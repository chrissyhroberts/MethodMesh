package com.unlocked.app.challenge

import com.unlocked.app.data.LearningPreset

class LearningSession(
    private val preset: LearningPreset,
    private val tables: Set<Int>,
    private val requiredCorrect: Int
) {
    private val retry = ArrayDeque<LearningQuestion>()
    var current: LearningQuestion = LearningEngine.next(preset, tables)
        private set
    var completed: Int = 0
        private set

    sealed interface Submission {
        data class Correct(val complete: Boolean) : Submission
        data class Incorrect(val question: LearningQuestion) : Submission
    }

    fun submit(answer: Int?): Submission {
        if (answer == current.answer) {
            completed++
            val complete = completed >= requiredCorrect && retry.isEmpty()
            if (!complete) current = retry.removeFirstOrNull() ?: LearningEngine.next(preset, tables)
            return Submission.Correct(complete)
        }
        retry.add(current)
        val wrong = current
        current = LearningEngine.next(preset, tables)
        return Submission.Incorrect(wrong)
    }
}
