package com.unlocked.app.challenge

import kotlin.random.Random

object MultipleChoice {
    /**
     * Returns four distinct positive answers including the correct answer.
     * Distractors are deliberately close enough to require recall rather than visual elimination.
     */
    fun answersFor(question: TimesTableQuestion): List<Int> {
        val correct = question.answer
        val random = Random(question.left * 10_007 + question.right * 1_009)
        val candidates = linkedSetOf<Int>()

        candidates += correct

        val factor = maxOf(question.left, question.right)
        val offsets = listOf(-2, -1, 1, 2, -3, 3).shuffled(random)
        for (offset in offsets) {
            val candidate = correct + (factor * offset)
            if (candidate > 0) candidates += candidate
            if (candidates.size >= 4) break
        }

        var radius = 1
        while (candidates.size < 4) {
            val signed = if (radius % 2 == 0) radius else -radius
            val candidate = correct + signed
            if (candidate > 0) candidates += candidate
            radius += 1
        }

        return candidates.toList().shuffled(random)
    }
}
