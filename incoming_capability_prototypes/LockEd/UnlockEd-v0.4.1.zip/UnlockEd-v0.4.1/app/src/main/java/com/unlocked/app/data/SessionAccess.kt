package com.unlocked.app.data

enum class SessionAccessKind { AWARENESS, BIOMETRIC, OVERRIDE }

/** In-process session grants. They intentionally disappear if Android kills UnlockEd. */
object SessionAccess {
    private val reopen = mutableSetOf<String>()
    private val biometric = mutableSetOf<String>()
    private val overrides = mutableSetOf<String>()
    private val awareness = mutableSetOf<String>()

    @Synchronized fun grant(packageName: String, kind: SessionAccessKind) {
        reopen += packageName
        when (kind) {
            SessionAccessKind.AWARENESS -> awareness += packageName
            SessionAccessKind.BIOMETRIC -> biometric += packageName
            SessionAccessKind.OVERRIDE -> overrides += packageName
        }
    }

    @Synchronized fun consumeReopen(packageName: String): Boolean = reopen.remove(packageName)
    @Synchronized fun biometricUnlocked(packageName: String) = packageName in biometric
    @Synchronized fun overrideUnlocked(packageName: String) = packageName in overrides
    @Synchronized fun awarenessShown(packageName: String) = packageName in awareness

    @Synchronized fun clearSession(packageName: String) {
        reopen.remove(packageName)
        biometric.remove(packageName)
        overrides.remove(packageName)
        awareness.remove(packageName)
    }
}
