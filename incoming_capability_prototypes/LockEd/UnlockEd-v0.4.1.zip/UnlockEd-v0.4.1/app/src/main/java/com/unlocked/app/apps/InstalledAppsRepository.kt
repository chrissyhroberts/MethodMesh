package com.unlocked.app.apps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager

data class LaunchableApp(
    val label: String,
    val packageName: String
)

class InstalledAppsRepository(private val context: Context) {
    private val pm = context.packageManager

    fun launchableApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

        val excluded = essentialPackages()
        return infos
            .mapNotNull { info ->
                val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
                LaunchableApp(info.loadLabel(pm).toString(), packageName)
            }
            .filterNot { it.packageName in excluded }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    /**
     * Returns true for packages that are plausible top-level user destinations. This deliberately
     * filters out IMEs, permission dialogs and System UI transient windows, whose accessibility
     * events must not be mistaken for the user leaving a gated app.
     */
    fun isUserForegroundCandidate(packageName: String): Boolean {
        if (packageName == context.packageName || packageName in essentialPackages()) return true
        return pm.getLaunchIntentForPackage(packageName) != null
    }

    fun inputMethodPackages(): Set<String> =
        context.getSystemService(InputMethodManager::class.java)
            ?.inputMethodList
            ?.mapNotNull { it.packageName }
            ?.toSet()
            .orEmpty()

    /**
     * Hard safety exclusions. UnlockEd is a social/leisure gate, not a device lock.
     * These packages are ignored by enforcement even if stale/corrupt preferences contain them.
     */
    fun essentialPackages(): Set<String> {
        val result = mutableSetOf(context.packageName, "com.android.settings")

        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let(result::add)

        context.getSystemService(TelecomManager::class.java)
            ?.defaultDialerPackage
            ?.let(result::add)

        Telephony.Sms.getDefaultSmsPackage(context)?.let(result::add)

        return result
    }
}
