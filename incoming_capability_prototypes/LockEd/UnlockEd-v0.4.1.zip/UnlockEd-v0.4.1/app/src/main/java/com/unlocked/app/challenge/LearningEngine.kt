package com.unlocked.app.challenge

import com.unlocked.app.data.LearningPreset
import kotlin.math.abs
import kotlin.random.Random

data class LearningQuestion(val prompt: String, val answer: Int)

object LearningEngine {
    fun next(preset: LearningPreset, tables: Set<Int>, random: Random = Random.Default): LearningQuestion = when (preset) {
        LearningPreset.CUSTOM_TIMES_TABLES -> {
            val safe = tables.filter { it in 1..20 }.ifEmpty { (2..12).toList() }
            val a = safe.random(random)
            val b = random.nextInt(2, 13)
            LearningQuestion("$a × $b", a * b)
        }
        LearningPreset.YEAR_1_2 -> if (random.nextBoolean()) {
            val a = random.nextInt(1, 20); val b = random.nextInt(1, 20 - a + 1)
            LearningQuestion("$a + $b", a + b)
        } else {
            val a = random.nextInt(5, 31); val b = random.nextInt(0, a + 1)
            LearningQuestion("$a − $b", a - b)
        }
        LearningPreset.YEAR_3_4 -> when (random.nextInt(3)) {
            0 -> { val a = random.nextInt(20, 200); val b = random.nextInt(10, 100); LearningQuestion("$a + $b", a + b) }
            1 -> { val a = random.nextInt(2, 13); val b = random.nextInt(2, 13); LearningQuestion("$a × $b", a * b) }
            else -> { val divisor = random.nextInt(2, 13); val q = random.nextInt(2, 13); LearningQuestion("${divisor * q} ÷ $divisor", q) }
        }
        LearningPreset.YEAR_5_6 -> when (random.nextInt(4)) {
            0 -> { val a = random.nextInt(100, 1000); val b = random.nextInt(20, 500); LearningQuestion("$a + $b", a + b) }
            1 -> { val a = random.nextInt(100, 1000); val b = random.nextInt(20, a); LearningQuestion("$a − $b", a - b) }
            2 -> { val a = random.nextInt(12, 50); val b = random.nextInt(2, 13); LearningQuestion("$a × $b", a * b) }
            else -> { val percent = listOf(10, 20, 25, 50).random(random); val base = listOf(20, 40, 60, 80, 100, 120, 200).random(random); LearningQuestion("$percent% of $base", percent * base / 100) }
        }
        LearningPreset.YEAR_7_9 -> when (random.nextInt(4)) {
            0 -> { val a = random.nextInt(-20, 21); val b = random.nextInt(-20, 21); LearningQuestion("$a + (${b})", a + b) }
            1 -> { val base = random.nextInt(2, 13); val power = random.nextInt(2, 4); LearningQuestion("$base^$power", if (power == 2) base * base else base * base * base) }
            2 -> { val x = random.nextInt(-12, 13); val a = random.nextInt(2, 8); val b = random.nextInt(-10, 11); LearningQuestion("Solve: ${a}x ${signed(b)} = ${a * x + b}", x) }
            else -> { val a = random.nextInt(2, 20); val b = random.nextInt(2, 20); LearningQuestion("$a × $b", a * b) }
        }
        LearningPreset.GCSE_FOUNDATION -> when (random.nextInt(4)) {
            0 -> { val x = random.nextInt(-20, 21); val a = random.nextInt(2, 10); val b = random.nextInt(-15, 16); LearningQuestion("Solve: ${a}x ${signed(b)} = ${a * x + b}", x) }
            1 -> { val p = listOf(5, 10, 20, 25, 40, 50, 75).random(random); val n = listOf(40, 60, 80, 100, 120, 160, 200).random(random); LearningQuestion("$p% of $n", p * n / 100) }
            2 -> { val a = random.nextInt(-15, 16); val b = random.nextInt(-15, 16); LearningQuestion("${a} − (${b})", a - b) }
            else -> { val side = random.nextInt(2, 20); LearningQuestion("Area of a square with side $side", side * side) }
        }
        LearningPreset.GCSE_HIGHER -> when (random.nextInt(4)) {
            0 -> { val x = random.nextInt(-12, 13); val a = random.nextInt(2, 9); val b = random.nextInt(-15, 16); LearningQuestion("Solve: ${a}x ${signed(b)} = ${a * x + b}", x) }
            1 -> { val a = random.nextInt(2, 8); val b = random.nextInt(2, 8); LearningQuestion("${a}² + ${b}²", a * a + b * b) }
            2 -> { val n = random.nextInt(2, 13); LearningQuestion("${n}³", n * n * n) }
            else -> { val x = random.nextInt(2, 15); val factor = random.nextInt(2, 8); LearningQuestion("If y = ${factor}x² and x = $x, find y", factor * x * x) }
        }
    }

    fun distractors(question: LearningQuestion, random: Random = Random(question.prompt.hashCode())): List<Int> {
        val correct = question.answer
        val candidates = linkedSetOf(correct)
        val offsets = listOf(-10, 10, -5, 5, -2, 2, -1, 1, -20, 20).shuffled(random)
        for (offset in offsets) {
            if (candidates.size == 4) break
            candidates += correct + offset
        }
        while (candidates.size < 4) candidates += correct + random.nextInt(-25, 26)
        return candidates.shuffled(random)
    }

    private fun signed(value: Int): String = if (value >= 0) "+ $value" else "− ${abs(value)}"
}
