package com.unlocked.app.data

import android.content.Context

/**
 * Stores earned access as remaining foreground-use milliseconds, not a wall-clock expiry.
 *
 * The active timestamp uses a monotonic clock. If Android reboots (and the monotonic clock
 * consequently resets), an old active timestamp is discarded without charging time. This is
 * deliberately conservative: a reboot may preserve a little earned time, but can never create
 * a huge allowance because the wall clock changed or the monotonic epoch reset.
 */
class UsageLedger(
    context: Context,
    private val clock: MonotonicClock = AndroidMonotonicClock
) {
    private val prefs = context.getSharedPreferences("unlocked_usage", Context.MODE_PRIVATE)

    fun remainingMillis(packageName: String, now: Long = clock.nowMillis()): Long {
        val stored = prefs.getLong(remainingKey(packageName), 0L).coerceAtLeast(0L)
        val activeSince = prefs.getLong(activeKey(packageName), INACTIVE)
        return UsageMath.remaining(stored, activeSince.takeUnless { it == INACTIVE }, now)
    }

    fun grantMinutes(packageName: String, minutes: Int) {
        val safeMinutes = minutes.coerceIn(1, 240)
        prefs.edit()
            .putLong(remainingKey(packageName), safeMinutes * 60_000L)
            .putLong(activeKey(packageName), INACTIVE)
            .apply()
    }

    fun startUsing(packageName: String, now: Long = clock.nowMillis()) {
        settle(packageName, now)
        if (prefs.getLong(remainingKey(packageName), 0L) > 0L) {
            prefs.edit().putLong(activeKey(packageName), now).apply()
        }
    }

    fun stopUsing(packageName: String, now: Long = clock.nowMillis()) {
        settle(packageName, now)
    }

    fun clear(packageName: String) {
        prefs.edit()
            .remove(remainingKey(packageName))
            .remove(activeKey(packageName))
            .apply()
    }

    private fun settle(packageName: String, now: Long) {
        val stored = prefs.getLong(remainingKey(packageName), 0L).coerceAtLeast(0L)
        val activeSince = prefs.getLong(activeKey(packageName), INACTIVE)
        if (activeSince == INACTIVE) return

        val next = UsageMath.remaining(stored, activeSince, now)
        prefs.edit()
            .putLong(remainingKey(packageName), next)
            .putLong(activeKey(packageName), INACTIVE)
            .apply()
    }

    private fun remainingKey(packageName: String) = "remaining_$packageName"
    private fun activeKey(packageName: String) = "active_$packageName"

    companion object {
        private const val INACTIVE = -1L
    }
}
