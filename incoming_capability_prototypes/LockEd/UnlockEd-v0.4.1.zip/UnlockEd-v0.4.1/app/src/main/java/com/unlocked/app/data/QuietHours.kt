package com.unlocked.app.data

import java.time.Instant
import java.time.ZoneId

object QuietHours {
    fun isActive(rule: AppRule, epochMillis: Long = System.currentTimeMillis(), zoneId: ZoneId = ZoneId.systemDefault()): Boolean {
        if (!rule.quietHoursEnabled) return false
        val time = Instant.ofEpochMilli(epochMillis).atZone(zoneId).toLocalTime()
        val nowMinutes = time.hour * 60 + time.minute
        val start = rule.quietStartMinutes.coerceIn(0, 1439)
        val end = rule.quietEndMinutes.coerceIn(0, 1439)
        if (start == end) return true
        return if (start < end) nowMinutes in start until end else nowMinutes >= start || nowMinutes < end
    }

    fun endEpochMillis(rule: AppRule, epochMillis: Long = System.currentTimeMillis(), zoneId: ZoneId = ZoneId.systemDefault()): Long {
        val now = Instant.ofEpochMilli(epochMillis).atZone(zoneId)
        val endMinutes = rule.quietEndMinutes.coerceIn(0, 1439)
        var end = now.toLocalDate().atTime(endMinutes / 60, endMinutes % 60).atZone(zoneId)
        if (!end.isAfter(now)) end = end.plusDays(1)
        return end.toInstant().toEpochMilli()
    }
}
