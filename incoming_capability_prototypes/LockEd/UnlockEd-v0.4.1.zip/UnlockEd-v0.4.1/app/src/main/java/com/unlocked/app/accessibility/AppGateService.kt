package com.unlocked.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import com.unlocked.app.apps.InstalledAppsRepository
import com.unlocked.app.data.AndroidMonotonicClock
import com.unlocked.app.data.GateType
import com.unlocked.app.data.QuietHours
import com.unlocked.app.data.RuleStore
import com.unlocked.app.data.SelfControlStore
import com.unlocked.app.data.SessionAccess
import com.unlocked.app.data.UsageHistoryStore
import com.unlocked.app.data.UsageLedger
import com.unlocked.app.gate.GateActivity
import com.unlocked.app.gate.GateReason

class AppGateService : AccessibilityService() {
    private lateinit var rules: RuleStore
    private lateinit var usage: UsageLedger
    private lateinit var history: UsageHistoryStore
    private lateinit var selfControl: SelfControlStore
    private lateinit var apps: InstalledAppsRepository

    private val handler = Handler(Looper.getMainLooper())
    private var lastForegroundPackage: String? = null
    private var expiryRunnable: Runnable? = null
    private var gateLaunchPendingFor: String? = null
    private var suppressNextOpenFor: String? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                settleCurrentUsage()
                lastForegroundPackage?.let(SessionAccess::clearSession)
                cancelExpiryCheck()
                lastForegroundPackage = null
                gateLaunchPendingFor = null
                suppressNextOpenFor = null
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        rules = RuleStore(this)
        usage = UsageLedger(this)
        history = UsageHistoryStore(this)
        selfControl = SelfControlStore(this)
        apps = InstalledAppsRepository(this)
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION") registerReceiver(screenReceiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::rules.isInitialized || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString()?.takeIf { it.isNotBlank() } ?: return
        if (packageName in apps.inputMethodPackages()) return
        handleForegroundPackage(packageName)
    }

    private fun handleForegroundPackage(packageName: String) {
        val elapsed = AndroidMonotonicClock.nowMillis()
        val epoch = System.currentTimeMillis()
        val previous = lastForegroundPackage

        if (previous != null && previous != packageName) {
            rules.ruleFor(previous)?.let {
                usage.stopUsing(previous, elapsed)
                history.stopSession(previous, elapsed, epoch)
            }
            if (previous != this.packageName) SessionAccess.clearSession(previous)
        }

        if (previous != packageName) {
            cancelExpiryCheck()
            lastForegroundPackage = packageName
        }

        if (packageName == this.packageName) {
            gateLaunchPendingFor = null
            return
        }
        if (packageName in apps.essentialPackages() || !apps.isUserForegroundCandidate(packageName)) {
            gateLaunchPendingFor = null
            return
        }

        val rule = rules.ruleFor(packageName) ?: run {
            gateLaunchPendingFor = null
            return
        }

        if (previous != packageName) {
            val suppressed = suppressNextOpenFor == packageName || SessionAccess.consumeReopen(packageName)
            if (suppressed) suppressNextOpenFor = null else history.recordOpen(packageName, epoch)
        }

        history.startSession(packageName, elapsed, epoch)

        val blockUntil = selfControl.activeBlockUntil(packageName, epoch)
        if (blockUntil != null && !SessionAccess.overrideUnlocked(packageName)) {
            showGate(packageName, GateReason.SELF_BLOCK, blockUntil)
            return
        }

        if (QuietHours.isActive(rule, epoch) && !SessionAccess.overrideUnlocked(packageName)) {
            showGate(packageName, GateReason.QUIET_HOURS, QuietHours.endEpochMillis(rule, epoch))
            return
        }

        when (rule.gateType) {
            GateType.BIOMETRIC -> if (!SessionAccess.biometricUnlocked(packageName)) {
                showGate(packageName, GateReason.BIOMETRIC)
                return
            }
            GateType.LEARNING -> {
                val remaining = usage.remainingMillis(packageName, elapsed)
                if (remaining <= 0L) {
                    usage.clear(packageName)
                    showGate(packageName, GateReason.LEARNING)
                    return
                }
                usage.startUsing(packageName, elapsed)
                scheduleExpiry(packageName, remaining)
            }
            GateType.NONE -> Unit
        }

        if (rule.awarenessEnabled && !SessionAccess.awarenessShown(packageName)) {
            showGate(packageName, GateReason.AWARENESS)
            return
        }

        gateLaunchPendingFor = null
    }

    private fun scheduleExpiry(packageName: String, remainingMillis: Long) {
        cancelExpiryCheck()
        expiryRunnable = Runnable {
            if (lastForegroundPackage == packageName && rules.ruleFor(packageName)?.gateType == GateType.LEARNING) {
                usage.stopUsing(packageName)
                history.stopSession(packageName, AndroidMonotonicClock.nowMillis())
                usage.clear(packageName)
                SessionAccess.clearSession(packageName)
                showGate(packageName, GateReason.LEARNING)
            }
        }.also { handler.postDelayed(it, remainingMillis.coerceAtLeast(250L)) }
    }

    private fun cancelExpiryCheck() {
        expiryRunnable?.let(handler::removeCallbacks)
        expiryRunnable = null
    }

    private fun settleCurrentUsage() {
        val packageName = lastForegroundPackage ?: return
        if (::rules.isInitialized && rules.ruleFor(packageName) != null) {
            val now = AndroidMonotonicClock.nowMillis()
            usage.stopUsing(packageName, now)
            if (::history.isInitialized) history.stopSession(packageName, now)
        }
    }

    private fun showGate(packageName: String, reason: GateReason, blockUntil: Long = 0L) {
        if (gateLaunchPendingFor == packageName) return
        gateLaunchPendingFor = packageName
        suppressNextOpenFor = packageName

        val intent = Intent(this, GateActivity::class.java).apply {
            putExtra(GateActivity.EXTRA_TARGET_PACKAGE, packageName)
            putExtra(GateActivity.EXTRA_REASON, reason.name)
            putExtra(GateActivity.EXTRA_BLOCK_UNTIL, blockUntil)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        runCatching { startActivity(intent) }.onFailure {
            gateLaunchPendingFor = null
            suppressNextOpenFor = null
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        cancelExpiryCheck()
        settleCurrentUsage()
        runCatching { unregisterReceiver(screenReceiver) }
        super.onDestroy()
    }
}
