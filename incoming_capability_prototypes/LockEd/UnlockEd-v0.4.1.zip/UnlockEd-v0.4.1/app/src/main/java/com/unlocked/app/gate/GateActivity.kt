package com.unlocked.app.gate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.unlocked.app.challenge.LearningEngine
import com.unlocked.app.challenge.LearningQuestion
import com.unlocked.app.challenge.LearningSession
import com.unlocked.app.data.AnswerMode
import com.unlocked.app.data.AppRule
import com.unlocked.app.data.AwarenessMessages
import com.unlocked.app.data.OverrideFriction
import com.unlocked.app.data.QuietHours
import com.unlocked.app.data.RuleStore
import com.unlocked.app.data.SelfControlStore
import com.unlocked.app.data.SessionAccess
import com.unlocked.app.data.SessionAccessKind
import com.unlocked.app.data.UsageHistoryStore
import com.unlocked.app.data.UsageLedger
import com.unlocked.app.speech.SpeechPhraseMatcher
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date
import java.util.Locale

class GateActivity : ComponentActivity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechCallback: ((List<String>) -> Unit)? = null
    private var speechFailure: ((String) -> Unit)? = null
    private var pendingSpeechStart: (() -> Unit)? = null

    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingSpeechStart?.invoke() else speechFailure?.invoke("Microphone permission was not granted.")
        pendingSpeechStart = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderFromIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        renderFromIntent(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }

    private fun renderFromIntent(sourceIntent: Intent) {
        val targetPackage = sourceIntent.getStringExtra(EXTRA_TARGET_PACKAGE)
        if (targetPackage.isNullOrBlank() || targetPackage == packageName) {
            finish(); return
        }
        val rule = RuleStore(this).ruleFor(targetPackage) ?: run { finish(); return }
        val reason = runCatching {
            GateReason.valueOf(sourceIntent.getStringExtra(EXTRA_REASON) ?: GateReason.AWARENESS.name)
        }.getOrDefault(GateReason.AWARENESS)
        val label = appLabel(targetPackage)
        val snapshot = UsageHistoryStore(this).snapshot(targetPackage)
        val blockUntil = sourceIntent.getLongExtra(EXTRA_BLOCK_UNTIL, 0L)

        setContent {
            MaterialTheme {
                GateScreen(
                    activity = this,
                    appLabel = label,
                    packageName = targetPackage,
                    rule = rule,
                    reason = reason,
                    blockUntilEpochMillis = blockUntil,
                    awarenessMessage = if (rule.awarenessEnabled) AwarenessMessages.choose(label, snapshot, rule) else null,
                    onLearningComplete = {
                        RuleStore(this).ruleFor(targetPackage)?.let {
                            UsageLedger(this).grantMinutes(targetPackage, it.earnedUsageMinutes)
                        }
                        SessionAccess.grant(targetPackage, SessionAccessKind.AWARENESS)
                        reopenTarget(targetPackage)
                    },
                    onAwarenessContinue = {
                        SessionAccess.grant(targetPackage, SessionAccessKind.AWARENESS)
                        reopenTarget(targetPackage)
                    },
                    onBiometricSuccess = {
                        SessionAccess.grant(targetPackage, SessionAccessKind.BIOMETRIC)
                        if (rule.awarenessEnabled) SessionAccess.grant(targetPackage, SessionAccessKind.AWARENESS)
                        reopenTarget(targetPackage)
                    },
                    onOverrideSuccess = {
                        SessionAccess.grant(targetPackage, SessionAccessKind.OVERRIDE)
                        if (rule.awarenessEnabled) SessionAccess.grant(targetPackage, SessionAccessKind.AWARENESS)
                        reopenTarget(targetPackage)
                    },
                    onTakeBreak = { millis ->
                        SelfControlStore(this).setBlockFor(targetPackage, millis)
                        goHome()
                    },
                    onLeave = ::goHome
                )
            }
        }
    }

    fun authenticateBiometric(title: String, onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            onFailure("Biometric unlock is unavailable on this Android version.")
            return
        }
        val cancellationSignal = CancellationSignal()
        val prompt = BiometricPrompt.Builder(this)
            .setTitle(title)
            .setSubtitle("Unlock this app for the current session")
            .setNegativeButton("Not now", mainExecutor) { _, _ -> onFailure("Biometric check cancelled.") }
            .build()
        prompt.authenticate(cancellationSignal, mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) = onSuccess()
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) = onFailure(errString?.toString() ?: "Biometric check failed.")
            override fun onAuthenticationFailed() = onFailure("Not recognised. Try again.")
        })
    }

    fun startOnDeviceSpeech(onResult: (List<String>) -> Unit, onFailure: (String) -> Unit) {
        speechCallback = onResult
        speechFailure = onFailure
        val start = {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                onFailure("On-device speech recognition is unavailable. Use the hold fallback below.")
            } else {
                speechRecognizer?.destroy()
                val recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
                speechRecognizer = recognizer
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) = Unit
                    override fun onBeginningOfSpeech() = Unit
                    override fun onRmsChanged(rmsdB: Float) = Unit
                    override fun onBufferReceived(buffer: ByteArray?) = Unit
                    override fun onEndOfSpeech() = Unit
                    override fun onError(error: Int) = onFailure("I didn’t catch that. Try again, or use the hold fallback.")
                    override fun onResults(results: Bundle?) {
                        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                        onResult(heard)
                    }
                    override fun onPartialResults(partialResults: Bundle?) = Unit
                    override fun onEvent(eventType: Int, params: Bundle?) = Unit
                })
                recognizer.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                })
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            start()
        } else {
            pendingSpeechStart = start
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun appLabel(packageName: String): String = runCatching {
        val info = packageManager.getApplicationInfo(packageName, 0)
        packageManager.getApplicationLabel(info).toString()
    }.getOrDefault("this app")

    private fun reopenTarget(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(launch)
        } else goHome()
        finish()
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        finish()
    }

    companion object {
        const val EXTRA_TARGET_PACKAGE = "target_package"
        const val EXTRA_REASON = "gate_reason"
        const val EXTRA_BLOCK_UNTIL = "block_until"
    }
}

@Composable
private fun GateScreen(
    activity: GateActivity,
    appLabel: String,
    packageName: String,
    rule: AppRule,
    reason: GateReason,
    blockUntilEpochMillis: Long,
    awarenessMessage: String?,
    onLearningComplete: () -> Unit,
    onAwarenessContinue: () -> Unit,
    onBiometricSuccess: () -> Unit,
    onOverrideSuccess: () -> Unit,
    onTakeBreak: (Long) -> Unit,
    onLeave: () -> Unit
) {
    BackHandler(onBack = onLeave)
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 36.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(appLabel, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            awarenessMessage?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(24.dp))

            when (reason) {
                GateReason.LEARNING -> LearningGate(rule, onLearningComplete)
                GateReason.BIOMETRIC -> BiometricGate(activity, appLabel, onBiometricSuccess)
                GateReason.SELF_BLOCK, GateReason.QUIET_HOURS -> SelfControlGate(
                    activity = activity,
                    rule = rule,
                    reason = reason,
                    blockUntilEpochMillis = blockUntilEpochMillis,
                    onOverrideSuccess = onOverrideSuccess
                )
                GateReason.AWARENESS -> AwarenessGate(onAwarenessContinue, onTakeBreak)
            }
            Spacer(Modifier.height(20.dp))
            Button(onClick = onLeave) { Text("Not now") }
        }
    }
}

@Composable
private fun AwarenessGate(onContinue: () -> Unit, onTakeBreak: (Long) -> Unit) {
    Text("A moment of intention", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(18.dp))
    Button(modifier = Modifier.fillMaxWidth(), onClick = onContinue) { Text("Continue") }
    Spacer(Modifier.height(12.dp))
    Text("Take a break", fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onTakeBreak(15 * 60_000L) }) { Text("15 min") }
        Button(onClick = { onTakeBreak(30 * 60_000L) }) { Text("30 min") }
        Button(onClick = { onTakeBreak(60 * 60_000L) }) { Text("1 hour") }
    }
    Spacer(Modifier.height(8.dp))
    Button(modifier = Modifier.fillMaxWidth(), onClick = { onTakeBreak(durationUntilMorning()) }) { Text("Done until morning") }
}

@Composable
private fun BiometricGate(activity: GateActivity, appLabel: String, onSuccess: () -> Unit) {
    var status by remember { mutableStateOf("Use your biometric to continue.") }
    Text("Private app", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(12.dp))
    Text(status, textAlign = TextAlign.Center)
    Spacer(Modifier.height(18.dp))
    Button(modifier = Modifier.fillMaxWidth(), onClick = {
        activity.authenticateBiometric("Unlock $appLabel", onSuccess) { status = it }
    }) { Text("Unlock with biometric") }
}

@Composable
private fun LearningGate(rule: AppRule, onComplete: () -> Unit) {
    val session = remember(rule.learningPreset, rule.tables, rule.questionsPerGate) {
        LearningSession(rule.learningPreset, rule.tables, rule.questionsPerGate.coerceIn(1, 20))
    }
    var question by remember { mutableStateOf(session.current) }
    var answer by remember { mutableStateOf("") }
    var completed by remember { mutableIntStateOf(session.completed) }
    var penaltyRemaining by remember { mutableIntStateOf(0) }
    var correction by remember { mutableStateOf<LearningQuestion?>(null) }
    var completionSent by remember { mutableStateOf(false) }
    val choices = remember(question) { LearningEngine.distractors(question) }

    LaunchedEffect(penaltyRemaining) {
        if (penaltyRemaining > 0) {
            delay(1_000)
            penaltyRemaining -= 1
            if (penaltyRemaining == 0) {
                correction = null
                answer = ""
                question = session.current
            }
        }
    }

    fun submit(candidate: Int? = answer.toIntOrNull()) {
        if (penaltyRemaining > 0 || completionSent) return
        when (val result = session.submit(candidate)) {
            is LearningSession.Submission.Correct -> {
                completed = session.completed
                answer = ""
                correction = null
                if (result.complete) {
                    completionSent = true
                    onComplete()
                } else question = session.current
            }
            is LearningSession.Submission.Incorrect -> {
                correction = result.question
                penaltyRemaining = rule.wrongAnswerDelaySeconds.coerceIn(1, 60)
                answer = ""
            }
        }
    }

    Text("A little revision first", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(20.dp))
    if (penaltyRemaining > 0) {
        Text("Not quite", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("${correction?.prompt} = ${correction?.answer}", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        Text("Try again in $penaltyRemaining…")
    } else {
        Text(question.prompt, fontSize = 38.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        if (rule.answerMode == AnswerMode.MULTIPLE_CHOICE) {
            choices.forEach { option ->
                Button(onClick = { submit(option) }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(option.toString(), fontSize = 20.sp) }
            }
        } else {
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = it.filter { ch -> ch.isDigit() || ch == '-' }.take(8) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Answer") },
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Spacer(Modifier.height(12.dp))
            Button(modifier = Modifier.fillMaxWidth(), onClick = { submit() }, enabled = answer.isNotBlank()) { Text("Check") }
        }
    }
    Spacer(Modifier.height(18.dp))
    Text("${completed.coerceAtMost(rule.questionsPerGate)} of ${rule.questionsPerGate} complete")
}


private fun durationUntilMorning(now: Long = System.currentTimeMillis()): Long {
    val zone = java.time.ZoneId.systemDefault()
    val current = java.time.Instant.ofEpochMilli(now).atZone(zone)
    var target = current.toLocalDate().atTime(7, 0).atZone(zone)
    if (!target.isAfter(current)) target = target.plusDays(1)
    return (target.toInstant().toEpochMilli() - now).coerceAtLeast(60_000L)
}

@Composable
private fun SelfControlGate(
    activity: GateActivity,
    rule: AppRule,
    reason: GateReason,
    blockUntilEpochMillis: Long,
    onOverrideSuccess: () -> Unit
) {
    var speechStatus by remember { mutableStateOf<String?>(null) }
    var speechPassed by remember { mutableStateOf(false) }
    var holdProgress by remember { mutableIntStateOf(0) }
    var holding by remember { mutableStateOf(false) }
    val configuredNeedsSpeech = rule.overrideFriction == OverrideFriction.SPEAK || rule.overrideFriction == OverrideFriction.HOLD_AND_SPEAK
    val configuredNeedsHold = rule.overrideFriction == OverrideFriction.HOLD || rule.overrideFriction == OverrideFriction.HOLD_AND_SPEAK
    val fallbackOnly = rule.overrideFriction == OverrideFriction.SPEAK
    val holdSeconds = if (fallbackOnly) 30 else rule.holdSeconds

    LaunchedEffect(holding, speechPassed, holdSeconds) {
        if (!holding) {
            holdProgress = 0
            return@LaunchedEffect
        }
        while (holding && holdProgress < holdSeconds) {
            delay(1_000)
            holdProgress++
        }
        if (!holding || holdProgress < holdSeconds) return@LaunchedEffect
        val canPass = when (rule.overrideFriction) {
            OverrideFriction.HOLD -> true
            OverrideFriction.SPEAK -> true // 30-second accessibility/reliability fallback deliberately bypasses speech.
            OverrideFriction.HOLD_AND_SPEAK -> speechPassed
        }
        if (canPass) onOverrideSuccess()
    }

    Text(if (reason == GateReason.QUIET_HOURS) "Quiet time" else "You asked for a break", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(10.dp))
    if (blockUntilEpochMillis > 0L) {
        Text("Until ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(blockUntilEpochMillis))}", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
    }
    Text("UnlockEd will keep this app closed unless you deliberately override your decision.", textAlign = TextAlign.Center)

    if (configuredNeedsSpeech) {
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Say your phrase", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("“${rule.overridePhrase}”")
                Spacer(Modifier.height(12.dp))
                Button(modifier = Modifier.fillMaxWidth(), onClick = {
                    speechStatus = "Listening…"
                    activity.startOnDeviceSpeech(
                        onResult = { candidates ->
                            val heard = candidates.firstOrNull().orEmpty()
                            if (SpeechPhraseMatcher.matches(rule.overridePhrase, candidates)) {
                                speechPassed = true
                                speechStatus = "Close enough — phrase accepted."
                                if (rule.overrideFriction == OverrideFriction.SPEAK) onOverrideSuccess()
                            } else {
                                speechStatus = if (heard.isBlank()) {
                                    "I didn’t catch that. Try again, or use the hold fallback."
                                } else {
                                    "I heard: “$heard”. Close, but try once more — or use the hold fallback."
                                }
                            }
                        },
                        onFailure = { speechStatus = it }
                    )
                }) { Text(if (speechPassed) "Phrase accepted" else "Speak phrase") }
                speechStatus?.let { Spacer(Modifier.height(8.dp)); Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    Spacer(Modifier.height(16.dp))
    val holdEnabled = configuredNeedsHold || fallbackOnly
    if (holdEnabled) {
        Text(
            when (rule.overrideFriction) {
                OverrideFriction.HOLD -> "Hold to override"
                OverrideFriction.HOLD_AND_SPEAK -> if (speechPassed) "Phrase accepted. Hold to confirm" else "Say the phrase, then hold to confirm"
                OverrideFriction.SPEAK -> "Speech not working? Hold for 30 seconds instead"
            },
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(8.dp))
        Surface(
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth().height(64.dp).pointerInput(holdSeconds, speechPassed) {
                detectTapGestures(onPress = {
                    holding = true
                    tryAwaitRelease()
                    holding = false
                })
            }
        ) {
            Column(verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (holding) "Keep holding… $holdProgress / ${holdSeconds}s" else "Press and hold")
            }
        }
    }
}
