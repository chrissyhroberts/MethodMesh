package com.unlocked.app.data

import android.content.Context

class SelfControlStore(context: Context) {
    private val prefs = context.getSharedPreferences("unlocked_self_control", Context.MODE_PRIVATE)

    fun blockUntil(packageName: String): Long = prefs.getLong("b_$packageName", 0L)

    fun setBlockFor(packageName: String, durationMillis: Long, nowEpochMillis: Long = System.currentTimeMillis()) {
        val safe = durationMillis.coerceIn(60_000L, 7L * 24L * 60L * 60L * 1000L)
        prefs.edit().putLong("b_$packageName", nowEpochMillis + safe).apply()
    }

    fun setBlockUntil(packageName: String, epochMillis: Long) {
        prefs.edit().putLong("b_$packageName", epochMillis.coerceAtLeast(0L)).apply()
    }

    fun clearBlock(packageName: String) {
        prefs.edit().remove("b_$packageName").apply()
    }

    fun activeBlockUntil(packageName: String, nowEpochMillis: Long = System.currentTimeMillis()): Long? {
        val until = blockUntil(packageName)
        if (until <= nowEpochMillis) {
            if (until != 0L) clearBlock(packageName)
            return null
        }
        return until
    }
}
