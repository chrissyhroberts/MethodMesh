# Gradle sync fix

This revision fixes the `NoClassDefFoundError: org/gradle/features/binding/ProjectTypeBinding`
reported by the previous archive.

## Root cause

The v0.2.0 archive accidentally omitted `gradle/wrapper/gradle-wrapper.properties` (and therefore
left the Gradle runtime implicit). Android Studio could then sync AGP 9.4.0 using a locally selected
Gradle version that did not contain the API AGP expected.

## Pinned build matrix

- Android Gradle Plugin: **9.4.0**
- Gradle: **9.6.0**
- Gradle JDK: **17**
- Compose compiler plugin / Kotlin: **2.3.21**
- compileSdk / targetSdk: **37**

The Gradle distribution is pinned in `gradle/wrapper/gradle-wrapper.properties`, including its
SHA-256 checksum.

## Android Studio

Open the project root and ensure:

1. Gradle distribution is set to **Wrapper** / `gradle-wrapper.properties`.
2. Gradle JDK is **JDK 17** (Android Studio's bundled JBR 17 is fine when available).
3. Do not accept the IDE's "New Minor Gradle Version Available" suggestion for this build. It is
   informational, not an error. Upgrade only as an intentional AGP/Gradle matrix change.

If Android Studio cached the failed model, use **File > Sync Project with Gradle Files** after opening
this revision. If it still displays the old `ProjectTypeBinding` stack trace, close the project,
remove the project's local `.gradle` directory (if one exists), reopen, and sync using the wrapper.

### Wrapper launcher note

This generated source archive includes the standard `gradle-wrapper.properties` pin. Because the
build environment that produced the archive could not retrieve the binary Gradle wrapper JAR,
`gradlew` / `gradlew.bat` are small bootstrap launchers: on first CLI use they download the official
Gradle 9.6.0 binary distribution, verify the published SHA-256, and then invoke that exact Gradle.
Android Studio should use the version in `gradle-wrapper.properties` for IDE sync.
