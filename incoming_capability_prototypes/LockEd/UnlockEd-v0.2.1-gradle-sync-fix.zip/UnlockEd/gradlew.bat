@echo off
setlocal enabledelayedexpansion
set GRADLE_VERSION=9.6.0
set DIST_NAME=gradle-%GRADLE_VERSION%-bin.zip
set DIST_URL=https://services.gradle.org/distributions/%DIST_NAME%
set DIST_SHA256=bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01
if "%GRADLE_USER_HOME%"=="" (
  set BASE_DIR=%USERPROFILE%\.gradle\unlocked-bootstrap
) else (
  set BASE_DIR=%GRADLE_USER_HOME%\unlocked-bootstrap
)
set ZIP_PATH=%BASE_DIR%\%DIST_NAME%
set GRADLE_HOME=%BASE_DIR%\gradle-%GRADLE_VERSION%

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
  if not exist "%ZIP_PATH%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%DIST_URL%' -OutFile '%ZIP_PATH%'"
    if errorlevel 1 exit /b 1
  )
  for /f "tokens=*" %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%ZIP_PATH%').Hash.ToLower()"') do set ACTUAL=%%H
  if /I not "!ACTUAL!"=="%DIST_SHA256%" (
    echo UnlockEd: Gradle distribution checksum mismatch. 1>&2
    del /q "%ZIP_PATH%" 2>nul
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP_PATH%' '%BASE_DIR%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
