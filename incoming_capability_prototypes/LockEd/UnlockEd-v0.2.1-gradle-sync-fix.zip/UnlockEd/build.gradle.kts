plugins {
    id("com.android.application") version "9.4.0" apply false
    // Keep the Compose compiler plugin on the conservative Kotlin version
    // used in Google's AGP 9.4 documentation. AGP 9.x provides Kotlin
    // compilation itself; this plugin configures the Compose compiler.
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
