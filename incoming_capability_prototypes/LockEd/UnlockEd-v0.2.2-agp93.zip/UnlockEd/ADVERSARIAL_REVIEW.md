# UnlockEd adversarial review — v0.2.0

This review was performed against the original v0.1.0 vertical slice and deliberately escalated from ordinary correctness checking to bypass, lifecycle, privacy and release-readiness analysis.

## Round 1 — correctness and time accounting

### Found
- Foreground attribution treated every accessibility window package as an app switch. IMEs, permission surfaces and System UI could pause or corrupt usage accounting.
- Usage accounting used wall-clock time, making it sensitive to device-clock changes.
- Screen-off could continue consuming allowance.

### Changed
- Accessibility input reduced to `TYPE_WINDOW_STATE_CHANGED`.
- Transient non-launchable window packages are ignored.
- Usage uses `SystemClock.uptimeMillis()` through a monotonic clock abstraction.
- Screen-off settles and pauses the active allowance.
- Reboot/monotonic-epoch reset is handled conservatively.

## Round 2 — active bypass attempts

### Found
- A child could use Recents while GateActivity was visible and return to the target app without seeing another gate because the duplicate-launch guard remained latched.
- Parent settings had no authentication, so a child could simply disable a gated app.

### Changed
- Gate launch state now represents only a short pending launch and clears as soon as UnlockEd becomes visible.
- Returning to the blocked app from Recents re-triggers gating.
- Added local parent PIN setup and verification.
- PIN is PBKDF2-HMAC-SHA256 derived with a random salt; the raw PIN is never stored.

## Round 3 — Android lifecycle / task semantics

### Found
- Parent authentication could survive pressing Home and leave settings open to a child.
- `singleTask` GateActivity semantics could deliver another gated app into an existing task and risk showing/granting the wrong target.

### Changed
- Parent authentication is cleared whenever MainActivity leaves the foreground.
- GateActivity uses `singleTop` and handles `onNewIntent()` explicitly.
- Completion re-reads the current app rule before granting access.

## Round 4 — manifest and privacy

### Found
- AccessibilityService was `exported=false`, which can prevent Android from binding to it. The service is protected by `BIND_ACCESSIBILITY_SERVICE`, so it should be exported to the system.
- App backup was enabled despite storing parental settings and a PIN verifier.

### Changed
- AccessibilityService is now `android:exported="true"` and remains protected by `android.permission.BIND_ACCESSIBILITY_SERVICE`.
- `android:allowBackup="false"`.
- Accessibility service still declares `canRetrieveWindowContent=false` and `isAccessibilityTool=false`.
- No `QUERY_ALL_PACKAGES` permission is requested.

## Round 5 — pedagogical state machine

### Found
- With multiple mistakes close together, an older missed fact could remain stranded in the retry queue while the gate eventually completed.

### Changed
- Extracted a pure Kotlin `QuizSession` state machine.
- Every missed fact must subsequently be answered correctly before the gate can complete.
- Retries are spaced with fresh questions where possible.
- The configured correct-answer count is a minimum rather than a maximum; mistakes may add retrievals but cannot create permanent denial.
- Added deterministic unit tests and separately compiled/executed the pure Kotlin logic successfully.

## Round 6 — residual attack surface

### Deliberately not "solved" in code

1. **AccessibilityService can be disabled by the user.** UnlockEd v0.x is a learning-friction product, not tamper-proof device-owner management. Do not claim otherwise.
2. **Gate Activity launch is still a device-test blocker.** Modern Android restricts background activity launches. AccessibilityService behaviour must be tested on Android 14–17 and relevant OEMs. If unreliable, the likely next architecture is an accessibility overlay rather than escalating permissions indiscriminately.
3. **Split screen / picture-in-picture / notification shade accounting is approximate.** The current model tracks the active top-level package, not fractional visibility.
4. **Package inventory is intentionally limited.** UnlockEd discovers launcher apps through a declared launcher-intent query rather than `QUERY_ALL_PACKAGES`. That is more privacy-preserving, but an app without a launcher activity is not selectable.
5. **No forgotten-PIN recovery flow exists.** Clearing app data/uninstalling resets configuration; this is acceptable for the prototype but requires product design before release.
6. **The current `applicationId` is provisional.** Choose the permanent Play package ID before the first Play Console upload; package IDs cannot casually be changed after release.
7. **No full Android build was executed in this environment.** The Android SDK/Gradle runtime is not installed here. Pure Kotlin challenge logic was compiled and executed; XML was parsed and repository structure was statically checked. A real Gradle/Android Studio build is the next mandatory check.

## Release gate before Play submission

Do not upload this build to production until all of the following pass:

- clean Gradle sync and `assembleDebug` / `test`;
- physical-device test of gate interception on at least one Android 16/17 device;
- Recents, notifications, deep links, split-screen, picture-in-picture and screen-off test matrix;
- service-disable/uninstall behaviour documented honestly;
- permanent application ID chosen;
- per-app rule editor implemented;
- parent PIN recovery/change flow designed;
- privacy policy and Play Data Safety answers prepared;
- Accessibility API declaration and prominent disclosure reviewed against current Play policy;
- closed testing before production rollout.
