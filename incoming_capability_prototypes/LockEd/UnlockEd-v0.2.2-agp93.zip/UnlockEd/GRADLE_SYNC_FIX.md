# Gradle sync compatibility fix

This revision is intended for Android Studio versions whose maximum supported Android Gradle Plugin is AGP 9.3.x.

## Pinned build matrix

- Android Gradle Plugin: **9.3.0**
- Gradle: **9.5.0**
- Gradle JDK: **17**
- Compose compiler plugin: **2.3.21**
- compileSdk / targetSdk: **37**

AGP 9.3 officially supports API 37 and requires Gradle 9.5.0 with JDK 17.

## Android Studio

1. Open the `UnlockEd` project root.
2. Set **Gradle JDK** to **17**.
3. Use the Gradle version defined by `gradle/wrapper/gradle-wrapper.properties`.
4. Ignore automatic Gradle/AGP upgrade suggestions for now; upgrades should be made as a compatible pair.
5. If Android Studio cached the previous failed model, close the project, delete only the project's local `.gradle` directory, reopen, and sync again.

## CLI launcher note

The source archive contains `gradle-wrapper.properties`. The generated environment could not embed the binary Gradle wrapper JAR, so `gradlew` and `gradlew.bat` are small bootstrap launchers for command-line use. On first use they download the official Gradle 9.5.0 binary distribution and its published `.sha256` sidecar, verify the download, and execute that version.
