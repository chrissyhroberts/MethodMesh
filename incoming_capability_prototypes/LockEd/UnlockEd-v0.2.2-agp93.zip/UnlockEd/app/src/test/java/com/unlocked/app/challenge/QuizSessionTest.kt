package com.unlocked.app.challenge

import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuizSessionTest {
    @Test
    fun selectedTableAlwaysAppearsInQuestion() {
        val engine = TimesTableEngine(setOf(7), Random(1))
        repeat(100) {
            val q = engine.next()
            assertTrue(q.left == 7 || q.right == 7)
            assertTrue(q.left in 2..12)
            assertTrue(q.right in 2..12)
        }
    }

    @Test
    fun missedFactReturnsAfterFreshQuestion() {
        val session = QuizSession(setOf(7), requiredCorrect = 3, random = Random(2))
        val missed = session.current

        val wrong = session.submit(-1) as QuizSession.Submission.Incorrect
        assertEquals(missed, wrong.question)

        val fresh = session.current
        session.submit(fresh.answer)
        assertEquals(missed, session.current)
    }

    @Test
    fun multipleMissesMustAllBeRecoveredBeforeUnlock() {
        val session = QuizSession(setOf(8), requiredCorrect = 3, random = Random(4))
        val missedA = session.current
        session.submit(-1)
        val missedB = session.current
        session.submit(-1)

        val fresh1 = session.current
        assertFalse((session.submit(fresh1.answer) as QuizSession.Submission.Correct).complete)
        assertEquals(missedA, session.current)
        assertFalse((session.submit(missedA.answer) as QuizSession.Submission.Correct).complete)

        val fresh2 = session.current
        // Minimum of three correct answers has now been reached, but B is still outstanding.
        assertFalse((session.submit(fresh2.answer) as QuizSession.Submission.Correct).complete)
        assertEquals(missedB, session.current)
        assertTrue((session.submit(missedB.answer) as QuizSession.Submission.Correct).complete)
        assertEquals(4, session.completed)
    }
}
