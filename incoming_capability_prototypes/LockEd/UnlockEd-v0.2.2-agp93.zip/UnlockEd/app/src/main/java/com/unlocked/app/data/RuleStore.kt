package com.unlocked.app.data

import android.content.Context

class RuleStore(context: Context) {
    private val prefs = context.getSharedPreferences("unlocked_rules", Context.MODE_PRIVATE)

    fun gatedPackages(): Set<String> =
        (prefs.getStringSet(KEY_GATED_PACKAGES, emptySet()) ?: emptySet()).toSet()

    fun setGated(packageName: String, gated: Boolean) {
        val next = gatedPackages().toMutableSet().apply {
            if (gated) add(packageName) else remove(packageName)
        }
        prefs.edit().putStringSet(KEY_GATED_PACKAGES, next).apply()
    }

    fun ruleFor(packageName: String): GatedAppRule? {
        if (packageName !in gatedPackages()) return null
        return GatedAppRule(
            packageName = packageName,
            questionsPerGate = prefs.getInt("q_$packageName", 3).coerceIn(1, 20),
            earnedUsageMinutes = prefs.getInt("m_$packageName", 15).coerceIn(1, 240),
            wrongAnswerDelaySeconds = prefs.getInt("d_$packageName", 10).coerceIn(1, 60),
            tables = parseTables(prefs.getString("t_$packageName", DEFAULT_TABLES) ?: DEFAULT_TABLES)
        )
    }

    fun saveRule(rule: GatedAppRule) {
        val safeTables = rule.tables.filter { it in 1..20 }.toSet().ifEmpty { (2..12).toSet() }
        setGated(rule.packageName, true)
        prefs.edit()
            .putInt("q_${rule.packageName}", rule.questionsPerGate.coerceIn(1, 20))
            .putInt("m_${rule.packageName}", rule.earnedUsageMinutes.coerceIn(1, 240))
            .putInt("d_${rule.packageName}", rule.wrongAnswerDelaySeconds.coerceIn(1, 60))
            .putString("t_${rule.packageName}", safeTables.sorted().joinToString(","))
            .apply()
    }

    private fun parseTables(raw: String): Set<Int> = raw
        .split(',')
        .mapNotNull { it.toIntOrNull() }
        .filter { it in 1..20 }
        .toSet()
        .ifEmpty { (2..12).toSet() }

    companion object {
        private const val KEY_GATED_PACKAGES = "gated_packages"
        private val DEFAULT_TABLES = (2..12).joinToString(",")
    }
}
