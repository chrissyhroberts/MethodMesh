package com.unlocked.app.challenge

import java.util.ArrayDeque
import kotlin.random.Random

/**
 * Pure Kotlin quiz state machine.
 *
 * Invariants:
 *  - a wrong answer incurs UI delay outside this class;
 *  - every missed fact is queued and must later be answered correctly before unlock;
 *  - retries are spaced by a fresh question where practical;
 *  - repeated misses never erase older missed facts;
 *  - requiredCorrect is a minimum, so mistakes can add retrieval work but never permanent denial.
 */
class QuizSession(
    tables: Set<Int>,
    val requiredCorrect: Int,
    random: Random = Random.Default
) {
    private val engine = TimesTableEngine(tables, random)
    private val missed = ArrayDeque<TimesTableQuestion>()
    private var currentIsRetry = false
    private var retryDueAfterFresh = false

    var current: TimesTableQuestion = engine.next()
        private set

    var completed: Int = 0
        private set

    val isComplete: Boolean
        get() = completed >= requiredCorrect.coerceAtLeast(1) && missed.isEmpty() && !currentIsRetry

    fun submit(answer: Int?): Submission {
        if (answer == current.answer) {
            completed += 1

            // A retry has now been demonstrated correctly. If no other missed facts remain and the
            // minimum correct count is satisfied, completion is allowed immediately.
            if (currentIsRetry && missed.isEmpty() && completed >= requiredCorrect.coerceAtLeast(1)) {
                currentIsRetry = false
                return Submission.Correct(complete = true)
            }

            chooseNextAfterCorrect()
            return Submission.Correct(complete = isComplete)
        }

        val missedQuestion = current
        missed.addLast(missedQuestion)
        current = engine.next()
        currentIsRetry = false
        retryDueAfterFresh = true
        return Submission.Incorrect(missedQuestion)
    }

    private fun chooseNextAfterCorrect() {
        when {
            retryDueAfterFresh && missed.isNotEmpty() -> {
                current = missed.removeFirst()
                currentIsRetry = true
                retryDueAfterFresh = false
            }
            currentIsRetry && missed.isNotEmpty() -> {
                // Space successive retries with one fresh retrieval.
                current = engine.next()
                currentIsRetry = false
                retryDueAfterFresh = true
            }
            else -> {
                current = engine.next()
                currentIsRetry = false
                retryDueAfterFresh = missed.isNotEmpty()
            }
        }
    }

    sealed interface Submission {
        data class Correct(val complete: Boolean) : Submission
        data class Incorrect(val question: TimesTableQuestion) : Submission
    }
}
