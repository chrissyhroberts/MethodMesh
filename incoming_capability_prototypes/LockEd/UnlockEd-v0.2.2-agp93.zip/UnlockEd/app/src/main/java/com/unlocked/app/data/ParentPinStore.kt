package com.unlocked.app.data

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Local-only parent PIN verifier. The PIN itself is never stored. */
class ParentPinStore(context: Context) {
    private val prefs = context.getSharedPreferences("unlocked_parent", Context.MODE_PRIVATE)

    fun hasPin(): Boolean = prefs.contains(KEY_SALT) && prefs.contains(KEY_HASH)

    fun setPin(pin: String): Boolean {
        if (!isValidPin(pin)) return false
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val hash = derive(pin, salt)
        prefs.edit()
            .putString(KEY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
        return true
    }

    fun verify(pin: String): Boolean {
        if (!isValidPin(pin)) return false
        val salt = prefs.getString(KEY_SALT, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val expected = prefs.getString(KEY_HASH, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val actual = derive(pin, salt)
        if (actual.size != expected.size) return false

        var difference = 0
        for (i in actual.indices) difference = difference or (actual[i].toInt() xor expected[i].toInt())
        return difference == 0
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    companion object {
        private const val KEY_SALT = "pin_salt"
        private const val KEY_HASH = "pin_hash"
        private const val ITERATIONS = 120_000
        private const val KEY_LENGTH_BITS = 256

        fun isValidPin(pin: String): Boolean = pin.length in 4..8 && pin.all(Char::isDigit)
    }
}
