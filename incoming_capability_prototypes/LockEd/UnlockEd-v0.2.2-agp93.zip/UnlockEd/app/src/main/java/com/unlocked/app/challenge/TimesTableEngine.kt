package com.unlocked.app.challenge

import kotlin.random.Random

data class TimesTableQuestion(
    val left: Int,
    val right: Int
) {
    val answer: Int get() = left * right
    val prompt: String get() = "$left × $right"
}

class TimesTableEngine(
    private val tables: Set<Int>,
    private val random: Random = Random.Default
) {
    private val safeTables = tables.ifEmpty { (2..12).toSet() }

    fun next(): TimesTableQuestion {
        val table = safeTables.elementAt(random.nextInt(safeTables.size))
        val multiplier = random.nextInt(2, 13)
        return if (random.nextBoolean()) {
            TimesTableQuestion(table, multiplier)
        } else {
            TimesTableQuestion(multiplier, table)
        }
    }
}
