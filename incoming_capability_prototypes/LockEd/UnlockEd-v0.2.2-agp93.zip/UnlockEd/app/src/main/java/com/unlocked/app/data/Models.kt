package com.unlocked.app.data

data class GatedAppRule(
    val packageName: String,
    val questionsPerGate: Int = 3,
    val earnedUsageMinutes: Int = 15,
    val wrongAnswerDelaySeconds: Int = 10,
    val tables: Set<Int> = (2..12).toSet()
)
