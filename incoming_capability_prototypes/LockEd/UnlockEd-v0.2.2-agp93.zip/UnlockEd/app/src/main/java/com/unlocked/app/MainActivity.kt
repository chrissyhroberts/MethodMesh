package com.unlocked.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.unlocked.app.apps.InstalledAppsRepository
import com.unlocked.app.apps.LaunchableApp
import com.unlocked.app.data.GatedAppRule
import com.unlocked.app.data.ParentPinStore
import com.unlocked.app.data.RuleStore
import com.unlocked.app.data.UsageLedger

class MainActivity : ComponentActivity() {
    private val authenticatedState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ParentEntry(
                    context = this,
                    authenticated = authenticatedState.value,
                    onAuthenticated = { authenticatedState.value = true },
                    openAccessibilitySettings = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }
                )
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Parent settings must never remain open for a child after the parent leaves the app.
        if (!isChangingConfigurations) authenticatedState.value = false
    }
}

@Composable
private fun ParentEntry(
    context: Context,
    authenticated: Boolean,
    onAuthenticated: () -> Unit,
    openAccessibilitySettings: () -> Unit
) {
    val pinStore = remember { ParentPinStore(context) }
    var hasPin by remember { mutableStateOf(pinStore.hasPin()) }

    when {
        !hasPin -> PinSetupScreen(onSetPin = { pin ->
            if (pinStore.setPin(pin)) {
                hasPin = true
                onAuthenticated()
                true
            } else false
        })
        !authenticated -> PinUnlockScreen(onVerify = { pin ->
            pinStore.verify(pin).also { if (it) onAuthenticated() }
        })
        else -> UnlockEdHome(context, openAccessibilitySettings)
    }
}

@Composable
private fun PinSetupScreen(onSetPin: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("UnlockEd", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Create a parent PIN", style = MaterialTheme.typography.titleLarge)
            Text("This protects which apps are gated and the learning settings.")
            Spacer(Modifier.height(24.dp))
            PinField("PIN (4–8 digits)", pin) { pin = it }
            Spacer(Modifier.height(12.dp))
            PinField("Confirm PIN", confirm) { confirm = it }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    error = when {
                        !ParentPinStore.isValidPin(pin) -> "Use 4–8 digits."
                        pin != confirm -> "PINs do not match."
                        !onSetPin(pin) -> "Could not save the PIN."
                        else -> null
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Set parent PIN") }
        }
    }
}

@Composable
private fun PinUnlockScreen(onVerify: (String) -> Boolean) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text("Parent settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            PinField("Parent PIN", pin) { pin = it }
            if (error) Text("Incorrect PIN.", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    if (!onVerify(pin)) {
                        error = true
                        pin = ""
                    }
                },
                enabled = ParentPinStore.isValidPin(pin),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Open settings") }
        }
    }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(8)) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
    )
}

@Composable
private fun UnlockEdHome(context: Context, openAccessibilitySettings: () -> Unit) {
    val ruleStore = remember { RuleStore(context) }
    val usageLedger = remember { UsageLedger(context) }
    val appRepo = remember { InstalledAppsRepository(context) }
    var apps by remember { mutableStateOf<List<LaunchableApp>>(emptyList()) }
    var gatedPackages by remember { mutableStateOf(ruleStore.gatedPackages()) }
    var disclosureAccepted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { apps = appRepo.launchableApps() }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("UnlockEd", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Learn to unlock", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(20.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("App gate service", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (isAccessibilityServiceEnabled(context)) {
                            "Enabled. UnlockEd can detect when a selected app comes to the foreground."
                        } else {
                            "Disabled. Enable the UnlockEd app gate after reading the disclosure below."
                        }
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "UnlockEd uses Android Accessibility events only to identify which selected app is currently visible. " +
                            "It does not retrieve window content, read messages, record the screen, inspect what you type, or monitor activity inside an app."
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = disclosureAccepted, onCheckedChange = { disclosureAccepted = it })
                        Text("I understand and consent to this use of Accessibility events.")
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = openAccessibilitySettings, enabled = disclosureAccepted) {
                        Text("Open Accessibility settings")
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("Choose apps that require learning to unlock", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Everything else remains unrestricted. Core device apps are excluded from this list.")
            Spacer(Modifier.height(10.dp))

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(apps, key = { it.packageName }) { app ->
                    val gated = app.packageName in gatedPackages
                    AppRuleRow(
                        app = app,
                        gated = gated,
                        rule = ruleStore.ruleFor(app.packageName),
                        onGatedChange = { shouldGate ->
                            if (shouldGate) {
                                ruleStore.saveRule(GatedAppRule(packageName = app.packageName))
                            } else {
                                ruleStore.setGated(app.packageName, false)
                                usageLedger.clear(app.packageName)
                            }
                            gatedPackages = ruleStore.gatedPackages()
                        }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun AppRuleRow(app: LaunchableApp, gated: Boolean, rule: GatedAppRule?, onGatedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(app.label, fontWeight = FontWeight.SemiBold)
            Text(
                if (gated) {
                    "${rule?.questionsPerGate ?: 3} questions • ${rule?.earnedUsageMinutes ?: 15} min earned use • ${rule?.wrongAnswerDelaySeconds ?: 10}s delay"
                } else "Unrestricted",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Switch(checked = gated, onCheckedChange = onGatedChange)
    }
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val manager = context.getSystemService(AccessibilityManager::class.java) ?: return false
    return manager
        .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        .any { info ->
            val service = info.resolveInfo.serviceInfo
            service.packageName == context.packageName &&
                service.name == "${context.packageName}.accessibility.AppGateService"
        }
}
