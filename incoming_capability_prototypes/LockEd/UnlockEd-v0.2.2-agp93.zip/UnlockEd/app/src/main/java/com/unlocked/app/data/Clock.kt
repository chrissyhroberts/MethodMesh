package com.unlocked.app.data

import android.os.SystemClock

/**
 * Monotonic time source used for usage accounting.
 * Device wall-clock changes must never create or destroy earned app time.
 */
fun interface MonotonicClock {
    fun nowMillis(): Long
}

object AndroidMonotonicClock : MonotonicClock {
    override fun nowMillis(): Long = SystemClock.uptimeMillis()
}
