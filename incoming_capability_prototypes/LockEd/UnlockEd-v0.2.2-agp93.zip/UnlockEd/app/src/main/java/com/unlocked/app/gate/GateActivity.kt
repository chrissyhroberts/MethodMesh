package com.unlocked.app.gate

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unlocked.app.challenge.QuizSession
import com.unlocked.app.challenge.TimesTableQuestion
import com.unlocked.app.data.RuleStore
import com.unlocked.app.data.UsageLedger
import kotlinx.coroutines.delay

class GateActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderFromIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        renderFromIntent(intent)
    }

    private fun renderFromIntent(sourceIntent: Intent) {
        val targetPackage = sourceIntent.getStringExtra(EXTRA_TARGET_PACKAGE)
        if (targetPackage.isNullOrBlank() || targetPackage == packageName) {
            finish()
            return
        }

        val rule = RuleStore(this).ruleFor(targetPackage)
        if (rule == null) {
            finish()
            return
        }

        setContent {
            MaterialTheme {
                GateScreen(
                    appLabel = appLabel(targetPackage),
                    tables = rule.tables,
                    questionsRequired = rule.questionsPerGate,
                    penaltySeconds = rule.wrongAnswerDelaySeconds,
                    onComplete = {
                        // Re-read the rule at completion so a parent disabling the gate concurrently
                        // cannot leave a stale or malformed grant behind.
                        val currentRule = RuleStore(this).ruleFor(targetPackage)
                        if (currentRule != null) {
                            UsageLedger(this).grantMinutes(targetPackage, currentRule.earnedUsageMinutes)
                        }
                        reopenTarget(targetPackage)
                    },
                    onLeave = ::goHome
                )
            }
        }
    }

    private fun appLabel(packageName: String): String = runCatching {
        val info = packageManager.getApplicationInfo(packageName, 0)
        packageManager.getApplicationLabel(info).toString()
    }.getOrDefault("this app")

    private fun reopenTarget(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(launch)
        } else {
            goHome()
        }
        finish()
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        finish()
    }

    companion object {
        const val EXTRA_TARGET_PACKAGE = "target_package"
    }
}

@Composable
private fun GateScreen(
    appLabel: String,
    tables: Set<Int>,
    questionsRequired: Int,
    penaltySeconds: Int,
    onComplete: () -> Unit,
    onLeave: () -> Unit
) {
    val session = remember(tables, questionsRequired) {
        QuizSession(tables = tables, requiredCorrect = questionsRequired.coerceIn(1, 20))
    }
    var question by remember { mutableStateOf(session.current) }
    var answer by remember { mutableStateOf("") }
    var completed by remember { mutableIntStateOf(session.completed) }
    var penaltyRemaining by remember { mutableIntStateOf(0) }
    var correction by remember { mutableStateOf<TimesTableQuestion?>(null) }
    var completionSent by remember { mutableStateOf(false) }

    BackHandler(onBack = onLeave)

    LaunchedEffect(penaltyRemaining) {
        if (penaltyRemaining > 0) {
            delay(1_000)
            penaltyRemaining -= 1
            if (penaltyRemaining == 0) {
                correction = null
                answer = ""
                question = session.current
            }
        }
    }

    fun submit() {
        if (penaltyRemaining > 0 || completionSent) return
        when (val result = session.submit(answer.toIntOrNull())) {
            is QuizSession.Submission.Correct -> {
                completed = session.completed
                answer = ""
                correction = null
                if (result.complete) {
                    completionSent = true
                    onComplete()
                } else {
                    question = session.current
                }
            }
            is QuizSession.Submission.Incorrect -> {
                correction = result.question
                penaltyRemaining = penaltySeconds.coerceIn(1, 60)
                answer = ""
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 48.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("$appLabel is waiting", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("A little revision first", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(36.dp))

            if (penaltyRemaining > 0) {
                Text("Not quite", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(
                    text = correction?.let { "${it.prompt} = ${it.answer}" }.orEmpty(),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(24.dp))
                Text("Try again in $penaltyRemaining…", style = MaterialTheme.typography.titleMedium)
            } else {
                Text("${question.prompt} = ?", fontSize = 42.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(28.dp))
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it.filter(Char::isDigit).take(4) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Answer") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() })
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { submit() },
                    enabled = answer.isNotBlank()
                ) { Text("Check") }
            }

            Spacer(Modifier.height(32.dp))
            Text("${completed.coerceAtMost(questionsRequired)} of $questionsRequired complete", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onLeave) { Text("Not now") }
        }
    }
}
