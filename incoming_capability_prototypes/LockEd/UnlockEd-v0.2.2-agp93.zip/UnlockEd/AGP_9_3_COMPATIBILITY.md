# UnlockEd v0.2.2 — Android Studio compatibility

This revision is pinned for Android Studio releases whose maximum supported Android Gradle Plugin is AGP 9.3.x.

- Android Gradle Plugin: **9.3.0**
- Gradle: **9.5.0**
- JDK: **17**
- compileSdk / targetSdk: **37**
- Compose compiler plugin: **2.3.21**

No application logic was changed in this compatibility revision.

The Gradle distribution checksum line from v0.2.1 was removed because it referred specifically to Gradle 9.6.0 and must not be reused for Gradle 9.5.0. The wrapper remains pinned to the official Gradle 9.5.0 distribution URL.
