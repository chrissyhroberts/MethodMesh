package com.example.methodmesh.modules.conversationtranslate

import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

internal const val CONVERSATION_VOICE_FEMALE = "female"
internal const val CONVERSATION_VOICE_MALE = "male"

internal fun normalizeConversationVoicePreference(value: String?): String =
    if (value.equals(CONVERSATION_VOICE_MALE, ignoreCase = true)) {
        CONVERSATION_VOICE_MALE
    } else {
        CONVERSATION_VOICE_FEMALE
    }

internal fun toggleConversationVoicePreference(value: String): String =
    if (normalizeConversationVoicePreference(value) == CONVERSATION_VOICE_FEMALE) {
        CONVERSATION_VOICE_MALE
    } else {
        CONVERSATION_VOICE_FEMALE
    }

internal fun conversationVoiceSymbol(value: String): String =
    if (normalizeConversationVoicePreference(value) == CONVERSATION_VOICE_FEMALE) "♀" else "♂"

/**
 * Android's TextToSpeech Voice API does not expose a standard gender field.
 * Some engines include a gender hint in the voice name/features; when they do,
 * honour the participant preference. Otherwise retain the engine's locale
 * default rather than pretending an arbitrary voice is male or female.
 */
internal fun TextToSpeech.applyConversationVoicePreference(
    locale: Locale,
    preference: String
): Boolean {
    val requested = normalizeConversationVoicePreference(preference)
    val availableVoices: Set<Voice> = voices ?: emptySet()
    val sameLanguage: List<Voice> = availableVoices
        .filter { voice: Voice -> voice.locale.language.equals(locale.language, ignoreCase = true) }
    val localeVoices: List<Voice> = if (locale.country.isBlank()) {
        sameLanguage
    } else {
        sameLanguage
            .filter { voice: Voice -> voice.locale.country.equals(locale.country, ignoreCase = true) }
            .ifEmpty { sameLanguage }
    }

    val tagged: List<Voice> = localeVoices.filter { voice: Voice -> voiceGenderHint(voice) == requested }
    val selected = tagged
        .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.latency }.thenBy { it.name })
        .firstOrNull()
        ?: return false

    return setVoice(selected) == TextToSpeech.SUCCESS
}

private fun voiceGenderHint(voice: Voice): String? {
    val searchable = buildString {
        append(voice.name.lowercase(Locale.ROOT))
        voice.features?.forEach { feature -> append(' ').append(feature.lowercase(Locale.ROOT)) }
    }
    return when {
        listOf("female", "woman", "feminine", "girl").any(searchable::contains) -> CONVERSATION_VOICE_FEMALE
        listOf("male", " man", "masculine", "boy").any(searchable::contains) -> CONVERSATION_VOICE_MALE
        else -> null
    }
}
