# Text documents v0.06

Compile repair over v0.05.

- removes the invalid explicit `androidx.compose.foundation.layout.weight` imports from `DocumentSurface.kt` and `TextDocumentsCapabilityScreen.kt`;
- retains the normal `Modifier.weight(...)` calls inside Row/Column scopes, where Compose supplies the scoped extension correctly;
- otherwise preserves the v0.05 Master Book conformance refresh unchanged.
