# Paper Bridge ODK round-trip test

Use `example_odk_showcase_paper_form_transcribe.xlsx` as the canonical integration fixture.

## Registration fixture

The current bundled schema uses APRILTAG8 registration. Its prepared blank/filled forms contain eight unique AprilTag36h11 markers (IDs 0–7); their corners define the runtime projective registration. Legacy QR4/bullseye4 registration is not the primary integration fixture.

## Expected flow

1. Load the XLSForm into ODK Collect.
2. Enter the `scan_paper` group. Its `body::intent` launches `paper.form.transcribe` with `return_mode='flat'` and `input_payload_mode='FULL'`.
3. Scan and review a completed paper form in Paper Bridge.
4. Commit once all review items are resolved.
5. Paper Bridge returns through the canonical Android/MethodMesh result path; it does **not** create a standalone result ZIP for an external/ODK launch.
6. ODK resumes the same form instance. The final note shows a short value summary so the operator can see that the round trip occurred.
7. The form instance also owns the hidden source image, registered image, image-ROI attachment, hashes and audit/metadata fields.

## Demo data nodes

- `participant_id`
- `visit_number`
- `eaten_today`
- `symptoms`
- `temperature_c`
- `specimen_barcode`
- `site_sketch` (`image`)

## Stable Paper Bridge nodes

- `paper_status`
- `paper_template_id`
- `paper_template_version`
- `paper_values_json`
- `paper_dynamic_fields_json`
- `paper_field_count`
- `paper_auto_accepted_count`
- `paper_reviewed_count`
- `paper_unresolved_count`
- `paper_source_image` (`image`)
- `paper_rectified_image` (`image`)
- `paper_template_sha256`
- `paper_source_sha256`
- `paper_rectified_sha256`
- `paper_extraction_audit_json`
- `paper_attachment_metadata_json`
- `paper_scan_time_iso`
- `paper_error`
- `methodmesh_full_json`

## Media expectation

The three demo media returns are `site_sketch`, `paper_source_image` and `paper_rectified_image`. They are returned as `content://` URIs and the shared MethodMesh Android result transport is responsible for read grants/ClipData so ODK can take ownership.

## Barcode expectation

A clean single barcode decode returns its decoded text directly. If a barcode ROI visibly contains a label but ML Kit cannot decode it after retry processing, the field must remain in Review rather than silently returning blank. OCR of human-readable text in the barcode ROI may be shown as a suggested value, but requires operator confirmation.

## Validation status

The workbook has been structurally inspected and contains no spreadsheet formula errors. A true ODK Collect device round trip remains the acceptance test; do not promote this Development module on workbook inspection alone.


## APRILTAG8 geometry contract

Current Paper Bridge schemas use eight unique AprilTag `tag36h11` markers, IDs 0–7, in semantic order TL, TC, TR, LC, RC, BL, BC, BR. The printable prepared form places these in a dedicated registration border outside the canonical form artwork. Runtime detection uses the four outer corners of every accepted tag (up to 32 correspondences), rejects duplicate/weak IDs, requires at least four well-distributed tags, fits a robust projective homography, reports RMS and maximum reprojection error, and fails closed when registration quality is not trustworthy. The registered bitmap is then cropped back to the exact canonical form dimensions. Saved field ROIs are never individually shifted or rescaled to compensate for scan geometry. QR4 and bullseye4 are legacy-compatible only.
