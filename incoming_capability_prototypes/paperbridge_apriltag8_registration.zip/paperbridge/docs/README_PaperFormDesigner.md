# Paper Bridge visual designer — `paper.form.design`

Paper Bridge treats a paper layout as a named reusable **schema**. The native designer opens through the Schema Library rather than dropping directly into a random form. User schemas can be created, opened, renamed, duplicated, deleted, exported and restored. The bundled example is a staged tutorial rather than a pre-wired finished schema.

## Normal authoring workflow

1. Open **Paper Bridge → Schemas**.
2. Create a schema and give it a name, or open **Example — learn Paper Bridge**.
3. Import an ordinary Excel/XLSForm-style workbook with `survey` and `choices` sheets.
4. Import the blank/colour-authored paper PNG or PDF **without QR fiducials**. The author supplies the form artwork only.
5. For a new schema, Paper Bridge assigns a short schema key and **automatically prepares a separate printable APRILTAG8 version** of the form. The eight tags live in a dedicated white registration border so the canonical artwork and saved ROIs are not rescaled or overwritten. The imported artwork is preserved unchanged as the canonical content; it is not destructively edited.
6. Press **AUTO DETECT**. Paper Bridge detects colour-authored question regions or ordinary printed response boxes, OCR-matches question labels against `survey.label`, matches select option labels against `choices.label`, and proposes ROI linkages.
7. Resolve highlighted queries in **EDIT**. Manual **+ BOX** exists only for regions automatic detection cannot find.
8. Use the persistent lifecycle: **SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE**.
9. The saved schema exports JSON/YAML, canonical/mapping images, a printable QR-prepared form, and a portable `.paperbridge.zip` backup.

## APRILTAG8 registration — default for new schemas

New Paper Bridge schemas use four schema-specific QR fiducials by default. Payloads are:

New schemas use **APRILTAG8** registration. Paper Bridge generates eight unique AprilTag `tag36h11` markers (IDs 0–7) in a dedicated white perimeter border at TL, TC, TR, LC, RC, BL, BC and BR. The imported artwork remains the unscaled canonical authoring canvas; the registration border is added only to the generated `*.prepared-form.png`.

Every detected tag contributes its four outer corners, giving up to 32 geometric correspondences. A robust homography maps the photographed prepared page back to the exact canonical artwork dimensions before any ROI is read. Registration fails closed when fewer than four suitably distributed tags are available or reprojection residuals are too large. Individual field ROIs must never be nudged to compensate for registration error.

Legacy **QR4** (`PB:<schema-key>:TL/TR/BR/BL`) and **bullseye4** schemas remain readable for backwards compatibility, but they are not the default authoring route.

## Colour-assisted authoring

For new forms, the fixed colour syntax in `README_Colour_Authoring.md` is preferred:

- solid magenta: scalar (`text`, `integer`, `decimal`);
- solid teal: `select_one`;
- solid orange: `select_multiple`;
- solid violet: `barcode`;
- solid lime: `image`;
- blue text: select-option labels;
- black: question text and response geometry.

Colour is used only to learn schema semantics. The production form may be monochrome or use any colours because runtime transcription reads only stored ROIs after registration.

Question matching uses the printed question text against **`survey.label`**, not the variable name. Choice matching uses printed option text against **`choices.label`** and stores the corresponding `choices.name` as the returned value. Compatible type is always part of matching, and uncertain matches remain explicit queries rather than being silently accepted.

## Excel workbook contract

Paper Bridge does not require ODK. Any `.xlsx` using the supported XLSForm-style structure can define the data schema.

`survey` requires `type`, `name`, `label`; `required` and `constraint` are optional. Supported types are:

- `text`
- `integer`
- `decimal`
- `select_one <list_name>`
- `select_multiple <list_name>`
- `barcode`
- `image`

`choices` uses `list_name`, `name`, `label`. Optional `settings` may provide `form_id`, `form_title`, and `version`.

## Canvas interaction

The designer is a fixed full-screen workspace. Its minimalist strip across the top of the paper viewport contains **NAV · AUTO DETECT · + BOX · EDIT · − · zoom · + · FIT**.

- **NAV** exclusively owns pinch-to-zoom and drag-to-pan.
- **EDIT** owns tap selection, move and corner-resize.
- Overlay labels use the same page transform as their ROI, so they remain attached while panning/zooming instead of accumulating against the viewport boundary.
- Overlapping boxes select the smallest region under the tap.

The lower pane contains field/linkage information and scrolls independently from the paper canvas.

## Lifecycle

The designer lifecycle is explicit:

**SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE**

Saving persists the current named schema without closing it. `TEST EMPTY` verifies that an unfilled production form does not create false response values. `TEST DATA` exercises the same acquisition/registration/extraction pipeline on a completed sheet. Editing the mapping after a test makes the schema dirty and requires another save/test cycle before Finalise.

`image` fields are not considered false-positive merely because their ROI crop exists on a blank form: the image attachment represents the declared region itself.

## Portable outputs

Saving a current APRILTAG8 schema produces:

- `*.paperbridge.json` — canonical schema definition;
- `*.paperbridge.yaml` — fixed-profile human-readable backup;
- `*.template.png` — canonical centre-to-centre authoring canvas;
- `*.prepared-form.png` — printable page with eight unique AprilTag36h11 registration markers;
- `*.mapping.png` — annotated ROI/linkage image;
- `*.paperbridge.zip` — portable backup containing the above artifacts.

The design method additionally returns `paper_design_prepared_form_image` when registration preparation is available.

A restored bundle stores `template.png` as an already-canonical source; it is never registered a second time.

## Built-in tutorial

The example appears in the Schema Library as **Example — learn Paper Bridge** and begins unresolved. Opening it shows the **QR-free colour-authored source form** and matching workbook. QR fiducials are generated later by Paper Bridge for the prepared blank/filled test sheets; they are not part of the authoring input. The intended exercise is:

1. **AUTO DETECT**;
2. inspect detected ROIs and proposed question/choice matches;
3. resolve any highlighted queries;
4. **SAVE SCHEMA**;
5. **TEST EMPTY** using the bundled blank production form;
6. **TEST DATA** using the bundled completed form;
7. **FINALISE**.

The tutorial includes text, integer, decimal, single-choice OMR, multiple-choice OMR, barcode and image-region capture. It can be reset and repeated.


### Test diagnostics

Schema-test status is shown directly under the lifecycle controls. APRILTAG8 registration failures therefore remain visible while the scan workspace is on screen, including marker counts and reprojection diagnostics. TEST EMPTY treats weak OMR activity as a baseline warning while preserving a blocking failure for strong apparent marks.


## APRILTAG8 geometry contract

Current Paper Bridge schemas use eight unique AprilTag `tag36h11` markers, IDs 0–7, in semantic order TL, TC, TR, LC, RC, BL, BC, BR. The printable prepared form places these in a dedicated registration border outside the canonical form artwork. Runtime detection uses the four outer corners of every accepted tag (up to 32 correspondences), rejects duplicate/weak IDs, requires at least four well-distributed tags, fits a robust projective homography, reports RMS and maximum reprojection error, and fails closed when registration quality is not trustworthy. The registered bitmap is then cropped back to the exact canonical form dimensions. Saved field ROIs are never individually shifted or rescaled to compensate for scan geometry. QR4 and bullseye4 are legacy-compatible only.
