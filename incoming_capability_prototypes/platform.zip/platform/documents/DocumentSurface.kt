package com.example.methodmesh.platform.documents

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon

/** Platform-owned document surface. It deliberately knows nothing about MethodMesh modules. */
enum class DocumentMode { RENDERED, SOURCE }
enum class DocumentFormat { MARKDOWN, TEXT }

@Composable
fun DocumentSurface(
    title: String,
    initialText: String,
    format: DocumentFormat,
    writable: Boolean,
    onBack: () -> Unit,
    onSave: suspend (String) -> Result<Unit>,
    modifier: Modifier = Modifier,
) {
    val androidContext = LocalContext.current
    var text by remember(initialText) { mutableStateOf(initialText) }
    var mode by remember(format) { mutableStateOf(if (format == DocumentFormat.MARKDOWN) DocumentMode.RENDERED else DocumentMode.SOURCE) }
    var hudOpen by remember { mutableStateOf(false) }
    var findOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var dirty by remember(initialText) { mutableStateOf(false) }
    var saveMessage by remember { mutableStateOf<String?>(null) }

    Surface(modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            DocumentTopBar(title, dirty, onBack)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (mode) {
                    DocumentMode.RENDERED -> MarkdownDocument(text, Modifier.fillMaxSize())
                    DocumentMode.SOURCE -> SourceDocument(
                        text = text,
                        onTextChanged = {
                            text = it
                            dirty = it != initialText
                            saveMessage = null
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Column(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 14.dp).imePadding(),
                    horizontalAlignment = Alignment.End
                ) {
                    DropdownMenu(expanded = hudOpen, onDismissRequest = { hudOpen = false }) {
                        if (format == DocumentFormat.MARKDOWN) {
                            DropdownMenuItem(
                                text = { Text(if (mode == DocumentMode.RENDERED) "Edit" else "Preview") },
                                leadingIcon = { Text(if (mode == DocumentMode.RENDERED) "✎" else "◉") },
                                onClick = {
                                    mode = if (mode == DocumentMode.RENDERED) DocumentMode.SOURCE else DocumentMode.RENDERED
                                    hudOpen = false
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Find") },
                            leadingIcon = { Text("⌕") },
                            onClick = { findOpen = true; hudOpen = false }
                        )
                        DropdownMenuItem(text = { Text("Copy all") }, onClick = {
                            copyText(androidContext, title, text); hudOpen = false
                        })
                        if (writable && dirty) {
                            DropdownMenuItem(text = { Text("Save") }, onClick = {
                                saveMessage = "Saving…"; hudOpen = false
                            })
                        }
                    }
                    FloatingActionButton(onClick = { hudOpen = true }, modifier = Modifier.size(48.dp)) {
                        Text("⋮", style = MaterialTheme.typography.titleLarge)
                    }
                }
            }
            if (findOpen) FindStrip(query, { query = it }, text, { findOpen = false })
            saveMessage?.let { pending ->
                if (pending == "Saving…") {
                    LaunchedEffect(text) {
                        saveMessage = onSave(text).fold({ dirty = false; "Saved" }, { "Save failed: ${it.message ?: "unknown error"}" })
                    }
                }
                Text(saveMessage.orEmpty(), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.ime))
        }
    }
}

@Composable
private fun DocumentTopBar(title: String, dirty: Boolean, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Text("×", style = MaterialTheme.typography.titleLarge) }
        Text(title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 1)
        if (dirty) Text("•", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun SourceDocument(text: String, onTextChanged: (String) -> Unit, modifier: Modifier = Modifier) {
    BasicTextField(
        value = text,
        onValueChange = onTextChanged,
        modifier = modifier.padding(horizontal = 16.dp, vertical = 8.dp).verticalScroll(rememberScrollState()),
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary)
    )
}

@Composable
private fun MarkdownDocument(markdown: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val markwon = remember(context) { Markwon.create(context) }
    AndroidView(
        modifier = modifier.verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 10.dp),
        factory = { ctx -> TextView(ctx).apply { textSize = 17f; setLineSpacing(0f, 1.18f); setTextIsSelectable(true) } },
        update = { view -> markwon.setMarkdown(view, markdown) }
    )
}

@Composable
private fun FindStrip(query: String, onQueryChanged: (String) -> Unit, text: String, onClose: () -> Unit) {
    val count = remember(query, text) { if (query.isBlank()) 0 else Regex(Regex.escape(query), RegexOption.IGNORE_CASE).findAll(text).count() }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer).padding(horizontal = 12.dp, vertical = 8.dp).navigationBarsPadding(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = query,
            onValueChange = onQueryChanged,
            singleLine = true,
            modifier = Modifier.weight(1f),
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            decorationBox = { inner -> if (query.isBlank()) Text("Find…", color = MaterialTheme.colorScheme.onSurfaceVariant); inner() }
        )
        Text(if (query.isBlank()) "" else "$count", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp))
        IconButton(onClick = onClose) { Text("×", style = MaterialTheme.typography.titleLarge) }
    }
}

private fun copyText(context: Context, label: String, text: String) {
    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
        .setPrimaryClip(ClipData.newPlainText(label, text))
}
