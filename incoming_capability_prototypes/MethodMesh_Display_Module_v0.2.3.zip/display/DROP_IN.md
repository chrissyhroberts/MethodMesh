# Drop-in

Replace the existing Display module folder with this folder at:

`app/src/main/java/com/example/methodmesh/modules/display/`

This is a clean experimental redesign. It intentionally removes the unused `display.static`, `display.marquee`, `display.board`, `display.code` and `display.sequence` method IDs and exposes only `display.show`.

No shared/core source edit or new Gradle dependency is intended.

Then run:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
```
