package com.example.methodmesh.modules.weather

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

@Composable
internal fun WeatherDashboardScreen(
    context: CapabilityScreenContext,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit
) {
    val app = LocalContext.current
    val scope = rememberCoroutineScope()
    var latitude by rememberSaveable { mutableStateOf((context.action.settings["latitude"] ?: context.action.settings["input_latitude"]).orEmpty()) }
    var longitude by rememberSaveable { mutableStateOf((context.action.settings["longitude"] ?: context.action.settings["input_longitude"]).orEmpty()) }
    var rainThreshold by rememberSaveable { mutableStateOf((context.action.settings["threshold_mm_per_hour"] ?: context.action.settings["input_threshold_mm_per_hour"] ?: "0.2")) }
    var offlineOnly by rememberSaveable { mutableStateOf((context.action.settings["offline_only"] ?: context.action.settings["input_offline_only"]).equals("true", ignoreCase = true)) }
    var payloadJson by rememberSaveable { mutableStateOf("") }
    var running by rememberSaveable { mutableStateOf(false) }
    var message by rememberSaveable { mutableStateOf("Locating…") }
    var attempted by rememberSaveable { mutableStateOf(false) }
    var showLocation by rememberSaveable { mutableStateOf(false) }

    val payload = remember(payloadJson) { runCatching { JSONObject(payloadJson) }.getOrNull() }
    fun section(name: String): Map<String,String> = payload?.optJSONObject(name)?.let { o ->
        buildMap { val keys=o.keys(); while(keys.hasNext()){ val k=keys.next(); put(k,o.optString(k,"")) } }
    }.orEmpty()

    fun runDashboard() {
        if(running || latitude.toDoubleOrNull()==null || longitude.toDoubleOrNull()==null) return
        running=true; message="Refreshing meteorology…"
        scope.launch {
            val settings=context.action.settings.mapKeys{it.key.removePrefix("input_")} + mapOf(
                "latitude" to latitude,
                "longitude" to longitude,
                "threshold_mm_per_hour" to rainThreshold,
                "offline_only" to offlineOnly.toString()
            )
            val capture=withContext(Dispatchers.IO) {
                // One coherent dashboard refresh: fetch the broad forecast + radar once,
                // then project the same provider payload through each canonical method.
                // This keeps panels temporally consistent and avoids four redundant
                // Open-Meteo requests with slightly different forecast horizons.
                val dashboardCapture = WeatherRuntime.capture(
                    As100WeatherDashboardMethod,
                    settings + ("horizon_hours" to "240")
                )
                val shared = dashboardCapture.settings
                val radarSettings = dashboardCapture.radarPayload?.let { radarPayload ->
                    shared + mapOf(
                        "provider" to radarPayload.provider,
                        "retrieved_time_iso" to radarPayload.retrievedTimeIso,
                        "from_cache" to radarPayload.fromCache.toString(),
                        "data_age_hours" to radarPayload.dataAgeHours?.toString().orEmpty(),
                        "api_error" to radarPayload.error
                    )
                } ?: shared
                mapOf(
                    "dashboard" to dashboardCapture.values,
                    "forecast" to As100WeatherForecastMethod.calculate(shared + ("horizon_hours" to "168")),
                    "precipitation" to As100WeatherPrecipitationMethod.calculate(shared + ("horizon_hours" to "24")),
                    "radar" to As100WeatherRadarMethod.calculate(radarSettings + ("zoom" to "6")),
                    "meteogram" to As100WeatherMeteogramMethod.calculate(shared + ("horizon_hours" to "72"))
                )
            }
            payloadJson=JSONObject().apply{capture.forEach{(k,v)->put(k,JSONObject(v))}}.toString()
            running=false; message="Live dashboard"; context.onSettingsChanged(settings)
            if(context.submitsImmediately) {
                val values=capture["dashboard"].orEmpty()
                val ex=As100WeatherDashboardMethod.result(
                    As100WeatherDashboardMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+settings,emptyList(),emptyList()),
                    values,context.request.invocationContext
                )
                onConfirmed(ex)
            }
        }
    }

    fun useGps() {
        if(!hasDashboardLocationPermission(app)) return
        running=true;message="Getting current location…"
        val token=CancellationTokenSource()
        LocationServices.getFusedLocationProviderClient(app).getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,token.token)
            .addOnSuccessListener { loc ->
                if(loc==null){running=false;message="Current GPS position unavailable."}
                else{latitude=loc.latitude.toString();longitude=loc.longitude.toString();running=false;runDashboard()}
            }
            .addOnFailureListener{running=false;message=it.message?:"Location failed."}
    }
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){
        if(hasDashboardLocationPermission(app))useGps() else {running=false;showLocation=true;message="Location denied. Enter coordinates below."}
    }
    fun locate(){if(hasDashboardLocationPermission(app))useGps() else permission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))}

    LaunchedEffect(Unit) {
        if(!attempted){attempted=true;if(latitude.toDoubleOrNull()!=null&&longitude.toDoubleOrNull()!=null)runDashboard()else locate()}
    }

    val dashboard=section("dashboard");val forecast=section("forecast");val precip=section("precipitation");val radar=section("radar");val meteogram=section("meteogram")

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal=18.dp,vertical=14.dp)) {
        Text("WEATHER",style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.primary)
        Text(if(latitude.isBlank())"Location required" else "${latitude.toDoubleOrNull()?.fmt(4)}, ${longitude.toDoubleOrNull()?.fmt(4)}",style=MaterialTheme.typography.bodyMedium)
        if(dashboard.isNotEmpty()) Text(
            "${if(dashboard["weather_dashboard_from_cache"]=="true")"Cached" else "Updated"} · ${dashboard["weather_dashboard_retrieved_time_iso"].orEmpty()}",
            style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            if (context.settingShouldBeShown("latitude") || context.settingShouldBeShown("longitude")) {
                OutlinedButton(onClick={showLocation=!showLocation},enabled=!running){Text(if(showLocation)"Hide" else "Location")}
                OutlinedButton(onClick={locate()},enabled=!running){Text("GPS")}
            }
            Button(onClick={runDashboard()},enabled=!running && latitude.toDoubleOrNull()!=null && longitude.toDoubleOrNull()!=null){Text("Refresh")}
        }
        if(showLocation && (context.settingShouldBeShown("latitude") || context.settingShouldBeShown("longitude"))) {
            Spacer(Modifier.height(10.dp))
            if(context.settingShouldBeShown("latitude")) OutlinedTextField(latitude,{latitude=it;payloadJson=""},label={Text("Latitude")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            Spacer(Modifier.height(6.dp))
            if(context.settingShouldBeShown("longitude")) OutlinedTextField(longitude,{longitude=it;payloadJson=""},label={Text("Longitude")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        }
        if(showLocation && context.settingShouldBeShown("threshold_mm_per_hour")) {
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(rainThreshold,{rainThreshold=it.take(8);payloadJson=""},label={Text("Meaningful rain threshold (mm/h)")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        }
        if(showLocation && context.settingShouldBeShown("offline_only")) {
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick={offlineOnly=!offlineOnly;payloadJson=""},modifier=Modifier.fillMaxWidth()) { Text(if(offlineOnly)"Cache only · on" else "Cache only · off") }
        }
        Spacer(Modifier.height(16.dp))

        if(running && dashboard.isEmpty()) {
            CircularProgressIndicator();Spacer(Modifier.height(8.dp));Text(message);Spacer(Modifier.height(420.dp))
        } else if(dashboard.isNotEmpty()) {
            CurrentHero(dashboard);Spacer(Modifier.height(10.dp));ImmediateStrip(dashboard);Spacer(Modifier.height(10.dp))

            DashboardCard("RAINFALL · NEXT 24H") {
                Text(precip["weather_precipitation_result"].orEmpty(),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                PrecipBars(dashboardPrecipPoints(precip["weather_precipitation_series_json"].orEmpty()),Modifier.fillMaxWidth().height(140.dp))
                precip["weather_precipitation_next_threshold_time_iso"]?.takeIf{it.isNotBlank()}?.let{CopyValue("Next meaningful rain",it)}
            }
            Spacer(Modifier.height(10.dp))

            DashboardCard("RADAR · HISTORY / NOWCAST") {
                RadarTimelinePanel(radar, Modifier.fillMaxWidth().height(320.dp))
                Spacer(Modifier.height(6.dp))
                Text("Observed history and any genuine provider-nowcast frames are radar. Model forecast precipitation is a separate product. Radar data: RainViewer.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))

            DashboardCard("HOURLY") {
                MiniLine(dashboardSeriesPoints(forecast["weather_forecast_series_json"].orEmpty(),"temperature_c"),Modifier.fillMaxWidth().height(130.dp))
                MetricGrid(listOf(
                    Triple("Selected",forecast["weather_forecast_selected_temperature_c"].orEmpty(),"°C"),
                    Triple("Rain",forecast["weather_forecast_selected_precipitation_mm"].orEmpty(),"mm"),
                    Triple("Rain chance",forecast["weather_forecast_selected_precipitation_probability_pct"].orEmpty(),"%"),
                    Triple("Wind",forecast["weather_forecast_selected_wind_speed_ms"].orEmpty(),"m/s")
                ))
            }
            Spacer(Modifier.height(10.dp))

            DashboardCard("NEXT DAYS") {
                DailyForecastStrip(forecast["weather_forecast_daily_series_json"].orEmpty())
            }
            Spacer(Modifier.height(10.dp))

            DashboardCard("METEOGRAM") {
                Text("Temperature",style=MaterialTheme.typography.labelMedium);MiniLine(dashboardSeriesPoints(meteogram["weather_meteogram_series_json"].orEmpty(),"temperature_c"),Modifier.fillMaxWidth().height(95.dp))
                Text("Pressure",style=MaterialTheme.typography.labelMedium);MiniLine(dashboardSeriesPoints(meteogram["weather_meteogram_series_json"].orEmpty(),"pressure_msl_hpa"),Modifier.fillMaxWidth().height(80.dp))
            }
            Spacer(Modifier.height(10.dp))

            DashboardCard("TODAY") {
                MetricGrid(listOf(
                    Triple("High",forecast["weather_forecast_daily_high_c"].orEmpty(),"°C"),
                    Triple("Low",forecast["weather_forecast_daily_low_c"].orEmpty(),"°C"),
                    Triple("Rain",forecast["weather_forecast_daily_precipitation_mm"].orEmpty(),"mm"),
                    Triple("Pressure",dashboard["weather_dashboard_pressure_msl_hpa"].orEmpty(),"hPa")
                ))
            }
            Spacer(Modifier.height(14.dp))
            Text("Provider queries use MethodMesh's declared online-data layer. Exact requested coordinates and rounded third-party query coordinates remain distinct in provenance.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            if(!context.submitsImmediately) {
                Spacer(Modifier.height(12.dp))
                Button(modifier=Modifier.fillMaxWidth(),onClick={
                    val ex=As100WeatherDashboardMethod.result(
                        As100WeatherDashboardMethod.request(
                            context.action.canonicalId,
                            context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings+
                                mapOf("latitude" to latitude,"longitude" to longitude,"threshold_mm_per_hour" to rainThreshold,"offline_only" to offlineOnly.toString()),
                            emptyList(),emptyList()
                        ),
                        dashboard,context.request.invocationContext
                    );onConfirmed(ex)
                }){Text("Commit dashboard snapshot")}
            }
        } else Text(message)

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            if(context.stepNumber>1)OutlinedButton(onClick=onBack){Text("Back")}
            OutlinedButton(onClick=onCancel){Text("Cancel")}
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun CurrentHero(v:Map<String,String>) {
    Card(modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(26.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(22.dp),horizontalArrangement=Arrangement.spacedBy(20.dp)) {
            val code=when(v["weather_dashboard_condition"]){"Clear"->0;"Mainly clear"->1;"Partly cloudy"->2;"Overcast"->3;"Rain"->61;"Rain showers"->80;"Thunderstorm"->95;else->2}
            WeatherGlyph(code,Modifier.width(100.dp).height(100.dp))
            Column {
                CopyValue("",v["weather_dashboard_temperature_c"].orEmpty()," °C",large=true)
                Text(v["weather_dashboard_condition"].orEmpty(),style=MaterialTheme.typography.titleLarge)
                Text(if(v["weather_dashboard_from_cache"]=="true")"CACHED WORKING RESULT" else "MODELLED CURRENT",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun ImmediateStrip(v:Map<String,String>) {
    DashboardCard("NOW") {
        MetricGrid(listOf(
            Triple("Rain",v["weather_dashboard_precipitation_mm"].orEmpty(),"mm"),
            Triple("Wind",v["weather_dashboard_wind_speed_ms"].orEmpty(),"m/s"),
            Triple("Pressure",v["weather_dashboard_pressure_msl_hpa"].orEmpty(),"hPa"),
            Triple("Radar frames",v["weather_dashboard_radar_frame_count"].orEmpty(),"")
        ))
        v["weather_dashboard_next_rain_time_iso"]?.takeIf{it.isNotBlank()}?.let{CopyValue("Next rain",it)}
    }
}

@Composable
private fun DashboardCard(label:String,content:@Composable ()->Unit) {
    Card(modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(defaultElevation=0.dp)) {
        Column(Modifier.padding(18.dp)) {Text(label,style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(8.dp));content()}
    }
}

private fun hasDashboardLocationPermission(context:android.content.Context):Boolean =
    ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED

private fun dashboardSeriesPoints(raw:String,key:String):List<Double> = runCatching {val a=JSONArray(raw);(0 until a.length()).mapNotNull{a.optJSONObject(it)?.optDouble(key,Double.NaN)?.takeIf(Double::isFinite)}}.getOrDefault(emptyList())
private fun dashboardPrecipPoints(raw:String):List<Double> = runCatching {
    val a=JSONArray(raw)
    (0 until a.length()).mapNotNull { index ->
        val o=a.optJSONObject(index) ?: return@mapNotNull null
        val v=if(o.has("precipitation_mm")) o.optDouble("precipitation_mm",Double.NaN) else o.optDouble("mm",Double.NaN)
        v.takeIf(Double::isFinite)
    }
}.getOrDefault(emptyList())
