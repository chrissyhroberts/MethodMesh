# Weather v0.1.0 validation record

**Review authority:** MethodMesh Master Book v1.08 FINAL, updated 2026-09-08.  
**Status:** Development module; `weather.atmosphere` and `weather.model_compare` are explicitly Experimental.

## Pass A — capability and architecture contract

- One self-contained module entry point: `WeatherModule`.
- Eleven independently callable canonical methods.
- Eleven matching native capability screens generated from the canonical method inventory.
- Eleven RIL bindings.
- Capability settings are module-owned.
- Every capability has explicit maturity and connectivity metadata through `WeatherMethodBase`.
- Dashboard is a canonical aggregation capability (`weather.dashboard`) rather than a dashboard-only bypass.
- No shared MethodMesh source file is required by this handoff.
- Weather provider logic uses generic MethodMesh online-data types and execution rather than a second ad-hoc HTTP architecture.
- `WeatherMethodBase.execute()` performs the same Weather runtime/provider resolution used by native capture, allowing supplied-input direct/headless execution.

## Pass B — output contract

Static contract audit over the final source found:

- 213 unique canonical Weather output fields across the 11 methods;
- no Weather UI reference to a capability return field absent from the declared output inventory;
- no declared non-status/non-error/non-audit output left without an explicit population path;
- no calculation output key outside the declared Weather output inventory;
- zero `TODO` / `FIXME` markers in the active Kotlin module.

The single `weather_code` string used inside chart/series JSON is an internal JSON member name, not a phantom MethodMesh return field.

## Pass C — interaction review

- Native tool/instrument view appears before advanced settings/result metadata.
- GPS and manual coordinates are available on the Weather dashboard itself.
- Individual capabilities retain their own native surfaces rather than becoming dashboard-only tools.
- Working result remains editable/refreshable until Commit.
- Commit returns the resolved canonical payload.
- External automatic-return origins return immediately once the canonical result is resolved.
- Displayed useful scalar/text values are tap-to-copy.
- Preset-fixed settings use `CapabilityScreenContext.settingShouldBeShown()`.
- Radar has a timeline scrubber across observed history and genuine provider-nowcast frames.
- On the canonical radar screen, choosing another frame re-runs resolution for that frame before Commit; displayed and returned frame time therefore agree.
- Dashboard includes current conditions, quantitative rainfall, radar, hourly trend, daily forecast strip and meteogram panels.
- Forecast precipitation is visibly distinguished from radar.

## Pass D — data/provenance review

- Open-Meteo coordinate disclosure uses MethodMesh `LocationDisclosureMode.ROUNDED` with a 5,000 m radius.
- Requested and disclosed/query coordinates are separate outputs/audit values.
- Open-Meteo provider-grid coordinates are separately returned where relevant.
- Cached results expose cache/freshness fields rather than masquerading as fresh data.
- Research snapshot distinguishes `REANALYSIS`, `HISTORICAL_FORECAST` and `FORECAST`.
- Historical/reanalysis values are not labelled station observations.
- RainViewer provider `past` frames map to `RADAR_OBSERVATION`.
- RainViewer provider `nowcast` maps to `NOWCAST` only if supplied.
- Radar geographic coverage is reported as `not_evaluated` rather than inferred merely from timeline availability.
- Ensemble spread is explicitly not described as a calibrated confidence interval.

## Pass E — Kotlin compile-oriented review

Current MethodMesh `master` interfaces were inspected directly before final packaging, including `MethodMeshModule`, `As100Method`, `MethodDescriptor`, `MethodContract`, `CapabilityScreenSpec`, `CapabilityScreenContext`, `MethodSetting`, online-data models/executor, Google Play Services location usage and the repository's MapLibre dependency.

All active Weather Kotlin sources were then compiled with `kotlinc` against a compile-oriented stub host modelling those current interfaces plus Android/Compose/GMS/MapLibre signatures. The full Weather-module type-check **passed** after resolving four real integration errors found by this stronger pass:

- a malformed dashboard Refresh callback;
- an inferred public `as100Methods()` return type that exposed the internal `WeatherMethodBase`;
- nullable `MethodDescriptor.description` assigned to non-null `CapabilityScreenSpec.description`;
- a missing `matchParentSize` import in the radar map.

Earlier static review also corrected a missing local `Double.fmt()` helper and an invalid regex escape. The final pass after narrow-screen UI hardening completed with exit status 0; remaining compiler output came only from intentionally minimal stub implementations.

Additional final hardening invalidates an old working result immediately when manual coordinates change, uses one broad dashboard meteorological fetch plus radar retrieval before projecting canonical dashboard/forecast/precipitation/meteogram views, and removes fixed-width header/metric layouts that could crowd narrow phones.

This is deliberately **not** represented as a successful `:app:compileDebugKotlin` or Android Gradle build. The complete Android repository/dependency graph was not available as a clonable local checkout in this packaging runtime, so the real host Gradle gates remain receiving-repository checks.

## Pass F — XLSForm structural audit

Eleven canonical v1.08 showcase workbooks were generated with `artifact_tool` and re-imported for verification.

For **every** workbook the audit found:

- exactly one MethodMesh `body::intent` invocation;
- expected canonical method ID;
- `input_payload_mode='FULL'`;
- `return_mode='flat'`;
- no `methodmesh_return_namespace`;
- all declared method-specific canonical output fields included;
- `methodmesh_status` included;
- `methodmesh_full_json` included;
- no duplicate survey node names;
- zero matched spreadsheet error tokens (`#REF!`, `#DIV/0!`, `#VALUE!`, `#NAME?`, `#N/A`).

`pyxform` is not installed in this packaging environment (`ModuleNotFoundError`), so pyxform/JavaRosa/ODK Validate and real provider upload checks are not claimed.

## Receiving-repository build and smoke checks

Before promotion beyond Development, run the host repository's normal gates, at minimum:

```text
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
./gradlew generateMethodMeshOdkTemplateAssets
```

Then exercise:

1. module auto-discovery/indexing;
2. native dashboard on a physical Android device;
3. GPS denial -> manual-coordinate fallback;
4. fresh and cache-only Open-Meteo execution;
5. requested/query coordinate separation;
6. RainViewer map loading, attribution and timeline scrubbing;
7. provider with zero nowcast frames;
8. direct/headless invocation of representative capabilities;
9. Preset and multi-step Protocol invocation;
10. ODK roundtrip using the canonical showcase workbooks;
11. rotation/process recreation and state preservation;
12. dark mode, large font and narrow-device layout.

## Known limitations / non-Production items

- The packaging environment could not perform a full repository Gradle build because it did not have a clonable host checkout/dependency graph.
- Shared online-data cache is disposable runtime cache, not a durable downloaded meteorological archive.
- `weather.atmosphere` depends on model-variable availability and remains Experimental.
- `weather.model_compare` exposes ensemble spread, not calibrated forecast probability/confidence.
- Radar availability/coverage is provider-dependent and not guaranteed globally.
- Weather alerts are not claimed in v0.1.0.
- No synthetic future radar is generated.
