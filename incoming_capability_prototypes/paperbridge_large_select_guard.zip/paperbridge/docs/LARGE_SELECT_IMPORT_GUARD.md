# Large select import guard

Paper Bridge deliberately excludes XLSForm select questions that are not practical paper OMR fields:

- `select_one` / `select_multiple` questions with `appearance` containing `image-map` are skipped.
- Any select list with more than 64 choices is skipped.

The XLSForm itself is not modified. The skipped question remains part of the source form; it is simply not imported into the Paper Bridge designer schema or passed into colour-template auto-matching.

This guard was added as a targeted regression/isolation change after a 75+ option image-map question was suspected of destabilising designer AUTO detection. No AUTO detection engine logic was changed in this patch.
