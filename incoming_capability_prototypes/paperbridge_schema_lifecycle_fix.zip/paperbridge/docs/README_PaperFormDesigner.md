# Paper Bridge visual designer — `paper.form.design`

The designer is the canonical authoring surface for paper templates. Study teams should not normally hand-edit `methodmesh.paper.v1` JSON.

## Fast path

1. Open **Paper Bridge → Design a form**.
2. Choose the blank questionnaire PDF/image.
3. Import the corresponding XLSForm.
4. Paper Bridge automatically detects printed response rectangles on the registered blank page and overlays them as numbered **UNLINKED** boxes.
5. Use **EDIT**, tap each detected box, choose the ODK field (and return option for `select_one` / `select_multiple`) and press **Link selected box to ODK**.
6. If necessary, drag a linked/detected box to move it or drag one of its four corner handles to resize it. **+ BOX** is a correction tool for unusual answer areas that are not printed as rectangles. **AUTO** re-runs rectangle detection.
7. Fix all red design errors, then use **TEST** with a completed page.
8. **SAVE**. The designer saves both the JSON definition and a marked-up PNG showing every linked bounding box and its ODK mapping.

The saved form is immediately available to `paper.form.transcribe` and becomes the active native Paper Bridge form.


## Automatic paper-box detection

The normal designer workflow does not require manually drawing every ROI. Once the blank PDF/image has been registered to the four target centres, `PaperBoxDetectionEngine` detects printed rectangular answer areas directly from that canonical canvas. It uses connected dark-component geometry plus four-edge/interior scoring, so ordinary text is rejected while empty checkbox/text-entry/barcode rectangles are retained. Registration-target remnants at the crop boundary are excluded.

Detected regions are sorted top-to-bottom/left-to-right and shown as `BOX 01 · UNLINKED`, `BOX 02 · UNLINKED`, etc. The detector deliberately does **not** infer semantics: the XLSForm supplies variable names, types, constraints and select values. The operator's normal task is therefore only to map paper boxes to ODK fields/options.

When editing an existing mapped template, nearby mapped ROIs are snapped to the newly detected printed rectangle without changing their ODK meaning. Remaining printed rectangles stay unlinked. This makes the physical printed box the geometry source of truth and repairs small coordinate drift. **AUTO** is available in the page sidebar to repeat detection; manual **+ BOX** remains available for signatures, free-form regions or non-rectangular paper designs.

## What XLSForm import provides

For compatible rows the designer imports:

- variable name and label;
- paper recognition type;
- required state;
- `select_one` / `select_multiple` choice values and labels;
- simple `regex(., '…')` constraints;
- simple numeric lower/upper bounds.

Compatible workbook types are `text`, `integer`, `decimal`, `select_one`, `select_multiple`, `barcode` and `image`. Other rows are skipped with a warning. The XLSForm remains authoritative for constraints that the designer cannot safely reduce.

## Error detection

Save is blocked for structural errors: missing registration targets, unlinked placed boxes, missing field/choice mappings, invalid or duplicate variable names, reserved `paper_`/`methodmesh_` names, out-of-page/inverted boxes, target-zone intrusion and substantial overlaps. Very small regions are warnings because they are likely to be fragile in real photographs.

Testing uses the actual Paper Bridge rectification + ML Kit/OMR extraction path; it is not a mock preview.

## Bundled fixture

The staged tutorial uses `example_colour_authoring_template.png` with `example_paperbridge_survey_choices.xlsx`, plus `example_blank_production_form.png` and `example_filled_production_form.png` for runtime tests. It covers all seven supported recognition families, including barcode decoding and image-ROI attachment return.

### Pan and zoom

The designer opens in a full-screen dialog and uses the same document-viewport discipline as MethodMesh Digital Signing: the page opens fitted at 1×, **NAV** exclusively owns drag-to-pan and pinch-to-zoom up to 48×, dedicated **+ / −** controls provide coarse zoom steps, and **FIT** restores the whole page. Tap-selection is active only in **EDIT**, so it cannot consume NAV pointer events. **AUTO** detects printed rectangles and **+ BOX** remains available for exceptions. Every box is stored in normalized page coordinates after inverting the active viewport transform, so geometry is invariant to zoom/pan. Linked boxes remain visible with `variable` or `variable = return_value` labels. A persistent left sidebar holds NAV / + BOX / EDIT / zoom / FIT. Tapping a box selects it independently of drag detection; if regions overlap, the smallest region under the tap wins. In **EDIT**, drag inside a box to move it and drag a corner handle to resize it. There is no redraw operation: unlink/delete is explicit.

### Full-screen split workspace

The designer is a fixed full-screen workspace rather than a vertically stacked capability page. After the slim header, the paper canvas receives two-thirds of the available height and the ODK data-linkage pane receives one-third. Only the lower linkage pane scrolls. This prevents page overlays, field cards and controls from occupying the same layout layer. Selecting a mapped box shows the ODK variable name, Paper Bridge type, required state, imported regex/range, or select-one/select-multiple return options directly in the lower pane.

## Built-in example

Paper Bridge ships with a staged, resettable tutorial schema rather than a pre-completed mapping. The canonical source files remain in this module's `docs/` directory:

- `example_paper_form_for_designer.pdf` — anchored blank paper questionnaire;
- `example_odk_showcase_paper_form_transcribe.xlsx` — matching XLSForm;
- `example_template_manifest.json` — generated Paper Bridge mapping;
- `example_paper_form_for_designer.png` — documentation preview.

The Android runtime does not assume `docs/` is an APK asset directory. Therefore the exact colour-authoring PNG and standard `survey`/`choices` workbook bytes are embedded in `PaperBridgeBuiltInExamples.kt` and materialised into app-private storage on first use. The example appears in the **Schema Library** automatically. Opening it in Designer loads both `example_colour_authoring_template.png` and `example_paperbridge_survey_choices.xlsx` but deliberately leaves response ROIs unresolved. The operator presses **AUTO DETECT**, sees proposed mappings and highlighted QUERY envelopes, corrects any ambiguous linkage, then follows the explicit lifecycle **SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE**. `TEST EMPTY` scans the monochrome blank production form; `TEST DATA` scans the filled production form. The built-in seed is immutable and can be reset/repeated without replacing the shipped fixture.


## Designer outputs

Saving `paper.form.design` creates durable app-private design artefacts and returns both of them to the caller:

- `paper_template_json` — the canonical JSON definition as text;
- `paper_template_json_uri` — a shareable URI for the saved `.paperbridge.json` file;
- `paper_design_markup_image` — a shareable PNG URI containing the blank page with every linked bounding box and mapping label burned into the image.

These are design/configuration artefacts only; they contain no completed questionnaire values.

## Registration targets

The four target **centres**, not the physical paper edges, define the designer coordinate frame. As soon as a blank PDF/image is loaded successfully, the designer crops its working canvas to the rectangle bounded by those four centres. All boxes are then stored as 0..1 coordinates inside that target-centre rectangle. Existing template dimensions are preserved when editing an established form; new forms use the cropped canvas dimensions.

This is deliberately identical to scan-time registration: ML Kit flattens the photographed sheet, Paper Bridge crops centre-to-centre, and that crop is resized to the template dimensions before field extraction.

The bundled example now uses bullseye-style registration targets (dark centre, light annulus, dark outer ring) rather than plain black dots. The detector scores this target structure explicitly while retaining compatibility with older solid-dot forms. This is intended to reduce accidental matches on ordinary corner content.

## Colour-assisted authoring

For new forms, prefer the fixed Paper Bridge colour syntax described in `README_Colour_Authoring.md`. The preferred solid colour panel expresses question type; black text is the question stem; blue text is select-option text; black inner rectangles are the eventual runtime ROIs. Paper Bridge uses OCR against the imported workbook labels to propose or complete mappings. Plain black-and-white box autodetection remains supported as a fallback.

The imported workbook is an ordinary `.xlsx` with XLSForm-style `survey` and `choices` sheets. It does not need to be deployed to ODK. ODK is one supported handoff target, not a prerequisite for authoring.

Saving now emits JSON, fixed-profile YAML, the canonical template image, the annotated mapping image, and a portable `.paperbridge.zip` backup.

### Designer interaction refinements

The canvas toolbox is a compact horizontal strip across the top of the paper workspace. NAV owns pan/pinch zoom; EDIT owns selection/move/resize; AUTO DETECT analyses the colour template or ordinary printed boxes; + BOX is a manual exception tool; FIT resets the viewport.

Overlay labels are rendered in the same page transform as their response boxes. They are never clamped to the viewport edge or collision-stacked independently, so panning/zooming keeps each label physically attached to its box.

The designer has a persistent lifecycle bar above the paper workspace: **SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE**. Saving persists the named schema without closing the editor. `TEST EMPTY` is enabled only for the current saved mapping; `TEST DATA` follows a passing blank-form test; `FINALISE` follows completion of both tests and returns the schema to the Schema Library. Editing the mapping after a save makes the current schema dirty again and therefore requires another save/retest. Blocking mapping errors are listed in Form Data Linkage. In the canonical `anchor_centres` frame there is no reserved interior corner-anchor exclusion zone: valid ROIs may sit close to the canvas edge as long as they remain within 0..1.

The built-in colour tutorial includes an IMAGE question (`Site sketch / drawing`) whose black ROI is inside its lime authoring envelope and whose question label is inside that same envelope, allowing AUTO DETECT to match it to the workbook `survey.label` like every other field type.
