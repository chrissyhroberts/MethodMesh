package com.example.methodmesh.modules.media

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.Instant
import java.util.Locale

/**
 * Publisher adapters deliberately use service credentials, never end-user media accounts.
 * TMDB availability is powered by JustWatch and requires visible JustWatch attribution.
 */
object MediaPublisherCredentials {
    private const val PREFS = "methodmesh_media_private"
    private const val KEY_TMDB = "tmdb_api_key"
    private const val KEY_WATCHMODE = "watchmode_api_key"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun tmdbKey(context: Context): String = prefs(context).getString(KEY_TMDB, "").orEmpty().trim()
    fun watchmodeKey(context: Context): String = prefs(context).getString(KEY_WATCHMODE, "").orEmpty().trim()
    fun saveTmdbKey(context: Context, value: String) = prefs(context).edit().putString(KEY_TMDB, value.trim()).apply()
    fun saveWatchmodeKey(context: Context, value: String) = prefs(context).edit().putString(KEY_WATCHMODE, value.trim()).apply()
    fun clearTmdbKey(context: Context) = prefs(context).edit().remove(KEY_TMDB).apply()
    fun clearWatchmodeKey(context: Context) = prefs(context).edit().remove(KEY_WATCHMODE).apply()
}

data class MediaPublisherService(val id: String, val name: String, val source: String)
data class MediaPublisherSyncSummary(val source: String, val services: Int, val inserted: Int, val total: Int, val verifiedAt: String)

object MediaCataloguePublishers {
    const val SOURCE_TMDB = "tmdb_justwatch"
    const val SOURCE_WATCHMODE = "watchmode"

    val popularGbServices = listOf(
        "Netflix", "Amazon Prime Video", "Disney Plus", "Apple TV Plus", "BBC iPlayer",
        "ITVX", "Channel 4", "My5", "NOW", "Paramount Plus", "Discovery Plus", "Crunchyroll",
        "MUBI", "BritBox", "BFI Player", "Sky Go"
    )

    fun tmdbServices(apiKey: String, region: String = "GB"): List<MediaPublisherService> {
        require(apiKey.isNotBlank()) { "TMDB API key is not configured." }
        val movie = tmdbGet("watch/providers/movie", apiKey, mapOf("watch_region" to region, "language" to "en-GB"))
        val tv = tmdbGet("watch/providers/tv", apiKey, mapOf("watch_region" to region, "language" to "en-GB"))
        val seen = linkedMapOf<String, MediaPublisherService>()
        listOf(movie, tv).forEach { root ->
            val arr = root.optJSONArray("results") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("provider_name").trim()
                if (name.isNotBlank()) seen[name.lowercase(Locale.ROOT)] = MediaPublisherService(o.optInt("provider_id").toString(), name, SOURCE_TMDB)
            }
        }
        return seen.values.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    fun syncTmdb(
        context: Context,
        apiKey: String,
        selectedServices: Set<String>,
        region: String = "GB",
        includeMovies: Boolean = true,
        includeSeries: Boolean = true,
        includeAds: Boolean = false,
        pagesPerService: Int = 3
    ): MediaPublisherSyncSummary {
        require(selectedServices.isNotEmpty()) { "Select at least one TV service." }
        val services = tmdbServices(apiKey, region).associateBy { it.name.lowercase(Locale.ROOT) }
        val repo = MediaCatalogueRepository(context)
        val now = Instant.now().toString()
        var inserted = 0
        selectedServices.forEach { requested ->
            val service = services[requested.lowercase(Locale.ROOT)] ?: return@forEach
            val rows = linkedMapOf<String, MediaCatalogueItem>()
            if (includeMovies) {
                fetchTmdbDiscover(apiKey, service, region, "movie", "flatrate", pagesPerService, now).forEach { rows[it.workId + "|" + it.accessType.wire] = it }
                if (includeAds) fetchTmdbDiscover(apiKey, service, region, "movie", "ads", pagesPerService, now).forEach { rows[it.workId + "|" + it.accessType.wire] = it }
            }
            if (includeSeries) {
                fetchTmdbDiscover(apiKey, service, region, "tv", "flatrate", pagesPerService, now).forEach { rows[it.workId + "|" + it.accessType.wire] = it }
                if (includeAds) fetchTmdbDiscover(apiKey, service, region, "tv", "ads", pagesPerService, now).forEach { rows[it.workId + "|" + it.accessType.wire] = it }
            }
            val summary = repo.replacePublisherItems(service.name, region, rows.values.toList(), "tmdb-justwatch:$now")
            inserted += summary.inserted
        }
        return MediaPublisherSyncSummary("TMDB · JustWatch", selectedServices.size, inserted, repo.countCatalogue(), now)
    }

    fun watchmodeServices(apiKey: String, region: String = "GB"): List<MediaPublisherService> {
        require(apiKey.isNotBlank()) { "Watchmode API key is not configured." }
        val root = watchmodeGet("sources", apiKey, mapOf("regions" to region, "types" to "sub,free"))
        val arr = when (root) {
            is JSONArray -> root
            is JSONObject -> root.optJSONArray("sources") ?: JSONArray()
            else -> JSONArray()
        }
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name").trim()
                if (name.isNotBlank()) add(MediaPublisherService(o.optInt("id").toString(), name, SOURCE_WATCHMODE))
            }
        }.distinctBy { it.name.lowercase(Locale.ROOT) }.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    fun syncWatchmode(
        context: Context,
        apiKey: String,
        selectedServices: Set<String>,
        region: String = "GB",
        includeMovies: Boolean = true,
        includeSeries: Boolean = true,
        pagesPerService: Int = 1
    ): MediaPublisherSyncSummary {
        require(selectedServices.isNotEmpty()) { "Select at least one TV service." }
        val services = watchmodeServices(apiKey, region).associateBy { it.name.lowercase(Locale.ROOT) }
        val repo = MediaCatalogueRepository(context)
        val now = Instant.now().toString()
        var inserted = 0
        selectedServices.forEach { requested ->
            val service = services[requested.lowercase(Locale.ROOT)] ?: return@forEach
            val rows = linkedMapOf<String, MediaCatalogueItem>()
            for (page in 1..pagesPerService.coerceIn(1, 10)) {
                val types = buildList { if (includeMovies) add("movie"); if (includeSeries) add("tv_series") }.joinToString(",")
                val root = watchmodeGet("list-titles", apiKey, mapOf(
                    "source_ids" to service.id, "source_types" to "sub,free", "regions" to region,
                    "types" to types, "sort_by" to "popularity_desc", "page" to page.toString(), "limit" to "250"
                )) as JSONObject
                val arr = root.optJSONArray("titles") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val title = o.optString("title").trim(); if (title.isBlank()) continue
                    val year = o.optInt("year").takeIf { it > 0 }
                    val wmId = o.optInt("id")
                    val type = if (o.optString("type").contains("tv")) "series" else "movie"
                    val externalId = "watchmode:$wmId"
                    val workId = MediaIds.stableWorkId(title, year, externalId)
                    rows[workId] = MediaCatalogueItem(
                        workId, title, type, year, "", "", "", null, service.name, region,
                        MediaAccessType.SubscriptionIncluded, false, null, "", externalId,
                        "https://api.watchmode.com/v1/title/$wmId/details/", "", "", now
                    )
                }
                if (arr.length() < 250) break
            }
            val summary = repo.replacePublisherItems(service.name, region, rows.values.toList(), "watchmode:$now")
            inserted += summary.inserted
        }
        return MediaPublisherSyncSummary("Watchmode", selectedServices.size, inserted, repo.countCatalogue(), now)
    }

    private fun fetchTmdbDiscover(
        apiKey: String, service: MediaPublisherService, region: String, kind: String,
        monetization: String, pages: Int, verifiedAt: String
    ): List<MediaCatalogueItem> = buildList {
        val access = if (monetization == "ads") MediaAccessType.FreeWithAds else MediaAccessType.SubscriptionIncluded
        for (page in 1..pages.coerceIn(1, 25)) {
            val root = tmdbGet("discover/$kind", apiKey, mapOf(
                "watch_region" to region, "with_watch_providers" to service.id,
                "with_watch_monetization_types" to monetization, "sort_by" to "popularity.desc",
                "include_adult" to "false", "language" to "en-GB", "page" to page.toString()
            ))
            val arr = root.optJSONArray("results") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = if (kind == "movie") o.optString("title") else o.optString("name")
                if (title.isBlank()) continue
                val date = if (kind == "movie") o.optString("release_date") else o.optString("first_air_date")
                val year = date.take(4).toIntOrNull()
                val tmdbId = o.optInt("id")
                val externalId = "tmdb:$kind:$tmdbId"
                val type = if (kind == "movie") "movie" else "series"
                val workId = MediaIds.stableWorkId(title, year, externalId)
                add(MediaCatalogueItem(
                    workId, title, type, year, "", "", o.optString("original_language"), null,
                    service.name, region, access, false, null, "", externalId,
                    "https://www.themoviedb.org/${if (kind == "tv") "tv" else "movie"}/$tmdbId/watch", "", "", verifiedAt
                ))
            }
            if (arr.length() < 20) break
        }
    }

    private fun tmdbGet(path: String, apiKey: String, params: Map<String, String>): JSONObject {
        val all = linkedMapOf("api_key" to apiKey).apply { putAll(params) }
        val body = httpGet("https://api.themoviedb.org/3/$path", all, emptyMap())
        return JSONObject(body)
    }

    private fun watchmodeGet(path: String, apiKey: String, params: Map<String, String>): Any {
        val body = httpGet("https://api.watchmode.com/v1/$path/", params, mapOf("X-API-Key" to apiKey))
        val trimmed = body.trim()
        return if (trimmed.startsWith("[")) JSONArray(trimmed) else JSONObject(trimmed)
    }

    private fun httpGet(base: String, params: Map<String, String>, headers: Map<String, String>): String {
        val query = params.filterValues { it.isNotBlank() }.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        val connection = (URL(if (query.isBlank()) base else "$base?$query").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 15_000; readTimeout = 30_000
            setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            val code = connection.responseCode
            val body = (if (code in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) error("Catalogue publisher returned HTTP $code${body.take(180).takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()}")
            return body
        } finally { connection.disconnect() }
    }
}
