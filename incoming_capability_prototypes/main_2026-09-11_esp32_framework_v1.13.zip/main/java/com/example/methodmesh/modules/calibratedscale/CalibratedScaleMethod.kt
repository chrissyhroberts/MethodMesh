package com.example.methodmesh.modules.calibratedscale

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.methodmesh.calibration.CalibrationRepository
import com.example.methodmesh.settings.MethodSetting
import com.example.methodmesh.settings.SettingsState
import java.util.Locale
import kotlin.math.abs

class CalibratedScaleInteraction {

    val settings = listOf(
        MethodSetting.FloatSetting(
            id = "vas_length_mm",
            label = "VAS length",
            group = "Appearance",
            defaultValue = 100f,
            minimum = 40f,
            maximum = 200f,
            step = 0.5f,
            unit = "mm",
            decimals = 1
        ),
        MethodSetting.BooleanSetting(
            id = "vertical_mode",
            label = "Vertical mode",
            group = "Appearance",
            defaultValue = false
        ),
        MethodSetting.TextSetting(
            id = "prompt",
            label = "Prompt",
            group = "Scale",
            defaultValue = "Rate your pain"
        ),
        MethodSetting.TextSetting(
            id = "hint",
            label = "Hint",
            group = "Scale",
            defaultValue = ""
        ),
        MethodSetting.FloatSetting(
            id = "minimum",
            label = "Minimum value",
            group = "Scale",
            defaultValue = 0f,
            minimum = 0f,
            maximum = 100f,
            step = 1f,
            decimals = 0
        ),
        MethodSetting.FloatSetting(
            id = "maximum",
            label = "Maximum value",
            group = "Scale",
            defaultValue = 100f,
            minimum = 0f,
            maximum = 100f,
            step = 1f,
            decimals = 0
        ),
        MethodSetting.BooleanSetting(
            id = "use_range",
            label = "Use two scales",
            group = "Range",
            defaultValue = false
        ),
        MethodSetting.TextSetting(
            id = "lower_label",
            label = "Lower scale label",
            group = "Range",
            defaultValue = "Minimum selected value"
        ),
        MethodSetting.TextSetting(
            id = "upper_label",
            label = "Upper scale label",
            group = "Range",
            defaultValue = "Maximum selected value"
        ),
        MethodSetting.FloatSetting(
            id = "value",
            label = "Current value",
            group = "Display",
            defaultValue = 50f,
            minimum = 0f,
            maximum = 100f,
            step = 1f,
            decimals = 0
        ),
        MethodSetting.FloatSetting(
            id = "lower_value",
            label = "Lower selected value",
            group = "Display",
            defaultValue = 25f,
            minimum = 0f,
            maximum = 100f,
            step = 1f,
            decimals = 0
        ),
        MethodSetting.FloatSetting(
            id = "upper_value",
            label = "Upper selected value",
            group = "Display",
            defaultValue = 75f,
            minimum = 0f,
            maximum = 100f,
            step = 1f,
            decimals = 0
        ),
        MethodSetting.BooleanSetting(
            id = "show_endpoint_labels",
            label = "Show endpoint labels",
            group = "Display",
            defaultValue = true
        ),
        MethodSetting.BooleanSetting(
            id = "show_current_score",
            label = "Show current value",
            group = "Display",
            defaultValue = true
        )
    )

@Composable
    fun Render(
        settingsState: SettingsState,
        onValueChanged: (String) -> Unit
    ) {
        val minimum = settingsState.getFloat("minimum")
        val maximum = settingsState.getFloat("maximum").let {
            if (it > minimum) it else minimum + 1f
        }
        val useRange = settingsState.getBoolean("use_range")
        val vasLengthMm = settingsState.getFloat("vas_length_mm").coerceIn(40f, 200f)
        val calibration by CalibrationRepository.calibration
        val desiredLength = scaleLengthDp(vasLengthMm, calibration.dpPerMm).dp
        val showEndpointLabels = settingsState.getBoolean("show_endpoint_labels")
        val showCurrentValue = settingsState.getBoolean("show_current_score")
        val verticalMode = settingsState.getBoolean("vertical_mode")

        normaliseRangeValues(settingsState, minimum, maximum)

        Column(modifier = Modifier.fillMaxWidth()) {
            Text(settingsState.getString("prompt"))
            settingsState.getString("hint").takeIf(String::isNotBlank)?.let { hint ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = hint,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (useRange) {
                if (verticalMode) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = desiredLength + 170.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Top
                    ) {
                        ScaleInput(
                            label = settingsState.getString("lower_label"),
                            valueId = "lower_value",
                            settingsState = settingsState,
                            scaleMinimum = minimum,
                            scaleMaximum = maximum,
                            desiredLength = desiredLength,
                            showEndpointLabels = showEndpointLabels,
                            showCurrentValue = showCurrentValue,
                            vertical = true,
                            onValueChange = { proposed ->
                                val upper = settingsState.getFloat("upper_value")
                                settingsState.setFloat("lower_value", proposed.coerceIn(minimum, upper))
                                onValueChanged("lower_value")
                            }
                        )

                        ScaleInput(
                            label = settingsState.getString("upper_label"),
                            valueId = "upper_value",
                            settingsState = settingsState,
                            scaleMinimum = minimum,
                            scaleMaximum = maximum,
                            desiredLength = desiredLength,
                            showEndpointLabels = showEndpointLabels,
                            showCurrentValue = showCurrentValue,
                            vertical = true,
                            onValueChange = { proposed ->
                                val lower = settingsState.getFloat("lower_value")
                                settingsState.setFloat("upper_value", proposed.coerceIn(lower, maximum))
                                onValueChanged("upper_value")
                            }
                        )
                    }
                } else {
                    Column {
                        ScaleInput(
                            label = settingsState.getString("lower_label"),
                            valueId = "lower_value",
                            settingsState = settingsState,
                            scaleMinimum = minimum,
                            scaleMaximum = maximum,
                            desiredLength = desiredLength,
                            showEndpointLabels = showEndpointLabels,
                            showCurrentValue = showCurrentValue,
                            vertical = false,
                            onValueChange = { proposed ->
                                val upper = settingsState.getFloat("upper_value")
                                settingsState.setFloat("lower_value", proposed.coerceIn(minimum, upper))
                                onValueChanged("lower_value")
                            }
                        )

                        ScaleInput(
                            label = settingsState.getString("upper_label"),
                            valueId = "upper_value",
                            settingsState = settingsState,
                            scaleMinimum = minimum,
                            scaleMaximum = maximum,
                            desiredLength = desiredLength,
                            showEndpointLabels = showEndpointLabels,
                            showCurrentValue = showCurrentValue,
                            vertical = false,
                            onValueChange = { proposed ->
                                val lower = settingsState.getFloat("lower_value")
                                settingsState.setFloat("upper_value", proposed.coerceIn(lower, maximum))
                                onValueChanged("upper_value")
                            }
                        )
                    }
                }
            } else {
                ScaleInput(
                    label = "Current value",
                    valueId = "value",
                    settingsState = settingsState,
                    scaleMinimum = minimum,
                    scaleMaximum = maximum,
                    desiredLength = desiredLength,
                    showEndpointLabels = showEndpointLabels,
                    showCurrentValue = showCurrentValue,
                    vertical = verticalMode,
                    onValueChange = { proposed ->
                        settingsState.setFloat("value", proposed.coerceIn(minimum, maximum))
                        onValueChanged("value")
                    }
                )
            }
        }
    }

    private fun normaliseRangeValues(
        settingsState: SettingsState,
        minimum: Float,
        maximum: Float
    ) {
        val lower = settingsState.getFloat("lower_value").coerceIn(minimum, maximum)
        val upper = settingsState.getFloat("upper_value").coerceIn(minimum, maximum)

        if (lower > upper) {
            settingsState.setFloat("lower_value", upper)
            settingsState.setFloat("upper_value", lower)
        } else {
            settingsState.setFloat("lower_value", lower)
            settingsState.setFloat("upper_value", upper)
        }
    }

    @Composable
    private fun ScaleInput(
        label: String,
        valueId: String,
        settingsState: SettingsState,
        scaleMinimum: Float,
        scaleMaximum: Float,
        desiredLength: Dp,
        showEndpointLabels: Boolean,
        showCurrentValue: Boolean,
        vertical: Boolean,
        onValueChange: (Float) -> Unit
    ) {
        val current = settingsState.getFloat(valueId).coerceIn(scaleMinimum, scaleMaximum)

        if (vertical) {
            Box(
                modifier = Modifier
                    .width(150.dp)
                    .height(desiredLength + 170.dp)
                    .padding(8.dp)
            ) {
                ScaleContent(
                    label = label,
                    current = current,
                    scaleMinimum = scaleMinimum,
                    scaleMaximum = scaleMaximum,
                    desiredLength = desiredLength,
                    showEndpointLabels = showEndpointLabels,
                    showCurrentValue = showCurrentValue,
                    vertical = true,
                    onValueChange = onValueChange
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 8.dp)
            ) {
                ScaleContent(
                    label = label,
                    current = current,
                    scaleMinimum = scaleMinimum,
                    scaleMaximum = scaleMaximum,
                    desiredLength = desiredLength,
                    showEndpointLabels = showEndpointLabels,
                    showCurrentValue = showCurrentValue,
                    vertical = false,
                    onValueChange = onValueChange
                )
            }
        }
    }

    @Composable
    private fun ScaleContent(
        label: String,
        current: Float,
        scaleMinimum: Float,
        scaleMaximum: Float,
        desiredLength: Dp,
        showEndpointLabels: Boolean,
        showCurrentValue: Boolean,
        vertical: Boolean,
        onValueChange: (Float) -> Unit
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = if (vertical) {
                Modifier.width(150.dp)
            } else {
                Modifier.width(desiredLength)
            }
        ) {
                Column(
                    modifier = Modifier
                        .height(84.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = label,
                        textAlign = TextAlign.Center,
                        maxLines = 3
                    )

                    if (showCurrentValue) {
                        Text(
                            text = formatScaleCurrentValue(current, scaleMinimum, scaleMaximum),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                if (vertical) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (showEndpointLabels) {
                            Column(
                                modifier = Modifier
                                    .height(desiredLength)
                                    .width(36.dp),
                                verticalArrangement = Arrangement.SpaceBetween,
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(scaleMaximum.toInt().toString())
                                Text(scaleMinimum.toInt().toString())
                            }

                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        CanvasScale(
                            value = current,
                            minimum = scaleMinimum,
                            maximum = scaleMaximum,
                            length = desiredLength,
                            vertical = true,
                            onValueChange = onValueChange
                        )
                    }
                } else {
                    CanvasScale(
                        value = current,
                        minimum = scaleMinimum,
                        maximum = scaleMaximum,
                        length = desiredLength,
                        vertical = false,
                        onValueChange = onValueChange
                    )

                    if (showEndpointLabels) {
                        Row(
                            modifier = Modifier
                                .width(desiredLength)
                                .height(24.dp)
                        ) {
                            Text(scaleMinimum.toInt().toString())
                            Spacer(modifier = Modifier.weight(1f))
                            Text(scaleMaximum.toInt().toString())
                        }
                    }
                }
        }
    }

    @Composable
    private fun CanvasScale(
        value: Float,
        minimum: Float,
        maximum: Float,
        length: Dp,
        vertical: Boolean,
        onValueChange: (Float) -> Unit
    ) {
        val modifier = if (vertical) {
            Modifier
                .width(56.dp)
                .height(length)
        } else {
            Modifier
                .width(length)
                .height(56.dp)
        }

        Box(
            modifier = modifier.pointerInput(minimum, maximum, vertical) {
                detectDragGestures(
                    onDragStart = { offset ->
                        onValueChange(
                            if (vertical) {
                                valueFromY(offset.y, size.height.toFloat(), minimum, maximum)
                            } else {
                                valueFromX(offset.x, size.width.toFloat(), minimum, maximum)
                            }
                        )
                    },
                    onDrag = { change, _ ->
                        onValueChange(
                            if (vertical) {
                                valueFromY(change.position.y, size.height.toFloat(), minimum, maximum)
                            } else {
                                valueFromX(change.position.x, size.width.toFloat(), minimum, maximum)
                            }
                        )
                    }
                )
            }
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val proportion = if (maximum > minimum) {
                    (value - minimum) / (maximum - minimum)
                } else {
                    0f
                }.coerceIn(0f, 1f)

                if (vertical) {
                    val x = size.width / 2f
                    val top = 0f
                    val bottom = size.height
                    val y = bottom - (bottom - top) * proportion

                    drawLine(
                        color = Color.Black,
                        start = Offset(x, top),
                        end = Offset(x, bottom),
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Square
                    )

                    drawCircle(
                        color = Color.Black,
                        radius = 10.dp.toPx(),
                        center = Offset(x, y)
                    )
                } else {
                    val y = size.height / 2f
                    val start = 0f
                    val end = size.width
                    val x = start + (end - start) * proportion

                    drawLine(
                        color = Color.Black,
                        start = Offset(start, y),
                        end = Offset(end, y),
                        strokeWidth = 4.dp.toPx(),
                        cap = StrokeCap.Square
                    )

                    drawCircle(
                        color = Color.Black,
                        radius = 10.dp.toPx(),
                        center = Offset(x, y)
                    )
                }
            }
        }
    }

    private fun valueFromX(
        x: Float,
        width: Float,
        minimum: Float,
        maximum: Float
    ): Float {
        val proportion = (x / width).coerceIn(0f, 1f)
        return minimum + proportion * (maximum - minimum)
    }

    private fun valueFromY(
        y: Float,
        height: Float,
        minimum: Float,
        maximum: Float
    ): Float {
        val proportion = (1f - (y / height)).coerceIn(0f, 1f)
        return minimum + proportion * (maximum - minimum)
    }


}

internal fun formatScaleCurrentValue(
    value: Float,
    minimum: Float,
    maximum: Float
): String {
    val decimals = if (abs(maximum - minimum) <= 1f) 2 else 1
    return String.format(Locale.ROOT, "%.${decimals}f", value)
}

internal fun scaleLengthDp(lengthMm: Float, dpPerMm: Float): Float =
    lengthMm.coerceAtLeast(0f) * dpPerMm.coerceAtLeast(0f)
