# Text documents v0.09

Standalone-toolkit and external-document revision over v0.08.

- Direct Capabilities/dashboard launch is now a document toolkit, not a Commit transaction.
- The capability requests the generic immersive host, so the module owns one bounded full-screen workspace and no longer inherits the Standard host's scroll/chrome.
- Open/New goes straight to the editor; Library returns to the toolkit home.
- Save is visible; Save As / Save a copy, Share, Copy all, Find/replace and Markdown Preview/Edit are available in the editor.
- Share always uses the current working buffer, including unsaved edits, and sends a typed temporary file plus text.
- Saved/unsaved state is explicit and is cleared only after confirmed write success.
- Save from the unsaved-changes dialog closes only after the write succeeds.
- External Android file opens use the same surface and are added to recent-file metadata.
- Writable URI detection no longer assumes every Storage Access Framework open is writable.
- JSON detection now recognises `application/json` and `text/json`; JSONL recognises `.jsonl`, `.ndjson`, `application/x-ndjson`, `application/ndjson` and `application/jsonl`.
- Preset/protocol/ODK/module-to-module origins get a small `Use document` action on the same editor; normal toolkit users do not see Commit controls.
- JSON/JSONL remain lossless text: no automatic formatting or reserialisation.
- ODK showcase reviewed; source text is optional so the same form can demonstrate caller-supplied or interactive editing.

Shared Android integration requirement: the host manifest must advertise `DocumentActivity` for the JSON/JSONL MIME types. That central file is deliberately not copied into the canonical module folder.
