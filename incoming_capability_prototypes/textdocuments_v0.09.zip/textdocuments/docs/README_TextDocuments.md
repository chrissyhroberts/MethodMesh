# Text documents

**Module:** `textdocuments`  
**Release:** v0.09  
**Capability:** `document.text.open`  
**Maturity:** **Development**  
**Connectivity:** **Offline**  
**Icon:** `document`

Text documents is MethodMesh's small local document toolkit for plain text, Markdown, JSON and JSON Lines. It creates, opens, edits, finds/replaces, saves, copies and shares documents without silently rewriting their contents.

Supported filename forms are `.txt`, `.md`, `.markdown`, `.json`, `.jsonl` and `.ndjson`.

## Interaction model

Normal launch from **Capabilities** is a standalone toolkit, not a capability transaction. The first screen is a small document library with **New**, **Open file**, **New from clipboard** and recent files. Opening or creating a file goes directly into the editor. There is no generic Commit/results window.

The editor is content-first and full-screen. It provides:

- visible Save / Save As behaviour;
- Share of the **current working buffer**, including unsaved edits;
- Copy all;
- Find / replace;
- Markdown Preview / Edit source;
- recent-file metadata without silently archiving document contents;
- unsaved-change protection on Library/Close/Back;
- keyboard/IME-safe controls;
- line/character count and clear saved/unsaved state.

When launched by a preset, protocol, ODK or another capability, the same editor is used. The only extra control is **Use document**, which returns the current buffer to the caller. MethodMesh Commit semantics remain the transport boundary, but are not presented to a normal toolkit user as a separate Commit screen.

Android `VIEW` / `EDIT` launches use the same editor and return to the originating app on Close/Back.

## Canonical capability

`document.text.open` remains the single canonical contract for direct use, presets, protocols and ODK/XLSForm roundtrips. Android file opening through `DocumentActivity` is an additional launch origin, not a second MethodMesh capability.

### Inputs

| Key | Type | Required | Meaning |
|---|---|---:|---|
| `document_text` | text | no | Caller-supplied text. If absent, interactive callers can create/open a document. |
| `document_title` | text | no | Suggested human-facing filename/title. |
| `document_format` | choice | no | `text`, `markdown`, `json`, `jsonl`. |

### Outputs

| Key | Type | Meaning |
|---|---|---|
| `document_status` | text | `succeeded` or `failed`. |
| `document_text` | text | Text returned when the caller chooses **Use document**. |
| `document_title` | text | Human-facing title at return. |
| `document_format` | text | `text`, `markdown`, `json`, or `jsonl`. |
| `document_error` | text | Failure diagnostic; blank on success. |

Shared transport adds `methodmesh_status` and, for the ODK/FULL projection, `methodmesh_full_json`.

## File semantics

**Save** writes back to the selected URI when write access exists. Otherwise the UI uses **Save As…**. **Save a copy…** is always available for an already-writable document.

JSON and JSON Lines are deliberately lossless text surfaces. Opening, saving or sharing does not pretty-print, minify, sort keys, parse/re-emit or otherwise rewrite the body.

**Share** materialises the current buffer as a temporary typed file through the existing MethodMesh `FileProvider` and supplies the same text to `Intent.EXTRA_TEXT`. The share operation therefore reflects unsaved edits rather than accidentally sharing a stale on-disk version. Share-cache files are disposable and old entries are pruned.

Recent files store URI/title/MIME metadata only. Opening a file from another Android app also adds it to the recent list when access is retained.

## Android external-open integration

The module accepts the following types internally:

- `text/plain`
- `text/markdown`
- `application/json`
- `text/json`
- `application/x-ndjson`
- `application/ndjson`
- `application/jsonl`

Android resolver visibility is controlled by the app manifest, which is shared integration outside the canonical module folder. The host `DocumentActivity` intent filter must advertise the same MIME set. v0.09 is delivered with a complete replacement manifest separately from the module ZIP; the module tree itself remains Master-Book compliant and contains no copied shared app files.

# ODK INTEGRATION

## Capability

Text documents  
`document.text.open`

## Tags

Maturity: **Development**  
Connectivity: **Offline**

## ODK INPUTS

| Canonical input | ODK type | Required | Meaning |
|---|---|---:|---|
| `document_text` | text | optional | Source text supplied by the form; blank permits interactive acquisition. |
| `document_title` | text | optional | Suggested title/filename. |
| `document_format` | select/text | optional | `text`, `markdown`, `json`, `jsonl`. |

## INTENT CALL

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='document.text.open',input_document_text=${source_text},input_document_title=${source_title},input_document_format=${source_format},input_payload_mode='FULL',return_mode='flat')
```

## CANONICAL RETURNS

| Canonical return | ODK type | Presence | Meaning |
|---|---|---|---|
| `methodmesh_status` | text | always | Shared MethodMesh execution status. |
| `document_status` | text | always | Capability status. |
| `document_text` | text | success | Returned edited text. |
| `document_title` | text | always | Returned title. |
| `document_format` | text | always | Returned format. |
| `document_error` | text | failure/blank on success | Failure diagnostic. |
| `methodmesh_full_json` | text/JSON | always on handled ODK roundtrip | Shared metadata/audit payload. |

Canonical showcase: `example_odk_showcase_document_text_open.xlsx`. It contains one MethodMesh invocation, uses canonical unprefixed return keys and does not require `methodmesh_return_namespace`.

The non-interactive method succeeds only when `document_text` is supplied. Without text it fails clearly rather than pretending that an unattended edit occurred.

## Privacy and dependencies

Core editing is offline. No online provider receives document contents. Storage is through Android content URIs chosen or supplied by the user. The module uses existing Android/Compose, FileProvider and Markwon dependencies; it introduces no new dependency.

## Validation status

v0.09 was reviewed against MethodMesh Master Book v1.22 and the supplied current `app/src/main` interfaces. The review specifically removed the dashboard Commit/result detour, adopted the generic `CapabilityHostPresentation.Immersive` contract, preserved one canonical method across launch origins, and checked the ODK showcase structure. A complete Gradle project is not present in this runtime, so `:app:compileDebugKotlin` / `:app:assembleDebug` could not be executed here. Promotion remains **Development** until local build and representative device/ODK validation pass.
