package com.example.methodmesh.modules.textdocuments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class DocumentFormat(val contractValue: String, val label: String, val extension: String, val mimeType: String) {
    TEXT("text", "Plain text", "txt", "text/plain"),
    MARKDOWN("markdown", "Markdown", "md", "text/markdown"),
    JSON("json", "JSON", "json", "application/json"),
    JSONL("jsonl", "JSON Lines", "jsonl", "application/x-ndjson");

    companion object {
        fun fromContract(value: String?): DocumentFormat = when (value?.trim()?.lowercase()) {
            "markdown", "md" -> MARKDOWN
            "json" -> JSON
            "jsonl", "ndjson" -> JSONL
            else -> TEXT
        }

        fun detect(name: String, mime: String?): DocumentFormat = when {
            mime.equals("text/markdown", true) || name.endsWith(".md", true) || name.endsWith(".markdown", true) -> MARKDOWN
            mime.equals("application/json", true) || mime.equals("text/json", true) || name.endsWith(".json", true) -> JSON
            mime.equals("application/x-ndjson", true) || mime.equals("application/ndjson", true) ||
                mime.equals("application/jsonl", true) || name.endsWith(".jsonl", true) || name.endsWith(".ndjson", true) -> JSONL
            else -> TEXT
        }
    }
}

data class DocumentBuffer(
    val uri: Uri?,
    val title: String,
    val format: DocumentFormat,
    val text: String,
    val writable: Boolean
)

object DocumentIo {
    suspend fun read(context: Context, uri: Uri, mime: String? = null): Result<DocumentBuffer> = withContext(Dispatchers.IO) {
        runCatching {
            val title = displayName(context, uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Document"
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: error("The document provider did not supply a readable stream.")
            val writable = runCatching {
                context.contentResolver.openAssetFileDescriptor(uri, "rw")?.use { true } ?: false
            }.getOrDefault(false)
            DocumentBuffer(uri, title, DocumentFormat.detect(title, mime ?: context.contentResolver.getType(uri)), text, writable)
        }
    }

    suspend fun write(context: Context, uri: Uri, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(text) }
                ?: error("The document provider did not supply a writable stream.")
        }
    }

    fun displayName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()

    fun retainAccess(context: Context, uri: Uri, flags: Int) {
        val persistable = flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        if (persistable != 0) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, persistable) }
        }
    }

    fun createIntent(format: DocumentFormat, suggestedTitle: String): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = format.mimeType
            putExtra(Intent.EXTRA_TITLE, ensureExtension(suggestedTitle, format))
        }

    fun ensureExtension(title: String, format: DocumentFormat): String {
        val clean = title.trim().ifBlank { "document.${format.extension}" }
        return if (clean.substringAfterLast('.', "").equals(format.extension, true) ||
            (format == DocumentFormat.MARKDOWN && clean.endsWith(".markdown", true)) ||
            (format == DocumentFormat.JSONL && clean.endsWith(".ndjson", true))) clean
        else "$clean.${format.extension}"
    }
}
