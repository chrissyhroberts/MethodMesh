package com.example.methodmesh.modules.espmesh

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startForegroundService
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

object EspMeshGatewayCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100EspMeshGatewayMethod.ID
    override val title = "ESP mesh gateway"
    override val description = "Discover and provision a nearby MethodMesh BLE gateway."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val app = LocalContext.current.applicationContext
        val provider = remember { EspMeshTransportProvider.get(app) }
        val status by provider.status.collectAsState()
        val gatewayInfo by provider.gatewayInfo.collectAsState()
        val provisioningState by provider.provisioningState.collectAsState()
        val candidates = remember { mutableStateListOf<EspMeshGatewayCandidate>() }
        var scanning by rememberSaveable { mutableStateOf(false) }
        var selectedAddress by rememberSaveable { mutableStateOf("") }
        var networkId by rememberSaveable { mutableStateOf("") }
        var networkKey by rememberSaveable { mutableStateOf("") }
        var provisioningToken by rememberSaveable { mutableStateOf("") }
        var configStatus by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (it.values.all { granted -> granted }) {
                candidates.clear()
                scanning = true
                provider.scan(
                    { candidate -> if (candidates.none { existing -> existing.address == candidate.address }) candidates += candidate },
                    { scanning = false }
                )
            }
        }

        fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

        fun scan() {
            val missing = requiredPermissions().filter { ContextCompat.checkSelfPermission(app, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
            else {
                candidates.clear()
                scanning = true
                provider.scan(
                    { candidate -> if (candidates.none { existing -> existing.address == candidate.address }) candidates += candidate },
                    { scanning = false }
                )
            }
        }

        fun select(candidate: EspMeshGatewayCandidate) {
            selectedAddress = candidate.address
            result = null
            configStatus = "Connecting and verifying gateway protocol…"
            provider.selectGateway(candidate)
        }

        fun commitProvisioned() {
            if (result != null) return
            startForegroundService(app, Intent(app, EspMeshGatewayService::class.java))
            val request = As100EspMeshGatewayMethod.request(capabilityId, emptyMap(), emptyList(), emptyList())
            val execution = As100EspMeshGatewayMethod.execute(request, null, "espmesh")
            result = execution
            if (context.submitsImmediately) onConfirmed(execution)
        }

        LaunchedEffect(provisioningState) {
            when (val state = provisioningState) {
                EspMeshProvisioningState.Idle -> Unit
                is EspMeshProvisioningState.AwaitingAck -> configStatus = "Network settings sent. Waiting for ${gatewayInfo.nodeId.ifBlank { "gateway" }} to confirm…"
                is EspMeshProvisioningState.Confirmed -> {
                    configStatus = "Provisioned and confirmed on network ${state.networkId}."
                    commitProvisioned()
                }
                is EspMeshProvisioningState.Failed -> configStatus = "Provisioning failed: ${state.reason}"
            }
        }

        LaunchedEffect(context.startsImmediately) {
            if (context.startsImmediately) scan()
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
            onBack = onBack,
            onRetry = { result = null; scan() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text(
                "Choose a nearby gateway, wait for the BLE handshake, then provision the mesh network. Selecting a device does not commit a MethodMesh result.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            Text("${status.detail} · ${if (status.connected) "protocol ready" else "not ready"}", style = MaterialTheme.typography.bodyMedium)
            if (gatewayInfo.nodeId.isNotBlank()) {
                Text("Node: ${gatewayInfo.nodeId} · ${gatewayInfo.firmware.ifBlank { "firmware unknown" }}", style = MaterialTheme.typography.bodySmall)
                Text(
                    if (gatewayInfo.provisioned) "Current network: ${gatewayInfo.networkId.ifBlank { "configured" }}" else "Factory-fresh / not yet provisioned",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scan() }, enabled = !scanning, modifier = Modifier.fillMaxWidth()) { Text(if (scanning) "Scanning…" else "Scan for gateways") }
            Spacer(Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                candidates.forEach { candidate ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(candidate.name, style = MaterialTheme.typography.titleMedium)
                                Text("${candidate.address} · RSSI ${candidate.rssi}", style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { select(candidate) }) {
                                Text(if (selectedAddress == candidate.address) "Reconnect" else "Connect")
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("Network provisioning", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(networkId, { networkId = it }, label = { Text("Network ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(
                networkKey,
                { networkKey = it },
                label = { Text("Network key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                provisioningToken,
                { provisioningToken = it },
                label = { Text("Node provisioning token (needed to reconfigure an existing node)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Button(
                onClick = {
                    val sent = provider.configureNetwork(networkId, networkKey, provisioningToken)
                    configStatus = sent.detail
                },
                enabled = status.connected && gatewayInfo.nodeId.isNotBlank() && networkId.isNotBlank() && networkKey.isNotBlank() && provisioningState !is EspMeshProvisioningState.AwaitingAck,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Provision network") }

            if (gatewayInfo.provisioned && selectedAddress.isNotBlank()) {
                OutlinedButton(
                    onClick = {
                        if (provider.acceptExistingGateway()) commitProvisioned()
                        else configStatus = "Could not adopt the existing gateway configuration."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Use existing gateway configuration") }
            }

            if (configStatus.isNotBlank()) Text(configStatus, style = MaterialTheme.typography.bodySmall)
        }
    }
}
