package com.example.methodmesh.platform.devices

import android.content.Context

/** Registers transport extension points without binding capabilities to hardware APIs. */
object PlatformDeviceBootstrap {
    /**
     * Context-free startup keeps architectural placeholders available. A capability
     * with Android context may call this overload again to install platform-backed
     * Device Services before resolving them through DeviceServiceRegistry.
     */
    fun initialise(context: Context? = null) {
        if (context != null && DeviceServiceRegistry.service(MethodMeshBleSensorDeviceService.SERVICE_ID) == null) {
            DeviceServiceRegistry.register(MethodMeshBleSensorDeviceService(context.applicationContext))
        }

        DeviceTransport.entries.forEach { transport ->
            if (DeviceServiceRegistry.service(transport) == null) {
                DeviceServiceRegistry.register(UnconfiguredDeviceService(transport))
            }
        }
    }
}
