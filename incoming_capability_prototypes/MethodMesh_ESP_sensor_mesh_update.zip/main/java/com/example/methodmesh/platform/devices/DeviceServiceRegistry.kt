package com.example.methodmesh.platform.devices

import java.util.concurrent.ConcurrentHashMap

/** Runtime registry for interchangeable device/protocol adapters. */
object DeviceServiceRegistry {
    private val services = ConcurrentHashMap<String, DeviceSignalService>()

    fun register(service: DeviceSignalService) {
        if (service !is UnconfiguredDeviceService) {
            services.entries
                .filter { (_, existing) -> existing is UnconfiguredDeviceService && existing.transport == service.transport }
                .forEach { (key, _) -> services.remove(key) }
        }
        services[service.serviceId] = service
    }

    /** Backward-compatible transport lookup. Prefer an actual service over a placeholder. */
    fun service(transport: DeviceTransport): DeviceSignalService? =
        services.values
            .filter { it.transport == transport }
            .sortedBy { it is UnconfiguredDeviceService }
            .firstOrNull()

    fun service(serviceId: String): DeviceSignalService? = services[serviceId]

    fun services(transport: DeviceTransport): List<DeviceSignalService> =
        services.values.filter { it.transport == transport }.sortedBy { it.serviceId }

    fun all(): List<DeviceSignalService> = services.values.sortedWith(compareBy({ it.transport.name }, { it.serviceId }))

    fun unregister(serviceId: String) {
        services.remove(serviceId)
    }

    fun unregister(transport: DeviceTransport) {
        services.entries.filter { it.value.transport == transport }.forEach { services.remove(it.key) }
    }
}
