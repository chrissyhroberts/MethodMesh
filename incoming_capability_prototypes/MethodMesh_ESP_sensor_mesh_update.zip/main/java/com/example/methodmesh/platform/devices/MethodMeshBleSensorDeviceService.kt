package com.example.methodmesh.platform.devices

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.util.UUID

/**
 * Android BLE adapter for the MethodMesh sensor-node contract.
 *
 * Platform Bluetooth APIs are contained here. Capabilities discover this service
 * through DeviceServiceRegistry and work with transport-neutral DeviceDescriptor /
 * DeviceSignal values.
 */
@SuppressLint("MissingPermission")
class MethodMeshBleSensorDeviceService(
    private val appContext: Context
) : InteractiveDeviceService {
    override val serviceId: String = SERVICE_ID
    override val transport: DeviceTransport = DeviceTransport.BLE

    private val mutableState = MutableStateFlow<DeviceServiceState>(DeviceServiceState.Idle)
    override val state: StateFlow<DeviceServiceState> = mutableState

    private val mutableDevices = MutableStateFlow<List<DeviceDescriptor>>(emptyList())
    override val devices: StateFlow<List<DeviceDescriptor>> = mutableDevices

    private val mutableSignals = MutableSharedFlow<DeviceSignal>(extraBufferCapacity = 32)
    override val signals: Flow<DeviceSignal> = mutableSignals

    private val operationMutex = Mutex()
    private var gatt: BluetoothGatt? = null
    private var manifestCharacteristic: BluetoothGattCharacteristic? = null
    private var readingCharacteristic: BluetoothGattCharacteristic? = null
    private var commandCharacteristic: BluetoothGattCharacteristic? = null
    private var connectedDescriptor: DeviceDescriptor? = null
    private var connectDeferred: CompletableDeferred<Unit>? = null
    private var readDeferred: CompletableDeferred<DeviceSignal>? = null
    private var readUuid: UUID? = null
    private var writeDeferred: CompletableDeferred<DeviceSignal>? = null
    private var writeUuid: UUID? = null
    private var scanCallback: ScanCallback? = null

    override suspend fun start(context: Context) {
        if (bluetoothAdapter()?.isEnabled == true) mutableState.value = DeviceServiceState.Idle
        else mutableState.value = DeviceServiceState.Unavailable("Bluetooth is not enabled")
    }

    override suspend fun stop() {
        stopScan()
        disconnect()
        mutableState.value = DeviceServiceState.Idle
    }

    override suspend fun discover(context: Context) {
        val adapter = bluetoothAdapter()
        val scanner = adapter?.bluetoothLeScanner
        if (adapter == null || !adapter.isEnabled || scanner == null) {
            mutableState.value = DeviceServiceState.Unavailable("Bluetooth is not enabled")
            return
        }

        stopScan()
        mutableDevices.value = emptyList()
        mutableState.value = DeviceServiceState.Discovering

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device = result.device ?: return
                val address = device.address ?: return
                val advertisedName = result.scanRecord?.deviceName.orEmpty()
                val cachedName = runCatching { device.name }.getOrNull().orEmpty()
                val advertisedServices = result.scanRecord?.serviceUuids?.map { it.uuid }.orEmpty()
                val looksLikeSensor =
                    advertisedServices.contains(SENSOR_SERVICE_UUID) ||
                        advertisedName.contains("MethodMesh-Sensor", ignoreCase = true) ||
                        cachedName.contains("MethodMesh-Sensor", ignoreCase = true)
                if (!looksLikeSensor) return

                val descriptor = DeviceDescriptor(
                    id = address,
                    name = advertisedName.ifBlank { cachedName }.ifBlank { "MethodMesh sensor ${address.takeLast(5)}" },
                    transport = DeviceTransport.BLE,
                    capabilities = setOf(SIGNAL_MANIFEST, SIGNAL_READING, SIGNAL_COMMAND, SIGNAL_COMMAND_RESPONSE),
                    metadata = mapOf(
                        "address" to address,
                        "rssi" to result.rssi.toString(),
                        "protocol" to "methodmesh_ble_sensor_node"
                    )
                )
                val updated = mutableDevices.value.filterNot { it.id.equals(address, true) } + descriptor
                mutableDevices.value = updated.sortedByDescending { it.metadata["rssi"]?.toIntOrNull() ?: Int.MIN_VALUE }
            }

            override fun onScanFailed(errorCode: Int) {
                mutableState.value = DeviceServiceState.Failed("BLE scan failed ($errorCode)")
            }
        }

        scanCallback = callback
        runCatching { scanner.startScan(callback) }
            .onFailure { error ->
                scanCallback = null
                mutableState.value = DeviceServiceState.Failed("BLE scan failed: ${error.message.orEmpty()}")
                return
            }

        delay(SCAN_DURATION_MS)
        stopScan()
        if (mutableState.value is DeviceServiceState.Discovering) mutableState.value = DeviceServiceState.Idle
    }

    override suspend fun connect(context: Context, deviceId: String) {
        operationMutex.withLock {
            disconnectInternal(updateState = false)
            val adapter = bluetoothAdapter()
            val device = runCatching { adapter?.getRemoteDevice(deviceId) }.getOrNull()
                ?: throw IllegalStateException("BLE device $deviceId is not available")

            val descriptor = mutableDevices.value.firstOrNull { it.id.equals(deviceId, true) }
                ?: DeviceDescriptor(
                    id = deviceId,
                    name = runCatching { device.name }.getOrNull().orEmpty().ifBlank { "MethodMesh sensor" },
                    transport = DeviceTransport.BLE,
                    capabilities = setOf(SIGNAL_MANIFEST, SIGNAL_READING, SIGNAL_COMMAND, SIGNAL_COMMAND_RESPONSE),
                    metadata = mapOf("address" to deviceId, "protocol" to "methodmesh_ble_sensor_node")
                )
            connectedDescriptor = descriptor
            mutableState.value = DeviceServiceState.Discovering
            val deferred = CompletableDeferred<Unit>()
            connectDeferred = deferred
            gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(appContext, false, callback, BluetoothDevice.TRANSPORT_LE)
            } else {
                @Suppress("DEPRECATION")
                device.connectGatt(appContext, false, callback)
            }
            try {
                withTimeout(CONNECT_TIMEOUT_MS) { deferred.await() }
            } catch (error: Exception) {
                disconnectInternal(updateState = false)
                mutableState.value = DeviceServiceState.Failed(error.message ?: "BLE connection failed")
                throw error
            } finally {
                if (connectDeferred === deferred) connectDeferred = null
            }
        }
    }

    override suspend fun disconnect() {
        operationMutex.withLock { disconnectInternal(updateState = true) }
    }

    override suspend fun read(signalType: String): DeviceSignal = operationMutex.withLock {
        val connection = gatt ?: throw IllegalStateException("No MethodMesh BLE sensor is connected")
        val characteristic = when (signalType) {
            SIGNAL_MANIFEST -> manifestCharacteristic
            SIGNAL_READING -> readingCharacteristic
            SIGNAL_COMMAND_RESPONSE -> commandCharacteristic
            else -> null
        } ?: throw IllegalArgumentException("Device channel '$signalType' is not available")

        val deferred = CompletableDeferred<DeviceSignal>()
        readDeferred = deferred
        readUuid = characteristic.uuid
        if (!connection.readCharacteristic(characteristic)) {
            readDeferred = null
            readUuid = null
            throw IllegalStateException("Could not queue BLE read for $signalType")
        }
        try {
            withTimeout(OPERATION_TIMEOUT_MS) { deferred.await() }
        } finally {
            if (readDeferred === deferred) readDeferred = null
            readUuid = null
        }
    }

    override suspend fun write(signalType: String, value: String): DeviceSignal = operationMutex.withLock {
        if (signalType != SIGNAL_COMMAND) throw IllegalArgumentException("Device channel '$signalType' is not writable")
        val connection = gatt ?: throw IllegalStateException("No MethodMesh BLE sensor is connected")
        val characteristic = commandCharacteristic ?: throw IllegalStateException("Sensor command endpoint is not available")
        val bytes = value.toByteArray(Charsets.UTF_8)
        val deferred = CompletableDeferred<DeviceSignal>()
        writeDeferred = deferred
        writeUuid = characteristic.uuid

        val queued = if (Build.VERSION.SDK_INT >= 33) {
            connection.writeCharacteristic(characteristic, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothGatt.GATT_SUCCESS
        } else {
            @Suppress("DEPRECATION")
            run {
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                characteristic.value = bytes
                connection.writeCharacteristic(characteristic)
            }
        }
        if (!queued) {
            writeDeferred = null
            writeUuid = null
            throw IllegalStateException("Could not queue BLE write")
        }
        try {
            withTimeout(OPERATION_TIMEOUT_MS) { deferred.await() }
        } finally {
            if (writeDeferred === deferred) writeDeferred = null
            writeUuid = null
        }
    }

    private val callback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                val mtuRequested = runCatching { g.requestMtu(517) }.getOrDefault(false)
                if (!mtuRequested) runCatching { g.discoverServices() }
            } else {
                val reason = "BLE sensor disconnected (status=$status)"
                connectDeferred?.completeExceptionally(IllegalStateException(reason))
                readDeferred?.completeExceptionally(IllegalStateException(reason))
                writeDeferred?.completeExceptionally(IllegalStateException(reason))
                mutableState.value = DeviceServiceState.Failed(reason)
                runCatching { g.close() }
                if (gatt === g) {
                    gatt = null
                    manifestCharacteristic = null
                    readingCharacteristic = null
                    commandCharacteristic = null
                }
            }
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            runCatching { g.discoverServices() }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                connectDeferred?.completeExceptionally(IllegalStateException("BLE service discovery failed ($status)"))
                return
            }
            val service = g.getService(SENSOR_SERVICE_UUID)
            manifestCharacteristic = service?.getCharacteristic(MANIFEST_UUID)
            readingCharacteristic = service?.getCharacteristic(READING_UUID)
            commandCharacteristic = service?.getCharacteristic(COMMAND_UUID)
            if (service == null || manifestCharacteristic == null || readingCharacteristic == null) {
                val error = IllegalStateException("Connected device does not expose the MethodMesh sensor contract")
                mutableState.value = DeviceServiceState.Failed(error.message.orEmpty())
                connectDeferred?.completeExceptionally(error)
                return
            }
            val descriptor = connectedDescriptor ?: DeviceDescriptor(
                id = g.device.address,
                name = runCatching { g.device.name }.getOrNull().orEmpty().ifBlank { "MethodMesh sensor" },
                transport = DeviceTransport.BLE
            )
            mutableState.value = DeviceServiceState.Ready(descriptor)
            connectDeferred?.complete(Unit)
        }

        @Suppress("DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            completeRead(characteristic, characteristic.value ?: ByteArray(0), status)
        }

        override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            completeRead(characteristic, value, status)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (characteristic.uuid != writeUuid) return
            val deferred = writeDeferred ?: return
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val signal = DeviceSignal(
                    sourceId = connectedDescriptor?.id.orEmpty(),
                    signalType = SIGNAL_COMMAND,
                    value = "written",
                    metadata = mapOf("gatt_status" to status.toString())
                )
                mutableSignals.tryEmit(signal)
                deferred.complete(signal)
            } else {
                deferred.completeExceptionally(IllegalStateException("BLE write failed with GATT status $status"))
            }
        }
    }

    private fun completeRead(characteristic: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
        if (characteristic.uuid != readUuid) return
        val deferred = readDeferred ?: return
        if (status != BluetoothGatt.GATT_SUCCESS) {
            deferred.completeExceptionally(IllegalStateException("BLE read failed with GATT status $status"))
            return
        }
        val signalType = when (characteristic.uuid) {
            MANIFEST_UUID -> SIGNAL_MANIFEST
            READING_UUID -> SIGNAL_READING
            COMMAND_UUID -> SIGNAL_COMMAND_RESPONSE
            else -> "device.read"
        }
        val signal = DeviceSignal(
            sourceId = connectedDescriptor?.id.orEmpty(),
            signalType = signalType,
            value = value.toString(Charsets.UTF_8),
            metadata = mapOf("transport" to "BLE")
        )
        mutableSignals.tryEmit(signal)
        deferred.complete(signal)
    }

    private fun stopScan() {
        val callback = scanCallback ?: return
        runCatching { bluetoothAdapter()?.bluetoothLeScanner?.stopScan(callback) }
        scanCallback = null
    }

    private fun disconnectInternal(updateState: Boolean) {
        stopScan()
        readDeferred?.cancel()
        writeDeferred?.cancel()
        connectDeferred?.cancel()
        readDeferred = null
        writeDeferred = null
        connectDeferred = null
        readUuid = null
        writeUuid = null
        gatt?.let { connection ->
            runCatching { connection.disconnect() }
            runCatching {
                val method = connection.javaClass.getMethod("refresh")
                method.invoke(connection)
            }
            runCatching { connection.close() }
        }
        gatt = null
        manifestCharacteristic = null
        readingCharacteristic = null
        commandCharacteristic = null
        connectedDescriptor = null
        if (updateState) mutableState.value = DeviceServiceState.Idle
    }

    private fun bluetoothAdapter() = appContext.getSystemService(BluetoothManager::class.java)?.adapter

    companion object {
        const val SERVICE_ID = "methodmesh.ble.sensor"
        const val SIGNAL_MANIFEST = "sensor.manifest"
        const val SIGNAL_READING = "sensor.reading"
        const val SIGNAL_COMMAND = "sensor.command"
        const val SIGNAL_COMMAND_RESPONSE = "sensor.command_response"
        const val SCAN_DURATION_MS = 8_000L
        const val CONNECT_TIMEOUT_MS = 15_000L
        const val OPERATION_TIMEOUT_MS = 8_000L

        val SENSOR_SERVICE_UUID: UUID = UUID.fromString("b6f2a900-9b8f-4f4e-9a1f-4f37a0010000")
        val MANIFEST_UUID: UUID = UUID.fromString("b6f2a901-9b8f-4f4e-9a1f-4f37a0010000")
        val READING_UUID: UUID = UUID.fromString("b6f2a902-9b8f-4f4e-9a1f-4f37a0010000")
        val COMMAND_UUID: UUID = UUID.fromString("b6f2a903-9b8f-4f4e-9a1f-4f37a0010000")
    }
}
