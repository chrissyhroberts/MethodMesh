# Text documents v0.10

Hardening release over v0.09.

## Recent-file durability

- Recent files now contain only URIs for which Android reports a persisted read grant.
- Transient external-provider URIs (notably messaging-app attachments such as WhatsApp media) remain fully usable in the current editing session but are not stored as if they were reopenable later.
- Existing stale/transient entries from earlier releases are pruned automatically when the library is read.
- If a previously durable recent file nevertheless becomes unavailable, the entry is removed after the failed open.

## Error handling

- Provider implementation details, process IDs and raw Android permission exceptions are no longer shown in the document library.
- Read failures are reduced to short actionable messages.
- Save permission failures direct the user toward Save as.

## Unchanged behaviour

- standalone toolkit launch remains free of Commit/results windows;
- TXT, Markdown, JSON and JSONL editing remains lossless;
- Save, Save as, share, clipboard creation, find/replace and Markdown source/preview remain unchanged;
- external VIEW/EDIT launches still return to their originating app;
- canonical `document.text.open` and ODK/preset/protocol behaviour are unchanged.
