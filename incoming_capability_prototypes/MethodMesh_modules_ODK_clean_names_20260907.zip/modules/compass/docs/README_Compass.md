# Compass — MethodMesh v1.05 refresh

`compass.read` is the canonical MethodMesh compass capability for reading a phone magnetic heading and sighting either magnetic North or a configured bearing.

**Module:** `compass`  
**Method ID:** `compass.read`  
**Capability version:** `0.2.0`  
**Lane:** Development  
**MethodMesh target:** v1.05

The v1.05 refresh is a migration of the existing capability. The established method ID, setting keys, input semantics and output field names are preserved.

## Capability contract and surface parity

There is one canonical capability: `compass.read`.

- **Dashboard:** the auto-discovered module presence uses the module metadata and `iconKey="location"`; it launches the same `compass.read` capability. There is no dashboard-only compass implementation.
- **Direct native use:** opens the purpose-built compass instrument.
- **Presets:** `compass.read` remains independently selectable. Fixed preset values are hidden at runtime; declared runtime fields remain editable.
- **Protocols:** `compass.read` remains an independent protocol step. Commit returns the canonical payload to the protocol runner.
- **Schedules/widgets:** where the host launches the capability interactively, it uses the same method and screen. Widget-origin completion respects `methodmesh_finish_to_launcher`.
- **ODK/XLSForm:** `compass.read` is invoked through the normal grouped intent route. Commit returns the same canonical fields to ODK; every declared output remains transport-addressable.

No central capability registration or shared dashboard special case is required.

## Native v1.05 interaction

The production interaction is now instrument-first rather than settings-form-first:

1. The live compass is at the top of the screen.
2. Heading, target and angular error update in place.
3. Tap any displayed useful value to copy its value to the clipboard.
4. **Commit reading** freezes the canonical result for this execution.
5. The live compass remains visible after Commit; the frozen committed result does not silently change as the sensor moves.
6. After Commit, the same screen exposes Copy, Share, Save, optional full JSON, Technical details and Done.
7. Settings are below the instrument.
8. **Sight** opens the full-screen rear-camera-axis sight. Its button is also explicitly **Commit reading**.

If settings are changed after a commit, the committed payload stays frozen and the UI says that a recommit is required to replace it.

### Launch-origin closeout

- normal dashboard/direct run: **Done** returns the committed result to the dashboard flow;
- app-launched native preset: **Done/Home** follows the existing preset closeout settings;
- widget preset: `methodmesh_finish_to_launcher=true` returns through the caller so the user is not stranded inside MethodMesh;
- protocol/schedule/dependency/ODK automatic-return route: **Commit** immediately returns the canonical payload to the caller;
- cancellation before Commit returns through the host cancellation callback.

## Compass behaviour

The module reuses existing shared platform boundaries:

- `PhoneSensorRepository.headingDegrees` — flat-phone magnetic heading;
- `PhoneSensorRepository.rearCameraHeadingDegrees` — rear-camera optical-axis heading in sight mode;
- `PhoneSensorRepository.pitchDegrees` / `rollDegrees` — capture metadata;
- `PhoneSensorRepository.readings["magnetometer"]?.accuracy` — Android sensor-accuracy metadata;
- `LiveCameraPreview` — optional camera background.

The module does not add a second orientation sensor stack.

The main instrument uses a dark compass face, brass bezel/ticks, a red north needle, a pale south needle, a direction-of-travel marker and a target bug. Numeric heading remains the authoritative live readout.

## North reference

This capability reports **magnetic north**. It does not request location and does not apply magnetic declination.

Every successful result includes:

```text
compass_north_reference = magnetic
```

A future true-north mode should consume an explicitly supplied/public location fix rather than silently acquiring precise location.

## Settings / runtime inputs

All reusable configuration remains declared through `MethodSetting` in `CompassModule.kt`.

| Key | Type | Meaning | Default |
|---|---|---|---|
| `target_mode` | choice | `north` or `bearing` | `north` |
| `target_bearing_deg` | float | Manual target bearing, 0–359.9° | `0` |
| `alignment_tolerance_deg` | float | Aligned-zone half-width, 1–30° | `5` |
| `show_camera_in_sight` | boolean | Rear-camera preview behind sight | `true` |
| `start_in_sight_mode` | boolean | Open directly into sight mode | `false` |

`target_bearing_deg` is ignored when `target_mode=north`; the effective target is 0°.

Useful preset patterns:

- **Sight North** — fixed North target; start in sight mode;
- **Transect 090°** — fixed 90° target and ±3° tolerance;
- **Bearing capture** — target bearing left as a runtime input.

## Canonical outputs

All fields below are declared outputs of `compass.read`. Presentation is selective, but contract availability is not.

| Field | Normal native presentation | Contract role / meaning |
|---|---|---|
| `compass_status` | technical | `succeeded` or `failed` |
| `compass_result` | **primary** | Compact human-readable beef, e.g. `091° E · 90.0° · On target` |
| `compass_heading_deg` | live + committed | Captured magnetic heading, [0,360) |
| `compass_cardinal` | primary/technical | 16-point direction |
| `compass_target_mode` | technical | `north` or `bearing` |
| `compass_target_bearing_deg` | live + committed | Effective target bearing |
| `compass_error_deg` | live + committed | Signed shortest error; positive means turn right |
| `compass_abs_error_deg` | technical | Absolute angular error |
| `compass_aligned` | primary/technical | Within configured tolerance |
| `compass_tolerance_deg` | settings/technical | Alignment tolerance |
| `compass_view_mode` | technical | `flat` or `sight` |
| `compass_heading_axis` | technical | `device_top_edge` or `rear_camera_optical_axis` |
| `compass_north_reference` | technical | `magnetic` |
| `compass_pitch_deg` | technical | Pitch at Commit when available |
| `compass_roll_deg` | technical | Roll at Commit when available |
| `compass_magnetometer_accuracy` | status/technical | Android sensor accuracy integer |
| `compass_captured_time_iso` | technical | UTC ISO timestamp of Commit |
| `compass_audit_json` | technical/audit | Capability audit JSON |
| `compass_error` | error | Failure detail |

### Beef-first actions

With **Include full JSON** off:

- tap-to-copy on a scalar copies the scalar value only;
- Copy/Share/Save use `compass_result` as the main result.

With **Include full JSON** on:

- Copy/Share append the standard full MethodMesh JSON representation;
- Save writes the main result and the full JSON metadata file to Downloads.

`compass_audit_json` remains independently addressable through the capability contract and ODK projection even though it is normally hidden under Technical details.

## ODK / XLSForm

The supplied `docs/example_odk_compass.xlsx` uses a grouped intent call and requests FULL payload mode.

Representative call:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='compass.read',
  input_target_mode=${target_mode},
  input_target_bearing_deg=${target_bearing},
  input_alignment_tolerance_deg=${tolerance_deg},
  input_show_camera_in_sight=${show_camera},
  input_start_in_sight_mode=${start_in_sight},
  input_payload_mode='FULL',
  return_mode='flat'
)
```

The compass is inherently interactive: the current sensor reading must be intentionally committed. ODK therefore follows the interactive route:

```text
ODK -> compass.read UI -> live sight/heading -> Commit -> canonical result -> ODK
```

ODK does not receive MethodMesh normal Share/Save/Home closeout after Commit. The external workflow transport owns namespace projection, `methodmesh_full_json`, closeout fields and return-to-caller behaviour.

The example workbook includes every declared `compass_*` output plus `methodmesh_full_json` and closeout/status fields. Example forms remain demonstrations rather than allow-lists: generic ODK projection is driven by the canonical method contract.

No MethodMesh archive copy is created merely because ODK invoked the capability.

## Audit JSON

`compass_audit_json` records at least:

- method ID and version;
- alignment algorithm version;
- magnetic north reference;
- captured heading and cardinal direction;
- target mode and effective target bearing;
- signed and absolute angular error;
- tolerance and aligned flag;
- flat vs sighting mode;
- heading axis;
- pitch and roll where available;
- Android magnetometer accuracy where available;
- Commit timestamp;
- sensor boundary identifier;
- `network_used=false`;
- `location_used=false`.

## State and persistence

- target, tolerance, camera option and start-in-sight configuration use saveable UI state;
- the full committed `compass_*` field set is saved as a compact JSON snapshot and reconstructed after Activity recreation;
- sight-open state is saveable;
- the committed payload remains separate from the continuously changing live sensor reading;
- there is no automatic permanent record or output-folder save;
- explicit **Save** is the only native persistence action introduced by this module.

## Permissions

### Orientation sensors

No runtime permission is required for the Android motion/magnetic sensors exposed by `PhoneSensorRepository`.

### Camera

`android.permission.CAMERA` is required only when the optional camera background is requested in sight mode. Denial leaves the sighting calculation usable on a dark background.

No location permission is requested.

## Offline behaviour

**Fully offline.**

No network request, cloud processing, telemetry upload, map lookup or remote API is required for compass operation.

## Dependencies

Host/shared MethodMesh dependencies used by the existing capability contract:

- `PhoneSensorRepository`;
- `LiveCameraPreview`;
- `OutputFormatter`;
- `OutputExportRepository`;
- standard capability workflow callbacks and preset closeout settings.

No new third-party library is introduced by this refresh.

## Validation status

Completed in the packaging environment:

- standalone Kotlin smoke compile/run for compass normalisation, cardinal mapping, wrap-around error, alignment boundaries and labels;
- v1.05 contract review against the supplied module review manual;
- current MethodMesh public framework interfaces cross-checked for `MethodMeshModule`, `CapabilityScreenContext`, output export and external automatic-return behaviour;
- ODK example expanded to cover all declared compass outputs.

Not claimable in this packaging environment:

- `./gradlew :app:testDebugUnitTest`;
- `./gradlew :app:assembleDebug`;
- physical-device sensor/camera testing;
- ODK Collect launch/Commit/return test.

Keep the capability in **Development** until those host/device checks pass.

## Known limitations

1. Magnetic north only; no declination correction.
2. Phone magnetometers are vulnerable to nearby magnets, steel, speakers, cases and electrical equipment.
3. Heading accuracy is hardware/calibration dependent; the UI reports Android sensor accuracy but makes no survey-grade claim.
4. Sight mode assesses horizontal bearing; it is not an inclinometer or full 3D aiming solution.
5. Rear-camera optical-axis heading is undefined near vertical up/down geometry.
6. Camera imagery is display-only and is not captured, persisted or analysed.

## Roadmap

Potential future work, outside this migration:

- optional true north using explicit location + geomagnetic declination;
- haptic/audio alignment cue;
- bearing hold/lock;
- inclinometer as a separate method;
- composition with GPS target bearing through the public GPS navigation contract.
