# MethodMesh XLSForm cleanup validation

Validation date: 2026-09-07

## Naming and identity results

- Total XLSForms in module bundle: **423** (147 legacy examples + 276 dedicated capability showcases).
- Filename convention violations: **0**.
- References to old XLSForm filenames in tracked text/source files: **0**.
- Legacy forms with blank `form_id`: **0**.
- Duplicate legacy `form_id` values: **0**.
- Legacy forms with blank `form_title`: **0**.
- Duplicate legacy titles: **0**.
- Legacy forms with blank version: **0**.
- Machine-token legacy titles remaining: **0**.

## Compatibility findings intentionally retained

- **34** existing `form_id` values do not meet the current lower-snake-case recommendation. They were intentionally preserved to avoid breaking ODK form identity.
- **10** otherwise unchanged legacy forms retain historical version strings outside the `YYYYMMDDrr` recommendation.

## Validator coverage

- MethodMesh naming/settings checks: completed for this cleanup.
- Dedicated capability showcase forms retain the earlier MethodMesh linter result: 0 showcase errors/warnings/naming issues.
- `pyxform` / ODK Validate is not installed in this build environment, so the optional second validation layer was not rerun here.
- Existing substantive legacy XLSForm findings (for example JavaRosa expression or duplicate survey-name problems previously reported) are outside this naming/identity cleanup and remain tracked separately.
