# MethodMesh ODK Capability Showcase Manifest

- Modules with generated showcases: **66**
- Dedicated capability XLSForms: **276**
- Placement: `modules/<module>/docs/example_odk_showcase_<purpose>.xlsx`
- Existing XLSForms were preserved; generated showcase files use distinct filenames.
- Each showcase uses `input_payload_mode=FULL` where specified by the resolved contract and captures `methodmesh_full_json`.
- Capability-specific return fields are scoped per call; unrelated module JSON leaves are not included.

## Forms

### `acoustics` — 4 form(s)

- `acoustic.analyse` → `example_odk_showcase_acoustic_analyse.xlsx` · `form_id=acoustics_acoustic_analyse` · JSON: `acoustic_harmonics_json`, `acoustic_spectrum_json`, `acoustic_timeseries_json`, `acoustic_audit_json`
- `acoustic.compare` → `example_odk_showcase_acoustic_compare.xlsx` · `form_id=acoustics_acoustic_compare` · JSON: `acoustic_compare_audit_json`
- `acoustic.level` → `example_odk_showcase_acoustic_level.xlsx` · `form_id=acoustics_acoustic_level` · JSON: `acoustic_level_audit_json`
- `acoustic.tune` → `example_odk_showcase_acoustic_tune.xlsx` · `form_id=acoustics_acoustic_tune` · JSON: `acoustic_tuner_audit_json`

### `adminfingerprint` — 1 form(s)

- `admin_fingerprint_confirmation` → `example_odk_showcase_admin_fingerprint_confirmation.xlsx` · `form_id=adminfingerprint_admin_fingerprint_confirmation` · JSON: `biometric_provenance_json`

### `apiget` — 1 form(s)

- `api.get` → `example_odk_showcase_api_get.xlsx` · `form_id=apiget_api_get` · JSON: `api_values_json`, `api_response_json`

### `appinspector` — 1 form(s)

- `android_app_inspector` → `example_odk_showcase_android_app_inspector.xlsx` · `form_id=appinspector_android_app_inspector` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `aquaticfield` — 16 form(s)

- `aquatic.ctd.cast` → `example_odk_showcase_aquatic_ctd_cast.xlsx` · `form_id=aquaticfield_aquatic_ctd_cast` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.depth_plan.generate` → `example_odk_showcase_aquatic_depth_plan_generate.xlsx` · `form_id=aquaticfield_aquatic_depth_plan_generate` · JSON: `aquatic_depth_plan_json`
- `aquatic.field_qc.run` → `example_odk_showcase_aquatic_field_qc_run.xlsx` · `form_id=aquaticfield_aquatic_field_qc_run` · JSON: `aquatic_qc_json`
- `aquatic.instrument.check` → `example_odk_showcase_aquatic_instrument_check.xlsx` · `form_id=aquaticfield_aquatic_instrument_check` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.mooring.record` → `example_odk_showcase_aquatic_mooring_record.xlsx` · `form_id=aquaticfield_aquatic_mooring_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.pressure_depth.convert` → `example_odk_showcase_aquatic_pressure_depth_convert.xlsx` · `form_id=aquaticfield_aquatic_pressure_depth_convert` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.profile.summarise` → `example_odk_showcase_aquatic_profile_summarise.xlsx` · `form_id=aquaticfield_aquatic_profile_summarise` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.rosette.fire` → `example_odk_showcase_aquatic_rosette_fire.xlsx` · `form_id=aquaticfield_aquatic_rosette_fire` · JSON: `aquatic_rosette_sample_ids_json`
- `aquatic.salinity.convert` → `example_odk_showcase_aquatic_salinity_convert.xlsx` · `form_id=aquaticfield_aquatic_salinity_convert` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.sample.record` → `example_odk_showcase_aquatic_sample_record.xlsx` · `form_id=aquaticfield_aquatic_sample_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.sample_id.generate` → `example_odk_showcase_aquatic_sample_id_generate.xlsx` · `form_id=aquaticfield_aquatic_sample_id_generate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.secchi.measure` → `example_odk_showcase_aquatic_secchi_measure.xlsx` · `form_id=aquaticfield_aquatic_secchi_measure` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.sediment.record` → `example_odk_showcase_aquatic_sediment_record.xlsx` · `form_id=aquaticfield_aquatic_sediment_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.station.dashboard` → `example_odk_showcase_aquatic_station_dashboard.xlsx` · `form_id=aquaticfield_aquatic_station_dashboard` · JSON: `aquatic_dashboard_snapshot_json`
- `aquatic.station.visit` → `example_odk_showcase_aquatic_station_visit.xlsx` · `form_id=aquaticfield_aquatic_station_visit` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `aquatic.transect.record` → `example_odk_showcase_aquatic_transect_record.xlsx` · `form_id=aquaticfield_aquatic_transect_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `arcade` — 1 form(s)

- `arcade.snapshot` → `example_odk_showcase_arcade_snapshot.xlsx` · `form_id=arcade_arcade_snapshot` · JSON: `arcade_state_json`

### `astronomy` — 12 form(s)

- `astronomy.conditions` → `example_odk_showcase_astronomy_conditions.xlsx` · `form_id=astronomy_astronomy_conditions` · JSON: `conditions_methodmesh_full_json`
- `astronomy.dashboard` → `example_odk_showcase_astronomy_dashboard.xlsx` · `form_id=astronomy_astronomy_dashboard` · JSON: `dashboard_astronomy_dashboard_json`, `dashboard_methodmesh_full_json`
- `astronomy.dew_risk` → `example_odk_showcase_astronomy_dew_risk.xlsx` · `form_id=astronomy_astronomy_dew_risk` · JSON: `dew_methodmesh_full_json`
- `astronomy.exposure_limit` → `example_odk_showcase_astronomy_exposure_limit.xlsx` · `form_id=astronomy_astronomy_exposure_limit` · JSON: `exposure_methodmesh_full_json`
- `astronomy.focus` → `example_odk_showcase_astronomy_focus.xlsx` · `form_id=astronomy_astronomy_focus` · JSON: `focus_methodmesh_full_json`
- `astronomy.image_scale` → `example_odk_showcase_astronomy_image_scale.xlsx` · `form_id=astronomy_astronomy_image_scale` · JSON: `scale_methodmesh_full_json`
- `astronomy.imaging_window` → `example_odk_showcase_astronomy_imaging_window.xlsx` · `form_id=astronomy_astronomy_imaging_window` · JSON: `window_astronomy_window_samples_json`, `window_methodmesh_full_json`
- `astronomy.light_pollution` → `example_odk_showcase_astronomy_light_pollution.xlsx` · `form_id=astronomy_astronomy_light_pollution` · JSON: `lightpollution_methodmesh_full_json`
- `astronomy.mount_stability` → `example_odk_showcase_astronomy_mount_stability.xlsx` · `form_id=astronomy_astronomy_mount_stability` · JSON: `mount_methodmesh_full_json`
- `astronomy.polar_align` → `example_odk_showcase_astronomy_polar_align.xlsx` · `form_id=astronomy_astronomy_polar_align` · JSON: `polar_methodmesh_full_json`
- `astronomy.session` → `example_odk_showcase_astronomy_session.xlsx` · `form_id=astronomy_astronomy_session` · JSON: `session_astronomy_session_json`, `session_methodmesh_full_json`
- `astronomy.sky_test` → `example_odk_showcase_astronomy_sky_test.xlsx` · `form_id=astronomy_astronomy_sky_test` · JSON: `sky_methodmesh_full_json`

### `attestation` — 2 form(s)

- `attestation.anchor_bundle` → `example_odk_showcase_attestation_anchor_bundle.xlsx` · `form_id=attestation_attestation_anchor_bundle` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `attestation.create` → `example_odk_showcase_attestation_create.xlsx` · `form_id=attestation_attestation_create` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `aviation` — 6 form(s)

- `aviation.airfield.nearby` → `example_odk_showcase_aviation_airfield_nearby.xlsx` · `form_id=aviation_aviation_airfield_nearby` · JSON: `nearby_methodmesh_full_json`
- `aviation.altitude.calculate` → `example_odk_showcase_aviation_altitude_calculate.xlsx` · `form_id=aviation_aviation_altitude_calculate` · JSON: `altitude_methodmesh_full_json`
- `aviation.dashboard` → `example_odk_showcase_aviation_dashboard.xlsx` · `form_id=aviation_aviation_dashboard` · JSON: `dashboard_methodmesh_full_json`
- `aviation.e6b.calculate` → `example_odk_showcase_aviation_e6b_calculate.xlsx` · `form_id=aviation_aviation_e6b_calculate` · JSON: `e6b_methodmesh_full_json`
- `aviation.emergency.instruments` → `example_odk_showcase_aviation_emergency_instruments.xlsx` · `form_id=aviation_aviation_emergency_instruments` · JSON: `emergency_methodmesh_full_json`
- `aviation.runway.wind` → `example_odk_showcase_aviation_runway_wind.xlsx` · `form_id=aviation_aviation_runway_wind` · JSON: `wind_methodmesh_full_json`

### `bluetoothinspector` — 1 form(s)

- `bluetooth_device_inspector` → `example_odk_showcase_bluetooth_device_inspector.xlsx` · `form_id=bluetoothinspector_bluetooth_device_inspector` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `bluetoothprinter` — 1 form(s)

- `bluetooth_print` → `example_odk_showcase_bluetooth_print.xlsx` · `form_id=bluetoothprinter_bluetooth_print` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `calibratedscale` — 1 form(s)

- `calibrated_scale` → `example_odk_showcase_calibrated_scale.xlsx` · `form_id=calibratedscale_calibrated_scale` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `chance` — 6 form(s)

- `chance.cards.draw` → `example_odk_showcase_chance_cards_draw.xlsx` · `form_id=chance_chance_cards_draw` · JSON: `card_cards_json`, `card_player_hands_json`, `card_audit_json`
- `chance.pick.one` → `example_odk_showcase_chance_pick_one.xlsx` · `form_id=chance_chance_pick_one` · JSON: `pick_arrangement_json`, `pick_audit_json`
- `chance.spinner.spin` → `example_odk_showcase_chance_spinner_spin.xlsx` · `form_id=chance_chance_spinner_spin` · JSON: `spinner_items_json`, `spinner_audit_json`
- `chance.weighted.choose` → `example_odk_showcase_chance_weighted_choose.xlsx` · `form_id=chance_chance_weighted_choose` · JSON: `weighted_options_json`, `weighted_audit_json`
- `coin.toss` → `example_odk_showcase_coin_toss.xlsx` · `form_id=chance_coin_toss` · JSON: `coin_audit_json`
- `dice.simulate` → `example_odk_showcase_dice_simulate.xlsx` · `form_id=chance_dice_simulate` · JSON: `dice_players_json`, `dice_last_roll_details_json`, `dice_audit_json`

### `choiceexperiment` — 5 form(s)

- `dce.conjoint` → `example_odk_showcase_dce_conjoint.xlsx` · `form_id=choiceexperiment_dce_conjoint` · JSON: `result_json`
- `dce.maxdiff` → `example_odk_showcase_dce_maxdiff.xlsx` · `form_id=choiceexperiment_dce_maxdiff` · JSON: `result_json`
- `dce.pairwise` → `example_odk_showcase_dce_pairwise.xlsx` · `form_id=choiceexperiment_dce_pairwise` · JSON: `result_json`
- `dce.points` → `example_odk_showcase_dce_points.xlsx` · `form_id=choiceexperiment_dce_points` · JSON: `result_json`
- `dce.ranking` → `example_odk_showcase_dce_ranking.xlsx` · `form_id=choiceexperiment_dce_ranking` · JSON: `result_json`

### `clinicalinstruments` — 1 form(s)

- `clinical.instrument.run` → `example_odk_showcase_clinical_instrument_run.xlsx` · `form_id=clinicalinstruments_clinical_instrument_run` · JSON: `clinical_responses_json`, `clinical_derived_json`, `clinical_result_json`

### `compass` — 1 form(s)

- `compass.read` → `example_odk_showcase_compass_read.xlsx` · `form_id=compass_compass_read` · JSON: `compass_audit_json`

### `conversationtranslate` — 1 form(s)

- `conversation.translate` → `example_odk_showcase_conversation_translate.xlsx` · `form_id=conversationtranslate_conversation_translate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `conversions` — 1 form(s)

- `conversion.calculate` → `example_odk_showcase_conversion_calculate.xlsx` · `form_id=conversions_conversion_calculate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `cryptography` — 20 form(s)

- `crypto.challenge.create` → `example_odk_showcase_crypto_challenge_create.xlsx` · `form_id=cryptography_crypto_challenge_create` · JSON: `crypto_provenance_json`
- `crypto.challenge.respond` → `example_odk_showcase_crypto_challenge_respond.xlsx` · `form_id=cryptography_crypto_challenge_respond` · JSON: `crypto_provenance_json`
- `crypto.challenge.verify` → `example_odk_showcase_crypto_challenge_verify.xlsx` · `form_id=cryptography_crypto_challenge_verify` · JSON: `crypto_provenance_json`
- `crypto.dashboard` → `example_odk_showcase_crypto_dashboard.xlsx` · `form_id=cryptography_crypto_dashboard` · JSON: `crypto_provenance_json`
- `crypto.file.decrypt` → `example_odk_showcase_crypto_file_decrypt.xlsx` · `form_id=cryptography_crypto_file_decrypt` · JSON: `crypto_provenance_json`
- `crypto.file.encrypt` → `example_odk_showcase_crypto_file_encrypt.xlsx` · `form_id=cryptography_crypto_file_encrypt` · JSON: `crypto_provenance_json`
- `crypto.hash` → `example_odk_showcase_crypto_hash.xlsx` · `form_id=cryptography_crypto_hash` · JSON: `crypto_provenance_json`
- `crypto.identity.export` → `example_odk_showcase_crypto_identity_export.xlsx` · `form_id=cryptography_crypto_identity_export` · JSON: `crypto_provenance_json`
- `crypto.key.generate` → `example_odk_showcase_crypto_key_generate.xlsx` · `form_id=cryptography_crypto_key_generate` · JSON: `crypto_provenance_json`
- `crypto.password.generate` → `example_odk_showcase_crypto_password_generate.xlsx` · `form_id=cryptography_crypto_password_generate` · JSON: `crypto_provenance_json`
- `crypto.secret.combine` → `example_odk_showcase_crypto_secret_combine.xlsx` · `form_id=cryptography_crypto_secret_combine` · JSON: `crypto_provenance_json`
- `crypto.secret.split` → `example_odk_showcase_crypto_secret_split.xlsx` · `form_id=cryptography_crypto_secret_split` · JSON: `crypto_provenance_json`
- `crypto.sign` → `example_odk_showcase_crypto_sign.xlsx` · `form_id=cryptography_crypto_sign` · JSON: `crypto_provenance_json`
- `crypto.signature.verify` → `example_odk_showcase_crypto_signature_verify.xlsx` · `form_id=cryptography_crypto_signature_verify` · JSON: `crypto_provenance_json`
- `crypto.text.decrypt` → `example_odk_showcase_crypto_text_decrypt.xlsx` · `form_id=cryptography_crypto_text_decrypt` · JSON: `crypto_provenance_json`
- `crypto.text.encrypt` → `example_odk_showcase_crypto_text_encrypt.xlsx` · `form_id=cryptography_crypto_text_encrypt` · JSON: `crypto_provenance_json`
- `otp.totp.delete` → `example_odk_showcase_otp_totp_delete.xlsx` · `form_id=cryptography_otp_totp_delete` · JSON: `crypto_provenance_json`
- `otp.totp.export` → `example_odk_showcase_otp_totp_export.xlsx` · `form_id=cryptography_otp_totp_export` · JSON: `crypto_provenance_json`
- `otp.totp.generate` → `example_odk_showcase_otp_totp_generate.xlsx` · `form_id=cryptography_otp_totp_generate` · JSON: `crypto_provenance_json`
- `otp.totp.import` → `example_odk_showcase_otp_totp_import.xlsx` · `form_id=cryptography_otp_totp_import` · JSON: `crypto_provenance_json`

### `datatools` — 1 form(s)

- `data.tools` → `example_odk_showcase_data_tools.xlsx` · `form_id=datatools_data_tools` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `digitalsigning` — 1 form(s)

- `document.sign_pdf` → `example_odk_showcase_document_sign_pdf.xlsx` · `form_id=digitalsigning_document_sign_pdf` · JSON: `digital_signing_tsa_json`, `digital_signing_result_json`

### `diving` — 18 form(s)

- `diving.bailout.plan` → `example_odk_showcase_diving_bailout_plan.xlsx` · `form_id=diving_diving_bailout_plan` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.cylinder.capacity` → `example_odk_showcase_diving_cylinder_capacity.xlsx` · `form_id=diving_diving_cylinder_capacity` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.cylinder.record` → `example_odk_showcase_diving_cylinder_record.xlsx` · `form_id=diving_diving_cylinder_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.dashboard` → `example_odk_showcase_diving_dashboard.xlsx` · `form_id=diving_diving_dashboard` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.ead` → `example_odk_showcase_diving_ead.xlsx` · `form_id=diving_diving_ead` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.end` → `example_odk_showcase_diving_end.xlsx` · `form_id=diving_diving_end` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.gas.analysis.record` → `example_odk_showcase_diving_gas_analysis_record.xlsx` · `form_id=diving_diving_gas_analysis_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.gas.dashboard` → `example_odk_showcase_diving_gas_dashboard.xlsx` · `form_id=diving_diving_gas_dashboard` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.gas.density` → `example_odk_showcase_diving_gas_density.xlsx` · `form_id=diving_diving_gas_density` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.gas.plan` → `example_odk_showcase_diving_gas_plan.xlsx` · `form_id=diving_diving_gas_plan` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.lift` → `example_odk_showcase_diving_lift.xlsx` · `form_id=diving_diving_lift` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.log.dashboard` → `example_odk_showcase_diving_log_dashboard.xlsx` · `form_id=diving_diving_log_dashboard` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.log.record` → `example_odk_showcase_diving_log_record.xlsx` · `form_id=diving_diving_log_record` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.mod` → `example_odk_showcase_diving_mod.xlsx` · `form_id=diving_diving_mod` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.navigation` → `example_odk_showcase_diving_navigation.xlsx` · `form_id=diving_diving_navigation` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.nitrox.best_mix` → `example_odk_showcase_diving_nitrox_best_mix.xlsx` · `form_id=diving_diving_nitrox_best_mix` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.ppo2` → `example_odk_showcase_diving_ppo2.xlsx` · `form_id=diving_diving_ppo2` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `diving.sac_rmv` → `example_odk_showcase_diving_sac_rmv.xlsx` · `form_id=diving_diving_sac_rmv` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `documentscanner` — 1 form(s)

- `document.scan` → `example_odk_showcase_document_scan.xlsx` · `form_id=documentscanner_document_scan` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `earthscience` — 12 form(s)

- `geodesy.destination` → `example_odk_showcase_geodesy_destination.xlsx` · `form_id=earthscience_geodesy_destination` · JSON: `destination_methodmesh_full_json`
- `geodesy.distance_bearing` → `example_odk_showcase_geodesy_distance_bearing.xlsx` · `form_id=earthscience_geodesy_distance_bearing` · JSON: `distance_methodmesh_full_json`
- `geodesy.utm_to_wgs84` → `example_odk_showcase_geodesy_utm_to_wgs84.xlsx` · `form_id=earthscience_geodesy_utm_to_wgs84` · JSON: `wgs84_methodmesh_full_json`
- `geodesy.wgs84_to_utm` → `example_odk_showcase_geodesy_wgs84_to_utm.xlsx` · `form_id=earthscience_geodesy_wgs84_to_utm` · JSON: `utm_methodmesh_full_json`
- `geotime.lookup` → `example_odk_showcase_geotime_lookup.xlsx` · `form_id=earthscience_geotime_lookup` · JSON: `geotime_methodmesh_full_json`
- `gnss.average_position` → `example_odk_showcase_gnss_average_position.xlsx` · `form_id=earthscience_gnss_average_position` · JSON: `gnss_methodmesh_full_json`
- `sediment.grain_size` → `example_odk_showcase_sediment_grain_size.xlsx` · `form_id=earthscience_sediment_grain_size` · JSON: `grain_methodmesh_full_json`
- `soil.texture_usda` → `example_odk_showcase_soil_texture_usda.xlsx` · `form_id=earthscience_soil_texture_usda` · JSON: `soil_methodmesh_full_json`
- `structural.line` → `example_odk_showcase_structural_line.xlsx` · `form_id=earthscience_structural_line` · JSON: `line_methodmesh_full_json`
- `structural.plane` → `example_odk_showcase_structural_plane.xlsx` · `form_id=earthscience_structural_plane` · JSON: `plane_methodmesh_full_json`
- `structural.plane_capture` → `example_odk_showcase_structural_plane_capture.xlsx` · `form_id=earthscience_structural_plane_capture` · JSON: `capture_methodmesh_full_json`
- `structural.plane_intersection` → `example_odk_showcase_structural_plane_intersection.xlsx` · `form_id=earthscience_structural_plane_intersection` · JSON: `intersection_methodmesh_full_json`

### `electrical` — 1 form(s)

- `electrical.workbench` → `example_odk_showcase_electrical_workbench.xlsx` · `form_id=electrical_electrical_workbench` · JSON: `electrical_audit_json`

### `emergency` — 5 form(s)

- `emergency.exit.find` → `example_odk_showcase_emergency_exit_find.xlsx` · `form_id=emergency_emergency_exit_find` · JSON: `emergency_exit_options_json`
- `emergency.location` → `example_odk_showcase_emergency_location.xlsx` · `form_id=emergency_emergency_location` · JSON: `emergency_location_audit_json`
- `emergency.pack.prepare` → `example_odk_showcase_emergency_pack_prepare.xlsx` · `form_id=emergency_emergency_pack_prepare` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `emergency.reference.open` → `example_odk_showcase_emergency_reference_open.xlsx` · `form_id=emergency_emergency_reference_open` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `emergency.status` → `example_odk_showcase_emergency_status.xlsx` · `form_id=emergency_emergency_status` · JSON: `emergency_status_audit_json`

### `expenses` — 1 form(s)

- `expenses.manage` → `example_odk_showcase_expenses_manage.xlsx` · `form_id=expenses_expenses_manage` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `fieldstats` — 10 form(s)

- `fieldstats.compare_binary` → `example_odk_showcase_fieldstats_compare_binary.xlsx` · `form_id=fieldstats_fieldstats_compare_binary` · JSON: `fieldstats_audit_json`
- `fieldstats.detection_limit` → `example_odk_showcase_fieldstats_detection_limit.xlsx` · `form_id=fieldstats_fieldstats_detection_limit` · JSON: `fieldstats_audit_json`
- `fieldstats.diagnostic_2x2` → `example_odk_showcase_fieldstats_diagnostic_2x2.xlsx` · `form_id=fieldstats_fieldstats_diagnostic_2x2` · JSON: `fieldstats_audit_json`
- `fieldstats.probability` → `example_odk_showcase_fieldstats_probability.xlsx` · `form_id=fieldstats_fieldstats_probability` · JSON: `fieldstats_audit_json`
- `fieldstats.proportion` → `example_odk_showcase_fieldstats_proportion.xlsx` · `form_id=fieldstats_fieldstats_proportion` · JSON: `fieldstats_audit_json`
- `fieldstats.roc` → `example_odk_showcase_fieldstats_roc.xlsx` · `form_id=fieldstats_fieldstats_roc` · JSON: `fieldstats_audit_json`
- `fieldstats.sample_size_diagnostic` → `example_odk_showcase_fieldstats_sample_size_diagnostic.xlsx` · `form_id=fieldstats_fieldstats_sample_size_diagnostic` · JSON: `fieldstats_audit_json`
- `fieldstats.sample_size_proportion` → `example_odk_showcase_fieldstats_sample_size_proportion.xlsx` · `form_id=fieldstats_fieldstats_sample_size_proportion` · JSON: `fieldstats_audit_json`
- `fieldstats.sample_size_two_proportions` → `example_odk_showcase_fieldstats_sample_size_two_proportions.xlsx` · `form_id=fieldstats_fieldstats_sample_size_two_proportions` · JSON: `fieldstats_audit_json`
- `fieldstats.summary` → `example_odk_showcase_fieldstats_summary.xlsx` · `form_id=fieldstats_fieldstats_summary` · JSON: `fieldstats_audit_json`

### `gamedeck` — 1 form(s)

- `gamedeck.snapshot` → `example_odk_showcase_gamedeck_snapshot.xlsx` · `form_id=gamedeck_gamedeck_snapshot` · JSON: `gamedeck_state_json`, `gamedeck_audit_json`

### `gpstargetnavigator` — 1 form(s)

- `gps_target_navigator` → `example_odk_showcase_gps_target_navigator.xlsx` · `form_id=gpstargetnavigator_gps_target_navigator` · JSON: `nav_methodmesh_full_json`

### `hamradio` — 9 form(s)

- `ham.activity.pskreporter` → `example_odk_showcase_ham_activity_pskreporter.xlsx` · `form_id=hamradio_ham_activity_pskreporter` · JSON: `ham_psk_band_counts_json`, `ham_psk_mode_counts_json`
- `ham.antenna.calculate` → `example_odk_showcase_ham_antenna_calculate.xlsx` · `form_id=hamradio_ham_antenna_calculate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.band.recommend` → `example_odk_showcase_ham_band_recommend.xlsx` · `form_id=hamradio_ham_band_recommend` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.dashboard` → `example_odk_showcase_ham_dashboard.xlsx` · `form_id=hamradio_ham_dashboard` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.link.calculate` → `example_odk_showcase_ham_link_calculate.xlsx` · `form_id=hamradio_ham_link_calculate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.maidenhead.convert` → `example_odk_showcase_ham_maidenhead_convert.xlsx` · `form_id=hamradio_ham_maidenhead_convert` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.path.calculate` → `example_odk_showcase_ham_path_calculate.xlsx` · `form_id=hamradio_ham_path_calculate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.spaceweather.snapshot` → `example_odk_showcase_ham_spaceweather_snapshot.xlsx` · `form_id=hamradio_ham_spaceweather_snapshot` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `ham.swr.calculate` → `example_odk_showcase_ham_swr_calculate.xlsx` · `form_id=hamradio_ham_swr_calculate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `imageredaction` — 1 form(s)

- `image.redact` → `example_odk_showcase_image_redact.xlsx` · `form_id=imageredaction_image_redact` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `labbench` — 13 form(s)

- `labbench.aliquot` → `example_odk_showcase_labbench_aliquot.xlsx` · `form_id=labbench_labbench_aliquot` · JSON: `lab_aliquot_audit_json`
- `labbench.cell_dilution` → `example_odk_showcase_labbench_cell_dilution.xlsx` · `form_id=labbench_labbench_cell_dilution` · JSON: `lab_cell_dilution_audit_json`
- `labbench.centrifuge` → `example_odk_showcase_labbench_centrifuge.xlsx` · `form_id=labbench_labbench_centrifuge` · JSON: `lab_centrifuge_audit_json`
- `labbench.concentration` → `example_odk_showcase_labbench_concentration.xlsx` · `form_id=labbench_labbench_concentration` · JSON: `lab_concentration_audit_json`
- `labbench.dashboard` → `example_odk_showcase_labbench_dashboard.xlsx` · `form_id=labbench_labbench_dashboard` · JSON: `labbench_dashboard_audit_json`
- `labbench.dilution` → `example_odk_showcase_labbench_dilution.xlsx` · `form_id=labbench_labbench_dilution` · JSON: `lab_dilution_audit_json`
- `labbench.hemocytometer` → `example_odk_showcase_labbench_hemocytometer.xlsx` · `form_id=labbench_labbench_hemocytometer` · JSON: `lab_hemocytometer_audit_json`
- `labbench.master_mix` → `example_odk_showcase_labbench_master_mix.xlsx` · `form_id=labbench_labbench_master_mix` · JSON: `lab_master_mix_components_json`, `lab_master_mix_audit_json`
- `labbench.molar_solution` → `example_odk_showcase_labbench_molar_solution.xlsx` · `form_id=labbench_labbench_molar_solution` · JSON: `lab_molar_solution_audit_json`
- `labbench.nucleic_acid` → `example_odk_showcase_labbench_nucleic_acid.xlsx` · `form_id=labbench_labbench_nucleic_acid` · JSON: `lab_nucleic_acid_audit_json`
- `labbench.percent_solution` → `example_odk_showcase_labbench_percent_solution.xlsx` · `form_id=labbench_labbench_percent_solution` · JSON: `lab_percent_solution_audit_json`
- `labbench.reconstitute` → `example_odk_showcase_labbench_reconstitute.xlsx` · `form_id=labbench_labbench_reconstitute` · JSON: `lab_reconstitute_audit_json`
- `labbench.serial_dilution` → `example_odk_showcase_labbench_serial_dilution.xlsx` · `form_id=labbench_labbench_serial_dilution` · JSON: `lab_serial_dilution_steps_json`, `lab_serial_dilution_audit_json`

### `magnifier` — 1 form(s)

- `visual.magnifier.capture` → `example_odk_showcase_visual_magnifier_capture.xlsx` · `form_id=magnifier_visual_magnifier_capture` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `mlkittranslate` — 1 form(s)

- `mlkit.translate` → `example_odk_showcase_mlkit_translate.xlsx` · `form_id=mlkittranslate_mlkit_translate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `mlkitvision` — 1 form(s)

- `mlkit.vision.analyze` → `example_odk_showcase_mlkit_vision_analyze.xlsx` · `form_id=mlkitvision_mlkit_vision_analyze` · JSON: `mlkit_barcodes_json`, `mlkit_labels_json`

### `multicounter` — 1 form(s)

- `counter.multientity` → `example_odk_showcase_counter_multientity.xlsx` · `form_id=multicounter_counter_multientity` · JSON: `counter_entities_json`, `counter_audit_json`

### `music` — 33 form(s)

- `music.arpeggiator` → `example_odk_showcase_music_arpeggiator.xlsx` · `form_id=music_music_arpeggiator` · JSON: `music_arpeggiator_notes_json`, `music_arpeggiator_audit_json`
- `music.bassline` → `example_odk_showcase_music_bassline.xlsx` · `form_id=music_music_bassline` · JSON: `music_bassline_notes_json`, `music_bassline_audit_json`
- `music.beat_pads` → `example_odk_showcase_music_beat_pads.xlsx` · `form_id=music_music_beat_pads` · JSON: `music_beat_pads_hits_json`, `music_beat_pads_audit_json`
- `music.chord` → `example_odk_showcase_music_chord.xlsx` · `form_id=music_music_chord` · JSON: `music_chord_matches_json`, `music_chord_audit_json`
- `music.chord_guide` → `example_odk_showcase_music_chord_guide.xlsx` · `form_id=music_music_chord_guide` · JSON: `music_chord_guide_audit_json`
- `music.chord_progression` → `example_odk_showcase_music_chord_progression.xlsx` · `form_id=music_music_chord_progression` · JSON: `music_progression_chords_json`, `music_progression_audit_json`
- `music.delay_time` → `example_odk_showcase_music_delay_time.xlsx` · `form_id=music_music_delay_time` · JSON: `music_delay_time_audit_json`
- `music.drum_machine` → `example_odk_showcase_music_drum_machine.xlsx` · `form_id=music_music_drum_machine` · JSON: `music_drum_machine_pattern_json`, `music_drum_machine_audit_json`
- `music.euclidean_rhythm` → `example_odk_showcase_music_euclidean_rhythm.xlsx` · `form_id=music_music_euclidean_rhythm` · JSON: `music_euclidean_pattern_json`, `music_euclidean_audit_json`
- `music.harmonics` → `example_odk_showcase_music_harmonics.xlsx` · `form_id=music_music_harmonics` · JSON: `music_harmonics_harmonics_json`, `music_harmonics_audit_json`
- `music.interval` → `example_odk_showcase_music_interval.xlsx` · `form_id=music_music_interval` · JSON: `music_interval_audit_json`
- `music.jam_dashboard` → `example_odk_showcase_music_jam_dashboard.xlsx` · `form_id=music_music_jam_dashboard` · JSON: `music_jam_dashboard_drum_pattern_json`, `music_jam_dashboard_snapshot_json`, `music_jam_dashboard_audit_json`
- `music.live_looper` → `example_odk_showcase_music_live_looper.xlsx` · `form_id=music_music_live_looper` · JSON: `music_live_looper_layers_json`, `music_live_looper_audit_json`
- `music.melody_sequence` → `example_odk_showcase_music_melody_sequence.xlsx` · `form_id=music_music_melody_sequence` · JSON: `music_melody_sequence_notes_json`, `music_melody_sequence_audit_json`
- `music.metronome` → `example_odk_showcase_music_metronome.xlsx` · `form_id=music_music_metronome` · JSON: `music_metronome_audit_json`
- `music.motif_generator` → `example_odk_showcase_music_motif_generator.xlsx` · `form_id=music_music_motif_generator` · JSON: `music_motif_variations_json`, `music_motif_audit_json`
- `music.note_frequency` → `example_odk_showcase_music_note_frequency.xlsx` · `form_id=music_music_note_frequency` · JSON: `music_note_frequency_audit_json`
- `music.pattern_mutation` → `example_odk_showcase_music_pattern_mutation.xlsx` · `form_id=music_music_pattern_mutation` · JSON: `music_pattern_mutation_output_json`, `music_pattern_mutation_audit_json`
- `music.performance_dashboard` → `example_odk_showcase_music_performance_dashboard.xlsx` · `form_id=music_music_performance_dashboard` · JSON: `music_performance_dashboard_songs_json`, `music_performance_dashboard_audit_json`
- `music.polyrhythm` → `example_odk_showcase_music_polyrhythm.xlsx` · `form_id=music_music_polyrhythm` · JSON: `music_polyrhythm_pulses_json`, `music_polyrhythm_audit_json`
- `music.practice_dashboard` → `example_odk_showcase_music_practice_dashboard.xlsx` · `form_id=music_music_practice_dashboard` · JSON: `music_practice_dashboard_audit_json`
- `music.probability_pattern` → `example_odk_showcase_music_probability_pattern.xlsx` · `form_id=music_music_probability_pattern` · JSON: `music_probability_probabilities_json`, `music_probability_pattern_json`, `music_probability_audit_json`
- `music.reference` → `example_odk_showcase_music_reference.xlsx` · `form_id=music_music_reference` · JSON: `music_reference_audit_json`
- `music.reference_dashboard` → `example_odk_showcase_music_reference_dashboard.xlsx` · `form_id=music_music_reference_dashboard` · JSON: `music_reference_dashboard_audit_json`
- `music.rhythm_capture` → `example_odk_showcase_music_rhythm_capture.xlsx` · `form_id=music_music_rhythm_capture` · JSON: `music_rhythm_capture_pattern_json`, `music_rhythm_capture_raw_offsets_ms_json`, `music_rhythm_capture_quantized_offsets_ms_json`, `music_rhythm_capture_audit_json`
- `music.setlist_timing` → `example_odk_showcase_music_setlist_timing.xlsx` · `form_id=music_music_setlist_timing` · JSON: `music_setlist_timing_audit_json`
- `music.song_sketch` → `example_odk_showcase_music_song_sketch.xlsx` · `form_id=music_music_song_sketch` · JSON: `music_song_sketch_sketch_json`, `music_song_sketch_audit_json`
- `music.song_sketch_dashboard` → `example_odk_showcase_music_song_sketch_dashboard.xlsx` · `form_id=music_music_song_sketch_dashboard` · JSON: `music_song_sketch_dashboard_snapshot_json`, `music_song_sketch_dashboard_audit_json`
- `music.tap_tempo` → `example_odk_showcase_music_tap_tempo.xlsx` · `form_id=music_music_tap_tempo` · JSON: `music_tap_tempo_audit_json`
- `music.temperament` → `example_odk_showcase_music_temperament.xlsx` · `form_id=music_music_temperament` · JSON: `music_temperament_audit_json`
- `music.tempo_convert` → `example_odk_showcase_music_tempo_convert.xlsx` · `form_id=music_music_tempo_convert` · JSON: `music_tempo_convert_audit_json`
- `music.tempo_trainer` → `example_odk_showcase_music_tempo_trainer.xlsx` · `form_id=music_music_tempo_trainer` · JSON: `music_tempo_trainer_sequence_json`, `music_tempo_trainer_audit_json`
- `music.transpose` → `example_odk_showcase_music_transpose.xlsx` · `form_id=music_music_transpose` · JSON: `music_transpose_audit_json`

### `networktools` — 1 form(s)

- `network.tools` → `example_odk_showcase_network_tools.xlsx` · `form_id=networktools_network_tools` · JSON: `network_result_json`

### `nfc` — 10 form(s)

- `nfc_credential_provisioning` → `example_odk_showcase_nfc_credential_provisioning.xlsx` · `form_id=nfc_nfc_credential_provisioning` · JSON: `credential_payload_json`, `credential_provisioning_json`
- `nfc_credential_verification` → `example_odk_showcase_nfc_credential_verification.xlsx` · `form_id=nfc_nfc_credential_verification` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `nfc_tag_read` → `example_odk_showcase_nfc_tag_read.xlsx` · `form_id=nfc_nfc_tag_read` · JSON: `ndef_records_json`
- `nfc_tag_wipe` → `example_odk_showcase_nfc_tag_wipe.xlsx` · `form_id=nfc_nfc_tag_wipe` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `nfc_tag_write` → `example_odk_showcase_nfc_tag_write.xlsx` · `form_id=nfc_nfc_tag_write` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `protocol_nfc_check` → `example_odk_showcase_protocol_nfc_check.xlsx` · `form_id=nfc_protocol_nfc_check` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `protocol_nfc_complete` → `example_odk_showcase_protocol_nfc_complete.xlsx` · `form_id=nfc_protocol_nfc_complete` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `protocol_nfc_override` → `example_odk_showcase_protocol_nfc_override.xlsx` · `form_id=nfc_protocol_nfc_override` · JSON: `protocol_payload_json`
- `protocol_nfc_provision` → `example_odk_showcase_protocol_nfc_provision.xlsx` · `form_id=nfc_protocol_nfc_provision` · JSON: `protocol_payload_json`
- `protocol_nfc_reconstruct` → `example_odk_showcase_protocol_nfc_reconstruct.xlsx` · `form_id=nfc_protocol_nfc_reconstruct` · JSON: `protocol_payload_json`

### `odkformlauncher` — 1 form(s)

- `odk_form_launcher` → `example_odk_showcase_odk_form_launcher.xlsx` · `form_id=odkformlauncher_odk_form_launcher` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `pluscodecapture` — 1 form(s)

- `plus_code.capture` → `example_odk_showcase_plus_code_capture.xlsx` · `form_id=pluscodecapture_plus_code_capture` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `providercommands` — 1 form(s)

- `provider.command.run` → `example_odk_showcase_provider_command_run.xlsx` · `form_id=providercommands_provider_command_run` · JSON: `provider_result_json`

### `psychomotorvigilance` — 1 form(s)

- `psychomotor.vigilance.run` → `example_odk_showcase_psychomotor_vigilance_run.xlsx` · `form_id=psychomotorvigilance_psychomotor_vigilance_run` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `qrcode` — 1 form(s)

- `barcode.scan` → `example_odk_showcase_barcode_scan.xlsx` · `form_id=qrcode_barcode_scan` · JSON: `scan_methodmesh_full_json`

### `questionprimitives` — 4 form(s)

- `question.number` → `example_odk_showcase_question_number.xlsx` · `form_id=questionprimitives_question_number` · JSON: `question_answer_json`
- `question.select_multiple` → `example_odk_showcase_question_select_multiple.xlsx` · `form_id=questionprimitives_question_select_multiple` · JSON: `question_answer_json`, `question_options_json`, `question_exclusive_options_json`
- `question.select_one` → `example_odk_showcase_question_select_one.xlsx` · `form_id=questionprimitives_question_select_one` · JSON: `question_answer_json`, `question_options_json`
- `question.text` → `example_odk_showcase_question_text.xlsx` · `form_id=questionprimitives_question_text` · JSON: `question_answer_json`

### `randomnumber` — 1 form(s)

- `random.number.generate` → `example_odk_showcase_random_number_generate.xlsx` · `form_id=randomnumber_random_number_generate` · JSON: `random_numbers_json`

### `referencelibrary` — 2 form(s)

- `reference.library.email` → `example_odk_showcase_reference_library_email.xlsx` · `form_id=referencelibrary_reference_library_email` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `reference.library.open` → `example_odk_showcase_reference_library_open.xlsx` · `form_id=referencelibrary_reference_library_open` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `sampling` — 1 form(s)

- `sampling.run` → `example_odk_showcase_sampling_run.xlsx` · `form_id=sampling_sampling_run` · JSON: `sampling_audit_json`

### `scaledphoto` — 1 form(s)

- `scaled_photo.capture` → `example_odk_showcase_scaled_photo_capture.xlsx` · `form_id=scaledphoto_scaled_photo_capture` · JSON: `grid_selection_json`

### `scoring` — 11 form(s)

- `score.counter` → `example_odk_showcase_score_counter.xlsx` · `form_id=scoring_score_counter` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.high_score` → `example_odk_showcase_score_high_score.xlsx` · `form_id=scoring_score_high_score` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.match` → `example_odk_showcase_score_match.xlsx` · `form_id=scoring_score_match` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.race_to` → `example_odk_showcase_score_race_to.xlsx` · `form_id=scoring_score_race_to` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.rounds` → `example_odk_showcase_score_rounds.xlsx` · `form_id=scoring_score_rounds` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.session.finish` → `example_odk_showcase_score_session_finish.xlsx` · `form_id=scoring_score_session_finish` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.session.read` → `example_odk_showcase_score_session_read.xlsx` · `form_id=scoring_score_session_read` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.session.resume` → `example_odk_showcase_score_session_resume.xlsx` · `form_id=scoring_score_session_resume` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.set_match` → `example_odk_showcase_score_set_match.xlsx` · `form_id=scoring_score_set_match` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.sports` → `example_odk_showcase_score_sports.xlsx` · `form_id=scoring_score_sports` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `score.tally` → `example_odk_showcase_score_tally.xlsx` · `form_id=scoring_score_tally` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `sensorfirmwareinstaller` — 1 form(s)

- `esp32.sensor_profile_install` → `example_odk_showcase_esp32_sensor_profile_install.xlsx` · `form_id=sensorfirmwareinstaller_esp32_sensor_profile_install` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `sensorprovisioner` — 1 form(s)

- `sensor_node_provisioner` → `example_odk_showcase_sensor_node_provisioner.xlsx` · `form_id=sensorprovisioner_sensor_node_provisioner` · JSON: `sensor_manifest_json`, `sensor_command_response_json`, `sensor_confirmation_reading_json`

### `sensorread` — 1 form(s)

- `sensor.read` → `example_odk_showcase_sensor_read.xlsx` · `form_id=sensorread_sensor_read` · JSON: `sensor_reading_json`, `sensor_trace_json`, `sensor_summary_json`, `in_range_devices_json`

### `sms` — 1 form(s)

- `sms.send` → `example_odk_showcase_sms_send.xlsx` · `form_id=sms_sms_send` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `soundgenerator` — 1 form(s)

- `sound.play` → `example_odk_showcase_sound_play.xlsx` · `form_id=soundgenerator_sound_play` · JSON: `sound_audit_json`

### `spatialgeometry` — 3 form(s)

- `geometry_distance_estimation` → `example_odk_showcase_geometry_distance_estimation.xlsx` · `form_id=spatialgeometry_geometry_distance_estimation` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `slope_inclination_measurement` → `example_odk_showcase_slope_inclination_measurement.xlsx` · `form_id=spatialgeometry_slope_inclination_measurement` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `tree_height_measurement` → `example_odk_showcase_tree_height_measurement.xlsx` · `form_id=spatialgeometry_tree_height_measurement` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `speechtranscription` — 1 form(s)

- `speech.transcribe` → `example_odk_showcase_speech_transcribe.xlsx` · `form_id=speechtranscription_speech_transcribe` · JSON: `speech_alternatives_json`

### `surveying` — 13 form(s)

- `survey.area` → `example_odk_showcase_survey_area.xlsx` · `form_id=surveying_survey_area` · JSON: `survey_metadata_json`
- `survey.bearing_distance` → `example_odk_showcase_survey_bearing_distance.xlsx` · `form_id=surveying_survey_bearing_distance` · JSON: `survey_metadata_json`
- `survey.chainage_offset` → `example_odk_showcase_survey_chainage_offset.xlsx` · `form_id=surveying_survey_chainage_offset` · JSON: `survey_metadata_json`
- `survey.forward_coordinate` → `example_odk_showcase_survey_forward_coordinate.xlsx` · `form_id=surveying_survey_forward_coordinate` · JSON: `survey_metadata_json`
- `survey.gps_average` → `example_odk_showcase_survey_gps_average.xlsx` · `form_id=surveying_survey_gps_average` · JSON: `survey_metadata_json`
- `survey.grade` → `example_odk_showcase_survey_grade.xlsx` · `form_id=surveying_survey_grade` · JSON: `survey_metadata_json`
- `survey.intersection` → `example_odk_showcase_survey_intersection.xlsx` · `form_id=surveying_survey_intersection` · JSON: `survey_metadata_json`
- `survey.level_reduce` → `example_odk_showcase_survey_level_reduce.xlsx` · `form_id=surveying_survey_level_reduce` · JSON: `survey_metadata_json`
- `survey.levelling_book` → `example_odk_showcase_survey_levelling_book.xlsx` · `form_id=surveying_survey_levelling_book` · JSON: `survey_metadata_json`
- `survey.offset_point` → `example_odk_showcase_survey_offset_point.xlsx` · `form_id=surveying_survey_offset_point` · JSON: `survey_metadata_json`
- `survey.setout` → `example_odk_showcase_survey_setout.xlsx` · `form_id=surveying_survey_setout` · JSON: `survey_metadata_json`
- `survey.traverse` → `example_odk_showcase_survey_traverse.xlsx` · `form_id=surveying_survey_traverse` · JSON: `survey_metadata_json`
- `survey.traverse_book` → `example_odk_showcase_survey_traverse_book.xlsx` · `form_id=surveying_survey_traverse_book` · JSON: `survey_metadata_json`

### `svgselector` — 1 form(s)

- `svg.select` → `example_odk_showcase_svg_select.xlsx` · `form_id=svgselector_svg_select` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `tabletoputilities` — 1 form(s)

- `tabletop.state.manage` → `example_odk_showcase_tabletop_state_manage.xlsx` · `form_id=tabletoputilities_tabletop_state_manage` · JSON: `tabletop_state_json`, `tabletop_audit_json`

### `texttools` — 10 form(s)

- `text.case` → `example_odk_showcase_text_case.xlsx` · `form_id=texttools_text_case` · JSON: `case_methodmesh_full_json`
- `text.clean` → `example_odk_showcase_text_clean.xlsx` · `form_id=texttools_text_clean` · JSON: `clean_methodmesh_full_json`
- `text.count` → `example_odk_showcase_text_count.xlsx` · `form_id=texttools_text_count` · JSON: `count_methodmesh_full_json`
- `text.encode` → `example_odk_showcase_text_encode.xlsx` · `form_id=texttools_text_encode` · JSON: `encode_methodmesh_full_json`
- `text.extract` → `example_odk_showcase_text_extract.xlsx` · `form_id=texttools_text_extract` · JSON: `extract_text_matches_json`, `extract_methodmesh_full_json`
- `text.lines` → `example_odk_showcase_text_lines.xlsx` · `form_id=texttools_text_lines` · JSON: `lines_methodmesh_full_json`
- `text.replace` → `example_odk_showcase_text_replace.xlsx` · `form_id=texttools_text_replace` · JSON: `replace_methodmesh_full_json`
- `text.slug` → `example_odk_showcase_text_slug.xlsx` · `form_id=texttools_text_slug` · JSON: `slug_methodmesh_full_json`
- `text.split_join` → `example_odk_showcase_text_split_join.xlsx` · `form_id=texttools_text_split_join` · JSON: `split_methodmesh_full_json`
- `text.truncate` → `example_odk_showcase_text_truncate.xlsx` · `form_id=texttools_text_truncate` · JSON: `truncate_methodmesh_full_json`

### `time_tools` — 6 form(s)

- `time.countdown` → `example_odk_showcase_time_countdown.xlsx` · `form_id=time_tools_time_countdown` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `time.duration.calculate` → `example_odk_showcase_time_duration_calculate.xlsx` · `form_id=time_tools_time_duration_calculate` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `time.elapsed` → `example_odk_showcase_time_elapsed.xlsx` · `form_id=time_tools_time_elapsed` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `time.interval` → `example_odk_showcase_time_interval.xlsx` · `form_id=time_tools_time_interval` · JSON: _no capability-owned JSON field resolved; see ambiguity log_
- `time.stopwatch` → `example_odk_showcase_time_stopwatch.xlsx` · `form_id=time_tools_time_stopwatch` · JSON: `laps_json`
- `time.until` → `example_odk_showcase_time_until.xlsx` · `form_id=time_tools_time_until` · JSON: _no capability-owned JSON field resolved; see ambiguity log_

### `trustedtimestamp` — 1 form(s)

- `integrity.trusted_timestamp` → `example_odk_showcase_integrity_trusted_timestamp.xlsx` · `form_id=trustedtimestamp_integrity_trusted_timestamp` · JSON: `trusted_timestamp_full_json`

### `visualacuity` — 1 form(s)

- `visual_acuity.measure` → `example_odk_showcase_visual_acuity_measure.xlsx` · `form_id=visualacuity_visual_acuity_measure` · JSON: `visual_acuity_audit_json`

### `webactions` — 4 form(s)

- `web.odk_central_roundtrip` → `example_odk_showcase_web_odk_central_roundtrip.xlsx` · `form_id=webactions_web_odk_central_roundtrip` · JSON: `web_central_audit_json`
- `web.open` → `example_odk_showcase_web_open.xlsx` · `form_id=webactions_web_open` · JSON: `web_open_audit_json`
- `web.precooked_enketo` → `example_odk_showcase_web_precooked_enketo.xlsx` · `form_id=webactions_web_precooked_enketo` · JSON: `web_enketo_audit_json`
- `web.roundtrip` → `example_odk_showcase_web_roundtrip.xlsx` · `form_id=webactions_web_roundtrip` · JSON: `web_roundtrip_audit_json`
