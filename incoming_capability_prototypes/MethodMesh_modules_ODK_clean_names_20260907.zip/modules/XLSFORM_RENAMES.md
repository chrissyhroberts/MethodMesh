# MethodMesh XLSForm rename and identity cleanup

Cleanup date: 2026-09-07

## Policy

- Repository filenames are normalized to `example_odk_<purpose>.xlsx` using lower snake case.
- Filename changes do **not** imply ODK identity changes.
- Existing nonblank `form_id` values are retained, including nonstandard historical IDs, because `form_id` is an ODK compatibility contract.
- Four malformed `settings` sheets were repaired. Existing Arcade, GameDeck, and ODK Form Launcher IDs were recovered and preserved; Spatial Geometry had no usable `form_id`, so `spatialgeometry_example` was created.
- Machine-oriented titles were replaced with human-readable titles. Forms whose title/settings definition changed were version-bumped to `2026090703`; the four structural settings repairs use `2026090702`.
- Capability method IDs, invocation contracts, survey logic, choices, and return payloads were not changed by this cleanup.

## Summary

- Legacy XLSForms reviewed: **147**
- Files renamed: **118**
- Titles/version metadata cleaned: **63**
- Structurally malformed settings sheets repaired: **4**
- Blank form IDs after cleanup: **0**
- Duplicate form IDs after cleanup: **0**
- Blank versions after cleanup: **0**
- Machine-token titles remaining: **0**
- Historical non-lower-snake `form_id`s intentionally retained: **34**
- Historical non-`YYYYMMDDrr` versions intentionally retained on otherwise unchanged forms: **10**

## Structural settings repairs

| Module | Form | Result |
|---|---|---|
| arcade | `example_odk_arcade.xlsx` | Converted vertical settings to standard row layout; preserved `methodmesh_arcade_example`; version `2026090702`. |
| gamedeck | `example_odk_gamedeck.xlsx` | Converted vertical settings to standard row layout; preserved `methodmesh_gamedeck_example`; version `2026090702`. |
| odkformlauncher | `example_odk_odk_form_launcher.xlsx` | Converted vertical settings to standard row layout; preserved `methodmesh_protocol_multimethod_workflow`; version `2026090702`. |
| spatialgeometry | `example_odk_spatialgeometry.xlsx` | Rebuilt malformed settings row; created `spatialgeometry_example`; version `2026090702`. |

## Filename mapping

| Module | Old filename | New filename |
|---|---|---|
| acoustics | `example_odk_Acoustics.xlsx` | `example_odk_acoustics.xlsx` |
| arcade | `example_odk_Arcade.xlsx` | `example_odk_arcade.xlsx` |
| astronomy | `example_odk_Astronomy.xlsx` | `example_odk_astronomy.xlsx` |
| attestation | `example_odk_attestation.anchor_bundle.xlsx` | `example_odk_attestation_anchor_bundle.xlsx` |
| attestation | `example_odk_attestation.create_Fingerprint.xlsx` | `example_odk_attestation_create_fingerprint.xlsx` |
| attestation | `example_odk_attestation.create_Nfc.xlsx` | `example_odk_attestation_create_nfc.xlsx` |
| attestation | `example_odk_attestation.create_Password.xlsx` | `example_odk_attestation_create_password.xlsx` |
| attestation | `example_odk_attestation.create_Pin.xlsx` | `example_odk_attestation_create_pin.xlsx` |
| attestation | `example_odk_attestation.create_Qr.xlsx` | `example_odk_attestation_create_qr.xlsx` |
| aviation | `example_odk_Aviation.xlsx` | `example_odk_aviation.xlsx` |
| calibratedscale | `example_odk_calibrated_scale_MinMax.xlsx` | `example_odk_calibrated_scale_minmax.xlsx` |
| calibratedscale | `example_odk_calibrated_scale_Range.xlsx` | `example_odk_calibrated_scale_range.xlsx` |
| calibratedscale | `example_odk_calibrated_scale_Vertical.xlsx` | `example_odk_calibrated_scale_vertical.xlsx` |
| choiceexperiment | `example_odk_dce.conjoint.xlsx` | `example_odk_dce_conjoint.xlsx` |
| choiceexperiment | `example_odk_dce.maxdiff.xlsx` | `example_odk_dce_maxdiff.xlsx` |
| choiceexperiment | `example_odk_dce.pairwise.xlsx` | `example_odk_dce_pairwise.xlsx` |
| choiceexperiment | `example_odk_dce.points.xlsx` | `example_odk_dce_points.xlsx` |
| choiceexperiment | `example_odk_dce.ranking.xlsx` | `example_odk_dce_ranking.xlsx` |
| clinicalinstruments | `example_odk_ClinicalInstruments.xlsx` | `example_odk_clinicalinstruments.xlsx` |
| compass | `example_odk_Compass.xlsx` | `example_odk_compass.xlsx` |
| conversationtranslate | `example_odk_conversation.translate.xlsx` | `example_odk_conversation_translate.xlsx` |
| conversions | `example_odk_conversion.calculate.xlsx` | `example_odk_conversion_calculate.xlsx` |
| cryptography | `example_odk_crypto.file.encrypt.xlsx` | `example_odk_crypto_file_encrypt.xlsx` |
| cryptography | `example_odk_crypto.text.encrypt.xlsx` | `example_odk_crypto_text_encrypt.xlsx` |
| datatools | `example_odk_data.tools.xlsx` | `example_odk_data_tools.xlsx` |
| digitalsigning | `example_odk_document.sign_pdf.xlsx` | `example_odk_document_sign_pdf.xlsx` |
| diving | `example_odk_Diving.xlsx` | `example_odk_diving.xlsx` |
| documentscanner | `example_odk_document.scan.xlsx` | `example_odk_document_scan.xlsx` |
| earthscience | `example_odk_EarthScience.xlsx` | `example_odk_earthscience.xlsx` |
| emergency | `example_odk_Emergency.xlsx` | `example_odk_emergency.xlsx` |
| expenses | `example_odk_Expenses.xlsx` | `example_odk_expenses.xlsx` |
| fieldstats | `example_odk_FieldStats_CompareBinary.xlsx` | `example_odk_fieldstats_comparebinary.xlsx` |
| fieldstats | `example_odk_FieldStats_DetectionLimit.xlsx` | `example_odk_fieldstats_detectionlimit.xlsx` |
| fieldstats | `example_odk_FieldStats_Diagnostic2x2.xlsx` | `example_odk_fieldstats_diagnostic2x2.xlsx` |
| fieldstats | `example_odk_FieldStats_Probability.xlsx` | `example_odk_fieldstats_probability.xlsx` |
| fieldstats | `example_odk_FieldStats_Proportion.xlsx` | `example_odk_fieldstats_proportion.xlsx` |
| fieldstats | `example_odk_FieldStats_ROC.xlsx` | `example_odk_fieldstats_roc.xlsx` |
| fieldstats | `example_odk_FieldStats_SampleSizeDiagnostic.xlsx` | `example_odk_fieldstats_samplesizediagnostic.xlsx` |
| fieldstats | `example_odk_FieldStats_SampleSizeProportion.xlsx` | `example_odk_fieldstats_samplesizeproportion.xlsx` |
| fieldstats | `example_odk_FieldStats_SampleSizeTwoProportions.xlsx` | `example_odk_fieldstats_samplesizetwoproportions.xlsx` |
| fieldstats | `example_odk_FieldStats_Summary.xlsx` | `example_odk_fieldstats_summary.xlsx` |
| gamedeck | `example_odk_GameDeck.xlsx` | `example_odk_gamedeck.xlsx` |
| hamradio | `example_odk_HamRadio.xlsx` | `example_odk_hamradio.xlsx` |
| imageredaction | `example_odk_image.redact.xlsx` | `example_odk_image_redact.xlsx` |
| labbench | `example_odk_labbench.aliquot.xlsx` | `example_odk_labbench_aliquot.xlsx` |
| labbench | `example_odk_labbench.cell_dilution.xlsx` | `example_odk_labbench_cell_dilution.xlsx` |
| labbench | `example_odk_labbench.centrifuge.xlsx` | `example_odk_labbench_centrifuge.xlsx` |
| labbench | `example_odk_labbench.concentration.xlsx` | `example_odk_labbench_concentration.xlsx` |
| labbench | `example_odk_labbench.dashboard.xlsx` | `example_odk_labbench_dashboard.xlsx` |
| labbench | `example_odk_labbench.dilution.xlsx` | `example_odk_labbench_dilution.xlsx` |
| labbench | `example_odk_labbench.hemocytometer.xlsx` | `example_odk_labbench_hemocytometer.xlsx` |
| labbench | `example_odk_labbench.master_mix.xlsx` | `example_odk_labbench_master_mix.xlsx` |
| labbench | `example_odk_labbench.molar_solution.xlsx` | `example_odk_labbench_molar_solution.xlsx` |
| labbench | `example_odk_labbench.nucleic_acid.xlsx` | `example_odk_labbench_nucleic_acid.xlsx` |
| labbench | `example_odk_labbench.percent_solution.xlsx` | `example_odk_labbench_percent_solution.xlsx` |
| labbench | `example_odk_labbench.reconstitute.xlsx` | `example_odk_labbench_reconstitute.xlsx` |
| labbench | `example_odk_labbench.serial_dilution.xlsx` | `example_odk_labbench_serial_dilution.xlsx` |
| magnifier | `example_odk_visual.magnifier.capture.xlsx` | `example_odk_visual_magnifier_capture.xlsx` |
| multicounter | `example_odk_Multicounter.xlsx` | `example_odk_multicounter.xlsx` |
| music | `example_odk_Arpeggiator.xlsx` | `example_odk_arpeggiator.xlsx` |
| music | `example_odk_Bassline.xlsx` | `example_odk_bassline.xlsx` |
| music | `example_odk_BeatPads.xlsx` | `example_odk_beatpads.xlsx` |
| music | `example_odk_Chord.xlsx` | `example_odk_chord.xlsx` |
| music | `example_odk_ChordGuide.xlsx` | `example_odk_chordguide.xlsx` |
| music | `example_odk_ChordProgression.xlsx` | `example_odk_chordprogression.xlsx` |
| music | `example_odk_DelayTime.xlsx` | `example_odk_delaytime.xlsx` |
| music | `example_odk_DrumMachine.xlsx` | `example_odk_drummachine.xlsx` |
| music | `example_odk_EuclideanRhythm.xlsx` | `example_odk_euclideanrhythm.xlsx` |
| music | `example_odk_Harmonics.xlsx` | `example_odk_harmonics.xlsx` |
| music | `example_odk_Interval.xlsx` | `example_odk_interval.xlsx` |
| music | `example_odk_JamDashboard.xlsx` | `example_odk_jamdashboard.xlsx` |
| music | `example_odk_LiveLooper.xlsx` | `example_odk_livelooper.xlsx` |
| music | `example_odk_MelodySequence.xlsx` | `example_odk_melodysequence.xlsx` |
| music | `example_odk_Metronome.xlsx` | `example_odk_metronome.xlsx` |
| music | `example_odk_MotifGenerator.xlsx` | `example_odk_motifgenerator.xlsx` |
| music | `example_odk_MusicReference.xlsx` | `example_odk_musicreference.xlsx` |
| music | `example_odk_NoteFrequency.xlsx` | `example_odk_notefrequency.xlsx` |
| music | `example_odk_PatternMutation.xlsx` | `example_odk_patternmutation.xlsx` |
| music | `example_odk_PerformanceDashboard.xlsx` | `example_odk_performancedashboard.xlsx` |
| music | `example_odk_Polyrhythm.xlsx` | `example_odk_polyrhythm.xlsx` |
| music | `example_odk_PracticeDashboard.xlsx` | `example_odk_practicedashboard.xlsx` |
| music | `example_odk_ProbabilityPattern.xlsx` | `example_odk_probabilitypattern.xlsx` |
| music | `example_odk_ReferenceDashboard.xlsx` | `example_odk_referencedashboard.xlsx` |
| music | `example_odk_RhythmCapture.xlsx` | `example_odk_rhythmcapture.xlsx` |
| music | `example_odk_SetListTiming.xlsx` | `example_odk_setlisttiming.xlsx` |
| music | `example_odk_SongSketch.xlsx` | `example_odk_songsketch.xlsx` |
| music | `example_odk_SongSketchDashboard.xlsx` | `example_odk_songsketchdashboard.xlsx` |
| music | `example_odk_TapTempo.xlsx` | `example_odk_taptempo.xlsx` |
| music | `example_odk_Temperament.xlsx` | `example_odk_temperament.xlsx` |
| music | `example_odk_TempoConvert.xlsx` | `example_odk_tempoconvert.xlsx` |
| music | `example_odk_TempoTrainer.xlsx` | `example_odk_tempotrainer.xlsx` |
| music | `example_odk_Transpose.xlsx` | `example_odk_transpose.xlsx` |
| networktools | `example_odk_network.tools.xlsx` | `example_odk_network_tools.xlsx` |
| pluscodecapture | `example_odk_plus_code.capture.xlsx` | `example_odk_plus_code_capture.xlsx` |
| qrcode | `example_odk_barcode.scan.xlsx` | `example_odk_barcode_scan.xlsx` |
| sampling | `example_odk_Sampling.xlsx` | `example_odk_sampling.xlsx` |
| scaledphoto | `example_odk_scaled_photo.capture.xlsx` | `example_odk_scaled_photo_capture.xlsx` |
| scoring | `example_odk_score.counter.xlsx` | `example_odk_score_counter.xlsx` |
| scoring | `example_odk_score.high_score.xlsx` | `example_odk_score_high_score.xlsx` |
| scoring | `example_odk_score.match.xlsx` | `example_odk_score_match.xlsx` |
| scoring | `example_odk_score.race_to.xlsx` | `example_odk_score_race_to.xlsx` |
| scoring | `example_odk_score.rounds.xlsx` | `example_odk_score_rounds.xlsx` |
| scoring | `example_odk_score.session.finish.xlsx` | `example_odk_score_session_finish.xlsx` |
| scoring | `example_odk_score.session.read.xlsx` | `example_odk_score_session_read.xlsx` |
| scoring | `example_odk_score.session.resume.xlsx` | `example_odk_score_session_resume.xlsx` |
| scoring | `example_odk_score.set_match.xlsx` | `example_odk_score_set_match.xlsx` |
| scoring | `example_odk_score.sports.xlsx` | `example_odk_score_sports.xlsx` |
| scoring | `example_odk_score.tally.xlsx` | `example_odk_score_tally.xlsx` |
| sms | `example_odk_sms.send.xlsx` | `example_odk_sms_send.xlsx` |
| soundgenerator | `example_odk_SoundGenerator.xlsx` | `example_odk_soundgenerator.xlsx` |
| svgselector | `example_odk_svg.select.xlsx` | `example_odk_svg_select.xlsx` |
| tabletoputilities | `example_odk_TabletopUtilities.xlsx` | `example_odk_tabletoputilities.xlsx` |
| trustedtimestamp | `example_odk_integrity.trusted_timestamp.xlsx` | `example_odk_integrity_trusted_timestamp.xlsx` |
| visualacuity | `example_odk_VisualAcuity.xlsx` | `example_odk_visualacuity.xlsx` |
| webactions | `example_odk_web.odk_central_roundtrip.xlsx` | `example_odk_web_odk_central_roundtrip.xlsx` |
| webactions | `example_odk_web.open.xlsx` | `example_odk_web_open.xlsx` |
| webactions | `example_odk_web.precooked_enketo.xlsx` | `example_odk_web_precooked_enketo.xlsx` |
| webactions | `example_odk_web.roundtrip.xlsx` | `example_odk_web_roundtrip.xlsx` |

## Historical form IDs intentionally retained

These IDs are not lower snake case under the current MethodMesh convention, but were left unchanged because changing them would create a new ODK form identity.

| Module | Form | Retained form_id |
|---|---|---|
| attestation | `example_odk_attestation_create_fingerprint.xlsx` | `attestation_create_Fingerprint` |
| attestation | `example_odk_attestation_create_nfc.xlsx` | `attestation_create_Nfc` |
| attestation | `example_odk_attestation_create_password.xlsx` | `attestation_create_Password` |
| attestation | `example_odk_attestation_create_pin.xlsx` | `attestation_create_Pin` |
| attestation | `example_odk_attestation_create_qr.xlsx` | `attestation_create_Qr` |
| calibratedscale | `example_odk_calibrated_scale_minmax.xlsx` | `calibrated_scale_MinMax` |
| calibratedscale | `example_odk_calibrated_scale_range.xlsx` | `calibrated_scale_Range` |
| calibratedscale | `example_odk_calibrated_scale_vertical.xlsx` | `calibrated_scale_Vertical` |
| labbench | `example_odk_labbench_aliquot.xlsx` | `labbench.aliquot` |
| labbench | `example_odk_labbench_cell_dilution.xlsx` | `labbench.cell_dilution` |
| labbench | `example_odk_labbench_centrifuge.xlsx` | `labbench.centrifuge` |
| labbench | `example_odk_labbench_concentration.xlsx` | `labbench.concentration` |
| labbench | `example_odk_labbench_dashboard.xlsx` | `labbench.dashboard` |
| labbench | `example_odk_labbench_dilution.xlsx` | `labbench.dilution` |
| labbench | `example_odk_labbench_hemocytometer.xlsx` | `labbench.hemocytometer` |
| labbench | `example_odk_labbench_master_mix.xlsx` | `labbench.master_mix` |
| labbench | `example_odk_labbench_molar_solution.xlsx` | `labbench.molar_solution` |
| labbench | `example_odk_labbench_nucleic_acid.xlsx` | `labbench.nucleic_acid` |
| labbench | `example_odk_labbench_percent_solution.xlsx` | `labbench.percent_solution` |
| labbench | `example_odk_labbench_reconstitute.xlsx` | `labbench.reconstitute` |
| labbench | `example_odk_labbench_serial_dilution.xlsx` | `labbench.serial_dilution` |
| pluscodecapture | `example_odk_plus_code_capture.xlsx` | `plus_code.capture` |
| scaledphoto | `example_odk_scaled_photo_capture.xlsx` | `scaled_photo.capture` |
| scoring | `example_odk_score_counter.xlsx` | `score.counter` |
| scoring | `example_odk_score_high_score.xlsx` | `score.high_score` |
| scoring | `example_odk_score_match.xlsx` | `score.match` |
| scoring | `example_odk_score_race_to.xlsx` | `score.race_to` |
| scoring | `example_odk_score_rounds.xlsx` | `score.rounds` |
| scoring | `example_odk_score_session_finish.xlsx` | `score.session.finish` |
| scoring | `example_odk_score_session_read.xlsx` | `score.session.read` |
| scoring | `example_odk_score_session_resume.xlsx` | `score.session.resume` |
| scoring | `example_odk_score_set_match.xlsx` | `score.set_match` |
| scoring | `example_odk_score_sports.xlsx` | `score.sports` |
| scoring | `example_odk_score_tally.xlsx` | `score.tally` |

## Historical versions intentionally retained

These forms did not require a definition change in this cleanup, so their existing version strings were not rewritten solely for style.

| Module | Form | Retained version |
|---|---|---|
| aquaticfield | `example_odk_aquaticfield.xlsx` | `20260904` |
| digitalsigning | `example_odk_document_sign_pdf.xlsx` | `20260907` |
| earthscience | `example_odk_earthscience.xlsx` | `20260904` |
| referencelibrary | `example_odk_reference_library.xlsx` | `20260907-0.2.6` |
| scaledphoto | `example_odk_scaled_photo_capture.xlsx` | `2` |
| time_tools | `example_odk_time_tools.xlsx` | `20260906` |
| webactions | `example_odk_web_odk_central_roundtrip.xlsx` | `20260907` |
| webactions | `example_odk_web_open.xlsx` | `20260907` |
| webactions | `example_odk_web_precooked_enketo.xlsx` | `20260907` |
| webactions | `example_odk_web_roundtrip.xlsx` | `20260907` |

## Notes

- Documentation references to renamed workbooks were updated. Two Cryptography module `notes` strings that pointed to example workbook filenames were updated; executable capability behavior was not changed.
- This cleanup is deliberately separate from the ODK contract ambiguity log and from substantive repairs to legacy survey logic.
