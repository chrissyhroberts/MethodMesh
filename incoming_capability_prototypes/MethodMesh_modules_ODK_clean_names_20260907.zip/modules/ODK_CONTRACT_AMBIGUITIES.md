# ODK Contract Ambiguities — Capability Showcase Pass

Generated during the capability-by-capability ODK showcase audit. Capability implementations were not changed.

## Summary

- Findings: **90**
- Architecture-level: **3**
- Needs discussion: **1**
- Capability contract gaps: **86**

### Cross-cutting contract point

The requested universal ODK return shape — a success indicator, a time field, and a capability-owned JSON payload for every MethodMesh call — is not currently exposed as one consistently named scalar contract across all modules. The shared transport consistently supports `methodmesh_full_json` and many capabilities expose their own status/time/JSON fields, but the names and presence are heterogeneous. This pass does **not** invent return fields that the runtime does not declare. The showcase forms therefore capture `methodmesh_status`, `methodmesh_full_json`, and only the capability-specific return fields resolved from the existing contract.

This should be resolved centrally in the shared MethodMesh ODK transport/canonical contract rather than independently inside individual XLSForms.

## Architecture-level findings

### `*`

- **`*` — `UNIVERSAL_SUCCESS_TIME_ENVELOPE_NOT_SCALAR_STANDARDIZED`**: Shared ODK transport consistently supports methodmesh_full_json and many examples use methodmesh_status, while capability-level success/time fields are heterogeneous (e.g. confirmed+timestamp_iso for local authentication, *_status plus *_time_iso elsewhere). The requested universal success + time + capability JSON contract should be standardized in shared transport/canonical contract rather than invented per XLSForm. New forms therefore capture methodmesh_status, methodmesh_full_json, and capability-specific status/time/JSON fields where declared.

### `fingerprints`

- **`*` — `DOCS_ONLY_FOLDER_NO_REGISTERED_MODULE`**: The fingerprints folder appears to contain documentation/schema material but no runnable MethodMeshModule. The runnable local biometric capability is adminfingerprint/admin_fingerprint_confirmation; no synthetic fingerprint capability was added.

### `sensorfirmwareinstaller`

- **`esp32.sensor_profile_install` — `ONLY_REGISTERED_PUBLIC_FIRMWARE_METHOD_EXPOSED`**: Firmware source contains additional board/runtime boundary operations, but the module catalogue exposes esp32.sensor_profile_install as the public MethodMesh capability. Showcase generation does not promote hidden/internal operations.

## Needs discussion

### `time_tools`

- **`time.*` — `LEGACY_XLSFORM_INTENT_PLACEHOLDERS`**: Legacy Time Tools XLSForm contains METHODMESH_INTENT_TO_ALIGN placeholders. New showcase forms use the canonical com.example.methodmesh.EXECUTE_METHOD action and the declared TimeToolsContract method IDs, but registry/runtime parity should be verified.

## Capability contract gaps

### `appinspector`

- **`android_app_inspector` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `aquaticfield`

- **`aquatic.salinity.convert` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.pressure_depth.convert` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.secchi.measure` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.station.visit` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.ctd.cast` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.sample_id.generate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.sample.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.profile.summarise` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.instrument.check` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.transect.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.mooring.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`aquatic.sediment.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `attestation`

- **`attestation.create` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`attestation.anchor_bundle` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `bluetoothinspector`

- **`bluetooth_device_inspector` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `bluetoothprinter`

- **`bluetooth_print` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `calibratedscale`

- **`calibrated_scale` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `conversationtranslate`

- **`conversation.translate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `conversions`

- **`conversion.calculate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `datatools`

- **`data.tools` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `diving`

- **`diving.sac_rmv` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.cylinder.capacity` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.ppo2` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.mod` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.nitrox.best_mix` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.ead` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.end` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.gas.density` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.gas.plan` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.bailout.plan` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.navigation` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.lift` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.dashboard` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.log.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.log.dashboard` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.gas.analysis.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.cylinder.record` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`diving.gas.dashboard` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `documentscanner`

- **`document.scan` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `emergency`

- **`emergency.reference.open` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`emergency.pack.prepare` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `expenses`

- **`expenses.manage` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `hamradio`

- **`ham.dashboard` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.spaceweather.snapshot` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.band.recommend` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.maidenhead.convert` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.path.calculate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.antenna.calculate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.swr.calculate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`ham.link.calculate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `imageredaction`

- **`image.redact` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `magnifier`

- **`visual.magnifier.capture` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `mlkittranslate`

- **`mlkit.translate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `nfc`

- **`nfc_tag_write` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`nfc_tag_wipe` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`nfc_credential_verification` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`protocol_nfc_check` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`protocol_nfc_complete` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `odkformlauncher`

- **`odk_form_launcher` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `pluscodecapture`

- **`plus_code.capture` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `psychomotorvigilance`

- **`psychomotor.vigilance.run` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `referencelibrary`

- **`reference.library.open` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`reference.library.email` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `scoring`

- **`score.counter` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.tally` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.match` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.rounds` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.race_to` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.set_match` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.sports` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.high_score` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.session.read` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.session.resume` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`score.session.finish` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `sensorfirmwareinstaller`

- **`esp32.sensor_profile_install` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `sms`

- **`sms.send` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `spatialgeometry`

- **`tree_height_measurement` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`slope_inclination_measurement` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`geometry_distance_estimation` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `svgselector`

- **`svg.select` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.

### `time_tools`

- **`time.countdown` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`time.interval` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`time.until` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`time.elapsed` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
- **`time.duration.calculate` — `NO_CAPABILITY_OWNED_JSON_FIELD_RESOLVED`**: No capability-owned *_json return field was resolved for this method. The showcase still captures methodmesh_full_json; discuss whether this capability should gain a dedicated JSON projection in the capability/shared contract.
