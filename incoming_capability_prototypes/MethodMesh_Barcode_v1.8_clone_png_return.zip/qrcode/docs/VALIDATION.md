# barcode module validation

Review date: 2026-09-22  
Authority: MethodMesh Master Book v1.22 (2026-09-15).

## Pass A — contract correctness

- [x] Historical module ID remains `barcode`.
- [x] Established `barcode.scan` method remains present at version `1.1.2` with its existing inputs/outputs/evidence recipe.
- [x] Existing `BarcodeScanCapabilityScreen` is included in the handoff; the earlier missing-source packaging defect is removed.
- [x] `barcode.generate` is independently registered with its own method, screen, settings, RIL bindings and ODK showcase.
- [x] `barcode.clone` is independently registered with its own method, screen, settings, RIL bindings and ODK showcase.
- [x] Direct/dashboard discovery, presets/protocol discovery and ODK all derive from the same registered method/screen metadata rather than dashboard-only implementations.
- [x] Exactly one module maturity tag (`Development`) and one connectivity tag (`Offline`) are declared. The established scanner method remains Production; new Generate/Clone methods remain Development until receiving-repository build and device gates pass.

## Pass B — interaction quality

- [x] Scan remains scanner-first with live result -> Commit.
- [x] Generate is renderer-first with immediate code updates and no redundant Generate button.
- [x] Clone invokes the established scanner acquisition boundary, then becomes a large renderer with swipe/rail/cycle format selection.
- [x] Generate and Clone never silently truncate, pad, normalise or rewrite the payload for a symbology.
- [x] Fixed format settings remain fixed; incompatible fixed formats fail visibly and disable Commit.
- [x] Fixed auto-cycle settings are not exposed as runtime toggle questions.
- [x] Useful displayed payload text is tap-to-copy/copyable.
- [x] Commit freezes the canonical payload/format choice before post-commit actions.
- [x] Generate/Clone save committed execution, observation, transformation, relationship and system-time identity so ordinary Android recreation does not silently create a different committed execution.
- [x] Generator QR branding is automatic MethodMesh presentation; arbitrary custom-logo controls are absent.
- [x] Clone renderings stay unbranded for fidelity.

## Pass C — field robustness

- [x] Core scanning/generation/cloning is offline.
- [x] Camera permission remains confined to scan/clone acquisition.
- [x] No private barcode history/wallet store was introduced.
- [x] Full-screen presentation restores prior brightness/keep-awake state on exit.
- [x] Android Share includes a PNG rendering for Generate/Clone while leaving canonical method outputs scalar/evidence based.
- [x] A standalone Kotlin parser pass reports no syntax/parser/redeclaration diagnostics across the five module source files.
- [ ] Receiving-repository Android build and physical-device scan tests are still required; this standalone module folder is not a complete Gradle project and therefore cannot resolve Android/Compose/ZXing host dependencies for a truthful app compile here.

## ODK/XLSForm inventory

- [x] `example_odk_barcode_scan.xlsx` retained with stable `form_id=barcode_scan`.
- [x] `example_odk_showcase_barcode_scan.xlsx` retained with stable `form_id=qrcode_barcode_scan`.
- [x] `example_odk_showcase_barcode_generate.xlsx` added with `form_id=barcode_generate`.
- [x] `example_odk_showcase_barcode_clone.xlsx` added with `form_id=barcode_clone`.
- [x] Each workbook contains exactly one MethodMesh invocation.
- [x] Canonical examples use unprefixed canonical return field names and no `methodmesh_return_namespace`.
- [x] All canonical examples request `input_payload_mode='FULL'`, use `return_mode='flat'`, and capture `methodmesh_status` plus `methodmesh_full_json`.
- [x] Generator/clone forms capture only outputs actually declared by their runtime contracts; no speculative image/print return field is invented.
- [x] Workbook node names are unique within each canonical workbook.

The workbooks were generated and re-inspected through the required spreadsheet artifact workflow. Provider-side ODK Central/Kobo upload and pyxform validation were not available in this standalone module workspace and are therefore not claimed.

## Receiving-repository gates

Run:

```text
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

Then exercise:

1. scan: live code A -> code B -> Commit; tap/copy/share/save; rotate before and after Commit;
2. generate: free text, URL, numeric retail code, incompatible fixed format, swipe/Cycle, QR MethodMesh mark, full-screen, Share PNG;
3. clone: QR and linear source codes, SOURCE mode, cross-format swipe, incompatible fixed target, full-screen, Commit, Share PNG;
4. verify every generated/cloned symbol with at least two independent scanners where practical;
5. verify generator branding does not materially reduce QR reliability at representative payload lengths;
6. exercise direct, preset, protocol/schedule/widget origins as applicable;
7. roundtrip all three canonical showcase XLSForms through ODK; confirm every declared output, `methodmesh_status`, `methodmesh_full_json`, Commit and Cancel return behaviour;
8. upload the canonical workbooks unchanged to ODK Central and Kobo where supported.

## Handoff check

This handoff is one `qrcode/` module root. It contains only module code and module-owned `docs/`; no `app/` wrapper, whole repository tree, build outputs or unrelated modules.


## v1.7 native artefact / preset contract

- [x] `barcode.clone` now owns a complete post-Commit native lifecycle: Share image, Copy image, Save image, optional JSON sidecar, Technical details, origin-aware Home/Done and Clone another.
- [x] `barcode.generate` uses the same image-first Share/Copy/Save rule.
- [x] Share/Copy/Save never create a payload `.txt` file for Generate/Clone. The payload remains available in the canonical result and as a secondary tap-to-copy scalar.
- [x] Native Share uses PNG as the first/primary attachment; optional metadata is a real `.json` sidecar attachment rather than JSON appended to a text share payload.
- [x] Native Save writes PNG plus optional `metadata.json`; no result text file is emitted.
- [x] Native Copy places the PNG URI on the Android clipboard.
- [x] Native presets honour `HOME`, `SHARE`, and `SAVE` result actions.
- [x] Native preset `CORE` uses image only; `AUDIT` / `FULL` request the corresponding JSON metadata sidecar for Share/Save.
- [x] ODK/external Commit remains transport-first and bypasses native Share/Save; canonical scalar fields plus `methodmesh_full_json` remain the ODK contract.
- [x] Clone/Generate method descriptor metadata now advertises the image-first native artefact contract and preset result/payload policies.
- [x] Existing scanner source, scanner contracts, legacy scanner XLSForm and canonical scanner showcase remain present.
- [x] Existing Generate/Clone XLSForms remain single-call, FULL + flat, unprefixed, and capture `methodmesh_status` / `methodmesh_full_json`; no speculative image return field is introduced.

Receiving-repository gates remain mandatory:

```text
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```


## Clone binary return v1.0.2

- [x] `barcode_clone_image_uri` is a declared canonical output and the clone core return.
- [x] Commit materialises one stable caller-readable PNG URI and reuses that artefact for ODK/native Share/Copy/Save.
- [x] ODK canonical showcase uses an `image` return field for `barcode_clone_image_uri`.
- [x] `barcode_return_text_payload` independently controls the scalar text return; it does not change barcode rendering.
- [x] Canonical ODK showcase defaults the text return to `true`, demonstrating PNG + exact payload + FULL JSON.
- [x] Native Share/Copy are image-first and default to no payload text; payload text can be included without creating a `.txt` sidecar.
- [x] Native Save writes the PNG and optional JSON sidecar only.
