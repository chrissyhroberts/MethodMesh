package com.example.methodmesh.modules.qrcode

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.methodmesh.MainActivity
import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.TemporalContext
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.core.protocols.PresetResultAction
import com.example.methodmesh.transport.OutputExportRepository
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.ResultShare
import com.example.methodmesh.transport.ReturnMode
import com.example.methodmesh.transport.workflow.ui.CapabilityCompletionMode
import com.example.methodmesh.transport.workflow.ui.CapabilityHostPresentation
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.File
import java.time.Instant
import kotlinx.coroutines.delay

private val CLONE_ORDER = listOf(
    BarcodeFormat.QR_CODE,
    BarcodeFormat.CODE_128,
    BarcodeFormat.DATA_MATRIX,
    BarcodeFormat.AZTEC,
    BarcodeFormat.PDF_417,
    BarcodeFormat.CODE_39,
    BarcodeFormat.EAN_13,
    BarcodeFormat.EAN_8,
    BarcodeFormat.UPC_A,
    BarcodeFormat.UPC_E
)

private data class CloneRenderedCode(val bitmap: Bitmap, val format: BarcodeFormat)

private class CodeCloneCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId: String = As100BarcodeCloneMethod.ID
    override val title: String = "Clone code"
    override val description: String = "Scan a code and re-present its exact payload in the same or another compatible symbology."
    override val hostPresentation: CapabilityHostPresentation = CapabilityHostPresentation.Immersive

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val automaticReturn = context.completionMode == CapabilityCompletionMode.AutomaticReturn
        val finishToLauncher = context.request.settings["methodmesh_finish_to_launcher"] == "true" ||
            context.request.settings["input_methodmesh_finish_to_launcher"] == "true"
        val presetResultAction = PresetResultAction.normalize(
            context.request.settings["methodmesh_preset_result_action"]
                ?: context.request.settings["input_methodmesh_preset_result_action"]
                ?: PresetResultAction.HOME
        )
        val presetPayloadMode = OutputFormatter.PayloadMode.normalize(
            context.request.settings["payload_mode"]
                ?: context.request.settings["input_payload_mode"]
                ?: context.action.settings["payload_mode"]
                ?: context.action.settings["input_payload_mode"]
                ?: OutputFormatter.PayloadMode.CORE
        )
        val formatEditable = context.settingShouldBeShown("barcode_clone_format")
        val cycleEditable = context.settingShouldBeShown("barcode_auto_cycle")
        val returnTextEditable = context.settingShouldBeShown("barcode_return_text_payload")

        val configuredFormat = context.action.settings["barcode_clone_format"]
            ?: context.action.settings["input_barcode_clone_format"]
            ?: "SOURCE"
        val configuredCycle = (context.action.settings["barcode_auto_cycle"]
            ?: context.action.settings["input_barcode_auto_cycle"]
            ?: "false").toBoolean()
        val configuredReturnText = (context.action.settings["barcode_return_text_payload"]
            ?: context.action.settings["input_barcode_return_text_payload"]
            ?: "true").toBoolean()

        var sourcePayload by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var sourceFormat by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var sourceScanTime by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var formatName by rememberSaveable(context.action.canonicalId) { mutableStateOf(configuredFormat) }
        var cycling by rememberSaveable(context.action.canonicalId) { mutableStateOf(configuredCycle) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Point the camera at a code.") }
        var presentationMode by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var initialScanPending by rememberSaveable(context.action.canonicalId) { mutableStateOf(true) }
        var includeJsonSidecar by rememberSaveable(context.action.canonicalId) {
            mutableStateOf(context.isNativePresetRun && presetPayloadMode != OutputFormatter.PayloadMode.CORE)
        }
        var returnTextPayload by rememberSaveable(context.action.canonicalId) { mutableStateOf(configuredReturnText) }
        var includePayloadInShare by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var showTechnicalDetails by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }

        var committedPayload by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedSourceFormat by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedCloneFormat by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedScanTime by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedCloneTime by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedImageUri by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedReturnTextPayload by rememberSaveable(context.action.canonicalId) { mutableStateOf<Boolean?>(null) }
        var committedExecutionId by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedObservationId by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedTransformationId by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedRelationshipIds by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var committedSystemTimeMs by rememberSaveable(context.action.canonicalId) { mutableStateOf<Long?>(null) }

        val displayPayload = committedPayload ?: sourcePayload.orEmpty()
        val compatible = remember(displayPayload) { CLONE_ORDER.filter { cloneCanEncode(displayPayload, it) } }
        val sourceAsFormat = sourceFormat?.let(::cloneParseFormatOrNull)
        val selected = cloneParseFormatOrNull(formatName)
        val effectiveFormat = when {
            committedCloneFormat != null -> cloneParseFormat(committedCloneFormat!!)
            formatName == "SOURCE" && sourceAsFormat != null && sourceAsFormat in compatible -> sourceAsFormat
            formatName == "SOURCE" && compatible.isNotEmpty() -> compatible.first()
            !formatEditable && selected != null -> selected
            selected != null && selected in compatible -> selected
            sourceAsFormat != null && sourceAsFormat in compatible -> sourceAsFormat
            compatible.isNotEmpty() -> compatible.first()
            else -> selected ?: BarcodeFormat.QR_CODE
        }

        LaunchedEffect(sourcePayload, sourceFormat, compatible, committedPayload, formatEditable) {
            if (committedPayload != null || sourcePayload.isNullOrEmpty() || !formatEditable) return@LaunchedEffect
            val parsed = cloneParseFormatOrNull(formatName)
            if (formatName == "SOURCE" || parsed == null || parsed !in compatible) {
                formatName = effectiveFormat.name
            }
        }

        val rendered = remember(displayPayload, effectiveFormat.name) {
            if (displayPayload.isEmpty()) null
            else runCatching { cloneRenderCode(displayPayload, effectiveFormat) }.getOrNull()
        }

        val committedResult = remember(
            committedPayload, committedSourceFormat, committedCloneFormat, committedScanTime, committedCloneTime,
            committedImageUri, committedReturnTextPayload,
            committedExecutionId, committedObservationId, committedTransformationId, committedRelationshipIds,
            committedSystemTimeMs, context.request.invocationContext
        ) {
            val payload = committedPayload
            val sf = committedSourceFormat
            val cf = committedCloneFormat
            val st = committedScanTime
            val ct = committedCloneTime
            val imageUri = committedImageUri
            val returnText = committedReturnTextPayload
            if (payload == null || sf == null || cf == null || st == null || ct == null || imageUri == null || returnText == null) null
            else buildCloneResult(
                context = context, payload = payload, sourceFormat = sf, cloneFormat = cf, scanTime = st, cloneTime = ct,
                imageUri = imageUri, returnTextPayload = returnText,
                executionId = committedExecutionId, observationId = committedObservationId,
                transformationId = committedTransformationId, relationshipIds = committedRelationshipIds,
                systemTimeEpochMs = committedSystemTimeMs
            )
        }

        val committedFields = remember(committedResult?.request?.id?.value) {
            committedResult?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty()
        }
        val metadataJson = remember(
            committedResult?.request?.id?.value, includeJsonSidecar, presetPayloadMode, context.isNativePresetRun
        ) {
            val result = committedResult ?: return@remember ""
            val mode = when {
                context.isNativePresetRun && presetPayloadMode != OutputFormatter.PayloadMode.CORE -> presetPayloadMode
                includeJsonSidecar -> OutputFormatter.PayloadMode.FULL
                else -> OutputFormatter.PayloadMode.CORE
            }
            if (mode == OutputFormatter.PayloadMode.CORE) "" else OutputFormatter.format(
                result = result,
                returnMode = ReturnMode.Json,
                includeProvenance = true,
                payloadMode = mode
            )
        }

        LaunchedEffect(formatName, cycling, returnTextPayload) {
            if (committedPayload == null) {
                context.onSettingsChanged(
                    mapOf(
                        "barcode_clone_format" to formatName,
                        "barcode_auto_cycle" to cycling.toString(),
                        "barcode_return_text_payload" to returnTextPayload.toString()
                    )
                )
            }
        }

        val cyclingState by rememberUpdatedState(cycling)
        LaunchedEffect(cycling, compatible, committedPayload, formatEditable) {
            if (!formatEditable || !cycling || committedPayload != null || compatible.size < 2) return@LaunchedEffect
            while (cyclingState) {
                delay(1700)
                val current = compatible.indexOf(effectiveFormat).coerceAtLeast(0)
                formatName = compatible[(current + 1) % compatible.size].name
            }
        }

        fun acceptScan(result: ExecutionResult) {
            val fields = result.observations.firstOrNull()?.values.orEmpty()
            val payload = fields["barcode_payload"].orEmpty()
            if (payload.isEmpty()) {
                status = "No payload was decoded."
                return
            }
            sourcePayload = payload
            sourceFormat = fields["barcode_format"].orEmpty().ifBlank { "UNKNOWN" }
            sourceScanTime = fields["barcode_scan_time_iso"].orEmpty().ifBlank { Instant.now().toString() }
            committedPayload = null
            committedSourceFormat = null
            committedCloneFormat = null
            committedScanTime = null
            committedCloneTime = null
            committedImageUri = null
            committedReturnTextPayload = null
            committedExecutionId = null
            committedObservationId = null
            committedTransformationId = null
            committedRelationshipIds = null
            committedSystemTimeMs = null
            cycling = configuredCycle
            formatName = configuredFormat
            status = "Captured ${clonePrettySource(sourceFormat.orEmpty())}. Swipe to change the clone format."
        }

        val launchScan = rememberBarcodeCapabilityInvocation(
            context = context,
            sourceLabel = "camera_zxing_clone",
            onResult = ::acceptScan,
            onCancel = { status = "Scan cancelled. Tap Scan to try again." },
            onError = { status = it }
        )

        LaunchedEffect(initialScanPending) {
            if (initialScanPending) {
                initialScanPending = false
                launchScan()
            }
        }

        fun moveFormat(delta: Int) {
            if (!formatEditable || committedPayload != null || compatible.isEmpty()) return
            if (cycleEditable) cycling = false
            val current = compatible.indexOf(effectiveFormat).coerceAtLeast(0)
            formatName = compatible[(current + delta + compatible.size) % compatible.size].name
        }

        fun commit() {
            val payload = sourcePayload ?: return
            val sf = sourceFormat ?: "UNKNOWN"
            val st = sourceScanTime ?: Instant.now().toString()
            if (rendered == null) return
            cycling = false
            val ct = Instant.now().toString()
            val imageUri = cloneMaterializeCommittedImage(appContext, rendered.bitmap, effectiveFormat).toString()
            val result = buildCloneResult(
                context = context,
                payload = payload,
                sourceFormat = sf,
                cloneFormat = effectiveFormat.name,
                scanTime = st,
                cloneTime = ct,
                imageUri = imageUri,
                returnTextPayload = returnTextPayload
            )
            committedPayload = payload
            committedSourceFormat = sf
            committedCloneFormat = effectiveFormat.name
            committedScanTime = st
            committedCloneTime = ct
            committedImageUri = imageUri
            committedReturnTextPayload = returnTextPayload
            committedExecutionId = result.request.id.value
            committedObservationId = result.observations.firstOrNull()?.id?.value
            committedTransformationId = result.transformations.firstOrNull()?.id?.value
            committedRelationshipIds = result.relationships.joinToString("|") { it.id.value }.ifBlank { null }
            committedSystemTimeMs = result.request.temporalContext.systemTimeEpochMs
            if (automaticReturn) onConfirmed(result)
        }

        fun shareCommitted(): Boolean {
            val imageUri = committedImageUri ?: return false
            return runCatching {
                cloneShareImage(
                    context = appContext,
                    imageUri = imageUri,
                    format = effectiveFormat,
                    payloadText = if (includePayloadInShare) committedPayload.orEmpty() else "",
                    metadataJson = metadataJson
                )
                exportStatus = "Sharing committed barcode…"
            }.onFailure {
                exportStatus = "Share failed: ${it.message ?: "no sharing app available"}"
            }.isSuccess
        }

        fun copyCommittedImage(): Boolean {
            val imageUri = committedImageUri ?: return false
            return runCatching {
                cloneCopyImage(
                    context = appContext,
                    imageUri = imageUri,
                    payloadText = if (includePayloadInShare) committedPayload.orEmpty() else ""
                )
                exportStatus = "Barcode image copied."
            }.onFailure {
                exportStatus = "Copy failed: ${it.message ?: "clipboard error"}"
            }.isSuccess
        }

        fun saveCommitted(): Boolean {
            val imageUri = committedImageUri ?: return false
            return runCatching {
                val saved = cloneSaveImage(
                    context = appContext,
                    imageUri = imageUri,
                    metadataJson = metadataJson
                )
                exportStatus = "Saved ${saved.summary}"
            }.onFailure {
                exportStatus = "Save failed: ${it.message ?: "storage error"}"
            }.isSuccess
        }

        fun finishCommitted() {
            val result = committedResult ?: return
            if (!context.isNativePresetRun || !context.isLastStep) {
                onConfirmed(result)
                return
            }
            when (presetResultAction) {
                PresetResultAction.SHARE -> {
                    if (!shareCommitted()) return
                    onConfirmed(result)
                }
                PresetResultAction.SAVE -> {
                    if (!saveCommitted()) return
                    onConfirmed(result)
                }
                else -> {
                    if (finishToLauncher) {
                        onConfirmed(result)
                    } else {
                        appContext.startActivity(
                            Intent(appContext, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                        )
                    }
                }
            }
        }

        fun cloneAnother() {
            committedPayload = null
            committedSourceFormat = null
            committedCloneFormat = null
            committedScanTime = null
            committedCloneTime = null
            committedImageUri = null
            committedReturnTextPayload = null
            committedExecutionId = null
            committedObservationId = null
            committedTransformationId = null
            committedRelationshipIds = null
            committedSystemTimeMs = null
            sourcePayload = null
            sourceFormat = null
            sourceScanTime = null
            formatName = configuredFormat
            cycling = configuredCycle
            status = "Point the camera at a code."
            exportStatus = ""
            showTechnicalDetails = false
            includeJsonSidecar = context.isNativePresetRun && presetPayloadMode != OutputFormatter.PayloadMode.CORE
            returnTextPayload = configuredReturnText
            includePayloadInShare = false
            launchScan()
        }

        DisposableEffect(presentationMode) {
            val activity = appContext.findCloneActivity()
            val oldBrightness = activity?.window?.attributes?.screenBrightness
            if (presentationMode && activity != null) {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                val attrs = activity.window.attributes
                attrs.screenBrightness = 1f
                activity.window.attributes = attrs
            }
            onDispose {
                if (activity != null) {
                    activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    if (oldBrightness != null) {
                        val attrs = activity.window.attributes
                        attrs.screenBrightness = oldBrightness
                        activity.window.attributes = attrs
                    }
                }
            }
        }

        if (presentationMode) {
            Surface(
                modifier = Modifier.fillMaxSize().clickable { presentationMode = false },
                color = Color.White
            ) {
                Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                    rendered?.let {
                        Image(
                            bitmap = it.bitmap.asImageBitmap(),
                            contentDescription = "Cloned ${clonePrettyFormat(it.format)} code",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Surface(
                        modifier = Modifier.align(Alignment.BottomCenter),
                        shape = RoundedCornerShape(999.dp),
                        color = Color.White.copy(alpha = 0.92f),
                        border = BorderStroke(1.dp, Color.Black.copy(alpha = 0.10f))
                    ) {
                        Text(
                            "Tap anywhere to return",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            color = Color.Black,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
            return
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CloneHeader(
                committed = committedPayload != null,
                sourceFormat = committedSourceFormat ?: sourceFormat,
                cloneFormat = if (displayPayload.isEmpty()) null else effectiveFormat
            )

            if (displayPayload.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(30.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 44.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Scan a code to clone it", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(status, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Button(onClick = launchScan) { Text("Scan") }
                    }
                }
            } else {
                CloneCodeHero(
                    rendered = rendered,
                    committed = committedPayload != null,
                    onSwipe = ::moveFormat,
                    onPresent = { if (rendered != null) presentationMode = true }
                )

                if (committedPayload == null && formatEditable) {
                    CloneTransport(
                        cycling = cycling,
                        enabled = compatible.size > 1,
                        cycleEditable = cycleEditable,
                        onPrevious = { moveFormat(-1) },
                        onCycle = { if (cycleEditable) cycling = !cycling },
                        onNext = { moveFormat(+1) }
                    )
                    CloneFormatRail(
                        compatible = compatible,
                        selected = effectiveFormat,
                        onSelect = { if (cycleEditable) cycling = false; formatName = it.name }
                    )
                } else if (committedPayload == null && rendered == null) {
                    Text(
                        "The fixed ${clonePrettyFormat(effectiveFormat)} format cannot represent this exact payload. The payload will not be altered.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                ClonePayloadCard(displayPayload) { cloneCopyPayload(appContext, displayPayload) }
                if (committedPayload == null && returnTextEditable) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Return text payload", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "The cloned PNG is always returned. Enable this when the caller also needs the exact decoded text.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = returnTextPayload, onCheckedChange = { returnTextPayload = it })
                    }
                }
                Text(
                    "${clonePrettySource(committedSourceFormat ?: sourceFormat.orEmpty())} → ${clonePrettyFormat(effectiveFormat)} · exact payload preserved",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (committedPayload == null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(modifier = Modifier.weight(1f), onClick = launchScan) { Text("Rescan") }
                        Button(
                            modifier = Modifier.weight(1f),
                            onClick = ::commit,
                            enabled = rendered != null
                        ) { Text(if (automaticReturn) "Commit & return" else "Commit") }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            modifier = Modifier.weight(1f),
                            onClick = { shareCommitted() }
                        ) { Text("Share image") }
                        OutlinedButton(
                            modifier = Modifier.weight(1f),
                            onClick = { copyCommittedImage() }
                        ) { Text("Copy image") }
                    }
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { saveCommitted() }
                    ) { Text("Save image") }

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("Include payload text in Share / Copy", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "Off by default: the barcode PNG is the primary human-facing artefact.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(checked = includePayloadInShare, onCheckedChange = { includePayloadInShare = it })
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("JSON sidecar", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        if (context.isNativePresetRun && presetPayloadMode != OutputFormatter.PayloadMode.CORE)
                                            "Preset return scope requests ${presetPayloadMode.lowercase()} metadata."
                                        else
                                            "Optional for native Share/Save. ODK receives methodmesh_full_json through the roundtrip contract.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = includeJsonSidecar,
                                    onCheckedChange = { includeJsonSidecar = it },
                                    enabled = !(context.isNativePresetRun && presetPayloadMode != OutputFormatter.PayloadMode.CORE)
                                )
                            }
                            TextButton(onClick = { showTechnicalDetails = !showTechnicalDetails }) {
                                Text(if (showTechnicalDetails) "Hide technical details" else "Technical details")
                            }
                            if (showTechnicalDetails) {
                                cloneTechnicalRows(committedFields).forEach { (label, value) ->
                                    CloneTechnicalValue(label, value) { cloneCopyPayload(appContext, value) }
                                }
                            }
                        }
                    }

                    if (exportStatus.isNotBlank()) {
                        Text(exportStatus, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    }

                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = ::finishCommitted,
                        enabled = committedResult != null
                    ) {
                        Text(
                            when {
                                context.isNativePresetRun && context.isLastStep && presetResultAction == PresetResultAction.SHARE -> "Share and finish"
                                context.isNativePresetRun && context.isLastStep && presetResultAction == PresetResultAction.SAVE -> "Save and finish"
                                finishToLauncher -> "Done"
                                else -> "Home"
                            }
                        )
                    }
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = ::cloneAnother) { Text("Clone another") }
                }
            }

            if (committedPayload == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) {
                        OutlinedButton(modifier = Modifier.weight(1f), onClick = onBack) { Text("Back") }
                    }
                    OutlinedButton(modifier = Modifier.weight(1f), onClick = onCancel) { Text("Cancel") }
                }
            }
        }
    }
}

@Composable
private fun CloneHeader(committed: Boolean, sourceFormat: String?, cloneFormat: BarcodeFormat?) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("Clone code", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Scan. Swipe. Share.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = if (committed) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        ) {
            Text(
                when {
                    committed -> "COMMITTED"
                    sourceFormat != null && cloneFormat != null -> "${clonePrettySource(sourceFormat)} → ${clonePrettyFormat(cloneFormat)}"
                    else -> "READY"
                },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun CloneCodeHero(
    rendered: CloneRenderedCode?,
    committed: Boolean,
    onSwipe: (Int) -> Unit,
    onPresent: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(committed) {
                if (!committed) {
                    var drag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { drag = 0f },
                        onHorizontalDrag = { _, amount -> drag += amount },
                        onDragEnd = {
                            when {
                                drag < -70f -> onSwipe(+1)
                                drag > 70f -> onSwipe(-1)
                            }
                        }
                    )
                }
            },
        shape = RoundedCornerShape(30.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color.Black.copy(alpha = 0.08f)),
        shadowElevation = 3.dp
    ) {
        Box(Modifier.fillMaxWidth().height(340.dp).padding(22.dp), contentAlignment = Alignment.Center) {
            if (rendered != null) {
                Image(
                    bitmap = rendered.bitmap.asImageBitmap(),
                    contentDescription = "Cloned ${clonePrettyFormat(rendered.format)}",
                    modifier = Modifier.fillMaxSize().clickable(onClick = onPresent),
                    contentScale = ContentScale.Fit
                )
                Surface(
                    modifier = Modifier.align(Alignment.BottomEnd),
                    shape = RoundedCornerShape(999.dp),
                    color = Color.White.copy(alpha = 0.94f),
                    border = BorderStroke(1.dp, Color.Black.copy(alpha = 0.08f))
                ) {
                    Text(
                        "FULL SCREEN",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = Color.Black,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                Text("No compatible rendering", color = Color.Black, style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
private fun CloneTransport(
    cycling: Boolean,
    enabled: Boolean,
    cycleEditable: Boolean,
    onPrevious: () -> Unit,
    onCycle: () -> Unit,
    onNext: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(modifier = Modifier.weight(1f), onClick = onPrevious, enabled = enabled) { Text("‹") }
        if (cycleEditable) {
            Button(modifier = Modifier.weight(2f), onClick = onCycle, enabled = enabled) {
                Text(if (cycling) "■  Stop" else "▶  Cycle")
            }
        }
        OutlinedButton(modifier = Modifier.weight(1f), onClick = onNext, enabled = enabled) { Text("›") }
    }
}

@Composable
private fun CloneFormatRail(
    compatible: List<BarcodeFormat>,
    selected: BarcodeFormat,
    onSelect: (BarcodeFormat) -> Unit
) {
    if (compatible.isEmpty()) return
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        compatible.forEach { format ->
            Surface(
                modifier = Modifier.clickable { onSelect(format) },
                shape = RoundedCornerShape(999.dp),
                color = if (format == selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                border = if (format == selected) BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)) else null
            ) {
                Text(
                    clonePrettyFormat(format),
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = if (format == selected) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}

@Composable
private fun ClonePayloadCard(payload: String, onCopy: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(enabled = payload.isNotEmpty(), onClick = onCopy),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("PAYLOAD", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    payload.ifEmpty { "—" },
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (payload.isNotEmpty()) Text("COPY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

private fun buildCloneResult(
    context: CapabilityScreenContext,
    payload: String,
    sourceFormat: String,
    cloneFormat: String,
    scanTime: String,
    cloneTime: String,
    imageUri: String,
    returnTextPayload: Boolean,
    executionId: String? = null,
    observationId: String? = null,
    transformationId: String? = null,
    relationshipIds: String? = null,
    systemTimeEpochMs: Long? = null
): ExecutionResult {
    val method: As100Method = As100BarcodeCloneMethod
    val methodContext = context.request.invocationContext.asMap(method.id) +
        context.action.settings + mapOf(
            "barcode_payload" to payload,
            "barcode_source_format" to sourceFormat,
            "barcode_clone_format" to cloneFormat,
            "barcode_scan_time_iso" to scanTime,
            "barcode_clone_time_iso" to cloneTime,
            "barcode_clone_image_uri" to imageUri,
            "barcode_return_text_payload" to returnTextPayload.toString(),
            "barcode_source" to "camera_zxing_clone"
        )
    val canRestoreIdentity = !executionId.isNullOrBlank() && !observationId.isNullOrBlank() &&
        !transformationId.isNullOrBlank() && systemTimeEpochMs != null
    val result = if (canRestoreIdentity) {
        val request = As100ExecutionEngine.request(
            action = method.id, method = method.ref, id = ArchitectureId(executionId!!),
            context = methodContext, temporalContext = TemporalContext(systemTimeEpochMs = systemTimeEpochMs!!)
        )
        As100BarcodeCloneMethod.executeWithIdentity(
            request, ArchitectureId(observationId!!), ArchitectureId(transformationId!!)
        )
    } else {
        method.execute(
            request = method.request(action = method.id, context = methodContext),
            settingsState = null, transport = context.request.source
        )
    }
    val contextual = result.withInvocationContext(context.request.invocationContext)
    val savedRelationshipIds = relationshipIds.orEmpty().split('|').filter(String::isNotBlank)
    return if (savedRelationshipIds.size == contextual.relationships.size) {
        contextual.copy(relationships = contextual.relationships.mapIndexed { index, relationship ->
            relationship.copy(id = ArchitectureId(savedRelationshipIds[index]))
        })
    } else contextual
}

private fun cloneParseFormat(raw: String): BarcodeFormat =
    cloneParseFormatOrNull(raw) ?: BarcodeFormat.QR_CODE

private fun cloneParseFormatOrNull(raw: String?): BarcodeFormat? =
    raw?.takeUnless { it.equals("SOURCE", ignoreCase = true) || it.isBlank() }
        ?.let { runCatching { BarcodeFormat.valueOf(it.trim().uppercase()) }.getOrNull() }

private fun clonePrettySource(raw: String): String =
    cloneParseFormatOrNull(raw)?.let(::clonePrettyFormat) ?: raw.ifBlank { "Unknown" }

private fun clonePrettyFormat(format: BarcodeFormat): String = when (format) {
    BarcodeFormat.QR_CODE -> "QR"
    BarcodeFormat.CODE_128 -> "Code 128"
    BarcodeFormat.DATA_MATRIX -> "Data Matrix"
    BarcodeFormat.AZTEC -> "Aztec"
    BarcodeFormat.PDF_417 -> "PDF417"
    BarcodeFormat.CODE_39 -> "Code 39"
    BarcodeFormat.EAN_13 -> "EAN-13"
    BarcodeFormat.EAN_8 -> "EAN-8"
    BarcodeFormat.UPC_A -> "UPC-A"
    BarcodeFormat.UPC_E -> "UPC-E"
    else -> format.name
}

private fun cloneCanEncode(payload: String, format: BarcodeFormat): Boolean {
    if (payload.isEmpty()) return false
    val (width, height) = cloneWriterDimensions(format)
    return runCatching {
        MultiFormatWriter().encode(payload, format, width, height, cloneHints(format))
    }.isSuccess
}

private fun cloneDimensions(format: BarcodeFormat): Pair<Int, Int> = when (format) {
    BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.EAN_13,
    BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E -> 960 to 320
    BarcodeFormat.PDF_417 -> 960 to 480
    else -> 720 to 720
}

private fun cloneWriterDimensions(format: BarcodeFormat): Pair<Int, Int> = when (format) {
    BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.EAN_13,
    BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E -> 360 to 120
    BarcodeFormat.PDF_417 -> 360 to 180
    else -> 320 to 320
}

private fun cloneHints(format: BarcodeFormat): Map<EncodeHintType, Any> {
    val hints = mutableMapOf<EncodeHintType, Any>(
        EncodeHintType.MARGIN to if (format == BarcodeFormat.QR_CODE) 4 else 2
    )
    if (format == BarcodeFormat.QR_CODE) hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.H
    return hints
}

private fun cloneRenderCode(payload: String, format: BarcodeFormat): CloneRenderedCode {
    val (writerWidth, writerHeight) = cloneWriterDimensions(format)
    val matrix = MultiFormatWriter().encode(payload, format, writerWidth, writerHeight, cloneHints(format))
    val raw = cloneMatrixToBitmap(matrix)
    val (targetWidth, targetHeight) = cloneDimensions(format)
    val bitmap = Bitmap.createScaledBitmap(raw, targetWidth, targetHeight, false)
    if (raw !== bitmap) raw.recycle()
    // Clone intentionally leaves the symbol pristine. Branding belongs to
    // barcode.generate; barcode.clone prioritises scanner/print fidelity.
    return CloneRenderedCode(bitmap, format)
}

private fun cloneMatrixToBitmap(matrix: BitMatrix): Bitmap {
    val pixels = IntArray(matrix.width * matrix.height)
    val black = android.graphics.Color.BLACK
    val white = android.graphics.Color.WHITE
    for (y in 0 until matrix.height) {
        val offset = y * matrix.width
        for (x in 0 until matrix.width) pixels[offset + x] = if (matrix[x, y]) black else white
    }
    return Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888).also {
        it.setPixels(pixels, 0, matrix.width, 0, 0, matrix.width, matrix.height)
    }
}

private fun cloneCopyPayload(context: Context, payload: String) {
    if (payload.isEmpty()) return
    context.getSystemService(ClipboardManager::class.java)
        .setPrimaryClip(ClipData.newPlainText("Barcode payload", payload))
    Toast.makeText(context, "Payload copied", Toast.LENGTH_SHORT).show()
}

private fun cloneMaterializeCommittedImage(
    context: Context,
    bitmap: Bitmap,
    format: BarcodeFormat
): Uri {
    val folder = File(context.cacheDir, "barcode_clone_result").apply { mkdirs() }
    val file = File(folder, "methodmesh_barcode_clone_${format.name.lowercase()}_${System.currentTimeMillis()}.png")
    file.outputStream().use { out ->
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "Could not encode barcode PNG." }
    }
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}

private fun cloneMetadataAttachment(context: Context, metadataJson: String): ResultShare.Attachment? {
    if (metadataJson.isBlank()) return null
    val folder = File(context.cacheDir, "barcode_clone_share").apply { mkdirs() }
    val file = File(folder, "methodmesh_barcode_clone_${System.currentTimeMillis()}_metadata.json")
    file.writeText(metadataJson, Charsets.UTF_8)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    return ResultShare.Attachment(file.name, uri)
}

private fun cloneShareImage(
    context: Context,
    imageUri: String,
    format: BarcodeFormat,
    payloadText: String,
    metadataJson: String
) {
    val image = Uri.parse(imageUri)
    val metadata = cloneMetadataAttachment(context, metadataJson)?.uri
    val streams = arrayListOf(image).apply { metadata?.let { add(it) } }
    val intent = if (streams.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, image)
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, streams)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/png", "application/json"))
        }
    }.apply {
        if (payloadText.isNotBlank()) putExtra(Intent.EXTRA_TEXT, payloadText)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        clipData = ClipData.newUri(context.contentResolver, "MethodMesh cloned barcode", streams.first()).apply {
            streams.drop(1).forEach { addItem(ClipData.Item(it)) }
        }
    }

    context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY).forEach { info ->
        streams.forEach { uri ->
            context.grantUriPermission(info.activityInfo.packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
    context.startActivity(
        Intent.createChooser(intent, "Share cloned ${clonePrettyFormat(format)} code").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = intent.clipData
        }
    )
}

private fun cloneCopyImage(context: Context, imageUri: String, payloadText: String) {
    val uri = Uri.parse(imageUri)
    val clip = ClipData.newUri(context.contentResolver, "MethodMesh barcode clone", uri)
    if (payloadText.isNotBlank()) clip.addItem(ClipData.Item(payloadText))
    context.getSystemService(ClipboardManager::class.java).setPrimaryClip(clip)
    Toast.makeText(context, if (payloadText.isBlank()) "Barcode image copied" else "Barcode image + payload copied", Toast.LENGTH_SHORT).show()
}

private fun cloneSaveImage(
    context: Context,
    imageUri: String,
    metadataJson: String
): OutputExportRepository.DownloadsExport = OutputExportRepository.saveToDownloads(
    context = context,
    label = "barcode_clone",
    text = "",
    mediaUris = listOf(imageUri),
    jsonText = metadataJson
)

private fun cloneTechnicalRows(fields: Map<String, Any?>): List<Pair<String, String>> = listOf(
    "Clone image" to fields["barcode_clone_image_uri"]?.toString().orEmpty(),
    "Payload" to fields["barcode_payload"]?.toString().orEmpty(),
    "Payload kind" to fields["barcode_payload_kind"]?.toString().orEmpty(),
    "URL" to fields["barcode_payload_url"]?.toString().orEmpty(),
    "Source format" to fields["barcode_source_format"]?.toString().orEmpty(),
    "Clone format" to fields["barcode_clone_format"]?.toString().orEmpty(),
    "SHA-256" to fields["barcode_payload_sha256"]?.toString().orEmpty(),
    "Evidence format" to fields[BarcodeEvidenceFields.FORMAT_FIELD]?.toString().orEmpty(),
    "Evidence hash" to fields[BarcodeEvidenceFields.HASH_FIELD]?.toString().orEmpty(),
    "Scan time" to fields["barcode_scan_time_iso"]?.toString().orEmpty(),
    "Clone time" to fields["barcode_clone_time_iso"]?.toString().orEmpty(),
    "Source" to fields["barcode_source"]?.toString().orEmpty()
).filter { it.second.isNotBlank() }

@Composable
private fun CloneTechnicalValue(label: String, value: String, onCopy: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(enabled = value.isNotBlank(), onClick = onCopy),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("TAP TO COPY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            Text(value, style = MaterialTheme.typography.bodyMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun Context.findCloneActivity(): android.app.Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is android.app.Activity) return current
        current = current.baseContext
    }
    return current as? android.app.Activity
}

val BarcodeCloneCapabilityScreen: CapabilityScreenSpec = CodeCloneCapabilityScreen()
