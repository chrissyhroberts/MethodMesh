# Four-seat, flag picker and transcript UX contract

## Design intent

The interface must remain usable when the people around the device do not share a language and cannot explain the controls to one another.

### Participant controls

Every participant-facing zone must expose, in order from the participant's edge inward:

1. current flag + native language name;
2. Arabic variant selector when and only when Arabic is selected;
3. prominent localised Talk button;
4. latest original/translation and replay where space permits.

The flag/language selector must remain available during an active conversation.

### Flag picker

The flag grid is the default visual route. A participant should be able to identify a familiar flag without first reading English instructions.

Flags map to country/region entries. They do not directly imply a single language where the country is multilingual. Multilingual country entries must display a language choice using native language labels.

The A–Z language route is always available alongside the flag grid.

### Arabic

Arabic is `ar` for ML Kit Translation. Regional speech selection is separate.

The Arabic variant control must present exactly three primary choices:

- Levantine · الشامية
- Gulf · الخليجية
- North African · شمال أفريقيا

Country selection may preselect one of these but must not remove the participant's ability to change it.

### Four-seat translation order

Seat order is A → B → C → D clockwise.

For a spoken turn:

- show the original on all seats whose language equals the source language;
- traverse other seats clockwise;
- skip seats whose language equals the source language;
- translate once per distinct remaining language;
- reuse each translation for every seat using that target language;
- queue spoken translations in the same distinct-language order.

### Transcript

Transcript state is orthogonal to translation state.

When transcript is OFF:

- microphone capture continues;
- translation continues;
- screen output continues;
- TTS continues when enabled;
- turn text is not added to transcript persistence.

A pause marker is persisted when active transcript capture is stopped. A resume marker is persisted when capture restarts after an unrecorded interval. Starting transcript after earlier unrecorded conversation must explicitly state that earlier content was not transcribed.
