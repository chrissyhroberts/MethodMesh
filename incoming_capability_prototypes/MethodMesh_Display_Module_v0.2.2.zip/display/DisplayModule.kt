package com.example.methodmesh.modules.display

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

/** One canonical display capability with presentation options rather than mode-specific methods. */
object DisplayModule : MethodMeshModule {
    override val moduleId = "display"
    override val displayName = "Display"
    override val version = "0.2.2"
    override val summary = "Turn the device into a large, readable sign or expressive visual display."
    override val iconKey = "display"

    override fun as100Methods() = listOf(DisplayShowMethod)

    override fun capabilityScreens() = listOf(DisplayCapabilityScreen())

    override fun rilBindings() = listOf(
        RilBinding("show display", DisplayShowMethod.ID, "Show content prominently on a display"),
        RilBinding("show sign", DisplayShowMethod.ID, "Show content prominently on a display"),
        RilBinding("show message", DisplayShowMethod.ID, "Show a large message"),
        RilBinding("scroll message", DisplayShowMethod.ID, "Show a scrolling message"),
        RilBinding("flash message", DisplayShowMethod.ID, "Show a safely rate-limited flashing message")
    )

    override fun capabilitySettings() = mapOf(
        DisplayShowMethod.ID to listOf(
            MethodSetting.ChoiceSetting(
                id = "content_kind",
                label = "Content",
                defaultValue = "text",
                choices = listOf("text", "media")
            ),
            MethodSetting.TextSetting(
                id = "text",
                label = "Message / emoji",
                defaultValue = DisplayShowMethod.DEFAULT_TEXT
            ),
            MethodSetting.TextSetting(
                id = "media_uri",
                label = "Image / GIF URI",
                description = "Android content URI for an image, animated GIF or animated WebP.",
                defaultValue = ""
            ),
            MethodSetting.ChoiceSetting(
                id = "motion",
                label = "Motion",
                defaultValue = "still",
                choices = listOf("still", "scroll", "flash", "pulse")
            ),
            MethodSetting.ChoiceSetting(
                id = "theme",
                label = "Appearance",
                defaultValue = "white_on_black",
                choices = listOf(
                    "white_on_black",
                    "black_on_white",
                    "black_on_yellow",
                    "neon",
                    "rainbow",
                    "pride",
                    "fabulous"
                )
            ),
            MethodSetting.ChoiceSetting(
                id = "alignment",
                label = "Alignment",
                defaultValue = "center",
                choices = listOf("start", "center", "end")
            ),
            MethodSetting.ChoiceSetting(
                id = "content_rotation",
                label = "Content rotation",
                defaultValue = "0",
                choices = listOf("0", "90", "180", "270")
            ),
            MethodSetting.FloatSetting(
                id = "text_scale",
                label = "Text size",
                description = "Fraction of the largest non-clipping fitted text size.",
                defaultValue = 1f,
                minimum = 0.2f,
                maximum = 1f,
                step = 0.05f
            ),
            MethodSetting.FloatSetting(
                id = "speed",
                label = "Motion speed",
                description = "Scroll/pulse speed. Flash is always capped at 2 Hz.",
                defaultValue = 1f,
                minimum = 0.25f,
                maximum = 4f,
                step = 0.25f
            ),
            MethodSetting.ChoiceSetting(
                id = "direction",
                label = "Scroll direction",
                defaultValue = "left",
                choices = listOf("left", "right")
            ),
            MethodSetting.BooleanSetting(
                id = "high_brightness",
                label = "Use high brightness while showing",
                defaultValue = true
            )
        )
    )
}
