# Display v0.2.2 validation notes

## Deliberate redesign

v0.2 removes the unused experimental method IDs:

- `display.static`
- `display.marquee`
- `display.board`
- `display.code`
- `display.sequence`

No compatibility aliases are retained because those methods had not been used. The only canonical method is now `display.show`.

## Review corrections included

- Removed method proliferation where multiple methods differed only by presentation settings.
- Multi-line boards and giant short codes now fall out naturally from text + auto-fit.
- Marquee became `motion=scroll`.
- Flash and pulse became motion settings, with flash hard-capped at 2 Hz.
- Added technical light/dark/high-visibility appearances plus neon/rainbow/pride/fabulous appearances.
- Emoji use the normal Android text stack and participate in automatic fitting.
- Added image/GIF/animated-WebP selection without adding a third-party image dependency.
- Media references remain URI-based; canonical output records MIME and SHA-256 when readable.
- Fixed the previous marquee pause behaviour so pause preserves the live offset.
- Scrolling is now a true single-line marquee sized from available height, with screen-relative travel speed and complete off-screen-to-off-screen traversal.
- Replaced A−/A+ and Slower/Faster step buttons with continuous text-size and motion-speed sliders in both configuration and live presentation controls.
- Removed the separate `auto_fit`/manual sizing mode; text size is now one continuous relative-fit parameter, which avoids discontinuous jumps when adjusting live text.
- Text size is now a 20–100% fraction of the largest measured non-clipping size; Fit resets to 100%, avoiding the previous large-to-tiny discontinuity.
- Scrolling text is sized from available height only; horizontal width is deliberately unconstrained because the marquee exists to carry content wider than the viewport.
- Fixed a marquee clipping regression where the `Text` child inherited the viewport's maximum width before translation. The marquee now measures the complete single-line layout and draws that full layout onto the clipping viewport canvas, including terminal emoji and other wide grapheme clusters.
- Marquee travel includes explicit edge padding and moves the complete measured line from fully off-screen on one side to fully off-screen on the other.
- Replaced the previous fixed-size pseudo-Fit behaviour with measured auto-fit that never breaks inside a word or emoji token; wrapping occurs only at whitespace or explicit newlines.
- Configuration preview and full-screen presentation now share the same renderer, so colour themes, gradient text, motion, rotation, fitting and media preview consistently.
- Replaced large pill-heavy configuration controls with compact rectangular wrapped selectors; Appearance no longer relies on a clipped horizontal row.
- 90/270-degree content rotation uses a swapped layout viewport to reduce clipping.
- Bottom controls use Android navigation-bar padding plus 18 dp extra clearance.
- Live controls auto-hide after three seconds and reappear on tap.
- Shared `CapabilityScreenScaffold` now owns automatic return after a committed result; the capability does not invoke the caller twice.
- Fixed presets/external requests may start the display immediately through `CapabilityScreenContext.startsImmediately`.

## Media platform behaviour

The project minimum SDK is API 27. Platform `ImageDecoder` is used from API 28 upward and supports animated image drawables. API 27 uses the platform drawable fallback; some animated formats may therefore display a static frame on API 27.

No new Gradle dependency is required.

## Safety

The visual `flash` effect is capped at 2 Hz regardless of requested speed. It should still be used with judgement around people with photosensitive conditions. The module does not implement unrestricted strobing.

## Build status

This module was revised against the current public MethodMesh app interfaces and dependency set, including the current `MethodSetting` signatures and `CapabilityScreenContext`/`CapabilityScreenScaffold` lifecycle. A complete local Android project/SDK is not mounted in this execution environment, so `:app:compileDebugKotlin` and device rendering could not be executed here.

Run locally after drop-in:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
```

Then smoke-test:

1. white-on-black still text and emoji;
2. black-on-white and black-on-yellow;
3. long auto-fitted multi-line text;
4. left/right scrolling with pause/resume, speed slider and text-size slider;
5. flash speed clamp at 2 Hz;
6. pulse;
7. rotation through 0/90/180/270;
8. Android 3-button navigation and gesture navigation control clearance;
9. image, GIF and animated WebP selection;
10. direct/manual Commit lifecycle;
11. fixed Preset immediate start;
12. Ask-when-run Preset;
13. Protocol step;
14. ODK/external automatic return.
