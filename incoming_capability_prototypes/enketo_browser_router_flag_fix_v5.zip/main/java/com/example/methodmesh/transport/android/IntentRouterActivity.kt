package com.example.methodmesh.transport.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Public Android/ODK entry point for MethodMesh.
 *
 * ODK/other Android callers use the normal Activity result channel. Browser
 * deep links are different: Chrome/Enketo is not waiting for an Activity
 * result, so simply finishing this activity can expose an older MethodMesh
 * MainActivity underneath it. For BROWSABLE methodmesh:// launches we remember
 * the browser package and explicitly bring that browser back to the foreground
 * after the transient workflow completes.
 */
class IntentRouterActivity : ComponentActivity() {
    private var browserLaunch: Boolean = false
    private var browserCallerPackage: String? = null

    private val workflowLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        setResult(result.resultCode, result.data)
        if (browserLaunch) {
            returnToCallingBrowser()
        } else {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        browserLaunch = intent.action == Intent.ACTION_VIEW &&
            intent.categories?.contains(Intent.CATEGORY_BROWSABLE) == true &&
            intent.data?.scheme.equals("methodmesh", ignoreCase = true)

        if (browserLaunch) {
            // Chrome and several Android browsers include the historical
            // Browser.EXTRA_APPLICATION_ID value. getReferrer() is a useful
            // fallback and commonly has the form android-app://<package>.
            browserCallerPackage = intent
                .getStringExtra("com.android.browser.application_id")
                ?.takeIf { it.isNotBlank() }
                ?: referrer
                    ?.takeIf { it.scheme == "android-app" }
                    ?.host
                    ?.takeIf { it.isNotBlank() }
        }

        workflowLauncher.launch(workflowIntentFor(intent))
    }


    /**
     * Build a payload-equivalent child intent without inheriting the browser's
     * task-navigation flags. Browsers normally enter an external application
     * with FLAG_ACTIVITY_NEW_TASK. Passing that flag on to an activity launched
     * with StartActivityForResult makes Android report an immediate cancelled
     * result because the child is placed in a different task. The capability
     * may still open elsewhere, which is exactly the race that caused Enketo to
     * be restored before the biometric prompt appeared.
     *
     * Keep URI permission grants, action, data, MIME type, clip data and extras;
     * deliberately discard activity/task-routing flags. This is generic for all
     * MethodMesh browser call-outs, not fingerprint-specific.
     */
    private fun workflowIntentFor(incoming: Intent): Intent =
        Intent(this, ExternalWorkflowActivity::class.java).apply {
            action = incoming.action
            setDataAndType(incoming.data, incoming.type)
            clipData = incoming.clipData
            incoming.extras?.let { putExtras(it) }
            flags = incoming.flags and URI_GRANT_FLAGS
        }

    private fun returnToCallingBrowser() {
        val caller = browserCallerPackage
        if (!caller.isNullOrBlank()) {
            val browserIntent = packageManager.getLaunchIntentForPackage(caller)
            if (browserIntent != null) {
                browserIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                        Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                )
                val relaunched = runCatching { startActivity(browserIntent) }.isSuccess
                if (relaunched) {
                    finish()
                    return
                }
            }
        }

        // Fallback for browsers that do not identify themselves. A BROWSABLE
        // MethodMesh launch is transient; putting its task behind the previous
        // task is preferable to exposing MethodMesh Home after verification.
        moveTaskToBack(true)
        finish()
    }

    private companion object {
        val URI_GRANT_FLAGS: Int =
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
    }
}
