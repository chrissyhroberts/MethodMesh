package com.example.methodmesh.modules.visualdatamapper

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.view.MotionEvent
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

object VisualDataMapperCapabilityScreens {
    val all:List<CapabilityScreenSpec> = listOf(
        VisualDesignStudioScreen, VisualDesignLibraryScreen,
        VisualRuntimeScreen(VisualDataMapperMethods.Binary),
        VisualRuntimeScreen(VisualDataMapperMethods.Intensity),
        VisualRuntimeScreen(VisualDataMapperMethods.Record),
        VisualRuntimeScreen(VisualDataMapperMethods.Persistent)
    )
}

object VisualDesignStudioScreen:CapabilityScreenSpec{
    override val capabilityId=VisualDataMapperMethods.Design.id
    override val title="Region Design Studio"
    override val description="Teach MethodMesh what a picture means."

    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
        val android=LocalContext.current
        val repo=remember{VisualDataMapperRepository(android.applicationContext)}
        var source by remember{mutableStateOf<Bitmap?>(null)}
        var boundaries by remember{mutableStateOf<Bitmap?>(null)}
        var threshold by rememberSaveable{mutableIntStateOf(70)}
        var drawBoundary by rememberSaveable{mutableStateOf(false)}
        var regions by remember{mutableStateOf<List<VisualRegion>>(emptyList())}
        var pending by remember{mutableStateOf<RegionGeometry?>(null)}
        var pendingLabel by remember{mutableStateOf("")}
        var designName by rememberSaveable{mutableStateOf("New visual design")}
        var status by remember{mutableStateOf("Choose a clean training image, then find regions.")}
        var result by remember{mutableStateOf<ExecutionResult?>(null)}

        val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri:Uri?->
            uri?:return@rememberLauncherForActivityResult
            runCatching{
                android.contentResolver.openInputStream(uri).use{input->requireNotNull(input); BitmapFactory.decodeStream(input)}
            }.onSuccess{bmp->source=bmp;boundaries=null;regions=emptyList();status="Image loaded. Tap Find regions."}
             .onFailure{status="Could not open image: ${it.message}"}
        }

        fun commitDesign(){
            val src=source?:return
            val id=designName.lowercase().replace(Regex("[^a-z0-9]+"),"_").trim('_').ifBlank{"design_${System.currentTimeMillis()}"}
            val training=repo.saveImage("${id}_training",src)
            val design=VisualDesign(id=id,name=designName,sourceWidth=src.width,sourceHeight=src.height,trainingImage=training,presentationImage=training,regions=regions)
            repo.saveDesign(design)
            val records=JSONArray().put(JSONObject().put("region_id","design:$id").put("values",JSONObject().put("saved","true"))).toString()
            val method=VisualDataMapperMethods.Design
            val request=method.request(capabilityId,context.request.invocationContext.asMap(capabilityId)+mapOf(
                VisualDataMapperFields.DESIGN_ID to id,VisualDataMapperFields.DESIGN_VERSION to "1",VisualDataMapperFields.REGION_COUNT to regions.size.toString(),VisualDataMapperFields.RECORDS_JSON to records
            ))
            result=method.result(request,request.context).withInvocationContext(context.request.invocationContext)
        }

        CapabilityScreenScaffold(title=title,capabilityId=capabilityId,context=context,canGoBack=context.stepNumber>1,capturedResult=result,
            resultPreview=result?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={result=null},onConfirm={result?.let(onConfirmed)},onCancel=onCancel){
            OutlinedTextField(value=designName,onValueChange={designName=it},label={Text("Design name")},modifier=Modifier.fillMaxWidth())
            Button(onClick={picker.launch(arrayOf("image/png","image/jpeg","image/*"))},modifier=Modifier.fillMaxWidth()){Text(if(source==null)"Choose training image" else "Replace training image")}
            source?.let{src->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                    Button(onClick={boundaries=VisualDataMapperEngine.edgeMap(src,threshold);status="Regions ready. Tap an enclosed area."},modifier=Modifier.weight(1f)){Text("Find regions")}
                    OutlinedButton(onClick={drawBoundary=!drawBoundary},modifier=Modifier.weight(1f)){Text(if(drawBoundary)"Boundary tool on" else "Draw boundary")}
                }
                Text("Detection detail: $threshold")
                Slider(value=threshold.toFloat(),onValueChange={threshold=it.toInt()},valueRange=25f..180f)
                boundaries?.let{edge->
                    AndroidView(modifier=Modifier.fillMaxWidth().height(460.dp),factory={ctx->
                        RegionAuthoringView(ctx,src,edge,{regions},{nx,ny->
                            val g=VisualDataMapperEngine.floodRegion(edge,(nx*edge.width).toInt(),(ny*edge.height).toInt())
                            if(g==null) status="That fill escaped or hit a boundary. Undo/close the gap and try again."
                            else {pending=g;pendingLabel="Region ${regions.size+1}"}
                        },{x0,y0,x1,y1-> if(drawBoundary){VisualDataMapperEngine.drawBoundary(edge,x0,y0,x1,y1);status="Boundary added. Tap the area again."}}, {drawBoundary})
                    },update={it.invalidate()})
                }
                Text("${regions.size} regions · $status")
                if(regions.isNotEmpty()) OutlinedButton(onClick={regions=regions.dropLast(1);status="Last region removed."},modifier=Modifier.fillMaxWidth()){Text("Undo last region")}
                Button(onClick={commitDesign()},enabled=regions.isNotEmpty()&&designName.isNotBlank(),modifier=Modifier.fillMaxWidth()){Text("Save design")}
            }
        }

        if(pending!=null) AlertDialog(onDismissRequest={pending=null},title={Text("Name this area")},text={OutlinedTextField(value=pendingLabel,onValueChange={pendingLabel=it},singleLine=true)},
            confirmButton={TextButton(onClick={
                val label=pendingLabel.trim().ifBlank{"Region ${regions.size+1}"}; val id=uniqueRegionId(label,regions)
                regions=regions+VisualRegion(id=id,label=label,geometry=pending!!);pending=null;status="Added $label."
            }){Text("Add region")}},dismissButton={TextButton(onClick={pending=null}){Text("Cancel")}})
    }
}

object VisualDesignLibraryScreen:CapabilityScreenSpec{
    override val capabilityId=VisualDataMapperMethods.Library.id
    override val title="Visual designs"
    override val description="Reusable visual instruments stored on this device."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
        val android=LocalContext.current; val repo=remember{VisualDataMapperRepository(android.applicationContext)}
        var ids by remember{mutableStateOf(repo.designIds())}
        CapabilityScreenScaffold(title=title,capabilityId=capabilityId,context=context,canGoBack=context.stepNumber>1,capturedResult=null,resultPreview=emptyMap(),onBack=onBack,onRetry={ids=repo.designIds()},onConfirm={},onCancel=onCancel){
            if(ids.isEmpty()) Text("No saved designs yet. Open Region Design Studio to teach MethodMesh a picture.")
            LazyColumn(Modifier.fillMaxWidth().heightIn(max=620.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                items(ids){id-> val d=repo.loadDesign(id); if(d!=null) Card(Modifier.fillMaxWidth()){
                    Column(Modifier.padding(16.dp)){Text(d.name,style=MaterialTheme.typography.titleMedium);Text("${d.regions.size} regions · v${d.version}");Text(d.id,style=MaterialTheme.typography.bodySmall)}
                }}
            }
        }
    }
}

class VisualRuntimeScreen(private val method:VisualDataMapperMethod):CapabilityScreenSpec{
    override val capabilityId=method.id
    override val title=when(method.mode){RegionInteractionMode.Binary->"Visual selector";RegionInteractionMode.Intensity->"Visual intensity";RegionInteractionMode.Persistent->"Persistent visual map";else->"Visual record"}
    override val description="Touch the thing in the picture to record data about it."

    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
        val android=LocalContext.current; val repo=remember{VisualDataMapperRepository(android.applicationContext)}
        val designId=context.action.settings["design_id"].orEmpty().ifBlank{repo.designIds().firstOrNull().orEmpty()}
        val design=remember(designId){repo.loadDesign(designId)}
        val stateKey=context.action.settings["state_key"].orEmpty().ifBlank{if(method.mode==RegionInteractionMode.Persistent)"$designId.default" else ""}
        var records by remember(designId,stateKey){mutableStateOf(loadRecords(repo,stateKey))}
        var touched by remember{mutableStateOf<String?>(null)}
        var editing by remember{mutableStateOf<VisualRegion?>(null)}
        var result by remember{mutableStateOf<ExecutionResult?>(null)}
        var viewMode by rememberSaveable{mutableStateOf("Data")}
        val image=remember(designId){design?.let{repo.loadImage(it.presentationImage?:it.trainingImage)}}

        fun updateRegion(region:VisualRegion){
            touched=region.id
            when(method.mode){
                RegionInteractionMode.Binary,RegionInteractionMode.Persistent->{
                    val existing=records.indexOfFirst{it.regionId==region.id}
                    records=if(existing>=0) records.filterIndexed{i,_->i!=existing} else records+RegionRecord(region.id,values=mapOf("selected" to "true"))
                    if(method.mode==RegionInteractionMode.Persistent&&stateKey.isNotBlank()) repo.saveState(stateKey,recordsJson(records))
                }
                RegionInteractionMode.Intensity,RegionInteractionMode.Record->editing=region
                else->Unit
            }
        }
        fun commit(){
            val d=design?:return
            val values=mapOf(VisualDataMapperFields.DESIGN_ID to d.id,VisualDataMapperFields.DESIGN_VERSION to d.version.toString(),VisualDataMapperFields.REGION_COUNT to d.regions.size.toString(),VisualDataMapperFields.RECORDS_JSON to recordsJson(records),VisualDataMapperFields.STATE_KEY to stateKey)
            val req=method.request(capabilityId,context.request.invocationContext.asMap(capabilityId)+context.action.settings+values)
            result=method.result(req,values).withInvocationContext(context.request.invocationContext)
        }

        CapabilityScreenScaffold(title=title,capabilityId=capabilityId,context=context,canGoBack=context.stepNumber>1,capturedResult=result,resultPreview=result?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={result=null},onConfirm={result?.let(onConfirmed)},onCancel=onCancel){
            if(design==null){Text("No visual design found. Create one in Region Design Studio, or supply design_id.");return@CapabilityScreenScaffold}
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(design.name,style=MaterialTheme.typography.titleMedium);Text("${records.size} / ${design.regions.size}")}
            if(image!=null) AndroidView(modifier=Modifier.fillMaxWidth().height(520.dp),factory={ctx->RegionRuntimeView(ctx,image,design,{records},{touched},::updateRegion)},update={it.invalidate()})
            else Text("Presentation image missing; design geometry is still available but this first version requires the local image for visual use.")
            touched?.let{id->Text(design.regions.firstOrNull{it.id==id}?.label?:id)}
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton(onClick={viewMode=if(viewMode=="Data")"Completion" else "Data"},modifier=Modifier.weight(1f)){Text("View: $viewMode")}
                OutlinedButton(onClick={if(records.isNotEmpty()){records=records.dropLast(1); if(method.mode==RegionInteractionMode.Persistent&&stateKey.isNotBlank())repo.saveState(stateKey,recordsJson(records))}},modifier=Modifier.weight(1f)){Text("Undo")}
            }
            if(method.mode!=RegionInteractionMode.Persistent) Button(onClick={commit()},modifier=Modifier.fillMaxWidth()){Text("Commit")}
            else Text("Changes are stored immediately for this persistent map. Undo remains available.",style=MaterialTheme.typography.bodySmall)
        }

        editing?.let { region ->
            RegionEditorDialog(
                region = region,
                mode = method.mode,
                existing = records.firstOrNull { it.regionId == region.id },
                onSave = { record -> records = records.filterNot { it.regionId == region.id } + record; editing = null },
                onCancel = { editing = null }
            )
        }
    }
}

@Composable private fun RegionEditorDialog(region:VisualRegion,mode:RegionInteractionMode,existing:RegionRecord?,onSave:(RegionRecord)->Unit,onCancel:()->Unit){
    if(mode==RegionInteractionMode.Intensity){
        var value by remember(region.id){mutableIntStateOf(existing?.values?.get("intensity")?.toIntOrNull()?:0)}
        AlertDialog(onDismissRequest=onCancel,title={Text(region.label)},text={Column{Text("Intensity: $value");Slider(value=value.toFloat(),onValueChange={value=it.toInt()},valueRange=0f..5f,steps=4)}},
            confirmButton={TextButton(onClick={onSave(RegionRecord(region.id,values=mapOf("intensity" to value.toString())))}){Text("Done")}},dismissButton={TextButton(onClick=onCancel){Text("Cancel")}})
    }else{
        val vars=if(region.variables.isEmpty()) listOf(RegionVariable("note","Note",RegionVariableType.Text)) else region.variables
        val values=remember(region.id){mutableStateMapOf<String,String>().apply{putAll(existing?.values.orEmpty())}}
        AlertDialog(onDismissRequest=onCancel,title={Text(region.label)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){vars.forEach{v->
            when(v.type){
                RegionVariableType.Binary->Row{Text(v.label,Modifier.weight(1f));Switch(checked=values[v.id]=="true",onCheckedChange={values[v.id]=it.toString()})}
                RegionVariableType.SingleSelect,RegionVariableType.Ordinal->Column{Text(v.label);v.choices.forEach{choice->Row{RadioButton(selected=values[v.id]==choice,onClick={values[v.id]=choice});Text(choice)}}}
                else->OutlinedTextField(value=values[v.id].orEmpty(),onValueChange={values[v.id]=it},label={Text(v.label)},modifier=Modifier.fillMaxWidth())
            }
        }}},confirmButton={TextButton(onClick={onSave(RegionRecord(region.id,values=values.toMap()))}){Text("Done")}},dismissButton={TextButton(onClick=onCancel){Text("Cancel")}})
    }
}

private class RegionRuntimeView(context:android.content.Context,private val bitmap:Bitmap,private val design:VisualDesign,private val records:()->List<RegionRecord>,private val touched:()->String?,private val onTap:(VisualRegion)->Unit):View(context){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private var downX=0f;private var downY=0f
    override fun onDraw(c:Canvas){super.onDraw(c);val dst=fitRect(width.toFloat(),height.toFloat(),bitmap.width.toFloat(),bitmap.height.toFloat());c.drawBitmap(bitmap,null,dst,p)
        design.regions.forEach{r-> val rec=records().firstOrNull{it.regionId==r.id}; if(rec!=null)drawSpans(c,r.displayGeometry?:r.geometry,dst,Color.argb(95,35,145,90)); if(touched()==r.id)drawSpans(c,r.hitGeometry?:r.geometry,dst,Color.argb(90,255,190,0))}
    }
    override fun onTouchEvent(e:MotionEvent):Boolean{when(e.actionMasked){MotionEvent.ACTION_DOWN->{downX=e.x;downY=e.y;return true};MotionEvent.ACTION_UP->{if(kotlin.math.abs(e.x-downX)<20&&kotlin.math.abs(e.y-downY)<20){val dst=fitRect(width.toFloat(),height.toFloat(),bitmap.width.toFloat(),bitmap.height.toFloat());if(dst.contains(e.x,e.y)){val nx=(e.x-dst.left)/dst.width();val ny=(e.y-dst.top)/dst.height();design.regionAt(nx,ny)?.let{onTap(it);performClick();invalidate()}}};return true}};return true}
    override fun performClick():Boolean{super.performClick();return true}
    private fun drawSpans(c:Canvas,g:RegionGeometry,dst:RectF,color:Int){p.color=color;p.style=Paint.Style.FILL;val sx=dst.width()/g.width;val sy=dst.height()/g.height;g.spans.forEach{s->c.drawRect(dst.left+s.x0*sx,dst.top+s.y*sy,dst.left+(s.x1+1)*sx,dst.top+(s.y+1)*sy,p)}}
}

private class RegionAuthoringView(context:android.content.Context,private val source:Bitmap,private val boundaries:Bitmap,private val regions:()->List<VisualRegion>,private val onTap:(Float,Float)->Unit,private val onBoundary:(Int,Int,Int,Int)->Unit,private val boundaryMode:()->Boolean):View(context){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG);private var sx=0;private var sy=0
    override fun onDraw(c:Canvas){super.onDraw(c);val dst=fitRect(width.toFloat(),height.toFloat(),source.width.toFloat(),source.height.toFloat());c.drawBitmap(source,null,dst,p);regions().forEachIndexed{i,r->drawSpans(c,r.geometry,dst,Color.argb(70,40+(i*31)%180,130,210))}}
    override fun onTouchEvent(e:MotionEvent):Boolean{val dst=fitRect(width.toFloat(),height.toFloat(),source.width.toFloat(),source.height.toFloat());fun px(x:Float)=(((x-dst.left)/dst.width())*source.width).toInt().coerceIn(0,source.width-1);fun py(y:Float)=(((y-dst.top)/dst.height())*source.height).toInt().coerceIn(0,source.height-1)
        when(e.actionMasked){MotionEvent.ACTION_DOWN->{sx=px(e.x);sy=py(e.y);return true};MotionEvent.ACTION_UP->{val ex=px(e.x);val ey=py(e.y);if(boundaryMode())onBoundary(sx,sy,ex,ey)else onTap(ex.toFloat()/source.width,ey.toFloat()/source.height);performClick();invalidate();return true}};return true}
    override fun performClick():Boolean{super.performClick();return true}
    private fun drawSpans(c:Canvas,g:RegionGeometry,dst:RectF,color:Int){p.color=color;val xs=dst.width()/g.width;val ys=dst.height()/g.height;g.spans.forEach{s->c.drawRect(dst.left+s.x0*xs,dst.top+s.y*ys,dst.left+(s.x1+1)*xs,dst.top+(s.y+1)*ys,p)}}
}

private fun fitRect(vw:Float,vh:Float,iw:Float,ih:Float):RectF{val s=minOf(vw/iw,vh/ih);val w=iw*s;val h=ih*s;return RectF((vw-w)/2,(vh-h)/2,(vw+w)/2,(vh+h)/2)}
private fun uniqueRegionId(label:String,regions:List<VisualRegion>):String{val base=label.lowercase().replace(Regex("[^a-z0-9]+"),"_").trim('_').ifBlank{"region"};var id=base;var n=2;while(regions.any{it.id==id})id="${base}_${n++}";return id}
private fun recordsJson(records:List<RegionRecord>)=JSONArray().apply{records.forEach{put(it.toJson())}}.toString()
private fun loadRecords(repo:VisualDataMapperRepository,key:String):List<RegionRecord>{if(key.isBlank())return emptyList();return runCatching{val a=JSONArray(repo.loadState(key)?:"[]");List(a.length()){i->val o=a.getJSONObject(i);RegionRecord(o.optString("region_id"),values=o.optJSONObject("values")?.let{v->v.keys().asSequence().associateWith{v.optString(it)}}.orEmpty())}}.getOrDefault(emptyList())}
