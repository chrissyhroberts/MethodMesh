package com.example.methodmesh.modules.textdocuments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.*

object TextDocumentsCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextDocumentsMethod.ID
    override val title = "Text documents"
    override val description = "Create, open and edit text, Markdown, JSON and JSON Lines files."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val app = LocalContext.current
        val repo = remember { TextDocumentRepository(app) }
        var recent by remember { mutableStateOf(repo.recent()) }
        var draft by remember { mutableStateOf<NewDraft?>(null) }
        var openDoc by remember { mutableStateOf<OpenedDocument?>(null) }
        var newMenu by remember { mutableStateOf(false) }
        var message by remember { mutableStateOf<String?>(null) }

        fun read(uri: Uri, mime: String? = null) {
            runCatching {
                runCatching { app.contentResolver.takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                val name = displayName(app, uri) ?: uri.lastPathSegment ?: "Document"
                val body = app.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val fmt = detectDocumentFormat(name, mime)
                val writable = runCatching { app.contentResolver.openOutputStream(uri, "wa")?.close(); true }.getOrDefault(false)
                repo.remember(uri, name, mime ?: mimeFor(fmt))
                recent = repo.recent()
                openDoc = OpenedDocument(uri, name, body, fmt, writable)
            }.onFailure { message = "Unable to open document: ${it.message ?: "unknown error"}" }
        }

        val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { read(it) } }
        val createLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
            val d = draft
            if (uri != null && d != null) {
                runCatching {
                    app.contentResolver.openOutputStream(uri, "wt")!!.bufferedWriter().use { it.write(d.body) }
                    read(uri, mimeFor(d.format))
                }.onFailure { message = "Unable to create document: ${it.message}" }
            }
            draft = null
        }

        if (openDoc != null) {
            val d = openDoc!!
            DocumentSurface(title=d.title, initialText=d.body, format=d.format, writable=d.writable,
                onBack={ openDoc=null; recent=repo.recent() },
                onSave={ body -> saveDocument(app,d.uri,body) },
                onSaveAs={ body, format ->
                    // Save As is exposed by the editor; SAF creation is handled from workspace for this slice.
                    Result.failure(IllegalStateException("Use New document to choose a new destination."))
                })
            return
        }

        Surface(Modifier.fillMaxSize()) {
            LazyColumn(contentPadding=PaddingValues(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Text("Text documents", style=MaterialTheme.typography.headlineSmall)
                        TextButton(onClick=onBack) { Text("Close") }
                    }
                    Text("Local text files. Nothing is reformatted unless you edit it.", style=MaterialTheme.typography.bodyMedium)
                }
                item {
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        Box {
                            Button(onClick={newMenu=true}) { Text("New document") }
                            DropdownMenu(expanded=newMenu,onDismissRequest={newMenu=false}) {
                                DocumentFormat.entries.forEach { f ->
                                    DropdownMenuItem(text={Text(f.label)}, onClick={
                                        newMenu=false; draft=NewDraft(f,"")
                                        createLauncher.launch(defaultName(f))
                                    })
                                }
                            }
                        }
                        OutlinedButton(onClick={openLauncher.launch(arrayOf("text/plain","text/markdown","application/json","application/x-ndjson","application/jsonl","*/*"))}) { Text("Open file") }
                    }
                }
                item {
                    OutlinedButton(onClick={
                        val clip=(app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip
                        val body=clip?.getItemAt(0)?.coerceToText(app)?.toString().orEmpty()
                        draft=NewDraft(DocumentFormat.TEXT,body); createLauncher.launch("clipboard.txt")
                    }) { Text("Create from clipboard") }
                }
                message?.let { item { Text(it, color=MaterialTheme.colorScheme.error) } }
                item { Text("Recent", style=MaterialTheme.typography.titleMedium) }
                if (recent.isEmpty()) item { Text("No recent documents.", color=MaterialTheme.colorScheme.onSurfaceVariant) }
                items(recent) { d ->
                    Card(Modifier.fillMaxWidth().clickable { read(Uri.parse(d.uri), d.mimeType) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(d.title, style=MaterialTheme.typography.titleSmall)
                            Text(d.mimeType, style=MaterialTheme.typography.labelSmall, color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
private data class NewDraft(val format: DocumentFormat,val body:String)
private data class OpenedDocument(val uri:Uri,val title:String,val body:String,val format:DocumentFormat,val writable:Boolean)
private fun displayName(c:Context,u:Uri):String?=runCatching{c.contentResolver.query(u,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0)else null}}.getOrNull()
private suspend fun saveDocument(c:Context,u:Uri,body:String):Result<Unit> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){runCatching{c.contentResolver.openOutputStream(u,"wt")?.bufferedWriter()?.use{it.write(body)}?:error("Provider did not supply a writable stream")}}
