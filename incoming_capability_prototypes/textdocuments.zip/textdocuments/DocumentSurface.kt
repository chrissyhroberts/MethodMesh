package com.example.methodmesh.modules.textdocuments

import android.content.*
import android.widget.TextView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon

enum class DocumentMode { RENDERED, SOURCE }
enum class DocumentFormat(val label:String) {
    TEXT("Plain text"), MARKDOWN("Markdown"), JSON("JSON"), JSONL("JSON Lines")
}
fun detectDocumentFormat(name:String,mime:String?):DocumentFormat = when {
    mime=="text/markdown" || name.endsWith(".md",true) || name.endsWith(".markdown",true) -> DocumentFormat.MARKDOWN
    mime=="application/json" || name.endsWith(".json",true) -> DocumentFormat.JSON
    mime=="application/x-ndjson" || mime=="application/jsonl" || name.endsWith(".jsonl",true) || name.endsWith(".ndjson",true) -> DocumentFormat.JSONL
    else -> DocumentFormat.TEXT
}
fun mimeFor(f:DocumentFormat)=when(f){DocumentFormat.MARKDOWN->"text/markdown";DocumentFormat.JSON->"application/json";DocumentFormat.JSONL->"application/x-ndjson";DocumentFormat.TEXT->"text/plain"}
fun defaultName(f:DocumentFormat)=when(f){DocumentFormat.MARKDOWN->"document.md";DocumentFormat.JSON->"document.json";DocumentFormat.JSONL->"document.jsonl";DocumentFormat.TEXT->"document.txt"}

@Composable fun DocumentSurface(
    title:String, initialText:String, format:DocumentFormat, writable:Boolean,
    onBack:()->Unit, onSave:suspend(String)->Result<Unit>,
    onSaveAs:suspend(String,DocumentFormat)->Result<Unit> = {_,_->Result.failure(UnsupportedOperationException())},
    modifier:Modifier=Modifier
) {
    val ctx=LocalContext.current
    var text by remember(initialText){mutableStateOf(initialText)}
    var mode by remember(format){mutableStateOf(if(format==DocumentFormat.MARKDOWN)DocumentMode.RENDERED else DocumentMode.SOURCE)}
    var menu by remember{mutableStateOf(false)}
    var find by remember{mutableStateOf(false)}
    var query by remember{mutableStateOf("")}
    var dirty by remember(initialText){mutableStateOf(false)}
    var saving by remember{mutableStateOf(false)}
    var status by remember{mutableStateOf<String?>(null)}
    var closePrompt by remember{mutableStateOf(false)}
    fun requestClose(){ if(dirty&&writable) closePrompt=true else onBack() }
    BackHandler { requestClose() }

    Surface(modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).imePadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start=6.dp,end=14.dp,top=14.dp,bottom=10.dp),verticalAlignment=Alignment.CenterVertically){
                TextButton(onClick={requestClose()}){Text("Close")}
                Text(title,style=MaterialTheme.typography.titleSmall,modifier=Modifier.weight(1f),maxLines=1)
                if(dirty) Text("•",color=MaterialTheme.colorScheme.primary)
            }
            Box(Modifier.weight(1f).fillMaxWidth()){
                if(mode==DocumentMode.RENDERED) MarkdownDocument(text,Modifier.fillMaxSize()) else
                    BasicTextField(text,{text=it;dirty=it!=initialText;status=null},
                        Modifier.fillMaxSize().padding(horizontal=16.dp,vertical=8.dp).verticalScroll(rememberScrollState()),
                        textStyle=MaterialTheme.typography.bodyMedium.copy(color=MaterialTheme.colorScheme.onSurface,fontFamily=androidx.compose.ui.text.font.FontFamily.Monospace),
                        cursorBrush=SolidColor(MaterialTheme.colorScheme.primary))
                Column(Modifier.align(Alignment.BottomEnd).padding(16.dp),horizontalAlignment=Alignment.End){
                    DropdownMenu(menu,{menu=false}){
                        if(format==DocumentFormat.MARKDOWN) DropdownMenuItem({Text(if(mode==DocumentMode.RENDERED)"Edit source" else "Preview")},{mode=if(mode==DocumentMode.RENDERED)DocumentMode.SOURCE else DocumentMode.RENDERED;menu=false})
                        DropdownMenuItem({Text("Find")},{find=true;menu=false})
                        DropdownMenuItem({Text("Copy all")},{(ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(title,text));menu=false})
                        if(writable) DropdownMenuItem({Text("Save")},{saving=true;menu=false})
                    }
                    FloatingActionButton({menu=true},Modifier.size(48.dp)){Text("⋮",style=MaterialTheme.typography.titleLarge)}
                }
            }
            if(find) {
                val count=remember(query,text){if(query.isBlank())0 else Regex(Regex.escape(query),RegexOption.IGNORE_CASE).findAll(text).count()}
                Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer).padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                    BasicTextField(query,{query=it},Modifier.weight(1f),singleLine=true,textStyle=MaterialTheme.typography.bodyMedium.copy(color=MaterialTheme.colorScheme.onSurface),cursorBrush=SolidColor(MaterialTheme.colorScheme.primary))
                    Text(if(query.isBlank())"" else "$count",Modifier.padding(8.dp)); TextButton({find=false}){Text("Close")}
                }
            }
            status?.let{Text(it,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(horizontal=16.dp,vertical=4.dp))}
        }
    }
    if(saving) LaunchedEffect(text){status=onSave(text).fold({dirty=false;"Saved"},{ "Save failed: ${it.message ?: "unknown error"}"});saving=false}
    if(closePrompt) AlertDialog(onDismissRequest={closePrompt=false},title={Text("Unsaved changes")},
        text={Text("Save your changes before closing?")},
        confirmButton={TextButton(onClick={saving=true;closePrompt=false}){Text("Save")}},
        dismissButton={Row{TextButton(onClick={closePrompt=false}){Text("Cancel")};TextButton(onClick={closePrompt=false;onBack()}){Text("Discard")}}})
}
@Composable private fun MarkdownDocument(markdown:String,modifier:Modifier=Modifier){
    val c=LocalContext.current;val m=remember(c){Markwon.create(c)}
    AndroidView(
        factory = { context: android.content.Context ->
            TextView(context).apply {
                textSize = 17f
                setLineSpacing(0f, 1.18f)
                setTextIsSelectable(true)
            }
        },
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        update = { view: TextView ->
            m.setMarkdown(view, markdown)
        }
    )
}
