package com.example.methodmesh.modules.textdocuments

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class RecentTextDocument(val uri: String, val title: String, val mimeType: String, val openedAt: Long)

class TextDocumentRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("textdocuments_recent", Context.MODE_PRIVATE)

    fun recent(): List<RecentTextDocument> {
        val raw = prefs.getString("items", "[]").orEmpty()
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull { i ->
                a.optJSONObject(i)?.let {
                    RecentTextDocument(it.optString("uri"), it.optString("title"), it.optString("mime"), it.optLong("openedAt"))
                }
            }.filter { it.uri.isNotBlank() }.sortedByDescending { it.openedAt }
        }.getOrDefault(emptyList())
    }

    fun remember(uri: Uri, title: String, mimeType: String) {
        val next = listOf(RecentTextDocument(uri.toString(), title, mimeType, System.currentTimeMillis())) +
            recent().filterNot { it.uri == uri.toString() }
        val a = JSONArray()
        next.take(20).forEach { d -> a.put(JSONObject().put("uri", d.uri).put("title", d.title).put("mime", d.mimeType).put("openedAt", d.openedAt)) }
        prefs.edit().putString("items", a.toString()).apply()
    }
}
