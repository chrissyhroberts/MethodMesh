package com.example.methodmesh.modules.textdocuments

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding

object TextDocumentsModule : MethodMeshModule {
    override val moduleId = "textdocuments"
    override val displayName = "Text documents"
    override val summary = "Create, open, read and edit plain text, Markdown, JSON and JSON Lines documents locally."
    override val iconKey = "document"
    override fun as100Methods() = listOf(As100TextDocumentsMethod)
    override fun rilBindings() = listOf(
        RilBinding("open text documents", As100TextDocumentsMethod.ID, "Open the text document workspace"),
        RilBinding("edit text document", As100TextDocumentsMethod.ID, "Open or edit a local text document")
    )
    override fun capabilityScreens() = listOf(TextDocumentsCapabilityScreen)
}
