package com.example.methodmesh.modules.textdocuments

import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.settings.SettingsState

object As100TextDocumentsMethod : As100Method {
    const val ID = "document.text.open"
    private const val VERSION = "0.2.0"
    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Text documents")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID), methodType = MethodObjectType.Method, name = "Text documents", version = VERSION,
        description = "Create, open and edit local text, Markdown, JSON and JSON Lines documents.",
        outputs = listOf("document_status","document_uri","document_title","document_format"),
        graphOutputs = listOf(ID),
        parameters = mapOf("category" to "Document", "status" to "Development", "maturity" to "DEVELOPMENT", "connectivity" to "OFFLINE")
    )
    override val contract = MethodContract(method = ref, producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs, producedGraphOutputs = descriptor.graphOutputs)
    override fun request(action: String, context: Map<String,String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action=action, method=ref, context=context, signals=signals, inputs=inputs)
    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult =
        result(request, mapOf("document_status" to "workspace_opened"), InvocationContext.from(request.context))
    fun result(request: ExecutionRequest, values: Map<String,String>, invocation: InvocationContext?): ExecutionResult {
        val observation = Observation(phenomenon=ID, subject=null, values=values, temporalContext=request.temporalContext,
            provenance=ProvenanceContext("methodmesh.textdocuments", ID, VERSION))
        return As100ExecutionEngine.complete(request, TransformationStatus.Succeeded, observations=listOf(observation),
            transformations=listOf(Transformation(action=ID, method=ref,
                outputs=listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
                status=TransformationStatus.Succeeded, temporalContext=request.temporalContext,
                provenance=ProvenanceContext("methodmesh.textdocuments", ID, VERSION)))).withInvocationContext(invocation)
    }
}
