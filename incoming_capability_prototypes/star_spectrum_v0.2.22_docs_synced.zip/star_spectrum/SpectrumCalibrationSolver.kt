package com.example.methodmesh.modules.star_spectrum

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Explainable wavelength calibration by consensus search.
 *
 * This is deliberately not a classifier. It generates many affine pixel→wavelength
 * hypotheses from candidate absorption troughs and a small physical line catalogue,
 * then asks which simple mapping explains the largest mutually-consistent set of
 * observed troughs. A chromatic wavelength bootstrap, when available, contributes
 * only a weak prior and can never create a line match on its own.
 *
 * The design is conceptually similar to RANSAC / pattern-matching wavelength
 * calibration approaches such as RASCAL, but this implementation is local to
 * MethodMesh and does not copy or depend on third-party source code.
 */
internal object SpectrumCalibrationSolver {

    data class ObservedCandidate(
        val index: Int,
        val distancePx: Double,
        val evidence: Double,
        val localSnr: Double,
        val scaleSamples: Int,
        val source: String
    )

    data class Match(
        val line: CalibrationLine,
        val candidate: ObservedCandidate,
        val predictedWavelengthNm: Double,
        val residualNm: Double,
        val toleranceNm: Double
    ) {
        val normalizedResidual: Double
            get() = abs(residualNm) / toleranceNm.coerceAtLeast(1e-9)

        fun anchor(): CalibrationAnchor = CalibrationAnchor(
            distancePx = candidate.distancePx,
            wavelengthNm = line.wavelengthNm,
            label = line.label
        )
    }

    data class Solution(
        val interceptNm: Double,
        val slopeNmPerPx: Double,
        val matches: List<Match>,
        val rmsNm: Double,
        val chromaticRmsNm: Double?,
        val descriptionLength: Double,
        val supportScore: Double,
        val confidence: Double,
        val scoreMargin: Double = 0.0,
        val ambiguous: Boolean = false
    ) {
        val anchorCount: Int get() = matches.size
        val anchors: List<CalibrationAnchor> get() = matches.map { it.anchor() }
        fun wavelength(distancePx: Double): Double = interceptNm + slopeNmPerPx * distancePx
    }

    data class Result(
        val candidates: List<ObservedCandidate>,
        val solutions: List<Solution>,
        val catalogueName: String,
        val usedChromaticPrior: Boolean
    ) {
        val best: Solution? get() = solutions.firstOrNull()
    }

    /**
     * Initial v0.2.22 catalogue: the four Balmer lines already used by the existing
     * A-star reference workflow. The search machinery is catalogue-agnostic; more
     * line families can be added after validation on independent observations.
     */
    val aStarBalmerCatalogue: List<CalibrationLine> = HydrogenBalmerLines.standard

    fun solveAStarReference(
        extraction: SpectrumExtraction,
        chromaticWavelengthByIndex: DoubleArray? = null,
        maxSolutions: Int = 5
    ): Result {
        val candidates = absorptionCandidates(extraction)
        val solutions = solve(
            candidates = candidates,
            catalogue = aStarBalmerCatalogue,
            extraction = extraction,
            chromaticWavelengthByIndex = chromaticWavelengthByIndex,
            maxSolutions = maxSolutions
        )
        return Result(
            candidates = candidates,
            solutions = solutions,
            catalogueName = "Balmer Hδ/Hγ/Hβ/Hα",
            usedChromaticPrior = chromaticWavelengthByIndex != null
        )
    }

    private fun solve(
        candidates: List<ObservedCandidate>,
        catalogue: List<CalibrationLine>,
        extraction: SpectrumExtraction,
        chromaticWavelengthByIndex: DoubleArray?,
        maxSolutions: Int
    ): List<Solution> {
        if (candidates.size < 2 || catalogue.size < 2) return emptyList()

        val hypotheses = mutableListOf<Solution>()
        val orderedCandidates = candidates.sortedBy { it.distancePx }
        val orderedLines = catalogue.sortedByDescending { it.wavelengthNm }

        for (i in 0 until orderedCandidates.lastIndex) {
            for (j in i + 1 until orderedCandidates.size) {
                val c1 = orderedCandidates[i]
                val c2 = orderedCandidates[j]
                val dx = c2.distancePx - c1.distancePx
                if (abs(dx) < 2.0) continue

                for (a in 0 until orderedLines.lastIndex) {
                    for (b in a + 1 until orderedLines.size) {
                        val l1 = orderedLines[a]
                        val l2 = orderedLines[b]
                        val slope = (l2.wavelengthNm - l1.wavelengthNm) / dx
                        if (!slope.isFinite()) continue

                        // RED→VIOLET trace selection means wavelength should fall with
                        // increasing distance. Keep the bound very broad so colour
                        // geometry is guidance, not a hard instrument model.
                        if (slope >= -0.01 || abs(slope) > 10.0) continue

                        val intercept = l1.wavelengthNm - slope * c1.distancePx
                        val matched = matchCatalogue(
                            candidates = orderedCandidates,
                            catalogue = catalogue,
                            interceptNm = intercept,
                            slopeNmPerPx = slope
                        )
                        if (matched.size < 2) continue

                        val rms = sqrt(matched.map { it.residualNm * it.residualNm }.average())
                        val chromaticRms = chromaticRms(
                            interceptNm = intercept,
                            slopeNmPerPx = slope,
                            extraction = extraction,
                            prior = chromaticWavelengthByIndex
                        )
                        val descriptionLength = descriptionLength(
                            matches = matched,
                            catalogueSize = catalogue.size,
                            chromaticRmsNm = chromaticRms
                        )
                        val supportScore = supportScore(matched, catalogue.size)
                        val confidence = provisionalConfidence(
                            matches = matched,
                            catalogueSize = catalogue.size,
                            rmsNm = rms,
                            chromaticRmsNm = chromaticRms
                        )

                        hypotheses += Solution(
                            interceptNm = intercept,
                            slopeNmPerPx = slope,
                            matches = matched,
                            rmsNm = rms,
                            chromaticRmsNm = chromaticRms,
                            descriptionLength = descriptionLength,
                            supportScore = supportScore,
                            confidence = confidence
                        )
                    }
                }
            }
        }

        if (hypotheses.isEmpty()) return emptyList()

        // Prefer support first, then parsimony. This prevents an exact two-point fit
        // from outranking a slightly noisier solution supported by 3–4 independent
        // Balmer troughs.
        val sorted = hypotheses.sortedWith(
            compareByDescending<Solution> { it.anchorCount }
                .thenBy { it.descriptionLength }
                .thenByDescending { it.supportScore }
        )

        val deduped = mutableListOf<Solution>()
        for (candidate in sorted) {
            val duplicate = deduped.any { existing ->
                abs(existing.slopeNmPerPx - candidate.slopeNmPerPx) <= max(0.002, abs(existing.slopeNmPerPx) * 0.015) &&
                    abs(existing.interceptNm - candidate.interceptNm) <= 3.0
            }
            if (!duplicate) deduped += candidate
            if (deduped.size >= maxSolutions.coerceAtLeast(1)) break
        }

        if (deduped.isEmpty()) return emptyList()
        val bestSolution = deduped.first()
        val bestDescription = bestSolution.descriptionLength
        val second = deduped.getOrNull(1)
        val margin = when {
            second == null -> 8.0
            bestSolution.anchorCount > second.anchorCount ->
                4.0 + 2.0 * (bestSolution.anchorCount - second.anchorCount) +
                    max(0.0, second.descriptionLength - bestDescription)
            else -> max(0.0, second.descriptionLength - bestDescription)
        }

        return deduped.mapIndexed { index, solution ->
            val localMargin = if (index == 0) margin else max(0.0, solution.descriptionLength - bestDescription)
            val ambiguity = index == 0 && (
                solution.anchorCount < 3 ||
                    margin < 1.5 ||
                    solution.confidence < 0.45
                )
            solution.copy(
                scoreMargin = localMargin,
                ambiguous = ambiguity
            )
        }
    }

    private fun matchCatalogue(
        candidates: List<ObservedCandidate>,
        catalogue: List<CalibrationLine>,
        interceptNm: Double,
        slopeNmPerPx: Double
    ): List<Match> {
        data class Pair(
            val line: CalibrationLine,
            val candidate: ObservedCandidate,
            val residualNm: Double,
            val toleranceNm: Double,
            val cost: Double
        )

        val pairs = mutableListOf<Pair>()
        catalogue.forEach { line ->
            candidates.forEach { candidate ->
                val predicted = interceptNm + slopeNmPerPx * candidate.distancePx
                val residual = predicted - line.wavelengthNm
                val tolerance = lineToleranceNm(candidate, slopeNmPerPx)
                val normalized = abs(residual) / tolerance
                if (normalized <= 1.0) {
                    // Prefer small wavelength residuals, but let strong stable troughs
                    // win close contests between nearby candidates.
                    val evidenceBonus = 0.20 * candidate.evidence.coerceIn(0.0, 4.0)
                    pairs += Pair(
                        line = line,
                        candidate = candidate,
                        residualNm = residual,
                        toleranceNm = tolerance,
                        cost = normalized - evidenceBonus
                    )
                }
            }
        }

        val usedLines = mutableSetOf<String>()
        val usedCandidates = mutableSetOf<Int>()
        val matched = mutableListOf<Match>()
        pairs.sortedBy { it.cost }.forEach { pair ->
            if (pair.line.label in usedLines || pair.candidate.index in usedCandidates) return@forEach
            usedLines += pair.line.label
            usedCandidates += pair.candidate.index
            matched += Match(
                line = pair.line,
                candidate = pair.candidate,
                predictedWavelengthNm = interceptNm + slopeNmPerPx * pair.candidate.distancePx,
                residualNm = pair.residualNm,
                toleranceNm = pair.toleranceNm
            )
        }
        return matched.sortedByDescending { it.line.wavelengthNm }
    }

    private fun lineToleranceNm(candidate: ObservedCandidate, slopeNmPerPx: Double): Double {
        // Broad Balmer troughs can have uncertain centres at this resolution. A
        // scale-aware component keeps the tolerance proportional to the structure
        // that generated the candidate without making it so broad that aliases win.
        val scaleNm = abs(slopeNmPerPx) * candidate.scaleSamples.coerceAtLeast(3) * 0.35
        return max(2.0, min(8.0, scaleNm + 1.5))
    }

    private fun chromaticRms(
        interceptNm: Double,
        slopeNmPerPx: Double,
        extraction: SpectrumExtraction,
        prior: DoubleArray?
    ): Double? {
        if (prior == null || prior.size != extraction.distancesPx.size || prior.isEmpty()) return null
        val guard = SpectrumFeatureSearchQa.endpointGuardSamples(prior.size)
        val first = guard.coerceAtMost(prior.lastIndex)
        val last = (prior.lastIndex - guard).coerceAtLeast(first)
        if (last <= first) return null

        val sampleCount = min(17, last - first + 1).coerceAtLeast(3)
        val residuals = mutableListOf<Double>()
        for (k in 0 until sampleCount) {
            val fraction = if (sampleCount == 1) 0.0 else k.toDouble() / (sampleCount - 1)
            val index = (first + fraction * (last - first)).toInt().coerceIn(first, last)
            val priorNm = prior[index]
            if (!priorNm.isFinite()) continue
            val modelNm = interceptNm + slopeNmPerPx * extraction.distancesPx[index]
            if (modelNm.isFinite()) residuals += modelNm - priorNm
        }
        if (residuals.size < 3) return null
        return sqrt(residuals.map { it * it }.average())
    }

    private fun descriptionLength(
        matches: List<Match>,
        catalogueSize: Int,
        chromaticRmsNm: Double?
    ): Double {
        if (matches.isEmpty()) return Double.POSITIVE_INFINITY
        val residualCost = matches.sumOf { match ->
            val z = match.normalizedResidual.coerceAtMost(4.0)
            z * z
        }
        val unexplainedLinePenalty = (catalogueSize - matches.size).coerceAtLeast(0) * 2.4
        val modelComplexityPenalty = 2.0 * ln(max(2, matches.size).toDouble()) // intercept + slope
        val chromaticPenalty = chromaticRmsNm?.let { rms ->
            // The colour bootstrap is intentionally weak: ~25 nm disagreement costs
            // about one unit, enough to break aliases but not override line evidence.
            (rms / 25.0).let { it * it }
        } ?: 0.0
        return residualCost + unexplainedLinePenalty + modelComplexityPenalty + chromaticPenalty
    }

    private fun supportScore(matches: List<Match>, catalogueSize: Int): Double {
        if (matches.isEmpty()) return 0.0
        val coverage = matches.size.toDouble() / catalogueSize.coerceAtLeast(1)
        val evidence = matches.map { it.candidate.evidence.coerceIn(0.0, 4.0) / 4.0 }.average()
        val residualQuality = exp(-0.5 * matches.map { it.normalizedResidual * it.normalizedResidual }.average())
        return (0.55 * coverage + 0.25 * evidence + 0.20 * residualQuality).coerceIn(0.0, 1.0)
    }

    private fun provisionalConfidence(
        matches: List<Match>,
        catalogueSize: Int,
        rmsNm: Double,
        chromaticRmsNm: Double?
    ): Double {
        val coverage = matches.size.toDouble() / catalogueSize.coerceAtLeast(1)
        val rmsScore = exp(-rmsNm.coerceAtLeast(0.0) / 2.5)
        val chromaticScore = chromaticRmsNm?.let { exp(-it.coerceAtLeast(0.0) / 45.0) } ?: 0.65
        val evidence = matches.map { (it.candidate.evidence / 3.0).coerceIn(0.0, 1.0) }.average()
        return (0.45 * coverage + 0.25 * rmsScore + 0.15 * chromaticScore + 0.15 * evidence).coerceIn(0.0, 1.0)
    }

    private fun absorptionCandidates(extraction: SpectrumExtraction): List<ObservedCandidate> {
        val n = extraction.distancesPx.size
        if (n < 12) return emptyList()
        val guard = SpectrumFeatureSearchQa.endpointGuardSamples(n)
        val first = guard.coerceAtMost(n - 1)
        val last = (n - 1 - guard).coerceAtLeast(first)
        if (last - first < 6) return emptyList()

        data class RawCandidate(
            val index: Int,
            val evidence: Double,
            val snr: Double,
            val scale: Int,
            val source: String
        )

        val raw = mutableListOf<RawCandidate>()

        // Existing detector output is useful evidence when it is available.
        extraction.features
            .filter { it.type == FeatureType.Absorption }
            .filter { it.index in first..last }
            .forEach { feature ->
                raw += RawCandidate(
                    index = feature.index,
                    evidence = (feature.snr / 3.0 + feature.confidence * 2.0).coerceAtLeast(0.0),
                    snr = feature.snr,
                    scale = feature.detectionScalePx.toInt().coerceAtLeast(5),
                    source = "detector"
                )
            }

        // Add deliberately permissive multi-scale minima. These are calibration
        // hypotheses only; they are not returned as scientific feature detections.
        // Consensus across known line spacing is what decides whether they matter.
        val scales = intArrayOf(5, 9, 15, 23, 35, 49).filter { it < n / 2 }
        scales.forEach { window ->
            val smoothed = movingAverage(extraction.residual, extraction.valid, window)
            val half = max(2, window / 3)
            for (i in max(first, half) .. min(last, n - 1 - half)) {
                val value = smoothed[i]
                if (!value.isFinite() || value >= 0.0) continue
                if (value > smoothed[i - 1] || value > smoothed[i + 1]) continue

                val localNoise = extraction.localNoise.getOrNull(i)?.takeIf { it.isFinite() && it > 1e-9 }
                    ?: robustLocalScale(smoothed, i, max(7, window * 2))
                if (!localNoise.isFinite() || localNoise <= 1e-9) continue
                val snr = -value / localNoise
                if (snr < 1.10) continue

                val shoulder = shoulderProminence(smoothed, i, max(3, window))
                val prominenceScore = if (localNoise > 0.0) shoulder / localNoise else 0.0
                val evidence = (0.70 * snr + 0.30 * prominenceScore).coerceAtLeast(0.0)
                raw += RawCandidate(i, evidence, snr, window, "multiscale")
            }
        }

        if (raw.isEmpty()) return emptyList()

        // Cluster repeated detections of the same trough across scales.
        val sorted = raw.sortedByDescending { it.evidence }
        val selected = mutableListOf<RawCandidate>()
        for (candidate in sorted) {
            val tooClose = selected.any { abs(it.index - candidate.index) <= max(3, min(it.scale, candidate.scale) / 3) }
            if (!tooClose) selected += candidate
            if (selected.size >= 18) break
        }

        return selected
            .map { candidate ->
                ObservedCandidate(
                    index = candidate.index,
                    distancePx = extraction.distancesPx[candidate.index],
                    evidence = candidate.evidence,
                    localSnr = candidate.snr,
                    scaleSamples = candidate.scale,
                    source = candidate.source
                )
            }
            .sortedBy { it.distancePx }
    }

    private fun movingAverage(values: DoubleArray, valid: BooleanArray, window: Int): DoubleArray {
        if (values.isEmpty()) return DoubleArray(0)
        val radius = max(1, window / 2)
        return DoubleArray(values.size) { index ->
            var sum = 0.0
            var count = 0
            val from = max(0, index - radius)
            val to = min(values.lastIndex, index + radius)
            for (j in from..to) {
                val value = values[j]
                if (value.isFinite() && valid.getOrElse(j) { true }) {
                    sum += value
                    count++
                }
            }
            if (count == 0) Double.NaN else sum / count
        }
    }

    private fun robustLocalScale(values: DoubleArray, index: Int, window: Int): Double {
        val radius = max(3, window / 2)
        val sample = mutableListOf<Double>()
        for (j in max(0, index - radius)..min(values.lastIndex, index + radius)) {
            val v = values[j]
            if (v.isFinite()) sample += v
        }
        if (sample.size < 5) return Double.NaN
        sample.sort()
        val median = sample[sample.size / 2]
        val deviations = sample.map { abs(it - median) }.sorted()
        return (1.4826 * deviations[deviations.size / 2]).coerceAtLeast(1e-9)
    }

    private fun shoulderProminence(values: DoubleArray, index: Int, window: Int): Double {
        val half = max(2, window / 2)
        val left = mutableListOf<Double>()
        val right = mutableListOf<Double>()
        for (j in max(0, index - half * 2)..max(0, index - half)) {
            values.getOrNull(j)?.takeIf { it.isFinite() }?.let(left::add)
        }
        for (j in min(values.lastIndex, index + half)..min(values.lastIndex, index + half * 2)) {
            values.getOrNull(j)?.takeIf { it.isFinite() }?.let(right::add)
        }
        if (left.isEmpty() || right.isEmpty() || !values[index].isFinite()) return 0.0
        val shoulder = 0.5 * (left.average() + right.average())
        return (shoulder - values[index]).coerceAtLeast(0.0)
    }
}
