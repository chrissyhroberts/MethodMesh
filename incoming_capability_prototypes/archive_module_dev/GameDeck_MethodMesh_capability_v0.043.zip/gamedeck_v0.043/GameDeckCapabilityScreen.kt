package com.example.methodmesh.modules.gamedeck

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.delay
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** GameDeck v0.043: full-screen, tactile game surfaces. */
object GameDeckCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100GameDeckMethod.ID
    override val title = "GameDeck"
    override val description = "A lightweight shelf of tactile games and procedural game experiments."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        var game by rememberSaveable {
            mutableStateOf(context.action.settings["game"] ?: context.action.settings["input_game"] ?: GameDeckEngine.LAUNCHER)
        }
        var rngMode by rememberSaveable {
            mutableStateOf(context.action.settings["rng_mode"] ?: context.action.settings["input_rng_mode"] ?: "secure_random")
        }
        var seed by rememberSaveable {
            mutableStateOf(context.action.settings["seed"] ?: context.action.settings["input_seed"] ?: "")
        }
        var stateJson by rememberSaveable(game) { mutableStateOf(GameDeckEngine.newStateJson(game)) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var mancalaCpu by rememberSaveable { mutableStateOf(true) }

        fun buildResult(): ExecutionResult {
            val summary = GameDeckEngine.stateSummary(stateJson)
            val values = As100GameDeckMethod.snapshot(
                game = summary.game,
                stateJson = stateJson,
                turn = summary.turn,
                winner = summary.winner,
                moveCount = summary.moves,
                rngMode = rngMode,
                seed = seed
            )
            val request = As100GameDeckMethod.request(
                action = As100GameDeckMethod.ID,
                context = context.request.invocationContext.asMap(As100GameDeckMethod.ID) + context.action.settings +
                    mapOf("game" to game, "rng_mode" to rngMode, "seed" to seed),
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100GameDeckMethod.result(request, values, context.request.invocationContext)
        }

        fun refreshSnapshot() { result = buildResult() }
        fun openGame(selected: String) {
            game = selected
            stateJson = GameDeckEngine.newStateJson(selected)
            result = null
        }
        fun reset() {
            stateJson = GameDeckEngine.newStateJson(game)
            refreshSnapshot()
        }
        fun home() { openGame(GameDeckEngine.LAUNCHER) }

        LaunchedEffect(game, rngMode, seed) {
            context.onSettingsChanged(mapOf("game" to game, "rng_mode" to rngMode, "seed" to seed))
        }

        LaunchedEffect(context.presentationMode, context.submitsImmediately, context.request.source) {
            val genuineExternalAutoSubmit = context.submitsImmediately && !context.request.source.equals("intent_test", ignoreCase = true)
            if (genuineExternalAutoSubmit && !launched) {
                launched = true
                onConfirmed(buildResult())
            } else if (!launched) {
                launched = true
                refreshSnapshot()
            }
        }

        val keepLiveDashboard = context.presentationMode == CapabilityPresentationMode.Dashboard || context.isNativePresetRun
        val scaffoldResult = if (keepLiveDashboard) null else result
        val summary = GameDeckEngine.stateSummary(stateJson)

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let {
                mapOf(GameDeckFields.RESULT to "${summary.game}: ${summary.moves} moves", GameDeckFields.WINNER to summary.winner)
            }.orEmpty(),
            onBack = onBack,
            onRetry = { reset() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (game == GameDeckEngine.LAUNCHER) {
                    Launcher(onOpen = ::openGame)
                } else {
                    GameHeader(game = game, onHome = ::home, onReset = ::reset)
                    when (game) {
                        GameDeckEngine.CONNECT_FOUR -> ConnectFourGame(
                            stateJson = stateJson,
                            onDrop = { col -> stateJson = GameDeckEngine.connectFourDrop(stateJson, col); refreshSnapshot() }
                        )
                        GameDeckEngine.SNAKES_AND_LADDERS -> SnakesGame(
                            stateJson = stateJson,
                            rngMode = rngMode,
                            seed = seed,
                            onRngMode = { rngMode = it },
                            onRoll = {
                                val (next, _) = GameDeckEngine.snakesRoll(stateJson, rngMode, seed)
                                stateJson = next; refreshSnapshot()
                            },
                            onMove = {
                                stateJson = if (JSONObject(stateJson).optString("pending_phase") == "jump") {
                                    GameDeckEngine.snakesCommitJump(stateJson)
                                } else GameDeckEngine.snakesCommitMove(stateJson)
                                refreshSnapshot()
                            }
                        )
                        GameDeckEngine.MANCALA -> MancalaGame(
                            stateJson = stateJson,
                            cpu = mancalaCpu,
                            onCpuChanged = { mancalaCpu = it; reset() },
                            onPit = { pit -> stateJson = GameDeckEngine.mancalaMove(stateJson, pit); refreshSnapshot() },
                            onCpuPit = { pit -> stateJson = GameDeckEngine.mancalaMove(stateJson, pit); refreshSnapshot() }
                        )
                        GameDeckEngine.MINESWEEPER -> MinesweeperGame(
                            stateJson = stateJson,
                            rngMode = rngMode,
                            onPreset = { w, h, m -> stateJson = GameDeckEngine.minesweeperConfigure(w, h, m, seed); refreshSnapshot() },
                            onReveal = { x, y -> stateJson = GameDeckEngine.minesweeperReveal(stateJson, x, y, rngMode, seed); refreshSnapshot() },
                            onFlag = { x, y -> stateJson = GameDeckEngine.minesweeperToggleFlag(stateJson, x, y); refreshSnapshot() }
                        )
                    }

                    GameResultPanel(stateJson)
                }

                if (keepLiveDashboard && result != null && game != GameDeckEngine.LAUNCHER) {
                    Button(onClick = { result?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot")
                    }
                }
            }
        }
    }
}

private val PlayerOneColor = Color(0xFFE84A5F)
private val PlayerTwoColor = Color(0xFFFFC857)
private val LadderColor = Color(0xFF2E9D70)
private val SnakeColor = Color(0xFF8D5BA6)
private val BeanColor = Color(0xFF9B633D)
private val BeanLight = Color(0xFFD9A66D)

@Composable
private fun Launcher(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Pick a game", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        GameTile("Connect Four", "Drag a chunky counter into a column", "2P", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.CONNECT_FOUR) }
        GameTile("Snakes & Ladders", "Roll, then move your own token", "2P", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.SNAKES_AND_LADDERS) }
        GameTile("Mancala", "Sow beans against a visible CPU", "CPU", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.MANCALA) }
        GameTile("Minesweeper", "Validated procedural boards", "LAB", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.MINESWEEPER) }
    }
}

@Composable
private fun GameTile(title: String, subtitle: String, badge: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(20.dp).height(124.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Text(badge, Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun GameHeader(game: String, onHome: () -> Unit, onReset: () -> Unit) {
    val gameTitle = when (game) {
        GameDeckEngine.SNAKES_AND_LADDERS -> "Snakes & Ladders"
        GameDeckEngine.MANCALA -> "Mancala"
        GameDeckEngine.MINESWEEPER -> "Minesweeper"
        else -> "Connect Four"
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(gameTitle, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = onReset) { Text("New") }
            OutlinedButton(onClick = onHome) { Text("Games") }
        }
    }
}

@Composable
private fun PlayerBanner(label: String, active: Boolean, color: Color, symbol: String, detail: String = "") {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (active) color.copy(alpha = 0.24f) else MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = if (active) 5.dp else 0.dp
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Surface(shape = CircleShape, color = color, modifier = Modifier.size(26.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(symbol, color = Color.Black, fontWeight = FontWeight.Black) }
            }
            Column {
                Text(label, fontWeight = FontWeight.Black)
                if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ConnectFourGame(stateJson: String, onDrop: (Int) -> Unit) {
    val state = JSONObject(stateJson)
    val board = state.getJSONArray("board")
    val winnerCells = GameDeckEngine.connectFourWinningCells(stateJson)
    val turn = state.optInt("turn", 1)
    var dragPos by remember(stateJson) { mutableStateOf<Offset?>(null) }
    var dragColumn by remember(stateJson) { mutableStateOf(-1) }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        PlayerBanner("PLAYER 1", turn == 1 && state.optString("winner").isBlank(), PlayerOneColor, "●")
        PlayerBanner("PLAYER 2", turn == 2 && state.optString("winner").isBlank(), PlayerTwoColor, "◆")
    }
    Text("Drag the ${if (turn == 1) "round" else "diamond"} counter into a column — or tap the column.", textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)

    val empty = MaterialTheme.colorScheme.surface
    val boardColor = Color(0xFF3159A8)
    val winStroke = MaterialTheme.colorScheme.onSurface
    Canvas(
        modifier = Modifier.fillMaxWidth().aspectRatio(7f / 6f)
            .pointerInput(stateJson) {
                detectTapGestures { tap ->
                    val col = (tap.x / (size.width / 7f)).toInt().coerceIn(0, 6)
                    onDrop(col)
                }
            }
            .pointerInput(stateJson, turn) {
                detectDragGestures(
                    onDragStart = { start ->
                        dragPos = start
                        dragColumn = (start.x / (size.width / 7f)).toInt().coerceIn(0, 6)
                    },
                    onDragEnd = {
                        val col = dragColumn
                        dragPos = null; dragColumn = -1
                        if (col in 0..6) onDrop(col)
                    },
                    onDragCancel = { dragPos = null; dragColumn = -1 },
                    onDrag = { change, _ ->
                        dragPos = change.position
                        dragColumn = (change.position.x / (size.width / 7f)).toInt().coerceIn(0, 6)
                    }
                )
            }
    ) {
        val cw = size.width / 7f
        val ch = size.height / 6f
        drawRoundRect(boardColor, cornerRadius = CornerRadius(cw * .24f, cw * .24f))
        for (r in 0..5) for (c in 0..6) {
            val center = Offset((c + .5f) * cw, (r + .5f) * ch)
            val value = board.getJSONArray(r).optInt(c)
            val color = when (value) { 1 -> PlayerOneColor; 2 -> PlayerTwoColor; else -> empty }
            drawCircle(Color.Black.copy(alpha = 0.20f), radius = minOf(cw, ch) * .37f, center = center + Offset(0f, 4f))
            drawCircle(color, radius = minOf(cw, ch) * .34f, center = center)
            if (value == 2) {
                val rr = minOf(cw, ch) * .18f
                val diamond = Path().apply {
                    moveTo(center.x, center.y - rr); lineTo(center.x + rr, center.y); lineTo(center.x, center.y + rr); lineTo(center.x - rr, center.y); close()
                }
                drawPath(diamond, Color.Black.copy(alpha = .35f))
            }
            if ((r to c) in winnerCells) drawCircle(winStroke, radius = minOf(cw, ch) * .40f, center = center, style = Stroke(width = 6f))
        }
        dragPos?.let { p ->
            drawCircle(if (turn == 1) PlayerOneColor else PlayerTwoColor, radius = minOf(cw, ch) * .30f, center = p)
            drawCircle(Color.White.copy(alpha = .55f), radius = minOf(cw, ch) * .30f, center = p, style = Stroke(4f))
        }
    }
}

@Composable
private fun SnakesGame(
    stateJson: String,
    rngMode: String,
    seed: String,
    onRngMode: (String) -> Unit,
    onRoll: () -> Unit,
    onMove: () -> Unit
) {
    val state = JSONObject(stateJson)
    val positions = state.getJSONArray("positions")
    val lastRoll = state.optInt("last_roll", 1).coerceIn(1, 6)
    val pendingPhase = state.optString("pending_phase")
    val pendingRoll = state.optInt("pending_roll", 0)
    val turn = state.optInt("turn", 0)
    var frame by remember { mutableStateOf(0) }
    var rolling by remember { mutableStateOf(false) }

    LaunchedEffect(pendingRoll, state.optInt("moves", 0)) {
        if (pendingRoll > 0 && pendingPhase == "move") {
            rolling = true
            repeat(20) { i -> frame = i + 1; delay(48L) }
            rolling = false
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        PlayerBanner("PLAYER 1", turn == 0 && state.optString("winner").isBlank(), PlayerOneColor, "●", "Square ${positions.optInt(0, 1)}")
        PlayerBanner("PLAYER 2", turn == 1 && state.optString("winner").isBlank(), PlayerTwoColor, "◆", "Square ${positions.optInt(1, 1)}")
    }

    SnakesBoard(stateJson = stateJson, rolling = rolling, onMove = onMove)

    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
            ChanceStyleD6(finalValue = lastRoll, frame = frame, rolling = rolling)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val instruction = when {
                    rolling -> "Rolling…"
                    pendingPhase == "move" -> "Drag P${turn + 1} to square ${state.optInt("pending_to")}."
                    pendingPhase == "jump" -> if (state.optInt("pending_to") > state.optInt("pending_from")) "Climb the ladder!" else "Ride the snake!"
                    else -> "Player ${turn + 1} to roll"
                }
                Text(instruction, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                Button(onClick = onRoll, enabled = state.optString("winner").isBlank() && pendingPhase.isBlank() && !rolling) { Text("ROLL D6", fontWeight = FontWeight.Black) }
                if (pendingPhase.isNotBlank() && !rolling) {
                    OutlinedButton(onClick = onMove) { Text("Move to ${state.optInt("pending_to")}") }
                }
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        OutlinedButton(onClick = { onRngMode("secure_random") }, enabled = rngMode != "secure_random" && pendingPhase.isBlank()) { Text("Secure") }
        OutlinedButton(onClick = { onRngMode("fixed_seed") }, enabled = rngMode != "fixed_seed" && pendingPhase.isBlank()) { Text("Seeded") }
    }
    if (rngMode == "fixed_seed") Text("Seed: ${seed.ifBlank { "default" }}", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun SnakesBoard(stateJson: String, rolling: Boolean, onMove: () -> Unit) {
    val state = JSONObject(stateJson)
    val positions = state.getJSONArray("positions")
    val (ladders, snakes) = GameDeckEngine.snakesTransitions()
    val pendingPhase = state.optString("pending_phase")
    val turn = state.optInt("turn", 0)
    val targetSquare = state.optInt("pending_to", 0)
    var ghost by remember(stateJson) { mutableStateOf<Offset?>(null) }
    var dragging by remember(stateJson) { mutableStateOf(false) }
    var releaseValid by remember(stateJson) { mutableStateOf(false) }
    val grid = MaterialTheme.colorScheme.outlineVariant
    val bg = MaterialTheme.colorScheme.surfaceVariant

    Canvas(
        Modifier.fillMaxWidth().aspectRatio(1f)
            .pointerInput(stateJson, rolling) {
                if (pendingPhase.isNotBlank() && !rolling) {
                    detectDragGestures(
                        onDragStart = { start ->
                            val current = snakeSquareCenter(positions.optInt(turn, 1), size.width.toFloat())
                            val cell = size.width / 10f
                            val distance = sqrt((start.x-current.x)*(start.x-current.x) + (start.y-current.y)*(start.y-current.y))
                            dragging = distance < cell * .8f
                            if (dragging) ghost = start
                        },
                        onDragEnd = {
                            if (dragging && releaseValid) onMove()
                            dragging = false; ghost = null; releaseValid = false
                        },
                        onDragCancel = { dragging = false; ghost = null; releaseValid = false },
                        onDrag = { change, _ ->
                            if (dragging) {
                                ghost = change.position
                                val target = snakeSquareCenter(targetSquare, size.width.toFloat())
                                val cell = size.width / 10f
                                val dx = change.position.x-target.x; val dy = change.position.y-target.y
                                releaseValid = sqrt(dx*dx + dy*dy) < cell * .85f
                            }
                        }
                    )
                }
            }
            .pointerInput(stateJson, rolling, "tap") {
                if (pendingPhase.isNotBlank() && !rolling) {
                    detectTapGestures { tap ->
                        val target = snakeSquareCenter(targetSquare, size.width.toFloat())
                        val cell = size.width / 10f
                        val dx = tap.x-target.x; val dy = tap.y-target.y
                        if (sqrt(dx*dx + dy*dy) < cell * .75f) onMove()
                    }
                }
            }
    ) {
        val cell = size.width / 10f
        drawRoundRect(bg, cornerRadius = CornerRadius(24f, 24f))
        for (i in 0..10) {
            drawLine(grid, Offset(i * cell, 0f), Offset(i * cell, size.height), 1.5f)
            drawLine(grid, Offset(0f, i * cell), Offset(size.width, i * cell), 1.5f)
        }
        if (targetSquare in 1..100 && pendingPhase.isNotBlank()) {
            drawCircle(Color.White.copy(alpha = .28f), cell * .43f, snakeSquareCenter(targetSquare, size.width.toFloat()))
            drawCircle(if (turn == 0) PlayerOneColor else PlayerTwoColor, cell * .43f, snakeSquareCenter(targetSquare, size.width.toFloat()), style = Stroke(cell * .07f))
        }
        ladders.forEach { (a, b) ->
            val start = snakeSquareCenter(a, size.width); val end = snakeSquareCenter(b, size.width)
            drawLine(LadderColor, start, end, cell * .15f)
            drawCircle(LadderColor, cell * .12f, start); drawCircle(LadderColor, cell * .12f, end)
        }
        snakes.forEach { (a, b) ->
            val start = snakeSquareCenter(a, size.width); val end = snakeSquareCenter(b, size.width)
            val path = Path().apply { moveTo(start.x, start.y); cubicTo(start.x + cell, start.y, end.x - cell, end.y, end.x, end.y) }
            drawPath(path, SnakeColor, style = Stroke(width = cell * .16f))
            drawCircle(SnakeColor, cell * .17f, start)
            drawCircle(Color.White, cell * .035f, start + Offset(-cell*.055f,-cell*.025f))
            drawCircle(Color.White, cell * .035f, start + Offset(cell*.055f,-cell*.025f))
        }
        val c1 = snakeSquareCenter(positions.optInt(0, 1), size.width)
        val c2 = snakeSquareCenter(positions.optInt(1, 1), size.width)
        drawCircle(Color.Black.copy(alpha=.18f), cell*.27f, c1 + Offset(-cell*.14f, 3f))
        drawCircle(PlayerOneColor, cell*.24f, c1 + Offset(-cell*.14f,0f))
        val p2 = c2 + Offset(cell*.14f,0f)
        val rr = cell*.24f
        val diamond = Path().apply { moveTo(p2.x,p2.y-rr); lineTo(p2.x+rr,p2.y); lineTo(p2.x,p2.y+rr); lineTo(p2.x-rr,p2.y); close() }
        drawPath(diamond, PlayerTwoColor)
        ghost?.let { p ->
            if (turn == 0) drawCircle(PlayerOneColor.copy(alpha=.88f), cell*.28f, p)
            else {
                val gr = cell*.28f
                val gp = Path().apply { moveTo(p.x,p.y-gr); lineTo(p.x+gr,p.y); lineTo(p.x,p.y+gr); lineTo(p.x-gr,p.y); close() }
                drawPath(gp, PlayerTwoColor.copy(alpha=.88f))
            }
            drawCircle(if (releaseValid) LadderColor else Color.White, cell*.31f, p, style=Stroke(cell*.05f))
        }
    }
}

private fun snakeSquareCenter(square: Int, boardWidth: Float): Offset {
    val safe = square.coerceIn(1,100)
    val zero = safe - 1
    val rowFromBottom = zero / 10
    val inRow = zero % 10
    val col = if (rowFromBottom % 2 == 0) inRow else 9 - inRow
    val row = 9 - rowFromBottom
    val cell = boardWidth / 10f
    return Offset((col + .5f) * cell, (row + .5f) * cell)
}

@Composable
private fun ChanceStyleD6(finalValue: Int, frame: Int, rolling: Boolean) {
    val line = MaterialTheme.colorScheme.onSurface
    val face = if (rolling) ((frame * 37 + 11) % 6) + 1 else finalValue.coerceIn(1,6)
    val cube = remember { normalizedCubeVertices() }
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp, modifier = Modifier.size(126.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                val centre = Offset(size.width/2f, size.height/2f)
                drawOval(line.copy(alpha=.10f), topLeft=Offset(size.width*.18f,size.height*.78f), size=Size(size.width*.64f,size.height*.11f))
                val phase = if (rolling) frame * .24 else 3.1
                val projected = projectCube(cube, phase, phase*.73 + .6, phase*.41, centre, size.minDimension*.39f)
                cubeEdges().forEach { edge ->
                    val a=projected[edge.first]; val b=projected[edge.second]
                    drawLine(line.copy(alpha=.72f), a, b, if (rolling) 3.2f else 2.6f)
                }
            }
            Text(face.toString(), style=MaterialTheme.typography.displayMedium, fontWeight=FontWeight.Black)
        }
    }
}

private data class GDV3(val x: Double, val y: Double, val z: Double)
private fun normalizedCubeVertices(): List<GDV3> {
    val raw = mutableListOf<GDV3>()
    listOf(-1.0,1.0).forEach { x -> listOf(-1.0,1.0).forEach { y -> listOf(-1.0,1.0).forEach { z -> raw += GDV3(x,y,z) } } }
    val radius = sqrt(3.0)
    return raw.map { GDV3(it.x/radius,it.y/radius,it.z/radius) }
}
private fun cubeEdges(): List<Pair<Int,Int>> = listOf(0 to 1,0 to 2,0 to 4,1 to 3,1 to 5,2 to 3,2 to 6,3 to 7,4 to 5,4 to 6,5 to 7,6 to 7)
private fun projectCube(vertices: List<GDV3>, rx: Double, ry: Double, rz: Double, centre: Offset, scale: Float): List<Offset> = vertices.map { original ->
    var x=original.x; var y=original.y; var z=original.z
    val y1=y*cos(rx)-z*sin(rx); val z1=y*sin(rx)+z*cos(rx); y=y1; z=z1
    val x2=x*cos(ry)+z*sin(ry); val z2=-x*sin(ry)+z*cos(ry); x=x2; z=z2
    val x3=x*cos(rz)-y*sin(rz); val y3=x*sin(rz)+y*cos(rz); x=x3; y=y3
    val perspective=1.0/(1.0+(z+2.8)*.10)
    Offset(centre.x+(x*perspective*scale).toFloat(), centre.y+(y*perspective*scale).toFloat())
}

@Composable
private fun MancalaGame(
    stateJson: String,
    cpu: Boolean,
    onCpuChanged: (Boolean) -> Unit,
    onPit: (Int) -> Unit,
    onCpuPit: (Int) -> Unit
) {
    val state = JSONObject(stateJson)
    val pits = state.getJSONArray("pits")
    val turn = state.optInt("turn",0)
    val terminal = state.optString("winner").isNotBlank()
    var cpuThinking by remember(stateJson) { mutableStateOf(false) }
    var cpuChoice by remember(stateJson) { mutableStateOf(-1) }
    var lastCpuChoice by rememberSaveable { mutableStateOf(-1) }

    LaunchedEffect(stateJson, cpu) {
        if (cpu && !terminal && turn == 1) {
            val choice = GameDeckEngine.mancalaCpuChoice(stateJson)
            if (choice >= 7) {
                cpuChoice = choice; cpuThinking = true
                delay(850L)
                lastCpuChoice = choice
                onCpuPit(choice)
                cpuThinking = false; cpuChoice = -1
            }
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        OutlinedButton(onClick = { onCpuChanged(true) }, enabled = !cpu) { Text("VS CPU") }
        OutlinedButton(onClick = { onCpuChanged(false) }, enabled = cpu) { Text("2 PLAYERS") }
    }

    PlayerBanner(if (cpu) "CPU" else "PLAYER 2", turn == 1 && !terminal, PlayerTwoColor, "◆", "Store ${pits.optInt(13)}")
    if (cpuThinking) {
        Surface(shape=RoundedCornerShape(18.dp), color=PlayerTwoColor.copy(alpha=.22f), modifier=Modifier.fillMaxWidth()) {
            Text("CPU chooses pit ${13-cpuChoice}…", Modifier.padding(12.dp), textAlign=TextAlign.Center, fontWeight=FontWeight.Black)
        }
    } else if (lastCpuChoice >= 7 && turn == 0 && !terminal) {
        Text("CPU moved pit ${13-lastCpuChoice}. Your turn.", modifier=Modifier.fillMaxWidth(), textAlign=TextAlign.Center, fontWeight=FontWeight.Bold)
    }

    MancalaStoreVisual(stones=pits.optInt(13), label=if(cpu) "CPU STORE" else "P2 STORE", color=PlayerTwoColor)

    Surface(shape=RoundedCornerShape(30.dp), color=Color(0xFFB77A4A).copy(alpha=.28f), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(vertical=12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            repeat(6) { row ->
                val cpuPit = 12-row
                val playerPit = row
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
                    MancalaPitVisual(
                        stones=pits.optInt(cpuPit), label=(row+1).toString(),
                        enabled=!cpu && turn==1 && !terminal,
                        highlighted=cpuChoice==cpuPit,
                        color=PlayerTwoColor
                    ) { onPit(cpuPit) }
                    Text("↕", style=MaterialTheme.typography.titleLarge, color=MaterialTheme.colorScheme.onSurfaceVariant)
                    MancalaPitVisual(
                        stones=pits.optInt(playerPit), label=(row+1).toString(),
                        enabled=turn==0 && !terminal,
                        highlighted=false,
                        color=PlayerOneColor
                    ) { onPit(playerPit) }
                }
            }
        }
    }

    MancalaStoreVisual(stones=pits.optInt(6), label="P1 STORE", color=PlayerOneColor)
    PlayerBanner("PLAYER 1", turn == 0 && !terminal, PlayerOneColor, "●", "Store ${pits.optInt(6)}")
    Text("Tap a pot to pick up its beans. Counts sit outside the pots; the beans show the physical state.", textAlign=TextAlign.Center, style=MaterialTheme.typography.bodySmall, modifier=Modifier.fillMaxWidth())
}

@Composable
private fun MancalaPitVisual(stones: Int, label: String, enabled: Boolean, highlighted: Boolean, color: Color, onClick: () -> Unit) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Text("$label  •  $stones", fontWeight=FontWeight.Black, color=if(highlighted) color else MaterialTheme.colorScheme.onSurface)
        Surface(
            onClick=onClick,
            enabled=enabled && stones>0,
            modifier=Modifier.size(82.dp),
            shape=CircleShape,
            color=if(highlighted) color.copy(alpha=.32f) else Color(0xFF70442D).copy(alpha=.30f),
            tonalElevation=if(highlighted) 7.dp else 2.dp
        ) {
            BeanPile(stones=stones)
        }
    }
}

@Composable
private fun MancalaStoreVisual(stones: Int, label: String, color: Color) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment=Alignment.CenterHorizontally) {
        Text("$label  •  $stones", fontWeight=FontWeight.Black, color=color)
        Surface(Modifier.fillMaxWidth().height(84.dp), shape=RoundedCornerShape(38.dp), color=color.copy(alpha=.18f), tonalElevation=3.dp) {
            BeanPile(stones=stones, store=true)
        }
    }
}

@Composable
private fun BeanPile(stones: Int, store: Boolean=false) {
    Canvas(Modifier.fillMaxSize().padding(8.dp)) {
        val shown=stones.coerceAtMost(if(store) 24 else 12)
        repeat(shown) { i ->
            val cols=if(store) 8 else 4
            val rows=if(store) 3 else 3
            val c=i%cols; val r=(i/cols)%rows
            val x=(c+.5f)*(size.width/cols) + (((i*7)%5)-2)*1.2f
            val y=(r+.5f)*(size.height/rows) + (((i*11)%5)-2)*1.1f
            val beanW=if(store) size.width*.075f else size.width*.17f
            val beanH=if(store) size.height*.25f else size.height*.17f
            drawOval(BeanColor, topLeft=Offset(x-beanW/2f,y-beanH/2f), size=Size(beanW,beanH))
            drawArc(BeanLight, 190f, 110f, false, topLeft=Offset(x-beanW*.34f,y-beanH*.30f), size=Size(beanW*.68f,beanH*.60f), style=Stroke(1.5f))
        }
        if(stones>shown) {
            drawCircle(Color.Black.copy(alpha=.12f), radius=size.minDimension*.12f, center=Offset(size.width*.86f,size.height*.18f))
        }
    }
}

@Composable
private fun MinesweeperGame(stateJson: String, rngMode: String, onPreset: (Int, Int, Int) -> Unit, onReveal: (Int, Int) -> Unit, onFlag: (Int, Int) -> Unit) {
    val state = JSONObject(stateJson)
    val metrics = GameDeckEngine.minesweeperMetrics(stateJson)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        OutlinedButton(onClick = { onPreset(8, 8, 8) }) { Text("CALM") }
        OutlinedButton(onClick = { onPreset(9, 9, 10) }) { Text("CLASSIC") }
        OutlinedButton(onClick = { onPreset(12, 12, 22) }) { Text("DENSE") }
    }

    MinesweeperBoard(stateJson, onReveal, onFlag)

    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("GameLab", style=MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(if (state.optBoolean("generated")) if (metrics.noGuessValidated) "VALIDATED" else "FALLBACK" else "WAITING", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
            }
            Text("${metrics.width}×${metrics.height} • ${metrics.mineCount} mines • ${(metrics.density * 100).toInt()}% density", fontWeight=FontWeight.Bold)
            if (state.optBoolean("generated")) Text("Generator attempts: ${metrics.generationAttempts} • solver passes: ${metrics.solverSteps} • RNG: $rngMode", style = MaterialTheme.typography.bodySmall)
            else Text("First tap fixes the opening; GameLab then seeks a no-guess-solvable board.", style = MaterialTheme.typography.bodySmall)
        }
    }
    Text("Tap to reveal • long-press to flag", style = MaterialTheme.typography.bodyMedium, fontWeight=FontWeight.Bold, textAlign=TextAlign.Center, modifier=Modifier.fillMaxWidth())
}

@Composable
private fun MinesweeperBoard(stateJson: String, onReveal: (Int, Int) -> Unit, onFlag: (Int, Int) -> Unit) {
    val state = JSONObject(stateJson)
    val w = state.optInt("width", 9)
    val h = state.optInt("height", 9)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cellSize = maxWidth / w
        Column {
            repeat(h) { y ->
                Row {
                    repeat(w) { x ->
                        val cell = GameDeckEngine.minesweeperCell(stateJson, x, y)
                        val bg = when {
                            cell.revealed -> MaterialTheme.colorScheme.surfaceVariant
                            cell.flagged -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.primaryContainer
                        }
                        Surface(
                            modifier = Modifier.size(cellSize).padding(1.2.dp).pointerInput(stateJson, x, y) {
                                detectTapGestures(onTap = { onReveal(x, y) }, onLongPress = { onFlag(x, y) })
                            },
                            shape = RoundedCornerShape(7.dp),
                            color = bg,
                            tonalElevation = if(cell.revealed) 0.dp else 3.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                val label = when {
                                    cell.flagged && !cell.revealed -> "⚑"
                                    cell.revealed && cell.mine -> "✹"
                                    cell.revealed && cell.adjacent > 0 -> cell.adjacent.toString()
                                    else -> ""
                                }
                                if (label.isNotBlank()) Text(label, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameResultPanel(stateJson: String) {
    val state=JSONObject(stateJson)
    val winner=state.optString("winner")
    if(winner.isBlank()) return
    val game=state.optString("game")
    val title: String
    val score: String
    when(game) {
        GameDeckEngine.CONNECT_FOUR -> {
            val board=state.getJSONArray("board")
            var p1=0; var p2=0
            for(r in 0 until board.length()) for(c in 0 until board.getJSONArray(r).length()) {
                when(board.getJSONArray(r).optInt(c)) { 1->p1++; 2->p2++ }
            }
            title=if(winner=="draw") "DRAW" else "PLAYER $winner WINS!"
            score="Counters played  •  P1 $p1 : $p2 P2"
        }
        GameDeckEngine.SNAKES_AND_LADDERS -> {
            val p=state.getJSONArray("positions")
            title="PLAYER $winner WINS!"
            score="Final positions  •  P1 ${p.optInt(0)} : ${p.optInt(1)} P2"
        }
        GameDeckEngine.MANCALA -> {
            val pits=state.getJSONArray("pits")
            title=if(winner=="draw") "DRAW" else "PLAYER $winner WINS!"
            score="Final score  •  P1 ${pits.optInt(6)} : ${pits.optInt(13)} P2"
        }
        else -> {
            val w=state.optInt("width",9); val h=state.optInt("height",9); val mines=state.optInt("mine_count",10)
            val revealed=state.optJSONArray("revealed")?.length() ?: 0
            title=if(winner=="cleared") "BOARD CLEARED!" else "BOOM — MINE HIT"
            score="Safe cells revealed  •  ${revealed.coerceAtMost(w*h-mines)} / ${w*h-mines}"
        }
    }
    Surface(shape=RoundedCornerShape(26.dp), color=MaterialTheme.colorScheme.primaryContainer, tonalElevation=6.dp, modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(title, style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Black, textAlign=TextAlign.Center)
            Text(score, style=MaterialTheme.typography.titleMedium, fontWeight=FontWeight.Bold, textAlign=TextAlign.Center)
        }
    }
}
