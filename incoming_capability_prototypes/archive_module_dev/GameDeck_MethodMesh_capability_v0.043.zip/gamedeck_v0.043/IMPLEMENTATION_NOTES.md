# GameDeck v0.043 implementation notes

This is the tactile/full-screen presentation pass following successful live tests of Connect Four, Snakes & Ladders, Mancala and Minesweeper.

## Important interaction changes

### Connect Four

The board accepts both tap and drag/release input. Player identities are intentionally redundant: colour plus shape/marking, rather than colour alone.

### Snakes & Ladders

A D6 roll no longer teleports the token. `GameDeckEngine.snakesRoll()` records a pending legal move. The active player then drags the token to the highlighted target (or taps/uses the explicit move fallback). If the landing square starts a snake or ladder, that traversal becomes a second pending manual move.

The D6 outcome is still generated through MethodMesh Chance (`As100DiceSimulationMethod`). GameDeck's local D6 renderer mirrors the rotating wireframe visual language used by Chance because the current Chance dice composables are private implementation details rather than a public embeddable component. If Chance later exposes a public reusable dice animation composable, GameDeck should switch to it and delete the local renderer.

### Mancala

The CPU no longer executes invisibly in the same state update as the player's move. The screen asks `mancalaCpuChoice()`, visibly highlights/announces that pit, waits briefly, and only then commits the move. Extra CPU turns repeat through the same visible cycle.

### Results

Finished games always display a prominent result and score summary. For games without a native score, the line is an interpretable terminal-state measure (e.g. Connect Four counters played or Snakes & Ladders final positions).

## Validation targets in the real app

1. Confirm drag and tap both work on Connect Four without double-firing a move.
2. Confirm a Snakes & Ladders roll cannot be followed by another roll until the pending token move is completed.
3. Confirm snake/ladder traversal requires the second manual move and that turn then passes correctly.
4. Confirm CPU Mancala pit highlight remains visible long enough to understand the move and that CPU extra turns remain signposted.
5. Confirm the vertical Mancala board fits comfortably on the target phone/tablet sizes used by MethodMesh.
6. Confirm all terminal states show the result panel and score line.
7. Re-run `./gradlew :app:assembleDebug` in the complete MethodMesh repository.
