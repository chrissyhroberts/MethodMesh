# GameDeck changelog

## v0.043

Presentation and interaction pass after live MethodMesh testing.

- All game surfaces now expand to the available capability area and use substantially larger controls, boards and pieces.
- Connect Four now gives Player 1 and Player 2 deliberately distinct persistent identities (red round counters vs yellow diamond-marked counters). Players can drag across the board and release in a column; tap remains available as a fallback.
- Snakes & Ladders now separates rolling from moving. Chance still supplies the D6 outcome, but the player must physically drag/tap the active token to the legal destination. Snakes/ladders are separate colours and a landed snake/ladder becomes a second manual move.
- Snakes & Ladders uses the Chance package's wireframe-die visual language and rolling cadence. The actual random outcome continues to come from `As100DiceSimulationMethod`; animation only reveals it.
- Mancala is now a vertical phone-friendly board: CPU/P2 at the top, Player 1 at the bottom, large bean-filled pots, counts outside the pots, and prominent stores.
- CPU Mancala moves are signposted before execution, the chosen pit highlights, and the previous CPU choice is reported when the turn returns to the player.
- Terminal states now always receive a large result panel with winner/outcome and a game-appropriate final score line.
- Minesweeper mechanics are unchanged; its cells, preset controls and GameLab panel are visually chunkier.

## v0.042

- Fixed the remaining `DieFace` call site after the `size` -> `dieSize` rename.
