# MethodMesh Reference Library

**Module ID:** `referencelibrary`  
**Method ID:** `reference.library.open`  
**Status:** Development  
**Version:** 0.1.5

## Purpose

Reference Library is the offline-first home for useful documents inside MethodMesh. It is deliberately not an emergency-monitoring capability. Its job is narrower: make manuals, field guides, procedures, reference cards and user documents quick to find and open.

The native surface is a library, not a settings form. Search, recent documents, shelf filters and document cards are shown on one screen. Imported files use Android's Storage Access Framework and persist read permission, so the app does not need to duplicate large PDFs into private storage.

## Shelves

- First aid
- Medical
- Safety
- Fieldwork
- Equipment
- Travel
- Personal

Shelves are presentation metadata, not hard security boundaries. Built-in shelves remain stable for presets and ODK. Native users can also create custom shelves, use them for scans/imported documents, and delete them later. Deleting a custom shelf moves its documents to Personal; it never deletes document files.

## Native workflow

**Reader return invariant:** direct/manual native use is always a persistent dashboard. Opening a document must never create a library execution result; closing or backing out of the Android document viewer returns to the same library dashboard state. Only native preset, protocol, schedule and external/ODK routes may use MethodMesh completion/result semantics.


Direct MethodMesh use is dashboard-style and persistent. It does **not** create a generic MethodMesh result merely because the operator opens a document.

1. Open Reference Library.
2. Search or select a shelf.
3. Tap a document card to open it with an Android document viewer.
4. Return from the viewer to the same Reference Library dashboard state.
5. Star frequently used documents.
6. Use **Scan to shelf** to capture paper pages with the existing MethodMesh Document Scanner, name the resulting PDF and choose its shelf.
7. Use **Add file** to reference an existing PDF, text file or image.
8. Use **Edit** on a library row to rename the library entry or move it to another shelf.
9. Use **Manage shelves** to create or delete custom categories.

The most recently opened documents are promoted into **Continue reading**. Direct dashboard use has no library-specific Confirm/Done conclusion step. Result/closeout behaviour is reserved for presets, protocols, ODK and other external launches that need a selected document returned to their caller.

## Persistence

The repository stores metadata in module-owned SharedPreferences and requests retained SAF read access to imported URIs. Files added with **Add file** remain in their original Android storage location. If the selected document provider does not support persistable access, the library reports that long-term access depends on that provider. Removing the library entry does not delete an externally imported source file.

**Scan to shelf** is different because the Document Scanner returns cache-backed MethodMesh attachments. Before the scan is admitted to the shelf, Reference Library copies the chosen PDF into `filesDir/reference_library/scans/` and exposes it through the existing MethodMesh FileProvider. The custom document name is used for the managed filename and library title. This prevents a library entry from depending on temporary scanner cache files. No cloud synchronization is performed.

## Presets and protocols

A preset may supply `document_id`, `query` and `shelf`. Fixed preset settings are transported through the normal MethodMesh capability context. A known `document_id` can resolve directly when the capability is launched by an intent.

Library entries are device-local. A `document_id` is therefore not portable between phones unless a future managed pack installs stable IDs.

## ODK / XLSForm

External callers use method ID `reference.library.open`.

Inputs:

- `input_document_id` — optional device-local document ID
- `input_query` — optional search string
- `input_shelf` — optional shelf ID

Outputs:

- `library_status`
- `library_document_id`
- `library_document_title`
- `library_document_uri`
- `library_document_mime`
- `library_shelf`
- `library_source`
- `library_version`
- `library_error`

The main useful result is the selected document URI/title. The URI remains subject to Android URI permission semantics; callers should not assume permanent cross-app access beyond the normal MethodMesh transport grant.

## Deliberate boundaries

This module does not contain:

- hazard monitoring or RAG status;
- emergency navigation or exit strategy;
- emergency numbers;
- location tracking;
- persistent emergency notifications;
- an encrypted identity-document vault.

Those belong in a separate Emergency capability. Emergency may later deep-link to stable Reference Library document IDs/packs rather than duplicating content.

## Next implementation steps

Before Production: add managed/bundled document packs with stable IDs and manifests; add a first-party in-app PDF/text reader; add pack provenance/checksum/version UI; test managed scan persistence and cleanup; test custom shelf migration/deletion and document editing across rotation/restart; test URI persistence across reboot/provider changes; test native/preset/protocol/ODK roundtrips; confirm accessibility and large-library performance.


## v0.1.1 review changes

- separates native **open/read** behaviour from external/ODK **select/return** behaviour;
- returns explicit `not_found` and `unavailable` results for broken device-local document IDs;
- verifies URI readability before opening or auto-returning a stored document;
- avoids duplicate library entries when the same URI is imported again;
- adds remove-from-library without deleting the source file;
- adds shelf counts, selected-state feedback and clearer empty/search states;
- adds document `source` and `version` outputs for future managed packs;
- preserves existing records while adding an `added` timestamp field;
- updates the ODK example output schema to match the method contract.


## v0.1.2 dashboard-flow changes

- direct MethodMesh dashboard use no longer creates a capture result when a document is opened;
- direct dashboard use bypasses the generic `CapabilityScreenScaffold` confirm/result surface, removing the Cancel/Done conclusion controls from the library itself;
- opening a document records recency, launches the Android reader and returns naturally to the same dashboard state;
- adding a document in direct dashboard use stays in the library instead of immediately producing a selected-document result;
- unreadable documents in direct dashboard use report an inline library status rather than routing to a failed result screen;
- intent, ODK, preset and protocol launches retain the established select/return closeout contract;
- method and XLSForm example versions updated to 0.1.2.


## v0.1.3 scan-to-shelf changes

- adds **Scan to shelf** as a first-class native dashboard action;
- invokes the installed `document.scan` capability through the MethodMesh public capability-screen registry instead of duplicating scanner code;
- declares the `documentscanner` module dependency explicitly;
- runs the scanner as a dependency/automatic-return flow so the scanner result screen does not interrupt the library dashboard;
- prefers the searchable PDF returned by Document Scanner and falls back to its scanner PDF;
- prompts after capture for a custom document name and destination shelf;
- copies the scanner's cache-backed PDF into persistent MethodMesh-owned library storage before adding it to the shelf;
- uses the custom name for both the managed PDF filename and the visible shelf title, adding a numeric suffix if a filename already exists;
- retains **Add file** for existing Android documents and leaves external/ODK selection semantics unchanged.


## v0.1.5 library-organisation changes

- adds **Edit** on each document for changing the displayed library name and destination shelf;
- editing library metadata never renames or moves the user's externally stored source file;
- adds persistent user-defined custom shelves/categories;
- exposes custom shelves in native filtering, scan-to-shelf and document-edit flows;
- adds **Manage shelves** for creating and deleting custom shelves;
- keeps built-in shelf IDs immutable for preset/ODK compatibility;
- deleting a custom shelf moves its documents to **Personal** and never deletes any files;
- guards against blank, duplicate and reserved custom shelf identifiers.
