package com.example.methodmesh.modules.digitalsigning

import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.sqrt

object DigitalSigningCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100DigitalSigningMethod.ID
    override val title = "Digital signing"
    override val description = "Ink-sign a PDF, commit a new version, and optionally obtain an RFC 3161 timestamp."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val scope = rememberCoroutineScope()

        fun initial(key: String, default: String): String =
            context.action.settings[key]
                ?: context.action.settings["input_$key"]
                ?: default

        fun truthy(value: String): Boolean =
            value.trim().lowercase() in setOf("true", "yes", "1", "on")

        fun suppliedPdfUri(): String = listOf("pdf_uri", "source_pdf_uri", "document_uri")
            .asSequence()
            .map { key -> context.action.settings[key] ?: context.action.settings["input_$key"] }
            .firstOrNull { !it.isNullOrBlank() }
            .orEmpty()

        fun updateSetting(key: String, value: String) {
            context.onSettingsChanged(mapOf(key to value))
        }

        val isOdkLaunch = context.request.source.contains("odk", ignoreCase = true) ||
            context.request.invocationContext.caller.contains("odk", ignoreCase = true)
        val pushedPdfUri = suppliedPdfUri()

        var finalisePdf by rememberSaveable { mutableStateOf(truthy(initial("finalise_pdf", "false"))) }
        var requestTsa by rememberSaveable { mutableStateOf(truthy(initial("request_tsa", "false"))) }
        var tsaUrl by rememberSaveable { mutableStateOf(initial("tsa_url", "")) }
        var penWidth by rememberSaveable { mutableStateOf(initial("pen_width_pt", "2.4").toFloatOrNull()?.coerceIn(0.8f, 10f) ?: 2.4f) }
        var penColor by rememberSaveable { mutableStateOf(initial("pen_color", "black").ifBlank { "black" }) }

        val finaliseForced = isOdkLaunch || context.submitsImmediately
        val effectiveFinalise = finaliseForced || finalisePdf

        var workingPdf by remember { mutableStateOf<WorkingPdf?>(null) }
        var strokes by remember { mutableStateOf<List<InkStroke>>(emptyList()) }
        var currentPage by rememberSaveable { mutableStateOf(0) }
        var renderedPage by remember { mutableStateOf<RenderedPdfPage?>(null) }
        var mode by rememberSaveable { mutableStateOf(DigitalSigningMode.Navigate) }
        var committedResult by remember { mutableStateOf<DigitalSigningCommittedResult?>(null) }
        var status by rememberSaveable { mutableStateOf("Preparing document workspace…") }
        var initialised by remember(context.action.canonicalId) { mutableStateOf(false) }
        var isCommitting by rememberSaveable { mutableStateOf(false) }
        var renderError by rememberSaveable { mutableStateOf<String?>(null) }

        fun resultFor(committed: DigitalSigningCommittedResult): ExecutionResult {
            val values = DigitalSigningResultJson.fields(committed)
            val request = As100DigitalSigningMethod.request(
                action = capabilityId,
                context = context.request.invocationContext.asMap(capabilityId) + context.action.settings + mapOf(
                    "finalise_pdf" to effectiveFinalise.toString(),
                    "request_tsa" to requestTsa.toString(),
                    "tsa_url" to tsaUrl,
                    "pen_width_pt" to penWidth.toString(),
                    "pen_color" to penColor
                ),
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100DigitalSigningMethod.result(request, values, context.request.invocationContext)
        }

        val result: ExecutionResult? = remember(committedResult, context.action.canonicalId) {
            committedResult?.let(::resultFor)
        }

        fun adoptDraft(draft: DigitalSigningDraftStore.RestoredDraft) {
            workingPdf = draft.workingPdf
            strokes = draft.strokes
            currentPage = draft.currentPage
            committedResult = draft.committedResult
            status = if (draft.committedResult != null) {
                "Recovered committed signed PDF."
            } else if (draft.strokes.isNotEmpty()) {
                "Recovered draft with ${draft.strokes.size} ink stroke(s)."
            } else {
                "Recovered PDF draft."
            }
        }

        fun importPdf(uri: Uri, origin: PdfInputOrigin) {
            scope.launch {
                isCommitting = true
                status = "Opening PDF…"
                val outcome = runCatching {
                    withContext(Dispatchers.IO) {
                        DigitalSigningDraftStore.importPdf(appContext, uri, origin)
                    }
                }
                outcome.onSuccess { working ->
                    workingPdf = working
                    strokes = emptyList()
                    currentPage = 0
                    committedResult = null
                    mode = DigitalSigningMode.Navigate
                    status = "${working.displayName} · ${working.pageCount} page(s)"
                }.onFailure { error ->
                    status = "Could not open PDF: ${error.message ?: "invalid or inaccessible document"}"
                }
                isCommitting = false
            }
        }

        val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importPdf(uri, PdfInputOrigin.FilePicker)
        }

        LaunchedEffect(context.action.canonicalId, pushedPdfUri) {
            if (initialised) return@LaunchedEffect
            initialised = true
            val restored = withContext(Dispatchers.IO) { DigitalSigningDraftStore.restore(appContext) }
            when {
                restored != null && pushedPdfUri.isBlank() -> adoptDraft(restored)
                restored != null && pushedPdfUri == restored.workingPdf.sourceUriString -> adoptDraft(restored)
                pushedPdfUri.isNotBlank() -> {
                    val origin = if (isOdkLaunch) PdfInputOrigin.Odk else PdfInputOrigin.AndroidIntent
                    runCatching {
                        withContext(Dispatchers.IO) {
                            DigitalSigningDraftStore.importPdf(appContext, Uri.parse(pushedPdfUri), origin)
                        }
                    }.onSuccess { working ->
                        workingPdf = working
                        strokes = emptyList()
                        currentPage = 0
                        committedResult = null
                        status = "${working.displayName} · ${working.pageCount} page(s)"
                    }.onFailure { error ->
                        status = "Supplied PDF could not be opened: ${error.message ?: "invalid URI"}"
                    }
                }
                else -> status = "Choose a PDF to begin."
            }
        }

        LaunchedEffect(workingPdf?.sourceFile?.absolutePath, currentPage) {
            val working = workingPdf ?: run {
                renderedPage = null
                return@LaunchedEffect
            }
            val safePage = currentPage.coerceIn(0, (working.pageCount - 1).coerceAtLeast(0))
            if (safePage != currentPage) currentPage = safePage
            renderError = null
            runCatching {
                withContext(Dispatchers.IO) {
                    DigitalSigningPdfEngine.renderPage(working.sourceFile, safePage)
                }
            }.onSuccess {
                renderedPage = it
            }.onFailure {
                renderedPage = null
                renderError = it.message ?: "Could not render this PDF page."
            }
        }

        LaunchedEffect(workingPdf?.sourceSha256, strokes, currentPage, committedResult) {
            val working = workingPdf ?: return@LaunchedEffect
            if (isCommitting) return@LaunchedEffect
            withContext(Dispatchers.IO) {
                DigitalSigningDraftStore.saveDraft(appContext, working, strokes, currentPage, committedResult)
            }
        }

        fun commit() {
            val working = workingPdf ?: return
            if (strokes.isEmpty() || isCommitting) return
            scope.launch {
                isCommitting = true
                mode = DigitalSigningMode.Navigate
                status = if (effectiveFinalise) "Finalising signed PDF…" else "Committing signed PDF…"
                val committed = runCatching {
                    withContext(Dispatchers.IO) {
                        val output = DigitalSigningDraftStore.nextResultFile(appContext, working.displayName)
                        val pdf = DigitalSigningPdfEngine.commit(
                            sourceFile = working.sourceFile,
                            strokes = strokes,
                            outputFile = output,
                            finalise = effectiveFinalise
                        )
                        val uri = FileProvider.getUriForFile(
                            appContext,
                            "${appContext.packageName}.fileprovider",
                            pdf.outputFile
                        ).toString()
                        DigitalSigningCommittedResult(
                            sourceOrigin = working.sourceOrigin,
                            sourceFilename = working.displayName,
                            sourceSha256 = working.sourceSha256,
                            signedFilename = pdf.outputFile.name,
                            signedPdfUri = uri,
                            signedSha256 = pdf.signedSha256,
                            pageCount = pdf.pageCount,
                            inkPresent = strokes.isNotEmpty(),
                            inkStrokeCount = strokes.size,
                            finalised = pdf.finalised,
                            finalisationMode = pdf.finalisationMode,
                            inkFlattened = pdf.inkFlattened,
                            formFieldsFlattened = pdf.formFieldsFlattened,
                            permissionRestrictionsApplied = pdf.permissionRestrictionsApplied,
                            newMarkupBlocked = pdf.newMarkupBlocked,
                            committedAtUtc = pdf.committedAtUtc,
                            tsa = if (requestTsa) TsaAttestation.pending(pdf.signedSha256) else TsaAttestation.notRequested()
                        )
                    }
                }

                val base = committed.getOrElse { error ->
                    status = "Commit failed: ${error.message ?: "PDF write error"}"
                    isCommitting = false
                    return@launch
                }

                // Persist the exact signed file/result before any network request.
                withContext(Dispatchers.IO) {
                    DigitalSigningDraftStore.saveDraft(appContext, working, strokes, currentPage, base)
                }

                val finalResult = if (requestTsa) {
                    status = if (tsaUrl.isBlank()) "Signed PDF committed · TSA is not configured" else "Signed PDF committed · requesting trusted timestamp…"
                    val tsa = withContext(Dispatchers.IO) {
                        DigitalSigningTsaClient.timestamp(tsaUrl.trim(), base.signedSha256)
                    }
                    base.copy(tsa = tsa)
                } else {
                    base
                }

                withContext(Dispatchers.IO) {
                    DigitalSigningDraftStore.saveDraft(appContext, working, strokes, currentPage, finalResult)
                }
                committedResult = finalResult
                status = when (finalResult.tsa.status) {
                    "verified" -> "Signed PDF committed and trusted timestamp verified."
                    "failed" -> "Signed PDF committed. Timestamp request failed; the signed PDF is preserved."
                    "not_configured" -> "Signed PDF committed. TSA was requested but no TSA URL is configured."
                    else -> "Signed PDF committed."
                }
                isCommitting = false
            }
        }

        fun clearCommittedAndReturnToDraft() {
            committedResult = null
            status = "Returned to editable draft. Commit again to create another version."
            workingPdf?.let { working ->
                scope.launch(Dispatchers.IO) {
                    DigitalSigningDraftStore.saveDraft(appContext, working, strokes, currentPage, committedResult = null)
                }
            }
        }

        fun confirmResult() {
            val execution = result ?: return
            DigitalSigningDraftStore.clear(appContext)
            onConfirmed(execution)
        }

        val preview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty()

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = preview,
            onBack = onBack,
            onRetry = ::clearCommittedAndReturnToDraft,
            onConfirm = ::confirmResult,
            onCancel = onCancel
        ) {
            val working = workingPdf
            if (working == null) {
                EmptySigningWorkspace(
                    status = status,
                    pushedPdfExpected = pushedPdfUri.isNotBlank(),
                    onChoosePdf = { pdfPicker.launch(arrayOf("application/pdf")) }
                )
            } else {
                SigningWorkspace(
                    workingPdf = working,
                    renderedPage = renderedPage,
                    renderError = renderError,
                    status = status,
                    currentPage = currentPage,
                    onPageChanged = { next -> currentPage = next.coerceIn(0, working.pageCount - 1) },
                    mode = mode,
                    onModeChanged = { mode = it },
                    strokes = strokes,
                    onStrokeAdded = { stroke -> strokes = strokes + stroke },
                    onEraseAt = { point, zoom ->
                        val threshold = (0.028f / zoom.coerceAtLeast(1f)).coerceAtLeast(0.006f)
                        val before = strokes.size
                        strokes = strokes.filterNot { stroke ->
                            stroke.pageIndex == currentPage && stroke.points.any { p ->
                                val dx = p.x - point.x
                                val dy = p.y - point.y
                                sqrt(dx * dx + dy * dy) <= threshold
                            }
                        }
                        if (strokes.size < before) status = "Ink erased."
                    },
                    onUndo = {
                        val index = strokes.indexOfLast { it.pageIndex == currentPage }
                        if (index >= 0) {
                            strokes = strokes.toMutableList().also { it.removeAt(index) }
                            status = "Last ink stroke removed."
                        }
                    },
                    penArgb = if (penColor == "blue") 0xFF184F9A.toInt() else 0xFF141718.toInt(),
                    canReplacePdf = !context.submitsImmediately,
                    onReplacePdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                    onCopySourceHash = {
                        appContext.getSystemService(ClipboardManager::class.java)
                            .setPrimaryClip(ClipData.newPlainText("PDF SHA-256", working.sourceSha256))
                        status = "Source SHA-256 copied."
                    },
                    finalisePdf = effectiveFinalise,
                    finaliseForced = finaliseForced,
                    onFinaliseChanged = {
                        finalisePdf = it
                        updateSetting("finalise_pdf", it.toString())
                    },
                    requestTsa = requestTsa,
                    onRequestTsaChanged = {
                        requestTsa = it
                        updateSetting("request_tsa", it.toString())
                    },
                    tsaUrl = tsaUrl,
                    onTsaUrlChanged = {
                        tsaUrl = it
                        updateSetting("tsa_url", it)
                    },
                    showTsaUrl = !context.settingIsFixedInNativePreset("tsa_url"),
                    penColor = penColor,
                    onPenColorChanged = {
                        penColor = it
                        updateSetting("pen_color", it)
                    },
                    penWidthPt = penWidth,
                    onPenWidthChanged = {
                        penWidth = it
                        updateSetting("pen_width_pt", it.toString())
                    },
                    isCommitting = isCommitting,
                    onCommit = ::commit
                )
            }
        }
    }
}

@Composable
private fun EmptySigningWorkspace(
    status: String,
    pushedPdfExpected: Boolean,
    onChoosePdf: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(92.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primaryContainer
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("PDF", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text(
            if (pushedPdfExpected) "PDF input unavailable" else "Choose a document",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            status,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onChoosePdf) { Text("Choose PDF") }
    }
}

@Composable
private fun SigningWorkspace(
    workingPdf: WorkingPdf,
    renderedPage: RenderedPdfPage?,
    renderError: String?,
    status: String,
    currentPage: Int,
    onPageChanged: (Int) -> Unit,
    mode: DigitalSigningMode,
    onModeChanged: (DigitalSigningMode) -> Unit,
    strokes: List<InkStroke>,
    onStrokeAdded: (InkStroke) -> Unit,
    onEraseAt: (InkPoint, Float) -> Unit,
    onUndo: () -> Unit,
    penArgb: Int,
    canReplacePdf: Boolean,
    onReplacePdf: () -> Unit,
    onCopySourceHash: () -> Unit,
    finalisePdf: Boolean,
    finaliseForced: Boolean,
    onFinaliseChanged: (Boolean) -> Unit,
    requestTsa: Boolean,
    onRequestTsaChanged: (Boolean) -> Unit,
    tsaUrl: String,
    onTsaUrlChanged: (String) -> Unit,
    showTsaUrl: Boolean,
    penColor: String,
    onPenColorChanged: (String) -> Unit,
    penWidthPt: Float,
    onPenWidthChanged: (Float) -> Unit,
    isCommitting: Boolean,
    onCommit: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        DocumentIdentityCard(workingPdf, status, canReplacePdf, onReplacePdf, onCopySourceHash)
        Spacer(Modifier.height(12.dp))

        PdfPageWorkspace(
            renderedPage = renderedPage,
            renderError = renderError,
            currentPage = currentPage,
            mode = mode,
            strokes = strokes.filter { it.pageIndex == currentPage },
            penWidthPt = penWidthPt,
            penArgb = penArgb,
            onStrokeAdded = onStrokeAdded,
            onEraseAt = onEraseAt
        )

        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = { onPageChanged(currentPage - 1) },
                enabled = currentPage > 0 && !isCommitting
            ) { Text("Previous") }
            Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
                Text(
                    "Page ${currentPage + 1} of ${workingPdf.pageCount}",
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge
                )
            }
            OutlinedButton(
                onClick = { onPageChanged(currentPage + 1) },
                enabled = currentPage < workingPdf.pageCount - 1 && !isCommitting
            ) { Text("Next") }
        }

        Spacer(Modifier.height(10.dp))
        InkToolbar(
            mode = mode,
            onModeChanged = onModeChanged,
            onUndo = onUndo,
            canUndo = strokes.any { it.pageIndex == currentPage },
            penColor = penColor,
            onPenColorChanged = onPenColorChanged,
            penWidthPt = penWidthPt,
            onPenWidthChanged = onPenWidthChanged,
            enabled = !isCommitting
        )

        Spacer(Modifier.height(16.dp))
        CommitCard(
            finalisePdf = finalisePdf,
            finaliseForced = finaliseForced,
            onFinaliseChanged = onFinaliseChanged,
            requestTsa = requestTsa,
            onRequestTsaChanged = onRequestTsaChanged,
            tsaUrl = tsaUrl,
            onTsaUrlChanged = onTsaUrlChanged,
            showTsaUrl = showTsaUrl,
            strokeCount = strokes.size,
            isCommitting = isCommitting,
            onCommit = onCommit
        )
    }
}

@Composable
private fun DocumentIdentityCard(
    workingPdf: WorkingPdf,
    status: String,
    canReplacePdf: Boolean,
    onReplacePdf: () -> Unit,
    onCopySourceHash: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(workingPdf.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${workingPdf.pageCount} page(s) · ${workingPdf.sourceOrigin.id.replace('_', ' ')}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (canReplacePdf) {
                    OutlinedButton(onClick = onReplacePdf) { Text("Replace") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "SHA-256  ${workingPdf.sourceSha256.take(20)}…",
                modifier = Modifier.clickable(onClick = onCopySourceHash).padding(vertical = 4.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun PdfPageWorkspace(
    renderedPage: RenderedPdfPage?,
    renderError: String?,
    currentPage: Int,
    mode: DigitalSigningMode,
    strokes: List<InkStroke>,
    penWidthPt: Float,
    penArgb: Int,
    onStrokeAdded: (InkStroke) -> Unit,
    onEraseAt: (InkPoint, Float) -> Unit
) {
    var zoom by rememberSaveable(currentPage) { mutableStateOf(1f) }
    var panX by rememberSaveable(currentPage) { mutableStateOf(0f) }
    var panY by rememberSaveable(currentPage) { mutableStateOf(0f) }
    var pageSize by remember { mutableStateOf(IntSize.Zero) }
    var activePoints by remember { mutableStateOf<List<InkPoint>>(emptyList()) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF202322),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        BoxWithConstraints(
            modifier = Modifier.fillMaxWidth().height(520.dp).padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            val page = renderedPage
            if (page == null) {
                Text(
                    renderError ?: "Rendering page…",
                    color = Color.White.copy(alpha = 0.82f),
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                val pageAspect = page.bitmap.width.toFloat() / page.bitmap.height.toFloat().coerceAtLeast(1f)
                val containerAspect = maxWidth.value / maxHeight.value.coerceAtLeast(1f)
                val sizeModifier = if (pageAspect >= containerAspect) {
                    Modifier.fillMaxWidth().aspectRatio(pageAspect)
                } else {
                    Modifier.fillMaxHeight().aspectRatio(pageAspect)
                }

                Box(
                    modifier = sizeModifier
                        .shadow(16.dp, RoundedCornerShape(3.dp))
                        .background(Color.White)
                        .onSizeChanged { pageSize = it }
                        .pointerInput(mode, currentPage, zoom, pageSize) {
                            when (mode) {
                                DigitalSigningMode.Navigate -> detectTransformGestures { _, pan, gestureZoom, _ ->
                                    val newZoom = (zoom * gestureZoom).coerceIn(1f, 5f)
                                    val maxX = pageSize.width * (newZoom - 1f) / 2f
                                    val maxY = pageSize.height * (newZoom - 1f) / 2f
                                    zoom = newZoom
                                    panX = (panX + pan.x).coerceIn(-maxX, maxX)
                                    panY = (panY + pan.y).coerceIn(-maxY, maxY)
                                }
                                DigitalSigningMode.Ink -> detectDragGestures(
                                    onDragStart = { position ->
                                        toNormalisedPoint(position, pageSize, zoom, Offset(panX, panY))?.let { activePoints = listOf(it) }
                                    },
                                    onDragEnd = {
                                        if (activePoints.isNotEmpty()) {
                                            onStrokeAdded(
                                                InkStroke(
                                                    id = UUID.randomUUID().toString(),
                                                    pageIndex = currentPage,
                                                    points = activePoints,
                                                    widthPt = penWidthPt,
                                                    argb = penArgb
                                                )
                                            )
                                        }
                                        activePoints = emptyList()
                                    },
                                    onDragCancel = { activePoints = emptyList() },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        toNormalisedPoint(change.position, pageSize, zoom, Offset(panX, panY))?.let { point ->
                                            activePoints = activePoints + point
                                        }
                                    }
                                )
                                DigitalSigningMode.Erase -> detectDragGestures(
                                    onDragStart = { position ->
                                        toNormalisedPoint(position, pageSize, zoom, Offset(panX, panY))?.let { onEraseAt(it, zoom) }
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        toNormalisedPoint(change.position, pageSize, zoom, Offset(panX, panY))?.let { onEraseAt(it, zoom) }
                                    }
                                )
                            }
                        }
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            scaleX = zoom
                            scaleY = zoom
                            translationX = panX
                            translationY = panY
                        }
                    ) {
                        Image(
                            bitmap = page.bitmap.asImageBitmap(),
                            contentDescription = "PDF page ${currentPage + 1}",
                            modifier = Modifier.fillMaxSize()
                        )
                        Canvas(Modifier.fillMaxSize()) {
                            fun drawStroke(stroke: InkStroke) {
                                if (stroke.points.isEmpty()) return
                                val colour = Color(stroke.argb)
                                val pxWidth = (stroke.widthPt * size.width / page.bitmap.width.toFloat().coerceAtLeast(1f)).coerceAtLeast(1.2f)
                                if (stroke.points.size == 1) {
                                    val p = stroke.points.first()
                                    drawCircle(colour, radius = pxWidth / 2f, center = Offset(p.x * size.width, p.y * size.height))
                                } else {
                                    val path = androidx.compose.ui.graphics.Path()
                                    val first = stroke.points.first()
                                    path.moveTo(first.x * size.width, first.y * size.height)
                                    stroke.points.drop(1).forEach { p -> path.lineTo(p.x * size.width, p.y * size.height) }
                                    drawPath(path, colour, style = Stroke(width = pxWidth, cap = StrokeCap.Round))
                                }
                            }
                            strokes.forEach(::drawStroke)
                            if (activePoints.isNotEmpty()) {
                                drawStroke(
                                    InkStroke(
                                        id = "active",
                                        pageIndex = currentPage,
                                        points = activePoints,
                                        widthPt = penWidthPt,
                                        argb = penArgb
                                    )
                                )
                            }
                        }
                    }

                    Surface(
                        modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                        shape = RoundedCornerShape(50),
                        color = Color.Black.copy(alpha = 0.62f)
                    ) {
                        Text(
                            if (zoom <= 1.01f) mode.name else "${mode.name} · ${String.format("%.1f", zoom)}×",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}

private fun toNormalisedPoint(position: Offset, size: IntSize, zoom: Float, pan: Offset): InkPoint? {
    if (size.width <= 0 || size.height <= 0) return null
    val centreX = size.width / 2f
    val centreY = size.height / 2f
    val unscaledX = (position.x - centreX - pan.x) / zoom.coerceAtLeast(1f) + centreX
    val unscaledY = (position.y - centreY - pan.y) / zoom.coerceAtLeast(1f) + centreY
    if (unscaledX !in 0f..size.width.toFloat() || unscaledY !in 0f..size.height.toFloat()) return null
    return InkPoint(unscaledX / size.width, unscaledY / size.height)
}

@Composable
private fun InkToolbar(
    mode: DigitalSigningMode,
    onModeChanged: (DigitalSigningMode) -> Unit,
    onUndo: () -> Unit,
    canUndo: Boolean,
    penColor: String,
    onPenColorChanged: (String) -> Unit,
    penWidthPt: Float,
    onPenWidthChanged: (Float) -> Unit,
    enabled: Boolean
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("Document tools", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ToolModeButton("Navigate", mode == DigitalSigningMode.Navigate, enabled, Modifier.weight(1f)) { onModeChanged(DigitalSigningMode.Navigate) }
                ToolModeButton("Ink", mode == DigitalSigningMode.Ink, enabled, Modifier.weight(1f)) { onModeChanged(DigitalSigningMode.Ink) }
                ToolModeButton("Erase", mode == DigitalSigningMode.Erase, enabled, Modifier.weight(1f)) { onModeChanged(DigitalSigningMode.Erase) }
                OutlinedButton(onClick = onUndo, enabled = enabled && canUndo, modifier = Modifier.weight(1f)) { Text("Undo") }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Ink", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.width(8.dp))
                PenColourChoice("black", penColor, enabled, onPenColorChanged)
                Spacer(Modifier.width(6.dp))
                PenColourChoice("blue", penColor, enabled, onPenColorChanged)
                Spacer(Modifier.weight(1f))
                OutlinedButton(
                    onClick = { onPenWidthChanged((penWidthPt - 0.4f).coerceAtLeast(0.8f)) },
                    enabled = enabled && penWidthPt > 0.8f
                ) { Text("−") }
                Text(" ${String.format("%.1f", penWidthPt)} pt ", style = MaterialTheme.typography.labelMedium)
                OutlinedButton(
                    onClick = { onPenWidthChanged((penWidthPt + 0.4f).coerceAtMost(10f)) },
                    enabled = enabled && penWidthPt < 10f
                ) { Text("+") }
            }
            Text(
                if (mode == DigitalSigningMode.Navigate) "Pan and pinch to zoom. Switch to Ink to write on the page." else "Navigate and inking are explicit modes so marks are never added accidentally.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ToolModeButton(label: String, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, enabled = enabled, modifier = modifier) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier) { Text(label) }
    }
}

@Composable
private fun PenColourChoice(value: String, selected: String, enabled: Boolean, onSelected: (String) -> Unit) {
    val colour = if (value == "blue") Color(0xFF184F9A) else Color(0xFF141718)
    Surface(
        modifier = Modifier.size(30.dp).clip(CircleShape).clickable(enabled = enabled) { onSelected(value) },
        shape = CircleShape,
        color = colour,
        border = BorderStroke(if (selected == value) 3.dp else 1.dp, if (selected == value) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
    ) {}
}

@Composable
private fun CommitCard(
    finalisePdf: Boolean,
    finaliseForced: Boolean,
    onFinaliseChanged: (Boolean) -> Unit,
    requestTsa: Boolean,
    onRequestTsaChanged: (Boolean) -> Unit,
    tsaUrl: String,
    onTsaUrlChanged: (String) -> Unit,
    showTsaUrl: Boolean,
    strokeCount: Int,
    isCommitting: Boolean,
    onCommit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.48f))
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("Commit", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(
                "$strokeCount ink stroke(s) · Commit always creates a new PDF; the source is never overwritten.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            HorizontalDivider()
            Spacer(Modifier.height(10.dp))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = finalisePdf,
                    onCheckedChange = if (finaliseForced) null else onFinaliseChanged,
                    enabled = !isCommitting
                )
                Column(Modifier.weight(1f)) {
                    Text("Finalise PDF", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(
                        if (finaliseForced) {
                            "Required for ODK/external return. The complete committed appearance is raster-flattened."
                        } else {
                            "Flatten the complete committed appearance, removing editable form/annotation structure."
                        },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            if (finalisePdf) {
                Text(
                    "Finalisation fixes the existing appearance but is not DRM: a capable PDF editor can still add new markup later. SHA-256/TSA verification detects any changed file bytes.",
                    modifier = Modifier.padding(start = 48.dp, top = 4.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = requestTsa,
                    onCheckedChange = onRequestTsaChanged,
                    enabled = !isCommitting
                )
                Column(Modifier.weight(1f)) {
                    Text("Trusted timestamp", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text("Request an RFC 3161 timestamp over the SHA-256 of the exact committed PDF.", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (requestTsa && showTsaUrl) {
                OutlinedTextField(
                    value = tsaUrl,
                    onValueChange = onTsaUrlChanged,
                    modifier = Modifier.fillMaxWidth().padding(start = 48.dp, top = 6.dp),
                    label = { Text("RFC 3161 TSA URL") },
                    placeholder = { Text("https://…") },
                    singleLine = true,
                    enabled = !isCommitting
                )
            }
            if (requestTsa) {
                Text(
                    "The TSA attests time/existence of the committed hash. It does not authenticate the identity of the person who drew the ink.",
                    modifier = Modifier.padding(start = 48.dp, top = 6.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onCommit,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = strokeCount > 0 && !isCommitting
            ) {
                Text(
                    when {
                        isCommitting -> "Committing…"
                        finalisePdf && requestTsa -> "Commit · Finalise · Timestamp"
                        finalisePdf -> "Commit finalised PDF"
                        requestTsa -> "Commit · Timestamp"
                        else -> "Commit signed PDF"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
            if (strokeCount == 0) {
                Text(
                    "Add at least one ink stroke before Commit.",
                    modifier = Modifier.padding(top = 6.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
