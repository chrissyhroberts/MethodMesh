package com.example.methodmesh.modules.digitalsigning

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object DigitalSigningModule : MethodMeshModule {
    override val moduleId = "digitalsigning"
    override val displayName = "Digital signing"
    override val summary = "Open a PDF, add handwritten ink, commit a new version, and optionally obtain an RFC 3161 trusted timestamp."
    override val iconKey = "document"

    override fun as100Methods() = listOf(As100DigitalSigningMethod)

    override fun rilBindings() = listOf(
        RilBinding("sign pdf", As100DigitalSigningMethod.ID, "Ink-sign a PDF and commit a new document"),
        RilBinding("digitally sign document", As100DigitalSigningMethod.ID, "Add visible handwritten ink to a PDF"),
        RilBinding("timestamp signed pdf", As100DigitalSigningMethod.ID, "Sign a PDF and optionally request an RFC 3161 timestamp")
    )

    override fun capabilityScreens() = listOf(DigitalSigningCapabilityScreen)

    override fun capabilitySettings() = mapOf(
        As100DigitalSigningMethod.ID to listOf(
            MethodSetting.TextSetting(
                id = "pdf_uri",
                label = "PDF input URI",
                description = "Optional content/file URI supplied by ODK, a protocol, or another Android caller. Direct use can choose a PDF in the workspace.",
                group = "Document",
                defaultValue = ""
            ),
            MethodSetting.BooleanSetting(
                id = "finalise_pdf",
                label = "Finalise PDF",
                description = "Raster-flatten the committed appearance to remove editable form/annotation structure. ODK calls always use this mode.",
                group = "Commit",
                defaultValue = false
            ),
            MethodSetting.BooleanSetting(
                id = "request_tsa",
                label = "Trusted timestamp",
                description = "After Commit, request an RFC 3161 timestamp over the SHA-256 of the exact committed PDF.",
                group = "Attestation",
                defaultValue = false
            ),
            MethodSetting.TextSetting(
                id = "tsa_url",
                label = "RFC 3161 TSA URL",
                description = "HTTP(S) endpoint accepting application/timestamp-query.",
                group = "Attestation",
                defaultValue = ""
            ),
            MethodSetting.FloatSetting(
                id = "pen_width_pt",
                label = "Ink width",
                group = "Ink",
                defaultValue = 2.4f,
                minimum = 0.8f,
                maximum = 10f,
                step = 0.2f,
                unit = "pt",
                decimals = 1
            ),
            MethodSetting.ChoiceSetting(
                id = "pen_color",
                label = "Ink colour",
                group = "Ink",
                defaultValue = "black",
                choices = listOf("black", "blue")
            )
        )
    )
}
