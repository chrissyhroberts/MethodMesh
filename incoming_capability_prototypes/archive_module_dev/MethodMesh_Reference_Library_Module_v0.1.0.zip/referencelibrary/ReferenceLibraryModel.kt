package com.example.methodmesh.modules.referencelibrary

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class LibraryDocument(
    val id: String,
    val title: String,
    val shelf: String,
    val uri: String,
    val mimeType: String,
    val source: String = "User supplied",
    val version: String = "",
    val favourite: Boolean = false,
    val lastOpenedEpochMs: Long = 0L
)

class ReferenceLibraryRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("methodmesh.reference.library", Context.MODE_PRIVATE)

    fun documents(): List<LibraryDocument> = decode(prefs.getString(KEY_DOCUMENTS, "[]").orEmpty())

    fun upsert(document: LibraryDocument) {
        val current = documents().toMutableList()
        val index = current.indexOfFirst { it.id == document.id }
        if (index >= 0) current[index] = document else current.add(document)
        save(current)
    }

    fun importDocument(title: String, shelf: String, uri: Uri, mimeType: String): LibraryDocument {
        val document = LibraryDocument(
            id = UUID.randomUUID().toString(),
            title = title.ifBlank { "Untitled document" },
            shelf = shelf.ifBlank { "personal" },
            uri = uri.toString(),
            mimeType = mimeType.ifBlank { "application/octet-stream" }
        )
        upsert(document)
        return document
    }

    fun markOpened(id: String) {
        documents().firstOrNull { it.id == id }?.let { upsert(it.copy(lastOpenedEpochMs = System.currentTimeMillis())) }
    }

    fun toggleFavourite(id: String) {
        documents().firstOrNull { it.id == id }?.let { upsert(it.copy(favourite = !it.favourite)) }
    }

    fun remove(id: String) = save(documents().filterNot { it.id == id })

    private fun save(documents: List<LibraryDocument>) {
        prefs.edit().putString(KEY_DOCUMENTS, encode(documents)).apply()
    }

    private fun encode(documents: List<LibraryDocument>): String = JSONArray().apply {
        documents.forEach { document ->
            put(JSONObject().apply {
                put("id", document.id)
                put("title", document.title)
                put("shelf", document.shelf)
                put("uri", document.uri)
                put("mime_type", document.mimeType)
                put("source", document.source)
                put("version", document.version)
                put("favourite", document.favourite)
                put("last_opened", document.lastOpenedEpochMs)
            })
        }
    }.toString()

    private fun decode(raw: String): List<LibraryDocument> = runCatching {
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                add(
                    LibraryDocument(
                        id = item.getString("id"),
                        title = item.optString("title", "Untitled document"),
                        shelf = item.optString("shelf", "personal"),
                        uri = item.getString("uri"),
                        mimeType = item.optString("mime_type", "application/octet-stream"),
                        source = item.optString("source", "User supplied"),
                        version = item.optString("version", ""),
                        favourite = item.optBoolean("favourite", false),
                        lastOpenedEpochMs = item.optLong("last_opened", 0L)
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    companion object { private const val KEY_DOCUMENTS = "documents" }
}
