# Reference Library architecture

The module owns document metadata, SAF import, shelf/search presentation and selection results. It does not require shared-shell special cases.

`ReferenceLibraryModule.kt` declares the MethodMesh module, settings and RIL bindings.  
`ReferenceLibraryMethod.kt` defines the stable method contract and output fields.  
`ReferenceLibraryCapabilityScreen.kt` implements the shelf-first native control centre.  
`ReferenceLibraryModel.kt` implements device-local metadata persistence.

The current reader boundary intentionally delegates display to an Android `ACTION_VIEW` handler. This keeps v0.1 dependency-free and makes PDFs/images/text usable immediately. A later in-module reader can replace that boundary without changing method IDs or repository metadata.
