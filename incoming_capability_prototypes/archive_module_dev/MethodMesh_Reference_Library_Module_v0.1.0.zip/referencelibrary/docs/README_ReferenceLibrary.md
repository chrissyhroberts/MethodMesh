# MethodMesh Reference Library

**Module ID:** `referencelibrary`  
**Method ID:** `reference.library.open`  
**Status:** Development  
**Version:** 0.1.0

## Purpose

Reference Library is the offline-first home for useful documents inside MethodMesh. It is deliberately not an emergency-monitoring capability. Its job is narrower: make manuals, field guides, procedures, reference cards and user documents quick to find and open.

The native surface is a library, not a settings form. Search, recent documents, shelf filters and document cards are shown on one screen. Imported files use Android's Storage Access Framework and persist read permission, so the app does not need to duplicate large PDFs into private storage.

## Shelves

- First aid
- Medical
- Safety
- Fieldwork
- Equipment
- Travel
- Personal

Shelves are presentation metadata, not hard security boundaries.

## Native workflow

1. Open Reference Library.
2. Search or select a shelf.
3. Tap a document card to open it with an Android document viewer.
4. Star frequently used documents.
5. Use **Add document** to import a PDF, text file or image.

The most recently opened documents are promoted into **Continue reading**.

## Persistence

The repository stores metadata in module-owned SharedPreferences and retains SAF read access to imported URIs. The original document remains in its original Android storage location. Removing the library entry does not delete the underlying file.

This v0.1 implementation does **not** copy user documents into MethodMesh storage and does not synchronize them to cloud services.

## Presets and protocols

A preset may supply `document_id`, `query` and `shelf`. Fixed preset settings are transported through the normal MethodMesh capability context. A known `document_id` can resolve directly when the capability is launched by an intent.

Library entries are device-local. A `document_id` is therefore not portable between phones unless a future managed pack installs stable IDs.

## ODK / XLSForm

External callers use method ID `reference.library.open`.

Inputs:

- `input_document_id` — optional device-local document ID
- `input_query` — optional search string
- `input_shelf` — optional shelf ID

Outputs:

- `library_status`
- `library_document_id`
- `library_document_title`
- `library_document_uri`
- `library_document_mime`
- `library_shelf`
- `library_error`

The main useful result is the selected document URI/title. The URI remains subject to Android URI permission semantics; callers should not assume permanent cross-app access beyond the normal MethodMesh transport grant.

## Deliberate boundaries

This module does not contain:

- hazard monitoring or RAG status;
- emergency navigation or exit strategy;
- emergency numbers;
- location tracking;
- persistent emergency notifications;
- an encrypted identity-document vault.

Those belong in a separate Emergency capability. Emergency may later deep-link to stable Reference Library document IDs/packs rather than duplicating content.

## Next implementation steps

Before Production: add managed/bundled document packs with stable IDs and manifests; add a first-party in-app PDF/text reader; add document metadata editing; add pack provenance/checksum/version UI; test URI persistence across reboot/provider changes; test native/preset/protocol/ODK roundtrips and rotation; confirm accessibility and large-library performance.
