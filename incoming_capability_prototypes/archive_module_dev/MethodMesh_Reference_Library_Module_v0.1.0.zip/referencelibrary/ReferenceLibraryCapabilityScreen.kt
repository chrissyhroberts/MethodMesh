package com.example.methodmesh.modules.referencelibrary

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

object ReferenceLibraryCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ReferenceLibraryMethod.ID
    override val title = "Reference library"
    override val description = "Useful documents, ready when the network is not."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val repository = remember { ReferenceLibraryRepository(appContext) }
        var documents by remember { mutableStateOf(repository.documents()) }
        var query by rememberSaveable { mutableStateOf(context.action.settings["query"] ?: context.action.settings["input_query"] ?: "") }
        var shelf by rememberSaveable { mutableStateOf(context.action.settings["shelf"] ?: context.action.settings["input_shelf"] ?: "all") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var selected by remember { mutableStateOf<LibraryDocument?>(null) }
        var pendingShelf by rememberSaveable { mutableStateOf("personal") }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun selectDocument(document: LibraryDocument) {
            selected = document
            repository.markOpened(document.id)
            documents = repository.documents()
            val request = As100ReferenceLibraryMethod.request(
                action = As100ReferenceLibraryMethod.ID,
                context = context.request.invocationContext.asMap(As100ReferenceLibraryMethod.ID) + context.action.settings + mapOf("document_id" to document.id),
                signals = emptyList(),
                inputs = emptyList()
            )
            result = As100ReferenceLibraryMethod.result(request, As100ReferenceLibraryMethod.selected(document), context.request.invocationContext)
            if (context.submitsImmediately) result?.let(onConfirmed)
        }

        fun openDocument(document: LibraryDocument) {
            selectDocument(document)
            runCatching {
                appContext.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(Uri.parse(document.uri), document.mimeType)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri ?: return@rememberLauncherForActivityResult
            runCatching { appContext.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = runCatching {
                appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            }.getOrNull().orEmpty().ifBlank { "Imported document" }
            val mime = appContext.contentResolver.getType(uri).orEmpty().ifBlank { "application/octet-stream" }
            val imported = repository.importDocument(name, pendingShelf, uri, mime)
            documents = repository.documents()
            selectDocument(imported)
        }

        LaunchedEffect(query, shelf) {
            context.onSettingsChanged(mapOf("query" to query, "shelf" to shelf))
        }

        LaunchedEffect(context.presentationMode, context.action.settings, documents) {
            if (context.presentationMode == CapabilityPresentationMode.IntentLaunch && !launched) {
                launched = true
                val targetId = context.action.settings["document_id"] ?: context.action.settings["input_document_id"]
                documents.firstOrNull { it.id == targetId }?.let(::selectDocument)
            }
        }

        val visible = documents
            .filter { shelf == "all" || it.shelf == shelf }
            .filter { query.isBlank() || it.title.contains(query, ignoreCase = true) || it.source.contains(query, ignoreCase = true) }
            .sortedWith(compareByDescending<LibraryDocument> { it.favourite }.thenByDescending { it.lastOpenedEpochMs }.thenBy { it.title.lowercase() })
        val recent = documents.filter { it.lastOpenedEpochMs > 0 }.sortedByDescending { it.lastOpenedEpochMs }.take(5)

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { selected?.let(::selectDocument) },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text("Your useful references", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("Keep manuals, field guides and procedures available offline.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search documents") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(SHELVES) { item ->
                    FilterChip(selected = shelf == item.id, onClick = { shelf = item.id }, label = { Text(item.label) })
                }
            }

            if (recent.isNotEmpty() && query.isBlank() && shelf == "all") {
                Spacer(Modifier.height(18.dp))
                SectionTitle("Continue reading")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(recent, key = { it.id }) { document -> DocumentTile(document, onOpen = { openDocument(document) }) }
                }
            }

            Spacer(Modifier.height(18.dp))
            SectionTitle(if (shelf == "all") "Your shelves" else SHELVES.firstOrNull { it.id == shelf }?.label ?: "Documents")
            if (visible.isEmpty()) {
                EmptyLibraryCard(onImport = { pendingShelf = if (shelf == "all") "personal" else shelf; picker.launch(arrayOf("application/pdf", "text/*", "image/*")) })
            } else {
                visible.forEach { document ->
                    LibraryRow(
                        document = document,
                        onOpen = { openDocument(document) },
                        onFavourite = { repository.toggleFavourite(document.id); documents = repository.documents() }
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { pendingShelf = if (shelf == "all") "personal" else shelf; picker.launch(arrayOf("application/pdf", "text/*", "image/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("＋ Add document") }
            Text("Imported documents stay in their original Android storage location; MethodMesh retains permission to read them offline.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

private data class Shelf(val id: String, val label: String)
private val SHELVES = listOf(
    Shelf("all", "All"), Shelf("first_aid", "First aid"), Shelf("medical", "Medical"), Shelf("safety", "Safety"),
    Shelf("fieldwork", "Fieldwork"), Shelf("equipment", "Equipment"), Shelf("travel", "Travel"), Shelf("personal", "Personal")
)

@Composable private fun SectionTitle(text: String) = Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

@Composable
private fun DocumentTile(document: LibraryDocument, onOpen: () -> Unit) {
    Card(
        modifier = Modifier.width(170.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text("▤", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))
            Text(document.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(document.shelf.replace('_', ' ').replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun LibraryRow(document: LibraryDocument, onOpen: () -> Unit, onFavourite: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.weight(1f)) {
                Text("▤", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(document.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(document.shelf.replace('_', ' ').replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodySmall)
                }
            }
            OutlinedButton(onClick = onFavourite) { Text(if (document.favourite) "★" else "☆") }
        }
    }
}

@Composable
private fun EmptyLibraryCard(onImport: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("This shelf is empty", style = MaterialTheme.typography.titleMedium)
            Text("Add a PDF, text file or image that you want available when you need it.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 6.dp))
            OutlinedButton(onClick = onImport) { Text("Add first document") }
        }
    }
}
