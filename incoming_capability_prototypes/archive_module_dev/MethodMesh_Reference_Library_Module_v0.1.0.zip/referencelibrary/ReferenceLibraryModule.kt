package com.example.methodmesh.modules.referencelibrary

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object ReferenceLibraryModule : MethodMeshModule {
    override val moduleId = "referencelibrary"
    override val displayName = "Reference library"
    override val summary = "Keep useful field references, manuals and document packs accessible offline."

    override fun as100Methods() = listOf(As100ReferenceLibraryMethod)

    override fun rilBindings() = listOf(
        RilBinding("open reference library", As100ReferenceLibraryMethod.ID, "Open the offline reference library"),
        RilBinding("find reference document", As100ReferenceLibraryMethod.ID, "Find and open a reference document")
    )

    override fun capabilityScreens() = listOf(ReferenceLibraryCapabilityScreen)

    override fun capabilitySettings() = mapOf(
        As100ReferenceLibraryMethod.ID to listOf(
            MethodSetting.TextSetting("document_id", "Document ID", defaultValue = ""),
            MethodSetting.TextSetting("query", "Search", defaultValue = ""),
            MethodSetting.ChoiceSetting(
                "shelf",
                "Shelf",
                defaultValue = "all",
                choices = listOf("all", "first_aid", "medical", "safety", "fieldwork", "equipment", "travel", "personal")
            )
        )
    )
}
