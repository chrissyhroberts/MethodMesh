# v0.041 compatibility fix

- Removed all `Modifier.weight(...)` usage for compatibility with the MethodMesh Compose version.
- Renamed the `DieFace` `size` parameter to `dieSize` so it no longer shadows `DrawScope.size`.
- Reworked Mancala sizing using `BoxWithConstraints` and explicit calculated sizes.
- No game-engine logic changed.

# v0.04 implementation notes

This release is intended to replace v0.03 as the next drop-in `gamedeck/` MethodMesh capability folder.

## What to test in the real MethodMesh app

1. Capability discovery still lists GameDeck without any central registration edit.
2. GameDeck opens on the four-card launcher.
3. Connect Four accepts taps on the graphical board and still detects horizontal, vertical and diagonal wins.
4. Snakes & Ladders rolls using the existing Chance module and moves tokens on the graphical board.
5. Mancala works in both local and `Vs CPU` modes; captures and extra turns behave sensibly.
6. Minesweeper generates only after the first tap. The GameLab panel should report `VALIDATED` for a solver-approved board, or explicitly `FALLBACK` if the bounded generator did not find one.
7. Long-pressing a hidden Minesweeper cell toggles a flag.
8. `Use this snapshot` still returns the state through `gamedeck.snapshot`.

## Static checks performed here

- `GameDeckEngine.kt` compiles against small type stubs, which checks Kotlin syntax/type consistency in the pure engine.
- No production copy of `DiceSimulatorEngine` exists in this folder.
- No manual `ChanceEngine.install(...)` or central registration hook is present.
- The Minesweeper generator obtains its random candidate draws through `As100DiceSimulationMethod`.

The full Android/Compose capability cannot be assembled here because the host MethodMesh Gradle project is not available in this runtime. The real app build remains the authoritative integration test.
