# GameDeck changelog

## v0.04 — 2026-09-05

- Replaced the developer-style selector with a four-card GameDeck launcher.
- Reworked Connect Four as a graphical board with direct column tapping and winning-line highlighting.
- Reworked Snakes & Ladders as a graphical board with visible snakes/ladders, player tokens and a die face.
- Retained the existing MethodMesh Chance engine for all Snakes & Ladders rolls.
- Added Mancala/Kalah with two-player mode and a lightweight heuristic CPU opponent.
- Added Minesweeper as the first GameLab game.
- Added parameter presets and first-click procedural generation.
- Added a deterministic Minesweeper constraint solver and bounded rejection loop for no-guess boards.
- GameLab random draws are sourced through the existing MethodMesh Chance dice method.
- Added visible GameLab validation metrics instead of hiding generator behaviour.
- Updated XLSForm example with launcher, Mancala and Minesweeper choices.
- Delivery is now the `gamedeck/` folder alone.

## v0.042
- Fixed remaining DieFace call site to use renamed `dieSize` parameter.
