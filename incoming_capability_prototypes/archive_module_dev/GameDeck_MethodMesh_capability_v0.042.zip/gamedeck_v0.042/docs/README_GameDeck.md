# GameDeck capability v0.04

GameDeck is a persistent MethodMesh dashboard capability containing small games implemented over shared MethodMesh services.

## Included games

- **Connect Four** — graphical 7×6 board, local two-player play, win highlighting.
- **Snakes & Ladders** — graphical board, two-player play, secure or fixed-seed d6 outcomes supplied by the existing MethodMesh Chance capability.
- **Mancala (Kalah)** — local two-player play or a lightweight heuristic CPU opponent.
- **Minesweeper / GameLab** — parameterised procedural boards. The first click fixes the opening; GameLab generates candidate boards using Chance-backed draws and runs a deterministic no-guess solver before accepting a board where possible.

## Delivery shape

This folder is itself the handoff unit. Copy `gamedeck/` beneath the MethodMesh modules directory. Do not add central registration code; `GameDeckModule.kt` is intended to be discovered by the normal MethodMesh module scanner.

## Shared Chance dependency

GameDeck does **not** contain `DiceSimulatorEngine`. It imports the existing MethodMesh Chance public method object:

- `As100DiceSimulationMethod`
- `DiceSimulationFields`

This is used for Snakes & Ladders and for GameLab random candidate generation. Secure runtime randomness and fixed-seed reproducibility therefore inherit the Chance engine's existing behaviour and provenance model.

## GameLab v1

The Minesweeper generator is the first live GameLab vertical slice:

1. wait for the player's first cell;
2. exclude that opening and its neighbours from mine placement;
3. generate candidate mine placements with the Chance dice engine;
4. run a deterministic constraint solver;
5. accept a no-guess-solvable board where possible;
6. expose validation status, generation attempts, solver passes and mine density in the UI.

If the bounded search cannot find a validated board, GameDeck explicitly labels the result `FALLBACK` rather than claiming validation succeeded.

## Snapshot method

Method ID: `gamedeck.snapshot`

The interactive dashboard remains live until the user explicitly chooses **Use this snapshot** / **Finish**. External invocations remain single-shot.

## Current boundaries

v0.04 is intentionally not yet the full GameDeck specification. It establishes:

- a launcher/shelf rather than a developer game selector;
- reusable graphical board surfaces;
- Chance integration without duplicate engines;
- the first CPU opponent;
- the first procedural `generate → simulate → validate → play` workflow.

P2P, player profiles/XP, replay UI, social deduction, micro-city generation and heavyweight optional runtimes remain later phases.
