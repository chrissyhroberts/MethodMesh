package com.example.methodmesh.modules.multicounter

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MulticounterStateTest {
    @Test
    fun count_changes_respect_step_and_zero_floor() {
        val state = MulticounterSessionState.create(
            settings = mapOf(
                "mode" to "count",
                "entity_count" to "2",
                "entity_names" to "A|B",
                "counter_start" to "0",
                "step" to "3",
                "allow_negative" to "false"
            ),
            nowRealtimeMs = 100L,
            startedTimeIso = "2026-09-06T12:00:00Z"
        )
        val plus = state.changeValue(0, 1, 110L, "2026-09-06T12:00:00.010Z")
        assertEquals(3, plus.entities[0].value)
        val minus = plus.changeValue(0, -1, 120L, "2026-09-06T12:00:00.020Z")
        assertEquals(0, minus.entities[0].value)
        val floor = minus.changeValue(0, -1, 130L, "2026-09-06T12:00:00.030Z")
        assertEquals(0, floor.entities[0].value)
    }

    @Test
    fun staggered_start_arms_successive_entities() {
        val state = MulticounterSessionState.create(
            settings = mapOf(
                "mode" to "time",
                "entity_count" to "3",
                "entity_names" to "A|B|C",
                "stagger_seconds" to "5"
            ),
            nowRealtimeMs = 1_000L,
            startedTimeIso = "2026-09-06T12:00:00Z"
        ).startAll(2_000L, "2026-09-06T12:00:01Z")

        assertEquals(2_000L, state.entities[0].runningSinceRealtimeMs)
        assertEquals(7_000L, state.entities[1].pendingStartRealtimeMs)
        assertEquals(12_000L, state.entities[2].pendingStartRealtimeMs)

        val later = state.normalize(7_500L, "2026-09-06T12:00:06.500Z")
        assertEquals(7_000L, later.entities[1].runningSinceRealtimeMs)
        assertEquals(null, later.entities[1].pendingStartRealtimeMs)
    }

    @Test
    fun countdown_stops_at_zero() {
        val state = MulticounterSessionState.create(
            settings = mapOf(
                "mode" to "time",
                "entity_count" to "1",
                "timer_mode" to "countdown",
                "countdown_seconds" to "10"
            ),
            nowRealtimeMs = 0L,
            startedTimeIso = "2026-09-06T12:00:00Z"
        ).toggleTimer(0, 1_000L, "2026-09-06T12:00:01Z")

        val expired = state.normalize(11_500L, "2026-09-06T12:00:11.500Z")
        assertEquals(0L, expired.displayTimerMs(expired.entities[0], 11_500L))
        assertEquals(null, expired.entities[0].runningSinceRealtimeMs)
        assertTrue(expired.events.any { it.eventType == "timer_expired" })
    }

    @Test
    fun finish_freezes_running_timers() {
        val running = MulticounterSessionState.create(
            settings = mapOf("mode" to "time", "entity_count" to "1"),
            nowRealtimeMs = 100L,
            startedTimeIso = "2026-09-06T12:00:00Z"
        ).toggleTimer(0, 200L, "2026-09-06T12:00:00.100Z")

        val finished = running.finish(1_200L, "2026-09-06T12:00:01.100Z")
        assertFalse(finished.hasActiveTimers)
        assertEquals(1_000L, finished.entities[0].elapsedMs)
        assertTrue(finished.events.any { it.eventType == "session_finished" })
    }

    @Test
    fun duration_format_supports_tenths_and_hours() {
        assertEquals("01:02.3", MulticounterSessionState.formatDuration(62_399L, "tenths"))
        assertEquals("1:01:01", MulticounterSessionState.formatDuration(3_661_999L, "seconds"))
    }

    @Test
    fun result_text_is_beef_first() {
        val state = MulticounterSessionState.create(
            settings = mapOf(
                "mode" to "count",
                "entity_count" to "2",
                "entity_names" to "Red|Blue",
                "show_total" to "true",
                "show_leader" to "true"
            ),
            nowRealtimeMs = 0L,
            startedTimeIso = "2026-09-06T12:00:00Z"
        ).changeValue(0, 1, 10L, "2026-09-06T12:00:00.010Z")

        val text = state.resultText(10L)
        assertTrue(text.contains("Red 1"))
        assertTrue(text.contains("Blue 0"))
        assertTrue(text.contains("Total 1"))
        assertTrue(text.contains("Leader Red (1)"))
    }
    @Test
    fun negative_start_is_normalized_when_negatives_are_disabled() {
        val state = MulticounterSessionState.create(
            settings = mapOf(
                "mode" to "count",
                "entity_count" to "1",
                "counter_start" to "-5",
                "allow_negative" to "false"
            ),
            nowRealtimeMs = 0L,
            startedTimeIso = "2026-09-06T12:00:00Z"
        )
        assertEquals(0, state.entities[0].value)
        assertEquals(0, state.counterStart)
    }

}
