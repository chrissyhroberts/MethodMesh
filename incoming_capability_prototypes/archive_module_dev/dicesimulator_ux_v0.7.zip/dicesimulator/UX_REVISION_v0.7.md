# Dice Simulator UX revision v0.7

## Pathological explosion-chain layout

The roll tray now treats each base die as a fixed-width visual slot. Explosion descendants remain nested inside their parent slot instead of widening the main dice grid.

- Up to four descendant rolls are shown as a compact 2 × 2 inset block.
- Longer chains collapse to `+N more`; the complete primitive chain remains available in the structured roll details/audit output.
- The full-screen tray is vertically scrollable when long chains or large base pools exceed the available height.
- The expert expression at the top can wrap across up to three centred lines rather than forcing a single horizontal line.

This is deliberately stress-tested for implausibly explosive configurations as well as ordinary RPG use. A pathological rule should make the tray taller, not make individual labels or dice collapse horizontally.
