package com.example.methodmesh.modules.timertools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.delay
import java.util.Locale

object TimerCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TimerManageMethod.ID
    override val title = "Timers"
    override val description = "Persistent stopwatches, laps, countdowns and multiple simultaneous timers."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val repository = remember { TimerRepository(androidContext.applicationContext) }

        var workspaceId by rememberSaveable { mutableStateOf(context.setting("workspace_id", "default")) }
        var workspace by remember { mutableStateOf(repository.load(workspaceId)) }
        var selectedId by rememberSaveable { mutableStateOf(context.setting("timer_id", "")) }
        var newName by rememberSaveable { mutableStateOf(context.setting("timer_name", "Timer")) }
        var newType by rememberSaveable { mutableStateOf(context.setting("timer_type", "stopwatch")) }
        var newDurationSeconds by rememberSaveable { mutableStateOf(context.setting("duration_seconds", "60")) }
        var latestExecution by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("Ready.") }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var nowEpochMs by remember { mutableStateOf(System.currentTimeMillis()) }

        val keepLiveDashboard =
            context.presentationMode == CapabilityPresentationMode.Dashboard ||
                context.isNativePresetRun ||
                context.request.source.equals("intent_test", ignoreCase = true)

        fun selectFallback() {
            if (workspace.timers.none { it.id == selectedId }) {
                selectedId = workspace.timers.firstOrNull()?.id.orEmpty()
            }
        }

        fun resultFor(selected: TimerRecord? = workspace.timers.firstOrNull { it.id == selectedId }, error: String = ""): ExecutionResult {
            val settings = context.request.settings + context.action.settings + mapOf("workspace_id" to workspaceId)
            val request = As100TimerManageMethod.request(
                action = capabilityId,
                context = context.request.invocationContext.asMap(capabilityId) + settings,
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100TimerManageMethod.result(
                request = request,
                values = repository.values(workspace, selected, error),
                invocation = context.request.invocationContext
            )
        }

        fun snapshot(selectedIdOverride: String? = null) {
            workspace = repository.normalise(workspace)
            if (selectedIdOverride != null) selectedId = selectedIdOverride
            selectFallback()
            val selected = workspace.timers.firstOrNull { it.id == selectedId }
            latestExecution = resultFor(selected)
            status = if (selected == null) {
                "Workspace snapshot: ${workspace.timers.size} timer(s)."
            } else {
                val displayMs = if (selected.type == "countdown") selected.remaining(nowEpochMs) else selected.elapsed(nowEpochMs)
                "${selected.name}: ${formatDuration(displayMs)}"
            }
        }

        fun performExternal() {
            val operation = context.setting("operation", "snapshot")
            val requestedId = context.setting("timer_id", "")
            val execution = runCatching {
                workspace = repository.load(workspaceId)
                val selected = when (operation) {
                    "create" -> {
                        val durationMs = ((context.setting("duration_seconds", "60").toDoubleOrNull() ?: 60.0) * 1000.0).toLong()
                        val pair = repository.create(
                            workspace = workspace,
                            name = context.setting("timer_name", "Timer"),
                            type = context.setting("timer_type", "stopwatch"),
                            durationMs = durationMs
                        )
                        workspace = pair.first
                        pair.second
                    }
                    "start" -> repository.start(workspace, requestedId).also { workspace = it.first }.second
                    "pause" -> repository.pause(workspace, requestedId).also { workspace = it.first }.second
                    "reset" -> repository.reset(workspace, requestedId).also { workspace = it.first }.second
                    "lap" -> repository.lap(workspace, requestedId).also { workspace = it.first }.second
                    "delete" -> {
                        workspace = repository.delete(workspace, requestedId)
                        null
                    }
                    "snapshot" -> workspace.timers.firstOrNull { it.id == requestedId }
                        ?: workspace.timers.firstOrNull()
                    else -> error("Unsupported timer operation '$operation'.")
                }
                resultFor(selected)
            }.getOrElse { error ->
                resultFor(null, error.message ?: "Timer operation failed.")
            }
            latestExecution = execution
            status = OutputFormatter.fields(execution, includeProvenance = false)[TimerFields.ERROR]
                ?.toString()
                ?.takeIf { it.isNotBlank() }
                ?: "Timer operation complete."
            if (context.submitsImmediately) onConfirmed(execution)
        }

        LaunchedEffect(workspaceId) {
            workspace = repository.load(workspaceId)
            selectFallback()
            context.onSettingsChanged(mapOf("workspace_id" to workspaceId))
            if (keepLiveDashboard) snapshot()
        }

        LaunchedEffect(workspace.timers.any { it.running }) {
            while (workspace.timers.any { it.running }) {
                delay(100L)
                nowEpochMs = System.currentTimeMillis()
                if (workspace.timers.any { it.running && it.completed(nowEpochMs) }) {
                    workspace = repository.normalise(workspace)
                    snapshot()
                }
            }
        }

        LaunchedEffect(context.presentationMode, context.action.settings, context.request.source) {
            if (!keepLiveDashboard && !launched) {
                launched = true
                performExternal()
            }
        }

        LaunchedEffect(newName, newType, newDurationSeconds, selectedId) {
            context.onSettingsChanged(
                mapOf(
                    "timer_id" to selectedId,
                    "timer_name" to newName,
                    "timer_type" to newType,
                    "duration_seconds" to newDurationSeconds
                )
            )
        }

        val scaffoldResult = if (keepLiveDashboard) null else latestExecution
        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { if (keepLiveDashboard) snapshot() else performExternal() },
            onConfirm = { latestExecution?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            if (!keepLiveDashboard) {
                Text(status)
                return@CapabilityScreenScaffold
            }

            Column(Modifier.fillMaxWidth()) {
                if (context.settingShouldBeShown("workspace_id")) {
                    OutlinedTextField(
                        value = workspaceId,
                        onValueChange = { workspaceId = it },
                        label = { Text("Workspace") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                }

                workspace.timers.forEach { timer ->
                    val elapsed = timer.elapsed(nowEpochMs)
                    val remaining = timer.remaining(nowEpochMs)
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(timer.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (timer.type == "countdown") formatDuration(remaining) else formatDuration(elapsed),
                                style = MaterialTheme.typography.headlineMedium
                            )
                            Text(
                                when {
                                    timer.type == "countdown" && timer.completed(nowEpochMs) -> "Countdown • complete"
                                    timer.type == "countdown" && timer.running -> "Countdown • running"
                                    timer.type == "countdown" -> "Countdown • paused"
                                    timer.running -> "Stopwatch • running"
                                    else -> "Stopwatch • paused"
                                },
                                style = MaterialTheme.typography.bodySmall
                            )

                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                if (timer.running) {
                                    Button(
                                        onClick = {
                                            runCatching { repository.pause(workspace, timer.id) }
                                                .onSuccess { (updated, selected) ->
                                                    workspace = updated
                                                    snapshot(selected.id)
                                                }
                                                .onFailure { status = it.message.orEmpty() }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Pause") }
                                } else {
                                    Button(
                                        onClick = {
                                            runCatching { repository.start(workspace, timer.id) }
                                                .onSuccess { (updated, selected) ->
                                                    workspace = updated
                                                    snapshot(selected.id)
                                                }
                                                .onFailure { status = it.message.orEmpty() }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Start") }
                                }
                                OutlinedButton(
                                    onClick = {
                                        runCatching { repository.reset(workspace, timer.id) }
                                            .onSuccess { (updated, selected) ->
                                                workspace = updated
                                                snapshot(selected.id)
                                            }
                                            .onFailure { status = it.message.orEmpty() }
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Reset") }
                                if (timer.type == "stopwatch") {
                                    OutlinedButton(
                                        onClick = {
                                            runCatching { repository.lap(workspace, timer.id) }
                                                .onSuccess { (updated, selected) ->
                                                    workspace = updated
                                                    snapshot(selected.id)
                                                }
                                                .onFailure { status = it.message.orEmpty() }
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("Lap") }
                                }
                            }

                            if (timer.laps.isNotEmpty()) {
                                Text(
                                    "Recent laps: " + timer.laps.takeLast(5).joinToString(" • ") { formatDuration(it) },
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    runCatching { repository.delete(workspace, timer.id) }
                                        .onSuccess { updated ->
                                            workspace = updated
                                            if (selectedId == timer.id) selectedId = ""
                                            snapshot()
                                        }
                                        .onFailure { status = it.message.orEmpty() }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Delete") }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Add timer", style = MaterialTheme.typography.titleMedium)
                if (context.settingShouldBeShown("timer_name")) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                if (context.settingShouldBeShown("timer_type")) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (newType == "stopwatch") {
                            Button(onClick = { newType = "stopwatch" }, modifier = Modifier.weight(1f)) { Text("✓ Stopwatch") }
                        } else {
                            OutlinedButton(onClick = { newType = "stopwatch" }, modifier = Modifier.weight(1f)) { Text("Stopwatch") }
                        }
                        if (newType == "countdown") {
                            Button(onClick = { newType = "countdown" }, modifier = Modifier.weight(1f)) { Text("✓ Countdown") }
                        } else {
                            OutlinedButton(onClick = { newType = "countdown" }, modifier = Modifier.weight(1f)) { Text("Countdown") }
                        }
                    }
                }
                if (newType == "countdown" && context.settingShouldBeShown("duration_seconds")) {
                    OutlinedTextField(
                        value = newDurationSeconds,
                        onValueChange = { newDurationSeconds = it.decimalText() },
                        label = { Text("Duration seconds") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                Button(
                    onClick = {
                        runCatching {
                            repository.create(
                                workspace = workspace,
                                name = newName,
                                type = newType,
                                durationMs = ((newDurationSeconds.toDoubleOrNull() ?: 60.0) * 1000.0).toLong()
                            )
                        }.onSuccess { (updated, timer) ->
                            workspace = updated
                            selectedId = timer.id
                            snapshot(timer.id)
                        }.onFailure { status = it.message.orEmpty() }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Add timer") }

                Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
                OutlinedButton(onClick = { snapshot() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Refresh snapshot")
                }
                if (latestExecution != null) {
                    Button(onClick = { latestExecution?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot")
                    }
                }
            }
        }
    }
}

private fun CapabilityScreenContext.setting(key: String, fallback: String): String =
    action.settings[key]
        ?: action.settings["input_$key"]
        ?: request.settings[key]
        ?: request.settings["input_$key"]
        ?: fallback

private fun String.decimalText(): String = filter { it.isDigit() || it == '.' }.let { filtered ->
    filtered.split('.').let { parts ->
        parts.first() + if (parts.size > 1) "." + parts.drop(1).joinToString("") else ""
    }
}

private fun formatDuration(ms: Long): String {
    val total = ms.coerceAtLeast(0L)
    val hours = total / 3_600_000L
    val minutes = (total / 60_000L) % 60L
    val seconds = (total / 1_000L) % 60L
    val tenths = (total / 100L) % 10L
    return if (hours > 0) {
        "%d:%02d:%02d.%d".format(Locale.US, hours, minutes, seconds, tenths)
    } else {
        "%02d:%02d.%d".format(Locale.US, minutes, seconds, tenths)
    }
}
