package com.example.methodmesh.modules.soundgenerator

import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState

object MetronomeFields {
    const val STATUS = "metronome_status"
    const val BPM = "metronome_bpm"
    const val BEATS = "metronome_beats"
    const val BEAT_INTERVAL_MS = "metronome_beat_interval_ms"
    const val CLICK_MS = "metronome_click_ms"
    const val FREQUENCY_HZ = "metronome_frequency_hz"
    const val LEVEL_DBFS = "metronome_level_dbfs"
    const val DURATION_MS = "metronome_duration_ms"
    const val PCM_SHA256 = "metronome_pcm_sha256"
    const val WRITTEN_PCM_SHA256 = "metronome_written_pcm_sha256"
    const val FRAMES_PLAYED = "metronome_frames_played"
    const val ROUTED_DEVICE = "metronome_routed_device"
    const val STARTED_TIME_ISO = "metronome_started_time_iso"
    const val FINISHED_TIME_ISO = "metronome_finished_time_iso"
    const val ERROR = "metronome_error"
    val outputs = listOf(STATUS, BPM, BEATS, BEAT_INTERVAL_MS, CLICK_MS, FREQUENCY_HZ, LEVEL_DBFS, DURATION_MS, PCM_SHA256, WRITTEN_PCM_SHA256, FRAMES_PLAYED, ROUTED_DEVICE, STARTED_TIME_ISO, FINISHED_TIME_ISO, ERROR)
}

object As100MetronomeMethod : As100Method {
    const val ID = "sound.metronome"
    private const val VERSION = "0.1.0"
    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Metronome")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID), methodType = MethodObjectType.Workflow, name = "Metronome", version = VERSION,
        description = "Generate a bounded metronome click sequence from the local AudioTrack synthesis boundary.",
        outputs = MetronomeFields.outputs, graphOutputs = listOf(ID),
        parameters = mapOf("category" to "Stimulus generation", "status" to "Development")
    )
    override val contract = MethodContract(method = ref, producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation), producedFields = descriptor.outputs, producedGraphOutputs = descriptor.graphOutputs)
    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) = As100ExecutionEngine.request(action, ref, context, signals, inputs)
    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?) = As100ExecutionEngine.complete(request, TransformationStatus.Unsupported, diagnostics = mapOf("reason" to "Metronome playback requires the Android AudioTrack boundary."))
    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[MetronomeFields.STATUS] == "played"
        val p = ProvenanceContext("android.media.AudioTrack", ID, VERSION)
        val o = Observation(phenomenon = ID, subject = null, values = values, temporalContext = request.temporalContext, provenance = p)
        val t = Transformation(action = ID, method = ref, outputs = listOf(ArchitectureRef(o.id, o.objectType, o.phenomenon)), status = if (ok) TransformationStatus.Succeeded else if (values[MetronomeFields.STATUS] == "stopped") TransformationStatus.Cancelled else TransformationStatus.Failed, temporalContext = request.temporalContext, provenance = p)
        return As100ExecutionEngine.complete(request, t.status, observations = listOf(o), transformations = listOf(t), diagnostics = if (ok) emptyMap() else mapOf(MetronomeFields.ERROR to values[MetronomeFields.ERROR].orEmpty())).withInvocationContext(invocation)
    }
}
