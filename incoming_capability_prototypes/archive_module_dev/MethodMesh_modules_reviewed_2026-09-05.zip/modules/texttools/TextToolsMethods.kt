package com.example.methodmesh.modules.texttools

import com.example.methodmesh.core.crypto.Digests
import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONObject
import java.util.Locale

object TextToolFields {
    const val STATUS = "texttool_status"
    const val OPERATION = "texttool_operation"
    const val INPUT_SHA256 = "texttool_input_sha256"
    const val OUTPUT_TEXT = "texttool_output_text"
    const val CHARACTER_COUNT = "texttool_character_count"
    const val NONSPACE_COUNT = "texttool_nonspace_count"
    const val WORD_COUNT = "texttool_word_count"
    const val LINE_COUNT = "texttool_line_count"
    const val UNIQUE_WORD_COUNT = "texttool_unique_word_count"
    const val ADDED_LINES = "texttool_added_lines"
    const val REMOVED_LINES = "texttool_removed_lines"
    const val UNCHANGED_LINES = "texttool_unchanged_lines"
    const val AUDIT_JSON = "texttool_audit_json"
    const val ERROR = "texttool_error"
    val outputs = listOf(STATUS, OPERATION, INPUT_SHA256, OUTPUT_TEXT, CHARACTER_COUNT, NONSPACE_COUNT, WORD_COUNT, LINE_COUNT, UNIQUE_WORD_COUNT, ADDED_LINES, REMOVED_LINES, UNCHANGED_LINES, AUDIT_JSON, ERROR)
}

internal abstract class BaseTextToolMethod(final override val id: String, name: String, description: String) : As100Method {
    override val ref = ArchitectureRef(ArchitectureId(id), "Method", name)
    override val descriptor = MethodDescriptor(id = ArchitectureId(id), methodType = MethodObjectType.Calculation, name = name, version = "0.1.0", description = description, outputs = TextToolFields.outputs, graphOutputs = listOf(id), parameters = mapOf("category" to "Text utilities", "status" to "Development"))
    override val contract = MethodContract(method = ref, producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation), producedFields = descriptor.outputs, producedGraphOutputs = descriptor.graphOutputs)
    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) = As100ExecutionEngine.request(action, ref, context, signals, inputs)
    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult = result(request, calculate(request.context), InvocationContext.from(request.context))
    abstract fun calculate(context: Map<String, String>): Map<String, String>
    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[TextToolFields.STATUS] == "succeeded"
        val provenance = ProvenanceContext("methodmesh.texttools", id, "0.1.0")
        val obs = Observation(phenomenon = id, subject = null, values = values, temporalContext = request.temporalContext, provenance = provenance)
        val tx = Transformation(action = id, method = ref, outputs = listOf(ArchitectureRef(obs.id, obs.objectType, obs.phenomenon)), status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, temporalContext = request.temporalContext, provenance = provenance)
        return As100ExecutionEngine.complete(request, if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, observations = listOf(obs), transformations = listOf(tx), diagnostics = if (ok) emptyMap() else mapOf(TextToolFields.ERROR to values[TextToolFields.ERROR].orEmpty())).withInvocationContext(invocation)
    }
}

object As100TextTransformMethod : BaseTextToolMethod("text.transform", "Text transformer", "Apply deterministic case, whitespace, line and replacement transformations.") {
    override fun calculate(context: Map<String, String>): Map<String, String> {
        val op = context.value("operation") ?: "trim"
        val input = context.valueAllowBlank("text") ?: ""
        return runCatching {
            require(input.length <= 1_000_000) { "Text is limited to 1,000,000 characters per transformation." }
            val output = when (op) {
                "uppercase" -> input.uppercase(Locale.ROOT)
                "lowercase" -> input.lowercase(Locale.ROOT)
                "title_case" -> titleCase(input)
                "trim" -> input.trim()
                "normalize_whitespace" -> input.trim().replace(Regex("[\\t\\r\\n ]+"), " ")
                "sort_lines" -> input.lines().sorted().joinToString("\n")
                "deduplicate_lines" -> input.lines().distinct().joinToString("\n")
                "reverse_lines" -> input.lines().reversed().joinToString("\n")
                "find_replace" -> {
                    val find = context.valueAllowBlank("find") ?: ""
                    require(find.isNotEmpty()) { "Find text cannot be empty." }
                    input.replace(find, context.valueAllowBlank("replace") ?: "")
                }
                else -> error("Unknown text operation '$op'.")
            }
            textSuccess(op, input, output, JSONObject().put("operation", op).put("input_length", input.length).put("output_length", output.length).toString())
        }.getOrElse { textFailure(op, input, it.message.orEmpty()) }
    }
    private fun titleCase(input: String): String = Regex("\\p{L}[\\p{L}\\p{M}'’-]*").replace(input.lowercase(Locale.ROOT)) { match -> match.value.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() } }
}

object As100TextStatsMethod : BaseTextToolMethod("text.stats", "Text statistics", "Count characters, words, lines and unique case-insensitive words.") {
    override fun calculate(context: Map<String, String>): Map<String, String> {
        val input = context.valueAllowBlank("text") ?: ""
        return runCatching {
            require(input.length <= 1_000_000) { "Text is limited to 1,000,000 characters." }
            val words = Regex("[\\p{L}\\p{N}]+(?:['’][\\p{L}\\p{N}]+)?").findAll(input).map { it.value }.toList()
            linkedMapOf(
                TextToolFields.STATUS to "succeeded", TextToolFields.OPERATION to "stats", TextToolFields.INPUT_SHA256 to Digests.sha256Hex(input),
                TextToolFields.OUTPUT_TEXT to "", TextToolFields.CHARACTER_COUNT to input.length.toString(),
                TextToolFields.NONSPACE_COUNT to input.count { !it.isWhitespace() }.toString(), TextToolFields.WORD_COUNT to words.size.toString(),
                TextToolFields.LINE_COUNT to if (input.isEmpty()) "0" else input.lines().size.toString(), TextToolFields.UNIQUE_WORD_COUNT to words.map { it.lowercase(Locale.ROOT) }.toSet().size.toString(),
                TextToolFields.AUDIT_JSON to JSONObject().put("word_pattern", "Unicode letters/digits with optional apostrophe").toString(), TextToolFields.ERROR to ""
            )
        }.getOrElse { textFailure("stats", input, it.message.orEmpty()) }
    }
}

object As100TextDiffMethod : BaseTextToolMethod("text.diff", "Line diff", "Compare two texts with a bounded line-level longest-common-subsequence diff.") {
    override fun calculate(context: Map<String, String>): Map<String, String> {
        val left = context.valueAllowBlank("left") ?: ""
        val right = context.valueAllowBlank("right") ?: ""
        return runCatching {
            val a = if (left.isEmpty()) emptyList() else left.lines()
            val b = if (right.isEmpty()) emptyList() else right.lines()
            require(a.size <= 500 && b.size <= 500) { "Line diff is limited to 500 lines per side." }
            val result = lineDiff(a, b)
            linkedMapOf(
                TextToolFields.STATUS to "succeeded", TextToolFields.OPERATION to "line_diff", TextToolFields.INPUT_SHA256 to Digests.sha256Hex(left + "\u0000" + right),
                TextToolFields.OUTPUT_TEXT to result.text, TextToolFields.ADDED_LINES to result.added.toString(), TextToolFields.REMOVED_LINES to result.removed.toString(), TextToolFields.UNCHANGED_LINES to result.unchanged.toString(),
                TextToolFields.AUDIT_JSON to JSONObject().put("algorithm", "bounded_lcs_lines").put("left_lines", a.size).put("right_lines", b.size).toString(), TextToolFields.ERROR to ""
            )
        }.getOrElse { textFailure("line_diff", left, it.message.orEmpty()) }
    }

    private data class Diff(val text: String, val added: Int, val removed: Int, val unchanged: Int)
    private fun lineDiff(a: List<String>, b: List<String>): Diff {
        val dp = Array(a.size + 1) { IntArray(b.size + 1) }
        for (i in a.indices.reversed()) for (j in b.indices.reversed()) dp[i][j] = if (a[i] == b[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
        var i = 0; var j = 0; var added = 0; var removed = 0; var unchanged = 0
        val out = StringBuilder()
        while (i < a.size || j < b.size) {
            when {
                i < a.size && j < b.size && a[i] == b[j] -> { out.append("  ").append(a[i]).append('\n'); i++; j++; unchanged++ }
                j < b.size && (i == a.size || dp[i][j + 1] >= dp[i + 1][j]) -> { out.append("+ ").append(b[j]).append('\n'); j++; added++ }
                else -> { out.append("- ").append(a[i]).append('\n'); i++; removed++ }
            }
        }
        return Diff(out.toString().trimEnd(), added, removed, unchanged)
    }
}

private fun Map<String, String>.value(key: String): String? = (this[key] ?: this["input_$key"])?.takeIf { it.isNotBlank() }
private fun Map<String, String>.valueAllowBlank(key: String): String? = this[key] ?: this["input_$key"]
private fun textSuccess(op: String, input: String, output: String, audit: String): Map<String, String> = linkedMapOf(TextToolFields.STATUS to "succeeded", TextToolFields.OPERATION to op, TextToolFields.INPUT_SHA256 to Digests.sha256Hex(input), TextToolFields.OUTPUT_TEXT to output, TextToolFields.CHARACTER_COUNT to output.length.toString(), TextToolFields.AUDIT_JSON to audit, TextToolFields.ERROR to "")
private fun textFailure(op: String, input: String, error: String): Map<String, String> = linkedMapOf(TextToolFields.STATUS to "failed", TextToolFields.OPERATION to op, TextToolFields.INPUT_SHA256 to Digests.sha256Hex(input), TextToolFields.OUTPUT_TEXT to "", TextToolFields.AUDIT_JSON to "{}", TextToolFields.ERROR to error)
