package com.example.xlsformlab.modules.digitalsigning

import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cms.SignerInformationVerifier
import org.bouncycastle.cms.jcajce.JcaSimpleSignerInfoVerifierBuilder
import org.bouncycastle.tsp.TSPAlgorithms
import org.bouncycastle.tsp.TimeStampRequestGenerator
import org.bouncycastle.tsp.TimeStampResponse
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.net.HttpURLConnection
import java.net.URI
import java.security.SecureRandom
import java.time.Instant
import java.util.Base64

object DigitalSigningTsaClient {
    private val random = SecureRandom()

    fun requestTimestamp(
        signedSha256Hex: String,
        tsaUrl: String,
        timeoutSeconds: Int
    ): TsaAttestation {
        if (tsaUrl.isBlank()) {
            return TsaAttestation(
                requested = true,
                status = "not_configured",
                messageImprintHex = signedSha256Hex,
                imprintMatchesSignedPdf = null,
                error = "No TSA URL is configured. The committed PDF is still valid and can be timestamped later."
            )
        }

        return runCatching {
            val digest = DigitalSigningHash.hexToBytes(signedSha256Hex)
            val nonce = java.math.BigInteger(96, random)
            val request = TimeStampRequestGenerator().apply {
                setCertReq(true)
            }.generate(TSPAlgorithms.SHA256, digest, nonce)

            val connection = URI(tsaUrl).toURL().openConnection() as HttpURLConnection
            try {
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.connectTimeout = timeoutSeconds.coerceIn(2, 60) * 1000
                connection.readTimeout = timeoutSeconds.coerceIn(2, 60) * 1000
                connection.setRequestProperty("Content-Type", "application/timestamp-query")
                connection.setRequestProperty("Accept", "application/timestamp-reply")
                connection.outputStream.use { it.write(request.encoded) }

                val code = connection.responseCode
                val responseBytes = if (code in 200..299) {
                    connection.inputStream.use { it.readBytes() }
                } else {
                    val errorBody = connection.errorStream?.use { it.readBytes().decodeToString() }.orEmpty()
                    error("TSA HTTP $code${if (errorBody.isBlank()) "" else ": $errorBody"}")
                }

                val response = TimeStampResponse(responseBytes)
                response.validate(request)
                val token = response.timeStampToken ?: error("TSA response did not contain a timestamp token")
                val info = token.timeStampInfo
                val signerMatches = token.certificates.getMatches(token.sid)
                val signerHolder = signerMatches.firstOrNull() as? X509CertificateHolder
                val provider = BouncyCastleProvider()
                val signerCertificate = signerHolder?.let {
                    JcaX509CertificateConverter().setProvider(provider).getCertificate(it)
                }
                val signatureValid = signerCertificate?.let { certificate ->
                    runCatching {
                        val verifier: SignerInformationVerifier = JcaSimpleSignerInfoVerifierBuilder()
                            .setProvider(provider)
                            .build(certificate)
                        token.validate(verifier)
                        true
                    }.getOrDefault(false)
                }
                val certValidAtTimestamp = signerCertificate?.let { certificate ->
                    runCatching {
                        certificate.checkValidity(info.genTime)
                        true
                    }.getOrDefault(false)
                }

                val authority = signerCertificate?.subjectX500Principal?.name
                    ?: signerHolder?.subject?.toString()

                TsaAttestation(
                    requested = true,
                    status = if (signatureValid == true && certValidAtTimestamp == true) "verified" else "received_unverified",
                    authority = authority,
                    timestampUtc = info.genTime.toInstant().toString(),
                    messageImprintHex = signedSha256Hex,
                    policyOid = info.policy?.id,
                    serialNumber = info.serialNumber?.toString(),
                    tokenBase64 = Base64.getEncoder().encodeToString(token.encoded),
                    signatureValid = signatureValid,
                    imprintMatchesSignedPdf = true,
                    certificateValidAtTimestamp = certValidAtTimestamp
                )
            } finally {
                connection.disconnect()
            }
        }.getOrElse { error ->
            TsaAttestation(
                requested = true,
                status = "failed",
                messageImprintHex = signedSha256Hex,
                imprintMatchesSignedPdf = null,
                error = error.message ?: error::class.java.simpleName
            )
        }
    }
}
