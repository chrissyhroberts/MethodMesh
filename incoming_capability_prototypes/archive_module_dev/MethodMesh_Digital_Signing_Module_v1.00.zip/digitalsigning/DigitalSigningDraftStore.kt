package com.example.xlsformlab.modules.digitalsigning

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class DigitalSigningDraftStore(
    context: Context,
    private val executionId: String
) {
    private val appContext = context.applicationContext
    private val draftDir = File(
        appContext.filesDir,
        "methodmesh/digital_signing/drafts/$executionId"
    ).apply { mkdirs() }

    private val sourceFile = File(draftDir, "source.pdf")
    private val stateFile = File(draftDir, "draft.json")

    data class RestoredDraft(
        val workingPdf: WorkingPdf,
        val strokes: List<InkStroke>,
        val currentPage: Int,
        val committedResult: DigitalSigningCommittedResult? = null,
        val committedFile: File? = null
    )

    fun importPdf(uri: Uri, origin: PdfInputOrigin): WorkingPdf {
        val resolver = appContext.contentResolver
        resolver.openInputStream(uri)?.use { input ->
            sourceFile.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Could not open the selected PDF")

        val displayName = queryDisplayName(uri) ?: "document.pdf"
        val pageCount = DigitalSigningPdfEngine.pageCount(sourceFile)
        val sha256 = DigitalSigningHash.sha256(sourceFile)

        val working = WorkingPdf(
            sourceFile = sourceFile,
            displayName = displayName.ensurePdfName(),
            sourceOrigin = origin,
            sourceSha256 = sha256,
            pageCount = pageCount
        )
        save(working, emptyList(), 0)
        return working
    }

    fun save(
        workingPdf: WorkingPdf,
        strokes: List<InkStroke>,
        currentPage: Int,
        preserveCommittedResult: Boolean = false
    ) {
        val previous = if (preserveCommittedResult && stateFile.exists()) {
            runCatching { JSONObject(stateFile.readText()) }.getOrNull()
        } else null
        val root = JSONObject()
            .put("display_name", workingPdf.displayName)
            .put("source_origin", workingPdf.sourceOrigin.id)
            .put("source_sha256", workingPdf.sourceSha256)
            .put("page_count", workingPdf.pageCount)
            .put("current_page", currentPage)

        val strokeArray = JSONArray()
        strokes.forEach { stroke ->
            val points = JSONArray()
            stroke.points.forEach { point ->
                points.put(JSONObject().put("x", point.x.toDouble()).put("y", point.y.toDouble()))
            }
            strokeArray.put(
                JSONObject()
                    .put("id", stroke.id)
                    .put("page_index", stroke.pageIndex)
                    .put("width_pt", stroke.widthPt.toDouble())
                    .put("argb", stroke.argb)
                    .put("points", points)
            )
        }
        root.put("strokes", strokeArray)
        previous?.optString("committed_result_json")?.takeIf { it.isNotBlank() }?.let {
            root.put("committed_result_json", it)
        }
        previous?.optString("committed_output_path")?.takeIf { it.isNotBlank() }?.let {
            root.put("committed_output_path", it)
        }
        stateFile.writeText(root.toString())
    }

    fun restore(): RestoredDraft? {
        if (!sourceFile.exists() || !stateFile.exists()) return null
        return runCatching {
            val root = JSONObject(stateFile.readText())
            val origin = PdfInputOrigin.entries.firstOrNull {
                it.id == root.optString("source_origin")
            } ?: PdfInputOrigin.RestoredDraft
            val working = WorkingPdf(
                sourceFile = sourceFile,
                displayName = root.optString("display_name", "document.pdf"),
                sourceOrigin = if (origin == PdfInputOrigin.Unknown) PdfInputOrigin.RestoredDraft else origin,
                sourceSha256 = root.optString("source_sha256", DigitalSigningHash.sha256(sourceFile)),
                pageCount = root.optInt("page_count", DigitalSigningPdfEngine.pageCount(sourceFile))
            )
            val strokesJson = root.optJSONArray("strokes") ?: JSONArray()
            val strokes = buildList {
                for (index in 0 until strokesJson.length()) {
                    val strokeJson = strokesJson.getJSONObject(index)
                    val pointsJson = strokeJson.optJSONArray("points") ?: JSONArray()
                    val points = buildList {
                        for (pointIndex in 0 until pointsJson.length()) {
                            val pointJson = pointsJson.getJSONObject(pointIndex)
                            add(
                                InkPoint(
                                    x = pointJson.optDouble("x").toFloat().coerceIn(0f, 1f),
                                    y = pointJson.optDouble("y").toFloat().coerceIn(0f, 1f)
                                )
                            )
                        }
                    }
                    if (points.isNotEmpty()) {
                        add(
                            InkStroke(
                                id = strokeJson.optString("id", UUID.randomUUID().toString()),
                                pageIndex = strokeJson.optInt("page_index", 0),
                                points = points,
                                widthPt = strokeJson.optDouble("width_pt", 2.4).toFloat(),
                                argb = strokeJson.optInt("argb", 0xFF101418.toInt())
                            )
                        )
                    }
                }
            }
            val committedResult = root.optString("committed_result_json")
                .takeIf { it.isNotBlank() }
                ?.let(DigitalSigningResultJson::parseResult)
            val committedFile = root.optString("committed_output_path")
                .takeIf { it.isNotBlank() }
                ?.let(::File)
                ?.takeIf(File::exists)

            RestoredDraft(
                workingPdf = working,
                strokes = strokes,
                currentPage = root.optInt("current_page", 0).coerceIn(0, (working.pageCount - 1).coerceAtLeast(0)),
                committedResult = if (committedFile != null) committedResult else null,
                committedFile = committedFile
            )
        }.getOrNull()
    }

    fun clearDraft() {
        draftDir.deleteRecursively()
    }

    fun markCommitted(result: DigitalSigningCommittedResult, outputFile: File) {
        val root = if (stateFile.exists()) {
            runCatching { JSONObject(stateFile.readText()) }.getOrElse { JSONObject() }
        } else {
            JSONObject()
        }
        root.put("committed_result_json", DigitalSigningResultJson.resultJson(result))
        root.put("committed_output_path", outputFile.absolutePath)
        stateFile.writeText(root.toString())
    }

    fun outputFile(displayName: String): File {
        val outputDir = File(appContext.filesDir, "methodmesh/digital_signing/committed").apply { mkdirs() }
        val base = displayName.removeSuffix(".pdf").removeSuffix(".PDF").ifBlank { "document" }
        val safe = base.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().take(80).ifBlank { "document" }
        val timestamp = DigitalSigningTime.fileStamp()
        return File(outputDir, "${safe}_signed_$timestamp.pdf")
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri.scheme != "content") return uri.lastPathSegment
        return appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (column >= 0 && cursor.moveToFirst()) cursor.getString(column) else null
        }
    }

    private fun String.ensurePdfName(): String = if (endsWith(".pdf", ignoreCase = true)) this else "$this.pdf"
}
