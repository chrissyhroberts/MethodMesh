package com.example.xlsformlab.modules.digitalsigning

import org.json.JSONObject

object DigitalSigningResultJson {
    fun tsaJson(tsa: TsaAttestation): String {
        return JSONObject()
            .put("requested", tsa.requested)
            .put("status", tsa.status)
            .putNullable("authority", tsa.authority)
            .putNullable("timestamp_utc", tsa.timestampUtc)
            .put("message_imprint_algorithm", tsa.messageImprintAlgorithm)
            .putNullable("message_imprint", tsa.messageImprintHex)
            .putNullable("policy_oid", tsa.policyOid)
            .putNullable("serial_number", tsa.serialNumber)
            .put("token_format", tsa.tokenFormat)
            .putNullable("token", tsa.tokenBase64)
            .put(
                "verification",
                JSONObject()
                    .putNullable("signature_valid", tsa.signatureValid)
                    .putNullable("imprint_matches_signed_pdf", tsa.imprintMatchesSignedPdf)
                    .putNullable("certificate_valid_at_timestamp", tsa.certificateValidAtTimestamp)
            )
            .putNullable("error", tsa.error)
            .toString()
    }

    fun parseResult(json: String): DigitalSigningCommittedResult? = runCatching {
        val root = JSONObject(json)
        val source = root.getJSONObject("source")
        val document = root.getJSONObject("document")
        val tsaJson = root.optJSONObject("tsa") ?: JSONObject()
        val verification = tsaJson.optJSONObject("verification") ?: JSONObject()
        val originId = source.optString("origin", PdfInputOrigin.Unknown.id)
        val origin = PdfInputOrigin.entries.firstOrNull { it.id == originId } ?: PdfInputOrigin.Unknown

        DigitalSigningCommittedResult(
            sourceOrigin = origin,
            sourceFilename = source.optString("filename", "document.pdf"),
            sourceSha256 = source.optString("sha256"),
            signedFilename = document.getString("signed_filename"),
            signedPdfUri = document.optString("signed_pdf_uri"),
            signedSha256 = document.getString("signed_sha256"),
            pageCount = document.optInt("page_count", 0),
            inkPresent = document.optBoolean("ink_present", false),
            inkStrokeCount = document.optInt("ink_stroke_count", 0),
            finalised = document.optBoolean("finalised", false),
            inkFlattened = document.optBoolean("ink_flattened", false),
            formFieldsFlattened = document.optBoolean("form_fields_flattened", false),
            editingRestricted = document.optBoolean("editing_restricted", false),
            markupRestricted = document.optBoolean("markup_restricted", false),
            committedAtUtc = document.optString("committed_at"),
            tsa = TsaAttestation(
                requested = tsaJson.optBoolean("requested", false),
                status = tsaJson.optString("status", "not_requested"),
                authority = tsaJson.nullableString("authority"),
                timestampUtc = tsaJson.nullableString("timestamp_utc"),
                messageImprintAlgorithm = tsaJson.optString("message_imprint_algorithm", "SHA-256"),
                messageImprintHex = tsaJson.nullableString("message_imprint"),
                policyOid = tsaJson.nullableString("policy_oid"),
                serialNumber = tsaJson.nullableString("serial_number"),
                tokenFormat = tsaJson.optString("token_format", "RFC3161"),
                tokenBase64 = tsaJson.nullableString("token"),
                signatureValid = verification.nullableBoolean("signature_valid"),
                imprintMatchesSignedPdf = verification.nullableBoolean("imprint_matches_signed_pdf"),
                certificateValidAtTimestamp = verification.nullableBoolean("certificate_valid_at_timestamp"),
                error = tsaJson.nullableString("error")
            )
        )
    }.getOrNull()

    fun resultJson(result: DigitalSigningCommittedResult): String {
        val source = JSONObject()
            .put("origin", result.sourceOrigin.id)
            .put("filename", result.sourceFilename)
            .put("sha256", result.sourceSha256)

        val document = JSONObject()
            .put("signed_filename", result.signedFilename)
            .put("signed_pdf_uri", result.signedPdfUri)
            .put("signed_sha256", result.signedSha256)
            .put("page_count", result.pageCount)
            .put("ink_present", result.inkPresent)
            .put("ink_stroke_count", result.inkStrokeCount)
            .put("finalised", result.finalised)
            .put("ink_flattened", result.inkFlattened)
            .put("form_fields_flattened", result.formFieldsFlattened)
            .put("editing_restricted", result.editingRestricted)
            .put("markup_restricted", result.markupRestricted)
            .put("committed_at", result.committedAtUtc)

        return JSONObject()
            .put("capability", DigitalSigningLaunchContract.CAPABILITY_ID)
            .put("status", "committed")
            .put("source", source)
            .put("document", document)
            .put("tsa", JSONObject(tsaJson(result.tsa)))
            .toString()
    }

    private fun JSONObject.putNullable(key: String, value: Any?): JSONObject {
        return if (value == null) put(key, JSONObject.NULL) else put(key, value)
    }

    private fun JSONObject.nullableString(key: String): String? =
        if (!has(key) || isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

    private fun JSONObject.nullableBoolean(key: String): Boolean? =
        if (!has(key) || isNull(key)) null else optBoolean(key)
}
