package com.example.xlsformlab.modules.digitalsigning

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.xlsformlab.core.Capability
import com.example.xlsformlab.core.CapabilityCategory
import com.example.xlsformlab.core.CapabilityField
import com.example.xlsformlab.core.CapabilityFieldType
import com.example.xlsformlab.core.CapabilityManifest
import com.example.xlsformlab.core.CapabilityOutput
import com.example.xlsformlab.core.CapabilityOutputSchema
import com.example.xlsformlab.core.CapabilityRequest
import com.example.xlsformlab.core.CapabilityResult
import com.example.xlsformlab.core.CapabilityStatus
import com.example.xlsformlab.settings.CapabilitySetting
import com.example.xlsformlab.settings.SettingsState

class DigitalSigningCapability : Capability {
    override val manifest = CapabilityManifest(
        id = DigitalSigningLaunchContract.CAPABILITY_ID,
        name = "Digital Signing",
        description = "Open a PDF, add handwritten ink, commit a new version, optionally finalise it and obtain an RFC 3161 trusted timestamp.",
        version = "1.0.0",
        category = CapabilityCategory.Utilities,
        status = CapabilityStatus.Beta
    )

    override val settings = listOf(
        CapabilitySetting.BooleanSetting(
            id = "finalise_pdf",
            label = "Finalise PDF",
            description = "Flatten new ink and restrict ordinary editing/markup in compliant PDF viewers.",
            group = "Commit",
            defaultValue = false
        ),
        CapabilitySetting.BooleanSetting(
            id = "request_tsa",
            label = "Request trusted timestamp",
            description = "After commit, send the final PDF SHA-256 imprint to an RFC 3161 timestamp authority.",
            group = "Timestamp",
            defaultValue = false
        ),
        CapabilitySetting.TextSetting(
            id = "tsa_url",
            label = "TSA URL",
            description = "RFC 3161 timestamp endpoint. Blank means timestamping is not configured.",
            group = "Timestamp",
            defaultValue = ""
        ),
        CapabilitySetting.IntSetting(
            id = "tsa_timeout_seconds",
            label = "TSA timeout",
            description = "Network timeout for timestamp requests.",
            group = "Timestamp",
            defaultValue = 15,
            minimum = 2,
            maximum = 60,
            step = 1,
            unit = "s"
        ),
        CapabilitySetting.FloatSetting(
            id = "pen_width_pt",
            label = "Ink width",
            description = "Width of committed vector ink in PDF points.",
            group = "Ink",
            defaultValue = 2.4f,
            minimum = 0.8f,
            maximum = 8f,
            step = 0.2f,
            unit = "pt",
            decimals = 1
        )
    )

    override val outputSchema = CapabilityOutputSchema(
        fields = listOf(
            CapabilityField("status", "Status", CapabilityFieldType.Text, required = false),
            CapabilityField("source_origin", "Source origin", CapabilityFieldType.Text, required = false),
            CapabilityField("source_filename", "Source filename", CapabilityFieldType.Text, required = false),
            CapabilityField("source_sha256", "Source SHA-256", CapabilityFieldType.Text, required = false),
            CapabilityField("signed_filename", "Signed filename", CapabilityFieldType.Text, required = false),
            CapabilityField("signed_pdf_uri", "Signed PDF URI", CapabilityFieldType.Text, required = false),
            CapabilityField("signed_sha256", "Signed SHA-256", CapabilityFieldType.Text, required = false),
            CapabilityField("page_count", "Page count", CapabilityFieldType.Integer, required = false),
            CapabilityField("ink_present", "Ink present", CapabilityFieldType.Boolean, required = false),
            CapabilityField("finalised", "Finalised", CapabilityFieldType.Boolean, required = false),
            CapabilityField("committed_at", "Committed at UTC", CapabilityFieldType.Text, required = false),
            CapabilityField("tsa_status", "TSA status", CapabilityFieldType.Text, required = false),
            CapabilityField("tsa_timestamp_utc", "TSA timestamp UTC", CapabilityFieldType.Text, required = false),
            CapabilityField("tsa_json", "TSA JSON", CapabilityFieldType.Json, required = false),
            CapabilityField("result_json", "Complete result JSON", CapabilityFieldType.Json, required = false)
        )
    )

    @Composable
    override fun Demo(settingsState: SettingsState) {
        DigitalSigningCapabilityScreen(settingsState)
    }

    @Composable
    override fun Help() {
        Text(
            "Digital Signing applies handwritten ink to a PDF and creates a new file; the source is never overwritten. " +
                "Finalise flattens the new ink and applies PDF permission restrictions to discourage ordinary editing and markup. " +
                "Those restrictions are not absolute DRM. An optional RFC 3161 timestamp attests that the exact committed file hash existed by the TSA's stated time. " +
                "This v1 ink workflow is not a certificate-backed identity signature or PAdES signature."
        )
    }

    override fun buildOutput(settingsState: SettingsState): CapabilityOutput {
        return CapabilityOutput(
            fields = mapOf(
                "status" to settingsState.getString("status"),
                "source_origin" to settingsState.getString("source_origin"),
                "source_filename" to settingsState.getString("source_filename"),
                "source_sha256" to settingsState.getString("source_sha256"),
                "signed_filename" to settingsState.getString("signed_filename"),
                "signed_pdf_uri" to settingsState.getString("signed_pdf_uri"),
                "signed_sha256" to settingsState.getString("signed_sha256"),
                "page_count" to settingsState.getInt("page_count"),
                "ink_present" to settingsState.getBoolean("ink_present"),
                "finalised" to settingsState.getBoolean("finalised"),
                "committed_at" to settingsState.getString("committed_at"),
                "tsa_status" to settingsState.getString("tsa_status"),
                "tsa_timestamp_utc" to settingsState.getString("tsa_timestamp_utc"),
                "tsa_json" to settingsState.getString("tsa_json"),
                "result_json" to settingsState.getString("result_json")
            )
        )
    }

    override fun execute(request: CapabilityRequest): CapabilityResult {
        return CapabilityResult(
            success = true,
            fields = mapOf(
                "interaction" to "required",
                "capability" to DigitalSigningLaunchContract.CAPABILITY_ID
            )
        )
    }
}
