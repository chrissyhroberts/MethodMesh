package com.example.xlsformlab.modules.digitalsigning

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import java.io.File
import java.security.SecureRandom
import kotlin.math.max
import kotlin.math.roundToInt

object DigitalSigningPdfEngine {
    private val random = SecureRandom()

    fun initialise(context: android.content.Context) {
        PDFBoxResourceLoader.init(context.applicationContext)
    }

    fun pageCount(file: File): Int {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer -> return renderer.pageCount }
        }
    }

    fun renderPage(file: File, pageIndex: Int, targetWidthPx: Int = 1800): RenderedPdfPage {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                require(pageIndex in 0 until renderer.pageCount) { "Page index out of range" }
                renderer.openPage(pageIndex).use { page ->
                    val width = max(targetWidthPx, 900)
                    val height = (width.toFloat() * page.height.toFloat() / page.width.toFloat())
                        .roundToInt()
                        .coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(android.graphics.Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return RenderedPdfPage(
                        pageIndex = pageIndex,
                        bitmap = bitmap,
                        pageWidthPt = page.width.toFloat(),
                        pageHeightPt = page.height.toFloat(),
                        rotation = 0
                    )
                }
            }
        }
    }

    fun commit(
        sourceFile: File,
        outputFile: File,
        strokes: List<InkStroke>,
        finalise: Boolean
    ): PdfCommitResult {
        val committedAt = DigitalSigningTime.nowUtc()
        var formFieldsFlattened = false
        var committedPageCount = 0

        PDDocument.load(sourceFile).use { document ->
            committedPageCount = document.numberOfPages
            strokes.groupBy { it.pageIndex }.forEach { (pageIndex, pageStrokes) ->
                if (pageIndex in 0 until document.numberOfPages) {
                    val page = document.getPage(pageIndex)
                    appendInk(page, pageStrokes, document)
                }
            }

            if (finalise) {
                val acroForm = document.documentCatalog.acroForm
                if (acroForm != null && acroForm.fields.isNotEmpty()) {
                    runCatching {
                        acroForm.flatten()
                        formFieldsFlattened = true
                    }
                }
                applyEditingRestrictions(document)
            }

            outputFile.parentFile?.mkdirs()
            document.save(outputFile)
        }

        return PdfCommitResult(
            outputFile = outputFile,
            signedSha256 = DigitalSigningHash.sha256(outputFile),
            pageCount = committedPageCount,
            inkFlattened = true,
            formFieldsFlattened = formFieldsFlattened,
            editingRestricted = finalise,
            markupRestricted = finalise,
            committedAtUtc = committedAt
        )
    }

    private fun appendInk(page: PDPage, strokes: List<InkStroke>, document: PDDocument) {
        if (strokes.isEmpty()) return
        val box = page.cropBox
        val rotation = ((page.rotation % 360) + 360) % 360
        PDPageContentStream(
            document,
            page,
            PDPageContentStream.AppendMode.APPEND,
            true,
            true
        ).use { stream ->
            stream.setLineCapStyle(1)
            stream.setLineJoinStyle(1)
            strokes.forEach { stroke ->
                if (stroke.points.isEmpty()) return@forEach
                val red = android.graphics.Color.red(stroke.argb)
                val green = android.graphics.Color.green(stroke.argb)
                val blue = android.graphics.Color.blue(stroke.argb)
                stream.setStrokingColor(red, green, blue)
                stream.setLineWidth(stroke.widthPt.coerceIn(0.5f, 18f))

                val first = toPdfPoint(stroke.points.first(), box.width, box.height, box.lowerLeftX, box.lowerLeftY, rotation)
                stream.moveTo(first.first, first.second)
                stroke.points.drop(1).forEach { point ->
                    val mapped = toPdfPoint(point, box.width, box.height, box.lowerLeftX, box.lowerLeftY, rotation)
                    stream.lineTo(mapped.first, mapped.second)
                }
                if (stroke.points.size == 1) {
                    stream.lineTo(first.first + 0.01f, first.second + 0.01f)
                }
                stream.stroke()
            }
        }
    }

    private fun toPdfPoint(
        point: InkPoint,
        width: Float,
        height: Float,
        offsetX: Float,
        offsetY: Float,
        rotation: Int
    ): Pair<Float, Float> {
        val nx = point.x.coerceIn(0f, 1f)
        val ny = point.y.coerceIn(0f, 1f)
        val local = when (rotation) {
            90 -> Pair(ny * width, nx * height)
            180 -> Pair((1f - nx) * width, ny * height)
            270 -> Pair((1f - ny) * width, (1f - nx) * height)
            else -> Pair(nx * width, (1f - ny) * height)
        }
        return Pair(local.first + offsetX, local.second + offsetY)
    }

    private fun applyEditingRestrictions(document: PDDocument) {
        val permissions = AccessPermission().apply {
            setCanModify(false)
            setCanModifyAnnotations(false)
            setCanFillInForm(false)
            setCanAssembleDocument(false)
            setCanExtractContent(true)
            setCanPrint(true)
            setCanPrintDegraded(true)
            setCanExtractForAccessibility(true)
        }
        val ownerPassword = ByteArray(24).also(random::nextBytes).joinToString("") { "%02x".format(it) }
        val policy = StandardProtectionPolicy(ownerPassword, "", permissions).apply {
            setEncryptionKeyLength(128)
            setPreferAES(true)
            setPermissions(permissions)
        }
        document.protect(policy)
    }
}
