package com.example.xlsformlab.modules.digitalsigning

import android.app.Activity
import android.content.Context
import android.graphics.Color as AndroidColor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Create
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Redo
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.xlsformlab.settings.SettingsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@Composable
fun DigitalSigningCapabilityScreen(settingsState: SettingsState) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val launch = remember(activity) {
        activity?.let(DigitalSigningLaunchContract::resolve)
            ?: DigitalSigningLaunchContract.ResolvedLaunch(null, PdfInputOrigin.Unknown, "direct", false)
    }
    val draftStore = remember(launch.executionId) { DigitalSigningDraftStore(context, launch.executionId) }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    var workingPdf by remember { mutableStateOf<WorkingPdf?>(null) }
    val strokes = remember { mutableStateListOf<InkStroke>() }
    val redoStack = remember { mutableStateListOf<InkStroke>() }
    var currentPage by remember { mutableIntStateOf(0) }
    var renderedPage by remember { mutableStateOf<RenderedPdfPage?>(null) }
    var mode by remember { mutableStateOf(DigitalSigningMode.Navigate) }
    var scale by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var busyMessage by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf("Choose a PDF to begin") }
    var commitResult by remember { mutableStateOf<DigitalSigningCommittedResult?>(null) }
    var committedFile by remember { mutableStateOf<File?>(null) }
    var activeStrokePoints by remember { mutableStateOf<List<InkPoint>>(emptyList()) }

    val openPdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    busyMessage = "Opening document…"
                    persistReadPermission(context, uri)
                    withContext(Dispatchers.IO) { draftStore.importPdf(uri, PdfInputOrigin.FilePicker) }
                }.onSuccess { working ->
                    workingPdf = working
                    strokes.clear()
                    redoStack.clear()
                    currentPage = 0
                    commitResult = null
                    committedFile = null
                    statusMessage = "Ready"
                }.onFailure { statusMessage = it.message ?: "Could not open PDF" }
                busyMessage = null
            }
        }
    }

    val savePdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { destination ->
        val file = committedFile
        if (destination != null && file != null) {
            scope.launch {
                runCatching {
                    busyMessage = "Saving copy…"
                    withContext(Dispatchers.IO) { DigitalSigningFileSupport.copyFileToUri(context, file, destination) }
                }.onSuccess { statusMessage = "Saved copy" }
                    .onFailure { statusMessage = it.message ?: "Could not save copy" }
                busyMessage = null
            }
        }
    }

    LaunchedEffect(Unit) {
        DigitalSigningPdfEngine.initialise(context)
        val restored = withContext(Dispatchers.IO) { draftStore.restore() }
        if (restored != null) {
            workingPdf = restored.workingPdf
            strokes.clear()
            strokes.addAll(restored.strokes)
            currentPage = restored.currentPage
            commitResult = restored.committedResult
            committedFile = restored.committedFile
            restored.committedResult?.let { result ->
                writeResultToSettings(
                    settingsState,
                    result,
                    DigitalSigningResultJson.resultJson(result),
                    DigitalSigningResultJson.tsaJson(result.tsa)
                )
            }
            statusMessage = if (restored.committedResult != null) "Committed result restored" else "Draft restored"
            return@LaunchedEffect
        }

        val pushedUri = launch.sourceUri
        if (pushedUri != null) {
            runCatching {
                busyMessage = "Opening supplied document…"
                withContext(Dispatchers.IO) { draftStore.importPdf(pushedUri, launch.sourceOrigin) }
            }.onSuccess { working ->
                workingPdf = working
                strokes.clear()
                currentPage = 0
                statusMessage = if (launch.sourceOrigin == PdfInputOrigin.Odk) "Document supplied by ODK" else "Document supplied by caller"
            }.onFailure {
                statusMessage = it.message ?: "Could not open supplied PDF"
            }
            busyMessage = null
        }
    }

    LaunchedEffect(workingPdf?.sourceFile, currentPage) {
        renderedPage?.bitmap?.recycle()
        renderedPage = null
        val working = workingPdf ?: return@LaunchedEffect
        runCatching {
            withContext(Dispatchers.IO) {
                DigitalSigningPdfEngine.renderPage(working.sourceFile, currentPage)
            }
        }.onSuccess { renderedPage = it }
            .onFailure { statusMessage = it.message ?: "Could not render page" }
        scale = 1f
        panX = 0f
        panY = 0f
    }

    DisposableEffect(Unit) {
        onDispose {
            renderedPage?.bitmap?.recycle()
        }
    }

    fun persistDraft(preserveCommittedResult: Boolean = false) {
        val working = workingPdf ?: return
        val strokeSnapshot = strokes.toList()
        val pageSnapshot = currentPage
        scope.launch(Dispatchers.IO) {
            runCatching {
                draftStore.save(
                    workingPdf = working,
                    strokes = strokeSnapshot,
                    currentPage = pageSnapshot,
                    preserveCommittedResult = preserveCommittedResult
                )
            }
        }
    }

    fun invalidateCommittedResult() {
        commitResult = null
        committedFile = null
    }

    fun copy(value: String, label: String) {
        if (value.isBlank()) return
        clipboard.setText(AnnotatedString(value))
        statusMessage = "$label copied"
    }

    fun commit() {
        val working = workingPdf ?: return
        if (busyMessage != null) return
        if (strokes.isEmpty()) {
            statusMessage = "Add ink before committing"
            return
        }
        scope.launch {
            busyMessage = "Committing signed PDF…"
            val finalise = settingsState.getBoolean("finalise_pdf") || launch.sourceOrigin == PdfInputOrigin.Odk
            val tsaRequested = settingsState.getBoolean("request_tsa")
            val tsaUrl = settingsState.getString("tsa_url").trim()
            val timeout = settingsState.getInt("tsa_timeout_seconds").coerceIn(2, 60)
            val outputFile = draftStore.outputFile(working.displayName)

            val strokeSnapshot = strokes.toList()
            val pdfCommit = runCatching {
                withContext(Dispatchers.IO) {
                    DigitalSigningPdfEngine.commit(
                        sourceFile = working.sourceFile,
                        outputFile = outputFile,
                        strokes = strokeSnapshot,
                        finalise = finalise
                    )
                }
            }.getOrElse { error ->
                busyMessage = null
                statusMessage = error.message ?: "Commit failed"
                return@launch
            }

            val shareUri = runCatching { DigitalSigningFileSupport.shareableUri(context, outputFile).toString() }
                .getOrElse { outputFile.toURI().toString() }

            fun resultFor(tsa: TsaAttestation) = DigitalSigningCommittedResult(
                sourceOrigin = working.sourceOrigin,
                sourceFilename = working.displayName,
                sourceSha256 = working.sourceSha256,
                signedFilename = outputFile.name,
                signedPdfUri = shareUri,
                signedSha256 = pdfCommit.signedSha256,
                pageCount = pdfCommit.pageCount,
                inkPresent = strokeSnapshot.isNotEmpty(),
                inkStrokeCount = strokeSnapshot.size,
                finalised = finalise,
                inkFlattened = pdfCommit.inkFlattened,
                formFieldsFlattened = pdfCommit.formFieldsFlattened,
                editingRestricted = pdfCommit.editingRestricted,
                markupRestricted = pdfCommit.markupRestricted,
                committedAtUtc = pdfCommit.committedAtUtc,
                tsa = tsa
            )

            // Persist the committed PDF/result before any network work. If Android kills
            // the process during TSA acquisition, the exact committed file can still be restored.
            val provisionalTsa = if (tsaRequested) {
                TsaAttestation.pending(pdfCommit.signedSha256)
            } else {
                TsaAttestation.notRequested()
            }
            var result = resultFor(provisionalTsa)
            var resultJson = DigitalSigningResultJson.resultJson(result)
            var tsaJson = DigitalSigningResultJson.tsaJson(result.tsa)
            commitResult = result
            committedFile = outputFile
            writeResultToSettings(settingsState, result, resultJson, tsaJson)
            withContext(Dispatchers.IO) {
                DigitalSigningFileSupport.writeResultSidecar(outputFile, resultJson)
                draftStore.markCommitted(result, outputFile)
            }

            if (tsaRequested) {
                busyMessage = "Obtaining trusted timestamp…"
                val tsa = withContext(Dispatchers.IO) {
                    DigitalSigningTsaClient.requestTimestamp(pdfCommit.signedSha256, tsaUrl, timeout)
                }
                result = resultFor(tsa)
                resultJson = DigitalSigningResultJson.resultJson(result)
                tsaJson = DigitalSigningResultJson.tsaJson(tsa)
                commitResult = result
                writeResultToSettings(settingsState, result, resultJson, tsaJson)
                withContext(Dispatchers.IO) {
                    DigitalSigningFileSupport.writeResultSidecar(outputFile, resultJson)
                    draftStore.markCommitted(result, outputFile)
                }
            }

            statusMessage = when (result.tsa.status) {
                "verified" -> "Committed and timestamp verified"
                "failed", "not_configured", "received_unverified" -> "Committed; timestamp needs attention"
                "pending" -> "Committed; timestamp pending"
                else -> "Committed"
            }
            busyMessage = null
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 8.dp)
    ) {
        SignatureHeroHeader(
            workingPdf = workingPdf,
            status = statusMessage,
            committed = commitResult != null
        )

        Spacer(Modifier.height(12.dp))

        if (workingPdf == null) {
            EmptyDocumentCard(
                onChoosePdf = { openPdfLauncher.launch(arrayOf("application/pdf")) },
                pushedExpected = launch.sourceUri != null,
                status = statusMessage
            )
        } else {
            DocumentWorkspace(
                renderedPage = renderedPage,
                currentPage = currentPage,
                pageCount = workingPdf!!.pageCount,
                pageStrokes = strokes.filter { it.pageIndex == currentPage },
                activeStrokePoints = activeStrokePoints,
                mode = mode,
                interactionLocked = busyMessage != null,
                scale = scale,
                panX = panX,
                panY = panY,
                penWidthPt = settingsState.getFloat("pen_width_pt").coerceIn(0.8f, 8f),
                onModeChange = { mode = it },
                onTransform = { zoomChange, panChange ->
                    scale = (scale * zoomChange).coerceIn(1f, 5f)
                    panX += panChange.x
                    panY += panChange.y
                },
                onStrokePreview = { points -> activeStrokePoints = points },
                onStrokeCommitted = { points ->
                    if (points.isNotEmpty()) {
                        strokes.add(
                            InkStroke(
                                id = UUID.randomUUID().toString(),
                                pageIndex = currentPage,
                                points = points,
                                widthPt = settingsState.getFloat("pen_width_pt").coerceIn(0.8f, 8f)
                            )
                        )
                        redoStack.clear()
                        activeStrokePoints = emptyList()
                        invalidateCommittedResult()
                        persistDraft()
                    }
                },
                onEraseAt = { point ->
                    val candidate = strokes
                        .filter { it.pageIndex == currentPage }
                        .minByOrNull { stroke -> stroke.points.minOfOrNull { it.distanceSquared(point) } ?: Float.MAX_VALUE }
                    if (candidate != null && (candidate.points.minOfOrNull { it.distanceSquared(point) } ?: Float.MAX_VALUE) < 0.0064f) {
                        strokes.remove(candidate)
                        redoStack.add(candidate)
                        invalidateCommittedResult()
                        persistDraft()
                    }
                },
                onPreviousPage = {
                    if (currentPage > 0) {
                        currentPage -= 1
                        persistDraft(preserveCommittedResult = true)
                    }
                },
                onNextPage = {
                    if (currentPage + 1 < workingPdf!!.pageCount) {
                        currentPage += 1
                        persistDraft(preserveCommittedResult = true)
                    }
                }
            )

            Spacer(Modifier.height(10.dp))

            WorkspaceToolbar(
                mode = mode,
                enabled = busyMessage == null,
                canUndo = strokes.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                onModeChange = { mode = it },
                onUndo = {
                    val last = strokes.lastOrNull()
                    if (last != null) {
                        strokes.remove(last)
                        redoStack.add(last)
                        invalidateCommittedResult()
                        persistDraft()
                    }
                },
                onRedo = {
                    val last = redoStack.lastOrNull()
                    if (last != null) {
                        redoStack.remove(last)
                        strokes.add(last)
                        invalidateCommittedResult()
                        persistDraft()
                    }
                },
                onClearPage = {
                    val removed = strokes.filter { it.pageIndex == currentPage }
                    strokes.removeAll(removed.toSet())
                    redoStack.addAll(removed)
                    invalidateCommittedResult()
                    persistDraft()
                }
            )

            Spacer(Modifier.height(12.dp))

            DocumentIdentityCard(
                workingPdf = workingPdf!!,
                strokeCount = strokes.size,
                onCopySourceHash = { copy(workingPdf!!.sourceSha256, "Source hash") },
                onReplacePdf = { openPdfLauncher.launch(arrayOf("application/pdf")) }
            )

            Spacer(Modifier.height(12.dp))

            CommitCard(
                settingsState = settingsState,
                odkOrigin = launch.sourceOrigin == PdfInputOrigin.Odk,
                inkPresent = strokes.isNotEmpty(),
                operationBusy = busyMessage != null,
                onCommit = ::commit
            )
        }

        AnimatedVisibility(visible = commitResult != null && committedFile != null) {
            val result = commitResult
            val file = committedFile
            if (result != null && file != null) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    CommittedResultCard(
                        result = result,
                        actionsEnabled = busyMessage == null,
                        onCopySignedHash = { copy(result.signedSha256, "Signed hash") },
                        onCopyTsaTime = { copy(result.tsa.timestampUtc.orEmpty(), "TSA time") },
                        onCopyResultJson = { copy(DigitalSigningResultJson.resultJson(result), "Result JSON") },
                        onShare = {
                            runCatching {
                                DigitalSigningFileSupport.sharePdf(
                                    context,
                                    file,
                                    DigitalSigningResultJson.resultJson(result)
                                )
                            }.onFailure { statusMessage = it.message ?: "Share unavailable" }
                        },
                        onSave = { savePdfLauncher.launch(file.name) },
                        onReturnToCaller = if (launch.launchedForResult && activity != null) {
                            {
                                val resultJson = DigitalSigningResultJson.resultJson(result)
                                val tsaJson = DigitalSigningResultJson.tsaJson(result.tsa)
                                val intent = DigitalSigningFileSupport.buildOdkResultIntent(
                                    context,
                                    file,
                                    resultJson,
                                    tsaJson,
                                    result.signedSha256
                                )
                                activity.setResult(Activity.RESULT_OK, intent)
                                activity.finish()
                            }
                        } else null
                    )
                }
            }
        }

        if (busyMessage != null) {
            Spacer(Modifier.height(12.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = busyMessage.orEmpty(),
                    modifier = Modifier.padding(16.dp),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun SignatureHeroHeader(workingPdf: WorkingPdf?, status: String, committed: Boolean) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        tonalElevation = 5.dp,
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = if (committed) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.size(50.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (committed) Icons.Rounded.CheckCircle else Icons.Rounded.Create,
                        contentDescription = null,
                        modifier = Modifier.size(27.dp)
                    )
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Digital Signing", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(
                    workingPdf?.displayName ?: "PDF ink + trusted timestamp",
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(status, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun EmptyDocumentCard(onChoosePdf: () -> Unit, pushedExpected: Boolean, status: String) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier.size(76.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Description, null, modifier = Modifier.size(38.dp))
                }
            }
            Spacer(Modifier.height(18.dp))
            Text(
                if (pushedExpected) "Opening supplied PDF" else "Choose a PDF",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                if (pushedExpected) status else "The original stays untouched. Your ink is committed into a new PDF.",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(22.dp))
            Button(onClick = onChoosePdf) {
                Icon(Icons.Rounded.Description, null)
                Spacer(Modifier.width(8.dp))
                Text("Choose PDF")
            }
        }
    }
}

@Composable
private fun DocumentWorkspace(
    renderedPage: RenderedPdfPage?,
    currentPage: Int,
    pageCount: Int,
    pageStrokes: List<InkStroke>,
    activeStrokePoints: List<InkPoint>,
    mode: DigitalSigningMode,
    interactionLocked: Boolean,
    scale: Float,
    panX: Float,
    panY: Float,
    penWidthPt: Float,
    onModeChange: (DigitalSigningMode) -> Unit,
    onTransform: (Float, Offset) -> Unit,
    onStrokePreview: (List<InkPoint>) -> Unit,
    onStrokeCommitted: (List<InkPoint>) -> Unit,
    onEraseAt: (InkPoint) -> Unit,
    onPreviousPage: () -> Unit,
    onNextPage: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onPreviousPage, enabled = currentPage > 0) {
                    Icon(Icons.Rounded.ArrowBack, "Previous page")
                }
                Text("Page ${currentPage + 1} of $pageCount", fontWeight = FontWeight.SemiBold)
                IconButton(onClick = onNextPage, enabled = currentPage + 1 < pageCount) {
                    Icon(Icons.Rounded.ArrowForward, "Next page")
                }
            }
            HorizontalDivider()
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(560.dp)
                    .background(Color(0xFF16191D)),
                contentAlignment = Alignment.Center
            ) {
                val page = renderedPage
                if (page == null) {
                    Text("Rendering page…", color = Color.White.copy(alpha = 0.8f))
                } else {
                    val ratio = page.bitmap.width.toFloat() / page.bitmap.height.toFloat()
                    val effectiveMode = if (interactionLocked) DigitalSigningMode.Navigate else mode
                    val pageModifier = Modifier
                        .fillMaxWidth(0.94f)
                        .aspectRatio(ratio)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = panX
                            translationY = panY
                        }
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color.White)
                        .then(
                            when (effectiveMode) {
                                DigitalSigningMode.Navigate -> Modifier.pointerInput(scale) {
                                    detectTransformGestures { _, pan, zoom, _ -> onTransform(zoom, pan) }
                                }
                                DigitalSigningMode.Ink -> Modifier.pointerInput(currentPage, penWidthPt) {
                                    var points = mutableListOf<InkPoint>()
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            points = mutableListOf(offset.normalised(size.width.toFloat(), size.height.toFloat()))
                                            onStrokePreview(points)
                                        },
                                        onDragEnd = {
                                            onStrokeCommitted(points)
                                            points = mutableListOf()
                                        },
                                        onDragCancel = {
                                            onStrokePreview(emptyList())
                                            points = mutableListOf()
                                        },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            points.add(change.position.normalised(size.width.toFloat(), size.height.toFloat()))
                                            onStrokePreview(points.toList())
                                        }
                                    )
                                }
                                DigitalSigningMode.Erase -> Modifier.pointerInput(currentPage) {
                                    detectDragGestures(
                                        onDragStart = { offset -> onEraseAt(offset.normalised(size.width.toFloat(), size.height.toFloat())) },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            onEraseAt(change.position.normalised(size.width.toFloat(), size.height.toFloat()))
                                        }
                                    )
                                }
                            }
                        )

                    Box(modifier = pageModifier) {
                        Image(
                            bitmap = page.bitmap.asImageBitmap(),
                            contentDescription = "PDF page ${currentPage + 1}",
                            modifier = Modifier.fillMaxSize()
                        )
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            pageStrokes.forEach { stroke -> drawStroke(stroke) }
                            if (activeStrokePoints.isNotEmpty()) {
                                drawStroke(
                                    InkStroke(
                                        id = "preview",
                                        pageIndex = currentPage,
                                        points = activeStrokePoints,
                                        widthPt = penWidthPt
                                    )
                                )
                            }
                        }
                    }
                }
            }
            Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 9.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (interactionLocked) {
                            "Committing · ink controls temporarily locked"
                        } else when (mode) {
                            DigitalSigningMode.Navigate -> "Navigate · drag or pinch to inspect"
                            DigitalSigningMode.Ink -> "Ink · draw on the page"
                            DigitalSigningMode.Erase -> "Erase · scrub over a stroke"
                        },
                        style = MaterialTheme.typography.labelMedium
                    )
                    if (scale > 1.01f) {
                        Text("${(scale * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceToolbar(
    mode: DigitalSigningMode,
    enabled: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    onModeChange: (DigitalSigningMode) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClearPage: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 2.dp
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton("Move", Icons.Rounded.TouchApp, mode == DigitalSigningMode.Navigate, enabled) { onModeChange(DigitalSigningMode.Navigate) }
            ToolButton("Ink", Icons.Rounded.Create, mode == DigitalSigningMode.Ink, enabled) { onModeChange(DigitalSigningMode.Ink) }
            ToolButton("Erase", Icons.Rounded.Delete, mode == DigitalSigningMode.Erase, enabled) { onModeChange(DigitalSigningMode.Erase) }
            IconButton(onClick = onUndo, enabled = enabled && canUndo) { Icon(Icons.Rounded.Undo, "Undo") }
            IconButton(onClick = onRedo, enabled = enabled && canRedo) { Icon(Icons.Rounded.Redo, "Redo") }
            IconButton(onClick = onClearPage, enabled = enabled && canUndo) { Icon(Icons.Rounded.Close, "Clear page ink") }
        }
    }
}

@Composable
private fun ToolButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, label, modifier = Modifier.size(20.dp))
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun DocumentIdentityCard(
    workingPdf: WorkingPdf,
    strokeCount: Int,
    onCopySourceHash: () -> Unit,
    onReplacePdf: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        tonalElevation = 1.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Description, null)
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(workingPdf.displayName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${workingPdf.pageCount} pages · ${workingPdf.sourceOrigin.id} · $strokeCount ink strokes", style = MaterialTheme.typography.labelMedium)
                }
                TextButton(onClick = onReplacePdf) { Text("Replace") }
            }
            Spacer(Modifier.height(10.dp))
            HashRow("Source SHA-256", workingPdf.sourceSha256, onCopySourceHash)
        }
    }
}

@Composable
private fun CommitCard(
    settingsState: SettingsState,
    odkOrigin: Boolean,
    inkPresent: Boolean,
    operationBusy: Boolean,
    onCommit: () -> Unit
) {
    val finalise = if (odkOrigin) true else settingsState.getBoolean("finalise_pdf")
    val tsa = settingsState.getBoolean("request_tsa")
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text("Commit", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Create a new PDF. The source document is never overwritten.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(14.dp))
            SettingSwitchRow(
                title = "Finalise PDF",
                subtitle = if (odkOrigin) "Required for ODK launches" else "Flatten ink and restrict ordinary editing/markup",
                checked = finalise,
                enabled = !odkOrigin && !operationBusy,
                onCheckedChange = { settingsState.setBoolean("finalise_pdf", it) }
            )
            SettingSwitchRow(
                title = "Trusted timestamp",
                subtitle = "RFC 3161 timestamp over the exact committed PDF hash",
                checked = tsa,
                enabled = !operationBusy,
                onCheckedChange = { settingsState.setBoolean("request_tsa", it) }
            )
            if (tsa && settingsState.getString("tsa_url").isBlank()) {
                Text(
                    "No TSA endpoint is configured. Commit will still succeed and report timestamp status as not configured.",
                    modifier = Modifier.padding(top = 8.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onCommit,
                enabled = inkPresent && !operationBusy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                Icon(if (finalise) Icons.Rounded.Lock else Icons.Rounded.CheckCircle, null)
                Spacer(Modifier.width(9.dp))
                Text(if (finalise) "Commit finalised PDF" else "Commit signed PDF", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.labelMedium)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

@Composable
private fun CommittedResultCard(
    result: DigitalSigningCommittedResult,
    actionsEnabled: Boolean,
    onCopySignedHash: () -> Unit,
    onCopyTsaTime: () -> Unit,
    onCopyResultJson: () -> Unit,
    onShare: () -> Unit,
    onSave: () -> Unit,
    onReturnToCaller: (() -> Unit)?
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(44.dp)) {
                    Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.CheckCircle, null) }
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Committed", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(result.signedFilename, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Spacer(Modifier.height(14.dp))
            HashRow("Signed SHA-256", result.signedSha256, onCopySignedHash)
            Spacer(Modifier.height(12.dp))
            ResultBadgeRow(result)
            Spacer(Modifier.height(12.dp))
            TsaResultBlock(result.tsa, onCopyTsaTime)
            TextButton(onClick = onCopyResultJson, modifier = Modifier.align(Alignment.End)) {
                Text("Copy result JSON")
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedButton(onClick = onShare, enabled = actionsEnabled, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Share, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Share")
                }
                OutlinedButton(onClick = onSave, enabled = actionsEnabled, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Rounded.Description, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Save")
                }
            }
            if (onReturnToCaller != null) {
                Spacer(Modifier.height(9.dp))
                Button(onClick = onReturnToCaller, enabled = actionsEnabled, modifier = Modifier.fillMaxWidth()) {
                    Text("Return signed PDF + JSON")
                }
            }
        }
    }
}

@Composable
private fun ResultBadgeRow(result: DigitalSigningCommittedResult) {
    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        StatusPill(if (result.finalised) "Finalised" else "Standard")
        StatusPill("${result.pageCount} pages")
        StatusPill("${result.inkStrokeCount} strokes")
    }
}

@Composable
private fun StatusPill(text: String) {
    Surface(shape = RoundedCornerShape(100.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun TsaResultBlock(tsa: TsaAttestation, onCopyTsaTime: () -> Unit) {
    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text("Trusted timestamp", fontWeight = FontWeight.Bold)
            Text(
                when (tsa.status) {
                    "verified" -> "Verified · ${tsa.timestampUtc.orEmpty()}"
                    "pending" -> "Committed · timestamp request pending"
                    "not_requested" -> "Not requested"
                    "not_configured" -> "Requested, but no TSA endpoint is configured"
                    "received_unverified" -> "Received, but signer verification was incomplete"
                    else -> "${tsa.status}${tsa.error?.let { ": $it" }.orEmpty()}"
                },
                modifier = Modifier
                    .padding(top = 4.dp)
                    .then(if (!tsa.timestampUtc.isNullOrBlank()) Modifier.clickable(onClick = onCopyTsaTime) else Modifier),
                style = MaterialTheme.typography.bodyMedium
            )
            if (!tsa.authority.isNullOrBlank()) {
                Text(tsa.authority, modifier = Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun HashRow(label: String, hash: String, onCopy: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onCopy),
        shape = RoundedCornerShape(15.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Text(hash, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("Tap to copy", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawStroke(stroke: InkStroke) {
    if (stroke.points.isEmpty()) return
    val path = Path()
    val first = stroke.points.first()
    path.moveTo(first.x * size.width, first.y * size.height)
    stroke.points.drop(1).forEach { point -> path.lineTo(point.x * size.width, point.y * size.height) }
    val previewWidth = (stroke.widthPt / 595f * size.width).coerceAtLeast(1.2f)
    drawPath(
        path = path,
        color = Color(stroke.argb),
        style = Stroke(width = previewWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

private fun Offset.normalised(width: Float, height: Float): InkPoint = InkPoint(
    x = if (width <= 0f) 0f else (x / width).coerceIn(0f, 1f),
    y = if (height <= 0f) 0f else (y / height).coerceIn(0f, 1f)
)

private fun InkPoint.distanceSquared(other: InkPoint): Float {
    val dx = x - other.x
    val dy = y - other.y
    return dx * dx + dy * dy
}

private fun persistReadPermission(context: Context, uri: Uri) {
    runCatching {
        context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
}

private fun writeResultToSettings(
    settingsState: SettingsState,
    result: DigitalSigningCommittedResult,
    resultJson: String,
    tsaJson: String
) {
    settingsState.setString("status", "committed")
    settingsState.setString("source_origin", result.sourceOrigin.id)
    settingsState.setString("source_filename", result.sourceFilename)
    settingsState.setString("source_sha256", result.sourceSha256)
    settingsState.setString("signed_filename", result.signedFilename)
    settingsState.setString("signed_pdf_uri", result.signedPdfUri)
    settingsState.setString("signed_sha256", result.signedSha256)
    settingsState.setInt("page_count", result.pageCount)
    settingsState.setBoolean("ink_present", result.inkPresent)
    settingsState.setBoolean("finalised", result.finalised)
    settingsState.setString("committed_at", result.committedAtUtc)
    settingsState.setString("tsa_status", result.tsa.status)
    settingsState.setString("tsa_timestamp_utc", result.tsa.timestampUtc.orEmpty())
    settingsState.setString("tsa_json", tsaJson)
    settingsState.setString("result_json", resultJson)
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is android.content.ContextWrapper -> baseContext.findActivity()
    else -> null
}
