# MethodMesh Digital Signing module v1.00

Canonical capability ID: `pdf_ink_signing`

## Scope

A deliberately small first release:

1. Acquire a PDF from an ODK/Android caller or the Android document picker.
2. View the PDF page-by-page with pan/zoom.
3. Switch to Ink mode and draw handwritten ink directly over the page surface.
4. Preserve an interrupted draft locally.
5. Commit to a **new** PDF; never overwrite the source.
6. Optionally finalise the PDF by flattening the new ink and AcroForm fields where possible, then apply PDF permission restrictions against ordinary editing/markup.
7. Calculate SHA-256 over the exact committed PDF.
8. Optionally request an RFC 3161 timestamp over that SHA-256 imprint.
9. Save/share directly, or return the signed PDF plus structured JSON to an ODK/external caller. Direct Share attaches both the PDF and an attestation JSON sidecar.

This is an ink-based electronic signing workflow. It does **not** claim that the handwritten mark identifies the signer cryptographically, and it is not a PAdES/certificate-backed PDF signature. The TSA attests the existence of the exact committed file hash at the TSA time.

## UX

The document is the primary surface. Navigation/inking controls sit immediately below it; source provenance and commit settings come below the tool. Live ink remains on the same screen. Commit changes the working result into a durable PDF and reveals Save/Share/Return actions.

Tap the source or signed SHA-256 card to copy it. Tap a TSA timestamp to copy it.

### ODK behaviour

When a PDF URI is pushed by ODK/caller via `input_pdf_uri`, `Intent.EXTRA_STREAM`, `Intent.data`, or `ClipData`, the file opens immediately; the picker is skipped.

ODK launches force `Finalise PDF = true`. The return intent contains:

- `data` + `ClipData`: content URI of the committed PDF
- `signed_pdf_uri`
- `result_json`
- `tsa_json`
- `signed_sha256`
- `status=committed`

`result_json.tsa` is always present. If timestamping was not requested it returns `requested=false,status=not_requested`; if requested while offline/unconfigured, the signed PDF remains committed and the TSA status records the failure/non-configuration.

## Dependencies

Add the dependencies shown in `_integration/app-build.gradle.kts.snippet` (Material icons + PDFBox-Android). The current Maven Central release used here is `com.tom-roush:pdfbox-android:2.0.27.0`; it already brings the Bouncy Castle packages needed for RFC 3161 processing.

## Host integration

1. Copy this folder to the app's existing modules package, preserving package `com.example.xlsformlab.modules.digitalsigning` unless the host namespace has already been migrated.
2. Add `DigitalSigningCapability()` to the capability/method registry.
3. Add the PDFBox dependency.
4. Add the FileProvider and paths XML snippets so committed PDFs can be shared/returned as content URIs.
5. Keep the host's normal v1.05 launch-origin completion logic. This module exposes a ready-to-use return intent helper but does not hard-wire shell navigation.
6. The module does not require storage permission; it uses Storage Access Framework URIs and app-private working files.
7. INTERNET permission is needed only for TSA requests.

## Finalisation semantics

`Finalise PDF`:

- writes new ink as PDF page content (not editable ink annotations);
- attempts to flatten AcroForm fields;
- applies PDF permissions disallowing modify/annotation/form/assembly operations in compliant viewers;
- leaves viewing, accessibility extraction, normal extraction and printing enabled;
- calculates the SHA-256 only after the final output is saved.

PDF permission flags are not absolute DRM. Integrity should be assessed using the returned SHA-256 and, where available, TSA attestation.

## Rotation

Committed ink maps normalized viewer coordinates through the PDF page rotation value (0/90/180/270) before writing vector paths, so common rotated PDFs remain aligned.

## Offline behaviour

PDF picking, viewing, inking, draft persistence, commit, hashing, save and share are offline. The committed result JSON is retained as an attestation sidecar next to the app-private committed PDF and is included in Share. TSA is the only network operation. TSA failure never discards or rolls back a successfully committed PDF.
