package com.example.xlsformlab.modules.digitalsigning

import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

object DigitalSigningTime {
    private val fileFormatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS").withZone(ZoneOffset.UTC)

    fun nowUtc(): String = Instant.now().toString()

    fun fileStamp(): String = fileFormatter.format(Instant.now())
}
