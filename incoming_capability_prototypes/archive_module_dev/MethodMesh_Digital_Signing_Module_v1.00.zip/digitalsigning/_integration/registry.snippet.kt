import com.example.xlsformlab.modules.digitalsigning.DigitalSigningCapability

// Add to the existing registry list; do not replace the registry.
DigitalSigningCapability()
