package com.example.xlsformlab.modules.digitalsigning

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object DigitalSigningFileSupport {
    fun shareableUri(context: Context, file: File): Uri {
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
    }

    fun writeResultSidecar(file: File, resultJson: String): File {
        val sidecar = File(file.parentFile, file.nameWithoutExtension + "_attestation.json")
        sidecar.writeText(resultJson)
        return sidecar
    }

    fun sharePdf(context: Context, file: File, resultJson: String) {
        val pdfUri = shareableUri(context, file)
        val sidecar = writeResultSidecar(file, resultJson)
        val jsonUri = shareableUri(context, sidecar)
        val streams = arrayListOf(pdfUri, jsonUri)
        val clip = ClipData.newUri(context.contentResolver, file.name, pdfUri).apply {
            addItem(ClipData.Item(jsonUri))
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "application/octet-stream"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, streams)
            putExtra(Intent.EXTRA_TEXT, "Signed PDF plus MethodMesh signing/TSA attestation JSON")
            clipData = clip
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share signed PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun copyFileToUri(context: Context, file: File, destination: Uri) {
        context.contentResolver.openOutputStream(destination, "w")?.use { output ->
            file.inputStream().use { input -> input.copyTo(output) }
        } ?: error("Could not open the selected save location")
    }

    fun buildOdkResultIntent(
        context: Context,
        file: File,
        resultJson: String,
        tsaJson: String,
        signedSha256: String
    ): Intent {
        val uri = shareableUri(context, file)
        return Intent().apply {
            data = uri
            type = "application/pdf"
            clipData = ClipData.newUri(context.contentResolver, file.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra(DigitalSigningLaunchContract.RESULT_SIGNED_PDF_URI, uri.toString())
            putExtra(DigitalSigningLaunchContract.RESULT_JSON, resultJson)
            putExtra(DigitalSigningLaunchContract.RESULT_TSA_JSON, tsaJson)
            putExtra(DigitalSigningLaunchContract.RESULT_SIGNED_SHA256, signedSha256)
            putExtra(DigitalSigningLaunchContract.RESULT_STATUS, "committed")
        }
    }
}
