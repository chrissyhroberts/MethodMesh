package com.example.xlsformlab.modules.digitalsigning

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build

/**
 * Runtime input contract for dashboard/direct/preset/protocol/ODK launches.
 * Inputs are execution data, not persistent admin settings.
 */
object DigitalSigningLaunchContract {
    const val CAPABILITY_ID = "pdf_ink_signing"

    const val EXTRA_INPUT_PDF_URI = "input_pdf_uri"
    const val EXTRA_SOURCE_ORIGIN = "source_origin"
    const val EXTRA_EXECUTION_ID = "execution_id"
    const val EXTRA_REQUEST_ID = "request_id"
    const val EXTRA_RETURN_MODE = "return_mode"

    const val RESULT_SIGNED_PDF_URI = "signed_pdf_uri"
    const val RESULT_JSON = "result_json"
    const val RESULT_TSA_JSON = "tsa_json"
    const val RESULT_SIGNED_SHA256 = "signed_sha256"
    const val RESULT_STATUS = "status"

    data class ResolvedLaunch(
        val sourceUri: Uri?,
        val sourceOrigin: PdfInputOrigin,
        val executionId: String,
        val launchedForResult: Boolean
    )

    fun resolve(activity: Activity): ResolvedLaunch {
        val intent = activity.intent
        val explicitUri = intent.getStringExtra(EXTRA_INPUT_PDF_URI)?.takeIf { it.isNotBlank() }?.let(Uri::parse)
            ?: intent.getStringExtra("pdf_uri")?.takeIf { it.isNotBlank() }?.let(Uri::parse)
        val streamUri = getParcelableUri(intent, Intent.EXTRA_STREAM)
        val clipUri = intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        val dataUri = intent.data

        val sourceUri = explicitUri ?: streamUri ?: clipUri ?: dataUri
        val originText = intent.getStringExtra(EXTRA_SOURCE_ORIGIN)?.lowercase()
        val origin = when {
            originText == "odk" -> PdfInputOrigin.Odk
            originText == "file_picker" -> PdfInputOrigin.FilePicker
            sourceUri != null && looksLikeOdkLaunch(activity, intent) -> PdfInputOrigin.Odk
            sourceUri != null -> PdfInputOrigin.AndroidIntent
            else -> PdfInputOrigin.Unknown
        }

        val explicitExecutionId = listOf(
            intent.getStringExtra(EXTRA_EXECUTION_ID),
            intent.getStringExtra(EXTRA_REQUEST_ID),
            intent.getStringExtra("session_id"),
            intent.getStringExtra("instance_id")
        ).firstOrNull { !it.isNullOrBlank() }
        val executionId = explicitExecutionId
            ?: sourceUri?.let { "source_${Integer.toHexString(it.toString().hashCode())}" }
            ?: "direct"

        return ResolvedLaunch(
            sourceUri = sourceUri,
            sourceOrigin = origin,
            executionId = executionId.sanitiseId(),
            launchedForResult = looksLikeOdkLaunch(activity, intent) || activity.callingActivity != null
        )
    }

    private fun looksLikeOdkLaunch(activity: Activity, intent: Intent): Boolean {
        val packageName = intent.`package`.orEmpty().lowercase()
        val referrer = intent.getStringExtra(Intent.EXTRA_REFERRER_NAME).orEmpty().lowercase()
        val caller = activity.callingPackage.orEmpty().lowercase()
        val activityReferrer = activity.referrer?.host.orEmpty().lowercase()
        val explicitOrigin = intent.getStringExtra(EXTRA_SOURCE_ORIGIN).orEmpty().lowercase()
        return explicitOrigin == "odk" ||
            packageName.contains("odk") ||
            referrer.contains("odk") ||
            caller.contains("odk") ||
            activityReferrer.contains("odk")
    }

    @Suppress("DEPRECATION")
    private fun getParcelableUri(intent: Intent, key: String): Uri? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(key, Uri::class.java)
        } else {
            intent.getParcelableExtra(key)
        }
    }

    private fun String.sanitiseId(): String =
        replace(Regex("[^A-Za-z0-9._-]"), "_").take(96).ifBlank { "direct" }
}
