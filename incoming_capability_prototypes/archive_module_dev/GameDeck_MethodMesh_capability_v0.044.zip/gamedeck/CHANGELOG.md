# GameDeck changelog

## v0.044

- Added generic MethodMesh immersive-host integration through `CapabilityScreenSpec.hostPresentation`; GameDeck requests `CapabilityHostPresentation.Immersive` rather than relying on any capability-specific runtime branch.
- Native GameDeck presentation no longer nests the games inside `CapabilityScreenScaffold`; external/ODK execution retains the normal generic scaffold and completion contract.
- Added a MethodMesh exit control to the GameDeck launcher so immersive mode remains navigable without host chrome.
- Fixed Snakes & Ladders result leakage: legal destination, destination highlight and snake/ladder instruction remain hidden until the die animation has stopped and the settled die has been shown briefly.
- Added a visible Connect Four pickup pile. Dragging must begin from the active player's supply; tapping a board column remains the accessible fallback.
- Added an asset-free retro sound palette using Android `ToneGenerator` for pickup/drop, dice roll, moves, CPU actions and wins.
- Added the `sound` capability setting, enabled by default.

## v0.043

- Reworked the current games toward chunkier, tactile full-screen game surfaces.
- Added stronger persistent player identity and improved game-end presentation.
- Added manual Snakes & Ladders movement and visible Mancala CPU action staging.
