# GameDeck prototype → MethodMesh capability alignment report

The previous `GameDeck_GameLab_prototype_v0.02.zip` was a standalone Kotlin prototype, not a discoverable MethodMesh capability.

## Runtime-blocking mismatches

1. **Wrong delivery path**  
   Previous: `gamedeck_lab/src/main/kotlin/...`  
   Required: `app/src/main/java/com/example/methodmesh/modules/gamedeck/`

2. **No `*Module.kt` discovery object**  
   MethodMesh generates its module index from `*Module.kt` files beneath the modules folder. The previous prototype therefore had nothing for the runtime to discover.

3. **No `MethodMeshModule` implementation**  
   There was no module ID, display name, method list, screen list or declared settings.

4. **No `As100Method`**  
   The prototype had game-domain contracts but no MethodMesh method identity, descriptor, outputs, contract or `ExecutionResult` integration.

5. **No `CapabilityScreenSpec`**  
   There was no native MethodMesh screen or `CapabilityScreenScaffold` lifecycle.

6. **Manual bootstrap instruction contradicted the guide**  
   The README asked for `ChanceEngine.install(MethodMeshChanceProvider)` at startup. The writing guide explicitly says capability discovery must not use one-off central/manual registration.

7. **Wrong dependency boundary**  
   The prototype added a separate Chance adapter abstraction. The corrected capability reuses the existing Chance method object and does not copy `DiceSimulatorEngine`.

8. **No persistent-dashboard lifecycle**  
   GameDeck is a dashboard-style capability. The previous prototype had no distinction between a retained live `ExecutionResult` and the result passed to the scaffold. The corrected screen follows `keepLiveDashboard` / `scaffoldResult = null` and explicit Finish/Use snapshot semantics.

9. **No native preset semantics**  
   The corrected screen uses `context.isNativePresetRun` and `settingShouldBeShown(...)`.

10. **No external/ODK completion semantics**  
    The corrected screen treats genuine auto-submit calls as single-shot while excluding `intent_test` from forced auto-return.

11. **No module-owned documentation/XLSForm**  
    The corrected package contains nested `docs/README_GameDeck.md` and `docs/example_odk_GameDeck.xlsx`.

## What remains useful from the old prototype

The pure state-machine work remains conceptually useful: deterministic game transitions, headless simulation and GameLab agents should be brought back later as capability-owned helper files or a genuinely shared framework module. The problem was packaging/lifecycle integration, not the core idea.
