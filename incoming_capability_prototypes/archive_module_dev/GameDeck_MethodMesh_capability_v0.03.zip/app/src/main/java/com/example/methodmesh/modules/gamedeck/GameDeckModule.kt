package com.example.methodmesh.modules.gamedeck

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

/**
 * GameDeck persistent dashboard capability.
 *
 * This object is intentionally named *Module.kt and lives beneath modules/gamedeck
 * so the generated MethodMesh module index discovers it automatically.
 */
object GameDeckModule : MethodMeshModule {
    override val moduleId = "gamedeck"
    override val displayName = "GameDeck"
    override val summary = "Play lightweight games using shared MethodMesh services and retain a reproducible game snapshot."

    override fun as100Methods() = listOf(As100GameDeckMethod)

    override fun capabilityScreens() = listOf(GameDeckCapabilityScreen)

    override fun rilBindings() = listOf(
        RilBinding("open gamedeck", As100GameDeckMethod.ID, "Open the GameDeck dashboard"),
        RilBinding("play game", As100GameDeckMethod.ID, "Open a lightweight GameDeck game")
    )

    override fun capabilitySettings() = mapOf(
        As100GameDeckMethod.ID to listOf(
            MethodSetting.ChoiceSetting(
                "game",
                "Game",
                defaultValue = "connect_four",
                choices = listOf("connect_four", "snakes_and_ladders")
            ),
            MethodSetting.ChoiceSetting(
                "rng_mode",
                "Random source",
                defaultValue = "secure_random",
                choices = listOf("secure_random", "fixed_seed")
            ),
            MethodSetting.TextSetting("seed", "Fixed seed", defaultValue = "")
        )
    )
}
