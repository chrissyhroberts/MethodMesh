package com.example.methodmesh.modules.gamedeck

import com.example.methodmesh.modules.chance.As100DiceSimulationMethod
import com.example.methodmesh.modules.chance.DiceSimulationFields
import org.json.JSONArray
import org.json.JSONObject

/** Pure game-state functions owned by GameDeck. No Compose or MethodMesh orchestration here. */
object GameDeckEngine {
    const val CONNECT_FOUR = "connect_four"
    const val SNAKES_AND_LADDERS = "snakes_and_ladders"

    fun newStateJson(game: String): String = when (game) {
        SNAKES_AND_LADDERS -> snakesState(intArrayOf(1, 1), 0, "", 0)
        else -> connectFourState(List(6) { List(7) { 0 } }, 1, "", 0)
    }

    fun connectFourDrop(stateJson: String, column: Int): String {
        val state = JSONObject(stateJson)
        val board = decodeBoard(state.getJSONArray("board"))
        val player = state.optInt("turn", 1)
        if (state.optString("winner").isNotBlank()) return stateJson
        if (column !in 0..6) return stateJson
        val row = (5 downTo 0).firstOrNull { board[it][column] == 0 } ?: return stateJson
        board[row][column] = player
        val winner = if (connectFourWinner(board, row, column, player)) player.toString() else ""
        val next = if (winner.isBlank()) if (player == 1) 2 else 1 else player
        return connectFourState(board.map { it.toList() }, next, winner, state.optInt("moves") + 1)
    }

    fun snakesRoll(stateJson: String, rngMode: String, seed: String): Pair<String, Int> {
        val state = JSONObject(stateJson)
        if (state.optString("winner").isNotBlank()) return stateJson to 0
        val turn = state.optInt("turn", 0).coerceIn(0, 1)
        val move = state.optInt("moves", 0)
        val effectiveSeed = if (rngMode == "fixed_seed") {
            "${seed.ifBlank { "gamedeck-snakes" }}|move:$move|player:$turn"
        } else ""

        // Reuse the existing Chance capability through its public Method object.
        // GameDeck deliberately does not copy or redeclare DiceSimulatorEngine.
        val dice = As100DiceSimulationMethod.generate(
            mapOf(
                "expression" to "d6",
                "roll_count" to "1",
                "player_count" to "1",
                "history_output" to "false",
                "rng_mode" to rngMode,
                "seed" to effectiveSeed,
                "animation_mode" to "off"
            )
        )
        val roll = dice[DiceSimulationFields.TOTAL]?.toIntOrNull()?.coerceIn(1, 6) ?: 1
        val positions = state.getJSONArray("positions")
        val p = intArrayOf(positions.optInt(0, 1), positions.optInt(1, 1))
        val candidate = p[turn] + roll
        if (candidate <= 100) p[turn] = snakesJump(candidate)
        val winner = if (p[turn] == 100) (turn + 1).toString() else ""
        val nextTurn = if (winner.isBlank()) 1 - turn else turn
        return snakesState(p, nextTurn, winner, move + 1) to roll
    }

    fun stateSummary(stateJson: String): GameStateSummary {
        val state = JSONObject(stateJson)
        return GameStateSummary(
            game = state.optString("game"),
            turn = when (state.optString("game")) {
                SNAKES_AND_LADDERS -> "Player ${state.optInt("turn", 0) + 1}"
                else -> "Player ${state.optInt("turn", 1)}"
            },
            winner = state.optString("winner").takeIf { it.isNotBlank() }?.let { "Player $it" }.orEmpty(),
            moves = state.optInt("moves", 0)
        )
    }

    private fun connectFourState(board: List<List<Int>>, turn: Int, winner: String, moves: Int): String {
        val rows = JSONArray()
        board.forEach { row -> rows.put(JSONArray(row)) }
        return JSONObject()
            .put("game", CONNECT_FOUR)
            .put("board", rows)
            .put("turn", turn)
            .put("winner", winner)
            .put("moves", moves)
            .toString()
    }

    private fun snakesState(positions: IntArray, turn: Int, winner: String, moves: Int): String = JSONObject()
        .put("game", SNAKES_AND_LADDERS)
        .put("positions", JSONArray().put(positions[0]).put(positions[1]))
        .put("turn", turn)
        .put("winner", winner)
        .put("moves", moves)
        .toString()

    private fun decodeBoard(json: JSONArray): Array<IntArray> = Array(6) { r ->
        IntArray(7) { c -> json.getJSONArray(r).optInt(c, 0) }
    }

    private fun connectFourWinner(board: Array<IntArray>, row: Int, col: Int, player: Int): Boolean {
        val directions = arrayOf(1 to 0, 0 to 1, 1 to 1, 1 to -1)
        return directions.any { (dr, dc) ->
            1 + count(board, row, col, dr, dc, player) + count(board, row, col, -dr, -dc, player) >= 4
        }
    }

    private fun count(board: Array<IntArray>, row: Int, col: Int, dr: Int, dc: Int, player: Int): Int {
        var r = row + dr
        var c = col + dc
        var n = 0
        while (r in 0..5 && c in 0..6 && board[r][c] == player) {
            n++; r += dr; c += dc
        }
        return n
    }

    private fun snakesJump(position: Int): Int = when (position) {
        4 -> 14; 9 -> 31; 20 -> 38; 28 -> 84; 40 -> 59; 51 -> 67; 63 -> 81; 71 -> 91
        17 -> 7; 54 -> 34; 62 -> 19; 64 -> 60; 87 -> 24; 93 -> 73; 95 -> 75; 99 -> 78
        else -> position
    }
}

data class GameStateSummary(
    val game: String,
    val turn: String,
    val winner: String,
    val moves: Int
)
