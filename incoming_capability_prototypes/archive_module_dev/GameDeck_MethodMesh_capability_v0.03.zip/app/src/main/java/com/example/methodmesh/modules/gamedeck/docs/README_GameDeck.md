# GameDeck capability

**Module:** `gamedeck`  
**Method ID:** `gamedeck.snapshot`  
**Status:** Development

## What it does

GameDeck is a persistent MethodMesh dashboard for lightweight games. This initial vertical slice contains Connect Four and Snakes & Ladders. The latter reuses the existing MethodMesh Chance capability for d6 outcomes rather than declaring another random-number engine.

This package is deliberately a normal MethodMesh capability module. The canonical delivery folder is:

```text
app/src/main/java/com/example/methodmesh/modules/gamedeck/
```

The generated MethodMesh module index should discover `GameDeckModule.kt` automatically. No central registration or application-startup installation is required.

## Native workflow

Open **GameDeck** from the capability browser/dashboard. Select a game and play in place. Game state is kept in `rememberSaveable` state so ordinary orientation changes retain the current game.

GameDeck follows the persistent dashboard pattern:

- gameplay updates the live dashboard state;
- the latest `ExecutionResult` snapshot is retained by the capability;
- native dashboard and native preset runs pass `capturedResult = null` to the shared scaffold;
- **Use this snapshot** / **Finish** explicitly confirms the current game snapshot.

A move does not create a graph/output record.

## Native preset workflow

A preset may fix the game and RNG mode/seed. Fixed settings are hidden by `settingShouldBeShown(...)`. The game remains on screen while played. Press **Finish** to return the latest snapshot.

## ODK / external workflow

External invocation is single-shot: GameDeck returns a structured initial/current snapshot without requiring the user to press Finish. `intent_test` is excluded from genuine external auto-submit so the capability browser/test flow can remain interactive.

GameDeck is currently primarily a native dashboard; ODK support is included to satisfy the MethodMesh capability contract rather than as the main use case.

## Inputs

| Setting | Meaning | Default |
|---|---|---|
| `game` | `connect_four` or `snakes_and_ladders` | `connect_four` |
| `rng_mode` | `secure_random` or `fixed_seed` | `secure_random` |
| `seed` | Seed used for reproducible stochastic games | empty |

## Outputs

| Field | Meaning |
|---|---|
| `gamedeck_status` | `succeeded`/failure state |
| `gamedeck_result` | Compact user-facing result |
| `gamedeck_game` | Active game ID |
| `gamedeck_state_json` | Reproducible game-state snapshot |
| `gamedeck_turn` | Current player |
| `gamedeck_winner` | Winner if complete |
| `gamedeck_move_count` | Number of moves/turns |
| `gamedeck_rng_mode` | Randomness mode |
| `gamedeck_seed` | Fixed seed if supplied |
| `gamedeck_generated_time_iso` | Snapshot time |
| `gamedeck_audit_json` | Full audit snapshot |
| `gamedeck_error` | Error text |

The main native/share result is `gamedeck_result`; `gamedeck_audit_json` is audit metadata rather than the primary result.

## Chance dependency

GameDeck does **not** contain or redeclare `DiceSimulatorEngine`.

The stochastic proving game calls the existing Chance capability through `As100DiceSimulationMethod`. This preserves one source of truth for secure/fixed-seed dice behaviour and avoids the previous Kotlin redeclaration issue.

No `ChanceEngine.install(...)` bootstrap call is required or desired.

## Online/offline behaviour

Fully offline. No network service or Android permission is required by the initial games.

## Known limitations

- Initial UI is intentionally minimal and exists to prove MethodMesh discovery/lifecycle contracts.
- Only Connect Four and Snakes & Ladders are present.
- Persistent player profiles, records, replay logs, GameLab simulation UI, CPU play and P2P are not yet exposed by this capability.
- ODK currently returns a snapshot; it is not an interactive game transport.
- The Chance dependency assumes the existing `chance` module is present in MethodMesh.

## Validation checklist

Before promoting beyond Development:

1. Copy this complete `gamedeck/` folder under `app/src/main/java/com/example/methodmesh/modules/`.
2. Confirm GameDeck appears automatically without editing a central registry.
3. Run native dashboard and verify it remains visible after moves.
4. Save a preset and verify fixed settings are hidden.
5. Run the preset and verify **Finish** returns the current snapshot.
6. Run `intent_test` and verify it remains interactive.
7. Exercise a genuine external call and verify automatic return.
8. Rotate during a game and verify state remains intact.
9. Run `./gradlew :app:assembleDebug`.
