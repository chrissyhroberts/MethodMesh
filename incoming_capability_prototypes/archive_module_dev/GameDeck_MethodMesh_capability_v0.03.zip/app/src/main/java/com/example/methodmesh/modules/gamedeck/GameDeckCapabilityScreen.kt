package com.example.methodmesh.modules.gamedeck

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONObject

/**
 * Persistent GameDeck dashboard.
 *
 * Native dashboard/preset runs keep the live game visible. The latest real
 * ExecutionResult is retained locally but withheld from CapabilityScreenScaffold
 * until the user presses Finish / Use this snapshot.
 */
object GameDeckCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100GameDeckMethod.ID
    override val title = "GameDeck"
    override val description = "Lightweight games using MethodMesh shared services."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        var game by rememberSaveable {
            mutableStateOf(context.action.settings["game"] ?: context.action.settings["input_game"] ?: GameDeckEngine.CONNECT_FOUR)
        }
        var rngMode by rememberSaveable {
            mutableStateOf(context.action.settings["rng_mode"] ?: context.action.settings["input_rng_mode"] ?: "secure_random")
        }
        var seed by rememberSaveable {
            mutableStateOf(context.action.settings["seed"] ?: context.action.settings["input_seed"] ?: "")
        }
        var stateJson by rememberSaveable(game) { mutableStateOf(GameDeckEngine.newStateJson(game)) }
        var lastRoll by rememberSaveable { mutableStateOf(0) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun buildResult(): ExecutionResult {
            val summary = GameDeckEngine.stateSummary(stateJson)
            val values = As100GameDeckMethod.snapshot(
                game = summary.game,
                stateJson = stateJson,
                turn = summary.turn,
                winner = summary.winner,
                moveCount = summary.moves,
                rngMode = rngMode,
                seed = seed
            )
            val request = As100GameDeckMethod.request(
                action = As100GameDeckMethod.ID,
                context = context.request.invocationContext.asMap(As100GameDeckMethod.ID) + context.action.settings +
                    mapOf("game" to game, "rng_mode" to rngMode, "seed" to seed),
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100GameDeckMethod.result(request, values, context.request.invocationContext)
        }

        fun refreshSnapshot() {
            result = buildResult()
        }

        fun reset(selected: String = game) {
            game = selected
            stateJson = GameDeckEngine.newStateJson(selected)
            lastRoll = 0
            refreshSnapshot()
        }

        fun playConnectFour(column: Int) {
            stateJson = GameDeckEngine.connectFourDrop(stateJson, column)
            refreshSnapshot()
        }

        fun rollSnakes() {
            val (next, roll) = GameDeckEngine.snakesRoll(stateJson, rngMode, seed)
            stateJson = next
            lastRoll = roll
            refreshSnapshot()
        }

        LaunchedEffect(game, rngMode, seed) {
            context.onSettingsChanged(mapOf("game" to game, "rng_mode" to rngMode, "seed" to seed))
        }

        // External/ODK calls are single-shot and must not require dashboard interaction.
        LaunchedEffect(context.presentationMode, context.submitsImmediately, context.request.source) {
            val genuineExternalAutoSubmit =
                context.submitsImmediately &&
                    !context.request.source.equals("intent_test", ignoreCase = true)
            if (genuineExternalAutoSubmit && !launched) {
                launched = true
                onConfirmed(buildResult())
            } else if (!launched) {
                launched = true
                refreshSnapshot()
            }
        }

        val keepLiveDashboard =
            context.presentationMode == CapabilityPresentationMode.Dashboard ||
                context.isNativePresetRun
        val scaffoldResult = if (keepLiveDashboard) null else result
        val summary = GameDeckEngine.stateSummary(stateJson)

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let {
                mapOf(
                    GameDeckFields.RESULT to "${summary.game}: ${summary.moves} moves",
                    GameDeckFields.WINNER to summary.winner
                )
            }.orEmpty(),
            onBack = onBack,
            onRetry = { reset() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("GameDeck", style = MaterialTheme.typography.headlineSmall)

                if (context.settingShouldBeShown("game")) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { reset(GameDeckEngine.CONNECT_FOUR) }) { Text("Connect Four") }
                        OutlinedButton(onClick = { reset(GameDeckEngine.SNAKES_AND_LADDERS) }) { Text("Snakes & Ladders") }
                    }
                }

                if (game == GameDeckEngine.SNAKES_AND_LADDERS) {
                    if (context.settingShouldBeShown("rng_mode")) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { rngMode = "secure_random" }) { Text("Secure random") }
                            OutlinedButton(onClick = { rngMode = "fixed_seed" }) { Text("Fixed seed") }
                        }
                    }
                    if (rngMode == "fixed_seed" && context.settingShouldBeShown("seed")) {
                        OutlinedTextField(
                            value = seed,
                            onValueChange = { seed = it },
                            label = { Text("Fixed seed") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                when (game) {
                    GameDeckEngine.SNAKES_AND_LADDERS -> SnakesBody(
                        stateJson = stateJson,
                        lastRoll = lastRoll,
                        onRoll = ::rollSnakes
                    )
                    else -> ConnectFourBody(stateJson = stateJson, onDrop = ::playConnectFour)
                }

                Text(
                    summary.winner.ifBlank { summary.turn },
                    style = MaterialTheme.typography.titleMedium
                )
                Text("Moves: ${summary.moves}", style = MaterialTheme.typography.bodySmall)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { reset() }) { Text("New game") }
                }

                Spacer(Modifier.height(6.dp))
                if (keepLiveDashboard && result != null) {
                    Button(
                        onClick = { result?.let(onConfirmed) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot")
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectFourBody(stateJson: String, onDrop: (Int) -> Unit) {
    val state = JSONObject(stateJson)
    val board = state.getJSONArray("board")
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(7) { c ->
                Button(onClick = { onDrop(c) }, enabled = state.optString("winner").isBlank()) { Text("${c + 1}") }
            }
        }
        repeat(6) { r ->
            val row = board.getJSONArray(r)
            Text((0 until 7).joinToString("  ") { c -> when (row.optInt(c)) { 1 -> "●"; 2 -> "○"; else -> "·" } })
        }
    }
}

@Composable
private fun SnakesBody(stateJson: String, lastRoll: Int, onRoll: () -> Unit) {
    val state = JSONObject(stateJson)
    val positions = state.getJSONArray("positions")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Player 1: ${positions.optInt(0, 1)}")
        Text("Player 2: ${positions.optInt(1, 1)}")
        if (lastRoll > 0) Text("Last roll: $lastRoll")
        Button(onClick = onRoll, enabled = state.optString("winner").isBlank()) { Text("ROLL D6") }
    }
}
