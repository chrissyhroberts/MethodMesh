package com.example.methodmesh.modules.emergency

import java.time.Instant

fun main() {
    val now = Instant.parse("2026-09-06T12:00:00Z")

    check(EmergencyStatusEngine.evaluate(emptyList(), emptyList(), EmergencyPreparednessState.MINIMAL, now).localRisk == EmergencyRiskState.GREY) {
        "No coverage must never become GREEN"
    }

    val currentCoverage = EmergencyHazardDomain.entries.map {
        EmergencyDomainCoverage(it, EmergencyCoverageState.CURRENT_NO_ALERT, critical = true, checkedAt = now)
    }
    check(EmergencyStatusEngine.evaluate(currentCoverage, emptyList(), EmergencyPreparednessState.READY, now).localRisk == EmergencyRiskState.GREEN)

    val stale = currentCoverage.toMutableList().apply {
        this[0] = this[0].copy(state = EmergencyCoverageState.STALE)
    }
    check(EmergencyStatusEngine.evaluate(stale, emptyList(), EmergencyPreparednessState.PARTIAL, now).localRisk == EmergencyRiskState.GREY)

    val red = EmergencyAlert(
        eventId = "official-1",
        title = "Evacuate now",
        domain = EmergencyHazardDomain.EVACUATION_SHELTER,
        sourceId = "official",
        authority = EmergencySourceAuthority.A_AUTHORITATIVE_INSTRUCTION,
        candidateRisk = EmergencyRiskState.RED,
        issuedAt = now.minusSeconds(60),
        retrievedAt = now,
        expiresAt = now.plusSeconds(3600),
        locallyRelevant = true,
        relevanceReason = EmergencyRelevanceReason.CURRENT_LOCATION_INTERSECTS_POLYGON,
        adapterAllowsRed = true
    )
    val redSnapshot = EmergencyStatusEngine.evaluate(stale, listOf(red), EmergencyPreparednessState.PARTIAL, now)
    check(redSnapshot.localRisk == EmergencyRiskState.RED)
    check(redSnapshot.incompleteCriticalCoverage)

    val unverifiedRed = red.copy(
        eventId = "open-1",
        authority = EmergencySourceAuthority.D_OPEN_UNVERIFIED,
        sourceId = "open"
    )
    check(EmergencyStatusEngine.evaluate(currentCoverage, listOf(unverifiedRed), EmergencyPreparednessState.READY, now).localRisk == EmergencyRiskState.AMBER)

    val curatedUncorroborated = red.copy(
        eventId = "curated-1",
        authority = EmergencySourceAuthority.C_CURATED_EVENT_FEED,
        sourceId = "curated",
        corroborated = false,
        adapterAllowsRed = true
    )
    check(EmergencyStatusEngine.evaluate(currentCoverage, listOf(curatedUncorroborated), EmergencyPreparednessState.READY, now).localRisk == EmergencyRiskState.AMBER)

    val pois = listOf(
        EmergencyStrategicPoi("a1", "Airport A", EmergencyPoiCategory.AIRPORT, 0.0, 0.10, "AA", sourceId = "t", sourceVersion = "1"),
        EmergencyStrategicPoi("a2", "Airport B", EmergencyPoiCategory.AIRPORT, 0.0, 0.20, "AA", sourceId = "t", sourceVersion = "1"),
        EmergencyStrategicPoi("a3", "Airport C", EmergencyPoiCategory.AIRPORT, 0.0, 0.30, "AA", sourceId = "t", sourceVersion = "1"),
        EmergencyStrategicPoi("a4", "Airport D", EmergencyPoiCategory.AIRPORT, 0.0, 0.40, "AA", sourceId = "t", sourceVersion = "1"),
        EmergencyStrategicPoi("p1", "Port", EmergencyPoiCategory.PORT_OR_FERRY, 0.20, 0.0, "AA", sourceId = "t", sourceVersion = "1"),
        EmergencyStrategicPoi("b1", "Border", EmergencyPoiCategory.LAND_BORDER, 0.30, 0.0, "AA", sourceId = "t", sourceVersion = "1"),
        EmergencyStrategicPoi("e1", "Embassy", EmergencyPoiCategory.EMBASSY, 0.05, 0.0, "AA", representedCountryCodes = setOf("GB"), sourceId = "t", sourceVersion = "1")
    )
    val ranked = EmergencyGeo.rankExitOptions(0.0, 0.0, pois, "gb")
    check(ranked.count { it.poi.category == EmergencyPoiCategory.AIRPORT } == 3)
    check(ranked.any { it.poi.id == "e1" })
    check(ranked.none { it.poi.id == "a4" })
    check(EmergencyGeo.distanceM(0.0, 179.9, 0.0, -179.9) < 30_000) { "Dateline distance should take short path" }

    println("Emergency core self-test passed (${ranked.size} ranked exit POIs).")
}
