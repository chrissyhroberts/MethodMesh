package com.example.methodmesh.modules.emergency

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class EmergencyCoreTest {
    private val now = Instant.parse("2026-09-06T12:00:00Z")

    @Test fun noCoverageIsGrey() {
        assertEquals(
            EmergencyRiskState.GREY,
            EmergencyStatusEngine.evaluate(emptyList(), emptyList(), EmergencyPreparednessState.MINIMAL, now).localRisk
        )
    }

    @Test fun completeCriticalCoverageCanBeGreen() {
        val coverage = EmergencyHazardDomain.entries.map {
            EmergencyDomainCoverage(it, EmergencyCoverageState.CURRENT_NO_ALERT, critical = true, checkedAt = now)
        }
        assertEquals(
            EmergencyRiskState.GREEN,
            EmergencyStatusEngine.evaluate(coverage, emptyList(), EmergencyPreparednessState.READY, now).localRisk
        )
    }

    @Test fun staleCriticalCoverageIsGrey() {
        val coverage = listOf(EmergencyDomainCoverage(EmergencyHazardDomain.SEVERE_WEATHER, EmergencyCoverageState.STALE, true))
        assertEquals(
            EmergencyRiskState.GREY,
            EmergencyStatusEngine.evaluate(coverage, emptyList(), EmergencyPreparednessState.PARTIAL, now).localRisk
        )
    }

    @Test fun unverifiedRedDowngradesToAmber() {
        val coverage = listOf(EmergencyDomainCoverage(EmergencyHazardDomain.CIVIL_SECURITY, EmergencyCoverageState.CURRENT_ALERT, true))
        val alert = EmergencyAlert(
            eventId = "open-event",
            title = "Reported incident",
            domain = EmergencyHazardDomain.CIVIL_SECURITY,
            sourceId = "open",
            authority = EmergencySourceAuthority.D_OPEN_UNVERIFIED,
            candidateRisk = EmergencyRiskState.RED,
            retrievedAt = now,
            locallyRelevant = true,
            relevanceReason = EmergencyRelevanceReason.EVENT_WITHIN_RADIUS,
            adapterAllowsRed = true
        )
        assertEquals(
            EmergencyRiskState.AMBER,
            EmergencyStatusEngine.evaluate(coverage, listOf(alert), EmergencyPreparednessState.READY, now).localRisk
        )
    }

    @Test fun redAlertOutranksGreyButKeepsIncompleteFlag() {
        val coverage = listOf(EmergencyDomainCoverage(EmergencyHazardDomain.SEVERE_WEATHER, EmergencyCoverageState.UNAVAILABLE, true))
        val alert = EmergencyAlert(
            eventId = "evacuate",
            title = "Evacuate",
            domain = EmergencyHazardDomain.EVACUATION_SHELTER,
            sourceId = "authority",
            authority = EmergencySourceAuthority.A_AUTHORITATIVE_INSTRUCTION,
            candidateRisk = EmergencyRiskState.RED,
            retrievedAt = now,
            locallyRelevant = true,
            relevanceReason = EmergencyRelevanceReason.CURRENT_LOCATION_INTERSECTS_POLYGON
        )
        val snapshot = EmergencyStatusEngine.evaluate(coverage, listOf(alert), EmergencyPreparednessState.PARTIAL, now)
        assertEquals(EmergencyRiskState.RED, snapshot.localRisk)
        assertTrue(snapshot.incompleteCriticalCoverage)
    }

    @Test fun exitRankingIsSparseByCategory() {
        val pois = (1..4).map { i ->
            EmergencyStrategicPoi("a$i", "Airport $i", EmergencyPoiCategory.AIRPORT, 0.0, i / 10.0, "AA", sourceId = "test", sourceVersion = "1")
        } + listOf(
            EmergencyStrategicPoi("p", "Port", EmergencyPoiCategory.PORT_OR_FERRY, 0.2, 0.0, "AA", sourceId = "test", sourceVersion = "1"),
            EmergencyStrategicPoi("b", "Border", EmergencyPoiCategory.LAND_BORDER, 0.3, 0.0, "AA", sourceId = "test", sourceVersion = "1"),
            EmergencyStrategicPoi("e", "Embassy", EmergencyPoiCategory.EMBASSY, 0.05, 0.0, "AA", setOf("GB"), sourceId = "test", sourceVersion = "1")
        )
        val ranked = EmergencyGeo.rankExitOptions(0.0, 0.0, pois, "GB")
        assertEquals(3, ranked.count { it.poi.category == EmergencyPoiCategory.AIRPORT })
        assertTrue(ranked.any { it.poi.id == "e" })
        assertTrue(ranked.none { it.poi.id == "a4" })
    }
}
