package com.example.methodmesh.modules.astronomy

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.UUID
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Astronomy-owned regional cache for light-pollution point grids. */
class LightPollutionRepository(context: Context) {
    data class Region(
        val id: String,
        val name: String,
        val datasetId: String,
        val datasetDate: String,
        val source: String,
        val unit: String,
        val resolutionM: Double,
        val centerLat: Double,
        val centerLon: Double,
        val radiusKm: Double,
        val pointCount: Int,
        val file: File
    )

    data class Match(
        val region: Region,
        val value: Double,
        val pointDistanceKm: Double
    )

    private val dir = File(context.applicationContext.filesDir, "astronomy/light_pollution").apply { mkdirs() }

    fun importRegion(raw: String): Region {
        val root = JSONObject(raw)
        val points = root.optJSONArray("points") ?: error("Region JSON must contain a points array.")
        require(points.length() > 0) { "Region contains no points." }
        val center = root.optJSONObject("center")
        val centerLat = center?.optDouble("latitude", Double.NaN)?.takeIf { it.isFinite() }
            ?: root.optDouble("center_latitude", Double.NaN).takeIf { it.isFinite() }
            ?: error("Region centre latitude is required.")
        val centerLon = center?.optDouble("longitude", Double.NaN)?.takeIf { it.isFinite() }
            ?: root.optDouble("center_longitude", Double.NaN).takeIf { it.isFinite() }
            ?: error("Region centre longitude is required.")
        val radiusKm = root.optDouble("radius_km", Double.NaN).takeIf { it.isFinite() && it > 0 }
            ?: error("Positive radius_km is required.")
        val id = root.optString("region_id").ifBlank { UUID.randomUUID().toString() }
        root.put("region_id", id)
        root.put("cached_at_iso", Instant.now().toString())
        root.put("point_count", points.length())
        val file = File(dir, safeName(id) + ".json")
        file.writeText(root.toString())
        return parseRegion(file) ?: error("Imported region could not be re-read.")
    }

    fun listRegions(): List<Region> = dir.listFiles { file -> file.extension.equals("json", true) }
        ?.mapNotNull(::parseRegion)
        ?.sortedBy { it.name.lowercase() }
        .orEmpty()

    fun query(latitude: Double, longitude: Double): Match? {
        val candidates = listRegions().filter { region ->
            distanceKm(latitude, longitude, region.centerLat, region.centerLon) <= region.radiusKm + 5.0
        }
        var best: Match? = null
        for (region in candidates) {
            val root = runCatching { JSONObject(region.file.readText()) }.getOrNull() ?: continue
            val points = root.optJSONArray("points") ?: continue
            for (i in 0 until points.length()) {
                val p = points.optJSONObject(i) ?: continue
                val lat = p.optDouble("latitude", Double.NaN)
                val lon = p.optDouble("longitude", Double.NaN)
                val value = p.optDouble("value", Double.NaN)
                if (!lat.isFinite() || !lon.isFinite() || !value.isFinite()) continue
                val d = distanceKm(latitude, longitude, lat, lon)
                if (best == null || d < best!!.pointDistanceKm) best = Match(region, value, d)
            }
        }
        val found = best ?: return null
        val toleranceKm = maxOf(2.0, found.region.resolutionM / 1000.0 * 2.5)
        return found.takeIf { it.pointDistanceKm <= toleranceKm }
    }

    fun deleteRegion(id: String): Boolean = File(dir, safeName(id) + ".json").delete()
    fun clearAll() = dir.listFiles()?.forEach { it.delete() }

    private fun parseRegion(file: File): Region? = runCatching {
        val root = JSONObject(file.readText())
        val center = root.optJSONObject("center")
        val points = root.optJSONArray("points") ?: JSONArray()
        Region(
            id = root.optString("region_id", file.nameWithoutExtension),
            name = root.optString("name", "Cached light-pollution region"),
            datasetId = root.optString("dataset_id", "unknown"),
            datasetDate = root.optString("dataset_date", ""),
            source = root.optString("source", ""),
            unit = root.optString("unit", "mcd/m²"),
            resolutionM = root.optDouble("resolution_m", 1000.0),
            centerLat = center?.optDouble("latitude", Double.NaN)?.takeIf { it.isFinite() }
                ?: root.getDouble("center_latitude"),
            centerLon = center?.optDouble("longitude", Double.NaN)?.takeIf { it.isFinite() }
                ?: root.getDouble("center_longitude"),
            radiusKm = root.getDouble("radius_km"),
            pointCount = root.optInt("point_count", points.length()),
            file = file
        )
    }.getOrNull()

    private fun safeName(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)

    private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0088
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) + cos(p1) * cos(p2) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * asin(sqrt(a.coerceIn(0.0, 1.0)))
    }
}
