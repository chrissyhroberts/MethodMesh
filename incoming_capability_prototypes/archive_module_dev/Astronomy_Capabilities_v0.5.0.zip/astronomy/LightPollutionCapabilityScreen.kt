package com.example.methodmesh.modules.astronomy

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

object LightPollutionCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100LightPollutionMethod.id
    override val title="Light pollution"
    override val description="Query module-owned cached regional sky-brightness data. Regional files can be imported now; a direct downloader can be attached later without changing the capability contract."

    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
        val app=LocalContext.current
        val scope=rememberCoroutineScope()
        val repo=remember{LightPollutionRepository(app)}
        val initial=remember(context.action.settings){context.action.settings.mapKeys{it.key.removePrefix("input_")}}
        var mode by rememberSaveable{mutableStateOf(initial["location_source"].orEmpty().ifBlank{"auto"})}
        var plusCode by rememberSaveable{mutableStateOf(initial["plus_code"].orEmpty())}
        var latitude by rememberSaveable{mutableStateOf(initial["latitude"].orEmpty())}
        var longitude by rememberSaveable{mutableStateOf(initial["longitude"].orEmpty())}
        var regions by remember{mutableStateOf(repo.listRegions())}
        var status by rememberSaveable{mutableStateOf("${regions.size} cached region${if(regions.size==1)"" else "s"}.")}
        var result by remember{mutableStateOf<ExecutionResult?>(null)}
        var values by remember{mutableStateOf<Map<String,String>>(emptyMap())}
        var launched by rememberSaveable(context.action.canonicalId){mutableStateOf(false)}

        fun settings():Map<String,String> = mapOf("location_source" to mode,"plus_code" to plusCode,"latitude" to latitude,"longitude" to longitude)
        LaunchedEffect(mode,plusCode,latitude,longitude){context.onSettingsChanged(context.action.settings+settings())}

        fun queryAt(loc:AstroLocation){
            val calculated=repo.query(loc.latitude,loc.longitude)?.let(As100LightPollutionMethod::fromMatch)?:As100LightPollutionMethod.noCache()
            values=calculated
            val ex=methodExecution(As100LightPollutionMethod,context,calculated,settings()+mapOf("latitude" to loc.latitude.toString(),"longitude" to loc.longitude.toString(),"resolved_location_source" to loc.source))
            result=ex
            status=calculated[LightPollutionFields.RESULT].orEmpty().ifBlank{calculated[LightPollutionFields.ERROR].orEmpty()}
            if(context.submitsImmediately)onConfirmed(ex)
        }
        fun selected():AstroLocation? = when(mode){
            "plus_code" -> explicitLocation(mapOf("plus_code" to plusCode,"location_source" to "plus_code"))
            "manual" -> explicitLocation(mapOf("plus_code" to "","latitude" to latitude,"longitude" to longitude,"location_source" to "manual"))
            else -> null
        }
        fun query(){
            if(mode=="auto") currentLocation(app,::queryAt){status=it}
            else selected()?.let(::queryAt)?:run{status=if(mode=="plus_code")"Enter a valid Plus Code." else "Enter valid coordinates."}
        }
        val gpsLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){_:Map<String,Boolean>->if(hasLocationPermission(app))query()else status="Location denied. Use Plus Code or coordinates."}
        fun startQuery(){if(mode!="auto"||hasLocationPermission(app))query()else gpsLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))}
        LaunchedEffect(Unit){if(!launched){launched=true;startQuery()}}

        val importLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
            if(uri!=null)scope.launch{
                runCatching{
                    withContext(Dispatchers.IO){app.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:error("Could not read selected file.")}
                }.mapCatching{raw->repo.importRegion(raw)}.onSuccess{region->
                    regions=repo.listRegions();status="Imported ${region.name} · ${region.pointCount} samples · ${region.radiusKm} km radius."
                }.onFailure{error->status="Import failed: ${error.message.orEmpty()}"}
            }
        }

        CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,result,result?.let{mapOf(LightPollutionFields.RESULT to OutputFormatter.fields(it,false)[LightPollutionFields.RESULT]?.toString().orEmpty())}.orEmpty(),onBack,{result=null;values=emptyMap()},{result?.let(onConfirmed)},onCancel){
            Text(description,style=MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Text("Location source",fontWeight=FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth()){
                listOf("auto" to "GPS","plus_code" to "Plus Code","manual" to "Lat/lon").forEach{(key,label)->
                    OutlinedButton(onClick={mode=key},modifier=Modifier.weight(1f)){Text(if(mode==key)"✓ $label" else label)}
                }
            }
            when(mode){
                "plus_code"->OutlinedTextField(plusCode,{plusCode=it},label={Text("Plus Code")},singleLine=true,modifier=Modifier.fillMaxWidth())
                "manual"->Row(Modifier.fillMaxWidth()){
                    OutlinedTextField(latitude,{latitude=it},label={Text("Latitude")},singleLine=true,modifier=Modifier.weight(1f))
                    Spacer(Modifier.padding(3.dp))
                    OutlinedTextField(longitude,{longitude=it},label={Text("Longitude")},singleLine=true,modifier=Modifier.weight(1f))
                }
            }
            Button(onClick=::startQuery,modifier=Modifier.fillMaxWidth().padding(top=8.dp)){Text("Look up cached light pollution")}
            values[LightPollutionFields.RESULT]?.takeIf{it.isNotBlank()}?.let{resultText->
                Card(Modifier.fillMaxWidth().padding(top=8.dp)){Column(Modifier.padding(12.dp)){
                    Text(values[LightPollutionFields.LABEL].orEmpty(),style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
                    Text(resultText)
                    Text("Artificial / natural reference ratio ${values[LightPollutionFields.RATIO].orEmpty()} · not a Bortle class",style=MaterialTheme.typography.bodySmall)
                }}
            }
            Spacer(Modifier.height(10.dp))
            Text("Regional cache",fontWeight=FontWeight.SemiBold)
            Text("Cache files live inside the astronomy module. A region JSON contains its centre, radius, dataset metadata and sampled grid points.",style=MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick={importLauncher.launch(arrayOf("application/json","text/plain","application/octet-stream"))},modifier=Modifier.fillMaxWidth()){Text("Import regional cache file")}
            regions.forEach{region->
                Card(Modifier.fillMaxWidth().padding(top=6.dp)){Column(Modifier.padding(10.dp)){
                    Text(region.name,fontWeight=FontWeight.SemiBold)
                    Text("${region.datasetId}${region.datasetDate.takeIf{it.isNotBlank()}?.let{" · $it"}.orEmpty()} · ${region.radiusKm} km · ${region.pointCount} points",style=MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick={repo.deleteRegion(region.id);regions=repo.listRegions();status="Region removed."}){Text("Remove")}
                }}
            }
            Text(status,style=MaterialTheme.typography.bodySmall,modifier=Modifier.padding(top=6.dp))
        }
    }
}
