# Astronomy v0.5.0 validation

## Added / changed in this package

- Dashboard site selection is explicit: **Current GPS**, **Plus Code**, or **Latitude / longitude**. Manual/Plus Code sites remain selected; **◎ GPS** deliberately recentres and switches back to GPS.
- Dashboard continues to use the atomic `As100ImagingWindowMethod.calculate()` engine for the best-window calculation rather than a second copy of the scoring logic.
- Added module-local regional light-pollution cache plus `astronomy.light_pollution`; cached site-darkness data is also shown on the dashboard when available.
- Regional cache files carry centre/radius, source/date/resolution metadata and sampled point values. `docs/build_light_pollution_region.py` builds an arbitrary radius cache from a World Atlas GeoTIFF.
- No core `HomeScreen` or global Settings/resource-registry changes are included.
- Polar alignment now has an AR sighting mode using rear-camera-axis azimuth/elevation for a vertically mounted phone/tripod, while preserving ordinary compass mode.
- Sky test is explicitly a relative point-source test against a user-saved clear-night reference; misleading absolute/screen-down claims were removed.
- Focus is renamed visually to **Telescope focus assistant**, supports rear/front camera selection, and uses a rolling-median FWHM metric.
- Image scale now has sliders plus exact numeric text fields.
- Astronomy session now has Start/Pause/Resume/Stop/Discard and astronomy-local resumable active-session persistence.
- Native preset astronomy dashboard refresh remains in the dashboard instead of switching to the generic result renderer. External/ODK dashboard calls still return structured outputs automatically.

## Local checks performed for this package

- `AstronomyMath.kt` + `docs/AstronomyMathSmoke.kt` compile and run as a JVM smoke test.
- Module structural check verifies all 12 registered astronomy methods and all 12 registered screens resolve to declarations.
- Python light-pollution preprocessing helper passes `py_compile` and a synthetic EPSG:4326 GeoTIFF extraction test.
- Kotlin source parse pass shows no parser-level `expecting` errors; Android/Compose symbols cannot be fully resolved without the complete MethodMesh Android build environment.
- XLSForm is scanned for formula errors and stale release metadata.

## Still required in the actual repository / on device

1. `./gradlew :app:assembleDebug` in the current full MethodMesh checkout.
2. Open the dashboard from the capability browser and from a native preset; confirm refresh remains on the visual dashboard and **Finish** closes a preset run.
3. Verify dashboard location switching between GPS, Plus Code and manual coordinates, including **◎ GPS** recentring.
4. Verify remote-site manual/Plus Code selection drives weather, imaging window and cached light-pollution lookup for that site.
5. Verify Open-Meteo current/hourly/AQ/GFS 200/250/300 hPa values on a physical phone.
6. Cross-check representative jet values with an independent GFS upper-air chart.
7. AR polar sighting: mount phone vertically, confirm rear-camera azimuth/elevation directionality, declination correction and pole guidance away from ferrous structures.
8. Sky clear-night reference persists and produces sensible relative directionality under deliberately degraded stability/brightness/contrast.
9. Characterise camera auto-exposure/autofocus/OIS effects for sky test.
10. Focus rear/front camera switch works; rolling median is more stable than instantaneous FWHM around best focus.
11. Image-scale sliders and exact fields remain synchronized and return correct calculations at representative rigs.
12. Session survives activity/process restart, pause excludes paused time, resume continues, stop returns the correct active duration, and discard clears unfinished state.
13. Build/import a regional light-pollution cache for a known site and verify query inside/outside coverage plus dashboard display.
14. Confirm `astronomy.light_pollution` does not label its heuristic category as Bortle and preserves source/date/resolution in audit output.
15. ODK Collect round-trip for all 12 public methods, including external automatic dashboard return.

Status remains **Development**.
