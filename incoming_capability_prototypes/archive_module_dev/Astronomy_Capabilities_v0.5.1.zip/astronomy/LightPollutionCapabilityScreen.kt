package com.example.methodmesh.modules.astronomy

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object LightPollutionCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100LightPollutionMethod.id
    override val title = "Light pollution"
    override val description = "Look up and manage astronomy-owned regional light-pollution caches. Native use stays interactive; external callers receive a structured lookup result."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val app = LocalContext.current
        val scope = rememberCoroutineScope()
        val repo = remember { LightPollutionRepository(app) }
        val initial = remember(context.action.settings) { context.action.settings.mapKeys { it.key.removePrefix("input_") } }

        var mode by rememberSaveable { mutableStateOf(initial["location_source"].orEmpty().ifBlank { "auto" }) }
        var plusCode by rememberSaveable { mutableStateOf(initial["plus_code"].orEmpty()) }
        var latitude by rememberSaveable { mutableStateOf(initial["latitude"].orEmpty()) }
        var longitude by rememberSaveable { mutableStateOf(initial["longitude"].orEmpty()) }
        var regions by remember { mutableStateOf(repo.listRegions()) }
        var status by rememberSaveable { mutableStateOf("${regions.size} cached region${if (regions.size == 1) "" else "s"} available.") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var values by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var lastLocation by remember { mutableStateOf<AstroLocation?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        // MethodMesh's own capability browser uses intent_test. That is a native
        // interactive surface, not an external machine caller and must not auto-return.
        val interactiveNative =
            context.request.source.equals("intent_test", ignoreCase = true) ||
                context.presentationMode == CapabilityPresentationMode.Dashboard ||
                context.isNativePresetRun

        fun settings(): Map<String, String> = mapOf(
            "location_source" to mode,
            "plus_code" to plusCode,
            "latitude" to latitude,
            "longitude" to longitude
        )

        LaunchedEffect(mode, plusCode, latitude, longitude) {
            context.onSettingsChanged(context.action.settings + settings())
        }

        fun selected(): AstroLocation? = when (mode) {
            "plus_code" -> explicitLocation(mapOf("plus_code" to plusCode, "location_source" to "plus_code"))
            "manual" -> explicitLocation(mapOf("plus_code" to "", "latitude" to latitude, "longitude" to longitude, "location_source" to "manual"))
            else -> null
        }

        fun lookupAt(location: AstroLocation, submitImmediately: Boolean) {
            lastLocation = location
            val match = repo.query(location.latitude, location.longitude)
            val calculated = match?.let(As100LightPollutionMethod::fromMatch) ?: As100LightPollutionMethod.noCache()
            values = calculated
            status = if (match == null) {
                "No cached region covers this site. Import a regional cache below."
            } else {
                "Covered by ${match.region.name} · nearest sample ${"%.2f".format(match.pointDistanceKm)} km."
            }

            if (match != null || submitImmediately) {
                val effective = settings() + mapOf(
                    "latitude" to location.latitude.toString(),
                    "longitude" to location.longitude.toString(),
                    "resolved_location_source" to location.source
                )
                val execution = methodExecution(As100LightPollutionMethod, context, calculated, effective)
                result = execution
                if (submitImmediately) onConfirmed(execution)
            } else {
                result = null
            }
        }

        fun resolveAndLookup(submitImmediately: Boolean) {
            if (mode == "auto") {
                currentLocation(app, { lookupAt(it, submitImmediately) }) { message ->
                    status = message
                    if (submitImmediately) {
                        val calculated = As100LightPollutionMethod.locationFailure(message)
                        val execution = methodExecution(As100LightPollutionMethod, context, calculated, settings())
                        result = execution
                        onConfirmed(execution)
                    }
                }
                return
            }
            val location = selected()
            if (location == null) {
                val message = if (mode == "plus_code") "Enter a valid Plus Code." else "Enter valid coordinates."
                status = message
                if (submitImmediately) {
                    val calculated = As100LightPollutionMethod.locationFailure(message)
                    val execution = methodExecution(As100LightPollutionMethod, context, calculated, settings())
                    result = execution
                    onConfirmed(execution)
                }
            } else lookupAt(location, submitImmediately)
        }

        val gpsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _: Map<String, Boolean> ->
            if (hasLocationPermission(app)) resolveAndLookup(submitImmediately = !interactiveNative)
            else {
                status = "Location denied. Use Plus Code or coordinates."
                if (!interactiveNative) {
                    val calculated = As100LightPollutionMethod.locationFailure(status)
                    val execution = methodExecution(As100LightPollutionMethod, context, calculated, settings())
                    result = execution
                    onConfirmed(execution)
                }
            }
        }

        fun startLookup(submitImmediately: Boolean = false) {
            if (mode != "auto" || hasLocationPermission(app)) resolveAndLookup(submitImmediately)
            else gpsLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }

        // External/ODK invocation remains a single-shot capability. Native/test/preset
        // invocation stays on the management/lookup screen until the user chooses a result.
        LaunchedEffect(Unit) {
            if (!launched) {
                launched = true
                if (!interactiveNative) startLookup(submitImmediately = true)
            }
        }

        val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) scope.launch {
                runCatching {
                    withContext(Dispatchers.IO) {
                        app.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                            ?: error("Could not read selected file.")
                    }
                }.mapCatching(repo::importRegion)
                    .onSuccess { region ->
                        regions = repo.listRegions()
                        status = "Imported ${region.name} · ${region.pointCount} samples · ${region.radiusKm} km radius."
                        lastLocation?.let { lookupAt(it, submitImmediately = false) }
                    }
                    .onFailure { error -> status = "Import failed: ${error.message.orEmpty()}" }
            }
        }

        // Keep the native capability visually on this screen. Only genuine external
        // invocation is allowed to use the scaffold's automatic result flow.
        val scaffoldResult = if (interactiveNative) null else result
        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = emptyMap(),
            onBack = onBack,
            onRetry = { result = null; values = emptyMap() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text(description, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.padding(4.dp))

            Text("Site", fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth()) {
                listOf("auto" to "GPS", "plus_code" to "Plus Code", "manual" to "Lat/lon").forEach { (key, label) ->
                    OutlinedButton(onClick = { mode = key; values = emptyMap(); result = null }, modifier = Modifier.weight(1f)) {
                        Text(if (mode == key) "✓ $label" else label)
                    }
                }
            }
            when (mode) {
                "plus_code" -> OutlinedTextField(plusCode, { plusCode = it }, label = { Text("Plus Code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                "manual" -> Row(Modifier.fillMaxWidth()) {
                    OutlinedTextField(latitude, { latitude = it }, label = { Text("Latitude") }, singleLine = true, modifier = Modifier.weight(1f))
                    Spacer(Modifier.padding(3.dp))
                    OutlinedTextField(longitude, { longitude = it }, label = { Text("Longitude") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
            Button(onClick = { startLookup(false) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text("Check this site")
            }

            val resultText = values[LightPollutionFields.RESULT].orEmpty()
            val label = values[LightPollutionFields.LABEL].orEmpty()
            if (label.isNotBlank()) {
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(label, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(resultText)
                        Text(
                            "Artificial / natural reference ratio ${values[LightPollutionFields.RATIO].orEmpty()} · not a Bortle class",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                if (interactiveNative && result != null) {
                    Button(onClick = { result?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text(if (context.isNativePresetRun) "Finish with this result" else "Use this result")
                    }
                }
            } else if (values[LightPollutionFields.ERROR].orEmpty().isNotBlank()) {
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("NOT CACHED", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(values[LightPollutionFields.ERROR].orEmpty(), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.padding(5.dp))
            Text("Regional cache", fontWeight = FontWeight.SemiBold)
            Text(
                "${regions.size} region${if (regions.size == 1) "" else "s"} stored inside astronomy. Import a MethodMesh astronomy light-pollution region JSON; the dashboard reads this same repository.",
                style = MaterialTheme.typography.bodySmall
            )
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            ) { Text("Import regional cache") }

            val coveringId = lastLocation?.let { location -> repo.query(location.latitude, location.longitude)?.region?.id }
            regions.forEach { region ->
                Card(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(region.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${region.datasetId}${region.datasetDate.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()} · ${region.radiusKm} km · ${region.pointCount} points",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (region.id == coveringId) Text("✓ Covers selected site", fontWeight = FontWeight.SemiBold)
                        OutlinedButton(onClick = {
                            repo.deleteRegion(region.id)
                            regions = repo.listRegions()
                            status = "Region removed."
                            lastLocation?.let { lookupAt(it, submitImmediately = false) }
                        }) { Text("Remove") }
                    }
                }
            }
            Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
