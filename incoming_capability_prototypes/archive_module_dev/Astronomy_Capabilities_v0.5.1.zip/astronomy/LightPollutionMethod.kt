package com.example.methodmesh.modules.astronomy

import com.example.methodmesh.core.methodmesh.MethodObjectType
import org.json.JSONObject
import java.util.Locale

object LightPollutionFields {
    const val STATUS="astronomy_light_pollution_status"
    const val RESULT="astronomy_light_pollution_result"
    const val VALUE="astronomy_light_pollution_artificial_zenith_radiance_mcd_m2"
    const val RATIO="astronomy_light_pollution_artificial_to_natural_ratio"
    const val LABEL="astronomy_light_pollution_label"
    const val DATASET="astronomy_light_pollution_dataset_id"
    const val DATASET_DATE="astronomy_light_pollution_dataset_date"
    const val REGION="astronomy_light_pollution_region"
    const val RESOLUTION="astronomy_light_pollution_resolution_m"
    const val DISTANCE="astronomy_light_pollution_sample_distance_km"
    const val AUDIT="astronomy_light_pollution_audit_json"
    const val ERROR="astronomy_light_pollution_error"
    val outputs=listOf(STATUS,RESULT,VALUE,RATIO,LABEL,DATASET,DATASET_DATE,REGION,RESOLUTION,DISTANCE,AUDIT,ERROR)
}

object As100LightPollutionMethod : AstronomyMethodBase(
    "astronomy.light_pollution",
    "Light pollution",
    "Look up artificial zenith sky radiance from an astronomy-owned cached regional dataset.",
    "astronomy.light_pollution",
    MethodObjectType.Calculation,
    LightPollutionFields.RESULT,
    LightPollutionFields.STATUS,
    LightPollutionFields.ERROR,
    LightPollutionFields.outputs,
    version="0.5.1"
) {
    fun fromMatch(match: LightPollutionRepository.Match): Map<String,String> {
        val value=match.value
        // Approximate natural zenith luminance used only to express an interpretable ratio.
        // The returned radiance value itself remains the authoritative dataset quantity.
        val naturalMcdM2=0.174
        val ratio=value/naturalMcdM2
        val label=when {
            ratio < 0.08 -> "VERY DARK"
            ratio < 0.33 -> "DARK"
            ratio < 1.0 -> "MODERATE"
            ratio < 4.0 -> "BRIGHT"
            else -> "VERY BRIGHT"
        }
        val r=match.region
        return success(
            LightPollutionFields.RESULT to "$label · ${fmt(value,3)} ${r.unit} artificial zenith radiance",
            LightPollutionFields.VALUE to fmt(value,6),
            LightPollutionFields.RATIO to fmt(ratio,3),
            LightPollutionFields.LABEL to label,
            LightPollutionFields.DATASET to r.datasetId,
            LightPollutionFields.DATASET_DATE to r.datasetDate,
            LightPollutionFields.REGION to r.name,
            LightPollutionFields.RESOLUTION to fmt(r.resolutionM,0),
            LightPollutionFields.DISTANCE to fmt(match.pointDistanceKm,3),
            LightPollutionFields.AUDIT to JSONObject().apply {
                put("method_id",id)
                put("algorithm_version","0.5.1")
                put("dataset_source",r.source)
                put("unit",r.unit)
                put("classification","MethodMesh heuristic based on artificial-to-natural radiance ratio; not a Bortle class")
                put("natural_reference_mcd_m2",naturalMcdM2)
                put("cache_scope","astronomy module only")
            }.toString()
        )
    }

    fun noCache():Map<String,String> = linkedMapOf(
        LightPollutionFields.STATUS to "failed",
        LightPollutionFields.RESULT to "NO CACHED LIGHT-POLLUTION DATA FOR THIS LOCATION",
        LightPollutionFields.ERROR to "No cached light-pollution sample covers this location. Import a regional dataset in the Light pollution capability."
    )

    fun locationFailure(message:String):Map<String,String> = linkedMapOf(
        LightPollutionFields.STATUS to "failed",
        LightPollutionFields.RESULT to "LIGHT-POLLUTION LOOKUP COULD NOT RESOLVE A LOCATION",
        LightPollutionFields.ERROR to message
    )
    private fun fmt(v:Double,d:Int)=String.format(Locale.US,"%.${d}f",v)
}
