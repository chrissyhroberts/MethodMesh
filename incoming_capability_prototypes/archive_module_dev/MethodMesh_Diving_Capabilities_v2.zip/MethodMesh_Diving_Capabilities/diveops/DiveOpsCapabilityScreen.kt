package com.example.methodmesh.modules.diveops

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.settings.MethodSetting
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONObject

private data class OpsScreenInfo(val title: String, val description: String, val button: String)
private val opsInfo = mapOf(
    DiveOpsIds.OPERATION_RECORD to OpsScreenInfo("Diving operation record", "Capture the operation, task, supervisor, depth/time, system and plan references.", "Record operation"),
    DiveOpsIds.PERSON_RECORD to OpsScreenInfo("Dive team readiness", "Record role, qualification/medical references and operator-entered readiness.", "Save person"),
    DiveOpsIds.EQUIPMENT_RECORD to OpsScreenInfo("Equipment readiness", "Record inspection/calibration context, defects and operator readiness.", "Save equipment"),
    DiveOpsIds.GAS_ENDURANCE to OpsScreenInfo("Surface-supply gas endurance", "Estimate nominal HP-bank endurance using entered reserve and consumption assumptions.", "Calculate endurance"),
    DiveOpsIds.PNEUMO to OpsScreenInfo("Pneumofathometer conversion", "Convert hydrostatic gauge pressure to depth or depth to expected gauge pressure.", "Calculate"),
    DiveOpsIds.UMBILICAL to OpsScreenInfo("Umbilical geometry", "Estimate straight-line and planning length from depth/excursion and an entered slack factor.", "Calculate"),
    DiveOpsIds.INCIDENT_RECORD to OpsScreenInfo("Diving incident / near miss", "Capture a concise chronology and immediate/follow-up actions.", "Record incident"),
    DiveOpsIds.SAMPLE_RECORD to OpsScreenInfo("Underwater sample record", "Capture sample identity, time, depth, location reference and container.", "Record sample")
)

class DiveOpsSimpleCapabilityScreen(private val methodId: String) : CapabilityScreenSpec {
    private val info = opsInfo.getValue(methodId)
    override val capabilityId = methodId
    override val title = info.title
    override val description = info.description

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val appContext = LocalContext.current
        val method = DiveOpsMethods.byId(methodId) ?: return
        val specs = DiveOpsSettings.forMethod(methodId)
        var settingsJson by rememberSaveable(context.action.canonicalId) { mutableStateOf(opsInitialJson(specs, context.action.settings)) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var note by rememberSaveable { mutableStateOf("Ready.") }
        val settings = remember(settingsJson) { opsJsonMap(settingsJson) }

        LaunchedEffect(settingsJson) { context.onSettingsChanged(settings) }

        fun run() {
            val merged = context.action.settings + settings
            val values = method.calculate(merged)
            if (values[DiveOpsFields.STATUS] == "succeeded") {
                when (methodId) {
                    DiveOpsIds.OPERATION_RECORD -> values[DiveOpsFields.OPERATION_RECORD_JSON]?.let { DiveOpsRepository.upsert(appContext, DiveOpsRepository.OPERATIONS, it) }
                    DiveOpsIds.PERSON_RECORD -> values[DiveOpsFields.PERSON_RECORD_JSON]?.let { DiveOpsRepository.upsert(appContext, DiveOpsRepository.PEOPLE, it) }
                    DiveOpsIds.EQUIPMENT_RECORD -> values[DiveOpsFields.EQUIPMENT_RECORD_JSON]?.let { DiveOpsRepository.upsert(appContext, DiveOpsRepository.EQUIPMENT, it) }
                    DiveOpsIds.INCIDENT_RECORD -> values[DiveOpsFields.INCIDENT_RECORD_JSON]?.let { DiveOpsRepository.upsert(appContext, DiveOpsRepository.INCIDENTS, it) }
                    DiveOpsIds.SAMPLE_RECORD -> values[DiveOpsFields.SAMPLE_RECORD_JSON]?.let { DiveOpsRepository.upsert(appContext, DiveOpsRepository.SAMPLES, it) }
                }
            }
            val request = method.request(method.id, context.request.invocationContext.asMap(method.id) + merged, emptyList(), emptyList())
            result = method.result(request, values, context.request.invocationContext)
            note = values[DiveOpsFields.ERROR].takeUnless { it.isNullOrBlank() }
                ?: values[DiveOpsFields.WARNING].takeUnless { it.isNullOrBlank() }
                ?: "Completed."
        }

        val genuineExternalAutoSubmit = context.submitsImmediately && !context.request.source.equals("intent_test", ignoreCase = true)
        val hasRuntimeInputs = specs.any { context.settingShouldBeShown(it.id) }
        LaunchedEffect(context.presentationMode, context.action.settings, settingsJson) {
            if (!launched && (genuineExternalAutoSubmit || (context.isNativePresetRun && !hasRuntimeInputs))) {
                launched = true
                run()
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
            onBack = onBack,
            onRetry = ::run,
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text(description, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            if (methodId in setOf(DiveOpsIds.GAS_ENDURANCE, DiveOpsIds.PNEUMO, DiveOpsIds.UMBILICAL)) OpsSafetyNotice()
            OpsSettingsEditor(context, specs, settings) { k, v -> settingsJson = opsMapJson(settings + (k to v)) }
            Spacer(Modifier.height(10.dp))
            Button(onClick = ::run, modifier = Modifier.fillMaxWidth()) { Text(info.button) }
            Text(note, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

object DiveOpsSupervisorDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = DiveOpsIds.DASHBOARD
    override val title = "Dive supervisor dashboard"
    override val description = "Local record-completeness and readiness overview. This is not a dive-control system or legal compliance determination."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val appContext = LocalContext.current
        val method = DiveOpsMethods.dashboard
        var valuesJson by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var attempted by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val values = remember(valuesJson) { opsJsonMap(valuesJson) }

        fun refresh() {
            val inputs = context.action.settings + mapOf(
                "operations_json" to DiveOpsRepository.allJson(appContext, DiveOpsRepository.OPERATIONS),
                "people_json" to DiveOpsRepository.allJson(appContext, DiveOpsRepository.PEOPLE),
                "equipment_json" to DiveOpsRepository.allJson(appContext, DiveOpsRepository.EQUIPMENT),
                "incidents_json" to DiveOpsRepository.allJson(appContext, DiveOpsRepository.INCIDENTS)
            )
            val calculated = method.calculate(inputs)
            valuesJson = opsMapJson(calculated)
            val request = method.request(method.id, context.request.invocationContext.asMap(method.id) + context.action.settings, emptyList(), emptyList())
            result = method.result(request, calculated, context.request.invocationContext)
        }

        LaunchedEffect(Unit) { if (!attempted) { attempted = true; refresh() } }
        LaunchedEffect(valuesJson) {
            if (result == null && valuesJson.isNotBlank()) {
                val restored = opsJsonMap(valuesJson)
                val request = method.request(method.id, context.request.invocationContext.asMap(method.id) + context.action.settings, emptyList(), emptyList())
                result = method.result(request, restored, context.request.invocationContext)
            }
        }

        val keepLive = context.presentationMode == CapabilityPresentationMode.Dashboard || context.isNativePresetRun || context.request.source.equals("intent_test", true)
        val scaffoldResult = if (keepLive) null else result

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let { OutputFormatter.fields(it, false) }.orEmpty(),
            onBack = onBack,
            onRetry = ::refresh,
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text(description, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Supervisor/contractor remains responsible for the diving project, team, plant, gas, emergency arrangements, records and go/no-go decision. MethodMesh only summarises stored operator-entered records.",
                    Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall
                )
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = ::refresh, modifier = Modifier.fillMaxWidth()) { Text("Refresh") }
            Spacer(Modifier.height(8.dp))
            OpsMetricRow("Active/planned operations", values[DiveOpsFields.ACTIVE_OPERATION_COUNT].orEmpty(), "People", values[DiveOpsFields.PERSON_COUNT].orEmpty())
            OpsMetricRow("People not ready", values[DiveOpsFields.PERSON_NOT_READY_COUNT].orEmpty(), "Equipment", values[DiveOpsFields.EQUIPMENT_COUNT].orEmpty())
            OpsMetricRow("Equipment not ready", values[DiveOpsFields.EQUIPMENT_NOT_READY_COUNT].orEmpty(), "Incidents recorded", values[DiveOpsFields.INCIDENT_COUNT].orEmpty())
            values[DiveOpsFields.WARNING]?.takeIf { it.isNotBlank() }?.let {
                Card(Modifier.fillMaxWidth().padding(top = 8.dp)) { Text(it, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) }
            }
            if (keepLive && result != null && values[DiveOpsFields.STATUS] == "succeeded") {
                Spacer(Modifier.height(12.dp))
                Button(onClick = { result?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) { Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot") }
            }
        }
    }
}

object DiveOpsCapabilityScreens {
    val all: List<CapabilityScreenSpec> = opsInfo.keys.map(::DiveOpsSimpleCapabilityScreen) + DiveOpsSupervisorDashboardCapabilityScreen
}

@Composable
private fun OpsSettingsEditor(context: CapabilityScreenContext, specs: List<MethodSetting>, values: Map<String, String>, onValue: (String, String) -> Unit) {
    var group: String? = null
    specs.forEach { s ->
        if (!context.settingShouldBeShown(s.id)) return@forEach
        if (s.group != null && s.group != group) {
            if (group != null) Spacer(Modifier.height(8.dp))
            Text(s.group.orEmpty(), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
            group = s.group
        }
        when (s) {
            is MethodSetting.BooleanSetting -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) { Text(s.label); s.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) } }
                Switch(values[s.id].toBoolean(), { onValue(s.id, it.toString()) })
            }
            is MethodSetting.ChoiceSetting -> OpsChoice(s, values[s.id].orEmpty()) { onValue(s.id, it) }
            is MethodSetting.IntSetting -> OpsText(s.label, s.description, values[s.id].orEmpty(), true) { onValue(s.id, it) }
            is MethodSetting.FloatSetting -> OpsText(s.label, s.description, values[s.id].orEmpty(), true) { onValue(s.id, it) }
            is MethodSetting.TextSetting -> OpsText(s.label, s.description, values[s.id].orEmpty(), false) { onValue(s.id, it) }
            is MethodSetting.MultiChoiceSetting -> OpsText(s.label, s.description, values[s.id].orEmpty(), false) { onValue(s.id, it) }
        }
    }
}

@Composable
private fun OpsChoice(s: MethodSetting.ChoiceSetting, value: String, onValue: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(s.label, style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text(value.ifBlank { s.defaultValue }) }
        DropdownMenu(open, { open = false }) { s.choices.forEach { choice -> DropdownMenuItem({ Text(choice) }, { onValue(choice); open = false }) } }
        s.description?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun OpsText(label: String, description: String?, value: String, numeric: Boolean, onValue: (String) -> Unit) {
    OutlinedTextField(value, { onValue(if (numeric) it.opsNumeric() else it) }, label = { Text(label) }, supportingText = description?.let { { Text(it) } }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
}

@Composable
private fun OpsSafetyNotice() {
    Card(Modifier.fillMaxWidth()) {
        Text("Calculation support only. Do not use these outputs as a substitute for the applicable diving project plan, supervisor, approved procedures, life-support system design, decompression system or manufacturer limits.", Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun OpsMetricRow(a: String, av: String, b: String, bv: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OpsMetric(a, av, Modifier.weight(1f)); OpsMetric(b, bv, Modifier.weight(1f))
    }
}

@Composable
private fun OpsMetric(label: String, value: String, modifier: Modifier) {
    Card(modifier.padding(vertical = 4.dp)) { Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Text(value.ifBlank { "—" }, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium) } }
}

private fun opsInitialJson(specs: List<MethodSetting>, supplied: Map<String, String>): String = opsMapJson(specs.associate { it.id to (supplied[it.id] ?: supplied["input_${it.id}"] ?: it.opsDefault()) })
private fun MethodSetting.opsDefault() = when (this) {
    is MethodSetting.BooleanSetting -> defaultValue.toString(); is MethodSetting.IntSetting -> defaultValue.toString(); is MethodSetting.FloatSetting -> defaultValue.toString()
    is MethodSetting.TextSetting -> defaultValue; is MethodSetting.ChoiceSetting -> defaultValue; is MethodSetting.MultiChoiceSetting -> defaultValue
}
private fun opsMapJson(m: Map<String, String>) = JSONObject(m).toString()
private fun opsJsonMap(raw: String): Map<String, String> = runCatching { val o = JSONObject(raw); o.keys().asSequence().associateWith { o.optString(it) } }.getOrDefault(emptyMap())
private fun String.opsNumeric(): String = filter { it.isDigit() || it == '-' || it == '.' }.let { x -> val sign = if (x.startsWith("-")) "-" else ""; val p = x.removePrefix("-").split('.'); sign + p.first() + if (p.size > 1) "." + p.drop(1).joinToString("") else "" }
