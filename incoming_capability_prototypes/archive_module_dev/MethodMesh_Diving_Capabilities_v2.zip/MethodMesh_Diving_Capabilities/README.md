# MethodMesh Diving Capabilities

This is the clean capability deliverable.

Copy the module folders into:

`app/src/main/java/com/example/methodmesh/modules/`

Contents:

- `diving/` — recreational/technical diving calculations, records and dashboards.
- `diveops/` — professional/commercial/scientific diving operation capabilities and supervisor dashboard.
- `INTEGRATION_HANDOFF.md` — build/admission notes.

There are no compiler stubs, JARs, scratch artefacts or wrapper project files in this package.
