# Build fixes

## 2026-09-04 — Compose `weight` resolution

Removed explicit `import androidx.compose.foundation.layout.weight` from:

- `diving/DivingCapabilityScreen.kt`
- `diving/DivingDashboardCapabilityScreen.kt`
- `diveops/DiveOpsCapabilityScreen.kt`

MethodMesh's Compose version resolves `Modifier.weight(...)` as the public `RowScope` / `ColumnScope` extension from inside the corresponding layout scope. The explicit import instead resolves to an internal Compose implementation symbol (`RowColumnParentData?.weight`) and causes `:app:compileDebugKotlin` to fail.

The `Modifier.weight(...)` calls themselves are intentionally retained.
