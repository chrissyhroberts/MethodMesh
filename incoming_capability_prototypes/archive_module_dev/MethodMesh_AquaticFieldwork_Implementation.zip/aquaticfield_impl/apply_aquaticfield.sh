#!/usr/bin/env bash
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${1:-$PWD}"

if [[ ! -f "$REPO_DIR/app/build.gradle.kts" ]] || [[ ! -d "$REPO_DIR/app/src/main/java/com/example/methodmesh/modules" ]]; then
  echo "Not a MethodMesh repository root: $REPO_DIR" >&2
  echo "Usage: $0 /path/to/MethodMesh" >&2
  exit 2
fi

TARGET_MAIN="$REPO_DIR/app/src/main/java/com/example/methodmesh/modules/aquaticfield"
TARGET_TEST="$REPO_DIR/app/src/test/java/com/example/methodmesh/modules/aquaticfield"

if [[ -e "$TARGET_MAIN" || -e "$TARGET_TEST" ]]; then
  echo "Aquatic fieldwork target already exists; refusing to overwrite." >&2
  exit 3
fi

mkdir -p "$(dirname "$TARGET_MAIN")" "$(dirname "$TARGET_TEST")"
cp -R "$BUNDLE_DIR/app/src/main/java/com/example/methodmesh/modules/aquaticfield" "$TARGET_MAIN"
cp -R "$BUNDLE_DIR/app/src/test/java/com/example/methodmesh/modules/aquaticfield" "$TARGET_TEST"

echo "Aquatic fieldwork module copied into: $REPO_DIR"
echo "Review ROADMAP_APPEND.md, then run:"
echo "  ./gradlew :app:testDebugUnitTest"
echo "  ./gradlew :app:assembleDebug"
