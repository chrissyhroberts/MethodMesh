### Aquatic fieldwork / oceanography / limnology

- Added as a self-contained `aquaticfield` Development module.
- Public methods cover salinity/conductivity, pressure/depth, Secchi, station visits, CTD/sonde casts, sample IDs, discrete samples, rosette firing, processed vertical profiles, depth plans, instrument checks, field QC, transects, moorings, sediment sampling and a persistent station dashboard.
- Module-owned local field state is separate from MethodMesh graph-result commits; dashboard Refresh reads local state and explicit Finish returns the selected station snapshot.
- Practical Salinity uses PSS-78 and is validated against the standard 42.9140 mS/cm reference point.
- Absolute Salinity is deliberately disabled until a validated offline TEOS-10 SAAR implementation/data pack is bundled; Reference Salinity is not relabelled as Absolute Salinity.
- Pressure/depth currently uses the documented UNESCO 1983 / Saunders relationship with latitude and explicit sensor/cable corrections.
- Raw manufacturer-specific CTD processing is deliberately excluded; the profile capability works from processed simple tabular data.
- Schmidt stability and whole-lake heat content remain unavailable until bathymetric/hypsographic geometry is explicitly supplied.
- Includes module documentation, scientific-method notes, unit tests and `docs/example_odk_aquaticfield.xlsx` covering all public methods.
- Needs full Android build plus native/preset/ODK/protocol/orientation testing before Production promotion.
