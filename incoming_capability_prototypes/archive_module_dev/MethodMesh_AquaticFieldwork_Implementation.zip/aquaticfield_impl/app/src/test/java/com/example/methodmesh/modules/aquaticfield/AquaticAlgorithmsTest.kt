package com.example.methodmesh.modules.aquaticfield

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class AquaticAlgorithmsTest {

    @Test
    fun pss78ReferenceConductivityReturnsApproximately35() {
        val sp = AquaticAlgorithms.practicalSalinityPss78(
            conductivityMsCm = 42.9140,
            temperatureC90 = 15.0,
            pressureDbar = 0.0
        )
        assertTrue("SP should be close to 35 at the PSS-78 reference point; got $sp", abs(sp - 35.0) < 0.02)
    }

    @Test
    fun pressureDepthRoundTripIsStable() {
        val latitude = 45.0
        val pressure = 1000.0
        val depth = AquaticAlgorithms.unescoDepthFromPressure(pressure, latitude)
        val recovered = AquaticAlgorithms.pressureFromDepthIterative(depth, latitude)
        assertTrue(abs(recovered - pressure) < 1e-6)
    }

    @Test
    fun secchiMeanUsesBothDirectionalObservations() {
        val result = AquaticAlgorithms.secchi(
            mapOf(
                "disappearance_depth_m" to "4",
                "reappearance_depth_m" to "6",
                "water_depth_m" to "20",
                "calculate_carlson_tsi" to "false"
            )
        )
        assertEquals("succeeded", result.status)
        assertEquals("5", result.values["aquatic_secchi_depth_m"])
    }

    @Test
    fun bottomLimitedSecchiDoesNotReturnTsi() {
        val result = AquaticAlgorithms.secchi(
            mapOf(
                "disappearance_depth_m" to "4",
                "reappearance_depth_m" to "4",
                "water_depth_m" to "4",
                "bottom_reached_before_disappearance" to "true",
                "calculate_carlson_tsi" to "true"
            )
        )
        assertEquals("", result.values["aquatic_secchi_tsi_sd"])
        assertTrue(result.warnings.any { it.contains("bottom", ignoreCase = true) })
    }

    @Test
    fun depthPlanClipsToBottomClearance() {
        val result = AquaticAlgorithms.depthPlan(
            mapOf(
                "strategy" to "explicit",
                "water_depth_m" to "10",
                "bottom_clearance_m" to "1",
                "explicit_depths_m" to "0,5,10"
            )
        )
        assertEquals("3", result.values["aquatic_depth_plan_count"])
        assertTrue(result.values["aquatic_depth_plan_text"].orEmpty().contains("9"))
        assertTrue(result.warnings.isNotEmpty())
    }

    @Test
    fun profileFindsStrongTemperatureGradient() {
        val csv = """
            depth,temperature,salinity,oxygen,density
            0,20,0.1,8,998
            2,19.8,0.1,8,998.1
            4,19.5,0.1,7.8,998.2
            6,14,0.1,6,999
            8,13.8,0.1,5.8,999.1
        """.trimIndent()
        val result = AquaticAlgorithms.profileSummary(mapOf("profile_data" to csv))
        assertEquals("succeeded", result.status)
        val thermocline = result.values["aquatic_profile_thermocline_depth_m"]?.toDoubleOrNull()
        assertTrue(thermocline != null && thermocline in 4.0..6.0)
    }

    @Test
    fun qcDoesNotMutateInputsAndFlagsImpossibleDepth() {
        val input = mapOf(
            "station_water_depth_m" to "10",
            "sample_depth_m" to "12",
            "planned_sample_count" to "4",
            "completed_sample_count" to "3"
        )
        val result = AquaticAlgorithms.fieldQc(input)
        assertEquals("10", input["station_water_depth_m"])
        assertEquals("INCOMPLETE", result.values["aquatic_qc_status"])
        assertTrue((result.values["aquatic_qc_issue_count"]?.toIntOrNull() ?: 0) >= 2)
    }

    @Test
    fun geodesicDistanceIsZeroForSamePoint() {
        assertEquals(0.0, AquaticAlgorithms.geodesicDistanceMeters(51.5, -0.1, 51.5, -0.1), 1e-9)
    }
}
