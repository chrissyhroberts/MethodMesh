package com.example.methodmesh.modules.aquaticfield

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

/**
 * Small module-owned field repository.
 *
 * It intentionally stores local field state separately from MethodMesh execution
 * graph results.  Recording a sample updates durable local state; committing a
 * dashboard snapshot remains a separate execution event.
 */
object AquaticFieldRepository {
    private const val PREFS = "methodmesh_aquaticfield"
    private const val RECORDS = "records_json"
    private const val MAX_RECORDS = 1000

    private const val ACTIVE_STATION = "active_station_id"
    private const val ACTIVE_VISIT = "active_visit_id"
    private const val VISIT_STATUS = "visit_status"
    private const val WATER_DEPTH = "water_depth_m"
    private const val PLANNED_SAMPLES = "planned_samples"
    private const val COMPLETED_SAMPLES = "completed_samples"
    private const val CAST_COUNT = "cast_count"
    private const val SECCHI_DEPTH = "secchi_depth_m"
    private const val QC_ISSUES = "qc_issues"
    private const val LAST_UPDATED = "last_updated_utc"

    fun record(context: Context, capabilityId: String, fields: Map<String, String>) {
        if (fields[AquaticCommonFields.STATUS] != "succeeded") return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = Instant.now().toString()
        val record = JSONObject().apply {
            put("capability_id", capabilityId)
            put("recorded_time_utc", now)
            put("fields", JSONObject(fields))
        }
        val records = readRecords(context)
        records.put(record)
        while (records.length() > MAX_RECORDS) {
            val next = JSONArray()
            for (i in 1 until records.length()) next.put(records.get(i))
            prefs.edit().putString(RECORDS, next.toString()).apply()
            break
        }
        if (records.length() <= MAX_RECORDS) prefs.edit().putString(RECORDS, records.toString()).apply()

        val edit = prefs.edit().putString(LAST_UPDATED, now)
        when (capabilityId) {
            As100AquaticStationVisitMethod.ID -> {
                edit.putString(ACTIVE_STATION, fields["aquatic_station_id"].orEmpty())
                edit.putString(ACTIVE_VISIT, fields["aquatic_visit_id"].orEmpty())
                edit.putString(VISIT_STATUS, fields["aquatic_visit_status"].orEmpty().ifBlank { "open" })
                edit.putString(WATER_DEPTH, fields["aquatic_station_water_depth_m"].orEmpty())
                // A new visit starts a fresh operational counter set.
                edit.putInt(PLANNED_SAMPLES, 0)
                edit.putInt(COMPLETED_SAMPLES, 0)
                edit.putInt(CAST_COUNT, 0)
                edit.putString(SECCHI_DEPTH, "")
                edit.putInt(QC_ISSUES, 0)
            }
            As100AquaticDepthPlanMethod.ID -> {
                edit.putInt(PLANNED_SAMPLES, fields["aquatic_depth_plan_count"]?.toIntOrNull() ?: 0)
            }
            As100AquaticSampleRecordMethod.ID -> {
                edit.putInt(COMPLETED_SAMPLES, prefs.getInt(COMPLETED_SAMPLES, 0) + 1)
            }
            As100AquaticCtdCastMethod.ID -> {
                edit.putInt(CAST_COUNT, prefs.getInt(CAST_COUNT, 0) + 1)
            }
            As100AquaticSecchiMethod.ID -> {
                edit.putString(SECCHI_DEPTH, fields["aquatic_secchi_depth_m"].orEmpty())
            }
            As100AquaticFieldQcMethod.ID -> {
                val issues = fields["aquatic_qc_issue_count"]?.toIntOrNull() ?: 0
                val warnings = fields["aquatic_qc_warning_count"]?.toIntOrNull() ?: 0
                edit.putInt(QC_ISSUES, issues + warnings)
            }
        }
        edit.apply()
    }

    fun snapshot(context: Context): Map<String, String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return linkedMapOf(
            "station_id" to prefs.getString(ACTIVE_STATION, "").orEmpty(),
            "visit_id" to prefs.getString(ACTIVE_VISIT, "").orEmpty(),
            "visit_status" to prefs.getString(VISIT_STATUS, "").orEmpty(),
            "water_depth_m" to prefs.getString(WATER_DEPTH, "").orEmpty(),
            "planned_sample_count" to prefs.getInt(PLANNED_SAMPLES, 0).toString(),
            "completed_sample_count" to prefs.getInt(COMPLETED_SAMPLES, 0).toString(),
            "cast_count" to prefs.getInt(CAST_COUNT, 0).toString(),
            "secchi_depth_m" to prefs.getString(SECCHI_DEPTH, "").orEmpty(),
            "qc_issue_count" to prefs.getInt(QC_ISSUES, 0).toString(),
            "last_updated_utc" to prefs.getString(LAST_UPDATED, "").orEmpty()
        )
    }

    fun finishVisit(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(VISIT_STATUS, "completed")
            .putString(LAST_UPDATED, Instant.now().toString())
            .apply()
    }

    fun clearActiveVisit(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(ACTIVE_STATION)
            .remove(ACTIVE_VISIT)
            .remove(VISIT_STATUS)
            .remove(WATER_DEPTH)
            .remove(PLANNED_SAMPLES)
            .remove(COMPLETED_SAMPLES)
            .remove(CAST_COUNT)
            .remove(SECCHI_DEPTH)
            .remove(QC_ISSUES)
            .putString(LAST_UPDATED, Instant.now().toString())
            .apply()
    }

    fun readRecords(context: Context): JSONArray {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(RECORDS, "[]").orEmpty()
        return runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    }
}
