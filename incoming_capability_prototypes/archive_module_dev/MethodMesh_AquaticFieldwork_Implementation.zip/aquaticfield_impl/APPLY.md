# Applying the Aquatic Fieldwork implementation

This bundle targets MethodMesh `master` commit:

`106ce201eb9d40a4c8b0fd3652773e8e1abcf8ad`

The GitHub connector used to prepare this bundle could read the repository but was not authorised to create a feature branch, so the implementation was deliberately **not** written directly to `master`.

## Files to copy

From the root of this bundle, copy:

```text
app/src/main/java/com/example/methodmesh/modules/aquaticfield/
    -> app/src/main/java/com/example/methodmesh/modules/aquaticfield/

app/src/test/java/com/example/methodmesh/modules/aquaticfield/
    -> app/src/test/java/com/example/methodmesh/modules/aquaticfield/
```

No central module registry edit is needed. MethodMesh discovers `*Module.kt` objects under the module package through its generated module index.

## Roadmap

Insert the contents of `ROADMAP_APPEND.md` under `## Capabilities` in `000_Roadmap.md`.

## Then validate in the real checkout

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

Then perform native/preset/ODK/protocol checks described in the module README.

## Important Development boundaries

- all 16 methods remain `Development`;
- Practical Salinity is PSS-78;
- Absolute Salinity intentionally fails until a validated offline TEOS-10 SAAR implementation/data pack is present;
- pressure/depth is explicitly UNESCO 1983/Saunders rather than falsely labelled `gsw_z_from_p`;
- raw manufacturer-specific CTD processing remains out of scope;
- processed profile data are currently supplied as simple CSV/TSV text; file-picker import remains a Production-promotion task;
- Schmidt stability and whole-lake heat content remain unavailable without explicit geometry/hypsography.
