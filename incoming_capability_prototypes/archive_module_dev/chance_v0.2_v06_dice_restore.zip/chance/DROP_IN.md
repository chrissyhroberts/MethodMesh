# Chance module handoff

This folder is a **Development** prototype built from the Dice Simulator UX v0.7 package.

Per the MethodMesh capability-writing guide, place it first at:

```text
incoming_capability_prototypes/chance/
```

After review and a successful repository build, move the complete folder to:

```text
app/src/main/java/com/example/methodmesh/modules/chance/
```

Do not add a central registry entry. `ChanceModule.kt` is auto-discovered by MethodMesh's generated module index.

Required repository check before admission:

```bash
./gradlew :app:assembleDebug
```

Then exercise all six native capabilities, native presets, orientation changes, fixed-seed replay and the ODK example in `docs/example_odk_Chance.xlsx`.

The existing Dice and Coin method IDs are deliberately preserved as `dice.simulate` and `coin.toss` so prototypes/forms built against the earlier package do not need an immediate method-ID migration. New Chance methods use the `chance.*` namespace.
