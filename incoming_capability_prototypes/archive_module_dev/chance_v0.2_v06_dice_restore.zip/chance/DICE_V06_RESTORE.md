# Dice animation restore — Chance v0.2

The Dice capability in this package intentionally uses `dicesimulator_ux_v0.6.zip` as the canonical last-known-good native UI implementation.

`DiceSimulatorCapabilityScreen.kt` was copied from v0.6 wholesale. The only intentional source changes are:

1. package declaration: `com.example.methodmesh.modules.dicesimulator` → `com.example.methodmesh.modules.chance`
2. native screen title: `Dice Simulator` → `Dice`

No v0.7 tray/layout changes are included in the Dice screen in this revision. In particular, the v0.6 animation state machine, pseudo-3D wireframe rendering, staggered base-roll animation, rule-resolution sequencing, cascading explosion inset animation, reroll animation, keep/drop resolution and Continue/Roll again flow are preserved as the baseline.

The broader Chance module (Coin toss, Draw cards, Pick one, Spinner, Weighted choice) remains from Chance v0.1.

## Validation note

The source has been mechanically compared against the uploaded v0.6 screen after normalising the two intentional package/title changes. Full Android Gradle build validation still needs to be run in the MethodMesh repository.
