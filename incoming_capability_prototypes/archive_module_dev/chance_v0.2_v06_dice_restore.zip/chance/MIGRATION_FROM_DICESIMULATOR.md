# Migration from Dice Simulator to Chance

The former `dicesimulator` module has become the broader **Chance** module.

## Package / module change

- old module ID: `dicesimulator`
- new module ID: `chance`
- old package: `com.example.methodmesh.modules.dicesimulator`
- new package: `com.example.methodmesh.modules.chance`
- display name: `Chance`

## Stable existing method IDs

The existing public method IDs are intentionally unchanged:

- `dice.simulate`
- `coin.toss`

New methods are:

- `chance.cards.draw`
- `chance.pick.one`
- `chance.spinner.spin`
- `chance.weighted.choose`

## Pick one semantics

`Pick one` is intentionally *not* another system-selected random outcome. Chance randomises a concealed arrangement, then the human selects a position. Native mode therefore has a two-stage interaction: **Lay out cards** → **user taps a face-down card**. External callers must supply `selected_position`; they do not get a silently machine-picked position.
