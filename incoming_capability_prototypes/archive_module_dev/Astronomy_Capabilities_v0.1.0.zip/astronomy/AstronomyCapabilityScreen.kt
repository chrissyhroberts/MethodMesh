package com.example.methodmesh.modules.astronomy

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.platform.sensors.PhoneSensorRepository
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.time.Instant
import java.util.concurrent.Executors

private data class AstroInput(val key: String, val label: String, val multiline: Boolean = false, val boolean: Boolean = false)

private class AstronomyCalculationScreen(
    override val capabilityId: String,
    override val title: String,
    override val description: String,
    private val method: AstronomyMethodBase,
    private val inputs: List<AstroInput>
) : CapabilityScreenSpec {
    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val initial = remember(context.action.settings) {
            inputs.associate { it.key to (context.action.settings[it.key] ?: context.action.settings["input_${it.key}"].orEmpty()) }
        }
        var settingsJson by rememberSaveable(context.action.canonicalId) { mutableStateOf(JSONObject(initial).toString()) }
        var resultJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Ready.") }
        val settings = remember(settingsJson) { jsonToMap(settingsJson) }

        fun update(key: String, value: String) {
            settingsJson = JSONObject(settings.toMutableMap().apply { put(key, value) }).toString()
        }

        LaunchedEffect(settingsJson) { context.onSettingsChanged(settings) }

        fun run() {
            val request = method.request(
                action = context.action.canonicalId,
                context = context.request.invocationContext.asMap(context.action.canonicalId) + context.action.settings + settings,
                signals = emptyList(), inputs = emptyList()
            )
            val values = method.calculate(settings)
            val execution = method.result(request, values, context.request.invocationContext)
            status = values[method.mainField].orEmpty().ifBlank { values.values.firstOrNull { it.isNotBlank() }.orEmpty() }
            if (!context.submitsImmediately) {
                result = execution
                resultJson = JSONObject(values).toString()
            }
            if (method.id == As100SessionMethod.id && settings["save_session"]?.toBooleanStrictOrNull() == true && values[SessionFields.JSON].orEmpty().isNotBlank()) {
                runCatching { AstronomyRepository(androidContext).saveSession(JSONObject(values[SessionFields.JSON])) }
            }
            if (context.submitsImmediately) onConfirmed(execution)
        }

        val restored = remember(resultJson) {
            resultJson?.let(::jsonToMap)?.let { values ->
                method.result(
                    method.request(context.action.canonicalId, context.request.invocationContext.asMap(context.action.canonicalId) + context.action.settings + settings, emptyList(), emptyList()),
                    values, context.request.invocationContext
                )
            }
        }
        val captured = result ?: restored

        LaunchedEffect(context.presentationMode, launched) {
            if (context.presentationMode == CapabilityPresentationMode.IntentLaunch && !launched) {
                launched = true
                run()
            }
        }

        CapabilityScreenScaffold(
            title = title, capabilityId = capabilityId, context = context, canGoBack = context.stepNumber > 1,
            capturedResult = captured,
            resultPreview = captured?.let { ex -> mapOf(method.mainField to OutputFormatter.fields(ex, false)[method.mainField]?.toString().orEmpty()) }.orEmpty(),
            onBack = onBack, onRetry = { result = null; resultJson = null; status = "Ready." }, onConfirm = { captured?.let(onConfirmed) }, onCancel = onCancel
        ) {
            Text(description, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            inputs.forEach { spec ->
                if (context.settingShouldBeShown(spec.key)) {
                    if (spec.boolean) {
                        val enabled = settings[spec.key]?.toBooleanStrictOrNull() ?: false
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(spec.label, modifier = Modifier.weight(1f))
                            OutlinedButton(onClick = { update(spec.key, (!enabled).toString()) }) { Text(if (enabled) "On" else "Off") }
                        }
                    } else {
                        OutlinedTextField(
                            value = settings[spec.key].orEmpty(), onValueChange = { update(spec.key, it) },
                            label = { Text(spec.label) }, modifier = Modifier.fillMaxWidth(),
                            minLines = if (spec.multiline) 3 else 1, maxLines = if (spec.multiline) 8 else 1,
                            singleLine = !spec.multiline
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = ::run, modifier = Modifier.fillMaxWidth()) { Text(if (captured == null) "Calculate" else "Calculate again") }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

val AstronomyConditionsCapabilityScreen: CapabilityScreenSpec = AstronomyCalculationScreen(
    As100ConditionsMethod.id, "Astro conditions", "Combine forecast/current conditions into transparent component scores.", As100ConditionsMethod,
    listOf(AstroInput("cloud_cover_pct","Cloud cover (%)"),AstroInput("visibility_m","Visibility (m)"),AstroInput("wind_kmh","Wind (km/h)"),AstroInput("wind_gust_kmh","Wind gust (km/h)"),AstroInput("temperature_c","Temperature (°C)"),AstroInput("humidity_pct","Relative humidity (%)"),AstroInput("use_supplied_dew_point","Use supplied dew point", boolean=true),AstroInput("dew_point_c","Dew point (°C)"),AstroInput("aerosol_optical_depth","Aerosol optical depth"),AstroInput("pm2_5","PM2.5 (µg/m³)"),AstroInput("moon_altitude_deg","Moon altitude (°)"),AstroInput("moon_illumination_pct","Moon illumination (%)"))
)
val ImagingWindowCapabilityScreen: CapabilityScreenSpec = AstronomyCalculationScreen(
    As100ImagingWindowMethod.id,"Tonight's imaging window","Plan the coming night locally; pipe hourly Open-Meteo JSON in a scheduled preset for weather-aware planning.",As100ImagingWindowMethod,
    listOf(AstroInput("latitude","Latitude"),AstroInput("longitude","Longitude"),AstroInput("target_name","Target name (optional)"),AstroInput("use_target","Use target RA/Dec", boolean=true),AstroInput("target_ra_hours","Target RA, decimal hours (optional)"),AstroInput("target_dec_deg","Target declination (optional)"),AstroInput("minimum_altitude_deg","Minimum target altitude"),AstroInput("hours_ahead","Hours ahead"),AstroInput("interval_minutes","Interval minutes"),AstroInput("minimum_score","Usable score threshold"),AstroInput("forecast_json","Hourly forecast JSON (optional/piped)",true))
)
val DewRiskCapabilityScreen: CapabilityScreenSpec = AstronomyCalculationScreen(
    As100DewRiskMethod.id,"Dew risk","Calculate the temperature–dewpoint margin before optics start to wet.",As100DewRiskMethod,
    listOf(AstroInput("temperature_c","Temperature (°C)"),AstroInput("humidity_pct","Relative humidity (%)"),AstroInput("use_supplied_dew_point","Use supplied dew point", boolean=true),AstroInput("dew_point_c","Dew point (°C)"))
)
val ImageScaleCapabilityScreen: CapabilityScreenSpec = AstronomyCalculationScreen(
    As100ImageScaleMethod.id,"Field of view & sampling","Calculate FoV, arcsec/pixel, effective focal length and focal ratio.",As100ImageScaleMethod,
    listOf(AstroInput("focal_length_mm","Focal length (mm)"),AstroInput("aperture_mm","Aperture (mm)"),AstroInput("pixel_size_micron","Pixel size (µm)"),AstroInput("sensor_width_mm","Sensor width (mm)"),AstroInput("sensor_height_mm","Sensor height (mm)"),AstroInput("multiplier","Barlow/reducer multiplier"))
)
val ExposureLimitCapabilityScreen: CapabilityScreenSpec = AstronomyCalculationScreen(
    As100ExposureLimitMethod.id,"Untracked exposure limit","Estimate a pixel-aware star-trail exposure limit and show the 500-rule comparator.",As100ExposureLimitMethod,
    listOf(AstroInput("focal_length_mm","Focal length (mm)"),AstroInput("pixel_size_micron","Pixel size (µm)"),AstroInput("declination_deg","Target declination (°)"),AstroInput("max_trail_pixels","Maximum acceptable trail (px)"),AstroInput("crop_factor","Crop factor"))
)
val SessionCapabilityScreen: CapabilityScreenSpec = AstronomyCalculationScreen(
    As100SessionMethod.id,"Astronomy session","Create a compact result designed to share cleanly to WhatsApp/messages.",As100SessionMethod,
    listOf(AstroInput("target","Target"),AstroInput("start_iso","Start ISO time"),AstroInput("end_iso","End ISO time"),AstroInput("equipment","Equipment",true),AstroInput("conditions_summary","Conditions summary",true),AstroInput("conditions_score","Conditions score"),AstroInput("sky_test_summary","Sky-test summary",true),AstroInput("notes","Notes",true),AstroInput("save_session","Save session locally", boolean=true))
)

object PolarAlignCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PolarAlignMethod.id
    override val title = "Polar alignment"
    override val description = "Point to true/celestial north or south, not magnetic north."

    @Composable override fun Render(context: CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit) {
        val androidContext=LocalContext.current
        var lat by rememberSaveable{mutableStateOf<Double?>(null)}; var lon by rememberSaveable{mutableStateOf<Double?>(null)}; var alt by rememberSaveable{mutableStateOf(0.0)}
        var resultJson by rememberSaveable(context.action.canonicalId){mutableStateOf<String?>(null)}; var result by remember{mutableStateOf<ExecutionResult?>(null)}; var status by rememberSaveable{mutableStateOf("Acquire location, then align the phone away from metal." )}
        var locationGranted by remember{mutableStateOf(hasLocationPermission(androidContext))}; var locationLaunchAttempted by rememberSaveable{mutableStateOf(false)}
        val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){locationGranted=hasLocationPermission(androidContext);if(locationGranted) requestLocation(androidContext,{a,b,c->lat=a;lon=b;alt=c;status="Location acquired."},{status=it})}
        DisposableEffect(androidContext){PhoneSensorRepository.start(androidContext);onDispose{PhoneSensorRepository.stop()}}
        fun acquire(){if(!locationGranted)launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)) else requestLocation(androidContext,{a,b,c->lat=a;lon=b;alt=c;status="Location acquired."},{status=it})}
        LaunchedEffect(context.presentationMode, locationGranted) { if (context.presentationMode == CapabilityPresentationMode.IntentLaunch && !locationLaunchAttempted) { locationLaunchAttempted=true; acquire() } }
        fun capture(){val a=lat;val b=lon;val heading=PhoneSensorRepository.headingDegrees?.toDouble();if(a==null||b==null){status="Acquire location first.";return};if(heading==null){status="Waiting for compass heading.";return};val tolerance=(context.action.settings["alignment_tolerance_deg"]?:"2").toDoubleOrNull()?:2.0;val values=As100PolarAlignMethod.capture(a,b,alt,heading,tolerance);val request=As100PolarAlignMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList());val ex=As100PolarAlignMethod.result(request,values,context.request.invocationContext);status=values[PolarAlignFields.RESULT].orEmpty();if(context.submitsImmediately)onConfirmed(ex) else {result=ex;resultJson=JSONObject(values).toString()}}
        val restored=remember(resultJson){resultJson?.let(::jsonToMap)?.let{As100PolarAlignMethod.result(As100PolarAlignMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),it,context.request.invocationContext)}};val captured=result?:restored
        CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,captured,captured?.let{mapOf(PolarAlignFields.RESULT to OutputFormatter.fields(it,false)[PolarAlignFields.RESULT]?.toString().orEmpty())}.orEmpty(),onBack,{result=null;resultJson=null},{captured?.let(onConfirmed)},onCancel){
            Text("True heading = phone magnetic heading + local geomagnetic declination. Celestial-pole altitude is your absolute latitude.")
            Spacer(Modifier.height(8.dp));Button(onClick=::acquire,modifier=Modifier.fillMaxWidth()){Text(if(lat==null)"Use current location" else "Refresh location")}
            Text(lat?.let{"Location ${"%.5f".format(it)}, ${"%.5f".format(lon)}"}?:"No location yet",style=MaterialTheme.typography.bodySmall)
            Text("Magnetic heading: ${PhoneSensorRepository.headingDegrees?.let{"%.1f°".format(it)}?:"—"}")
            lat?.let{Text("Celestial pole: ${if(it>=0)"true north" else "true south"}, ${"%.1f°".format(kotlin.math.abs(it))} above horizon")}
            Spacer(Modifier.height(8.dp));Button(onClick=::capture,modifier=Modifier.fillMaxWidth()){Text("Capture polar alignment")};Text(status,style=MaterialTheme.typography.bodySmall)
        }
    }
}

object SkyTestCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100SkyTestMethod.id; override val title="Live sky test"; override val description="Measure a bright point source against your saved good-night reference."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
        val androidContext=LocalContext.current;val repo=remember{AstronomyRepository(androidContext)};var cameraGranted by remember{mutableStateOf(ContextCompat.checkSelfPermission(androidContext,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)};var running by rememberSaveable{mutableStateOf(false)};var summaryText by rememberSaveable{mutableStateOf("Centre a bright star and keep the phone fixed.")};var resultJson by rememberSaveable(context.action.canonicalId){mutableStateOf<String?>(null)};var result by remember{mutableStateOf<ExecutionResult?>(null)}
        val analyzer=remember{StarFrameAnalyzer()};val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){cameraGranted=it};val duration=(context.action.settings["duration_seconds"]?:"10").toLongOrNull()?.coerceIn(3,60)?:10
        fun finish(){val summary=analyzer.summary((context.action.settings["minimum_frames"]?:"25").toIntOrNull()?:25);val cal=repo.loadCalibration();val scores=repo.scoreAgainstCalibration(summary,cal);val values=As100SkyTestMethod.capture(summary,scores,cal);val ex=As100SkyTestMethod.result(As100SkyTestMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),values,context.request.invocationContext);summaryText=values[SkyTestFields.RESULT].orEmpty();if(context.submitsImmediately)onConfirmed(ex) else {result=ex;resultJson=JSONObject(values).toString()}}
        LaunchedEffect(running){if(running){analyzer.clear();delay(duration*1000);running=false;finish()}}
        val restored=remember(resultJson){resultJson?.let(::jsonToMap)?.let{As100SkyTestMethod.result(As100SkyTestMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),it,context.request.invocationContext)}};val captured=result?:restored
        CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,captured,captured?.let{mapOf(SkyTestFields.RESULT to OutputFormatter.fields(it,false)[SkyTestFields.RESULT]?.toString().orEmpty())}.orEmpty(),onBack,{result=null;resultJson=null},{captured?.let(onConfirmed)},onCancel){
            if(!cameraGranted){Button(onClick={launcher.launch(Manifest.permission.CAMERA)},modifier=Modifier.fillMaxWidth()){Text("Allow camera")}} else {StarCamera(analyzer,Modifier.fillMaxWidth().height(280.dp));Spacer(Modifier.height(8.dp));Button(onClick={running=true},enabled=!running,modifier=Modifier.fillMaxWidth()){Text(if(running)"Testing…" else "Run ${duration}s sky test")}}
            Text(summaryText,style=MaterialTheme.typography.bodySmall);val current=runCatching{analyzer.summary(10)}.getOrNull();if(current!=null&&current.detectionCount>0){OutlinedButton(onClick={repo.saveCalibration(current,context.action.settings["calibration_note"].orEmpty());summaryText="Saved as good-night calibration. Future results are relative to this baseline."},modifier=Modifier.fillMaxWidth()){Text("Save current sample as GOOD NIGHT calibration")}}
            repo.loadCalibration()?.let{Text("Calibration: ${it.savedAtIso}${if(it.note.isNotBlank())" · ${it.note}" else ""}",style=MaterialTheme.typography.bodySmall)}
        }
    }
}

object FocusCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100FocusMethod.id;override val title="Focus assistant";override val description="Minimise the measured point-source width; lower FWHM is better."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
        val androidContext=LocalContext.current;var granted by remember{mutableStateOf(ContextCompat.checkSelfPermission(androidContext,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)};var live by rememberSaveable{mutableStateOf<Double?>(null)};var best by rememberSaveable{mutableStateOf(Double.POSITIVE_INFINITY)};var resultJson by rememberSaveable(context.action.canonicalId){mutableStateOf<String?>(null)};var result by remember{mutableStateOf<ExecutionResult?>(null)};val handler=remember{Handler(Looper.getMainLooper())};val analyzer=remember{StarFrameAnalyzer(onMetric={m->if(m.detected&&m.fwhmPx.isFinite())handler.post{live=m.fwhmPx;if(m.fwhmPx<best)best=m.fwhmPx}})};val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){granted=it}
        fun capture(){val s=analyzer.summary(10);val b=best.takeIf{it.isFinite()}?:s.medianFwhmPx;val values=As100FocusMethod.capture(s,b);val ex=As100FocusMethod.result(As100FocusMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),values,context.request.invocationContext);if(context.submitsImmediately)onConfirmed(ex) else {result=ex;resultJson=JSONObject(values).toString()}}
        val restored=remember(resultJson){resultJson?.let(::jsonToMap)?.let{As100FocusMethod.result(As100FocusMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),it,context.request.invocationContext)}};val captured=result?:restored
        CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,captured,captured?.let{mapOf(FocusFields.RESULT to OutputFormatter.fields(it,false)[FocusFields.RESULT]?.toString().orEmpty())}.orEmpty(),onBack,{result=null;resultJson=null},{captured?.let(onConfirmed)},onCancel){if(!granted)Button(onClick={launcher.launch(Manifest.permission.CAMERA)}){Text("Allow camera")}else{StarCamera(analyzer,Modifier.fillMaxWidth().height(280.dp));Text("Current FWHM: ${live?.let{"%.2f px".format(it)}?:"—"}");Text("Best: ${best.takeIf{it.isFinite()}?.let{"%.2f px".format(it)}?:"—"}");Row(Modifier.fillMaxWidth()){OutlinedButton(onClick={best=Double.POSITIVE_INFINITY;analyzer.clear()},modifier=Modifier.weight(1f)){Text("Reset best")};Button(onClick=::capture,modifier=Modifier.weight(1f)){Text("Capture focus")}}}}
    }
}

object MountStabilityCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100MountStabilityMethod.id;override val title="Mount stability";override val description="Put the phone firmly on the telescope/tripod and measure vibration."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){val androidContext=LocalContext.current;val sampler=remember{MountStabilitySampler(androidContext)};var running by rememberSaveable{mutableStateOf(false)};var status by rememberSaveable{mutableStateOf("Ready. Avoid touching the mount during the baseline test.")};var resultJson by rememberSaveable(context.action.canonicalId){mutableStateOf<String?>(null)};var result by remember{mutableStateOf<ExecutionResult?>(null)};val duration=(context.action.settings["duration_seconds"]?:"10").toLongOrNull()?.coerceIn(3,60)?:10;DisposableEffect(Unit){onDispose{sampler.stop()}}
        fun finish(){sampler.stop();val values=As100MountStabilityMethod.capture(sampler.summary());val ex=As100MountStabilityMethod.result(As100MountStabilityMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),values,context.request.invocationContext);status=values[MountFields.RESULT].orEmpty();if(context.submitsImmediately)onConfirmed(ex) else {result=ex;resultJson=JSONObject(values).toString()}};LaunchedEffect(running){if(running){sampler.start();delay(duration*1000);running=false;finish()}}
        val restored=remember(resultJson){resultJson?.let(::jsonToMap)?.let{As100MountStabilityMethod.result(As100MountStabilityMethod.request(context.action.canonicalId,context.request.invocationContext.asMap(context.action.canonicalId)+context.action.settings,emptyList(),emptyList()),it,context.request.invocationContext)}};val captured=result?:restored;CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,captured,captured?.let{mapOf(MountFields.RESULT to OutputFormatter.fields(it,false)[MountFields.RESULT]?.toString().orEmpty())}.orEmpty(),onBack,{result=null;resultJson=null},{captured?.let(onConfirmed)},onCancel){Text("Baseline: leave the mount alone. For a tap test, start the run and give the rig one light tap immediately after starting.");Spacer(Modifier.height(8.dp));Button(onClick={running=true},enabled=!running,modifier=Modifier.fillMaxWidth()){Text(if(running)"Measuring…" else "Measure ${duration}s")};Text(status,style=MaterialTheme.typography.bodySmall)}
    }
}

@Composable private fun StarCamera(analyzer:StarFrameAnalyzer,modifier:Modifier){val context=LocalContext.current;val lifecycle=LocalLifecycleOwner.current;val executor=remember{Executors.newSingleThreadExecutor()};var previewView by remember{mutableStateOf<PreviewView?>(null)};var provider by remember{mutableStateOf<ProcessCameraProvider?>(null)}
    AndroidView(factory={ctx->PreviewView(ctx).also{previewView=it}},modifier=modifier.background(Color.Black));LaunchedEffect(previewView,lifecycle){val view=previewView?:return@LaunchedEffect;val future=ProcessCameraProvider.getInstance(context);future.addListener({runCatching{val p=future.get();provider=p;val preview=Preview.Builder().build().also{it.setSurfaceProvider(view.surfaceProvider)};val analysis=ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build().also{it.setAnalyzer(executor,analyzer)};p.unbindAll();p.bindToLifecycle(lifecycle,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis)}},ContextCompat.getMainExecutor(context))};DisposableEffect(Unit){onDispose{provider?.unbindAll();executor.shutdown()}}
}

private fun requestLocation(context:Context,onSuccess:(Double,Double,Double)->Unit,onError:(String)->Unit){if(!hasLocationPermission(context)){onError("Location permission is required.");return};val token=CancellationTokenSource();LocationServices.getFusedLocationProviderClient(context).getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,token.token).addOnSuccessListener{loc->if(loc==null)onError("Current GPS location unavailable.")else onSuccess(loc.latitude,loc.longitude,loc.altitude)}.addOnFailureListener{onError(it.message?:"Location failed.")}}
private fun hasLocationPermission(context:Context)=ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
private fun jsonToMap(json:String):Map<String,String> = runCatching{val o=JSONObject(json.ifBlank{"{}"});buildMap{o.keys().forEach{k->put(k,o.optString(k,""))}}}.getOrDefault(emptyMap())
