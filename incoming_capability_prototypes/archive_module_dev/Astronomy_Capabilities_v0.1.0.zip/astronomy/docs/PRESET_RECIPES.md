# Astronomy preset recipes

These are compositions, not new capability IDs.

## Afternoon "should I set up tonight?"

Suggested scheduled time: **15:00 local**.

```text
Step site
  saved observing-site latitude/longitude
  OR gps.capture

Step weather
  api.get
  config = openmeteo.astronomy_hourly
  (import docs/openmeteo_astronomy_hourly.methodmesh-api.json)
  latitude = ${site.latitude}
  longitude = ${site.longitude}

Step air
  api.get
  config = openmeteo.air_quality_current
  latitude = ${site.latitude}
  longitude = ${site.longitude}

Step conditions
  astronomy.conditions
  cloud_cover_pct = selected forecast/current cloud value
  visibility_m = selected forecast visibility
  wind_kmh = selected wind
  wind_gust_kmh = selected gust
  temperature_c = selected temperature
  humidity_pct = selected humidity
  pm2_5 = ${air.data.current.pm2_5}
  moon fields = optional if separately calculated/exposed

Step window
  astronomy.imaging_window
  latitude = ${site.latitude}
  longitude = ${site.longitude}
  forecast_json = ${weather.data}
  use_target = false

Output
  ${conditions.astronomy_conditions_result}
  ${window.astronomy_window_result}
```

A target-specific version sets `use_target=true`, supplies RA/Dec and can be saved as e.g. **M31 tonight**.

## Telescope setup

```text
astronomy.polar_align
astronomy.mount_stability
astronomy.focus
astronomy.sky_test
```

## End-of-session share

Pipe or paste the relevant summaries into `astronomy.session` and share only:

```text
astronomy_session_result
```
