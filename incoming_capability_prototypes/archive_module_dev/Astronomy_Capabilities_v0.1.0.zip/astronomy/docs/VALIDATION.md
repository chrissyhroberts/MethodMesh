# Astronomy v0.1.0 — validation record

**Status:** Development

## Completed in the packaging environment

- `AstronomyMath.kt` compiled with the available Kotlin/JVM compiler.
- `AstronomyMathSmoke.kt` passed checks covering:
  - image scale / focal ratio;
  - dew-point magnitude;
  - declination-dependent untracked exposure behaviour;
  - good-vs-bad observing-condition score directionality;
  - Polaris clock angle bounds;
  - plausible low-precision solar/lunar declination bounds.
- `AstronomyMethod.kt` + `AstronomyModule.kt` compiled against small contract stubs matching the current MethodMesh public method/module/setting signatures retrieved from the repository.
- The compile-oriented pass confirmed all ten stable method IDs and current `MethodSetting` constructor usage.
- Camera analysis, calibration semantics, and mount metrics were reviewed for explicit **relative/proxy** labelling; no output claims calibrated arcsecond seeing or sky magnitude.
- Calculation logic distinguishes general night planning from target-specific planning through explicit `use_target`.
- Dew calculations distinguish computed dew point from an explicitly supplied dew point through `use_supplied_dew_point`.

## Not completed here

A full Android Gradle build was not available in this packaging environment. The GitHub integration could read the current repository but could not create a feature branch (`403 Resource not accessible by integration`), and the execution container did not have a complete checkout with Android build resolution.

Therefore the following remain required before Production:

```text
./gradlew :app:assembleDebug
```

followed by real-device CameraX, location, sensor, orientation, ODK and share-intent testing listed in `README_Astronomy.md`.

## Scientific interpretation boundary

`astronomy.sky_test` reports same-device/same-setup relative point-source metrics. It is not a DIMM, SQM, calibrated photometer, aerosol monitor, or absolute seeing instrument.

`astronomy.mount_stability` reports phone attachment-point acceleration/rotation metrics. v0.1 class thresholds are engineering heuristics awaiting device characterization.

`astronomy.polar_align` converts a phone magnetic heading with Android geomagnetic declination. Accuracy remains constrained by device magnetometer error, local magnetic interference and the geomagnetic model implementation.
