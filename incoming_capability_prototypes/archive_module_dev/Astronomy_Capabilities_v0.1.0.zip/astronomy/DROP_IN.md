# Astronomy drop-in

Copy this complete folder to:

```text
app/src/main/java/com/example/methodmesh/modules/astronomy/
```

Do not add central registry entries. The current MethodMesh build generates the module index from `*Module.kt` files.

Then run:

```bash
./gradlew :app:assembleDebug
```

Recommended initial device checks:

```text
1. astronomy.image_scale and astronomy.dew_risk (pure calculations)
2. astronomy.polar_align away from metal
3. astronomy.mount_stability on rigid and flexible supports
4. astronomy.focus on a bright star
5. astronomy.sky_test, then save a GOOD NIGHT baseline and repeat
6. import docs/openmeteo_astronomy_hourly.methodmesh-api.json
7. astronomy.imaging_window with an api.get hourly response
8. docs/example_odk_Astronomy.xlsx round trip in ODK Collect
9. astronomy.session and share astronomy_session_result to WhatsApp/messages
```

All methods are intentionally Development in v0.1.0.
