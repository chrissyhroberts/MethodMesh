# GameDeck changelog

## v0.044

- Added generic MethodMesh immersive-host integration through `CapabilityScreenSpec.hostPresentation`; GameDeck requests `CapabilityHostPresentation.Immersive` rather than relying on any capability-specific runtime branch.
- Native GameDeck presentation no longer nests the games inside `CapabilityScreenScaffold`; external/ODK execution retains the normal generic scaffold and completion contract.
- Added a MethodMesh exit control to the GameDeck launcher so immersive mode remains navigable without host chrome.
- Fixed Snakes & Ladders result leakage: legal destination, destination highlight and snake/ladder instruction remain hidden until the die animation has stopped and the settled die has been shown briefly.
- Added a visible Connect Four pickup pile. Dragging must begin from the active player's supply; tapping a board column remains the accessible fallback.
- Added an asset-free retro sound palette using Android `ToneGenerator` for pickup/drop, dice roll, moves, CPU actions and wins.
- Added the `sound` capability setting, enabled by default.

## v0.043

- Reworked the current games toward chunkier, tactile full-screen game surfaces.
- Added stronger persistent player identity and improved game-end presentation.
- Added manual Snakes & Ladders movement and visible Mancala CPU action staging.

## v0.045 — fixed tabletop / two-ended local multiplayer

- Native game play is laid out as a fixed full-screen table rather than a vertically growing page.
- End-of-game result cards are overlays, so they do not make the game surface scroll.
- Added a shared `TabletopFrame` presentation primitive owned by GameDeck.
- In two-human same-device play, Player 2 owns the far end of the device and that player rail is rotated 180°.
- Player 1 owns the near end; the board remains in a stable shared orientation.
- Connect Four and Snakes & Ladders now use the two-ended table directly.
- Mancala uses the same table; its far rail rotates only in 2-player mode and remains upright for CPU play.
- Mancala pots/stores were reduced to fit the full table without requiring scroll.
- Snakes & Ladders board/die sizing was tightened for a fixed play surface.
- This remains capability-local; the MethodMesh runtime still knows only the generic `Immersive` host presentation contract.

## v0.046
- Rebuilt active play as a measured fixed tabletop surface rather than a vertically composed mobile page.
- Added capability-local `TabletopFrame` with fixed far/near player rails and a board rectangle that consumes the remaining viewport.
- Two-human far-player UI is rotated 180°; near-player UI stays upright.
- Snakes & Ladders moves roll/move controls into each player's own rail and removes Secure/Seeded controls from the table surface.
- Board sizing now uses the shorter measured centre dimension so square boards fill available space without scrolling.
- Removed permanent New/Games controls from gameplay; game management now lives behind a compact overlay menu.
- Mancala mode switching is compacted into the far rail; CPU remains upright while human Player 2 rotates.
- No runtime capability special case was added; all changes remain inside GameDeck's immersive presentation.
