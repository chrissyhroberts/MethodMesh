# GameDeck v0.044 implementation notes

## Required generic runtime patch

GameDeck v0.044 deliberately does **not** ask the MethodMesh runtime to recognise GameDeck by ID or module name.

Apply the accompanying `MethodMesh_immersive_capability_host_v0.01.patch` to MethodMesh first. It adds one generic screen declaration:

```kotlin
val hostPresentation: CapabilityHostPresentation
```

with two framework-level values:

```text
Standard
Immersive
```

Every existing capability defaults to `Standard`. GameDeck declares `Immersive`. The generic `FullScreenCapabilityDialog` then either retains normal MethodMesh chrome or gives the capability the complete host surface. No branch contains `gamedeck`, a GameDeck method ID, or any other capability-specific knowledge.

## What to test

1. Open GameDeck from the capability browser. The launcher should occupy the whole capability dialog surface, without the outer Home button, generic capability card, Step 1 of 1 header or nested scaffold padding.
2. `MethodMesh` on the launcher should close the immersive surface and return to MethodMesh.
3. Connect Four should show a visible active-player counter supply above the board. Drag should begin from that pile; board-column tap should still work.
4. Snakes & Ladders: press ROLL D6 and watch carefully. While the die is moving, there must be no destination ring, `Move to …` action, or snake/ladder instruction. The die settles first; the move appears after a short reveal pause.
5. Confirm external/ODK/preset completion still returns normal structured results. Immersive presentation is native chrome policy only; it does not alter execution semantics.
6. Confirm 8-bit sounds are audible with `sound=true` and silent with `sound=false`.

## Architectural invariant

> The runtime knows presentation contracts, never capabilities.

The immersive host facility is available to any future map, whiteboard, simulation, camera, media or other capability that needs a full-bleed operator surface.

## Build check

Run:

```bash
./gradlew :app:assembleDebug
```

The local preparation environment does not contain the full Android repository, so the Android/Compose build cannot be executed here.

## Tabletop invariant (v0.046)

GameDeck treats local multiplayer as a shared physical table:

> When two humans share one device, each player owns one end of the table.

The far human rail is rotated 180 degrees. A CPU rail is not rotated because no person is physically seated at that end. The central game board normally keeps a stable orientation. Gameplay surfaces must fit the available immersive host area; scrolling is not part of the in-game interaction model.
