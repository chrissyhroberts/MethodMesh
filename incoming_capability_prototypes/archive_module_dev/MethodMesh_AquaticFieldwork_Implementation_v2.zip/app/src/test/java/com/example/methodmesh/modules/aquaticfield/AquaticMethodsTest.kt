package com.example.methodmesh.modules.aquaticfield

import org.junit.Assert.assertEquals
import org.junit.Test

class AquaticMethodsTest {
    @Test
    fun sampleIdTemplateAcceptsPublicTypeAlias() {
        val result = As100AquaticSampleIdMethod.calculate(
            mapOf(
                "template" to "{station}-{cast}-{depth}-{type}-{replicate}",
                "station" to "ST01",
                "cast" to "CT02",
                "depth" to "25",
                "type" to "NUT",
                "replicate" to "01"
            )
        )

        assertEquals("ST01-CT02-25-NUT-01", result["aquatic_sample_id"])
        assertEquals("succeeded", result[AquaticCommonFields.STATUS])
    }

    @Test
    fun sampleIdTemplateStillAcceptsNativeSampleTypeSetting() {
        val result = As100AquaticSampleIdMethod.calculate(
            mapOf(
                "template" to "{station}-{type}",
                "station" to "ST01",
                "sample_type" to "eDNA"
            )
        )

        assertEquals("ST01-EDNA", result["aquatic_sample_id"])
    }
}
