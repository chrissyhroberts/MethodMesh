package com.example.methodmesh.modules.astronomy

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

/** Module-owned persistence: explicit good-night calibration and opt-in session history only. */
class AstronomyRepository(context: Context) {
    data class GoodNightCalibration(
        val centroidRmsPx: Double,
        val fwhmPx: Double,
        val backgroundLuma: Double,
        val contrast: Double,
        val scintillationCv: Double,
        val savedAtIso: String,
        val note: String
    )

    private val prefs = context.applicationContext.getSharedPreferences("methodmesh_astronomy", Context.MODE_PRIVATE)

    fun loadCalibration(): GoodNightCalibration? {
        val raw = prefs.getString("good_night_calibration", null) ?: return null
        return runCatching {
            val o = JSONObject(raw)
            GoodNightCalibration(
                o.getDouble("centroid_rms_px"), o.getDouble("fwhm_px"), o.getDouble("background_luma"),
                o.getDouble("contrast"), o.getDouble("scintillation_cv"), o.getString("saved_at_iso"), o.optString("note")
            )
        }.getOrNull()
    }

    fun saveCalibration(summary: StarTestSummary, note: String = "") {
        require(summary.detectionCount > 0 && summary.centroidRmsPx.isFinite() && summary.medianFwhmPx.isFinite())
        val o = JSONObject().apply {
            put("centroid_rms_px", summary.centroidRmsPx)
            put("fwhm_px", summary.medianFwhmPx)
            put("background_luma", summary.medianBackgroundLuma)
            put("contrast", summary.medianContrast)
            put("scintillation_cv", summary.scintillationCv)
            put("saved_at_iso", Instant.now().toString())
            put("note", note)
            put("meaning", "User-marked good-night relative reference; not absolute astronomical seeing calibration")
        }
        prefs.edit().putString("good_night_calibration", o.toString()).apply()
    }

    fun clearCalibration() = prefs.edit().remove("good_night_calibration").apply()

    fun scoreAgainstCalibration(summary: StarTestSummary, calibration: GoodNightCalibration?): Map<String, Int?> {
        if (calibration == null || summary.detectionCount == 0) return mapOf("stability" to null, "transparency" to null, "darkness" to null, "focus" to null, "overall" to null)
        fun ratioGood(reference: Double, current: Double): Int? = if (!reference.isFinite() || !current.isFinite() || current <= 0) null else (100.0 * reference / current).toInt().coerceIn(0, 100)
        fun ratioHigh(reference: Double, current: Double): Int? = if (!reference.isFinite() || !current.isFinite() || reference <= 0) null else (100.0 * current / reference).toInt().coerceIn(0, 100)
        val stability = ratioGood(calibration.centroidRmsPx, summary.centroidRmsPx)
        val transparency = ratioHigh(calibration.contrast, summary.medianContrast)
        val darkness = ratioGood(calibration.backgroundLuma, summary.medianBackgroundLuma)
        val focus = ratioGood(calibration.fwhmPx, summary.medianFwhmPx)
        val vals = listOfNotNull(stability, transparency, darkness, focus)
        val overall = vals.takeIf { it.isNotEmpty() }?.average()?.toInt()?.coerceIn(0, 100)
        return mapOf("stability" to stability, "transparency" to transparency, "darkness" to darkness, "focus" to focus, "overall" to overall)
    }

    fun saveSession(json: JSONObject, maxSessions: Int = 100) {
        val arr = runCatching { JSONArray(prefs.getString("sessions", "[]")) }.getOrElse { JSONArray() }
        arr.put(json)
        val trimmed = JSONArray()
        val start = (arr.length() - maxSessions).coerceAtLeast(0)
        for (i in start until arr.length()) trimmed.put(arr.get(i))
        prefs.edit().putString("sessions", trimmed.toString()).apply()
    }
}
