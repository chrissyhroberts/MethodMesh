package com.example.methodmesh.modules
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.settings.MethodSetting
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
data class RilBinding(val verb:String,val actionId:String,val description:String)
interface MethodMeshModule { val moduleId:String;val displayName:String;val summary:String;val iconKey:String get()=""; fun as100Methods():List<As100Method>;fun rilBindings():List<RilBinding> = emptyList();fun capabilityScreens():List<CapabilityScreenSpec> = emptyList();fun capabilitySettings():Map<String,List<MethodSetting>> = emptyMap() }
