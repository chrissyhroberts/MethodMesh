package com.example.methodmesh.transport.workflow
import com.example.methodmesh.core.methodmesh.InvocationContext
data class ExternalActionRequest(val canonicalId:String="x",val settings:Map<String,String> = emptyMap())
data class ExternalWorkflowRequest(val source:String="dashboard",val settings:Map<String,String> = emptyMap(),val invocationContext:InvocationContext=InvocationContext())
