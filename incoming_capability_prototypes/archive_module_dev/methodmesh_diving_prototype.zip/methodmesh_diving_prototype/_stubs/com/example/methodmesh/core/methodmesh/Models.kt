package com.example.methodmesh.core.methodmesh

data class ArchitectureId(val value:String)
data class ArchitectureRef(val id:ArchitectureId,val objectType:String,val label:String="")
data class RequestId(val value:String)
data class ExecutionRequest(val id:RequestId=RequestId("x"),val method:ArchitectureRef=ArchitectureRef(ArchitectureId("m"),"Method"),val context:Map<String,String> = emptyMap(),val temporalContext:Any?=null)
data class ExecutionResult(val request:ExecutionRequest,val status:TransformationStatus)
class Signal
class InvocationContext { companion object { fun from(m:Map<String,String>)=InvocationContext() }; fun asMap(id:String)=emptyMap<String,String>() }
enum class KnowledgeObjectType { Observation }
enum class MethodObjectType { Calculation }
data class MethodDescriptor(val id:ArchitectureId,val methodType:MethodObjectType,val name:String,val version:String,val description:String,val outputs:List<String>,val graphOutputs:List<String>,val parameters:Map<String,String>)
data class MethodContract(val method:ArchitectureRef,val producedKnowledgeTypes:List<KnowledgeObjectType>,val producedFields:List<String>,val producedGraphOutputs:List<String>)
data class ProvenanceContext(val a:String,val b:String,val c:String)
data class Entity(val id:ArchitectureId,val objectType:String,val temporalContext:Any?=null)
data class Observation(val phenomenon:String,val subject:Any?,val values:Map<String,String>,val temporalContext:Any?,val provenance:ProvenanceContext){val id=ArchitectureId("o");val objectType="Observation"}
enum class TransformationStatus { Succeeded, Failed }
data class Transformation(val action:String,val method:ArchitectureRef,val outputs:List<ArchitectureRef>,val status:TransformationStatus,val temporalContext:Any?,val provenance:ProvenanceContext)
fun ExecutionResult.withInvocationContext(i:InvocationContext?)=this
