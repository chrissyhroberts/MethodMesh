package com.example.methodmesh.transport.workflow.ui
import androidx.compose.runtime.Composable
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ExternalActionRequest
import com.example.methodmesh.transport.workflow.ExternalWorkflowRequest
enum class CapabilityCompletionMode { ManualConfirmation, AutomaticReturn }
enum class CapabilityPresentationMode { Dashboard, IntentLaunch }
data class CapabilityScreenContext(val action:ExternalActionRequest,val request:ExternalWorkflowRequest,val stepNumber:Int=1,val totalSteps:Int=1,val completionMode:CapabilityCompletionMode=CapabilityCompletionMode.ManualConfirmation,val presentationMode:CapabilityPresentationMode=CapabilityPresentationMode.Dashboard,val onSettingsChanged:(Map<String,String>)->Unit={}) { val isNativePresetRun:Boolean get()=request.settings["methodmesh_native_preset_run"]=="true"; val submitsImmediately:Boolean get()=completionMode==CapabilityCompletionMode.AutomaticReturn; fun settingShouldBeShown(settingId:String,alwaysShow:Boolean=false)=true }
interface CapabilityScreenSpec { val capabilityId:String;val title:String;val description:String; @Composable fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit) }
@Composable fun CapabilityScreenScaffold(title:String,capabilityId:String,context:CapabilityScreenContext,canGoBack:Boolean,capturedResult:ExecutionResult?,resultPreview:Map<String,Any?>,onBack:()->Unit,onRetry:()->Unit,onConfirm:()->Unit,onCancel:()->Unit,content:@Composable ()->Unit){content()}
