package com.example.methodmesh.transport
import com.example.methodmesh.core.methodmesh.ExecutionResult
object OutputFormatter { fun fields(r:ExecutionResult,includeProvenance:Boolean=true):Map<String,Any?> = emptyMap() }
