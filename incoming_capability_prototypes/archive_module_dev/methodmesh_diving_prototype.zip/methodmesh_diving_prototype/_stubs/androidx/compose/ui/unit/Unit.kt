package androidx.compose.ui.unit
class Dp(val v:Float)
val Int.dp get()=Dp(toFloat())
val Float.dp get()=Dp(this)
