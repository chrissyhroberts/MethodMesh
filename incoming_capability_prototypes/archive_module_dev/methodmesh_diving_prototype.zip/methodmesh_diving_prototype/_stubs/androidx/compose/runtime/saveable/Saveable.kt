package androidx.compose.runtime.saveable
fun <T> rememberSaveable(vararg keys:Any?, init:()->T)=init()
