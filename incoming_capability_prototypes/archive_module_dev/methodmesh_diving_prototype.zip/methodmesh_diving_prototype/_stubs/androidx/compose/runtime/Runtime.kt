package androidx.compose.runtime
@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE) annotation class Composable
class MutableState<T>(var value:T)
fun <T> mutableStateOf(v:T)=MutableState(v)
operator fun <T> MutableState<T>.getValue(thisRef:Any?,p:kotlin.reflect.KProperty<*>)=value
operator fun <T> MutableState<T>.setValue(thisRef:Any?,p:kotlin.reflect.KProperty<*>,v:T){value=v}
fun <T> remember(vararg keys:Any?, init:()->T)=init()
@Composable fun LaunchedEffect(vararg keys:Any?, block:()->Unit){ }
