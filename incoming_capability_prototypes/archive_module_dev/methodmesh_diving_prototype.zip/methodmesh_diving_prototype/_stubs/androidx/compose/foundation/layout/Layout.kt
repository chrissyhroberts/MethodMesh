package androidx.compose.foundation.layout
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
object Arrangement { object SpaceBetween; class Spaced; fun spacedBy(v:Any)=Spaced() }
fun Modifier.fillMaxWidth()=this
fun Modifier.height(v:Any)=this
fun Modifier.padding(v:Any)=this
fun Modifier.padding(vertical:Any=0,horizontal:Any=0,top:Any=0,bottom:Any=0,start:Any=0,end:Any=0)=this
fun Modifier.weight(v:Float)=this
@Composable fun Column(modifier:Modifier=Modifier, content:@Composable ()->Unit){content()}
@Composable fun Row(modifier:Modifier=Modifier,horizontalArrangement:Any?=null,content:@Composable ()->Unit){content()}
@Composable fun Spacer(modifier:Modifier=Modifier){}
