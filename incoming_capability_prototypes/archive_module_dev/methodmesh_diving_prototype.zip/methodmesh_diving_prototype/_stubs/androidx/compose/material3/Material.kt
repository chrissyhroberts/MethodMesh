package androidx.compose.material3
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
object MaterialTheme { object typography { val bodyMedium=Any();val bodySmall=Any();val labelLarge=Any();val labelMedium=Any();val titleMedium=Any() } }
@Composable fun Text(text:String,modifier:Modifier=Modifier,style:Any?=null,fontWeight:Any?=null){}
@Composable fun Button(onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,content:@Composable ()->Unit){content()}
@Composable fun OutlinedButton(onClick:()->Unit,modifier:Modifier=Modifier,content:@Composable ()->Unit){content()}
@Composable fun Card(modifier:Modifier=Modifier,content:@Composable ()->Unit){content()}
@Composable fun Switch(checked:Boolean,onCheckedChange:(Boolean)->Unit){}
@Composable fun OutlinedTextField(value:String,onValueChange:(String)->Unit,label:(@Composable ()->Unit)?=null,supportingText:(@Composable ()->Unit)?=null,modifier:Modifier=Modifier,singleLine:Boolean=false){}
@Composable fun DropdownMenu(expanded:Boolean,onDismissRequest:()->Unit,content:@Composable ()->Unit){content()}
@Composable fun DropdownMenuItem(text:@Composable ()->Unit,onClick:()->Unit){text()}
