package android.content
open class Context { companion object { const val MODE_PRIVATE=0 }; fun getSharedPreferences(name:String,mode:Int)=SharedPreferences() }
class SharedPreferences { fun getString(k:String,d:String?)=d; fun edit()=Editor() }
class Editor { fun putString(k:String,v:String)=this; fun apply(){} }
