# MethodMesh diving / diveops prototype handoff

## Placement

This package follows the current roadmap rule for work originating outside Work mode: both capability folders are staged under:

```text
incoming_capability_prototypes/
  diving/
  diveops/
```

Each folder is shaped as a self-contained MethodMesh module and can be moved into:

```text
app/src/main/java/com/example/methodmesh/modules/
```

after build/review.

No shared MethodMesh UI/runtime file is intentionally modified by this prototype.

## Implemented

### diving

- 13 calculation/dashboard methods plus 5 record/dashboard methods.
- Pure `DivingAlgorithms` engine.
- Module-owned local repositories for dive log, gas analyses and cylinders.
- Atomic capability screens.
- Three persistent dashboard screens using the documented scaffold-result withholding pattern.
- Canonical MethodSetting declarations, RIL bindings and Development descriptors.
- Safety/audit JSON on every calculation.
- Pure Kotlin smoke tests.
- README and example ODK workbook.

### diveops

- Operation, team, equipment, incident and sample record methods.
- HP-bank endurance, pneumo and umbilical calculations.
- Local repositories.
- Persistent supervisor dashboard.
- Development descriptors, settings, RIL bindings and audit/warning fields.
- Pure Kotlin smoke tests.
- README and example ODK workbook.

## Deliberately excluded

Do not silently add these while admitting the prototype:

- decompression schedules / NDL algorithms;
- repetitive tissue loading;
- omitted-decompression procedures;
- chamber treatment tables;
- equipment/manufacturer-specific supply pressure rules;
- automated legal/compliance determination;
- automatic certification of personnel, medical fitness, cylinders, oxygen cleanliness or plant.

Those require their own model/standard/version/validation architecture.

## Required integration checks

1. Move/copy both module folders into the real `modules/` path in a clean branch.
2. Run `./gradlew :app:assembleDebug`.
3. Fix only module-local API drift first; do not patch shared UI to accommodate these capabilities.
4. Run pure algorithm smoke tests as proper app unit tests or migrate them to JUnit.
5. Run the architecture tests enforcing self-contained module conventions.
6. Exercise every method from:
   - native capability browser;
   - native preset with fixed settings;
   - native preset with runtime inputs;
   - ODK multi-field intent;
   - protocol/sequence execution.
7. Specifically verify dashboard behaviour:
   - normal dashboard remains live after refresh;
   - native preset remains live after refresh;
   - `capturedResult` remains null while live;
   - `Finish`/`Use this snapshot` commits exactly once;
   - external/ODK returns automatically;
   - `intent_test` remains interactive;
   - protocol steps are not trapped.
8. Verify OutputFormatter CORE projection returns the intended headline scalar fields while `_audit_json` and record JSON stay out of the default compact payload.
9. Domain-review all safety wording and reference vectors before any status promotion beyond Development.

## Build limitation of this handoff

The execution container used to prepare the prototype has no network DNS access to clone the GitHub repository, so a full Android Gradle build could not be run here. The connected GitHub API was used to inspect current MethodMesh interfaces and examples; pure calculation engines were compiled and smoke-tested locally.
