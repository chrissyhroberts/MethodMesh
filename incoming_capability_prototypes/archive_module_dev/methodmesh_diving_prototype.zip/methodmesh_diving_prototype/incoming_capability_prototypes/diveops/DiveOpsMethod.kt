package com.example.methodmesh.modules.diveops

import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.Locale
import java.util.UUID

object DiveOpsIds {
    const val OPERATION_RECORD = "diveops.operation.record"
    const val PERSON_RECORD = "diveops.person.record"
    const val EQUIPMENT_RECORD = "diveops.equipment.record"
    const val GAS_ENDURANCE = "diveops.gas.endurance"
    const val PNEUMO = "diveops.pneumo"
    const val UMBILICAL = "diveops.umbilical.geometry"
    const val INCIDENT_RECORD = "diveops.incident.record"
    const val SAMPLE_RECORD = "diveops.sample.record"
    const val DASHBOARD = "diveops.supervisor.dashboard"
}

object DiveOpsFields {
    const val STATUS = "diveops_status"
    const val WARNING = "diveops_warning"
    const val AUDIT_JSON = "diveops_audit_json"
    const val ERROR = "diveops_error"
    const val TIME_ISO = "diveops_time_iso"

    const val OPERATION_ID = "diveops_operation_id"
    const val OPERATION_NAME = "diveops_operation_name"
    const val OPERATION_MAX_DEPTH_M = "diveops_operation_max_depth_m"
    const val OPERATION_BOTTOM_TIME_MIN = "diveops_operation_bottom_time_min"
    const val OPERATION_RECORD_JSON = "diveops_operation_record_json"

    const val PERSON_ID = "diveops_person_id"
    const val PERSON_NAME = "diveops_person_name"
    const val PERSON_ROLE = "diveops_person_role"
    const val PERSON_READY = "diveops_person_ready"
    const val PERSON_RECORD_JSON = "diveops_person_record_json"

    const val EQUIPMENT_ID = "diveops_equipment_id"
    const val EQUIPMENT_LABEL = "diveops_equipment_label"
    const val EQUIPMENT_READY = "diveops_equipment_ready"
    const val EQUIPMENT_RECORD_JSON = "diveops_equipment_record_json"

    const val GAS_AVAILABLE_L = "diveops_gas_available_l"
    const val GAS_CONSUMPTION_L_MIN = "diveops_gas_consumption_l_min"
    const val GAS_ENDURANCE_MIN = "diveops_gas_endurance_min"

    const val PNEUMO_DEPTH_M = "diveops_pneumo_depth_m"
    const val PNEUMO_GAUGE_BAR = "diveops_pneumo_gauge_bar"

    const val UMBILICAL_STRAIGHT_M = "diveops_umbilical_straight_m"
    const val UMBILICAL_PLANNED_M = "diveops_umbilical_planned_m"

    const val INCIDENT_ID = "diveops_incident_id"
    const val INCIDENT_TYPE = "diveops_incident_type"
    const val INCIDENT_RECORD_JSON = "diveops_incident_record_json"

    const val SAMPLE_ID = "diveops_sample_id"
    const val SAMPLE_LABEL = "diveops_sample_label"
    const val SAMPLE_RECORD_JSON = "diveops_sample_record_json"

    const val ACTIVE_OPERATION_COUNT = "diveops_active_operation_count"
    const val PERSON_COUNT = "diveops_person_count"
    const val PERSON_NOT_READY_COUNT = "diveops_person_not_ready_count"
    const val EQUIPMENT_COUNT = "diveops_equipment_count"
    const val EQUIPMENT_NOT_READY_COUNT = "diveops_equipment_not_ready_count"
    const val INCIDENT_COUNT = "diveops_incident_count"
    const val DASHBOARD_JSON = "diveops_dashboard_json"

    val common = listOf(STATUS, WARNING, AUDIT_JSON, ERROR, TIME_ISO)
}

data class DiveOpsMethodSpec(
    val id: String,
    val name: String,
    val description: String,
    val outputs: List<String>,
    val safetyClass: String,
    val calculator: (Map<String, String>) -> Map<String, String>
)

class DiveOpsCalculationMethod(val spec: DiveOpsMethodSpec, private val version: String = "0.1.0") : As100Method {
    override val id = spec.id
    override val ref = ArchitectureRef(ArchitectureId(id), "Method", spec.name)
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(id),
        methodType = MethodObjectType.Calculation,
        name = spec.name,
        version = version,
        description = spec.description,
        outputs = (spec.outputs + DiveOpsFields.common).distinct(),
        graphOutputs = listOf(id),
        parameters = mapOf("category" to "Professional diving", "status" to "Development", "safety_class" to spec.safetyClass)
    )
    override val contract = MethodContract(
        method = ref,
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult =
        result(request, calculate(request.context), InvocationContext.from(request.context))

    fun calculate(settings: Map<String, String>): Map<String, String> = runCatching { spec.calculator(settings) }.getOrElse {
        diveOpsFailure(id, spec.safetyClass, settings, it.message ?: "Calculation failed")
    }

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[DiveOpsFields.STATUS] == "succeeded"
        val provenance = ProvenanceContext("methodmesh.diveops", id, version)
        val observation = Observation(id, null, values, request.temporalContext, provenance)
        val entity = Entity(ArchitectureId("diveops:$id:${System.currentTimeMillis()}"), "DiveOperationSupport", temporalContext = request.temporalContext)
        val transformation = Transformation(
            action = id, method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext, provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request,
            if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOf(entity), observations = listOf(observation), transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf(DiveOpsFields.ERROR to values[DiveOpsFields.ERROR].orEmpty())
        ).withInvocationContext(invocation)
    }
}

object DiveOpsMethods {
    val operationRecord = method(DiveOpsIds.OPERATION_RECORD, "Diving operation record", "Prepare a structured diving-operation record.", listOf(DiveOpsFields.OPERATION_ID, DiveOpsFields.OPERATION_NAME, DiveOpsFields.OPERATION_MAX_DEPTH_M, DiveOpsFields.OPERATION_BOTTOM_TIME_MIN, DiveOpsFields.OPERATION_RECORD_JSON), "record", ::calculateOperationRecord)
    val personRecord = method(DiveOpsIds.PERSON_RECORD, "Dive team person record", "Record a team member, role and operator-entered readiness/qualification metadata.", listOf(DiveOpsFields.PERSON_ID, DiveOpsFields.PERSON_NAME, DiveOpsFields.PERSON_ROLE, DiveOpsFields.PERSON_READY, DiveOpsFields.PERSON_RECORD_JSON), "record", ::calculatePersonRecord)
    val equipmentRecord = method(DiveOpsIds.EQUIPMENT_RECORD, "Diving equipment readiness record", "Record equipment identity, inspection/calibration context, defects and operator readiness state.", listOf(DiveOpsFields.EQUIPMENT_ID, DiveOpsFields.EQUIPMENT_LABEL, DiveOpsFields.EQUIPMENT_READY, DiveOpsFields.EQUIPMENT_RECORD_JSON), "record", ::calculateEquipmentRecord)
    val gasEndurance = method(DiveOpsIds.GAS_ENDURANCE, "Surface-supply gas endurance", "Estimate nominal HP-bank gas endurance at depth from entered consumption and reserve assumptions.", listOf(DiveOpsFields.GAS_AVAILABLE_L, DiveOpsFields.GAS_CONSUMPTION_L_MIN, DiveOpsFields.GAS_ENDURANCE_MIN), "safety_supporting", ::calculateGasEndurance)
    val pneumo = method(DiveOpsIds.PNEUMO, "Pneumofathometer conversion", "Convert gauge pressure to hydrostatic depth, or depth to expected gauge pressure.", listOf(DiveOpsFields.PNEUMO_DEPTH_M, DiveOpsFields.PNEUMO_GAUGE_BAR), "safety_supporting", ::calculatePneumo)
    val umbilical = method(DiveOpsIds.UMBILICAL, "Umbilical geometry", "Estimate geometric umbilical length from depth, horizontal excursion, slack factor and topside allowance.", listOf(DiveOpsFields.UMBILICAL_STRAIGHT_M, DiveOpsFields.UMBILICAL_PLANNED_M), "safety_supporting", ::calculateUmbilical)
    val incident = method(DiveOpsIds.INCIDENT_RECORD, "Diving incident / near-miss record", "Prepare a local incident or near-miss chronology record.", listOf(DiveOpsFields.INCIDENT_ID, DiveOpsFields.INCIDENT_TYPE, DiveOpsFields.INCIDENT_RECORD_JSON), "record", ::calculateIncidentRecord)
    val sample = method(DiveOpsIds.SAMPLE_RECORD, "Underwater sample record", "Prepare a scientific/archaeological sample record with time, depth, location reference and notes.", listOf(DiveOpsFields.SAMPLE_ID, DiveOpsFields.SAMPLE_LABEL, DiveOpsFields.SAMPLE_RECORD_JSON), "record", ::calculateSampleRecord)
    val dashboard = method(DiveOpsIds.DASHBOARD, "Dive supervisor dashboard", "Summarise locally stored operation, team, equipment and incident readiness records.", listOf(DiveOpsFields.ACTIVE_OPERATION_COUNT, DiveOpsFields.PERSON_COUNT, DiveOpsFields.PERSON_NOT_READY_COUNT, DiveOpsFields.EQUIPMENT_COUNT, DiveOpsFields.EQUIPMENT_NOT_READY_COUNT, DiveOpsFields.INCIDENT_COUNT, DiveOpsFields.DASHBOARD_JSON), "operational_dashboard", ::calculateDashboard)

    val all = listOf(operationRecord, personRecord, equipmentRecord, gasEndurance, pneumo, umbilical, incident, sample, dashboard)
    fun byId(id: String) = all.firstOrNull { it.id == id }

    private fun method(id: String, name: String, description: String, outputs: List<String>, safety: String, calculator: (Map<String, String>) -> Map<String, String>) =
        DiveOpsCalculationMethod(DiveOpsMethodSpec(id, name, description, outputs, safety, calculator))
}

private fun calculateOperationRecord(s: Map<String, String>): Map<String, String> {
    val id = s.value("operation_id") ?: newId("op")
    val record = JSONObject().apply {
        put("id", id); put("name", s.value("operation_name").orEmpty()); put("project", s.value("project").orEmpty())
        put("supervisor", s.value("supervisor").orEmpty()); put("date_time_iso", s.value("date_time_iso") ?: Instant.now().toString())
        put("location", s.value("location").orEmpty()); put("task", s.value("task").orEmpty()); put("max_depth_m", s.double("max_depth_m", 0.0))
        put("bottom_time_min", s.double("bottom_time_min", 0.0)); put("decompression_reference", s.value("decompression_reference").orEmpty())
        put("breathing_system", s.value("breathing_system") ?: "surface_supplied_air"); put("environment", s.value("environment").orEmpty())
        put("emergency_plan_reference", s.value("emergency_plan_reference").orEmpty()); put("notes", s.value("notes").orEmpty())
        put("operation_state", s.value("operation_state") ?: "planned"); put("recorded_time_iso", Instant.now().toString())
    }
    val outputs = linkedMapOf(
        DiveOpsFields.OPERATION_ID to id,
        DiveOpsFields.OPERATION_NAME to record.optString("name"),
        DiveOpsFields.OPERATION_MAX_DEPTH_M to fmt(record.optDouble("max_depth_m"), 1),
        DiveOpsFields.OPERATION_BOTTOM_TIME_MIN to fmt(record.optDouble("bottom_time_min"), 1),
        DiveOpsFields.OPERATION_RECORD_JSON to record.toString()
    )
    return diveOpsSuccess(DiveOpsIds.OPERATION_RECORD, "record", s, outputs, listOf("The record captures entered operational information; it does not establish legal/regulatory compliance or replace the diving contractor/supervisor's required records."))
}

private fun calculatePersonRecord(s: Map<String, String>): Map<String, String> {
    val id = s.value("person_id") ?: newId("person")
    val ready = s.bool("ready", false)
    val record = JSONObject().apply {
        put("id", id); put("name", s.value("name").orEmpty()); put("role", s.value("role") ?: "diver")
        put("qualification", s.value("qualification").orEmpty()); put("qualification_expiry", s.value("qualification_expiry").orEmpty())
        put("medical_expiry", s.value("medical_expiry").orEmpty()); put("ready", ready); put("readiness_note", s.value("readiness_note").orEmpty())
        put("updated_time_iso", Instant.now().toString())
    }
    return diveOpsSuccess(DiveOpsIds.PERSON_RECORD, "record", s, linkedMapOf(
        DiveOpsFields.PERSON_ID to id, DiveOpsFields.PERSON_NAME to record.optString("name"), DiveOpsFields.PERSON_ROLE to record.optString("role"),
        DiveOpsFields.PERSON_READY to ready.toString(), DiveOpsFields.PERSON_RECORD_JSON to record.toString()
    ), listOf("Readiness and qualification validity are operator-entered assertions; MethodMesh does not verify credentials or medical fitness."))
}

private fun calculateEquipmentRecord(s: Map<String, String>): Map<String, String> {
    val id = s.value("equipment_id") ?: newId("equipment")
    val ready = s.bool("ready", false)
    val record = JSONObject().apply {
        put("id", id); put("label", s.value("label").orEmpty()); put("category", s.value("category") ?: "other")
        put("serial", s.value("serial").orEmpty()); put("inspection_due", s.value("inspection_due").orEmpty()); put("calibration_due", s.value("calibration_due").orEmpty())
        put("ready", ready); put("defect", s.value("defect").orEmpty()); put("service_note", s.value("service_note").orEmpty()); put("updated_time_iso", Instant.now().toString())
    }
    return diveOpsSuccess(DiveOpsIds.EQUIPMENT_RECORD, "record", s, linkedMapOf(
        DiveOpsFields.EQUIPMENT_ID to id, DiveOpsFields.EQUIPMENT_LABEL to record.optString("label"), DiveOpsFields.EQUIPMENT_READY to ready.toString(), DiveOpsFields.EQUIPMENT_RECORD_JSON to record.toString()
    ), listOf("Readiness is an operator record, not equipment certification or manufacturer approval."))
}

private fun calculateGasEndurance(s: Map<String, String>): Map<String, String> {
    val r = DiveOpsAlgorithms.gasEndurance(
        s.double("bank_water_volume_l", 200.0), s.double("bank_pressure_bar", 200.0), s.double("reserve_pressure_bar", 50.0),
        s.int("diver_count", 1), s.double("per_diver_rmv_l_min", 25.0), s.double("depth_m", 20.0),
        s.double("water_density_kg_m3", 1025.0), s.double("surface_pressure_bar", 1.01325), s.double("contingency_factor", 1.5)
    )
    return diveOpsSuccess(DiveOpsIds.GAS_ENDURANCE, "safety_supporting", s, linkedMapOf(
        DiveOpsFields.GAS_AVAILABLE_L to fmt(r.availableSurfaceGasL, 0), DiveOpsFields.GAS_CONSUMPTION_L_MIN to fmt(r.consumptionSurfaceLMin, 0), DiveOpsFields.GAS_ENDURANCE_MIN to fmt(r.enduranceMin, 1)
    ), listOf("Nominal HP-bank arithmetic only. Compressor delivery, pressure-regulation requirements, leaks, reserve architecture, standby/bell/chamber demand and equipment-specific minimum supply pressures are not modelled."))
}

private fun calculatePneumo(s: Map<String, String>): Map<String, String> {
    val mode = s.value("mode") ?: "pressure_to_depth"
    val density = s.double("water_density_kg_m3", 1025.0)
    val pressure = if (mode == "depth_to_pressure") DiveOpsAlgorithms.pneumoGaugePressureBar(s.double("depth_m", 20.0), density) else s.double("gauge_pressure_bar", 2.0)
    val depth = if (mode == "depth_to_pressure") s.double("depth_m", 20.0) else DiveOpsAlgorithms.pneumoDepthM(pressure, density)
    return diveOpsSuccess(DiveOpsIds.PNEUMO, "safety_supporting", s, linkedMapOf(DiveOpsFields.PNEUMO_DEPTH_M to fmt(depth, 2), DiveOpsFields.PNEUMO_GAUGE_BAR to fmt(pressure, 3)), listOf("Hydrostatic conversion only; instrument calibration, gas-column behaviour, sea state and reference-point geometry are not modelled."))
}

private fun calculateUmbilical(s: Map<String, String>): Map<String, String> {
    val r = DiveOpsAlgorithms.umbilicalLength(s.double("depth_m", 20.0), s.double("horizontal_excursion_m", 20.0), s.double("slack_factor", 1.15), s.double("topside_allowance_m", 5.0))
    return diveOpsSuccess(DiveOpsIds.UMBILICAL, "safety_supporting", s, linkedMapOf(DiveOpsFields.UMBILICAL_STRAIGHT_M to fmt(r.straightLineM, 1), DiveOpsFields.UMBILICAL_PLANNED_M to fmt(r.plannedLengthM, 1)), listOf("Geometry only. Snagging, current, bend radius, tending, reserve length, working-area constraints and project-specific umbilical procedures are not modelled."))
}

private fun calculateIncidentRecord(s: Map<String, String>): Map<String, String> {
    val id = s.value("incident_id") ?: newId("incident")
    val record = JSONObject().apply {
        put("id", id); put("operation_id", s.value("operation_id").orEmpty()); put("type", s.value("incident_type") ?: "near_miss")
        put("date_time_iso", s.value("date_time_iso") ?: Instant.now().toString()); put("person", s.value("person").orEmpty()); put("depth_m", s.double("depth_m", 0.0))
        put("chronology", s.value("chronology").orEmpty()); put("immediate_action", s.value("immediate_action").orEmpty()); put("follow_up", s.value("follow_up").orEmpty())
        put("recorded_time_iso", Instant.now().toString())
    }
    return diveOpsSuccess(DiveOpsIds.INCIDENT_RECORD, "record", s, linkedMapOf(DiveOpsFields.INCIDENT_ID to id, DiveOpsFields.INCIDENT_TYPE to record.optString("type"), DiveOpsFields.INCIDENT_RECORD_JSON to record.toString()), emptyList())
}

private fun calculateSampleRecord(s: Map<String, String>): Map<String, String> {
    val id = s.value("sample_id") ?: newId("sample")
    val record = JSONObject().apply {
        put("id", id); put("label", s.value("label").orEmpty()); put("operation_id", s.value("operation_id").orEmpty()); put("date_time_iso", s.value("date_time_iso") ?: Instant.now().toString())
        put("depth_m", s.double("depth_m", 0.0)); put("location_reference", s.value("location_reference").orEmpty()); put("collector", s.value("collector").orEmpty())
        put("sample_type", s.value("sample_type").orEmpty()); put("container_id", s.value("container_id").orEmpty()); put("notes", s.value("notes").orEmpty())
        put("recorded_time_iso", Instant.now().toString())
    }
    return diveOpsSuccess(DiveOpsIds.SAMPLE_RECORD, "record", s, linkedMapOf(DiveOpsFields.SAMPLE_ID to id, DiveOpsFields.SAMPLE_LABEL to record.optString("label"), DiveOpsFields.SAMPLE_RECORD_JSON to record.toString()), emptyList())
}

private fun calculateDashboard(s: Map<String, String>): Map<String, String> {
    val operations = jsonArrayObjects(s.value("operations_json"))
    val people = jsonArrayObjects(s.value("people_json"))
    val equipment = jsonArrayObjects(s.value("equipment_json"))
    val incidents = jsonArrayObjects(s.value("incidents_json"))
    val active = operations.count { it.optString("operation_state") in setOf("planned", "active") }
    val peopleNotReady = people.count { !it.optBoolean("ready", false) }
    val equipmentNotReady = equipment.count { !it.optBoolean("ready", false) || it.optString("defect").isNotBlank() }
    val data = JSONObject().apply {
        put("operations", JSONArray(operations)); put("people", JSONArray(people)); put("equipment", JSONArray(equipment)); put("incidents", JSONArray(incidents))
    }
    return diveOpsSuccess(DiveOpsIds.DASHBOARD, "operational_dashboard", s.filterKeys { !it.endsWith("_json") }, linkedMapOf(
        DiveOpsFields.ACTIVE_OPERATION_COUNT to active.toString(), DiveOpsFields.PERSON_COUNT to people.size.toString(), DiveOpsFields.PERSON_NOT_READY_COUNT to peopleNotReady.toString(),
        DiveOpsFields.EQUIPMENT_COUNT to equipment.size.toString(), DiveOpsFields.EQUIPMENT_NOT_READY_COUNT to equipmentNotReady.toString(), DiveOpsFields.INCIDENT_COUNT to incidents.size.toString(), DiveOpsFields.DASHBOARD_JSON to data.toString()
    ), buildList {
        if (peopleNotReady > 0) add("One or more stored team records are marked not ready.")
        if (equipmentNotReady > 0) add("One or more stored equipment records are not ready or have a recorded defect.")
        add("Dashboard is a record-completeness/readiness aid only; the diving supervisor/contractor remains responsible for operational decisions and compliance.")
    })
}

private fun diveOpsSuccess(methodId: String, safetyClass: String, inputs: Map<String, String>, outputs: Map<String, String>, warnings: List<String>): Map<String, String> = linkedMapOf<String, String>().apply {
    putAll(outputs); put(DiveOpsFields.STATUS, "succeeded"); put(DiveOpsFields.WARNING, warnings.distinct().joinToString(" | ")); put(DiveOpsFields.ERROR, ""); put(DiveOpsFields.TIME_ISO, Instant.now().toString())
    put(DiveOpsFields.AUDIT_JSON, diveOpsAudit(methodId, safetyClass, inputs, outputs, warnings))
}

private fun diveOpsFailure(methodId: String, safetyClass: String, inputs: Map<String, String>, error: String): Map<String, String> = linkedMapOf(
    DiveOpsFields.STATUS to "failed", DiveOpsFields.WARNING to "", DiveOpsFields.ERROR to error, DiveOpsFields.TIME_ISO to Instant.now().toString(),
    DiveOpsFields.AUDIT_JSON to diveOpsAudit(methodId, safetyClass, inputs, emptyMap(), emptyList(), error)
)

private fun diveOpsAudit(methodId: String, safetyClass: String, inputs: Map<String, String>, outputs: Map<String, String>, warnings: List<String>, error: String = "") = JSONObject().apply {
    put("method_id", methodId); put("module", "diveops"); put("prototype_version", "0.1.0"); put("safety_class", safetyClass); put("time_iso", Instant.now().toString())
    put("inputs", JSONObject(inputs.filterKeys { !it.endsWith("_json") })); put("outputs", JSONObject(outputs)); put("warnings", JSONArray(warnings))
    put("not_authoritative_for", JSONArray(listOf("decompression schedules", "treatment tables", "legal compliance determination", "equipment certification", "supervisor decision-making")))
    if (error.isNotBlank()) put("error", error)
}.toString()

private fun Map<String, String>.value(key: String) = (this[key] ?: this["input_$key"])?.trim()?.takeIf { it.isNotBlank() }
private fun Map<String, String>.double(key: String, default: Double) = value(key)?.toDoubleOrNull() ?: default
private fun Map<String, String>.int(key: String, default: Int) = value(key)?.toIntOrNull() ?: default
private fun Map<String, String>.bool(key: String, default: Boolean) = value(key)?.toBooleanStrictOrNull() ?: default
private fun fmt(v: Double, n: Int) = String.format(Locale.US, "%.${n}f", v)
private fun newId(prefix: String) = "$prefix-${UUID.randomUUID()}"
private fun jsonArrayObjects(raw: String?): List<JSONObject> = runCatching {
    val a = JSONArray(raw ?: "[]"); (0 until a.length()).mapNotNull { a.optJSONObject(it) }
}.getOrDefault(emptyList())
