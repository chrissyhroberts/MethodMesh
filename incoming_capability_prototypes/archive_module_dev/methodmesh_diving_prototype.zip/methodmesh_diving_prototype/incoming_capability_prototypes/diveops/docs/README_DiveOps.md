# MethodMesh Diving Operations capability family — Development prototype v0.1.0

## Purpose

`diveops` is a lightweight professional/commercial/scientific diving operations layer. It is intentionally **not** a certified dive-control or life-support system. Its useful niche is structured capture, audit-friendly readiness summaries and conservative physical calculations that can also be invoked from ODK/protocols.

The module does not determine legal compliance, personnel competence, medical fitness, equipment certification, decompression schedules, treatment tables or go/no-go decisions.

## Public method IDs

| Method | Purpose |
|---|---|
| `diveops.operation.record` | Operation/project/task/supervisor/depth/time/system/plan reference record |
| `diveops.person.record` | Team member/role/qualification-medical reference/readiness record |
| `diveops.equipment.record` | Asset/inspection/calibration/defect/readiness record |
| `diveops.gas.endurance` | Nominal HP-bank surface-equivalent gas endurance |
| `diveops.pneumo` | Pneumofathometer gauge-pressure/depth conversion |
| `diveops.umbilical.geometry` | Geometric umbilical length with entered slack/topside allowance |
| `diveops.incident.record` | Incident/near-miss chronology and response record |
| `diveops.sample.record` | Scientific/archaeological underwater sample record |
| `diveops.supervisor.dashboard` | Persistent local operation/team/equipment/incident readiness summary |

Every result includes `diveops_audit_json` plus explicit warning/error fields.

## Regulatory/standards framing

The schema was designed to be useful alongside professional diving governance, but it deliberately does not claim to implement any ACOP or industry standard automatically.

Relevant current UK/industry references for reviewers include:

- HSE Diving at Work Regulations/ACOP overview: https://www.hse.gov.uk/diving/regulations.htm
- HSE commercial diving projects inland/inshore ACOP (L104): https://www.hse.gov.uk/pubns/books/l104.htm
- HSE recreational diving projects at work ACOP (L105): https://www.hse.gov.uk/pubns/books/l105.htm
- HSE scientific/archaeological diving projects ACOP (L107): https://www.hse.gov.uk/pubns/books/l107.htm
- IMCA D037 surface supplied mixed gas diving systems: https://www.imca-int.com/resources/technical-library/document/1a4b165f-c55b-ee11-8def-6045bdd2c9bc/
- IMCA D040 portable surface supplied systems: https://www.imca-int.com/resources/technical-library/document/17571700-c75b-ee11-8def-6045bdd2c9bc/

Exact requirements vary by jurisdiction, diving project and system. The capability therefore stores plan/schedule/qualification/test references rather than trying to infer compliance from dates or names.

## Operation records

`diveops.operation.record` stores a compact structured record containing operation/project, supervisor, date/time/location, task, max depth, bottom time, breathing-system category, decompression schedule/table reference, environmental factors, emergency-plan reference, state and notes.

The record is intended to complement—never replace—the records required by the applicable diving contractor/supervisor regime.

## Team and equipment readiness

The person and equipment methods expose a deliberately simple operator-entered `ready` state, with supporting qualification/medical or inspection/calibration/defect metadata.

The supervisor dashboard counts records marked not ready. MethodMesh does not turn expiry text into a compliance verdict because:

- regulatory requirements differ by jurisdiction and role;
- recognised qualifications/medical requirements can change;
- equipment inspection/testing intervals depend on plant and governing procedure;
- a date alone cannot establish actual fitness/serviceability.

This is therefore a **readiness register**, not an automated compliance engine.

## Surface-supply gas endurance

Inputs:

- total HP-bank water volume;
- bank pressure;
- reserve pressure;
- number of divers supplied;
- entered per-diver surface RMV;
- working depth;
- contingency multiplier;
- water density / surface pressure.

The calculator estimates nominal usable surface gas and consumption at ambient pressure, then returns endurance in minutes.

It deliberately excludes compressors, regulator/supply-pressure requirements, leaks, standby/bell/chamber demand, HP-bank architecture, changeover procedures and manufacturer minimum pressures. It must not be treated as a standalone surface-supply life-support plan.

## Pneumo conversion

Hydrostatic conversion between gauge pressure and water depth. Instrument zero/calibration, gas-column effects, sea state, hose geometry and reference datum are not modelled.

## Umbilical geometry

Calculates straight-line geometry from vertical depth and horizontal excursion, then applies an entered slack factor plus topside allowance.

It does not decide an operationally adequate umbilical length; snag risk, tending method, current, bends, reserve, worksite geometry and project procedure remain external.

## Incidents and samples

Incident records capture type, operation reference, time, person, depth, chronology and response/follow-up.

Sample records capture sample/container IDs, operation, collection time/depth, location reference, collector, type and notes. This is intended to combine particularly well with MethodMesh GPS/Plus Code, barcode/QR, photo and attestation capabilities in protocols rather than duplicating them here.

## Persistent supervisor dashboard

The dashboard aggregates the local repositories and shows:

- active/planned operations;
- team count;
- team records marked not ready;
- equipment count;
- equipment records not ready or carrying a defect;
- incidents recorded.

It follows the MethodMesh persistent-dashboard pattern: refresh updates live state only; native/native-preset use stays on the dashboard; `Use this snapshot` / `Finish` returns the selected `ExecutionResult`; external/ODK invocation returns a single structured result automatically.

## ODK

MethodMesh multi-field intent example:

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='diveops.pneumo',input_mode='pressure_to_depth',input_gauge_pressure_bar='2.0',input_water_density_kg_m3='1025',return_mode='flat')
```

`docs/example_odk_DiveOps.xlsx` contains one group per public method.

## Development validation

`tests/DiveOpsAlgorithmsSmokeTest.kt` validates gas-endurance arithmetic, pneumo pressure/depth round-trip and umbilical geometry.

Before admission/promotion:

- build in a current MethodMesh checkout with `./gradlew :app:assembleDebug`;
- run native/preset/ODK tests on Android;
- review all professional-diving wording/fields with appropriately competent diving supervisors/domain reviewers;
- compare operation-record fields with the exact governing jurisdiction/ACOP/company system before operational use;
- keep authoritative decompression, treatment and equipment-specific life-support functions outside this generic prototype unless separately validated and versioned.
