package com.example.methodmesh.modules.diveops

import kotlin.math.abs

fun main() {
    val depth = DiveOpsAlgorithms.pneumoDepthM(DiveOpsAlgorithms.pneumoGaugePressureBar(20.0))
    check(abs(depth - 20.0) < 1e-6)
    val umb = DiveOpsAlgorithms.umbilicalLength(30.0, 40.0, 1.2, 5.0)
    check(abs(umb.straightLineM - 50.0) < 1e-6)
    check(abs(umb.plannedLengthM - 65.0) < 1e-6)
    val gas = DiveOpsAlgorithms.gasEndurance(200.0, 200.0, 50.0, 2, 25.0, 20.0)
    check(gas.availableSurfaceGasL == 30000.0)
    check(gas.enduranceMin > 100.0)
    println("DiveOpsAlgorithms smoke tests passed")
}
