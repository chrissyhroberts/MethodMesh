package com.example.methodmesh.modules.diveops

import kotlin.math.sqrt

object DiveOpsAlgorithms {
    const val STANDARD_GRAVITY = 9.80665

    data class GasEnduranceResult(
        val availableSurfaceGasL: Double,
        val consumptionSurfaceLMin: Double,
        val enduranceMin: Double
    )

    fun gasEndurance(
        bankWaterVolumeL: Double,
        bankPressureBar: Double,
        reservePressureBar: Double,
        diverCount: Int,
        perDiverRmvLMin: Double,
        depthM: Double,
        waterDensityKgM3: Double = 1025.0,
        surfacePressureBar: Double = 1.01325,
        contingencyFactor: Double = 1.0
    ): GasEnduranceResult {
        require(bankWaterVolumeL > 0.0)
        require(bankPressureBar >= reservePressureBar && reservePressureBar >= 0.0)
        require(diverCount > 0)
        require(perDiverRmvLMin > 0.0)
        require(depthM >= 0.0)
        require(contingencyFactor > 0.0)
        val available = bankWaterVolumeL * (bankPressureBar - reservePressureBar)
        val ambientBar = surfacePressureBar + waterDensityKgM3 * STANDARD_GRAVITY * depthM / 100000.0
        val ratio = ambientBar / surfacePressureBar
        val consumption = diverCount * perDiverRmvLMin * ratio * contingencyFactor
        return GasEnduranceResult(available, consumption, available / consumption)
    }

    fun pneumoDepthM(gaugePressureBar: Double, waterDensityKgM3: Double = 1025.0): Double {
        require(gaugePressureBar >= 0.0)
        require(waterDensityKgM3 > 0.0)
        return gaugePressureBar * 100000.0 / (waterDensityKgM3 * STANDARD_GRAVITY)
    }

    fun pneumoGaugePressureBar(depthM: Double, waterDensityKgM3: Double = 1025.0): Double {
        require(depthM >= 0.0)
        require(waterDensityKgM3 > 0.0)
        return waterDensityKgM3 * STANDARD_GRAVITY * depthM / 100000.0
    }

    data class UmbilicalResult(val straightLineM: Double, val plannedLengthM: Double)

    fun umbilicalLength(
        depthM: Double,
        horizontalExcursionM: Double,
        slackFactor: Double = 1.15,
        topsideAllowanceM: Double = 5.0
    ): UmbilicalResult {
        require(depthM >= 0.0 && horizontalExcursionM >= 0.0)
        require(slackFactor >= 1.0)
        require(topsideAllowanceM >= 0.0)
        val straight = sqrt(depthM * depthM + horizontalExcursionM * horizontalExcursionM)
        return UmbilicalResult(straight, straight * slackFactor + topsideAllowanceM)
    }
}
