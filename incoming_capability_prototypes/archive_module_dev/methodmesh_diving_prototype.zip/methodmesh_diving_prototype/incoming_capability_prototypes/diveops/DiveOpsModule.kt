package com.example.methodmesh.modules.diveops

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object DiveOpsSettings {
    val all = mapOf(
        DiveOpsIds.OPERATION_RECORD to listOf(
            MethodSetting.TextSetting("operation_id", "Operation ID", "Leave blank for a new record; provide an existing ID to update it.", "Identity", ""),
            MethodSetting.TextSetting("operation_name", "Operation name", group = "Operation", defaultValue = ""),
            MethodSetting.TextSetting("project", "Project / contract", group = "Operation", defaultValue = ""),
            MethodSetting.TextSetting("supervisor", "Diving supervisor", group = "Operation", defaultValue = ""),
            MethodSetting.TextSetting("date_time_iso", "Date/time", "ISO-8601 preferred; blank uses current time.", "Operation", ""),
            MethodSetting.TextSetting("location", "Location / site", group = "Operation", defaultValue = ""),
            MethodSetting.TextSetting("task", "Task / work scope", group = "Operation", defaultValue = ""),
            MethodSetting.FloatSetting("max_depth_m", "Maximum depth", group = "Plan", defaultValue = 0f, minimum = 0f, maximum = 500f, step = 0.5f, unit = "m", decimals = 1),
            MethodSetting.FloatSetting("bottom_time_min", "Bottom time", group = "Plan", defaultValue = 0f, minimum = 0f, maximum = 1440f, step = 1f, unit = "min", decimals = 1),
            MethodSetting.TextSetting("decompression_reference", "Decompression schedule / table reference", "Reference only; MethodMesh does not generate the schedule.", "Plan", ""),
            MethodSetting.ChoiceSetting("breathing_system", "Breathing system", group = "System", defaultValue = "surface_supplied_air", choices = listOf("surface_supplied_air", "surface_supplied_mixed_gas", "scuba", "closed_bell", "other")),
            MethodSetting.TextSetting("environment", "Environmental factors", group = "Operation", defaultValue = ""),
            MethodSetting.TextSetting("emergency_plan_reference", "Emergency plan reference", group = "Safety", defaultValue = ""),
            MethodSetting.ChoiceSetting("operation_state", "Operation state", group = "Operation", defaultValue = "planned", choices = listOf("planned", "active", "completed", "cancelled")),
            MethodSetting.TextSetting("notes", "Notes", group = "Operation", defaultValue = "")
        ),
        DiveOpsIds.PERSON_RECORD to listOf(
            MethodSetting.TextSetting("person_id", "Person ID", "Leave blank for a new record.", "Identity", ""),
            MethodSetting.TextSetting("name", "Name", group = "Person", defaultValue = ""),
            MethodSetting.ChoiceSetting("role", "Role", group = "Person", defaultValue = "diver", choices = listOf("diving_supervisor", "diver", "standby_diver", "tender", "life_support", "chamber_operator", "medic", "scientist", "other")),
            MethodSetting.TextSetting("qualification", "Qualification / competence reference", group = "Readiness", defaultValue = ""),
            MethodSetting.TextSetting("qualification_expiry", "Qualification expiry", group = "Readiness", defaultValue = ""),
            MethodSetting.TextSetting("medical_expiry", "Medical expiry", group = "Readiness", defaultValue = ""),
            MethodSetting.BooleanSetting("ready", "Marked ready for operation", "Operator-entered readiness state only.", "Readiness", false),
            MethodSetting.TextSetting("readiness_note", "Readiness note", group = "Readiness", defaultValue = "")
        ),
        DiveOpsIds.EQUIPMENT_RECORD to listOf(
            MethodSetting.TextSetting("equipment_id", "Equipment ID", "Leave blank for a new record.", "Identity", ""),
            MethodSetting.TextSetting("label", "Equipment label", group = "Equipment", defaultValue = ""),
            MethodSetting.ChoiceSetting("category", "Category", group = "Equipment", defaultValue = "other", choices = listOf("helmet_mask", "umbilical", "communications", "compressor", "hp_bank", "gauge", "gas_analyser", "chamber", "lars", "bailout", "other")),
            MethodSetting.TextSetting("serial", "Serial / asset number", group = "Equipment", defaultValue = ""),
            MethodSetting.TextSetting("inspection_due", "Inspection / test due", group = "Readiness", defaultValue = ""),
            MethodSetting.TextSetting("calibration_due", "Calibration due", group = "Readiness", defaultValue = ""),
            MethodSetting.BooleanSetting("ready", "Marked ready", "Operator-entered readiness state only.", "Readiness", false),
            MethodSetting.TextSetting("defect", "Defect / restriction", group = "Readiness", defaultValue = ""),
            MethodSetting.TextSetting("service_note", "Service note", group = "Readiness", defaultValue = "")
        ),
        DiveOpsIds.GAS_ENDURANCE to listOf(
            MethodSetting.FloatSetting("bank_water_volume_l", "Total bank water volume", group = "Gas bank", defaultValue = 200f, minimum = 1f, maximum = 100000f, step = 1f, unit = "L", decimals = 0),
            MethodSetting.FloatSetting("bank_pressure_bar", "Bank pressure", group = "Gas bank", defaultValue = 200f, minimum = 0f, maximum = 400f, step = 1f, unit = "bar", decimals = 0),
            MethodSetting.FloatSetting("reserve_pressure_bar", "Reserve pressure", group = "Gas bank", defaultValue = 50f, minimum = 0f, maximum = 400f, step = 1f, unit = "bar", decimals = 0),
            MethodSetting.IntSetting("diver_count", "Divers supplied", group = "Demand", defaultValue = 1, minimum = 1, maximum = 20),
            MethodSetting.FloatSetting("per_diver_rmv_l_min", "Per-diver surface RMV", group = "Demand", defaultValue = 25f, minimum = 1f, maximum = 200f, step = 1f, unit = "L/min", decimals = 1),
            MethodSetting.FloatSetting("depth_m", "Working depth", group = "Demand", defaultValue = 20f, minimum = 0f, maximum = 500f, step = 0.5f, unit = "m", decimals = 1),
            MethodSetting.FloatSetting("contingency_factor", "Consumption contingency factor", "Multiplier applied to calculated diver gas demand.", "Demand", 1.5f, 1f, 10f, 0.1f, null, 1),
            MethodSetting.FloatSetting("water_density_kg_m3", "Water density", group = "Environment", defaultValue = 1025f, minimum = 900f, maximum = 1100f, step = 1f, unit = "kg/m³", decimals = 0),
            MethodSetting.FloatSetting("surface_pressure_bar", "Surface absolute pressure", group = "Environment", defaultValue = 1.01325f, minimum = 0.5f, maximum = 1.2f, step = 0.001f, unit = "bar abs", decimals = 3)
        ),
        DiveOpsIds.PNEUMO to listOf(
            MethodSetting.ChoiceSetting("mode", "Conversion", group = "Calculation", defaultValue = "pressure_to_depth", choices = listOf("pressure_to_depth", "depth_to_pressure")),
            MethodSetting.FloatSetting("gauge_pressure_bar", "Gauge pressure", group = "Calculation", defaultValue = 2f, minimum = 0f, maximum = 100f, step = 0.01f, unit = "bar gauge", decimals = 3),
            MethodSetting.FloatSetting("depth_m", "Depth", group = "Calculation", defaultValue = 20f, minimum = 0f, maximum = 1000f, step = 0.1f, unit = "m", decimals = 2),
            MethodSetting.FloatSetting("water_density_kg_m3", "Water density", group = "Environment", defaultValue = 1025f, minimum = 900f, maximum = 1100f, step = 1f, unit = "kg/m³", decimals = 0)
        ),
        DiveOpsIds.UMBILICAL to listOf(
            MethodSetting.FloatSetting("depth_m", "Vertical depth", group = "Geometry", defaultValue = 20f, minimum = 0f, maximum = 1000f, step = 0.5f, unit = "m", decimals = 1),
            MethodSetting.FloatSetting("horizontal_excursion_m", "Horizontal excursion", group = "Geometry", defaultValue = 20f, minimum = 0f, maximum = 5000f, step = 0.5f, unit = "m", decimals = 1),
            MethodSetting.FloatSetting("slack_factor", "Slack factor", group = "Planning", defaultValue = 1.15f, minimum = 1f, maximum = 3f, step = 0.05f, decimals = 2),
            MethodSetting.FloatSetting("topside_allowance_m", "Topside allowance", group = "Planning", defaultValue = 5f, minimum = 0f, maximum = 500f, step = 1f, unit = "m", decimals = 1)
        ),
        DiveOpsIds.INCIDENT_RECORD to listOf(
            MethodSetting.TextSetting("incident_id", "Incident ID", "Leave blank for a new record.", "Identity", ""),
            MethodSetting.TextSetting("operation_id", "Operation ID", group = "Context", defaultValue = ""),
            MethodSetting.ChoiceSetting("incident_type", "Type", group = "Incident", defaultValue = "near_miss", choices = listOf("near_miss", "injury", "equipment_failure", "gas_supply", "loss_of_comms", "decompression_event", "environmental", "other")),
            MethodSetting.TextSetting("date_time_iso", "Date/time", group = "Incident", defaultValue = ""),
            MethodSetting.TextSetting("person", "Person / diver", group = "Incident", defaultValue = ""),
            MethodSetting.FloatSetting("depth_m", "Depth", group = "Incident", defaultValue = 0f, minimum = 0f, maximum = 1000f, step = 0.5f, unit = "m", decimals = 1),
            MethodSetting.TextSetting("chronology", "Chronology", group = "Incident", defaultValue = ""),
            MethodSetting.TextSetting("immediate_action", "Immediate action", group = "Response", defaultValue = ""),
            MethodSetting.TextSetting("follow_up", "Follow-up / reference", group = "Response", defaultValue = "")
        ),
        DiveOpsIds.SAMPLE_RECORD to listOf(
            MethodSetting.TextSetting("sample_id", "Sample ID", "Leave blank for a new record.", "Identity", ""),
            MethodSetting.TextSetting("label", "Sample label", group = "Sample", defaultValue = ""),
            MethodSetting.TextSetting("operation_id", "Operation / dive ID", group = "Context", defaultValue = ""),
            MethodSetting.TextSetting("date_time_iso", "Collection time", group = "Sample", defaultValue = ""),
            MethodSetting.FloatSetting("depth_m", "Collection depth", group = "Sample", defaultValue = 0f, minimum = 0f, maximum = 1000f, step = 0.5f, unit = "m", decimals = 1),
            MethodSetting.TextSetting("location_reference", "GPS / Plus Code / transect reference", group = "Sample", defaultValue = ""),
            MethodSetting.TextSetting("collector", "Collector", group = "Sample", defaultValue = ""),
            MethodSetting.TextSetting("sample_type", "Sample type", group = "Sample", defaultValue = ""),
            MethodSetting.TextSetting("container_id", "Container / bag ID", group = "Sample", defaultValue = ""),
            MethodSetting.TextSetting("notes", "Notes", group = "Sample", defaultValue = "")
        ),
        DiveOpsIds.DASHBOARD to emptyList()
    )

    fun forMethod(id: String) = all[id].orEmpty()
}

object DiveOpsModule : MethodMeshModule {
    override val moduleId = "diveops"
    override val displayName = "Diving operations"
    override val summary = "Professional, commercial and scientific diving operation records, readiness tools and conservative physics helpers."
    override val iconKey = "diveops"
    override fun as100Methods() = DiveOpsMethods.all
    override fun capabilityScreens() = DiveOpsCapabilityScreens.all
    override fun capabilitySettings() = DiveOpsSettings.all
    override fun rilBindings() = listOf(
        RilBinding("record diving operation", DiveOpsIds.OPERATION_RECORD, "Create or update a diving-operation record"),
        RilBinding("record dive team member", DiveOpsIds.PERSON_RECORD, "Record a team member and readiness metadata"),
        RilBinding("record diving equipment", DiveOpsIds.EQUIPMENT_RECORD, "Record equipment readiness and defects"),
        RilBinding("calculate surface supply gas endurance", DiveOpsIds.GAS_ENDURANCE, "Estimate nominal HP-bank endurance"),
        RilBinding("calculate pneumo depth", DiveOpsIds.PNEUMO, "Convert pneumo gauge pressure and depth"),
        RilBinding("calculate umbilical length", DiveOpsIds.UMBILICAL, "Estimate geometric umbilical length"),
        RilBinding("record diving incident", DiveOpsIds.INCIDENT_RECORD, "Record an incident or near miss"),
        RilBinding("record underwater sample", DiveOpsIds.SAMPLE_RECORD, "Record a scientific or archaeological sample"),
        RilBinding("open dive supervisor dashboard", DiveOpsIds.DASHBOARD, "Open the persistent local readiness dashboard")
    )
}
