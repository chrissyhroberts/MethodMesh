package com.example.methodmesh.modules.diveops

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local professional/scientific diving records owned by the diveops module. */
object DiveOpsRepository {
    private const val PREFS = "methodmesh_diveops"
    const val OPERATIONS = "operations"
    const val PEOPLE = "people"
    const val EQUIPMENT = "equipment"
    const val INCIDENTS = "incidents"
    const val SAMPLES = "samples"

    fun all(context: Context, collection: String): List<JSONObject> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(collection, "[]").orEmpty()
        val a = JSONArray(raw.ifBlank { "[]" })
        (0 until a.length()).mapNotNull { a.optJSONObject(it) }
    }.getOrDefault(emptyList())

    fun allJson(context: Context, collection: String): String = JSONArray(all(context, collection)).toString()

    fun upsert(context: Context, collection: String, raw: String): JSONObject? = runCatching {
        val record = JSONObject(raw)
        val id = record.optString("id").takeIf { it.isNotBlank() } ?: return null
        val records = all(context, collection).toMutableList()
        val index = records.indexOfFirst { it.optString("id") == id }
        if (index >= 0) records[index] = record else records.add(record)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(collection, JSONArray(records).toString()).apply()
        record
    }.getOrNull()
}
