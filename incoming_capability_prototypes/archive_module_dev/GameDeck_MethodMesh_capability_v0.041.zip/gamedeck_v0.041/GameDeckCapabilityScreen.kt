package com.example.methodmesh.modules.gamedeck

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONObject

/** GameDeck v0.041: launcher + four real game surfaces + first GameLab surface. */
object GameDeckCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100GameDeckMethod.ID
    override val title = "GameDeck"
    override val description = "A lightweight shelf of games and procedural game experiments."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        var game by rememberSaveable {
            mutableStateOf(context.action.settings["game"] ?: context.action.settings["input_game"] ?: GameDeckEngine.LAUNCHER)
        }
        var rngMode by rememberSaveable {
            mutableStateOf(context.action.settings["rng_mode"] ?: context.action.settings["input_rng_mode"] ?: "secure_random")
        }
        var seed by rememberSaveable {
            mutableStateOf(context.action.settings["seed"] ?: context.action.settings["input_seed"] ?: "")
        }
        var stateJson by rememberSaveable(game) { mutableStateOf(GameDeckEngine.newStateJson(game)) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var mancalaCpu by rememberSaveable { mutableStateOf(true) }

        fun buildResult(): ExecutionResult {
            val summary = GameDeckEngine.stateSummary(stateJson)
            val values = As100GameDeckMethod.snapshot(
                game = summary.game,
                stateJson = stateJson,
                turn = summary.turn,
                winner = summary.winner,
                moveCount = summary.moves,
                rngMode = rngMode,
                seed = seed
            )
            val request = As100GameDeckMethod.request(
                action = As100GameDeckMethod.ID,
                context = context.request.invocationContext.asMap(As100GameDeckMethod.ID) + context.action.settings +
                    mapOf("game" to game, "rng_mode" to rngMode, "seed" to seed),
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100GameDeckMethod.result(request, values, context.request.invocationContext)
        }

        fun refreshSnapshot() { result = buildResult() }
        fun openGame(selected: String) {
            game = selected
            stateJson = GameDeckEngine.newStateJson(selected)
            refreshSnapshot()
        }
        fun reset() {
            stateJson = GameDeckEngine.newStateJson(game)
            refreshSnapshot()
        }
        fun home() { openGame(GameDeckEngine.LAUNCHER) }

        fun playMancala(pit: Int) {
            var next = GameDeckEngine.mancalaMove(stateJson, pit)
            if (mancalaCpu) {
                var safety = 0
                while (JSONObject(next).optString("winner").isBlank() && JSONObject(next).optInt("turn", 0) == 1 && safety++ < 12) {
                    next = GameDeckEngine.mancalaCpuMove(next)
                }
            }
            stateJson = next
            refreshSnapshot()
        }

        LaunchedEffect(game, rngMode, seed) {
            context.onSettingsChanged(mapOf("game" to game, "rng_mode" to rngMode, "seed" to seed))
        }

        LaunchedEffect(context.presentationMode, context.submitsImmediately, context.request.source) {
            val genuineExternalAutoSubmit = context.submitsImmediately && !context.request.source.equals("intent_test", ignoreCase = true)
            if (genuineExternalAutoSubmit && !launched) {
                launched = true
                onConfirmed(buildResult())
            } else if (!launched) {
                launched = true
                refreshSnapshot()
            }
        }

        val keepLiveDashboard = context.presentationMode == CapabilityPresentationMode.Dashboard || context.isNativePresetRun
        val scaffoldResult = if (keepLiveDashboard) null else result
        val summary = GameDeckEngine.stateSummary(stateJson)

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let {
                mapOf(GameDeckFields.RESULT to "${summary.game}: ${summary.moves} moves", GameDeckFields.WINNER to summary.winner)
            }.orEmpty(),
            onBack = onBack,
            onRetry = { reset() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (game == GameDeckEngine.LAUNCHER) {
                    Launcher(onOpen = ::openGame)
                } else {
                    GameHeader(game = game, onHome = ::home, onReset = ::reset)
                    when (game) {
                        GameDeckEngine.CONNECT_FOUR -> ConnectFourGame(
                            stateJson = stateJson,
                            onDrop = { col -> stateJson = GameDeckEngine.connectFourDrop(stateJson, col); refreshSnapshot() }
                        )
                        GameDeckEngine.SNAKES_AND_LADDERS -> SnakesGame(
                            stateJson = stateJson,
                            rngMode = rngMode,
                            seed = seed,
                            onRngMode = { rngMode = it },
                            onRoll = {
                                val (next, _) = GameDeckEngine.snakesRoll(stateJson, rngMode, seed)
                                stateJson = next; refreshSnapshot()
                            }
                        )
                        GameDeckEngine.MANCALA -> MancalaGame(
                            stateJson = stateJson,
                            cpu = mancalaCpu,
                            onCpuChanged = { mancalaCpu = it; reset() },
                            onPit = ::playMancala
                        )
                        GameDeckEngine.MINESWEEPER -> MinesweeperGame(
                            stateJson = stateJson,
                            rngMode = rngMode,
                            onPreset = { w, h, m -> stateJson = GameDeckEngine.minesweeperConfigure(w, h, m, seed); refreshSnapshot() },
                            onReveal = { x, y -> stateJson = GameDeckEngine.minesweeperReveal(stateJson, x, y, rngMode, seed); refreshSnapshot() },
                            onFlag = { x, y -> stateJson = GameDeckEngine.minesweeperToggleFlag(stateJson, x, y); refreshSnapshot() }
                        )
                    }

                    if (summary.winner.isNotBlank()) {
                        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                            Text(summary.winner, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (keepLiveDashboard && result != null && game != GameDeckEngine.LAUNCHER) {
                    Button(onClick = { result?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot")
                    }
                }
            }
        }
    }
}

@Composable
private fun Launcher(onOpen: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("GameDeck", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Pick something to play.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        GameTile("Connect Four", "Drop four in a row", "2P", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.CONNECT_FOUR) }
        GameTile("Snakes & Ladders", "Chance-powered race", "2P", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.SNAKES_AND_LADDERS) }
        GameTile("Mancala", "Kalah with a quick CPU", "CPU", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.MANCALA) }
        GameTile("Minesweeper", "Validated procedural boards", "LAB", Modifier.fillMaxWidth()) { onOpen(GameDeckEngine.MINESWEEPER) }

        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("GameLab", fontWeight = FontWeight.Bold)
                Text("Minesweeper is the first generated game: the board is created after your first move, simulated with a deterministic solver, and rejected when it requires guessing where possible.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun GameTile(title: String, subtitle: String, badge: String, modifier: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(14.dp).height(112.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Text(badge, Modifier.padding(horizontal = 9.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun GameHeader(game: String, onHome: () -> Unit, onReset: () -> Unit) {
    val title = when (game) {
        GameDeckEngine.SNAKES_AND_LADDERS -> "Snakes & Ladders"
        GameDeckEngine.MANCALA -> "Mancala"
        GameDeckEngine.MINESWEEPER -> "Minesweeper"
        else -> "Connect Four"
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(if (game == GameDeckEngine.MINESWEEPER) "GameLab prototype" else "GameDeck", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = onReset) { Text("New") }
            OutlinedButton(onClick = onHome) { Text("Games") }
        }
    }
}

@Composable
private fun ConnectFourGame(stateJson: String, onDrop: (Int) -> Unit) {
    val state = JSONObject(stateJson)
    val board = state.getJSONArray("board")
    val winnerCells = GameDeckEngine.connectFourWinningCells(stateJson)
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.tertiary
    val empty = MaterialTheme.colorScheme.surface
    val boardColor = MaterialTheme.colorScheme.primaryContainer
    val winStroke = MaterialTheme.colorScheme.onPrimaryContainer

    Text("Player ${state.optInt("turn", 1)}", style = MaterialTheme.typography.titleMedium)
    Canvas(
        modifier = Modifier.fillMaxWidth().aspectRatio(7f / 6f).pointerInput(stateJson) {
            detectTapGestures { tap ->
                val col = (tap.x / (size.width / 7f)).toInt().coerceIn(0, 6)
                onDrop(col)
            }
        }
    ) {
        val cw = size.width / 7f
        val ch = size.height / 6f
        drawRoundRect(boardColor, cornerRadius = androidx.compose.ui.geometry.CornerRadius(cw * .24f, cw * .24f))
        for (r in 0..5) for (c in 0..6) {
            val center = Offset((c + .5f) * cw, (r + .5f) * ch)
            val value = board.getJSONArray(r).optInt(c)
            val color = when (value) { 1 -> primary; 2 -> secondary; else -> empty }
            drawCircle(color, radius = minOf(cw, ch) * .34f, center = center)
            if ((r to c) in winnerCells) drawCircle(winStroke, radius = minOf(cw, ch) * .39f, center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f))
        }
    }
    Text("Tap a column to drop a counter.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun SnakesGame(stateJson: String, rngMode: String, seed: String, onRngMode: (String) -> Unit, onRoll: () -> Unit) {
    val state = JSONObject(stateJson)
    val positions = state.getJSONArray("positions")
    val lastRoll = state.optInt("last_roll", 0)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text("P1  ${positions.optInt(0, 1)}", Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
        }
        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text("P2  ${positions.optInt(1, 1)}", Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
        }
        Text("Turn: P${state.optInt("turn", 0) + 1}", style = MaterialTheme.typography.labelLarge)
    }

    SnakesBoard(stateJson)

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        DieFace(value = if (lastRoll == 0) 1 else lastRoll, size = 70.dp)
        Button(onClick = onRoll, enabled = state.optString("winner").isBlank()) { Text("Roll d6") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { onRngMode("secure_random") }, enabled = rngMode != "secure_random") { Text("Secure") }
        OutlinedButton(onClick = { onRngMode("fixed_seed") }, enabled = rngMode != "fixed_seed") { Text("Seeded") }
        if (rngMode == "fixed_seed") Text(seed.ifBlank { "default seed" }, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun SnakesBoard(stateJson: String) {
    val state = JSONObject(stateJson)
    val positions = state.getJSONArray("positions")
    val (ladders, snakes) = GameDeckEngine.snakesTransitions()
    val grid = MaterialTheme.colorScheme.outlineVariant
    val ladderColor = MaterialTheme.colorScheme.primary
    val snakeColor = MaterialTheme.colorScheme.tertiary
    val p1 = MaterialTheme.colorScheme.primary
    val p2 = MaterialTheme.colorScheme.tertiary
    val bg = MaterialTheme.colorScheme.surfaceVariant
    Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
        val cell = size.width / 10f
        drawRoundRect(bg, cornerRadius = androidx.compose.ui.geometry.CornerRadius(14f, 14f))
        for (i in 0..10) {
            drawLine(grid, Offset(i * cell, 0f), Offset(i * cell, size.height), 1.5f)
            drawLine(grid, Offset(0f, i * cell), Offset(size.width, i * cell), 1.5f)
        }
        fun center(square: Int): Offset {
            val zero = square - 1
            val rowFromBottom = zero / 10
            val inRow = zero % 10
            val col = if (rowFromBottom % 2 == 0) inRow else 9 - inRow
            val row = 9 - rowFromBottom
            return Offset((col + .5f) * cell, (row + .5f) * cell)
        }
        ladders.forEach { (a, b) -> drawLine(ladderColor, center(a), center(b), cell * .12f) }
        snakes.forEach { (a, b) ->
            val start = center(a); val end = center(b)
            val path = Path().apply {
                moveTo(start.x, start.y)
                cubicTo(start.x + cell, start.y, end.x - cell, end.y, end.x, end.y)
            }
            drawPath(path, snakeColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = cell * .12f))
        }
        val c1 = center(positions.optInt(0, 1)); val c2 = center(positions.optInt(1, 1))
        drawCircle(p1, cell * .22f, c1 + Offset(-cell * .12f, 0f))
        drawCircle(p2, cell * .22f, c2 + Offset(cell * .12f, 0f))
    }
}

@Composable
private fun DieFace(value: Int, dieSize: Dp) {
    val face = MaterialTheme.colorScheme.surfaceVariant
    val pip = MaterialTheme.colorScheme.onSurface
    Surface(shape = RoundedCornerShape(16.dp), color = face, tonalElevation = 3.dp, modifier = Modifier.size(dieSize)) {
        Canvas(Modifier.padding(10.dp)) {
            val x = listOf(size.width * .22f, size.width * .5f, size.width * .78f)
            val y = listOf(size.height * .22f, size.height * .5f, size.height * .78f)
            val points = when (value.coerceIn(1, 6)) {
                1 -> listOf(1 to 1)
                2 -> listOf(0 to 0, 2 to 2)
                3 -> listOf(0 to 0, 1 to 1, 2 to 2)
                4 -> listOf(0 to 0, 2 to 0, 0 to 2, 2 to 2)
                5 -> listOf(0 to 0, 2 to 0, 1 to 1, 0 to 2, 2 to 2)
                else -> listOf(0 to 0, 2 to 0, 0 to 1, 2 to 1, 0 to 2, 2 to 2)
            }
            points.forEach { (px, py) -> drawCircle(pip, radius = size.width * .075f, center = Offset(x[px], y[py])) }
        }
    }
}

@Composable
private fun MancalaGame(stateJson: String, cpu: Boolean, onCpuChanged: (Boolean) -> Unit, onPit: (Int) -> Unit) {
    val state = JSONObject(stateJson)
    val pits = state.getJSONArray("pits")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { onCpuChanged(true) }, enabled = !cpu) { Text("Vs CPU") }
        OutlinedButton(onClick = { onCpuChanged(false) }, enabled = cpu) { Text("2 players") }
    }
    Text(if (cpu) "You are Player 1" else "Player ${state.optInt("turn", 0) + 1}", style = MaterialTheme.typography.titleMedium)

    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(10.dp)) {
            val gap = 6.dp
            val storeWidth = 42.dp
            val centreWidth = maxWidth - (storeWidth * 2) - (gap * 2)
            val pitWidth = (centreWidth - (5.dp * 5)) / 6
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(gap)) {
                MancalaStore(pits.optInt(13), Modifier.size(width = storeWidth, height = 118.dp))
                Column(Modifier.size(width = centreWidth, height = 118.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        for (pit in 12 downTo 7) MancalaPit(pits.optInt(pit), enabled = !cpu && state.optInt("turn") == 1, Modifier.size(pitWidth)) { onPit(pit) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        for (pit in 0..5) MancalaPit(pits.optInt(pit), enabled = state.optInt("turn") == 0, Modifier.size(pitWidth)) { onPit(pit) }
                    }
                }
                MancalaStore(pits.optInt(6), Modifier.size(width = storeWidth, height = 118.dp))
            }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("P2 store ${pits.optInt(13)}", style = MaterialTheme.typography.bodySmall)
        Text("P1 store ${pits.optInt(6)}", style = MaterialTheme.typography.bodySmall)
    }
    Text("Sow anticlockwise. Landing in your store grants another turn; landing in an empty pit on your side captures the opposite stones.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun MancalaPit(stones: Int, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(onClick = onClick, enabled = enabled && stones > 0, modifier = modifier.aspectRatio(.82f), shape = CircleShape, color = if (enabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Box(contentAlignment = Alignment.Center) { Text(stones.toString(), fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun MancalaStore(stones: Int, modifier: Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(40.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
        Box(contentAlignment = Alignment.Center) { Text(stones.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun MinesweeperGame(stateJson: String, rngMode: String, onPreset: (Int, Int, Int) -> Unit, onReveal: (Int, Int) -> Unit, onFlag: (Int, Int) -> Unit) {
    val state = JSONObject(stateJson)
    val metrics = GameDeckEngine.minesweeperMetrics(stateJson)
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(onClick = { onPreset(8, 8, 8) }) { Text("Calm") }
        OutlinedButton(onClick = { onPreset(9, 9, 10) }) { Text("Classic") }
        OutlinedButton(onClick = { onPreset(12, 12, 22) }) { Text("Dense") }
    }

    MinesweeperBoard(stateJson, onReveal, onFlag)

    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("GameLab", fontWeight = FontWeight.Bold)
                Text(if (state.optBoolean("generated")) if (metrics.noGuessValidated) "VALIDATED" else "FALLBACK" else "WAITING", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Text("${metrics.width}×${metrics.height} • ${metrics.mineCount} mines • ${(metrics.density * 100).toInt()}% density", style = MaterialTheme.typography.bodySmall)
            if (state.optBoolean("generated")) {
                Text("Generator attempts: ${metrics.generationAttempts} • solver passes: ${metrics.solverSteps} • RNG: $rngMode", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Your first tap fixes the opening. GameLab then generates candidate boards and accepts a no-guess-solvable one where possible.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    Text("Tap to reveal • long-press to flag", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun MinesweeperBoard(stateJson: String, onReveal: (Int, Int) -> Unit, onFlag: (Int, Int) -> Unit) {
    val state = JSONObject(stateJson)
    val w = state.optInt("width", 9)
    val h = state.optInt("height", 9)
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cellSize = maxWidth / w
        Column {
            repeat(h) { y ->
                Row {
                    repeat(w) { x ->
                        val cell = GameDeckEngine.minesweeperCell(stateJson, x, y)
                        val bg = when {
                            cell.revealed -> MaterialTheme.colorScheme.surfaceVariant
                            cell.flagged -> MaterialTheme.colorScheme.tertiaryContainer
                            else -> MaterialTheme.colorScheme.primaryContainer
                        }
                        Surface(
                            modifier = Modifier.size(cellSize).padding(.7.dp).pointerInput(stateJson, x, y) {
                                detectTapGestures(onTap = { onReveal(x, y) }, onLongPress = { onFlag(x, y) })
                            },
                            shape = RoundedCornerShape(4.dp),
                            color = bg
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                val label = when {
                                    cell.flagged && !cell.revealed -> "⚑"
                                    cell.revealed && cell.mine -> "✹"
                                    cell.revealed && cell.adjacent > 0 -> cell.adjacent.toString()
                                    else -> ""
                                }
                                if (label.isNotBlank()) Text(label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}
