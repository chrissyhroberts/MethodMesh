# Web Actions v0.06 validation record

Status: **Development / admission candidate**

This module has been reviewed against the MethodMesh v1.05 module-refresh requirements and the current public ODK Central / ODK Web Forms / Enketo API contracts. No claim of Production status is made until a full app build and device integration tests pass.

## Contract inventory

| Capability | Native | Preset | Protocol/schedule | RIL | ODK | Canonical completion |
|---|---|---|---|---|---|---|
| `web.odk_central_roundtrip` | yes | yes | yes | yes | yes | one-shot Central `return_url` |
| `web.precooked_enketo` | yes | yes | yes | yes | yes | one-shot Enketo `return_url` |
| `web.roundtrip` | yes | yes | yes | yes | yes | one-shot callback parameter/placeholder |
| `web.open` | yes | yes | yes | yes | yes | successful browser dispatch only |

All public capabilities have a method descriptor, typed capability settings where appropriate, a capability-specific screen, RIL binding, and ODK example.

## v1.05 UX review

- primary Central workflow is paste link → Open form, not an API configuration screen
- public Central/web-form links require no Enketo/Central API token; API credentials are confined to the separate advanced `web.precooked_enketo` capability
- live web state remains on the capability screen
- returning/backing out is not success
- explicit callback completion is displayed as a live working result
- manual/native use requires Commit to freeze the result
- `submitsImmediately` origins return automatically after the terminal callback, avoiding a redundant second confirmation
- post-Commit result actions use copy/share/save/finish affordances
- displayed canonical values are tap-to-copy
- fixed preset settings are conditionally hidden through `settingShouldBeShown`
- transaction state is durable and resumes across normal recreation

## ODK Central review

Validated in source against the documented Central v2025.2.3+ link behavior:

- Public Access: `/f/<id>?st=<secret>`
- Data Collector new submission: `/projects/<id>/forms/<name>/submissions/new`
- `return_url` supported for redirect-after-submit
- `single=true` added for Data Collector links when absent
- existing Central query parameters are preserved
- legacy `/-/...` links are tolerated; authenticated legacy Data Collector links are converted to the documented `/-/single/...` redirect form
- no renderer assumption: Central can select ODK Web Forms or Enketo
- raw Central URL / `st` are not outputs

Reference: https://docs.getodk.org/central-submissions/

ODK Web Forms is the default for new forms in Central v2026.2.0+ and existing form links continue to reflect the server-selected renderer. File upload and geospatial browser interactions are supported by Web Forms; the embedded WebView delegates file chooser and geolocation permission flows to Android.

Reference: https://docs.getodk.org/web-forms-intro/

## Enketo API review

The programmatic capability uses API v2 semantics:

- POST `/survey/single` or `/survey/single/once`
- `application/x-www-form-urlencoded`
- Basic Authorization `API_KEY:`
- required `server_url` + `form_id`
- optional `return_url`, `theme`, `defaults[/path]`
- response `single_url` / `single_once_url`
- API redirects not followed while credentials are attached

Reference: https://apidocs.enketo.org/v2

## Precook/prefill review

- flat form-node mappings only
- paths must start with `/`
- fixed literal values supported
- runtime references `{{field}}` supported
- lookup includes normalized `input_*` values, invocation context and action/request settings
- protocol-piped previous result fields are therefore available to mappings
- built-ins `{{today}}`, `{{now_iso}}`
- missing runtime source is a visible validation error; it is not silently replaced
- resolved values are not returned in canonical result/audit

## Security/static checks

- callback token generated from 24 SecureRandom bytes
- constant-time callback compare
- top-level-navigation requirement
- SSL fail-closed
- mixed content disabled
- encrypted secret active-state record using Android Keystore AES-GCM
- Central `st`, callback `k`, `return_url`, common credential parameters and prefill/default query values covered by redaction policy
- Central source URI omitted from declared outputs
- API token excluded from typed settings/result context/audit
- no raw callback-injected launch URL in declared outputs

## Required real integration test matrix before Production

1. `:app:compileDebugKotlin` and normal debug app assembly in the current MethodMesh tree.
2. Public Access Link on a current Central server using ODK Web Forms.
3. Public Access Link using Enketo renderer.
4. Authenticated Data Collector `/submissions/new` link, including login/session behavior.
5. Legacy Central Enketo-style link if backwards compatibility is required operationally.
6. Successful submit → callback → live result → Commit/native completion.
7. ODK-originated run → submit → automatic canonical return without extra confirmation.
8. browser back/cancel must not produce success.
9. replay/cross-transaction callback rejection.
10. rotation/activity recreation while a form is active.
11. process recreation / active transaction restoration where Android allows.
12. image/file upload on representative Android WebView versions.
13. geopoint permission grant/deny flow.
14. `st` and callback token absent from flat/FULL outputs and saved result package.
15. precooked Enketo session with fixed + protocol-piped + ODK runtime mappings.
16. invalid/missing mapping source produces visible error and sends no API request.
17. timeout/cancel/failure removes active secret state.

## Packaging checks

Final delivery must contain exactly one top-level `webactions/` folder and no MethodMesh app tree.

## v0.05 kiosk-form repair

- Replaced the fixed-height embedded form panel with a full-screen `Dialog` surface.
- Live Central, Precooked Enketo, and generic roundtrip WebViews now receive the full remaining viewport (`weight(1f)`) instead of a hard-coded 590 dp window.
- Dashboard/setup/result UI is hidden while the form is active.
- Explicit **Exit form** is the only kiosk dismissal path; merely leaving/returning is never treated as successful completion.
- The one-shot callback still drives the automatic transition back to MethodMesh completion/Commit state.
- File chooser, camera/content selection, geolocation delegation, WebView pooling, rotation survival, timeout and callback handling remain on the existing transaction path.

- v0.06 regression: callback roundtrips force terminating single-submit semantics on known Central/Kobo Enketo links so successful submit cannot reset into a second blank record.
- v0.06 regression: callback interception calls `stopLoading()` before leaving the kiosk to avoid a navigation/reset race.
