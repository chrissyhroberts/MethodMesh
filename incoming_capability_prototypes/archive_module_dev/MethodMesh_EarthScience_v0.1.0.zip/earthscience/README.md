# MethodMesh Earth Science utilities v0.1.0

Drop-in Development module for MethodMesh.

## Install

Copy this complete `earthscience/` directory to:

```text
app/src/main/java/com/example/methodmesh/modules/earthscience/
```

Do **not** add manual registry entries. Current MethodMesh module discovery should find `EarthScienceModule.kt` automatically.

Then run:

```bash
./gradlew :app:assembleDebug
```

See `docs/README_EarthScience.md` for the capability contract, inputs/outputs, ODK examples, validation status and source attribution.

## Included methods

- `geodesy.distance_bearing`
- `geodesy.destination`
- `geodesy.wgs84_to_utm`
- `geodesy.utm_to_wgs84`
- `gnss.average_position`
- `structural.plane`
- `structural.plane_capture`
- `structural.line`
- `structural.plane_intersection`
- `geotime.lookup`
- `soil.texture_usda`
- `sediment.grain_size`

Status: **Development**. The pure calculation core is smoke-tested; Android Gradle/ODK/physical sensor validation remains required.
