# Dice Simulator UX revision v0.5

This revision changes advanced dice effects from final-state decoration into staged animation driven by the actual primitive-draw trace.

## Staged rule resolution

The full-screen dice tray now resolves in this order:

1. all base dice roll and settle neutrally;
2. rerolls replay from the primitive draw trace, with the affected die flashing amber before its replacement roll;
3. explosions replay from the primitive draw trace, with the triggering die flashing green before a smaller inset die rolls;
4. cascading explosions continue recursively/iteratively for as long as the engine recorded explosion draws;
5. keep/drop is revealed only after all reroll and explosion chains have finished; affected dice flash red before fading to the final dropped state;
6. the final total is then presented for Continue / Roll again.

No die is greyed out before the keep/drop phase.

## Keep/drop grouping

Keep/drop remains a property of an individual dice term/group in the expression engine. Unlike dice are therefore never compared to one another for keep/drop resolution.

The friendly Roll options panel now lets the user choose the dice group to edit when an expression contains multiple groups. This makes mixed pools such as D6 and D20 explicit rather than silently applying rules across incompatible dice.

## Explosion chains

The engine already supported cascading explosions. The visual layer now exposes them correctly. An explosion chain is displayed as inset dice belonging to the triggering base die, and each trigger in the chain receives its own green flash before the next inset roll appears.

For example, the deterministic Development test seed `cascade-6` with `d6!` produces:

- initial: 6
- explosion 1: 6
- explosion 2: 3
- total: 15

## Dropped explosion chains

Keep/drop operates on the total contribution of the original die, including its explosion chain, as defined by engine evaluation order. If that die is subsequently dropped, the base die and its inset explosion dice fade together after the red drop flash.

## Coin heads artwork

The Heads emblem has been redrawn as an explicitly happy cat: closed smiling eyes, triangular nose, broad upward smile and raised whiskers. Tails remains the MethodMesh three-bar mark.

## Validation

The pure Kotlin engine was recompiled after the UI changes and the existing smoke checks passed. A dedicated cascading-explosion smoke test confirmed a multi-step explosion chain. Full Android Gradle/device validation remains required before Production status.
