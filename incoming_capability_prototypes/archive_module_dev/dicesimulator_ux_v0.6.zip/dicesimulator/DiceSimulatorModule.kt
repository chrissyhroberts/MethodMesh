package com.example.methodmesh.modules.dicesimulator

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object DiceSimulatorModule : MethodMeshModule {
    override val moduleId = "dicesimulator"
    override val displayName = "Dice Simulator"
    override val summary = "Roll simple or advanced RPG dice with a visual dice tray, secure randomness and complete roll details."

    override fun as100Methods() = listOf(As100DiceSimulationMethod, As100CoinTossMethod)

    override fun rilBindings() = listOf(
        RilBinding("roll dice", As100DiceSimulationMethod.ID, "Roll one or more dice"),
        RilBinding("simulate dice", As100DiceSimulationMethod.ID, "Simulate a simple or advanced dice expression"),
        RilBinding("roll d20", As100DiceSimulationMethod.ID, "Roll a twenty-sided die"),
        RilBinding("roll with advantage", As100DiceSimulationMethod.ID, "Roll two d20 and keep the highest"),
        RilBinding("roll with disadvantage", As100DiceSimulationMethod.ID, "Roll two d20 and keep the lowest"),
        RilBinding("roll percentile", As100DiceSimulationMethod.ID, "Roll percentile dice"),
        RilBinding("toss coin", As100CoinTossMethod.ID, "Toss a fair coin one or more times"),
        RilBinding("flip coin", As100CoinTossMethod.ID, "Toss a fair coin one or more times")
    )

    override fun capabilityScreens() = listOf(DiceSimulatorCapabilityScreen, CoinTossCapabilityScreen)

    override fun capabilitySettings() = mapOf(
        As100DiceSimulationMethod.ID to listOf(
            MethodSetting.TextSetting("expression", "Dice expression", defaultValue = "d6"),
            MethodSetting.IntSetting("roll_count", "Number of simulations", defaultValue = 1, minimum = 1, maximum = 1000),
            MethodSetting.BooleanSetting("history_output", "Return full simulation series", defaultValue = true),
            MethodSetting.ChoiceSetting(
                "rng_mode",
                "Random source",
                defaultValue = "secure_random",
                choices = listOf("secure_random", "fixed_seed")
            ),
            MethodSetting.TextSetting("seed", "Fixed seed", defaultValue = ""),
            MethodSetting.ChoiceSetting(
                "animation_mode",
                "Animation",
                defaultValue = "full",
                choices = listOf("full", "fast", "off")
            )
        ),
        As100CoinTossMethod.ID to listOf(
            MethodSetting.IntSetting("toss_count", "Number of tosses", defaultValue = 1, minimum = 1, maximum = 10000),
            MethodSetting.ChoiceSetting(
                "interaction_mode",
                "Single-coin mode",
                defaultValue = "record",
                choices = listOf("record", "just_toss")
            ),
            MethodSetting.BooleanSetting("history_output", "Return full toss series", defaultValue = true),
            MethodSetting.ChoiceSetting(
                "rng_mode",
                "Random source",
                defaultValue = "secure_random",
                choices = listOf("secure_random", "fixed_seed")
            ),
            MethodSetting.TextSetting("seed", "Fixed seed", defaultValue = ""),
            MethodSetting.ChoiceSetting(
                "animation_mode",
                "Animation",
                defaultValue = "full",
                choices = listOf("full", "fast", "off")
            )
        )
    )
}
