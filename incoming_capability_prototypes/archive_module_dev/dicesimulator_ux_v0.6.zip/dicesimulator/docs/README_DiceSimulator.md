# Dice Simulator

**MethodMesh module:** `dicesimulator`  
**Primary method:** `dice.simulate`  
**Secondary convenience method:** `coin.toss`  
**Status:** Development  
**Module version:** 0.2.0

## What this capability does

Dice Simulator provides a lightweight native dice tray for ordinary users and a versioned dice-expression engine for users who need advanced tabletop/RPG mechanics.

The native screen is intentionally usable without dice notation. A user can choose common rolls, add dice groups, change the number of dice and sides, and press **Roll**. If the current roll contains six D6 and one D20, seven individual dice are shown in the tray and all seven animate before settling on their recorded values.

The same method also accepts advanced expressions such as:

- `d20`
- `6d6+d20`
- `2d6+4`
- `4d6kh3`
- `4d6dl1`
- `d20r1`
- `d6rr<3`
- `d6!`
- `d6!>=5`
- `8d6cs>=5`
- `dF`
- `d%`
- `d20+5>=15`

The engine records the primitive random draws and the transformations applied to them. Rerolled, dropped and exploded results therefore remain available in structured roll details instead of disappearing from the record.

Dice Simulator is stateless. Persistent game state such as HP, EXP, mana, character records or leaderboards belongs in a separate tabletop-utilities package rather than this module.

## Design principles

### Beginner first

A user does not need to understand RPG notation. The native screen provides:

- quick rolls for D6, D20, 2D6 and percentile;
- quick configurations for advantage, disadvantage and 4D6-drop-lowest;
- a simple dice-group builder;
- one visible die per die in the expression;
- a single prominent Roll action;
- the final result as the primary native output.

Advanced notation is collapsed by default for a simple roll and available when wanted.

### Professional underneath

The dice-expression engine is not implemented as a collection of named game-system special cases. Advantage is `2d20kh1`; disadvantage is `2d20kl1`. This allows the same primitives to represent mechanics from many systems without making the engine D&D-specific.

The method also returns a complete operation record containing initial draws, rerolls, explosion chains, retained/dropped state, success counts and the final arithmetic/comparison result.

### Outcome first, animation second

The random result is generated before native animation starts. Animation is presentation only and cannot alter the outcome.

This is deliberate. Dice Simulator is a randomisation method with a visual representation, not a physics engine whose simulated collisions decide the result.

## Native workflow

For a normal native run:

1. Open **Dice Simulator**.
2. Choose a quick roll or configure the dice using the simple builder.
3. Optionally open **Advanced notation** and enter an expression directly.
4. Choose the number of simulations when a repeated series is required.
5. Leave **Secure** randomness selected for normal play, or choose **Fixed seed** for reproducible tests/replay.
6. Choose **Full**, **Fast** or **Off** animation.
7. Press **Roll**.
8. The tray animates every base die and then settles on the recorded final round.
9. The primary result is shown clearly. Detailed trace/audit fields remain in the execution result rather than being dumped into the main UI.

When `roll_count > 1`, all rounds are generated and returned. The native dice tray visualises the final round only.

## Native dice tray and visual design

The visual renderer is implemented with Jetpack Compose `Canvas` and module-owned geometry. It deliberately avoids adding a third-party 3D or game engine.

Recognised common dice receive pseudo-3D wireframe geometry:

- D4: tetrahedral geometry;
- D6: cube geometry with pip result display;
- D8: octahedral geometry;
- D10: pentagonal-trapezohedron-style geometry;
- D12: dodecahedral geometry;
- D20: icosahedral geometry;
- other Dn: lightweight generic polyhedral representation.

Each die rotates independently during the cosmetic roll. Rows wrap four dice at a time so a seven-die roll is represented by seven visible dice rather than a single aggregate icon.

Advanced outcomes receive lightweight visual annotations in the settled tray:

- dropped dice are dimmed;
- a rerolled die gets a `↻N` badge showing how many discarded reroll draws exist;
- exploding dice display a `+N` badge for the additional explosion contribution.

The detailed operation chain remains available in `dice_last_roll_details_json` and `dice_audit_json`.

## Dice expression grammar

Version 0.2 intentionally uses a small grammar with no parentheses. Whitespace is ignored.

### Basic dice

| Expression | Meaning |
|---|---|
| `d6` | one six-sided die |
| `2d6` | two six-sided dice |
| `6d6+d20` | six D6 plus one D20 |
| `d%` | percentile alias for D100 |
| `dF` | Fate/Fudge die with faces -1, 0, +1 |

Dice groups may contain 1-100 dice. Numeric dice may have 2-1000 sides. An entire expression may contain at most 100 base dice.

### Arithmetic

Addition and subtraction are supported between dice terms and integer constants.

Examples:

- `d20+5`
- `2d6+3`
- `d20-d4+2`

The expression result is the signed sum of its evaluated terms.

### Keep and drop

| Operator | Meaning |
|---|---|
| `khN` | keep highest N |
| `klN` | keep lowest N |
| `dhN` | drop highest N |
| `dlN` | drop lowest N |

Examples:

- `2d20kh1` — advantage-style roll;
- `2d20kl1` — disadvantage-style roll;
- `4d6dl1` — roll four D6 and drop the lowest;
- `4d6kh3` — equivalent keep-highest form.

Dropped dice remain present in the structured roll record with `retained=false`.

### Rerolls

`r` rerolls once when a condition is met. `rr` repeats until the condition is no longer met.

An omitted comparator means equality.

Examples:

- `d20r1` — if the initial accepted D20 is 1, reroll it once;
- `d6r<=2` — reroll once on 1 or 2;
- `d6rr<3` — repeatedly reroll while the value is below 3.

Discarded reroll values are recorded in `rerolled_values` and in the primitive-draw list.

The parser rejects a repeated reroll condition that matches every possible face, such as `d6rr<7`, because it could never terminate.

### Exploding dice

`!` explodes on the maximum face. A comparator can specify another explosion condition.

Examples:

- `d6!` — roll another D6 after every 6 and add the explosion chain;
- `d6!>=5` — explode on 5 or 6.

Explosion draws are recorded individually and summed into the originating die's `die_total`.

The parser rejects an explosion rule that matches every possible face, such as `d6!>=1`.

### Success-counting pools

Use `cs` followed by a comparator and threshold.

Examples:

- `8d6cs>=5` — roll eight D6 and return the number whose evaluated die total is 5 or greater;
- `10d10cs>=8` — count dice at 8+.

When a dice term uses `cs`, the value contributed by that term is the success count rather than the sum of its retained dice.

### Roll-over / roll-under comparisons

A final comparator evaluates the complete arithmetic result.

Examples:

- `d20+5>=15`
- `d100<=65`

The numeric total is retained and `dice_outcome` is returned as `success` or `failure`.

## Defined evaluation order

The engine uses a documented, versioned evaluation order:

1. Parse the expression.
2. Generate the initial primitive draw for each base die.
3. Apply that term's reroll rule.
4. Evaluate explosions. Explosion draws are themselves passed through the term's reroll rule before their explosion trigger is evaluated.
5. Sum each original die's accepted base value and explosion chain into a die total.
6. Apply keep/drop to die totals.
7. If the term has a success-count rule, count retained die totals that meet it; otherwise sum retained die totals.
8. Apply the term sign and arithmetic across terms.
9. Apply the optional top-level comparison.

This order is part of Dice Simulator engine version `0.2.0`. Some RPG systems define unusual operator interactions differently; those systems should not be assumed equivalent unless their rule semantics match this ordering.

## Randomness

### Secure mode

Normal operation uses `java.security.SecureRandom.nextInt(bound)`.

This is cryptographically strong, OS-seeded pseudorandomness. The capability does **not** claim that each Android device provides a physical true-random source.

Numeric dice use bounded integer generation without hand-written modulo reduction.

### Fixed-seed mode

Fixed-seed mode exists for tests, demonstrations and reproducible replay.

It uses the versioned algorithm:

`methodmesh.sha256_counter_u32_rejection` version `2.0.0`

Each primitive draw derives an unsigned 32-bit candidate from SHA-256 over a domain separator, the hashed seed and a monotonic counter. Rejection sampling avoids modulo bias when mapping to a bounded die.

Reproduction therefore depends on:

- expression;
- seed;
- Dice Simulator engine version;
- deterministic RNG algorithm/version.

The seed and its SHA-256 digest are returned for fixed-seed runs. Do not assume a future engine version will intentionally reproduce an older engine's sequence unless its versioned algorithm contract says so.

## Method: `dice.simulate`

### Input settings

| Setting | Type | Default | Meaning |
|---|---|---:|---|
| `expression` | text | `d6` | dice expression; runtime input when not fixed by a preset |
| `roll_count` | integer | 1 | number of complete simulations, 1-1000 |
| `history_output` | boolean | true | return the requested complete series in `dice_history_json` |
| `rng_mode` | choice | `secure_random` | `secure_random` or `fixed_seed` |
| `seed` | text | empty | required when `rng_mode=fixed_seed` |
| `animation_mode` | choice | `fast` | native-only presentation control: `full`, `fast`, `off` |

`animation_mode` does not affect method randomness or outputs.

### Main/native result

`dice_result`

For a normal numeric roll this is the final numeric result, for example:

`42`

For a top-level comparison it is compactly formatted, for example:

`18 · Success`

The primary result preview intentionally does not dump the audit JSON.

### Output fields

| Field | Meaning |
|---|---|
| `dice_status` | `succeeded` / `failed` |
| `dice_result` | compact user-facing final result |
| `dice_total` | numeric final total |
| `dice_outcome` | `success` / `failure` when a top-level comparison exists |
| `dice_expression` | expression supplied by caller |
| `dice_canonical_expression` | normalised expression used by the engine |
| `dice_roll_count` | number of complete simulations |
| `dice_last_values_csv` | accepted base face for every base die in the final round |
| `dice_last_retained_values_csv` | retained die totals in the final round |
| `dice_totals_csv` | final total for every requested simulation |
| `dice_history_json` | all structured simulation rounds when `history_output=true` |
| `dice_last_roll_details_json` | structured details for the final round regardless of `history_output` |
| `dice_primitive_draw_count` | total primitive RNG draws across the run |
| `dice_rng_mode` | random source mode |
| `dice_seed` | fixed seed when fixed-seed mode is used |
| `dice_seed_sha256` | SHA-256 of the fixed seed |
| `dice_rng_algorithm` | RNG implementation identifier |
| `dice_rng_algorithm_version` | version/`platform` identifier |
| `dice_engine_version` | Dice Simulator semantic engine version |
| `dice_generated_time_iso` | generation timestamp |
| `dice_audit_json` | complete run provenance and every simulation round |
| `dice_error` | human-readable failure reason |

### Detailed round structure

`dice_last_roll_details_json` and each round inside the audit JSON include:

- term source and sign;
- every base die;
- initial face;
- discarded reroll faces;
- accepted base face;
- explosion faces;
- per-die total;
- retained/dropped state;
- success count where applicable;
- term value;
- round total;
- top-level comparison and outcome;
- ordered primitive draws with draw type (`initial`, `reroll`, `explosion`).

## Method: `coin.toss`

Coin toss remains in this package because it is a trivial two-state random primitive that can reuse the same entropy/replay machinery.

### Inputs

| Setting | Type | Default |
|---|---|---:|
| `toss_count` | integer | 1 |
| `history_output` | boolean | true |
| `rng_mode` | choice | `secure_random` |
| `seed` | text | empty |
| `animation_mode` | choice | `fast` |

### Main result

For one toss: `Heads` or `Tails`.

For repeated tosses the main result remains compact, e.g. `Heads · H=6, T=4`. The complete sequence is returned separately when requested.

### Outputs

- `coin_status`
- `coin_result`
- `coin_toss_count`
- `coin_last_toss`
- `coin_heads_count`
- `coin_tails_count`
- `coin_tosses_csv`
- `coin_tosses_json`
- `coin_rng_mode`
- `coin_seed`
- `coin_seed_sha256`
- `coin_rng_algorithm`
- `coin_rng_algorithm_version`
- `coin_engine_version`
- `coin_generated_time_iso`
- `coin_audit_json`
- `coin_error`

## Preset workflow

The capability uses MethodMesh's generic preset machinery; it does not define a capability-specific preset system.

A user can configure and test an expression, save it as a preset, then choose which settings remain runtime inputs.

Examples of useful presets include:

- D20;
- percentile;
- advantage (`2d20kh1`);
- disadvantage (`2d20kl1`);
- ability score (`4d6dl1`);
- a campaign-specific damage expression;
- a fixed success pool.

During a native preset run, fixed settings are hidden through `CapabilityScreenContext.settingShouldBeShown()`. Runtime inputs remain available. ODK callers supply their inputs directly and are not routed through native configuration dialogs.

The quick-roll buttons in the native UI are convenience configurations, not replacements for saved MethodMesh presets.

## ODK/XLSForm workflow

The module includes:

`docs/example_odk_DiceSimulator.xlsx`

The example calls MethodMesh through an XLSForm group and supplies intent extras directly. It demonstrates common dice configurations plus a custom-expression option.

Representative intent:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='dice.simulate',
  input_expression=${dice_expression},
  input_roll_count=${roll_count},
  input_history_output='true',
  input_rng_mode=${rng_mode},
  input_seed=${fixed_seed},
  input_animation_mode='off',
  input_payload_mode='FULL',
  return_mode='flat'
)
```

The example receives the compact result and structured fields including:

- `dice_result`
- `dice_total`
- `dice_outcome`
- `dice_canonical_expression`
- `dice_last_values_csv`
- `dice_last_retained_values_csv`
- `dice_history_json`
- `dice_last_roll_details_json`
- `dice_audit_json`
- `methodmesh_full_json`

ODK does not depend on the native Dice Simulator UI or animation.

## RIL bindings

The module declares convenience bindings for:

- `roll dice`
- `simulate dice`
- `roll d20`
- `roll with advantage`
- `roll with disadvantage`
- `roll percentile`
- `toss coin`
- `flip coin`

The generic runtime remains responsible for resolving intent/settings; the shared dashboard does not contain Dice Simulator-specific code.

## Permissions, services and dependencies

No Android runtime permissions are required.

No network service is contacted.

No third-party graphics, physics or RPG-expression library is required by this prototype. Pseudo-3D rendering uses Jetpack Compose drawing primitives already present in MethodMesh.

## Offline behaviour

Dice Simulator is fully offline.

Secure mode depends only on the Android/JVM platform random source. Fixed-seed mode is fully deterministic and local.

## State and orientation

Native configuration and encoded result values use `rememberSaveable` where appropriate. The animation itself is transient presentation state; if Android recreates the screen during an animation, the already-generated result remains available and the visual can settle directly on it instead of generating another roll.

Intent launch state is saveable so a configuration change should not intentionally trigger a second external simulation.

## Limits and deliberate non-features in v0.2

The current engine deliberately does **not** yet implement every dice-language convention used by every RPG system.

Not currently supported:

- parentheses or nested arithmetic groups;
- multiplication/division;
- custom symbol-faced dice beyond Fate/Fudge;
- named game systems as hard-coded special cases;
- multiple keep/drop rules on one dice term;
- multiple reroll rules on one dice term;
- multiple explosion rules on one dice term;
- botch/fumble subtraction rules;
- success rules that independently count every explosion die rather than the originating die total;
- system-specific precedence that differs from the documented v0.2 evaluation order;
- penetrating/compounding explosion variants;
- a full graphical rule-builder for every advanced operator.

The simple native builder edits ordinary dice groups. If an expression contains advanced rules, the tray still renders the base dice but rule editing is done through the advanced notation field or a quick configuration. A future version can add friendly per-pool advanced controls without changing the expression engine.

For explosion chains, the current settled tray keeps the originating die visible and annotates its extra contribution. It does not yet spawn each explosion die as a separately animated object.

## Migration from the earlier `tabletoprandom` prototype

This module supersedes the Development-only `tabletoprandom` prototype supplied during design discussion.

The prototype method IDs `tabletop.dice.roll` and `tabletop.coin.toss` are intentionally replaced by:

- `dice.simulate`
- `coin.toss`

The deterministic domain separator/version is also changed. Fixed-seed sequences from the earlier Development prototype must therefore not be assumed identical.

Because both versions are Development prototypes, this is the appropriate point to establish the new stable naming and expression architecture before presets/examples become relied upon.

## Validation performed in this handoff

The pure Kotlin engine has been compiled independently with `kotlinc` and smoke-tested for:

- basic D20;
- mixed `6d6+d20`;
- arithmetic modifiers;
- keep/drop;
- one-time reroll;
- repeated reroll;
- maximum and threshold explosions;
- success-count pools;
- Fate/Fudge dice;
- percentile alias;
- top-level comparisons;
- fixed-seed reproducibility;
- D7/D13 secure range checks;
- rejection of non-terminating repeated-reroll/explosion conditions.

This does **not** replace the MethodMesh production checklist.

## Required validation before Production

The module must remain Development until at least:

1. `./gradlew :app:assembleDebug` passes in the complete MethodMesh repository.
2. Focused repo unit tests are added for parser/evaluation semantics.
3. Native simple builder works on device/emulator.
4. Seven-dice and larger trays are checked in portrait and landscape.
5. Full/Fast/Off animation is checked without altering generated results.
6. Advanced notation errors are presented cleanly.
7. Native preset creation works.
8. Native preset runs hide fixed settings and ask only runtime inputs.
9. ODK/XLSForm example round-trips the declared fields.
10. Orientation changes preserve the generated result and do not duplicate intent execution.
11. Main sharing sends the useful compact result rather than the full audit JSON.
12. Documentation and repository `000_Roadmap.md` are updated when merged.

## Canonical delivery

Copy this folder to:

```text
app/src/main/java/com/example/methodmesh/modules/dicesimulator/
```

No shared dashboard registration should be added. MethodMesh discovers `DiceSimulatorModule.kt` through its generated module index.

## Native interaction flow (v0.3 prototype)

The native UI separates configuration from the animated event.

### Dice

1. Configure the roll using quiet dice-group rows: quantity controls plus one die-type dropdown.
2. Press **ROLL**.
3. MethodMesh enters a full-screen dice tray. Every base die is shown separately (for example `6d6+d20` shows seven dice).
4. Full animation runs for roughly 1.8 seconds. Individual dice settle at staggered times.
5. Values are shown below dice rather than covering the pseudo-3D geometry. Keep/drop, reroll and explosion state remains visible.
6. Once settled, **Continue** opens the normal MethodMesh result screen. **Roll again** repeats the configured roll without returning to configuration.

### Coin toss

1. Configure the number of coins and press **TOSS**.
2. For 1–10 coins, MethodMesh shows every coin on a full-screen toss surface and staggers landing times.
3. For more than 10 coins, individual animation is intentionally skipped and a compact aggregate transition/result is used.
4. Recorded tosses wait at the settled screen for **Continue**, then enter the normal MethodMesh result screen.
5. A native single-coin **Just toss** mode does not accumulate a session history. The settled screen offers **Toss again** and **Done**. `Done` exits without confirming a result into the workflow.

External/ODK calls remain result-oriented and do not depend on the interactive native toss/roll screens.

## UX revision v0.4

The v0.4 prototype restores accessible RPG mechanics without returning to a dense setup screen. A collapsed **Roll options** section provides keep/drop, reroll, exploding-dice, success-counting and modifier controls; **Advanced notation** remains available separately for expert users. Dice results are displayed below wireframe geometry for every die type, and the projection geometry is normalized so mixed dice occupy comparable tray slots. Coin heads uses a line-art cat emblem and tails reproduces the three-bar MethodMesh launcher mark. See `UX_REVISION_v0.4.md` for the focused change note.

## Staged advanced-rule animation

The native full-screen tray does not reveal advanced-rule outcomes before the base roll has finished. Base dice first roll and settle neutrally. Rerolls are then replayed with amber highlighting; explosion triggers flash green and create inset rolls; cascading explosions continue until the recorded chain ends; finally keep/drop decisions flash red before discarded dice fade.

The animation is driven by `primitive_draws` in the recorded round details, so it reflects the same sequence used by the calculation rather than reconstructing a plausible-looking animation from the final total.

Keep/drop is resolved within each dice term/group. Mixed dice types are not compared with one another. When multiple dice groups are present, the native Roll options panel lets the operator select which group is being configured.

## UX revision v0.6

On narrow screens, each dice group is rendered as a compact single-row control strip with small decrement/increment controls, a flexible die-type dropdown, and a compact `×` delete action. Explosion thresholds are selected from die-aware legal values rather than entered as free text; values that would make every face explode indefinitely are not offered. See `UX_REVISION_v0.6.md`.
