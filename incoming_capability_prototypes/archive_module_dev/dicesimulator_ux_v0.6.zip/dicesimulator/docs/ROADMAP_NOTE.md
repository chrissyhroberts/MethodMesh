# Dice Simulator — repository roadmap note

Suggested entry for `000_Roadmap.md` when this Development module is merged.

## Dice Simulator

Development module: `modules/dicesimulator`

Implemented in v0.2 prototype:

- beginner-facing dice-group builder and quick rolls;
- one visible pseudo-3D die per base die in the expression;
- Compose-only D4/D6/D8/D10/D12/D20/common-Dn renderer; no game/3D engine dependency;
- animation generated after the outcome and unable to influence it;
- mixed dice and arithmetic;
- keep/drop highest/lowest;
- reroll once/repeated reroll;
- exploding dice;
- success-count pools;
- roll-over/roll-under comparison;
- D100/percentile and Fate/Fudge dice;
- secure `SecureRandom` mode;
- versioned fixed-seed deterministic mode with rejection sampling;
- primitive-draw and operation provenance in structured JSON;
- repeated simulation series;
- coin toss convenience method;
- ODK/XLSForm example.

Open before Production:

- integrate module into full repository and run `./gradlew :app:assembleDebug`;
- add repo unit tests for parser/evaluator and regression vectors for fixed-seed mode;
- device/emulator check of pseudo-3D tray in portrait/landscape, including 7, 20 and 100 dice;
- validate native preset fixed/runtime setting hiding;
- validate ODK round-trip and returned JSON size behaviour;
- confirm generic sharing surfaces only `dice_result` as the default share payload;
- consider friendlier per-pool UI controls for keep/drop, reroll, explode and success thresholds;
- consider visually spawning explosion-chain dice rather than only annotating the originating die;
- decide whether v0.3 should add parentheses and additional system-neutral operators before method semantics are promoted to Production;
- document any deliberately supported alternate semantics as versioned engine behaviour, not unnamed game-system assumptions.

Out of scope for this module:

- HP/EXP/mana/resource counters;
- character cards;
- campaign records;
- scoreboards/leaderboards/high scores.

Those belong in a separate persistent Tabletop Utilities module/package.
