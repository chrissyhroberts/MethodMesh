# Dice Simulator UX revision v0.4

This revision refines the v0.3 full-screen roll/toss flow without changing the random engine semantics.

## Changes

- Restores friendly RPG roll controls in a collapsed **Roll options** panel:
  - keep highest / keep lowest / drop highest / drop lowest;
  - one-time reroll of ones;
  - repeated reroll below or at/above a threshold;
  - exploding dice on maximum or at/above a threshold;
  - success counting with a threshold;
  - arithmetic modifier.
- Keeps **Advanced notation** as a separate expert-facing control. Friendly controls update the same expression used by the engine.
- For mixed expressions, friendly RPG controls apply to the first dice group; Advanced notation remains available for per-group specialist rules.
- Dice-group quantity/type editing preserves compatible rules rather than resetting the roll to plain dice.
- Removes D6 pips/numbers from inside the wireframe. All settled values are displayed below their dice.
- Normalizes polyhedron vertices before projection, so D4/D6/D8/D10/D12/D20 occupy comparable visual footprints.
- Uses a more consistent responsive tray: up to 16 dice use four columns, then five columns for larger sets.
- Heads now uses a line-art cat emblem.
- Tails now uses the MethodMesh launcher mark (three rounded bars, including the MethodMesh green middle bar).
- Retains the v0.3 full-screen animation, staggered settling, repeated-roll buttons, and 1–10 individual coin animations.

## Build status

Development prototype. Run `./gradlew :app:assembleDebug` after copying into the current MethodMesh repository before promotion from `incoming_capability_prototypes/` into the auto-discovered modules path.
