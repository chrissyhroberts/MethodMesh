# Dice Simulator build fixes

This corrected package supersedes the earlier `dicesimulator.zip` prototype.

## Compile errors corrected

1. `DiceSimulatorCapabilityScreen.kt` attempted to rebuild an `ExecutionResult` by passing `context.request` (`ExternalWorkflowRequest`) to `As100DiceSimulationMethod.result(...)` and `As100CoinTossMethod.result(...)`, both of which require an `ExecutionRequest`.
   - Fixed by reconstructing a proper method `ExecutionRequest` through each method's `request(...)` function before wrapping the saved values.

2. `DiceSimulatorCapabilityScreen.kt` explicitly imported `androidx.compose.foundation.layout.weight`.
   - With MethodMesh's current Kotlin/Compose line this resolves to an internal Compose symbol and fails compilation.
   - The import has been removed. `Modifier.weight(...)` is used only inside `RowScope`, where it is available without an import.

3. `parseLastVisualOutcomes(...)` was expression-bodied while containing a bare `return emptyList()`.
   - Kotlin rejects `return` from an expression-bodied function.
   - Converted to a normal block-bodied function.

## Checks run here

- `DiceSimulatorEngine.kt` compiles with `kotlinc`.
- Engine smoke checks pass for:
  - `6d6+d20` (seven separately represented dice),
  - `4d6kh3`,
  - `8d6cs>=5`,
  - `d6!`,
  - `d20r1`,
  - `d100<=65`,
  - repeated coin tosses.
- Engine + method + module + capability screen pass a synthetic Kotlin compile against stubs matching the current MethodMesh method/screen contracts and the Compose scope semantics relevant to this module.

## Required repository check

Per `CAPABILITY_WRITING_GUIDE.md`, this remains a Development prototype until it is compiled inside the real repository:

```bash
./gradlew :app:assembleDebug
```

If that build reports another Dice Simulator error, use the first `e:`/`error:` block as the authoritative next defect; do not promote the module to Production until the full repository build and native/preset/ODK checks pass.
