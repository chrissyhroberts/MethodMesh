# Dice Simulator handoff

This is a corrected Development prototype.

Per the MethodMesh capability-writing guide, the safest initial location before a full Android build has passed is:

```text
incoming_capability_prototypes/dicesimulator/
```

After review and a successful repository build, the canonical destination is:

```text
app/src/main/java/com/example/methodmesh/modules/dicesimulator/
```

Copy the complete folder, including its nested `docs/` folder. Do not add a manual module registration entry; MethodMesh generates the module index automatically from `*Module.kt` files.

Required repository check:

```bash
./gradlew :app:assembleDebug
```

Then run the native, preset, orientation and ODK checks listed in `docs/README_DiceSimulator.md`.

See `BUILD_FIXES.md` for the compile defects corrected in this revision.

### UX v0.5 note

Advanced animations now use the round `primitive_draws` trace for staged reroll/explosion playback and delay keep/drop styling until rule resolution. See `UX_REVISION_v0.5.md`.
