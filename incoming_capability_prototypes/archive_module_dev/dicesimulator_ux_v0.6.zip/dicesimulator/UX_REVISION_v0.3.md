# Dice Simulator UX revision v0.3

Changes made from the first on-device prototype:

- removed the row of D4/D6/D8/D10/D12/D20 oval buttons from each dice group;
- replaced them with a single die-type dropdown plus an `Other...` custom-side field;
- removed the result-number bubble from the centre of pseudo-3D dice;
- result values now sit below each die;
- dice configuration and dice rolling are separate interaction phases;
- dice rolls use a full-screen tray and Full animation is approximately 1.8 seconds;
- each die receives its own deterministic visual settle offset so multi-die rolls land asynchronously;
- settled dice wait for `Continue` before the normal MethodMesh result screen;
- settled dice also offer `Roll again` without rebuilding the roll;
- coin tossing now uses the same full-screen interaction pattern;
- 1–10 coins are rendered individually and land at different times;
- >10 coins intentionally skip per-coin animation;
- added `interaction_mode = record | just_toss` for native single-coin use;
- `just_toss` generates one secure toss at a time, does not accumulate a session series, and offers `Toss again` / `Done`;
- default animation mode is now `full` for both dice and coins.

Status remains Development pending full `:app:assembleDebug` in the repository and device testing.
