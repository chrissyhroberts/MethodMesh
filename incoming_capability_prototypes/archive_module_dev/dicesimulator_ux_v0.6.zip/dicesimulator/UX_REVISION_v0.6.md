# UX revision v0.6

This revision responds to narrow-screen configuration feedback.

## Dice group rows

Dice groups now use a compact single-row control strip:

- 44 dp decrement button;
- count label;
- 44 dp increment button;
- die-type dropdown occupying the remaining width;
- compact 44 dp `×` delete control when more than one group exists.

This replaces the full `Remove` button, which could wrap vertically on narrow devices and make additional dice groups visually dominant.

## Explosion threshold

The free-text explosion threshold has been replaced by a die-aware dropdown. The available values are derived from the selected die and exclude thresholds that would make every possible face explode indefinitely.

Examples:

- D4: `2+`, `3+`, `4+`
- D6: `2+` through `6+`
- D20: `2+` through `20+`

`Explode on maximum` remains the simplest default option.
