# Astronomy v0.3.0 validation

## Completed in this package build

- `AstronomyMath.kt` + `AstronomyMathSmoke.kt` compile/smoke-test material is retained from v0.2.
- Open-Meteo astronomy API declarations use the shared `ApiDefinitionRepository` + `api.get` execution boundary.
- standalone `astronomy.dew_risk` defaults to GPS + Open-Meteo, then manual fallback.
- `astronomy.dew_risk` also accepts `temperature_c` and `relative_humidity_pct` when those fields are already present in the current action context. This supports the existing multi-step `ExternalWorkflowActivity` forwarding mechanism, including a preceding AHT20 `sensor.read` step. It is **not** evidence of a general user-facing pipe.
- `sensorread` has therefore been removed from astronomy's declared module dependencies.
- `astronomy.imaging_window` accepts a supplied full `plus_code` and resolves its centroid using the existing Open Location Code implementation; otherwise it obtains live GPS.
- native conditions/dew/imaging screens implement automatic GPS/API behaviour with manual fallback.
- `astronomy.sky_test` specifies flat screen-down/rear-camera-up use.
- `astronomy.focus` is explicitly restricted to eyepiece/optical-train use.

## Still required in the actual repository

1. `./gradlew :app:assembleDebug`
2. architecture/module tests
3. physical Android validation of GPS permission flow and API refresh
4. multi-step workflow test: `sensor.read(AHT20)` followed by `astronomy.dew_risk`
5. standalone dew test confirming it does **not** imply or attempt an AHT20 read
6. Plus Code input test for `astronomy.imaging_window`
7. camera sensitivity testing for bright-star sky test on representative phones
8. optical-adapter validation before treating `astronomy.focus` as production-ready

Status remains **Development**.
