# Cryptography capability set v0.1.1

This is a clean replacement folder for v0.1.0.

## Compile fix

`cryptography/CryptographyMethods.kt` is aligned to the current AS1.00 `MethodDescriptor` constructor style used by current MethodMesh modules:

```kotlin
MethodDescriptor(
    id = ArchitectureId(id),
    methodType = MethodObjectType.Calculation,
    name = methodName,
    version = version,
    description = methodDescription,
    outputs = CryptoFields.common,
    graphOutputs = listOf(id),
    parameters = mapOf(
        "category" to "Cryptography",
        "status" to "Development"
    )
)
```

Named arguments are intentional so constructor parameter ordering cannot produce the earlier `Map -> ArchitectureId` / `List -> Map` mismatch.

## Integration

Replace the earlier cryptography capability folder with this folder and rerun:

```bash
./gradlew :app:compileDebugKotlin
```

The existing trusted timestamp capability remains included unchanged.
