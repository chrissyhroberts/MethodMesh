# Fix v0.1.2

## Kotlin compile fix

`CryptographyMethods.kt` previously called `As100ExecutionEngine.request(...)` positionally:

```kotlin
As100ExecutionEngine.request(action, ref, context, signals, inputs)
```

The current MethodMesh AS1.00 API must be called using the same named-argument form already used by the trusted timestamp module:

```kotlin
As100ExecutionEngine.request(
    action = action,
    method = ref,
    context = context,
    signals = signals,
    inputs = inputs
)
```

This resolves the compiler error in which `context: Map<String,String>` was being bound to an `ArchitectureId` parameter in the current overload/signature.
