# Fix v0.1.3 — OpenPGP compile classpath

## Reported compiler error

```text
:app:compileDebugKotlin
OpenPgpEngine.kt
Unresolved reference 'openpgp'.
```

## Cause

`OpenPgpEngine.kt` directly imports Bouncy Castle OpenPGP classes such as
`org.bouncycastle.openpgp.PGPPublicKeyRingCollection` to obtain an interoperable
OpenPGP certificate fingerprint.

The integration file previously added only:

```kotlin
implementation("org.pgpainless:pgpainless-sop:2.0.4")
```

PGPainless SOP exposes the SOP API, but PGPainless Core is its internal/runtime
dependency rather than part of SOP's exported compile API. Consequently the
Bouncy Castle OpenPGP classes used directly by MethodMesh were not visible to
`:app:compileDebugKotlin`.

## Fix

Add the matching PGPainless Core release explicitly:

```kotlin
implementation("org.pgpainless:pgpainless-sop:2.0.4")
implementation("org.pgpainless:pgpainless-core:2.0.4")
```

`pgpainless-core` exports the Bouncy Castle provider, OpenPGP and utility
libraries it needs, making the `org.bouncycastle.openpgp.*` API available at
compile time.

The previous manual Bouncy Castle `1.85.2` constraints have been removed. The
cryptography capability should use the dependency family tested by the selected
PGPainless release unless the MethodMesh host centrally pins Bouncy Castle for
the entire application.

An unused `PGPObjectFactory` import was also removed.
