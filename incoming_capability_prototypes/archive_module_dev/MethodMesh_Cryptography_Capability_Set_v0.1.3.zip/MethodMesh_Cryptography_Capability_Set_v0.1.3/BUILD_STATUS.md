# Build status

## Completed in this package

- MethodMesh `cryptography` module with AS1.00 method descriptors, RIL bindings, settings and capability screens.
- Portable OpenPGP text/file encryption and decryption, including password and recipient-key paths.
- OpenPGP key generation, detached signing/verification and public NFC/QR identity-token export.
- Signature verification can require an expected fingerprint obtained from an NFC/QR identity handoff.
- SHA-256/SHA-512 hashing with streamed file hashing.
- CSPRNG password/PIN/token/phrase generation with entropy reporting.
- RFC 6238 TOTP calculation and `otpauth://` parsing/provisioning.
- Android Keystore + `BIOMETRIC_STRONG` encrypted local TOTP locker with import/use/delete and OpenPGP-encrypted backup.
- Shamir 2..20 threshold secret splitting/reconstruction over GF(256), with compact textual share transport.
- Expiring challenge / signed-response / verification workflow.
- Persistent, deliberately non-secret crypto status dashboard following the supplied dashboard pattern.
- Existing `integrity.trusted_timestamp` capability included unchanged for RFC 3161 integration.
- ODK XLSForm examples for encrypted text and encrypted photo/file handoffs.
- Security/interoperability/integration documentation.

## Executed verification

- `CryptoCore.kt` + `ShamirEngine.kt` compiled with Kotlin/JVM 1.9.0.
- Core self-test passed: SHA-256 KAT, RFC 6238 KAT, otpauth round-trip, generator invariants and 100 randomized Shamir recovery trials.
- XLSForms built and inspected with `artifact_tool`; no formula-error tokens found.
- Trusted timestamp copy compared byte-for-byte/file-for-file against the source extraction: no differences.
- Whole-source Kotlin parse attempt found no syntax/redeclaration errors; unresolved Android/MethodMesh classes are expected outside the host repository.

## Required host integration validation

This is a capability source package, not a standalone APK and not the full MethodMesh repository. Before release, compile it in the actual MethodMesh Android project and exercise the Android/Compose/OpenPGP/FileProvider/ODK paths on devices. In particular, validate the resolved PGPainless/Bouncy Castle dependency graph and cross-tool OpenPGP interoperability.

Shamir support is deliberately marked Development: the implementation has property tests but has not been independently cryptographically audited. Do not use it as the sole recovery mechanism for production master keys until that review is complete or it is replaced with a vetted implementation/standardized mnemonic scheme such as SLIP-0039 where appropriate.

## v0.1.3 compile-classpath correction

`OpenPgpEngine.kt` directly imports Bouncy Castle OpenPGP types for certificate
fingerprint extraction. The app integration now declares both
`org.pgpainless:pgpainless-sop:2.0.4` and
`org.pgpainless:pgpainless-core:2.0.4`; the latter exposes the required Bouncy
Castle compile API. Manual Bouncy Castle version constraints were removed to
avoid forcing a provider family independently of the selected PGPainless
release.
