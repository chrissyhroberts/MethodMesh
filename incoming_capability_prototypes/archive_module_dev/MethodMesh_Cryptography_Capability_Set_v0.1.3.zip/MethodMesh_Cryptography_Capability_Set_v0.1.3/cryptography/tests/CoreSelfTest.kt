package com.example.methodmesh.modules.cryptography

import java.security.SecureRandom

private fun assertThat(condition: Boolean, message: String) {
    if (!condition) error(message)
}

fun main() {
    // SHA-256 known-answer test.
    assertThat(
        HashEngine.hex("abc".toByteArray()) == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        "SHA-256 known-answer test failed"
    )

    // RFC 6238 Appendix B SHA-1 vector: T=59, 8 digits -> 94287082.
    val rfcSecret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
    val code = TotpEngine.generate(
        TotpAccount("", "test", rfcSecret, digits = 8, periodSeconds = 30, algorithm = "SHA1"),
        epochSeconds = 59
    )
    assertThat(code.code == "94287082", "RFC 6238 known-answer test failed: ${code.code}")

    // otpauth parse/serialize retains operational fields.
    val parsed = TotpEngine.parseOtpAuth(
        "otpauth://totp/Example%3Aalice%40example.com?secret=$rfcSecret&issuer=Example&algorithm=SHA1&digits=8&period=30"
    )
    assertThat(parsed.issuer == "Example" && parsed.accountName == "alice@example.com", "otpauth label parse failed")
    val reparsed = TotpEngine.parseOtpAuth(TotpEngine.toOtpAuth(parsed))
    assertThat(reparsed == parsed, "otpauth round-trip failed")

    // Generated-secret dimensions and entropy claims are internally coherent.
    val p1 = PasswordEngine.random(24)
    val p2 = PasswordEngine.random(24)
    assertThat(p1.value.length == 24 && p2.value.length == 24, "random password length failed")
    assertThat(p1.value != p2.value, "two CSPRNG samples unexpectedly matched")
    assertThat(p1.entropyBits > 100.0, "reported password entropy unexpectedly low")
    assertThat(PasswordEngine.pin(8).entropyBits > 26.0, "PIN entropy calculation failed")
    assertThat(PasswordEngine.syllablePhrase(6).value.split('-').size == 6, "phrase word count failed")

    // Shamir deterministic recovery properties across random secrets and subsets.
    val rng = SecureRandom()
    repeat(100) { iteration ->
        val secret = ByteArray(1 + rng.nextInt(256)).also(rng::nextBytes)
        val shares = ShamirEngine.split(secret, threshold = 3, shares = 5)
        val candidateSets = listOf(
            listOf(shares[0], shares[1], shares[2]),
            listOf(shares[0], shares[2], shares[4]),
            listOf(shares[1], shares[3], shares[4]),
            shares.shuffled().take(4)
        )
        candidateSets.forEachIndexed { subsetIndex, subset ->
            val recovered = ShamirEngine.combine(subset)
            assertThat(secret.contentEquals(recovered), "Shamir recovery failed at iteration $iteration subset $subsetIndex")
        }
        shares.forEach {
            val decoded = ShamirShare.decode(it.encode())
            assertThat(decoded.threshold == it.threshold && decoded.index == it.index && decoded.payload.contentEquals(it.payload), "Shamir transport round-trip failed")
        }
    }

    println("CoreSelfTest: PASS")
}
