package com.example.methodmesh.modules.cryptography

import org.bouncycastle.openpgp.PGPPublicKeyRing
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection
import org.bouncycastle.openpgp.PGPUtil
import org.bouncycastle.openpgp.operator.jcajce.JcaKeyFingerprintCalculator
import org.pgpainless.sop.SOPImpl
import sop.SOP
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream

/** Thin interoperability layer around the Stateless OpenPGP API. */
object OpenPgpEngine {
    private val sop: SOP by lazy { SOPImpl() }

    fun encryptWithPassword(input: InputStream, output: OutputStream, password: String, armor: Boolean) {
        require(password.isNotEmpty()) { "Password is required." }
        val operation = sop.encrypt().withPassword(password)
        val ready = if (armor) operation.plaintext(input) else operation.noArmor().plaintext(input)
        ready.writeTo(output)
    }

    fun encryptForRecipients(
        input: InputStream,
        output: OutputStream,
        recipientCertificates: List<ByteArray>,
        signingKey: ByteArray? = null,
        signingKeyPassword: String? = null,
        armor: Boolean = false
    ) {
        require(recipientCertificates.isNotEmpty()) { "At least one recipient certificate is required." }
        val operation = sop.encrypt()
        recipientCertificates.forEach(operation::withCert)
        if (signingKey != null) {
            operation.signWith(signingKey)
            if (!signingKeyPassword.isNullOrEmpty()) operation.withKeyPassword(signingKeyPassword)
        }
        val ready = if (armor) operation.plaintext(input) else operation.noArmor().plaintext(input)
        ready.writeTo(output)
    }

    fun decrypt(
        input: InputStream,
        output: OutputStream,
        password: String? = null,
        secretKey: ByteArray? = null,
        keyPassword: String? = null,
        verificationCertificates: List<ByteArray> = emptyList()
    ): List<String> {
        val operation = sop.decrypt()
        if (!password.isNullOrEmpty()) operation.withPassword(password)
        if (secretKey != null) operation.withKey(secretKey)
        if (!keyPassword.isNullOrEmpty()) operation.withKeyPassword(keyPassword)
        verificationCertificates.forEach(operation::verifyWithCert)
        val result = operation.ciphertext(input).writeTo(output)
        return result.verifications.map { it.signingCertFingerprint.toString() }
    }

    fun generateKey(userId: String, keyPassword: String): Pair<ByteArray, ByteArray> {
        require(userId.isNotBlank())
        require(keyPassword.isNotEmpty()) { "Key password is required." }
        val secret = sop.generateKey()
            .userId(userId)
            .withKeyPassword(keyPassword)
            .generate()
            .bytes
        val certificate = sop.extractCert().key(secret).bytes
        return secret to certificate
    }


    fun extractCertificate(secretKey: ByteArray): ByteArray = sop.extractCert().key(secretKey).bytes

    fun detachedSign(data: InputStream, signingKey: ByteArray, keyPassword: String, output: OutputStream) {
        val result = sop.detachedSign()
            .key(signingKey)
            .withKeyPassword(keyPassword)
            .data(data)
        result.writeTo(output)
    }

    fun detachedVerify(data: InputStream, signature: ByteArray, certificate: ByteArray): List<String> =
        sop.detachedVerify()
            .cert(certificate)
            .signatures(signature)
            .data(data)
            .map { it.signingCertFingerprint.toString() }

    fun certificateFingerprint(certificate: ByteArray): String {
        val decoded = PGPUtil.getDecoderStream(ByteArrayInputStream(certificate))
        val rings = PGPPublicKeyRingCollection(decoded, JcaKeyFingerprintCalculator())
        val ring: PGPPublicKeyRing = rings.keyRings.asSequence().firstOrNull()
            ?: error("No OpenPGP public key ring found.")
        return with(CryptoEncoding) { ring.publicKey.fingerprint.hex().uppercase() }
    }
}
