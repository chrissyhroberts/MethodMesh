# Trusted timestamp integration

Do not rename or duplicate `integrity.trusted_timestamp`.

The existing source is included in this package as `../trustedtimestamp/` unchanged. The Cryptography user-facing category should surface it under **Integrity & time**, while protocols/RIL continue to call its stable method ID.

Suggested compositions:

- `crypto.hash` -> `integrity.trusted_timestamp`
- `crypto.sign` -> `integrity.trusted_timestamp`
- `crypto.file.encrypt` -> `crypto.hash` -> `integrity.trusted_timestamp` when proof of the encrypted artefact's existence is wanted

Which object is timestamped is a protocol decision and must be explicit in provenance.
