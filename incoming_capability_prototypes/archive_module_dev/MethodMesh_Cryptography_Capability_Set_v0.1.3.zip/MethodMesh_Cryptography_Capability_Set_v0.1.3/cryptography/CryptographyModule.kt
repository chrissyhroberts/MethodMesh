package com.example.methodmesh.modules.cryptography

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object CryptographyModule : MethodMeshModule {
    override val moduleId = "cryptography"
    override val displayName = "Cryptography"
    override val summary = "Portable encryption, signatures, passwords, TOTP, secret sharing and proof-of-key-possession."

    override fun as100Methods() = listOf(
        As100PasswordGenerateMethod,
        As100HashMethod,
        As100TextEncryptMethod,
        As100TextDecryptMethod,
        As100FileEncryptMethod,
        As100FileDecryptMethod,
        As100KeyGenerateMethod,
        As100IdentityExportMethod,
        As100SignMethod,
        As100VerifySignatureMethod,
        As100SecretSplitMethod,
        As100SecretCombineMethod,
        As100ChallengeCreateMethod,
        As100ChallengeRespondMethod,
        As100ChallengeVerifyMethod,
        As100TotpImportMethod,
        As100TotpGenerateMethod,
        As100TotpDeleteMethod,
        As100TotpExportMethod,
        As100CryptoDashboardMethod
    )

    override fun rilBindings() = listOf(
        RilBinding("create password", As100PasswordGenerateMethod.id, "Create a cryptographically random password or passphrase"),
        RilBinding("hash content", As100HashMethod.id, "Hash exact content"),
        RilBinding("encrypt text", As100TextEncryptMethod.id, "Encrypt text as OpenPGP"),
        RilBinding("decrypt text", As100TextDecryptMethod.id, "Decrypt OpenPGP text"),
        RilBinding("encrypt file", As100FileEncryptMethod.id, "Encrypt a file as OpenPGP"),
        RilBinding("decrypt file", As100FileDecryptMethod.id, "Decrypt an OpenPGP file"),
        RilBinding("create signing key", As100KeyGenerateMethod.id, "Create an OpenPGP identity key"),
        RilBinding("export cryptographic identity", As100IdentityExportMethod.id, "Create a public NFC/QR identity token"),
        RilBinding("sign content", As100SignMethod.id, "Create a detached OpenPGP signature"),
        RilBinding("verify signature", As100VerifySignatureMethod.id, "Verify an OpenPGP signature"),
        RilBinding("split secret", As100SecretSplitMethod.id, "Split a secret into Shamir shares"),
        RilBinding("merge secret shares", As100SecretCombineMethod.id, "Recover a Shamir-shared secret"),
        RilBinding("create challenge", As100ChallengeCreateMethod.id, "Create an expiring proof-of-possession challenge"),
        RilBinding("sign challenge", As100ChallengeRespondMethod.id, "Respond to a challenge with a signature"),
        RilBinding("verify challenge", As100ChallengeVerifyMethod.id, "Verify a signed challenge response"),
        RilBinding("import totp account", As100TotpImportMethod.id, "Import a TOTP account"),
        RilBinding("create totp code", As100TotpGenerateMethod.id, "Generate a TOTP code"),
        RilBinding("delete totp account", As100TotpDeleteMethod.id, "Delete a TOTP account"),
        RilBinding("export totp backup", As100TotpExportMethod.id, "Export encrypted TOTP backup"),
        RilBinding("describe cryptography status", As100CryptoDashboardMethod.id, "Show non-secret cryptography status")
    )

    override fun capabilityScreens() = listOf(
        PasswordGenerateCapabilityScreen,
        HashCapabilityScreen,
        TextEncryptCapabilityScreen,
        TextDecryptCapabilityScreen,
        FileEncryptCapabilityScreen,
        FileDecryptCapabilityScreen,
        KeyGenerateCapabilityScreen,
        IdentityExportCapabilityScreen,
        SignCapabilityScreen,
        VerifySignatureCapabilityScreen,
        SecretSplitCapabilityScreen,
        SecretCombineCapabilityScreen,
        ChallengeCreateCapabilityScreen,
        ChallengeRespondCapabilityScreen,
        ChallengeVerifyCapabilityScreen,
        TotpImportCapabilityScreen,
        TotpGenerateCapabilityScreen,
        TotpDeleteCapabilityScreen,
        TotpExportCapabilityScreen,
        CryptoDashboardCapabilityScreen
    )

    override fun capabilitySettings() = mapOf(
        As100PasswordGenerateMethod.id to listOf(
            MethodSetting.TextSetting("mode", "Mode", defaultValue = "random"),
            MethodSetting.IntSetting("length", "Length", defaultValue = 20, minimum = 4, maximum = 512),
            MethodSetting.BooleanSetting("include_symbols", "Include symbols", defaultValue = true),
            MethodSetting.IntSetting("words", "Phrase words", defaultValue = 6, minimum = 3, maximum = 20)
        ),
        As100HashMethod.id to listOf(
            MethodSetting.TextSetting("input_text", "Text", defaultValue = ""),
            MethodSetting.TextSetting("algorithm", "Digest algorithm", defaultValue = "SHA-256"),
            MethodSetting.BooleanSetting("include_full_json", "Return provenance JSON", defaultValue = true)
        ),
        As100TextEncryptMethod.id to listOf(
            MethodSetting.TextSetting("input_text", "Text", defaultValue = ""),
            MethodSetting.TextSetting("password", "Password", defaultValue = ""),
            MethodSetting.TextSetting("recipient_certificate", "Recipient OpenPGP certificate", defaultValue = ""),
            MethodSetting.BooleanSetting("include_full_json", "Return provenance JSON", defaultValue = true)
        ),
        As100TextDecryptMethod.id to listOf(
            MethodSetting.TextSetting("input_text", "OpenPGP ciphertext", defaultValue = ""),
            MethodSetting.TextSetting("password", "Password", defaultValue = ""),
            MethodSetting.TextSetting("secret_key", "OpenPGP secret key", defaultValue = ""),
            MethodSetting.TextSetting("key_password", "Key password", defaultValue = ""),
            MethodSetting.BooleanSetting("include_full_json", "Return provenance JSON", defaultValue = true)
        ),
        As100FileEncryptMethod.id to listOf(
            MethodSetting.TextSetting("input_uri", "Input file URI", defaultValue = ""),
            MethodSetting.TextSetting("password", "Password", defaultValue = ""),
            MethodSetting.TextSetting("recipient_certificate", "Recipient OpenPGP certificate", defaultValue = ""),
            MethodSetting.BooleanSetting("include_full_json", "Return provenance JSON", defaultValue = true)
        ),
        As100FileDecryptMethod.id to listOf(
            MethodSetting.TextSetting("input_uri", "Encrypted file URI", defaultValue = ""),
            MethodSetting.TextSetting("password", "Password", defaultValue = ""),
            MethodSetting.TextSetting("secret_key", "OpenPGP secret key", defaultValue = ""),
            MethodSetting.TextSetting("key_password", "Key password", defaultValue = ""),
            MethodSetting.BooleanSetting("include_full_json", "Return provenance JSON", defaultValue = true)
        ),
        As100KeyGenerateMethod.id to listOf(
            MethodSetting.TextSetting("user_id", "OpenPGP user ID", defaultValue = ""),
            MethodSetting.TextSetting("key_password", "Key password", defaultValue = "")
        ),
        As100IdentityExportMethod.id to listOf(
            MethodSetting.TextSetting("display_name", "Display name", defaultValue = ""),
            MethodSetting.TextSetting("certificate", "OpenPGP public certificate", defaultValue = "")
        ),
        As100SignMethod.id to listOf(
            MethodSetting.TextSetting("input_text", "Text", defaultValue = ""),
            MethodSetting.TextSetting("input_uri", "Input file URI", defaultValue = ""),
            MethodSetting.TextSetting("secret_key", "OpenPGP secret key", defaultValue = ""),
            MethodSetting.TextSetting("key_password", "Key password", defaultValue = "")
        ),
        As100VerifySignatureMethod.id to listOf(
            MethodSetting.TextSetting("input_text", "Text", defaultValue = ""),
            MethodSetting.TextSetting("input_uri", "Input file URI", defaultValue = ""),
            MethodSetting.TextSetting("signature", "Detached OpenPGP signature", defaultValue = ""),
            MethodSetting.TextSetting("certificate", "Signer OpenPGP public certificate", defaultValue = ""),
            MethodSetting.TextSetting("expected_fingerprint", "Expected signer fingerprint", defaultValue = "")
        ),
        As100SecretSplitMethod.id to listOf(
            MethodSetting.TextSetting("input_text", "Secret", defaultValue = ""),
            MethodSetting.IntSetting("threshold", "Threshold", defaultValue = 3, minimum = 2, maximum = 20),
            MethodSetting.IntSetting("share_count", "Number of shares", defaultValue = 5, minimum = 2, maximum = 20)
        ),
        As100ChallengeCreateMethod.id to listOf(
            MethodSetting.TextSetting("audience", "Audience", defaultValue = ""),
            MethodSetting.IntSetting("ttl_seconds", "Validity seconds", defaultValue = 300, minimum = 30, maximum = 3600)
        ),
        As100ChallengeRespondMethod.id to listOf(
            MethodSetting.TextSetting("challenge", "Challenge JSON", defaultValue = ""),
            MethodSetting.TextSetting("secret_key", "OpenPGP secret key", defaultValue = ""),
            MethodSetting.TextSetting("key_password", "Key password", defaultValue = "")
        ),
        As100ChallengeVerifyMethod.id to listOf(
            MethodSetting.TextSetting("challenge", "Challenge JSON", defaultValue = ""),
            MethodSetting.TextSetting("signature", "Detached signature", defaultValue = ""),
            MethodSetting.TextSetting("certificate", "Signer OpenPGP public certificate", defaultValue = ""),
            MethodSetting.TextSetting("audience", "Expected audience", defaultValue = "")
        ),
        As100TotpImportMethod.id to listOf(
            MethodSetting.TextSetting("otpauth_uri", "otpauth URI", defaultValue = "")
        ),
        As100TotpGenerateMethod.id to listOf(
            MethodSetting.TextSetting("secret", "Base32 secret", defaultValue = ""),
            MethodSetting.IntSetting("digits", "Digits", defaultValue = 6, minimum = 6, maximum = 8),
            MethodSetting.IntSetting("period", "Period seconds", defaultValue = 30, minimum = 5, maximum = 300),
            MethodSetting.TextSetting("algorithm", "Algorithm", defaultValue = "SHA1")
        ),
        As100TotpDeleteMethod.id to listOf(
            MethodSetting.TextSetting("account_label", "Exact account label", defaultValue = "")
        ),
        As100TotpExportMethod.id to listOf(
            MethodSetting.TextSetting("password", "Backup password", defaultValue = ""),
            MethodSetting.TextSetting("recipient_certificate", "Recipient OpenPGP public certificate", defaultValue = "")
        )
    )
}
