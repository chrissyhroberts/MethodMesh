package com.example.methodmesh.modules.cryptography

import android.os.Build
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONObject

/**
 * Intentionally small dashboard: it exposes only non-secret security state and
 * interoperability status. Crypto operations remain separate Methods.
 */
object CryptoDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100CryptoDashboardMethod.id
    override val title = "Cryptography"
    override val description = "Non-secret status snapshot for portable crypto, the local TOTP locker and trusted timestamp integration."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var values by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
        var loading by rememberSaveable { mutableStateOf(false) }
        var attempted by rememberSaveable { mutableStateOf(false) }

        fun refresh() {
            if (loading) return
            loading = true
            val biometricSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
            val vaultPresent = if (biometricSupported) runCatching { AndroidBiometricVault(androidContext).hasVault() }.getOrDefault(false) else false
            val status = JSONObject(
                linkedMapOf(
                    "schema" to "methodmesh.crypto.dashboard.v1",
                    "portable_encryption" to "OpenPGP (RFC 9580 family)",
                    "portable_signatures" to "OpenPGP detached signatures",
                    "trusted_timestamp_method" to "integrity.trusted_timestamp",
                    "trusted_timestamp_format" to "RFC 3161 (.tsq/.tsr)",
                    "totp" to "RFC 6238 / otpauth provisioning",
                    "biometric_vault_supported" to biometricSupported,
                    "totp_vault_present" to vaultPresent,
                    "secrets_in_dashboard" to false
                )
            ).toString()
            values = mapOf(
                CryptoFields.VALUE to status,
                CryptoFields.FORMAT to "MethodMesh cryptography status snapshot",
                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                    methodId = capabilityId,
                    status = "succeeded",
                    format = "methodmesh.crypto.dashboard.v1",
                    extra = mapOf("biometric_vault_supported" to biometricSupported, "totp_vault_present" to vaultPresent)
                )
            )
            result = CryptoScreenSupport.succeeded(As100CryptoDashboardMethod, context, values)
            loading = false
        }

        LaunchedEffect(Unit) {
            if (!attempted) {
                attempted = true
                refresh()
            }
        }

        val keepLiveDashboard =
            context.presentationMode == CapabilityPresentationMode.Dashboard || context.isNativePresetRun
        val scaffoldResult = if (keepLiveDashboard) null else result

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let { OutputFormatter.fields(it, false) }.orEmpty(),
            onBack = onBack,
            onRetry = { result = null; values = emptyMap(); refresh() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Column {
                Text("Portable cryptography", style = MaterialTheme.typography.titleMedium)
                Text("OpenPGP encryption and detached signatures; generic tools can decrypt/verify off-platform.")
                Spacer(Modifier.height(10.dp))

                Text("Trusted time", style = MaterialTheme.typography.titleMedium)
                Text("RFC 3161 is provided by the existing integrity.trusted_timestamp capability.")
                Spacer(Modifier.height(10.dp))

                Text("Authenticator", style = MaterialTheme.typography.titleMedium)
                val vaultText = when {
                    Build.VERSION.SDK_INT < Build.VERSION_CODES.R -> "Biometric TOTP locker unavailable on this Android version."
                    values[CryptoFields.VALUE]?.contains("\"totp_vault_present\":true") == true -> "Biometric TOTP locker configured."
                    else -> "Biometric TOTP locker not yet configured."
                }
                Text(vaultText)
                Spacer(Modifier.height(10.dp))

                Text("This dashboard intentionally contains no keys, OTP seeds, passwords, plaintext payloads or operational crypto controls.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = ::refresh, modifier = Modifier.fillMaxWidth(), enabled = !loading) {
                    Text(if (loading) "Refreshing…" else "Refresh status")
                }

                if (keepLiveDashboard && result != null) {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { result?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot")
                    }
                }
            }
        }
    }
}
