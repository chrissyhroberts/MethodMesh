# MethodMesh writing-guide / architecture alignment

## Method boundary

Every operation exposed to MethodMesh is an `As100Method`. Screens are presentation adapters; the cryptographic engines do not own workflow state.

## Module ownership

`CryptographyModule.kt` owns:

- method registration;
- RIL bindings using existing core verbs (create/hash/encrypt/decrypt/sign/verify/split/merge/import/export/describe);
- capability-screen registration;
- capability settings.

## Provenance

Each successful operation returns `crypto_provenance_json` plus relevant flat fields. Provenance describes transformation and public key fingerprints but excludes secrets.

## External invocation

Runtime inputs use stable names such as `input_text`, `input_uri`, `password`, `recipient_certificate`, `secret_key`, `signature` and `expected_fingerprint`. Screens use `settingShouldBeShown(...)` where the setting can be supplied by a caller/preset.

Secrets should generally be prompted locally rather than persisted in presets or ODK forms.

## File outputs

Generated files are written to app cache and exposed through FileProvider URIs for handoff. The consumer must copy/import the object into durable storage; the crypto module does not silently create a second research-data repository.

## Dashboard

The dashboard follows the supplied persistent-dashboard pattern and locally withholds `capturedResult` only for native Dashboard/native-preset presentation. External invocations preserve normal structured completion.

## Existing trusted timestamp

The existing timestamp method ID and source remain unchanged. Cryptography composes with it rather than absorbing its TSA logic.
