# Cryptography capability

**Module ID:** `cryptography`  
**Status:** Development  
**Version:** 0.1.0

The module provides small, independently callable cryptographic Methods while using established external formats for portable artefacts.

## Capability matrix

| Method | Purpose | Portable format / boundary |
|---|---|---|
| `crypto.password.generate` | CSPRNG password, PIN, hex token, Base64URL token, human-enterable phrase | plain generated secret; caller decides storage |
| `crypto.hash` | SHA-256/SHA-512 exact-byte digest | hexadecimal digest |
| `crypto.text.encrypt` | password-encrypt UTF-8 text | ASCII-armoured OpenPGP |
| `crypto.text.decrypt` | decrypt OpenPGP text | UTF-8 plaintext |
| `crypto.file.encrypt` | password or recipient-key encryption | binary OpenPGP `.pgp` |
| `crypto.file.decrypt` | generic OpenPGP decryption | original bytes |
| `crypto.key.generate` | OpenPGP identity keypair | public certificate + password-protected secret key |
| `crypto.identity.export` | public NFC/QR identity binding | JSON identity token + OpenPGP public certificate |
| `crypto.sign` | detached signature of exact text/file bytes | OpenPGP detached signature |
| `crypto.signature.verify` | verify detached signature; optionally require expected fingerprint | structured verification result |
| `crypto.secret.split` | threshold secret sharing | Shamir GF(256); `mms1:` textual share transport |
| `crypto.secret.combine` | threshold reconstruction | recovered secret |
| `crypto.challenge.create` | create expiring random challenge | `methodmesh.challenge.v1` JSON |
| `crypto.challenge.respond` | prove present control of signing key | OpenPGP detached signature |
| `crypto.challenge.verify` | verify response and expiry/audience | structured result |
| `otp.totp.import` | import TOTP provisioning record | `otpauth://`; encrypted local vault |
| `otp.totp.generate` | generate RFC 6238 code or open biometric locker | RFC 6238 |
| `otp.totp.delete` | delete local TOTP account | local operation |
| `otp.totp.export` | safe backup of TOTP locker | OpenPGP `.pgp` only; never plaintext output |
| `crypto.dashboard` | non-secret module-status snapshot | structured JSON |
| `integrity.trusted_timestamp` | existing trusted TSA proof | RFC 3161 `.tsq` / `.tsr` evidence |

## Portable encryption rule

Portable content encryption is OpenPGP rather than a MethodMesh container. A file encrypted on Android can therefore be decrypted in a controlled server/desktop environment using an independent OpenPGP implementation.

Password-protected content and recipient-public-key content are both supported. The MethodMesh JSON is provenance about the operation; it is not required to interpret the ciphertext.

## Biometric boundary

Biometric authentication is intentionally device-local. It protects the TOTP vault using an AES-GCM key generated in Android Keystore and configured for `BIOMETRIC_STRONG` authorization. Biometrics are not converted into passwords, hashes or OpenPGP keys.

For research data that must later be decrypted off-device, use password-based or recipient-public-key OpenPGP. A device-bound biometric wrapper is not represented as a portable decryption mechanism.

## NFC and QR boundary

NFC/QR capabilities should transport:

- OpenPGP public certificates;
- public key fingerprints;
- `methodmesh.identity.openpgp.v1` identity tokens;
- challenge JSON and challenge signatures;
- `otpauth://` provisioning payloads when explicitly handling a secret;
- Shamir shares when the operator explicitly chooses that transport.

The crypto module itself does not implement NFC hardware access. This preserves MethodMesh separation between cryptographic Methods and device services.

## Trusted timestamp composition

The existing `integrity.trusted_timestamp` method is retained unchanged. Recommended research-integrity composition is:

```text
exact file bytes
  -> SHA-256
  -> detached OpenPGP signature
  -> RFC 3161 trusted timestamp over the relevant evidence bytes/hash
```

This separately establishes byte integrity, signer-key control and an independent time assertion.

## Development status

Core JVM primitives have executable tests in `tests/CoreSelfTest.kt`. Android/Compose/OpenPGP integration must still be compiled and exercised inside the MethodMesh host app because this capability package does not contain the full host repository.
