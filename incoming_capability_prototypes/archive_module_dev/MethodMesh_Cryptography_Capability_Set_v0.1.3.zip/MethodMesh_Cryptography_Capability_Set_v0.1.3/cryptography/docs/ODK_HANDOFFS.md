# ODK handoffs

## Principle

ODK should receive the portable encrypted value/file plus non-secret provenance. Do not place encryption passwords, TOTP seeds or private keys into ODK form fields merely to automate an external-app call.

For sensitive item encryption the recommended interaction is:

1. ODK passes the plaintext item/file reference to MethodMesh.
2. MethodMesh prompts locally for the encryption password or uses a supplied *public* recipient certificate.
3. MethodMesh returns OpenPGP ciphertext and provenance.
4. ODK stores ciphertext.
5. Data are downloaded/moved to the secure analysis environment.
6. A generic OpenPGP implementation decrypts there.

## Text item: participant name

Representative intent:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='crypto.text.encrypt',
  input_text=${participant_name},
  input_include_full_json='true',
  return_mode='flat'
)
```

Do **not** include `input_password=${...}` in a real study form unless the deployment has explicitly assessed the resulting secret-handling/logging path.

Suggested returned fields:

- `crypto_status`
- `crypto_value` — ASCII-armoured OpenPGP ciphertext
- `crypto_format`
- `crypto_output_sha256` — hash of ciphertext; plaintext hash is deliberately not returned
- `crypto_provenance_json`
- `crypto_error`

## File/photo

Representative intent:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='crypto.file.encrypt',
  input_uri=${photo},
  input_include_full_json='true',
  return_mode='flat'
)
```

Returned file fields:

- `crypto_output_uri`
- `crypto_output_filename`
- `crypto_output_sha256` — hash of ciphertext; plaintext hash is deliberately not returned
- `crypto_provenance_json`
- `crypto_status`
- `crypto_error`

The host integration must ensure Collect grants MethodMesh readable access to the attachment URI and then imports/copies the returned FileProvider URI before the cache object is removed. The included XLSForm is therefore a handoff example and requires device-level validation with the target Collect/MethodMesh versions.

## Signatures

ODK can also call `crypto.sign` after collecting a file/text item and retain the detached signature and fingerprint alongside the record. Signature verification later does not require MethodMesh.

## Trusted timestamp

Where a protocol requires trusted time, use the existing `integrity.trusted_timestamp` method as a separate composed step. Do not bake network TSA calls into the encryption method.

## Plaintext-hash rule

Encryption provenance deliberately does **not** return a SHA-256 of the plaintext. For low-entropy values such as names, IDs or short categorical responses, a plaintext hash can act as a dictionary oracle and partially defeat the confidentiality objective. The ciphertext hash is safe to retain as an artefact identifier.
