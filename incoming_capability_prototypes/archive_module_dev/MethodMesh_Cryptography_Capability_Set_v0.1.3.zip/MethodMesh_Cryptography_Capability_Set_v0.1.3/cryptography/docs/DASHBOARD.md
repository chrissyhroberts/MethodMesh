# Cryptography dashboard

The dashboard is intentionally minimal.

## Useful native status

It shows only:

- portable encryption/signature format: OpenPGP;
- trusted timestamp method/format: `integrity.trusted_timestamp`, RFC 3161;
- TOTP standard/provisioning convention;
- whether the device supports the biometric-vault implementation;
- whether a local TOTP vault exists.

It does **not** show:

- passwords;
- private keys;
- TOTP seeds;
- OTP codes by default;
- plaintext research data;
- Shamir shares;
- encryption/decryption controls.

The reason is architectural as well as security-related: crypto actions are Methods and should remain callable from native UI, ODK, RIL and protocols. A dashboard should not become a second orchestration layer or a privileged secret-management screen.

## Persistent dashboard behaviour

`CryptoDashboardCapabilityScreen.kt` follows `METHODMESH_PERSISTENT_DASHBOARD_CAPABILITY.md`:

- normal native dashboard and native preset runs keep the live dashboard visible;
- the genuine latest `ExecutionResult` remains in local state;
- `capturedResult` is withheld from the generic scaffold while native/preset presentation is live;
- native preset shows **Finish** and ordinary dashboard shows **Use this snapshot**;
- external/ODK runs receive the normal single-shot structured result.
