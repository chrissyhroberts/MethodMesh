# Testing

## Executed core tests

`tests/CoreSelfTest.kt` can be run without Android dependencies:

```bash
kotlinc CryptoCore.kt ShamirEngine.kt tests/CoreSelfTest.kt -include-runtime -d tests/core-self-test.jar
java -jar tests/core-self-test.jar
```

Current test coverage includes:

- SHA-256 known-answer test (`abc`);
- RFC 6238 Appendix B SHA-1 test vector (`T=59`, 8 digits -> `94287082`);
- `otpauth://` parse/serialize round-trip;
- CSPRNG generator length/non-repeat/entropy invariants;
- 100 randomized Shamir 3-of-5 recovery cycles using multiple subsets;
- Shamir textual transport encode/decode.

## Host-app tests still required

Because the complete MethodMesh Android repository is not in this package, the following must be tested after integration:

- Compose compilation against the exact host capability-screen APIs;
- PGPainless SOP compilation against the resolved host dependency graph;
- OpenPGP round-trip with GnuPG/Sequoia/RNP reference tooling;
- Android `BIOMETRIC_STRONG` vault import/unlock/delete/export on real devices;
- FileProvider lifetime and URI grants;
- ODK Collect text/file external-app handoff and returned attachment import;
- NFC/QR handoff into identity fingerprint and public certificate fields;
- trusted timestamp composition using the existing module.
