# Interoperability contract

## OpenPGP

Encrypted files are ordinary OpenPGP messages (`.pgp`). Encrypted text is ASCII-armoured OpenPGP. Detached signatures and public certificates are ordinary OpenPGP artefacts.

MethodMesh provenance JSON is optional evidence alongside these artefacts. It is not necessary for generic decryption or signature verification.

### Generic server/desktop examples

```bash
# Password or recipient-key decryption
gpg --output photo.jpg --decrypt photo.jpg.pgp

# Detached signature verification
gpg --verify results.xlsx.sig results.xlsx
```

Equivalent OpenPGP implementations may be used instead of GnuPG.

## Trusted timestamps

The existing timestamp capability emits/retains RFC 3161 request/response artefacts (`.tsq` and `.tsr`) inside its evidence bundle. The ZIP is a transport bundle, not a proprietary timestamp format.

## TOTP

TOTP calculation follows RFC 6238. Provisioning uses the widely implemented `otpauth://totp/...` URI convention so accounts can be imported/exported independently of MethodMesh when policy permits.

## NFC/QR identity

`methodmesh.identity.openpgp.v1` is a small public handoff record containing a display name and full OpenPGP fingerprint. For 160-bit v4 fingerprints the record may additionally include the established `openpgp4fpr:` URI form. RFC 9580 v6 fingerprints are 256-bit, so the implementation deliberately does not label a v6 fingerprint as an `openpgp4fpr:` URI.

The public certificate is transported separately or alongside the token. Verification can require the fingerprint from the NFC/QR identity token in addition to validating the OpenPGP signature.

## Shamir shares

The underlying operation is Shamir Secret Sharing over GF(256). There is no single universal interchange format for arbitrary Shamir shares. This module therefore uses a compact `mms1:` transport encoding containing threshold, share index and share bytes. It is not presented as a standard cryptographic container.
