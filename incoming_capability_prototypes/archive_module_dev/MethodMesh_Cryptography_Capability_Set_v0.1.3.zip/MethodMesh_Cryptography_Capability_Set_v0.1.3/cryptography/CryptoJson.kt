package com.example.methodmesh.modules.cryptography

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

object CryptoJson {
    fun provenance(
        methodId: String,
        status: String,
        sourceSha256: String? = null,
        outputSha256: String? = null,
        format: String? = null,
        protection: String? = null,
        keyFingerprints: List<String> = emptyList(),
        extra: Map<String, Any?> = emptyMap()
    ): String {
        val obj = JSONObject()
        obj.put("schema", "methodmesh.crypto.provenance.v1")
        obj.put("method_id", methodId)
        obj.put("status", status)
        obj.put("created_time_iso", Instant.now().toString())
        sourceSha256?.let { obj.put("source_sha256", it) }
        outputSha256?.let { obj.put("output_sha256", it) }
        format?.let { obj.put("format", it) }
        protection?.let { obj.put("protection", it) }
        if (keyFingerprints.isNotEmpty()) obj.put("key_fingerprints", JSONArray(keyFingerprints))
        extra.forEach { (key, value) -> obj.put(key, value) }
        return obj.toString()
    }

    /** Public identity token suitable for QR/NFC. No private material. */
    fun identityToken(displayName: String, fingerprint: String): String {
        val fp = fingerprint.filterNot(Char::isWhitespace).uppercase()
        val values = linkedMapOf<String, Any?>(
            "schema" to "methodmesh.identity.openpgp.v1",
            "display_name" to displayName,
            "fingerprint" to fp,
            "fingerprint_bits" to fp.length * 4
        )
        // openpgp4fpr: is defined for 160-bit (v4) fingerprints. RFC 9580 v6
        // fingerprints are 256-bit, so do not mislabel them with that URI scheme.
        if (fp.length == 40) values["fingerprint_uri"] = "openpgp4fpr:$fp"
        return JSONObject(values as Map<*, *>).toString()
    }
}
