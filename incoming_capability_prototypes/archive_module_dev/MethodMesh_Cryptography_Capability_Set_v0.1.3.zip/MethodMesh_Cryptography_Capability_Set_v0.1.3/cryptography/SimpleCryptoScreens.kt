package com.example.methodmesh.modules.cryptography

import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

@Composable
private fun ResultScaffold(
    title: String,
    capabilityId: String,
    context: CapabilityScreenContext,
    result: ExecutionResult?,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    body: @Composable () -> Unit
) {
    CapabilityScreenScaffold(
        title = title,
        capabilityId = capabilityId,
        context = context,
        canGoBack = context.stepNumber > 1,
        capturedResult = result,
        resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
        onBack = onBack,
        onRetry = onRetry,
        onConfirm = { result?.let(onConfirmed) },
        onCancel = onCancel
    ) { body() }
}

object PasswordGenerateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PasswordGenerateMethod.id
    override val title = "Password generator"
    override val description = "Generate secrets using the platform cryptographic random source."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var mode by rememberSaveable { mutableStateOf(context.action.settings["mode"] ?: "random") }
        var length by rememberSaveable { mutableStateOf(context.action.settings["length"] ?: "20") }
        var words by rememberSaveable { mutableStateOf(context.action.settings["words"] ?: "6") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var value by rememberSaveable { mutableStateOf("") }
        var entropy by rememberSaveable { mutableStateOf("") }

        fun generate() = runCatching {
            val generated = when (mode.lowercase()) {
                "pin" -> PasswordEngine.pin(length.toIntOrNull() ?: 8)
                "hex" -> PasswordEngine.hex(length.toIntOrNull() ?: 32)
                "token", "base64url" -> PasswordEngine.token(length.toIntOrNull() ?: 32)
                "phrase", "syllable_phrase" -> PasswordEngine.syllablePhrase(words.toIntOrNull() ?: 6)
                "alphanumeric" -> PasswordEngine.random(length.toIntOrNull() ?: 20, includeSymbols = false)
                else -> PasswordEngine.random(length.toIntOrNull() ?: 20, includeSymbols = true)
            }
            value = generated.value
            entropy = "%.1f".format(generated.entropyBits)
            val values = mapOf(
                CryptoFields.VALUE to generated.value,
                CryptoFields.FORMAT to generated.mode,
                CryptoFields.ENTROPY_BITS to entropy,
                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                    methodId = capabilityId,
                    status = "succeeded",
                    format = generated.mode,
                    extra = mapOf("entropy_bits" to generated.entropyBits)
                )
            )
            result = CryptoScreenSupport.succeeded(As100PasswordGenerateMethod, context, values)
        }.onFailure { result = CryptoScreenSupport.failed(As100PasswordGenerateMethod, context, it) }

        LaunchedEffect(context.startsImmediately) {
            if (context.startsImmediately && context.presentationMode == CapabilityPresentationMode.IntentLaunch) {
                generate()
            }
        }

        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; generate() }) {
            OutlinedTextField(mode, { mode = it }, label = { Text("Mode: random / alphanumeric / pin / hex / token / phrase") }, modifier = Modifier.fillMaxWidth())
            if (mode.lowercase() in setOf("phrase", "syllable_phrase")) {
                OutlinedTextField(words, { words = it.filter(Char::isDigit) }, label = { Text("Words") }, modifier = Modifier.fillMaxWidth())
            } else {
                OutlinedTextField(length, { length = it.filter(Char::isDigit) }, label = { Text(if (mode == "hex" || mode == "token") "Random bytes" else "Length") }, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = ::generate, modifier = Modifier.fillMaxWidth()) { Text("Generate") }
            if (value.isNotBlank()) {
                Spacer(Modifier.height(8.dp)); Text(value, style = MaterialTheme.typography.bodyLarge); Text("Estimated entropy: $entropy bits")
            }
        }
    }
}

object HashCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100HashMethod.id
    override val title = "Hash"
    override val description = "Calculate a SHA-256 or SHA-512 digest of exact bytes."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val resolver = androidContext.contentResolver
        var text by rememberSaveable { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var algorithm by rememberSaveable { mutableStateOf(context.action.settings["algorithm"] ?: "SHA-256") }
        var uriText by rememberSaveable { mutableStateOf(context.action.settings["input_uri"] ?: "") }
        var sourceName by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uriText = uri?.toString().orEmpty(); sourceName = uri?.let { CryptoScreenSupport.sourceName(resolver, it) }.orEmpty()
        }

        fun runHash() = runCatching {
            val sourceSha: String
            val digest: String
            if (uriText.isNotBlank()) {
                val uri = Uri.parse(uriText)
                digest = resolver.openInputStream(uri).use { HashEngine.hex(requireNotNull(it), algorithm) }
                sourceSha = if (algorithm == "SHA-256") digest else resolver.openInputStream(uri).use { HashEngine.hex(requireNotNull(it), "SHA-256") }
            } else {
                val bytes = text.toByteArray(Charsets.UTF_8)
                require(bytes.isNotEmpty()) { "No content supplied." }
                digest = HashEngine.hex(bytes, algorithm)
                sourceSha = HashEngine.hex(bytes)
            }
            val values = mapOf(
                CryptoFields.VALUE to digest,
                CryptoFields.FORMAT to algorithm,
                CryptoFields.SOURCE_SHA256 to sourceSha,
                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, sourceSha256 = sourceSha, format = algorithm, status = "succeeded")
            )
            result = CryptoScreenSupport.succeeded(As100HashMethod, context, values)
        }.onFailure { result = CryptoScreenSupport.failed(As100HashMethod, context, it) }

        LaunchedEffect(context.startsImmediately, text, uriText) {
            if (context.startsImmediately && (text.isNotEmpty() || uriText.isNotBlank())) runHash()
        }

        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; runHash() }) {
            OutlinedTextField(algorithm, { algorithm = it }, label = { Text("SHA-256 or SHA-512") }, modifier = Modifier.fillMaxWidth())
            if (context.settingShouldBeShown("input_text")) OutlinedTextField(text, { text = it }, label = { Text("Text") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (sourceName.isBlank()) "Hash a file instead" else sourceName) }
            Button(onClick = ::runHash, modifier = Modifier.fillMaxWidth()) { Text("Calculate hash") }
        }
    }
}

private class TextOpenPgpScreen(
    override val capabilityId: String,
    override val title: String,
    override val description: String,
    private val decrypt: Boolean
) : CapabilityScreenSpec {
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val method = if (decrypt) As100TextDecryptMethod else As100TextEncryptMethod
        var text by rememberSaveable { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var password by rememberSaveable { mutableStateOf(context.action.settings["password"] ?: "") }
        var recipientCertificate by rememberSaveable { mutableStateOf(context.action.settings["recipient_certificate"] ?: "") }
        var secretKey by rememberSaveable { mutableStateOf(context.action.settings["secret_key"] ?: "") }
        var keyPassword by rememberSaveable { mutableStateOf(context.action.settings["key_password"] ?: "") }
        var outputText by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun runTransform() = runCatching {
            require(text.isNotEmpty()) { "Text is required." }
            val source = text.toByteArray(Charsets.UTF_8)
            val out = ByteArrayOutputStream()
            if (decrypt) {
                require(password.isNotBlank() || secretKey.isNotBlank()) { "Supply a password or OpenPGP secret key." }
                OpenPgpEngine.decrypt(
                    ByteArrayInputStream(source), out,
                    password = password.ifBlank { null },
                    secretKey = secretKey.takeIf(String::isNotBlank)?.toByteArray(Charsets.UTF_8),
                    keyPassword = keyPassword.ifBlank { null }
                )
            } else {
                require(password.isNotBlank() || recipientCertificate.isNotBlank()) { "Supply a password or recipient OpenPGP certificate." }
                if (recipientCertificate.isNotBlank()) {
                    OpenPgpEngine.encryptForRecipients(
                        ByteArrayInputStream(source), out,
                        listOf(recipientCertificate.toByteArray(Charsets.UTF_8)),
                        armor = true
                    )
                } else {
                    OpenPgpEngine.encryptWithPassword(ByteArrayInputStream(source), out, password, armor = true)
                }
            }
            val bytes = out.toByteArray(); outputText = bytes.toString(Charsets.UTF_8)
            val safeHashFields = if (decrypt) {
                mapOf(CryptoFields.SOURCE_SHA256 to HashEngine.hex(source)) // source is ciphertext
            } else {
                mapOf(CryptoFields.OUTPUT_SHA256 to HashEngine.hex(bytes)) // output is ciphertext
            }
            val protection = when {
                decrypt && secretKey.isNotBlank() -> "OpenPGP recipient secret key"
                decrypt -> "OpenPGP password"
                recipientCertificate.isNotBlank() -> "OpenPGP recipient public key"
                else -> "OpenPGP password"
            }
            val provenance = if (decrypt) {
                CryptoJson.provenance(capabilityId, "succeeded", sourceSha256 = HashEngine.hex(source), format = "UTF-8", protection = protection, extra = mapOf("plaintext_hash_disclosed" to false))
            } else {
                val fingerprints = if (recipientCertificate.isNotBlank()) listOf(OpenPgpEngine.certificateFingerprint(recipientCertificate.toByteArray(Charsets.UTF_8))) else emptyList()
                CryptoJson.provenance(capabilityId, "succeeded", outputSha256 = HashEngine.hex(bytes), format = "OpenPGP", protection = protection, keyFingerprints = fingerprints, extra = mapOf("plaintext_hash_disclosed" to false))
            }
            val values = mapOf(
                CryptoFields.VALUE to outputText,
                CryptoFields.FORMAT to if (decrypt) "UTF-8" else "OpenPGP ASCII armor",
                CryptoFields.PROVENANCE_JSON to provenance
            ) + safeHashFields
            result = CryptoScreenSupport.succeeded(method, context, values)
        }.onFailure { result = CryptoScreenSupport.failed(method, context, it) }

        LaunchedEffect(context.startsImmediately, text, password, recipientCertificate, secretKey) {
            val hasCredential = if (decrypt) password.isNotBlank() || secretKey.isNotBlank() else password.isNotBlank() || recipientCertificate.isNotBlank()
            if (context.startsImmediately && text.isNotEmpty() && hasCredential) runTransform()
        }

        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; runTransform() }) {
            if (context.settingShouldBeShown("input_text")) OutlinedTextField(text, { text = it }, label = { Text(if (decrypt) "OpenPGP ciphertext" else "Plaintext") }, minLines = 5, modifier = Modifier.fillMaxWidth())
            if (context.settingShouldBeShown("password")) OutlinedTextField(password, { password = it }, label = { Text("Password (optional when using a key)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            if (decrypt) {
                if (context.settingShouldBeShown("secret_key")) OutlinedTextField(secretKey, { secretKey = it }, label = { Text("OpenPGP secret key (optional)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                if (secretKey.isNotBlank()) OutlinedTextField(keyPassword, { keyPassword = it }, label = { Text("Secret-key password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            } else {
                if (context.settingShouldBeShown("recipient_certificate")) OutlinedTextField(recipientCertificate, { recipientCertificate = it }, label = { Text("Recipient OpenPGP public certificate (optional)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            }
            Button(onClick = ::runTransform, modifier = Modifier.fillMaxWidth()) { Text(if (decrypt) "Decrypt" else "Encrypt") }
            if (outputText.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(outputText, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

val TextEncryptCapabilityScreen: CapabilityScreenSpec = TextOpenPgpScreen(
    As100TextEncryptMethod.id, "Encrypt text", "Create portable ASCII-armoured OpenPGP ciphertext.", false
)
val TextDecryptCapabilityScreen: CapabilityScreenSpec = TextOpenPgpScreen(
    As100TextDecryptMethod.id, "Decrypt text", "Decrypt portable OpenPGP ciphertext.", true
)

object SecretSplitCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SecretSplitMethod.id
    override val title = "Split secret"
    override val description = "Create threshold Shamir shares."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var secret by rememberSaveable { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var threshold by rememberSaveable { mutableStateOf(context.action.settings["threshold"] ?: "3") }
        var shareCount by rememberSaveable { mutableStateOf(context.action.settings["share_count"] ?: "5") }
        var sharesText by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        fun split() = runCatching {
            val shares = ShamirEngine.split(secret.toByteArray(Charsets.UTF_8), threshold.toInt(), shareCount.toInt()).map(ShamirShare::encode)
            sharesText = shares.joinToString("\n")
            result = CryptoScreenSupport.succeeded(As100SecretSplitMethod, context, mapOf(
                CryptoFields.VALUE to sharesText,
                CryptoFields.FORMAT to "Shamir GF(256); MethodMesh share transport mms1",
                CryptoFields.THRESHOLD to threshold,
                CryptoFields.SHARE_COUNT to shareCount,
                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", format = "Shamir GF(256)", extra = mapOf("threshold" to threshold.toInt(), "share_count" to shareCount.toInt()))
            ))
        }.onFailure { result = CryptoScreenSupport.failed(As100SecretSplitMethod, context, it) }
        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; split() }) {
            OutlinedTextField(secret, { secret = it }, label = { Text("Secret") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(threshold, { threshold = it.filter(Char::isDigit) }, label = { Text("Threshold") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(shareCount, { shareCount = it.filter(Char::isDigit) }, label = { Text("Shares") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::split, modifier = Modifier.fillMaxWidth()) { Text("Create shares") }
            if (sharesText.isNotBlank()) Text(sharesText, style = MaterialTheme.typography.bodySmall)
        }
    }
}

object SecretCombineCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SecretCombineMethod.id
    override val title = "Combine secret shares"
    override val description = "Recover a Shamir secret when the threshold is met."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var sharesText by rememberSaveable { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var recovered by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        fun combine() = runCatching {
            val shares = sharesText.lines().map(String::trim).filter(String::isNotBlank).map(ShamirShare::decode)
            recovered = ShamirEngine.combine(shares).toString(Charsets.UTF_8)
            result = CryptoScreenSupport.succeeded(As100SecretCombineMethod, context, mapOf(
                CryptoFields.VALUE to recovered,
                CryptoFields.FORMAT to "UTF-8 recovered secret",
                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", format = "Shamir GF(256)", extra = mapOf("shares_supplied" to shares.size))
            ))
        }.onFailure { result = CryptoScreenSupport.failed(As100SecretCombineMethod, context, it) }
        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; combine() }) {
            OutlinedTextField(sharesText, { sharesText = it }, label = { Text("One mms1 share per line") }, minLines = 5, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::combine, modifier = Modifier.fillMaxWidth()) { Text("Recover secret") }
            if (recovered.isNotBlank()) Text(recovered, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

object ChallengeCreateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ChallengeCreateMethod.id
    override val title = "Create challenge"
    override val description = "Create an expiring proof-of-key-possession challenge."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var audience by rememberSaveable { mutableStateOf(context.action.settings["audience"] ?: "") }
        var ttl by rememberSaveable { mutableStateOf(context.action.settings["ttl_seconds"] ?: "300") }
        var challenge by rememberSaveable { mutableStateOf("") }; var result by remember { mutableStateOf<ExecutionResult?>(null) }
        fun create() = runCatching {
            challenge = ChallengeEngine.create(audience, ttl.toLong())
            result = CryptoScreenSupport.succeeded(As100ChallengeCreateMethod, context, mapOf(CryptoFields.VALUE to challenge, CryptoFields.FORMAT to "methodmesh.challenge.v1", CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", format = "JSON challenge")))
        }.onFailure { result = CryptoScreenSupport.failed(As100ChallengeCreateMethod, context, it) }
        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; create() }) {
            OutlinedTextField(audience, { audience = it }, label = { Text("Audience / verifier") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(ttl, { ttl = it.filter(Char::isDigit) }, label = { Text("Validity seconds") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::create, modifier = Modifier.fillMaxWidth()) { Text("Create challenge") }
            if (challenge.isNotBlank()) Text(challenge, style = MaterialTheme.typography.bodySmall)
        }
    }
}

object TotpGenerateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TotpGenerateMethod.id
    override val title = "TOTP authenticator"
    override val description = "Generate an RFC 6238 code from an explicit secret or an account in the biometric TOTP locker."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var secret by rememberSaveable { mutableStateOf(context.action.settings["secret"] ?: "") }
        var digits by rememberSaveable { mutableStateOf(context.action.settings["digits"] ?: "6") }
        var period by rememberSaveable { mutableStateOf(context.action.settings["period"] ?: "30") }
        var algorithm by rememberSaveable { mutableStateOf(context.action.settings["algorithm"] ?: "SHA1") }
        var code by rememberSaveable { mutableStateOf("") }
        var remaining by rememberSaveable { mutableStateOf("") }
        var selectedLabel by rememberSaveable { mutableStateOf("") }
        var lockerAccounts by remember { mutableStateOf<List<TotpAccount>>(emptyList()) }
        var lockerMessage by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun makeResult(account: TotpAccount, label: String) = runCatching {
            val generated = TotpEngine.generate(account)
            code = generated.code
            remaining = generated.validForSeconds.toString()
            selectedLabel = label
            result = CryptoScreenSupport.succeeded(
                As100TotpGenerateMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to code,
                    CryptoFields.FORMAT to "RFC 6238 TOTP",
                    CryptoFields.TOTP_VALID_FOR_SECONDS to remaining,
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId,
                        "succeeded",
                        format = "RFC6238",
                        extra = mapOf(
                            "account_label" to label,
                            "digits" to account.digits,
                            "period_seconds" to account.periodSeconds,
                            "algorithm" to account.algorithm,
                            "secret_returned" to false
                        )
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100TotpGenerateMethod, context, it) }

        fun generateExplicit() {
            val account = TotpAccount("", "explicit", secret, digits.toInt(), period.toInt(), algorithm)
            makeResult(account, "explicit secret")
        }

        fun unlockLocker() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                lockerMessage = "Biometric TOTP locker requires Android 11 or later."
                return
            }
            val vault = AndroidBiometricVault(androidContext)
            if (!vault.hasVault()) {
                lockerMessage = "TOTP locker is empty. Import an otpauth:// account first."
                return
            }
            BiometricAuth.authenticate(
                androidContext,
                "Unlock TOTP locker",
                "Show one-time codes",
                onSuccess = {
                    runCatching {
                        lockerAccounts = vault.loadWithAuthenticatedCipher(vault.newDecryptCipher())
                        lockerMessage = "Unlocked ${lockerAccounts.size} account${if (lockerAccounts.size == 1) "" else "s"}."
                    }.onFailure { lockerMessage = it.message ?: "Unable to unlock TOTP locker." }
                },
                onError = { lockerMessage = it }
            )
        }

        LaunchedEffect(context.startsImmediately, secret) {
            if (context.startsImmediately && secret.isNotBlank()) generateExplicit()
        }

        ResultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null }) {
            if (secret.isBlank()) {
                Text("Biometric locker", style = MaterialTheme.typography.titleMedium)
                Text("Seeds remain encrypted at rest and are never returned in the MethodMesh result.")
                Spacer(Modifier.height(8.dp))
                Button(onClick = ::unlockLocker, modifier = Modifier.fillMaxWidth()) { Text("Unlock TOTP locker") }
                if (lockerMessage.isNotBlank()) Text(lockerMessage)
                lockerAccounts.forEach { account ->
                    val generated = runCatching { TotpEngine.generate(account) }.getOrNull()
                    if (generated != null) {
                        Spacer(Modifier.height(6.dp))
                        Text(account.label, style = MaterialTheme.typography.titleSmall)
                        Text("${generated.code}  ·  ${generated.validForSeconds}s")
                        OutlinedButton(onClick = { makeResult(account, account.label) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Use this code")
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Explicit secret", style = MaterialTheme.typography.titleMedium)
            }

            if (context.settingShouldBeShown("secret")) {
                OutlinedTextField(secret, { secret = it }, label = { Text("Base32 secret") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            }
            OutlinedTextField(digits, { digits = it.filter(Char::isDigit) }, label = { Text("Digits (6–8)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(period, { period = it.filter(Char::isDigit) }, label = { Text("Period seconds") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(algorithm, { algorithm = it }, label = { Text("SHA1 / SHA256 / SHA512") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::generateExplicit, enabled = secret.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Generate code") }
            if (code.isNotBlank()) {
                Text(code, style = MaterialTheme.typography.headlineMedium)
                Text("$selectedLabel · valid for $remaining s")
            }
        }
    }
}

