package com.example.methodmesh.modules.cryptography

import android.os.Build
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.FileOutputStream

@Composable
private fun VaultScaffold(
    title: String,
    capabilityId: String,
    context: CapabilityScreenContext,
    result: ExecutionResult?,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    body: @Composable () -> Unit
) {
    CapabilityScreenScaffold(
        title = title,
        capabilityId = capabilityId,
        context = context,
        canGoBack = context.stepNumber > 1,
        capturedResult = result,
        resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
        onBack = onBack,
        onRetry = onRetry,
        onConfirm = { result?.let(onConfirmed) },
        onCancel = onCancel
    ) { body() }
}

private fun vaultUnavailableResult(
    method: AbstractCryptoMethod,
    context: CapabilityScreenContext
): ExecutionResult = CryptoScreenSupport.failed(
    method,
    context,
    IllegalStateException("Biometric TOTP vault requires Android 11 or later with a strong enrolled biometric.")
)

object TotpImportCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TotpImportMethod.id
    override val title = "Import TOTP account"
    override val description = "Import an otpauth:// TOTP account into the biometric-protected local vault."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var otpAuth by rememberSaveable { mutableStateOf(context.action.settings["otpauth_uri"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("") }

        fun importNow() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                result = vaultUnavailableResult(As100TotpImportMethod, context)
                return
            }
            val account = runCatching { TotpEngine.parseOtpAuth(otpAuth) }.getOrElse {
                result = CryptoScreenSupport.failed(As100TotpImportMethod, context, it); return
            }
            val vault = AndroidBiometricVault(androidContext)
            // Make sure a key exists before prompting so the authentication policy is registered.
            runCatching { vault.ensureKey() }.onFailure {
                result = CryptoScreenSupport.failed(As100TotpImportMethod, context, it); return
            }
            BiometricAuth.authenticate(
                context = androidContext,
                title = "Unlock TOTP locker",
                subtitle = "Import ${account.label}",
                onSuccess = {
                    runCatching {
                        val existing = if (vault.hasVault()) vault.loadWithAuthenticatedCipher(vault.newDecryptCipher()) else emptyList()
                        val replacement = existing.filterNot { it.issuer == account.issuer && it.accountName == account.accountName } + account
                        vault.saveWithAuthenticatedCipher(vault.newEncryptCipher(), replacement)
                        status = "Imported ${account.label} (${replacement.size} account${if (replacement.size == 1) "" else "s"} in locker)."
                        result = CryptoScreenSupport.succeeded(
                            As100TotpImportMethod,
                            context,
                            mapOf(
                                CryptoFields.VALUE to account.label,
                                CryptoFields.FORMAT to "RFC 6238 / otpauth TOTP account",
                                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                                    methodId = capabilityId,
                                    status = "succeeded",
                                    format = "RFC6238/otpauth",
                                    protection = "Android Keystore key gated by BIOMETRIC_STRONG",
                                    extra = mapOf("account_label" to account.label, "account_count" to replacement.size)
                                )
                            )
                        )
                    }.onFailure { result = CryptoScreenSupport.failed(As100TotpImportMethod, context, it) }
                },
                onError = { result = CryptoScreenSupport.failed(As100TotpImportMethod, context, IllegalStateException(it)) }
            )
        }

        VaultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; importNow() }) {
            Text("Paste an otpauth:// URI or hand one in from a QR/NFC capability. The seed is encrypted locally and is never returned in MethodMesh provenance.")
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = otpAuth,
                onValueChange = { otpAuth = it },
                label = { Text("otpauth:// URI") },
                visualTransformation = PasswordVisualTransformation(),
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = ::importNow, modifier = Modifier.fillMaxWidth()) { Text("Unlock and import") }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

object TotpDeleteCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TotpDeleteMethod.id
    override val title = "Delete TOTP account"
    override val description = "Delete one TOTP account from the biometric-protected locker."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var label by rememberSaveable { mutableStateOf(context.action.settings["account_label"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun deleteNow() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                result = vaultUnavailableResult(As100TotpDeleteMethod, context); return
            }
            val vault = AndroidBiometricVault(androidContext)
            if (!vault.hasVault()) {
                result = CryptoScreenSupport.failed(As100TotpDeleteMethod, context, IllegalStateException("TOTP locker is empty.")); return
            }
            BiometricAuth.authenticate(
                androidContext,
                "Unlock TOTP locker",
                "Delete $label",
                onSuccess = {
                    runCatching {
                        val current = vault.loadWithAuthenticatedCipher(vault.newDecryptCipher())
                        val next = current.filterNot { it.label == label }
                        require(next.size < current.size) { "No TOTP account matched '$label'." }
                        vault.saveWithAuthenticatedCipher(vault.newEncryptCipher(), next)
                        result = CryptoScreenSupport.succeeded(
                            As100TotpDeleteMethod,
                            context,
                            mapOf(
                                CryptoFields.VALUE to label,
                                CryptoFields.FORMAT to "TOTP locker change",
                                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                                    capabilityId,
                                    "succeeded",
                                    format = "RFC6238 vault metadata",
                                    protection = "Android Keystore key gated by BIOMETRIC_STRONG",
                                    extra = mapOf("deleted_account_label" to label, "remaining_account_count" to next.size)
                                )
                            )
                        )
                    }.onFailure { result = CryptoScreenSupport.failed(As100TotpDeleteMethod, context, it) }
                },
                onError = { result = CryptoScreenSupport.failed(As100TotpDeleteMethod, context, IllegalStateException(it)) }
            )
        }

        VaultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; deleteNow() }) {
            OutlinedTextField(label, { label = it }, label = { Text("Exact account label") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = ::deleteNow, modifier = Modifier.fillMaxWidth()) { Text("Unlock and delete") }
        }
    }
}

object TotpExportCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TotpExportMethod.id
    override val title = "Export encrypted TOTP backup"
    override val description = "Export TOTP seeds only inside password- or recipient-encrypted OpenPGP ciphertext."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var password by rememberSaveable { mutableStateOf(context.action.settings["password"] ?: "") }
        var recipientCertificate by rememberSaveable { mutableStateOf(context.action.settings["recipient_certificate"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun exportNow() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                result = vaultUnavailableResult(As100TotpExportMethod, context); return
            }
            require(password.isNotEmpty() || recipientCertificate.isNotBlank()) {
                "Supply a backup password or recipient OpenPGP certificate."
            }
            val vault = AndroidBiometricVault(androidContext)
            if (!vault.hasVault()) {
                result = CryptoScreenSupport.failed(As100TotpExportMethod, context, IllegalStateException("TOTP locker is empty.")); return
            }
            BiometricAuth.authenticate(
                androidContext,
                "Unlock TOTP locker",
                "Create encrypted backup",
                onSuccess = {
                    runCatching {
                        val accounts = vault.loadWithAuthenticatedCipher(vault.newDecryptCipher())
                        val clearJson = JSONObject().apply {
                            put("schema", "methodmesh.totp.backup.v1")
                            put("accounts", JSONArray().apply {
                                accounts.forEach { put(TotpEngine.toOtpAuth(it)) }
                            })
                        }.toString().toByteArray(Charsets.UTF_8)

                        val file = CryptoScreenSupport.cacheFile(androidContext, "methodmesh-totp-backup.pgp")
                        FileOutputStream(file).use { out ->
                            if (recipientCertificate.isNotBlank()) {
                                OpenPgpEngine.encryptForRecipients(
                                    ByteArrayInputStream(clearJson),
                                    out,
                                    listOf(recipientCertificate.toByteArray(Charsets.UTF_8))
                                )
                            } else {
                                OpenPgpEngine.encryptWithPassword(ByteArrayInputStream(clearJson), out, password, armor = false)
                            }
                        }
                        // Minimise lifetime of the clear backup byte array.
                        clearJson.fill(0)
                        val outputSha = HashEngine.hex(file)
                        val protection = if (recipientCertificate.isNotBlank()) "OpenPGP recipient public key" else "OpenPGP password"
                        result = CryptoScreenSupport.succeeded(
                            As100TotpExportMethod,
                            context,
                            mapOf(
                                CryptoFields.OUTPUT_URI to CryptoScreenSupport.shareableUri(androidContext, file),
                                CryptoFields.OUTPUT_FILENAME to file.name,
                                CryptoFields.OUTPUT_SHA256 to outputSha,
                                CryptoFields.FORMAT to "OpenPGP binary (.pgp)",
                                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                                    capabilityId,
                                    "succeeded",
                                    outputSha256 = outputSha,
                                    format = "OpenPGP",
                                    protection = protection,
                                    extra = mapOf("account_count" to accounts.size, "cleartext_export_returned" to false)
                                )
                            )
                        )
                    }.onFailure { result = CryptoScreenSupport.failed(As100TotpExportMethod, context, it) }
                },
                onError = { result = CryptoScreenSupport.failed(As100TotpExportMethod, context, IllegalStateException(it)) }
            )
        }

        VaultScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; exportNow() }) {
            Text("The backup is never returned as plaintext. MethodMesh decrypts the biometric vault only in memory and immediately OpenPGP-encrypts the export.")
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Backup password (or use recipient certificate)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(recipientCertificate, { recipientCertificate = it }, label = { Text("Recipient OpenPGP public certificate (optional)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = ::exportNow, modifier = Modifier.fillMaxWidth()) { Text("Unlock and export encrypted backup") }
        }
    }
}
