package com.example.methodmesh.modules.referencelibrary

import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.modules.MethodMeshModuleRegistry
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ExternalActionRequest
import com.example.methodmesh.transport.workflow.ui.CapabilityCompletionMode
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

object ReferenceLibraryCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ReferenceLibraryMethod.ID
    override val title = "Reference library"
    override val description = "Useful documents, ready when the network is not."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val repository = remember { ReferenceLibraryRepository(appContext) }
        // Treat every ordinary manual native run as the persistent library dashboard.
        // HomeScreen can construct a manual-confirmation capability context through more
        // than one native route; presentationMode alone is therefore too narrow and can
        // allow a read action to fall through into CapabilityScreenScaffold's Result page.
        // Native presets remain transactional and external/ODK runs are AutomaticReturn.
        val dashboardMode =
            context.completionMode == CapabilityCompletionMode.ManualConfirmation &&
                !context.isNativePresetRun
        var documents by remember { mutableStateOf(repository.documents()) }
        var customShelves by remember { mutableStateOf(repository.customShelves()) }
        var query by rememberSaveable { mutableStateOf(context.action.settings["query"] ?: context.action.settings["input_query"] ?: "") }
        var shelf by rememberSaveable { mutableStateOf(context.action.settings["shelf"] ?: context.action.settings["input_shelf"] ?: "all") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
        var pendingShelf by rememberSaveable { mutableStateOf("personal") }
        var statusMessage by rememberSaveable { mutableStateOf<String?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var scannerActive by rememberSaveable { mutableStateOf(false) }
        var scannerHandled by rememberSaveable { mutableStateOf(false) }
        var pendingScanUri by rememberSaveable { mutableStateOf<String?>(null) }
        var pendingScanName by rememberSaveable { mutableStateOf("") }
        var pendingScanShelf by rememberSaveable { mutableStateOf("personal") }
        var editingDocumentId by rememberSaveable { mutableStateOf<String?>(null) }
        var editDocumentTitle by rememberSaveable { mutableStateOf("") }
        var editDocumentShelf by rememberSaveable { mutableStateOf("personal") }
        var manageShelves by rememberSaveable { mutableStateOf(false) }
        var newShelfName by rememberSaveable { mutableStateOf("") }
        var shelfToDelete by rememberSaveable { mutableStateOf<String?>(null) }
        val allShelves = BUILT_IN_SHELVES + customShelves
        fun shelfLabel(id: String): String = allShelves.firstOrNull { it.id == id }?.label ?: id.labelForShelf()

        fun executionFor(values: Map<String, String>): ExecutionResult {
            val request = As100ReferenceLibraryMethod.request(
                action = As100ReferenceLibraryMethod.ID,
                context = context.request.invocationContext.asMap(As100ReferenceLibraryMethod.ID) + context.action.settings,
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100ReferenceLibraryMethod.result(request, values, context.request.invocationContext)
        }

        fun selectDocument(document: LibraryDocument) {
            selectedId = document.id
            repository.markOpened(document.id)
            documents = repository.documents()
            result = executionFor(As100ReferenceLibraryMethod.selected(document))
            statusMessage = "Selected ${document.title}"
            if (context.submitsImmediately) result?.let(onConfirmed)
        }

        fun launchViewer(document: LibraryDocument) {
            runCatching {
                appContext.startActivity(
                    Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(Uri.parse(document.uri), document.mimeType)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }.onFailure {
                statusMessage = "No installed app can open this document type."
            }
        }

        fun openDocument(document: LibraryDocument) {
            if (!repository.isReadable(document)) {
                if (dashboardMode) {
                    statusMessage = "Document unavailable. Re-import it or restore access to its storage location."
                    return
                }
                val failed = executionFor(
                    As100ReferenceLibraryMethod.failure(
                        documentId = document.id,
                        shelf = document.shelf,
                        status = "unavailable",
                        error = "This document is no longer readable. Re-import it or restore access to its storage location."
                    )
                )
                result = failed
                statusMessage = "Document unavailable"
                if (context.submitsImmediately) onConfirmed(failed)
                return
            }

            if (dashboardMode) {
                // Direct MethodMesh use is a persistent library dashboard, not a
                // capture-and-conclude workflow. Opening a document records recency
                // and launches the reader without creating a MethodMesh result.
                selectedId = null
                result = null
                repository.markOpened(document.id)
                documents = repository.documents()
                statusMessage = null
                launchViewer(document)
                return
            }

            // Preset/protocol/ODK/external launches still honour the normal
            // MethodMesh select/return contract.
            selectDocument(document)
            if (!context.submitsImmediately) launchViewer(document)
        }

        if (scannerActive) {
            val scannerScreen = remember { MethodMeshModuleRegistry.screenFor("document.scan") }
            if (scannerScreen == null) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Document scanner unavailable", style = MaterialTheme.typography.titleLarge)
                        Text("Install or enable the MethodMesh Document Scanner module, then try again.")
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { scannerActive = false }) { Text("Back to library") }
                    }
                }
            } else {
                val scannerAction = remember {
                    ExternalActionRequest(
                        requestedId = "document.scan",
                        settings = mapOf(
                            "page_limit" to "20",
                            "scanner_mode" to "full",
                            "allow_gallery_import" to "true",
                            "run_ocr" to "true",
                            "return_searchable_pdf" to "true",
                            "return_text_file" to "false"
                        )
                    )
                }
                val scannerContext = context.copy(
                    action = scannerAction,
                    request = context.request.copy(
                        actions = listOf(scannerAction),
                        source = "reference_library_dependency"
                    ),
                    stepNumber = 1,
                    totalSteps = 1,
                    completionMode = CapabilityCompletionMode.AutomaticReturn,
                    presentationMode = CapabilityPresentationMode.Dashboard,
                    onSettingsChanged = {}
                )
                scannerScreen.Render(
                    context = scannerContext,
                    onBack = { scannerActive = false },
                    onConfirmed = { scanResult ->
                        if (!scannerHandled) {
                            scannerHandled = true
                            val fields = OutputFormatter.fields(scanResult, includeProvenance = false)
                            val scannedUri = fields["document_scan_searchable_pdf_uri"]?.toString().orEmpty()
                                .ifBlank { fields["document_scan_pdf_uri"]?.toString().orEmpty() }
                            if (scannedUri.isBlank()) {
                                scannerActive = false
                                statusMessage = "The scanner completed but did not return a PDF."
                            } else {
                                pendingScanUri = scannedUri
                                pendingScanName = "Scanned document"
                                pendingScanShelf = if (shelf == "all") "personal" else shelf
                                scannerActive = false
                            }
                        }
                    },
                    onCancel = {
                        scannerHandled = true
                        scannerActive = false
                        statusMessage = "Scan cancelled"
                    }
                )
            }
            return
        }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri ?: return@rememberLauncherForActivityResult
            val permissionPersisted = runCatching {
                appContext.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                true
            }.getOrDefault(false)

            val name = runCatching {
                appContext.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
            }.getOrNull().orEmpty().ifBlank { "Imported document" }
            val mime = appContext.contentResolver.getType(uri).orEmpty().ifBlank { "application/octet-stream" }
            val imported = repository.importDocument(name, pendingShelf, uri, mime)
            documents = repository.documents()
            statusMessage = if (permissionPersisted) "Added to ${pendingShelf.labelForShelf()}" else "Added; long-term access depends on the document provider"
            if (!dashboardMode) {
                selectDocument(imported)
            } else {
                selectedId = null
                result = null
            }
        }

        LaunchedEffect(query, shelf) {
            context.onSettingsChanged(mapOf("query" to query, "shelf" to shelf))
        }

        LaunchedEffect(context.presentationMode, context.action.settings, documents) {
            if (context.presentationMode == CapabilityPresentationMode.IntentLaunch && !launched) {
                launched = true
                val targetId = context.action.settings["document_id"] ?: context.action.settings["input_document_id"]
                if (!targetId.isNullOrBlank()) {
                    val target = documents.firstOrNull { it.id == targetId }
                    if (target != null) {
                        if (repository.isReadable(target)) {
                            selectDocument(target)
                        } else {
                            val failed = executionFor(
                                As100ReferenceLibraryMethod.failure(
                                    documentId = targetId,
                                    shelf = target.shelf,
                                    status = "unavailable",
                                    error = "The requested reference document is no longer readable on this device."
                                )
                            )
                            result = failed
                            statusMessage = "Requested document unavailable"
                            if (context.submitsImmediately) onConfirmed(failed)
                        }
                    } else {
                        val failed = executionFor(
                            As100ReferenceLibraryMethod.failure(
                                documentId = targetId,
                                shelf = shelf,
                                status = "not_found",
                                error = "The requested reference document ID is not installed on this device."
                            )
                        )
                        result = failed
                        statusMessage = "Requested document not found"
                        if (context.submitsImmediately) onConfirmed(failed)
                    }
                }
            }
        }

        val visible = documents
            .filter { shelf == "all" || it.shelf == shelf }
            .filter {
                query.isBlank() ||
                    it.title.contains(query, ignoreCase = true) ||
                    it.source.contains(query, ignoreCase = true) ||
                    it.shelf.contains(query.replace(' ', '_'), ignoreCase = true)
            }
            .sortedWith(
                compareByDescending<LibraryDocument> { it.favourite }
                    .thenByDescending { it.lastOpenedEpochMs }
                    .thenBy { it.title.lowercase() }
            )
        val recent = documents.filter { it.lastOpenedEpochMs > 0 }.sortedByDescending { it.lastOpenedEpochMs }.take(5)

        val libraryContent: @Composable () -> Unit = {
            Column(Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "REFERENCE LIBRARY",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(
                            "Your field shelf",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "${documents.size} document${if (documents.size == 1) "" else "s"} · ${allShelves.size} shelves",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (dashboardMode) {
                        TextButton(onClick = { manageShelves = true }) { Text("Manage") }
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search title, shelf or source") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp)
                )

                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(listOf(LibraryShelf("all", "All")) + allShelves, key = { it.id }) { item ->
                        val count = if (item.id == "all") documents.size else documents.count { it.shelf == item.id }
                        FilterChip(
                            selected = shelf == item.id,
                            onClick = { shelf = item.id },
                            label = { Text(if (count > 0) "${item.label}  $count" else item.label) },
                            shape = RoundedCornerShape(50)
                        )
                    }
                }

                if (recent.isNotEmpty() && query.isBlank() && shelf == "all") {
                    Spacer(Modifier.height(24.dp))
                    SectionTitle("Continue reading")
                    Spacer(Modifier.height(9.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(recent, key = { it.id }) { document ->
                            DocumentTile(
                                document = document,
                                selected = document.id == selectedId,
                                shelfLabel = shelfLabel(document.shelf),
                                onOpen = { openDocument(document) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SectionTitle(if (shelf == "all") "All documents" else shelfLabel(shelf))
                    if (visible.isNotEmpty()) {
                        Text(
                            visible.size.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(9.dp))

                if (visible.isEmpty()) {
                    EmptyLibraryCard(
                        filtered = documents.isNotEmpty(),
                        onImport = {
                            pendingShelf = if (shelf == "all") "personal" else shelf
                            picker.launch(arrayOf("application/pdf", "text/*", "image/*"))
                        }
                    )
                } else {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.22f)
                    ) {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                            visible.forEachIndexed { index, document ->
                                LibraryRow(
                                    document = document,
                                    selected = document.id == selectedId,
                                    onOpen = { openDocument(document) },
                                    shelfLabel = shelfLabel(document.shelf),
                                    onFavourite = {
                                        repository.toggleFavourite(document.id)
                                        documents = repository.documents()
                                    },
                                    onEdit = {
                                        editingDocumentId = document.id
                                        editDocumentTitle = document.title
                                        editDocumentShelf = document.shelf
                                    },
                                    onRemove = {
                                        repository.remove(document.id)
                                        if (selectedId == document.id) {
                                            selectedId = null
                                            result = null
                                        }
                                        documents = repository.documents()
                                        statusMessage = "Removed from library; original file was not deleted"
                                    }
                                )
                                if (index < visible.lastIndex) {
                                    HorizontalDivider(
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.42f)
                                    )
                                }
                            }
                        }
                    }
                }

                statusMessage?.let {
                    Spacer(Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.32f)
                    ) {
                        Text(
                            it,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }

                Spacer(Modifier.height(18.dp))
                if (dashboardMode) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.18f)
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    scannerHandled = false
                                    scannerActive = true
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Scan") }
                            OutlinedButton(
                                onClick = {
                                    pendingShelf = if (shelf == "all") "personal" else shelf
                                    picker.launch(arrayOf("application/pdf", "text/*", "image/*"))
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(16.dp)
                            ) { Text("Add file") }
                        }
                    }
                } else {
                    Button(
                        onClick = {
                            pendingShelf = if (shelf == "all") "personal" else shelf
                            picker.launch(arrayOf("application/pdf", "text/*", "image/*"))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) { Text("Add document") }
                }
            }
        }

        if (dashboardMode) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                libraryContent()
            }
        } else {
            CapabilityScreenScaffold(
                title = title,
                capabilityId = capabilityId,
                context = context,
                canGoBack = context.stepNumber > 1,
                capturedResult = result,
                resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
                onBack = onBack,
                onRetry = { selectedId?.let(repository::document)?.let(::selectDocument) },
                onConfirm = { result?.let(onConfirmed) },
                onCancel = onCancel,
                content = libraryContent
            )
        }

        if (dashboardMode && pendingScanUri != null) {
            AlertDialog(
                onDismissRequest = {
                    pendingScanUri = null
                    pendingScanName = ""
                },
                title = { Text("Save scan to shelf") },
                text = {
                    Column {
                        Text("Give the scanned document a useful name and choose where it belongs.")
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = pendingScanName,
                            onValueChange = { pendingScanName = it.take(100) },
                            label = { Text("Document name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("Shelf", style = MaterialTheme.typography.labelLarge)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(allShelves, key = { it.id }) { item ->
                                FilterChip(
                                    selected = pendingScanShelf == item.id,
                                    onClick = { pendingScanShelf = item.id },
                                    label = { Text(item.label) }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        enabled = pendingScanName.isNotBlank(),
                        onClick = {
                            val uri = pendingScanUri ?: return@Button
                            runCatching {
                                repository.importManagedCopy(
                                    sourceUri = Uri.parse(uri),
                                    title = pendingScanName.trim(),
                                    shelf = pendingScanShelf
                                )
                            }.onSuccess { imported ->
                                documents = repository.documents()
                                statusMessage = "Scanned ${imported.title} into ${shelfLabel(imported.shelf)}"
                                pendingScanUri = null
                                pendingScanName = ""
                            }.onFailure { error ->
                                statusMessage = "Could not save scan: ${error.message ?: "storage error"}"
                            }
                        }
                    ) { Text("Save to shelf") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        pendingScanUri = null
                        pendingScanName = ""
                    }) { Text("Discard") }
                }
            )
        }

        if (dashboardMode && editingDocumentId != null) {
            AlertDialog(
                onDismissRequest = { editingDocumentId = null },
                title = { Text("Edit library entry") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = editDocumentTitle,
                            onValueChange = { editDocumentTitle = it.take(100) },
                            label = { Text("Document name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("Shelf", style = MaterialTheme.typography.labelLarge)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(allShelves, key = { it.id }) { item ->
                                FilterChip(
                                    selected = editDocumentShelf == item.id,
                                    onClick = { editDocumentShelf = item.id },
                                    label = { Text(item.label) }
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        enabled = editDocumentTitle.isNotBlank(),
                        onClick = {
                            val id = editingDocumentId ?: return@Button
                            repository.updateDocument(id, editDocumentTitle, editDocumentShelf)?.let { updated ->
                                documents = repository.documents()
                                statusMessage = "Updated ${updated.title}"
                            }
                            editingDocumentId = null
                        }
                    ) { Text("Save changes") }
                },
                dismissButton = { TextButton(onClick = { editingDocumentId = null }) { Text("Cancel") } }
            )
        }

        if (dashboardMode && manageShelves) {
            AlertDialog(
                onDismissRequest = { manageShelves = false },
                title = { Text("Manage shelves") },
                text = {
                    Column {
                        Text("Built-in shelves stay available for presets and ODK. Custom shelves are local to this library.")
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = newShelfName,
                            onValueChange = { newShelfName = it.take(40) },
                            label = { Text("New shelf name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            enabled = newShelfName.isNotBlank(),
                            onClick = {
                                runCatching { repository.addCustomShelf(newShelfName) }
                                    .onSuccess { created ->
                                        customShelves = repository.customShelves()
                                        shelf = created.id
                                        newShelfName = ""
                                        statusMessage = "Created ${created.label}"
                                    }
                                    .onFailure { error -> statusMessage = error.message ?: "Could not create shelf" }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Create shelf") }
                        if (customShelves.isNotEmpty()) {
                            Spacer(Modifier.height(16.dp))
                            Text("Custom shelves", style = MaterialTheme.typography.labelLarge)
                            customShelves.forEach { custom ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${custom.label}  ${documents.count { it.shelf == custom.id }}", modifier = Modifier.weight(1f).padding(vertical = 10.dp))
                                    TextButton(onClick = { manageShelves = false; shelfToDelete = custom.id }) { Text("Delete") }
                                }
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { manageShelves = false }) { Text("Done") } }
            )
        }

        val deletingShelf = shelfToDelete?.let { id -> customShelves.firstOrNull { it.id == id } }
        if (dashboardMode && deletingShelf != null) {
            val affected = documents.count { it.shelf == deletingShelf.id }
            AlertDialog(
                onDismissRequest = { shelfToDelete = null },
                title = { Text("Delete ${deletingShelf.label}?") },
                text = {
                    Text(
                        if (affected == 0) "This removes the custom shelf."
                        else "$affected document${if (affected == 1) "" else "s"} will move to Personal. No files will be deleted."
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        val moved = repository.deleteCustomShelf(deletingShelf.id, "personal")
                        customShelves = repository.customShelves()
                        documents = repository.documents()
                        if (shelf == deletingShelf.id) shelf = "personal"
                        if (editDocumentShelf == deletingShelf.id) editDocumentShelf = "personal"
                        if (pendingScanShelf == deletingShelf.id) pendingScanShelf = "personal"
                        statusMessage = if (moved == 0) "Deleted ${deletingShelf.label}" else "Deleted ${deletingShelf.label}; moved $moved document${if (moved == 1) "" else "s"} to Personal"
                        shelfToDelete = null
                    }) { Text("Delete shelf") }
                },
                dismissButton = { TextButton(onClick = { shelfToDelete = null }) { Text("Cancel") } }
            )
        }
    }
}

private val BUILT_IN_SHELVES = listOf(
    LibraryShelf("first_aid", "First aid"),
    LibraryShelf("medical", "Medical"),
    LibraryShelf("safety", "Safety"),
    LibraryShelf("fieldwork", "Fieldwork"),
    LibraryShelf("equipment", "Equipment"),
    LibraryShelf("travel", "Travel"),
    LibraryShelf("personal", "Personal")
)

private fun String.labelForShelf(): String =
    BUILT_IN_SHELVES.firstOrNull { it.id == this }?.label ?: replace('_', ' ').replaceFirstChar { it.uppercase() }

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurface
    )
}

private fun documentKind(document: LibraryDocument): String = when {
    document.mimeType.contains("pdf", ignoreCase = true) -> "PDF"
    document.mimeType.startsWith("image/", ignoreCase = true) -> "IMG"
    document.mimeType.startsWith("text/", ignoreCase = true) -> "TXT"
    else -> "DOC"
}

@Composable
private fun DocumentTile(
    document: LibraryDocument,
    selected: Boolean,
    shelfLabel: String,
    onOpen: () -> Unit
) {
    Surface(
        modifier = Modifier.width(176.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(20.dp),
        color = if (selected) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f)
        }
    ) {
        Column(Modifier.padding(15.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(9.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
                ) {
                    Text(
                        documentKind(document),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    )
                }
                if (document.favourite) {
                    Text("★", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(
                document.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(5.dp))
            Text(
                shelfLabel,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun LibraryRow(
    document: LibraryDocument,
    selected: Boolean,
    shelfLabel: String,
    onOpen: () -> Unit,
    onFavourite: () -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (selected) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.80f)
            } else {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
            }
        ) {
            Column(
                modifier = Modifier.width(46.dp).padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    documentKind(document),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    document.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (document.favourite) {
                    Spacer(Modifier.width(6.dp))
                    Text("★", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                }
            }
            Spacer(Modifier.height(3.dp))
            Text(
                buildString {
                    append(shelfLabel)
                    if (document.source.isNotBlank() && !document.source.equals("User supplied", ignoreCase = true)) {
                        append("  ·  ${document.source}")
                    }
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(4.dp))
        Box {
            TextButton(onClick = { menuExpanded = true }) {
                Text("•••", style = MaterialTheme.typography.titleSmall)
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                DropdownMenuItem(
                    text = { Text(if (document.favourite) "Remove favourite" else "Add to favourites") },
                    onClick = { menuExpanded = false; onFavourite() }
                )
                DropdownMenuItem(
                    text = { Text("Rename or move") },
                    onClick = { menuExpanded = false; onEdit() }
                )
                DropdownMenuItem(
                    text = { Text("Remove from library") },
                    onClick = { menuExpanded = false; onRemove() }
                )
            }
        }
    }
}

@Composable
private fun EmptyLibraryCard(filtered: Boolean, onImport: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.22f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 24.dp)) {
            Text(
                if (filtered) "Nothing found" else "A quiet shelf",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                if (filtered) "Try another search or shelf." else "Add a PDF, text file or image and it will be ready offline.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 5.dp, bottom = 8.dp)
            )
            TextButton(onClick = onImport) { Text(if (filtered) "Add document" else "Add first document") }
        }
    }
}

