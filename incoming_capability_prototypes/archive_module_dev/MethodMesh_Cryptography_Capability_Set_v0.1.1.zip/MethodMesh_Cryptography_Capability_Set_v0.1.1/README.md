# MethodMesh Cryptography Capability Set v0.1.1

Development capability package for MethodMesh.

This package adds a `cryptography` module and carries the existing `trustedtimestamp` module unchanged so the two can be integrated as one user-facing cryptography family without changing the existing method identity `integrity.trusted_timestamp`.

## Design commitments

1. **Methods, not a monolith.** Each operation is a Method with its own capability screen, RIL binding, settings and structured outputs.
2. **Interoperable cryptographic artefacts.** Portable encryption and signatures use OpenPGP; trusted timestamps use RFC 3161; TOTP uses RFC 6238 and `otpauth://` provisioning. There is no MethodMesh encrypted-file container.
3. **Secrets do not enter provenance.** Passwords, private keys, TOTP seeds and biometric data are never written to `crypto_provenance_json`.
4. **Biometrics are authorization, not key material.** The Android biometric API gates a device-local Android Keystore key. MethodMesh never receives biometric templates.
5. **NFC/QR are transports.** Cryptography emits public identity tokens, certificates, fingerprints, challenges and interoperable provisioning strings; existing NFC/QR capabilities transport them.
6. **ODK remains the research-record owner.** ODK can hand text/files to MethodMesh and receive ciphertext, hashes, signatures and provenance. Server-side decryption does not require MethodMesh.
7. **Trusted time is composed, not duplicated.** `integrity.trusted_timestamp` stays intact and may be composed after hashing/signing/encryption where a protocol needs independent proof of time.

## Contents

- `cryptography/` — new module source, screens, core crypto helpers, tests, docs and XLSForm examples.
- `trustedtimestamp/` — existing trusted timestamp capability copied unchanged for integration.

See `cryptography/docs/README_Cryptography.md` first.
