#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/build"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  $(find "$ROOT/src/main/kotlin" -name '*.kt' | sort) \
  $(find "$ROOT/src/test/kotlin" -name '*.kt' | sort) \
  -include-runtime -d "$OUT/gamedeck-tests.jar"
java -cp "$OUT/gamedeck-tests.jar" com.methodmesh.gamedeck.PrototypeTests
