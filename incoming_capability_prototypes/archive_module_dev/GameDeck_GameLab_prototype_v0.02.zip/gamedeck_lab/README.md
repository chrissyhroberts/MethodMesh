# GameDeck / GameLab prototype

First executable vertical slice derived from `GameDeck_GameLab_Specification_v0.02.md`.

## What exists

- pure-Kotlin GameDeck game contracts;
- event/replay model;
- thin `ChanceEngine` adapter over the existing MethodMesh `DiceSimulatorEngine`;
- explicit secure-runtime vs fixed-seed deterministic randomness;
- Connect Four proving game;
- Snakes & Ladders stochastic proving game using Chance rather than its own RNG;
- headless GameLab simulation;
- random and heuristic Connect Four agents;
- deterministic/replay regression tests.

This deliberately does **not** recreate the existing Android/Compose Chance visuals. Those remain upstream MethodMesh components and should be reused when this headless core is integrated into the app.

## Run

Requires JDK + Kotlin compiler (`kotlinc`).

```bash
./run_tests.sh
./run_demo.sh
```

## Architecture proven here

```text
Game Module -> GameDeck contracts -> shared Chance adapter
                           |
                           +-> event/replay
                           +-> headless GameLab agents/simulation
```

## Next implementation steps

1. Integrate the full `ChanceSelectionEngine` through an adapter in the real MethodMesh/Android project (cards, spinner, weighted choice, pick-one).
2. Add versioned JSON persistence for players, saves and replays.
3. Add a generic parameter-definition contract for GameLab.
4. Turn Connect Four into the first parameter/simulation dashboard.
5. Add Minesweeper as the first procedural validation problem.
6. Only then add player skills/adaptive generation and P2P.

## Upstream Chance

GameDeck **does not vendor `DiceSimulatorEngine.kt`**. The existing MethodMesh Chance capability remains the single source of truth.

Production integration lives in `src/integration/kotlin/.../MethodMeshChanceProvider.kt`. It imports the existing `com.example.methodmesh.modules.chance.DiceSimulatorEngine` and adapts it to the small GameDeck `ChanceProvider` contract.

At MethodMesh startup install it once:

```kotlin
ChanceEngine.install(MethodMeshChanceProvider)
```

The standalone prototype tests use a deliberately limited test-only `TestChanceProvider`; this avoids declaring a second `DiceSimulatorEngine` and therefore avoids Kotlin redeclaration errors.


## MethodMesh integration

When these sources are added to the existing MethodMesh Android app, compile `src/main/kotlin` plus `src/integration/kotlin`. Do **not** copy any `DiceSimulatorEngine.kt` from GameDeck: none is included. The adapter compiles against the engine already present in the Chance capability.

Install the provider during application/bootstrap initialization:

```kotlin
import com.methodmesh.gamedeck.chance.ChanceEngine
import com.methodmesh.gamedeck.chance.MethodMeshChanceProvider

ChanceEngine.install(MethodMeshChanceProvider)
```

The integration adapter has been compile-checked against the `DiceSimulatorEngine.kt` supplied in `chance.zip`.
