#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/build"
mkdir -p "$OUT"
# The demo is headless and does not use Chance. Production MethodMesh builds additionally compile
# src/integration/kotlin and use the existing MethodMesh Chance engine.
kotlinc \
  $(find "$ROOT/src/main/kotlin" -name '*.kt' | sort) \
  -include-runtime -d "$OUT/gamedeck-demo.jar"
java -cp "$OUT/gamedeck-demo.jar" com.methodmesh.gamedeck.MainKt
