package com.methodmesh.gamedeck.games.snakes

import com.methodmesh.gamedeck.chance.ChanceEngine
import com.methodmesh.gamedeck.core.*

data class SnakesState(
    val positions: List<Int> = listOf(0, 0),
    val player: Int = 1,
    val turn: Int = 0,
    val seed: String? = null,
    val lastRoll: Int? = null,
    val winningPlayer: Int? = null
) : GameState

data class RollTurn(val expectedTurn: Int) : GameAction

object SnakesAndLadders : GameModule<SnakesState, RollTurn> {
    override val manifest = GameManifest("snakes_ladders", "Snakes & Ladders", "0.1.0", 2, 2, stochastic = true)

    private val jumps = mapOf(
        1 to 38, 4 to 14, 9 to 31, 21 to 42, 28 to 84, 36 to 44, 51 to 67, 71 to 91, 80 to 100,
        16 to 6, 47 to 26, 49 to 11, 56 to 53, 62 to 19, 64 to 60, 87 to 24, 93 to 73, 95 to 75, 98 to 78
    )

    override fun initialState(seed: String?) = SnakesState(seed = seed)

    override fun legalActions(state: SnakesState, player: Int): List<RollTurn> =
        if (!isTerminal(state) && state.player == player) listOf(RollTurn(state.turn)) else emptyList()

    override fun applyAction(state: SnakesState, action: RollTurn, player: Int): SnakesState {
        require(action in legalActions(state, player)) { "Illegal roll action" }
        val chance = if (state.seed == null) ChanceEngine.runtime() else ChanceEngine.deterministic(state.seed)
        val roll = chance.roll("d6", stream = "turn-${state.turn}").total
        val i = player - 1
        val current = state.positions[i]
        val raw = current + roll
        val landed = if (raw <= 100) jumps[raw] ?: raw else current
        val positions = state.positions.toMutableList().also { it[i] = landed }.toList()
        val winner = if (landed == 100) player else null
        return SnakesState(
            positions = positions,
            player = if (player == 1) 2 else 1,
            turn = state.turn + 1,
            seed = state.seed,
            lastRoll = roll,
            winningPlayer = winner
        )
    }

    override fun currentPlayer(state: SnakesState) = state.player
    override fun isTerminal(state: SnakesState) = state.winningPlayer != null
    override fun winner(state: SnakesState) = state.winningPlayer
    override fun serialize(state: SnakesState): String =
        "{\"positions\":[${state.positions.joinToString(",")}],\"player\":${state.player},\"turn\":${state.turn},\"last_roll\":${state.lastRoll ?: "null"},\"winner\":${state.winningPlayer ?: "null"},\"seed\":${state.seed?.let { "\"$it\"" } ?: "null"}}"
}
