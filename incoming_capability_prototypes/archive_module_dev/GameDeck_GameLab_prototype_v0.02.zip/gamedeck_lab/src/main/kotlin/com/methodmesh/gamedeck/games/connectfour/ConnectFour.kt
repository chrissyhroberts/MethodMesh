package com.methodmesh.gamedeck.games.connectfour

import com.methodmesh.gamedeck.core.*

data class ConnectFourState(
    val board: List<List<Int>> = List(6) { List(7) { 0 } },
    val player: Int = 1,
    val moveCount: Int = 0,
    val winningPlayer: Int? = null
) : GameState

data class Drop(val column: Int) : GameAction

object ConnectFour : GameModule<ConnectFourState, Drop> {
    override val manifest = GameManifest("connect_four", "Connect Four", "0.1.0", 2, 2, stochastic = false)

    override fun initialState(seed: String?) = ConnectFourState()

    override fun legalActions(state: ConnectFourState, player: Int): List<Drop> {
        if (isTerminal(state) || state.player != player) return emptyList()
        return (0..6).filter { state.board[0][it] == 0 }.map(::Drop)
    }

    override fun applyAction(state: ConnectFourState, action: Drop, player: Int): ConnectFourState {
        require(action in legalActions(state, player)) { "Illegal column ${action.column}" }
        val rows = state.board.map { it.toMutableList() }.toMutableList()
        val row = (5 downTo 0).first { rows[it][action.column] == 0 }
        rows[row][action.column] = player
        val frozen = rows.map { it.toList() }
        val winner = if (hasFour(frozen, player)) player else null
        return ConnectFourState(frozen, if (player == 1) 2 else 1, state.moveCount + 1, winner)
    }

    override fun currentPlayer(state: ConnectFourState) = state.player
    override fun isTerminal(state: ConnectFourState) = state.winningPlayer != null || state.moveCount == 42
    override fun winner(state: ConnectFourState) = state.winningPlayer
    override fun serialize(state: ConnectFourState): String = buildString {
        append("{\"player\":${state.player},\"move_count\":${state.moveCount},\"winner\":")
        append(state.winningPlayer ?: "null")
        append(",\"board\":[")
        append(state.board.joinToString(",") { row -> "[${row.joinToString(",")}]" })
        append("]}")
    }

    private fun hasFour(board: List<List<Int>>, p: Int): Boolean {
        val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
        for (r in 0..5) for (c in 0..6) if (board[r][c] == p) {
            for ((dr, dc) in dirs) {
                if ((0..3).all { k ->
                    val rr = r + dr * k; val cc = c + dc * k
                    rr in 0..5 && cc in 0..6 && board[rr][cc] == p
                }) return true
            }
        }
        return false
    }
}
