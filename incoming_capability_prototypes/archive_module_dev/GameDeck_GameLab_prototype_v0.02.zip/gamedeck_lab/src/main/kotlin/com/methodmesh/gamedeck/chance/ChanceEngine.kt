package com.methodmesh.gamedeck.chance

/** GameDeck-facing chance contract. Production MethodMesh integration is supplied by an adapter. */
interface ChanceSession {
    data class Roll(
        val expression: String,
        val total: Int,
        val algorithm: String,
        val algorithmVersion: String,
        val seed: String?,
        val primitiveDrawCount: Int
    )

    data class Coins(
        val tosses: List<Boolean>,
        val heads: Int,
        val tails: Int,
        val algorithm: String,
        val algorithmVersion: String,
        val seed: String?
    )

    fun roll(expression: String, stream: String = "default"): Roll
    fun tossCoins(count: Int, stream: String = "default"): Coins
}

interface ChanceProvider {
    fun runtime(): ChanceSession
    fun deterministic(seed: String): ChanceSession
}

/**
 * Process-wide provider registry. The MethodMesh app installs MethodMeshChanceProvider once at
 * startup. Tests can install a lightweight fixture without compiling a second DiceSimulatorEngine.
 */
object ChanceEngine {
    @Volatile
    private var provider: ChanceProvider? = null

    fun install(provider: ChanceProvider) {
        this.provider = provider
    }

    fun clear() {
        provider = null
    }

    fun runtime(): ChanceSession = requireProvider().runtime()
    fun deterministic(seed: String): ChanceSession = requireProvider().deterministic(seed)

    private fun requireProvider(): ChanceProvider = provider
        ?: error(
            "No ChanceProvider installed. In MethodMesh call " +
                "ChanceEngine.install(MethodMeshChanceProvider) during app startup."
        )
}
