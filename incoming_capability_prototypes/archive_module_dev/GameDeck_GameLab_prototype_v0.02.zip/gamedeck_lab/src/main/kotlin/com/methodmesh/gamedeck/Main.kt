package com.methodmesh.gamedeck

import com.methodmesh.gamedeck.games.connectfour.ConnectFour
import com.methodmesh.gamedeck.lab.ConnectFourAgents
import com.methodmesh.gamedeck.lab.GameLab

fun main() {
    println("GameDeck prototype")
    val summary = GameLab.simulate(
        ConnectFour,
        games = 1000,
        agent1 = ConnectFourAgents.heuristic,
        agent2 = ConnectFourAgents.random,
        seed = 42
    )
    println("Connect Four heuristic vs random: $summary")
}
