package com.methodmesh.gamedeck.core

interface GameState
interface GameAction

data class GameManifest(
    val id: String,
    val name: String,
    val version: String,
    val minPlayers: Int,
    val maxPlayers: Int,
    val stochastic: Boolean,
    val supportsSimulation: Boolean = true
)

data class GameEvent<A : GameAction>(
    val sequence: Int,
    val actor: Int,
    val action: A
)

interface GameModule<S : GameState, A : GameAction> {
    val manifest: GameManifest
    fun initialState(seed: String? = null): S
    fun legalActions(state: S, player: Int): List<A>
    fun applyAction(state: S, action: A, player: Int): S
    fun currentPlayer(state: S): Int
    fun isTerminal(state: S): Boolean
    fun winner(state: S): Int?
    fun serialize(state: S): String
}

fun <S : GameState, A : GameAction> replay(
    game: GameModule<S, A>,
    seed: String?,
    events: List<GameEvent<A>>
): S {
    var state = game.initialState(seed)
    events.sortedBy { it.sequence }.forEach { event ->
        require(game.currentPlayer(state) == event.actor) { "Replay actor mismatch at event ${event.sequence}" }
        require(event.action in game.legalActions(state, event.actor)) { "Illegal replay action at event ${event.sequence}" }
        state = game.applyAction(state, event.action, event.actor)
    }
    return state
}
