package com.methodmesh.gamedeck.lab

import com.methodmesh.gamedeck.core.*
import com.methodmesh.gamedeck.games.connectfour.*
import kotlin.random.Random

fun interface Agent<S : GameState, A : GameAction> {
    fun choose(game: GameModule<S, A>, state: S, player: Int, rng: Random): A
}

object ConnectFourAgents {
    val random = Agent<ConnectFourState, Drop> { game, state, player, rng ->
        game.legalActions(state, player).random(rng)
    }

    val heuristic = Agent<ConnectFourState, Drop> { game, state, player, rng ->
        val legal = game.legalActions(state, player)
        legal.firstOrNull { action -> game.winner(game.applyAction(state, action, player)) == player }
            ?: run {
                val opponent = if (player == 1) 2 else 1
                legal.firstOrNull { candidate ->
                    val after = game.applyAction(state, candidate, player)
                    game.legalActions(after.copy(player = opponent), opponent).any { response ->
                        game.winner(game.applyAction(after.copy(player = opponent), response, opponent)) == opponent
                    }
                }
            }
            ?: legal.minByOrNull { kotlin.math.abs(it.column - 3) }
            ?: legal.random(rng)
    }
}

data class SimulationSummary(
    val games: Int,
    val player1Wins: Int,
    val player2Wins: Int,
    val draws: Int,
    val meanMoves: Double
)

object GameLab {
    fun <S : GameState, A : GameAction> simulate(
        game: GameModule<S, A>,
        games: Int,
        agent1: Agent<S, A>,
        agent2: Agent<S, A>,
        seed: Int = 1,
        maxMoves: Int = 10_000
    ): SimulationSummary {
        val rng = Random(seed)
        var p1 = 0; var p2 = 0; var draws = 0; var movesTotal = 0L
        repeat(games) {
            var state = game.initialState("lab-$seed-$it")
            var moves = 0
            while (!game.isTerminal(state) && moves < maxMoves) {
                val player = game.currentPlayer(state)
                val agent = if (player == 1) agent1 else agent2
                val action = agent.choose(game, state, player, rng)
                state = game.applyAction(state, action, player)
                moves++
            }
            movesTotal += moves
            when (game.winner(state)) { 1 -> p1++; 2 -> p2++; else -> draws++ }
        }
        return SimulationSummary(games, p1, p2, draws, movesTotal.toDouble() / games)
    }
}
