package com.methodmesh.gamedeck.chance

import com.example.methodmesh.modules.chance.DiceSimulatorEngine

/**
 * Thin adapter over the existing MethodMesh Chance engine.
 *
 * IMPORTANT: DiceSimulatorEngine is NOT vendored by GameDeck. This adapter intentionally imports
 * the copy already owned by the MethodMesh Chance capability.
 */
object MethodMeshChanceProvider : ChanceProvider {
    override fun runtime(): ChanceSession = Session("secure_random", null)
    override fun deterministic(seed: String): ChanceSession = Session("fixed_seed", seed)

    private class Session(
        private val mode: String,
        private val baseSeed: String?
    ) : ChanceSession {
        override fun roll(expression: String, stream: String): ChanceSession.Roll {
            val seed = derivedSeed(stream)
            val result = DiceSimulatorEngine.simulate(expression, 1, mode, seed)
            val round = result.rounds.single()
            return ChanceSession.Roll(
                expression = result.canonicalExpression,
                total = round.total,
                algorithm = result.algorithm,
                algorithmVersion = result.algorithmVersion,
                seed = result.seed,
                primitiveDrawCount = round.primitiveDraws.size
            )
        }

        override fun tossCoins(count: Int, stream: String): ChanceSession.Coins {
            val seed = derivedSeed(stream)
            val result = DiceSimulatorEngine.tossCoins(count, mode, seed)
            return ChanceSession.Coins(
                tosses = result.tosses,
                heads = result.heads,
                tails = result.tails,
                algorithm = result.algorithm,
                algorithmVersion = result.algorithmVersion,
                seed = result.seed
            )
        }

        private fun derivedSeed(stream: String): String? = when (mode) {
            "fixed_seed" -> "${baseSeed ?: "gamedeck"}::$stream"
            else -> null
        }
    }
}
