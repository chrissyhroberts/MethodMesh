package com.methodmesh.gamedeck

import com.methodmesh.gamedeck.chance.ChanceEngine
import com.methodmesh.gamedeck.testsupport.TestChanceProvider
import com.methodmesh.gamedeck.core.GameEvent
import com.methodmesh.gamedeck.core.replay
import com.methodmesh.gamedeck.games.connectfour.*
import com.methodmesh.gamedeck.games.snakes.*
import com.methodmesh.gamedeck.lab.*

object PrototypeTests {
    @JvmStatic
    fun main(args: Array<String>) {
        ChanceEngine.install(TestChanceProvider)
        chanceReproducible()
        connectFourWinAndReplay()
        snakesReproducible()
        labReproducible()
        heuristicBeatsRandom()
        println("ALL TESTS PASSED")
    }

    private fun chanceReproducible() {
        val a = ChanceEngine.deterministic("abc").roll("d6", "x")
        val b = ChanceEngine.deterministic("abc").roll("d6", "x")
        check(a == b) { "Fixed-seed Chance roll is not reproducible" }
        check(a.algorithmVersion.isNotBlank())
    }

    private fun connectFourWinAndReplay() {
        val actions = listOf(0, 1, 0, 1, 0, 1, 0)
        var state = ConnectFour.initialState()
        val events = mutableListOf<GameEvent<Drop>>()
        actions.forEachIndexed { i, c ->
            val p = ConnectFour.currentPlayer(state)
            val action = Drop(c)
            events += GameEvent(i + 1, p, action)
            state = ConnectFour.applyAction(state, action, p)
        }
        check(ConnectFour.winner(state) == 1)
        val replayed = replay(ConnectFour, null, events)
        check(ConnectFour.serialize(state) == ConnectFour.serialize(replayed))
    }

    private fun snakesReproducible() {
        fun run(seed: String): String {
            var state = SnakesAndLadders.initialState(seed)
            var guard = 0
            while (!SnakesAndLadders.isTerminal(state) && guard++ < 1000) {
                val p = SnakesAndLadders.currentPlayer(state)
                state = SnakesAndLadders.applyAction(state, RollTurn(state.turn), p)
            }
            check(SnakesAndLadders.isTerminal(state))
            return SnakesAndLadders.serialize(state)
        }
        check(run("same") == run("same"))
    }

    private fun labReproducible() {
        val a = GameLab.simulate(ConnectFour, 200, ConnectFourAgents.random, ConnectFourAgents.random, seed = 99)
        val b = GameLab.simulate(ConnectFour, 200, ConnectFourAgents.random, ConnectFourAgents.random, seed = 99)
        check(a == b)
    }

    private fun heuristicBeatsRandom() {
        val result = GameLab.simulate(ConnectFour, 500, ConnectFourAgents.heuristic, ConnectFourAgents.random, seed = 123)
        check(result.player1Wins > result.player2Wins) { "Heuristic should outperform random in proving simulation: $result" }
    }
}
