package com.methodmesh.gamedeck.testsupport

import com.methodmesh.gamedeck.chance.ChanceProvider
import com.methodmesh.gamedeck.chance.ChanceSession
import java.security.SecureRandom
import java.util.Random

/** Test-only provider: enough to exercise GameDeck without redeclaring MethodMesh Chance classes. */
object TestChanceProvider : ChanceProvider {
    override fun runtime(): ChanceSession = Session(null)
    override fun deterministic(seed: String): ChanceSession = Session(seed)

    private class Session(private val baseSeed: String?) : ChanceSession {
        override fun roll(expression: String, stream: String): ChanceSession.Roll {
            val sides = parseSimpleDie(expression)
            val rng = random(stream)
            val value = rng.nextInt(sides) + 1
            return ChanceSession.Roll(
                expression = expression,
                total = value,
                algorithm = if (baseSeed == null) "test.secure" else "test.seeded",
                algorithmVersion = "1",
                seed = baseSeed?.let { "$it::$stream" },
                primitiveDrawCount = 1
            )
        }

        override fun tossCoins(count: Int, stream: String): ChanceSession.Coins {
            require(count >= 0)
            val rng = random(stream)
            val tosses = List(count) { rng.nextBoolean() }
            return ChanceSession.Coins(
                tosses = tosses,
                heads = tosses.count { it },
                tails = tosses.count { !it },
                algorithm = if (baseSeed == null) "test.secure" else "test.seeded",
                algorithmVersion = "1",
                seed = baseSeed?.let { "$it::$stream" }
            )
        }

        private fun random(stream: String): Random = if (baseSeed == null) {
            SecureRandom()
        } else {
            Random(stableSeed("$baseSeed::$stream"))
        }

        private fun stableSeed(value: String): Long {
            var h = 1125899906842597L
            for (c in value) h = 31L * h + c.code
            return h
        }

        private fun parseSimpleDie(expression: String): Int {
            val m = Regex("^d(\\d+)$", RegexOption.IGNORE_CASE).matchEntire(expression.trim())
                ?: error("TestChanceProvider only supports simple dN expressions; got $expression")
            return m.groupValues[1].toInt().also { require(it > 0) }
        }
    }
}
