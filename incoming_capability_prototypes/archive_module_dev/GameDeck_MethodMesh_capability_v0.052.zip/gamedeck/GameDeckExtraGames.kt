package com.example.methodmesh.modules.gamedeck

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min

private val ExtraP1 = Color(0xFFE84A5F)
private val ExtraP2 = Color(0xFFFFC857)

@Composable
internal fun ExtraGameScreen(
    game: String,
    stateJson: String,
    rngMode: String,
    seed: String,
    soundEnabled: Boolean,
    onStateChange: (String) -> Unit
) {
    when (game) {
        GameDeckExtraEngine.TIC_TAC_TOE -> TicTacToeScreen(stateJson, soundEnabled, cpuOpponent, onCpuOpponentChanged, onStateChange)
        GameDeckExtraEngine.REVERSI -> ReversiScreen(stateJson, soundEnabled, cpuOpponent, onCpuOpponentChanged, onStateChange)
        GameDeckExtraEngine.NIM -> NimScreen(stateJson, soundEnabled, cpuOpponent, onCpuOpponentChanged, onStateChange)
        GameDeckExtraEngine.LIGHTS_OUT -> LightsOutScreen(stateJson, onStateChange)
        GameDeckExtraEngine.FIFTEEN -> FifteenScreen(stateJson, onStateChange)
        GameDeckExtraEngine.MEMORY -> MemoryScreen(stateJson, onStateChange)
        GameDeckExtraEngine.SHUT_THE_BOX -> ShutTheBoxScreen(stateJson, rngMode, seed, soundEnabled, onStateChange)
        GameDeckExtraEngine.CODEBREAKER -> CodebreakerScreen(stateJson, onStateChange)
    }
}

@Composable
private fun ExtraRail(label:String, detail:String, active:Boolean, top:Boolean, human:Boolean, control:(@Composable ()->Unit)?=null){
    Surface(
        modifier=Modifier.fillMaxWidth().graphicsLayer{rotationZ=if(top&&human)180f else 0f},
        shape=RoundedCornerShape(22.dp),
        color=(if(top) ExtraP2 else ExtraP1).copy(alpha=if(active).22f else .10f),
        tonalElevation=if(active)5.dp else 0.dp
    ){
        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween){
            Column { Text(label,fontWeight=FontWeight.Black); Text(detail,style=MaterialTheme.typography.labelSmall) }
            control?.invoke()
        }
    }
}

@Composable
private fun ExtraTabletop(
    turn:Int,
    topHuman:Boolean,
    topDetail:String,
    bottomDetail:String,
    topControl:(@Composable ()->Unit)?=null,
    bottomControl:(@Composable ()->Unit)?=null,
    board:@Composable ()->Unit
){
    BoxWithConstraints(Modifier.fillMaxSize()){
        val rail=86.dp; val gap=6.dp; val centre=(maxHeight-rail-rail-gap-gap).coerceAtLeast(140.dp)
        Column(Modifier.fillMaxSize(), horizontalAlignment=Alignment.CenterHorizontally){
            Box(Modifier.fillMaxWidth().height(rail),contentAlignment=Alignment.Center){ExtraRail(if(topHuman)"PLAYER 2" else "CPU",topDetail,turn==2,true,topHuman,topControl)}
            Spacer(Modifier.height(gap)); Box(Modifier.fillMaxWidth().height(centre),contentAlignment=Alignment.Center){board()}; Spacer(Modifier.height(gap))
            Box(Modifier.fillMaxWidth().height(rail),contentAlignment=Alignment.Center){ExtraRail("PLAYER 1",bottomDetail,turn==1,false,true,bottomControl)}
        }
    }
}

@Composable
private fun CpuModeButton(cpu:Boolean,onChange:(Boolean)->Unit){OutlinedButton(onClick={onChange(!cpu)}){Text(if(cpu)"CPU" else "2P",fontWeight=FontWeight.Bold)}}

@Composable
private fun TicTacToeScreen(
    stateJson:String,
    sound:Boolean,
    cpu:Boolean,
    onCpuChanged:(Boolean)->Unit,
    onStateChange:(String)->Unit
){
    val s=JSONObject(stateJson)
    val turn=s.optInt("turn",1)
    LaunchedEffect(stateJson,cpu){
        if(cpu&&turn==2&&s.optString("winner").isBlank()){
            delay(420)
            val decision=GameDeckAgents.choose(
                game=GameDeckExtraEngine.TIC_TAC_TOE,
                stateJson=stateJson,
                seat=2,
                profile=GameDeckAgents.STANDARD,
                decisionSeed="interactive|ttt|${s.optInt("moves")}"
            )
            val c=decision.action?.toIntOrNull() ?: -1
            if(c>=0){
                GameDeckSound.cpu(sound)
                onStateChange(GameDeckExtraEngine.ticTacToeMove(stateJson,c))
            }
        }
    }
    ExtraTabletop(turn,!cpu,"${s.optInt("moves")} turns","${s.optInt("moves")} turns",topControl={CpuModeButton(cpu,onCpuChanged)}){
        SquareBoard(3){cell,side->
            val v=s.getJSONArray("board").optInt(cell)
            Box(
                Modifier.size(side).background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(enabled=v==0&&s.optString("winner").isBlank()&&!(cpu&&turn==2)){
                        onStateChange(GameDeckExtraEngine.ticTacToeMove(stateJson,cell))
                    },
                contentAlignment=Alignment.Center
            ){
                Text(
                    if(v==1)"●" else if(v==2)"◆" else "",
                    style=MaterialTheme.typography.headlineLarge,
                    fontWeight=FontWeight.Black,
                    color=if(v==1)ExtraP1 else ExtraP2
                )
            }
        }
    }
}

@Composable
private fun ReversiScreen(
    stateJson:String,
    sound:Boolean,
    cpu:Boolean,
    onCpuChanged:(Boolean)->Unit,
    onStateChange:(String)->Unit
){
    val s=JSONObject(stateJson)
    val turn=s.optInt("turn",1)
    val legal=GameDeckExtraEngine.reversiLegalMoves(stateJson).toSet()
    val b=s.getJSONArray("board")
    val c1=(0 until 64).count{b.optInt(it)==1}
    val c2=(0 until 64).count{b.optInt(it)==2}
    LaunchedEffect(stateJson,cpu){
        if(cpu&&turn==2&&s.optString("winner").isBlank()){
            delay(500)
            val decision=GameDeckAgents.choose(
                game=GameDeckExtraEngine.REVERSI,
                stateJson=stateJson,
                seat=2,
                profile=GameDeckAgents.STANDARD,
                decisionSeed="interactive|reversi|${s.optInt("moves")}"
            )
            val c=decision.action?.toIntOrNull() ?: -1
            if(c>=0){
                GameDeckSound.cpu(sound)
                onStateChange(GameDeckExtraEngine.reversiMove(stateJson,c))
            }
        }
    }
    ExtraTabletop(turn,!cpu,"$c2 discs","$c1 discs",topControl={CpuModeButton(cpu,onCpuChanged)}){
        SquareBoard(8){cell,side->
            val v=b.optInt(cell)
            Box(
                Modifier.size(side).background(Color(0xFF2E9D70))
                    .clickable(enabled=cell in legal&&!(cpu&&turn==2)){
                        onStateChange(GameDeckExtraEngine.reversiMove(stateJson,cell))
                    },
                contentAlignment=Alignment.Center
            ){
                if(v!=0) Surface(
                    Modifier.size(side*.72f),
                    CircleShape,
                    color=if(v==1)Color(0xFFF4F1EA) else Color(0xFF222222)
                ){}
                else if(cell in legal) Surface(
                    Modifier.size(side*.18f),
                    CircleShape,
                    color=MaterialTheme.colorScheme.primary.copy(alpha=.55f)
                ){}
            }
        }
    }
}

@Composable
private fun NimScreen(
    stateJson:String,
    sound:Boolean,
    cpu:Boolean,
    onCpuChanged:(Boolean)->Unit,
    onStateChange:(String)->Unit
){
    val s=JSONObject(stateJson)
    val turn=s.optInt("turn",1)
    val heaps=s.getJSONArray("heaps")
    LaunchedEffect(stateJson,cpu){
        if(cpu&&turn==2&&s.optString("winner").isBlank()){
            delay(420)
            val decision=GameDeckAgents.choose(
                game=GameDeckExtraEngine.NIM,
                stateJson=stateJson,
                seat=2,
                profile=GameDeckAgents.STANDARD,
                decisionSeed="interactive|nim|${s.optInt("moves")}"
            )
            val parts=decision.action?.split(":")
            if(parts?.size==2){
                GameDeckSound.cpu(sound)
                onStateChange(
                    GameDeckExtraEngine.nimMove(
                        stateJson,
                        parts[0].toInt(),
                        parts[1].toInt()
                    )
                )
            }
        }
    }
    ExtraTabletop(turn,!cpu,"Take counters","Take counters",topControl={CpuModeButton(cpu,onCpuChanged)}){
        Column(verticalArrangement=Arrangement.spacedBy(14.dp),horizontalAlignment=Alignment.CenterHorizontally){
            (0..2).forEach{h->
                val n=heaps.optInt(h)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
                    Text("${h+1}",fontWeight=FontWeight.Black)
                    repeat(n){i->
                        Surface(
                            modifier=Modifier.size(34.dp).clickable(enabled=!(cpu&&turn==2)){
                                onStateChange(GameDeckExtraEngine.nimMove(stateJson,h,n-i))
                            },
                            shape=CircleShape,
                            color=if(turn==1)ExtraP1 else ExtraP2
                        ){}
                    }
                }
            }
        }
    }
}

@Composable
private fun LightsOutScreen(stateJson:String,onStateChange:(String)->Unit){val s=JSONObject(stateJson);val lights=s.getJSONArray("lights");SoloFrame("LIGHTS OUT","Turn every light off","${s.optInt("moves")} moves"){SquareBoard(5){cell,side->val on=lights.optInt(cell)==1;Box(Modifier.size(side).background(if(on)Color(0xFFFFC857) else MaterialTheme.colorScheme.surfaceVariant).clickable{onStateChange(GameDeckExtraEngine.lightsMove(stateJson,cell))})}}}

@Composable
private fun FifteenScreen(stateJson:String,onStateChange:(String)->Unit){val s=JSONObject(stateJson);val a=s.getJSONArray("tiles");SoloFrame("15 PUZZLE","Slide tiles into order","${s.optInt("moves")} moves"){SquareBoard(4){cell,side->val v=a.optInt(cell);Box(Modifier.size(side).background(if(v==0)Color.Transparent else MaterialTheme.colorScheme.primaryContainer).clickable(enabled=v!=0){onStateChange(GameDeckExtraEngine.fifteenMove(stateJson,cell))},contentAlignment=Alignment.Center){if(v!=0)Text(v.toString(),fontWeight=FontWeight.Black,style=MaterialTheme.typography.headlineSmall)}}}}

@Composable
private fun MemoryScreen(stateJson:String,onStateChange:(String)->Unit){
    val s=JSONObject(stateJson)
    val turn=s.optInt("turn",1)
    val cards=s.getJSONArray("cards")
    val matched=s.getJSONArray("matched")
    val face=s.getJSONArray("face_up")
    val visible=(0 until face.length()).map{face.optInt(it)}.toSet()
    val scores=s.getJSONArray("scores")
    val resolving=s.optString("phase","choose")=="resolve"

    // A mismatch remains visible long enough to be perceived and remembered.
    LaunchedEffect(stateJson){
        if(resolving){
            delay(850)
            onStateChange(GameDeckExtraEngine.memoryResolve(stateJson))
        }
    }

    ExtraTabletop(turn,true,"${scores.optInt(1)} pairs","${scores.optInt(0)} pairs"){
        SquareBoard(4){cell,side->
            val shown=matched.optInt(cell)==1||cell in visible
            Box(
                Modifier.size(side)
                    .background(if(shown)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable(enabled=!resolving&&matched.optInt(cell)==0&&cell !in visible){
                        onStateChange(GameDeckExtraEngine.memoryFlip(stateJson,cell))
                    },
                contentAlignment=Alignment.Center
            ){
                Text(if(shown)cards.optInt(cell).toString() else "?",fontWeight=FontWeight.Black)
            }
        }
    }
}

@Composable
private fun ShutTheBoxScreen(stateJson:String,rngMode:String,seed:String,sound:Boolean,onStateChange:(String)->Unit){val s=JSONObject(stateJson);val open=s.getJSONArray("open");val openSet=(0 until open.length()).map{open.optInt(it)}.toSet();val selectedArray=s.optJSONArray("selected")?:JSONArray();val selected=(0 until selectedArray.length()).map{selectedArray.optInt(it)}.toSet();val dice=s.getJSONArray("dice");val total=if(dice.length()>=2)dice.optInt(0)+dice.optInt(1) else 0;SoloFrame("SHUT THE BOX","Choose any open numbers that sum to the dice","Score ${s.optInt("score",45)}"){Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(18.dp)){Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){(1..9).forEach{n->OutlinedButton(onClick={onStateChange(GameDeckExtraEngine.shutToggle(stateJson,n))},enabled=n in openSet&&s.optString("phase")=="choose"){Text(if(n !in openSet)"×" else if(n in selected)"[$n]" else n.toString())}}};Text(if(total>0)"Rolled ${dice.optInt(0)} + ${dice.optInt(1)} = $total" else "Ready to roll",fontWeight=FontWeight.Bold);if(s.optString("phase")=="choose")Button(onClick={onStateChange(GameDeckExtraEngine.shutConfirm(stateJson))},enabled=selected.sum()==total){Text("CLOSE ${selected.sorted().joinToString(" + ")}")} else Button(onClick={GameDeckSound.roll(sound);onStateChange(GameDeckExtraEngine.shutRoll(stateJson,rngMode,seed))},enabled=s.optString("phase")=="roll"){Text("ROLL")}}}}

@Composable
private fun CodebreakerScreen(stateJson:String,onStateChange:(String)->Unit){val s=JSONObject(stateJson);val g=s.getJSONArray("guess");val hist=s.getJSONArray("history");SoloFrame("CODEBREAKER","Crack four digits 1–6","${s.optInt("moves")} / 10 guesses"){Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)){Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){(0..3).forEach{i->Column(horizontalAlignment=Alignment.CenterHorizontally){OutlinedButton(onClick={onStateChange(GameDeckExtraEngine.codeAdjust(stateJson,i,1))}){Text("+")};Surface(shape=CircleShape,color=MaterialTheme.colorScheme.primaryContainer){Box(Modifier.size(52.dp),contentAlignment=Alignment.Center){Text(g.optInt(i).toString(),fontWeight=FontWeight.Black,style=MaterialTheme.typography.headlineSmall)}};OutlinedButton(onClick={onStateChange(GameDeckExtraEngine.codeAdjust(stateJson,i,-1))}){Text("−")}}};Button(onClick={onStateChange(GameDeckExtraEngine.codeSubmit(stateJson))}){Text("TRY CODE")};if(hist.length()>0){val last=hist.getJSONObject(hist.length()-1);Text("Exact ${last.optInt("exact")}   Near ${last.optInt("near")}",fontWeight=FontWeight.Bold)}}}}}

@Composable
private fun SoloFrame(
    title: String,
    subtitle: String,
    detail: String,
    content: @Composable () -> Unit
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Capture BoxWithConstraintsScope values before entering nested layout
        // receivers. This avoids ambiguous implicit-receiver resolution on
        // Compose/Kotlin versions used by MethodMesh.
        val availableHeight = maxHeight
        val footerHeight = 88.dp
        val contentHeight = (availableHeight - footerHeight).coerceAtLeast(180.dp)

        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.fillMaxWidth().height(contentHeight),
                contentAlignment = Alignment.Center
            ) {
                content()
            }

            Surface(
                modifier = Modifier.fillMaxWidth().height(footerHeight),
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(title, fontWeight = FontWeight.Black)
                        Text(subtitle, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(detail, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SquareBoard(n:Int,cell: @Composable (Int, Dp) -> Unit){BoxWithConstraints(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){val board=minOf(maxWidth,maxHeight);val side=board/n;Column(Modifier.size(board)){for(r in 0 until n)Row{for(c in 0 until n)cell(r*n+c,side)}}}}
