package com.example.methodmesh.modules.gamedeck

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

internal const val GAMEDECK_STATS = "player_stats"
internal const val GAMEDECK_SIMULATOR = "simulator"

@Composable
internal fun GameDeckStatsScreen(store: GameDeckStatsStore) {
    val s = remember { store.snapshot() }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("PLAYER RECORD", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        Text("Local-only play record. Shared-table games are not silently treated as personal wins or losses.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            StatChip("Games", s.games.toString()); StatChip("Wins", s.wins.toString()); StatChip("Losses", s.losses.toString()); StatChip("Draws", s.draws.toString())
        }
        Text("Games played", fontWeight = FontWeight.Black)
        if (s.byGame.isEmpty()) Text("Finish games to build your record.") else s.byGame.toList().sortedByDescending { it.second }.take(10).forEach { (g,n) -> Text("${prettyGame(g)}  •  $n") }
        Text("Personal bests", fontWeight = FontWeight.Black)
        if (s.bestMoves.isEmpty()) Text("No completed best-move records yet.") else s.bestMoves.toList().sortedBy { it.second }.take(8).forEach { (g,n) -> Text("${prettyGame(g)}  •  $n moves") }
        Text("Play exposure", fontWeight = FontWeight.Black)
        Text("Exposure is not a competence estimate. Calibrated skill modelling comes later.", style = MaterialTheme.typography.labelSmall)
        if (s.skillExposure.isEmpty()) Text("No exposure yet.") else s.skillExposure.toList().sortedByDescending { it.second }.forEach { (skill,n) -> Text("${skill.replace('_',' ').uppercase()}  $n") }
        if (s.sharedTableGames > 0) Text("Shared-table sessions  •  ${s.sharedTableGames}")
        Text("Achievements", fontWeight = FontWeight.Black)
        if (s.achievements.isEmpty()) Text("No achievements yet.") else Text(s.achievements.sorted().joinToString("  •  ") { it.replace('_',' ') })
    }
}

@Composable
private fun StatChip(label:String,value:String){Surface(shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.primaryContainer){Column(Modifier.padding(horizontal=12.dp,vertical=9.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(value,fontWeight=FontWeight.Black);Text(label,style=MaterialTheme.typography.labelSmall)}}}

@Composable
internal fun GameDeckSimulatorScreen() {
    var game by remember { mutableStateOf(GameDeckExtraEngine.TIC_TAC_TOE) }
    var agentA by remember { mutableStateOf(GameDeckAgents.STANDARD) }
    var agentB by remember { mutableStateOf(GameDeckAgents.CASUAL) }
    var result by remember { mutableStateOf<SimSeriesResult?>(null) }
    var running by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp),
        horizontalAlignment=Alignment.CenterHorizontally
    ) {
        Text("CPU ARENA", style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Black)
        Text("Seat-aware agents play the real rules engine headlessly. Series alternate seats and vary deterministic decision seeds.")

        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf(
                GameDeckExtraEngine.TIC_TAC_TOE,
                GameDeckExtraEngine.NIM,
                GameDeckExtraEngine.REVERSI
            ).forEach { g ->
                OutlinedButton(onClick={game=g;result=null}, enabled=!running){
                    Text(prettyGame(g))
                }
            }
        }

        Text("AGENT A  ${agentA.label}", fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            GameDeckAgents.profiles.forEach { p ->
                OutlinedButton(onClick={agentA=p;result=null}, enabled=!running){ Text(p.level.name) }
            }
        }

        Text("AGENT B  ${agentB.label}", fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            GameDeckAgents.profiles.forEach { p ->
                OutlinedButton(onClick={agentB=p;result=null}, enabled=!running){ Text(p.level.name) }
            }
        }

        Button(
            onClick={
                scope.launch {
                    running=true
                    result = withContext(Dispatchers.Default) {
                        GameDeckSimulator.runSeries(
                            game=game,
                            games=100,
                            agentA=agentA,
                            agentB=agentB,
                            seriesSeed="ui_arena"
                        )
                    }
                    running=false
                }
            },
            enabled=!running
        ){
            Text(if(running)"RUNNING…" else "RUN 100 MATCHES")
        }

        result?.let { r ->
            Surface(
                Modifier.fillMaxWidth(),
                RoundedCornerShape(24.dp),
                color=MaterialTheme.colorScheme.surfaceVariant
            ){
                Column(
                    Modifier.padding(18.dp),
                    verticalArrangement=Arrangement.spacedBy(8.dp)
                ){
                    Text(prettyGame(r.game),fontWeight=FontWeight.Black)
                    Text("${r.agentA} wins  ${r.agentAWins}")
                    Text("${r.agentB} wins  ${r.agentBWins}")
                    Text("Draws  ${r.draws}")
                    Text("Seat 1 wins  ${r.seat1Wins}   •   Seat 2 wins  ${r.seat2Wins}")
                    Text("Mean moves  ${"%.1f".format(r.meanMoves)}")
                }
            }
        }
    }
}

internal fun prettyGame(game:String):String = game.split('_').joinToString(" "){ it.replaceFirstChar { ch -> ch.uppercase() } }
