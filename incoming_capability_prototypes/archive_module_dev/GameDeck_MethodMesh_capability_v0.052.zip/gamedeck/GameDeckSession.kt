package com.example.methodmesh.modules.gamedeck

import org.json.JSONArray
import org.json.JSONObject

/**
 * Capability-local game-session contract.
 *
 * This deliberately lives inside GameDeck for now. It is the proving shape for a
 * future shared game-system service once GameDeck and Arcade have both stabilised.
 */
enum class GameDeckSeatKind {
    HUMAN_LOCAL,
    CPU,
    REMOTE,
    SIMULATION
}

data class GameDeckPlayerSeat(
    val seat: Int,
    val kind: GameDeckSeatKind,
    val playerId: String? = null,
    val agentProfileId: String? = null
)

data class GameDeckSession(
    val sessionId: String,
    val gameId: String,
    val rulesVersion: String,
    val seats: List<GameDeckPlayerSeat>,
    val rngMode: String,
    val seed: String
)

/**
 * Public/private state boundary.
 *
 * Most current GameDeck games are perfect-information games, so their public state
 * is identical to their internal state. Hidden-information games redact secrets
 * before state leaves the capability as a snapshot/audit result.
 */
object GameDeckSessionCodec {
    fun publicStateJson(stateJson: String): String {
        val s = runCatching { JSONObject(stateJson) }.getOrElse { return stateJson }
        return when (s.optString("game")) {
            GameDeckExtraEngine.CODEBREAKER -> {
                // The secret remains local/internal. Export only information that a
                // player is legitimately allowed to reconstruct from the table.
                JSONObject()
                    .put("game", s.optString("game"))
                    .put("guess", copyArray(s.optJSONArray("guess")))
                    .put("history", copyArray(s.optJSONArray("history")))
                    .put("turn", s.optInt("turn", 1))
                    .put("winner", s.optString("winner"))
                    .put("moves", s.optInt("moves", 0))
                    .put("private_state_redacted", true)
                    .toString()
            }
            else -> stateJson
        }
    }

    private fun copyArray(array: JSONArray?): JSONArray {
        if (array == null) return JSONArray()
        return JSONArray(array.toString())
    }
}
