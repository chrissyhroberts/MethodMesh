# Changelog

## v0.050

- Expanded from four games to twelve playable games/puzzles.
- Added Tic Tac Toe, Reversi, Nim, Memory Pairs, Lights Out, 15 Puzzle, Shut the Box and Codebreaker.
- Added game-agent profiles and first CPU adapters.
- Added CPU Arena for headless agent-vs-agent simulation.
- Added local player record with per-game counts and coarse cross-game skill evidence.
- Launcher now scrolls; active games remain fixed non-scrolling tabletop surfaces.
- New two-human games follow opposite-end player ownership and far-player rotation.
- Extra-game procedural setup uses the public MethodMesh Chance method boundary.
- Updated XLSForm game choices and version.

## v0.046

- Rebuilt active play around a measured fixed tabletop surface.
- Moved game management to an overlay menu.
- Strengthened opposite-end two-human presentation.

## v0.051
- Fixed Compose compiler error caused by reading `LocalContext.current` inside the non-composable `remember {}` calculation lambda.
- Fixed `BoxWithConstraintsScope.maxHeight` implicit-receiver conflict in `SoloFrame` by capturing the available height before nested layout receivers.

## v0.052
- Reviewer-remediation release.
- Fixed invalid 15 Puzzle generation: one blank, tiles 1–15, legal-move scrambling, solvability guaranteed.
- Memory mismatches now remain visibly face-up during a resolve phase before concealment/turn transfer.
- Reversi legal-move decoding now parses state once per operation.
- Added capability-local session/seat/public-private state contracts.
- Codebreaker secret is redacted from exported snapshot/audit state.
- CPU agents are now seat-aware and CPU profiles affect decisions.
- CPU Arena alternates seats, varies deterministic decision seeds, compares distinct agent profiles, and reports seat bias.
- Simulator work now runs off the Compose UI thread.
- Player records use durable session IDs and do not treat Player 1 as the account holder in shared-table games.
- Renamed provisional "skill evidence" to play/skill exposure; no competence inference is claimed.
