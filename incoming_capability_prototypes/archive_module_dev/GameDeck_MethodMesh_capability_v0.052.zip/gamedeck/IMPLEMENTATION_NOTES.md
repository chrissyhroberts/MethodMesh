# GameDeck implementation notes — v0.050

## Generic runtime only

GameDeck requests `CapabilityHostPresentation.Immersive`. There must be no `gamedeck` ID/name branch in shared MethodMesh UI. The runtime knows only generic host presentation semantics.

## Shared tabletop contract

Two-human local play is approximately 180-degree rotationally symmetric in player-facing UI. Player rails, local controls and status belong to the player at that end of the device. The central board is stable.

The current original games use `TabletopFrame`; the v0.050 compact games use the equivalent `ExtraTabletop`. These should converge into one public capability-local component after the interaction designs settle.

## Game state

All compact new games use JSON state with common fields:

- `game`
- `turn`
- `winner`
- `moves`

Game-specific state is additional. UI is a projection of state; CPU agents and simulators call the same state-transition functions.

## Agent and simulator direction

The CPU boundary is intentionally action-oriented. Future adapters should expose legal actions and evaluation separately so RANDOM, GREEDY, HEURISTIC, BOUNDED, OPTIMAL and NOISY-EXPERT agents can share one harness.

`GameDeckSimulator` is deliberately headless and bounded. It must never use rendering or animation state to determine outcomes.

## Stats direction

Current stats are local-only `SharedPreferences`. This is an initial implementation rather than the final cross-capability player identity service. Arcade and future game capabilities should eventually use a public game-system method/repository contract rather than import GameDeck internals.

## Chance

Random outcome generation stays behind the existing Chance public method boundary. Presentation animation never determines outcomes.

## Validation

The capability still requires validation in the real MethodMesh Android project with:

```bash
./gradlew :app:compileDebugKotlin
```

and then `:app:assembleDebug` before release.


## v0.052 reviewer invariants

- A hidden-information game's internal state is not necessarily exportable state.
- A simulator agent must always be told which seat it controls.
- A CPU profile must alter policy; profile labels must not be decorative.
- A simulation series alternates seats and varies decision seeds so repeated matches are not duplicated trajectories.
- Two-human hot-seat results are shared-table records unless an explicit player identity/seat mapping exists.
- Game counts by cognitive domain are exposure, not calibrated skill estimates.
- Puzzle generators must guarantee their declared state invariants (15 Puzzle: exactly one blank, tiles 1–15 exactly once, reachable from solved state).
