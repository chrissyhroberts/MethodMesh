package com.example.methodmesh.modules.gamedeck

import org.json.JSONObject

data class SimMatchResult(
    val winner: String,
    val moves: Int,
    val seed: String,
    val profileForSeat1: String,
    val profileForSeat2: String
)

data class SimSeriesResult(
    val game: String,
    val games: Int,
    val agentAWins: Int,
    val agentBWins: Int,
    val draws: Int,
    val meanMoves: Double,
    val agentA: String,
    val agentB: String,
    val seat1Wins: Int,
    val seat2Wins: Int
)

/**
 * Headless CPU-vs-CPU arena.
 *
 * The arena varies the deterministic decision seed for every match and alternates
 * which agent occupies seat 1. This means a series is no longer 100 copies of one
 * deterministic trajectory and also exposes first-player/seat bias.
 */
object GameDeckSimulator {
    fun runSeries(
        game: String,
        games: Int = 100,
        agentA: GameDeckAgentProfile = GameDeckAgents.STANDARD,
        agentB: GameDeckAgentProfile = GameDeckAgents.CASUAL,
        seriesSeed: String = "arena"
    ): SimSeriesResult {
        val n = games.coerceIn(1, 5000)
        var aWins = 0
        var bWins = 0
        var draws = 0
        var seat1Wins = 0
        var seat2Wins = 0
        var totalMoves = 0

        repeat(n) { index ->
            val aIsSeat1 = index % 2 == 0
            val seat1Profile = if (aIsSeat1) agentA else agentB
            val seat2Profile = if (aIsSeat1) agentB else agentA
            val r = runMatch(
                game = game,
                seat1Profile = seat1Profile,
                seat2Profile = seat2Profile,
                matchSeed = "$seriesSeed|$game|$index"
            )

            when (r.winner) {
                "1" -> {
                    seat1Wins++
                    if (aIsSeat1) aWins++ else bWins++
                }
                "2" -> {
                    seat2Wins++
                    if (aIsSeat1) bWins++ else aWins++
                }
                else -> draws++
            }
            totalMoves += r.moves
        }

        return SimSeriesResult(
            game = game,
            games = n,
            agentAWins = aWins,
            agentBWins = bWins,
            draws = draws,
            meanMoves = totalMoves.toDouble() / n,
            agentA = agentA.label,
            agentB = agentB.label,
            seat1Wins = seat1Wins,
            seat2Wins = seat2Wins
        )
    }

    fun runMatch(
        game: String,
        seat1Profile: GameDeckAgentProfile = GameDeckAgents.STANDARD,
        seat2Profile: GameDeckAgentProfile = GameDeckAgents.CASUAL,
        matchSeed: String = "sim",
        maxMoves: Int = 512
    ): SimMatchResult {
        var state = GameDeckExtraEngine.newStateJson(game, "fixed_seed", matchSeed)
        var guard = 0

        while (JSONObject(state).optString("winner").isBlank() && guard < maxMoves) {
            guard++
            val s = JSONObject(state)
            val seat = s.optInt("turn", 1).coerceIn(1, 2)
            val profile = if (seat == 1) seat1Profile else seat2Profile
            val decision = GameDeckAgents.choose(
                game = game,
                stateJson = state,
                seat = seat,
                profile = profile,
                decisionSeed = "$matchSeed|decision|$guard|seat$seat"
            )
            val action = decision.action ?: break

            state = when (game) {
                GameDeckExtraEngine.TIC_TAC_TOE ->
                    GameDeckExtraEngine.ticTacToeMove(state, action.toInt())

                GameDeckExtraEngine.REVERSI ->
                    GameDeckExtraEngine.reversiMove(state, action.toInt())

                GameDeckExtraEngine.NIM -> {
                    val parts = action.split(":")
                    if (parts.size != 2) state
                    else GameDeckExtraEngine.nimMove(
                        state,
                        parts[0].toInt(),
                        parts[1].toInt()
                    )
                }

                else -> return SimMatchResult(
                    winner = "unsupported",
                    moves = guard - 1,
                    seed = matchSeed,
                    profileForSeat1 = seat1Profile.id,
                    profileForSeat2 = seat2Profile.id
                )
            }
        }

        val final = JSONObject(state)
        return SimMatchResult(
            winner = final.optString("winner").ifBlank { "draw" },
            moves = final.optInt("moves", guard),
            seed = matchSeed,
            profileForSeat1 = seat1Profile.id,
            profileForSeat2 = seat2Profile.id
        )
    }
}
