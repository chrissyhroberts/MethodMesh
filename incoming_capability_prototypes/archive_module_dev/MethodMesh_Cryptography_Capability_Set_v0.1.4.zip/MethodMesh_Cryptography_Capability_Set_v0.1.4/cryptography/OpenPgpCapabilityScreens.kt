package com.example.methodmesh.modules.cryptography

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

private fun hashContentUri(context: android.content.Context, uri: Uri): String =
    context.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Unable to open input." }
        val md = java.security.MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) break
            if (n > 0) md.update(buffer, 0, n)
        }
        with(CryptoEncoding) { md.digest().hex() }
    }

@Composable
private fun PgpScaffold(
    title: String,
    capabilityId: String,
    context: CapabilityScreenContext,
    result: ExecutionResult?,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    retry: () -> Unit,
    body: @Composable () -> Unit
) {
    CapabilityScreenScaffold(
        title = title,
        capabilityId = capabilityId,
        context = context,
        canGoBack = context.stepNumber > 1,
        capturedResult = result,
        resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
        onBack = onBack,
        onRetry = retry,
        onConfirm = { result?.let(onConfirmed) },
        onCancel = onCancel
    ) { body() }
}

private class FileCryptScreen(
    override val capabilityId: String,
    override val title: String,
    override val description: String,
    private val decrypt: Boolean
) : CapabilityScreenSpec {
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val resolver = androidContext.contentResolver
        val method = if (decrypt) As100FileDecryptMethod else As100FileEncryptMethod
        var uriText by rememberSaveable { mutableStateOf(context.action.settings["input_uri"] ?: "") }
        var sourceName by rememberSaveable { mutableStateOf("") }
        var password by rememberSaveable { mutableStateOf(context.action.settings["password"] ?: "") }
        var recipientCertificate by rememberSaveable { mutableStateOf(context.action.settings["recipient_certificate"] ?: "") }
        var secretKey by rememberSaveable { mutableStateOf(context.action.settings["secret_key"] ?: "") }
        var keyPassword by rememberSaveable { mutableStateOf(context.action.settings["key_password"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var outputName by rememberSaveable { mutableStateOf("") }
        var outputUri by rememberSaveable { mutableStateOf("") }
        var status by rememberSaveable { mutableStateOf("") }
        var launched by rememberSaveable { mutableStateOf(false) }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uriText = uri?.toString().orEmpty()
            sourceName = uri?.let { CryptoScreenSupport.sourceName(resolver, it) }.orEmpty()
        }

        fun runCrypto() = runCatching {
            val uri = Uri.parse(uriText)
            val original = sourceName.ifBlank { CryptoScreenSupport.sourceName(resolver, uri) }
            val sourceHash = hashContentUri(androidContext, uri)
            outputName = if (decrypt) original.removeSuffix(".pgp").ifBlank { "decrypted-content" } else "$original.pgp"
            val outFile = CryptoScreenSupport.cacheFile(androidContext, outputName)
            resolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Unable to open selected file." }
                outFile.outputStream().use { output ->
                    if (decrypt) {
                        require(password.isNotBlank() || secretKey.isNotBlank()) { "Supply a password or OpenPGP secret key." }
                        OpenPgpEngine.decrypt(
                            input, output,
                            password = password.ifBlank { null },
                            secretKey = secretKey.takeIf(String::isNotBlank)?.toByteArray(Charsets.UTF_8),
                            keyPassword = keyPassword.ifBlank { null }
                        )
                    } else {
                        require(password.isNotBlank() || recipientCertificate.isNotBlank()) { "Supply a password or recipient OpenPGP certificate." }
                        if (recipientCertificate.isNotBlank()) {
                            OpenPgpEngine.encryptForRecipients(input, output, listOf(recipientCertificate.toByteArray(Charsets.UTF_8)), armor = false)
                        } else {
                            OpenPgpEngine.encryptWithPassword(input, output, password, armor = false)
                        }
                    }
                }
            }
            val outputSha = HashEngine.hex(outFile)
            outputUri = CryptoScreenSupport.shareableUri(androidContext, outFile)
            val protection = when {
                decrypt -> "decrypted"
                recipientCertificate.isNotBlank() -> "OpenPGP recipient public key"
                else -> "OpenPGP password"
            }
            val safeHashFields = if (decrypt) {
                mapOf(CryptoFields.SOURCE_SHA256 to sourceHash) // source is ciphertext
            } else {
                mapOf(CryptoFields.OUTPUT_SHA256 to outputSha) // output is ciphertext
            }
            val provenance = if (decrypt) {
                CryptoJson.provenance(
                    capabilityId, "succeeded", sourceSha256 = sourceHash,
                    format = "plaintext", protection = protection,
                    extra = mapOf("plaintext_hash_disclosed" to false)
                )
            } else {
                CryptoJson.provenance(
                    capabilityId, "succeeded", outputSha256 = outputSha,
                    format = "OpenPGP", protection = protection,
                    extra = mapOf("plaintext_hash_disclosed" to false)
                )
            }
            val values = mapOf(
                CryptoFields.OUTPUT_URI to outputUri,
                CryptoFields.OUTPUT_FILENAME to outputName,
                CryptoFields.FORMAT to if (decrypt) "decrypted original bytes" else "OpenPGP binary",
                CryptoFields.PROVENANCE_JSON to provenance
            ) + safeHashFields
            result = CryptoScreenSupport.succeeded(method, context, values)
            status = if (decrypt) "Decrypted to $outputName" else "Encrypted to $outputName"
        }.onFailure {
            status = it.message ?: "Operation failed"
            result = CryptoScreenSupport.failed(method, context, it)
        }

        LaunchedEffect(context.startsImmediately, uriText) {
            if (context.startsImmediately && uriText.isNotBlank() && !launched) {
                val hasCredential = if (decrypt) password.isNotBlank() || secretKey.isNotBlank() else password.isNotBlank() || recipientCertificate.isNotBlank()
                if (hasCredential) { launched = true; runCrypto() }
            }
        }

        PgpScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; runCrypto() }) {
            Text("Output is standard OpenPGP. MethodMesh is not required for later decryption.", style = MaterialTheme.typography.bodyMedium)
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (sourceName.isBlank()) "Choose file" else sourceName) }
            if (decrypt) {
                if (context.settingShouldBeShown("password")) OutlinedTextField(password, { password = it }, label = { Text("Password (if symmetric)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                if (context.settingShouldBeShown("secret_key")) OutlinedTextField(secretKey, { secretKey = it }, label = { Text("OpenPGP secret key (ASCII armor; if recipient encrypted)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                if (secretKey.isNotBlank()) OutlinedTextField(keyPassword, { keyPassword = it }, label = { Text("Secret-key password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            } else {
                if (context.settingShouldBeShown("password")) OutlinedTextField(password, { password = it }, label = { Text("Password (leave blank when using recipient certificate)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                if (context.settingShouldBeShown("recipient_certificate")) OutlinedTextField(recipientCertificate, { recipientCertificate = it }, label = { Text("Recipient OpenPGP public certificate (optional)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            }
            Button(onClick = ::runCrypto, enabled = uriText.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (decrypt) "Decrypt file" else "Encrypt file") }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodySmall)
        }
    }
}

val FileEncryptCapabilityScreen: CapabilityScreenSpec = FileCryptScreen(As100FileEncryptMethod.id, "Encrypt file", "Encrypt any file as portable OpenPGP.", false)
val FileDecryptCapabilityScreen: CapabilityScreenSpec = FileCryptScreen(As100FileDecryptMethod.id, "Decrypt file", "Decrypt a portable OpenPGP file.", true)

object KeyGenerateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100KeyGenerateMethod.id
    override val title = "Create OpenPGP identity"
    override val description = "Create a portable signing/encryption identity."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        var userId by rememberSaveable { mutableStateOf(context.action.settings["user_id"] ?: "") }
        var password by rememberSaveable { mutableStateOf(context.action.settings["key_password"] ?: "") }
        var fingerprint by rememberSaveable { mutableStateOf("") }
        var publicCert by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        fun generate() = runCatching {
            val (secret, cert) = OpenPgpEngine.generateKey(userId, password)
            fingerprint = OpenPgpEngine.fingerprintForSecretKey(secret, password)
            publicCert = cert.toString(Charsets.UTF_8)
            val secretFile = CryptoScreenSupport.cacheFile(androidContext, "methodmesh-openpgp-secret-${fingerprint.take(16)}.asc").apply { writeBytes(secret) }
            result = CryptoScreenSupport.succeeded(As100KeyGenerateMethod, context, mapOf(
                CryptoFields.VALUE to publicCert,
                CryptoFields.CERTIFICATE to publicCert,
                CryptoFields.FORMAT to "OpenPGP secret key + public certificate",
                CryptoFields.OUTPUT_URI to CryptoScreenSupport.shareableUri(androidContext, secretFile),
                CryptoFields.OUTPUT_FILENAME to secretFile.name,
                CryptoFields.FINGERPRINT to fingerprint,
                CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", outputSha256 = HashEngine.hex(cert), format = "OpenPGP", protection = "secret key password", keyFingerprints = listOf(fingerprint))
            ))
        }.onFailure { result = CryptoScreenSupport.failed(As100KeyGenerateMethod, context, it) }
        PgpScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; generate() }) {
            Text("The returned public certificate is safe to distribute. The secret-key URI is sensitive and should be saved to controlled storage.")
            OutlinedTextField(userId, { userId = it }, label = { Text("User ID, e.g. Chrissy h. Roberts <...>") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(password, { password = it }, label = { Text("Secret-key password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button(onClick = ::generate, enabled = userId.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Generate identity") }
            if (fingerprint.isNotBlank()) { Text("Fingerprint: $fingerprint"); Text("NFC/QR identity token may carry only this fingerprint (for v4: openpgp4fpr URI).") }
        }
    }
}

object IdentityExportCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100IdentityExportMethod.id
    override val title = "Export crypto identity"
    override val description = "Create a public identity token for QR/NFC transfer. It contains no private key material."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        var displayName by rememberSaveable { mutableStateOf(context.action.settings["display_name"] ?: "") }
        var certificate by rememberSaveable { mutableStateOf(context.action.settings["certificate"] ?: "") }
        var fingerprintInput by rememberSaveable { mutableStateOf(context.action.settings["fingerprint"] ?: "") }
        var token by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun exportIdentity() = runCatching {
            require(displayName.isNotBlank()) { "Display name is required." }
            require(certificate.isNotBlank()) { "OpenPGP public certificate is required." }
            val certBytes = certificate.toByteArray(Charsets.UTF_8)
            val fingerprint = OpenPgpEngine.normaliseFingerprint(fingerprintInput)
            token = CryptoJson.identityToken(displayName, fingerprint)
            result = CryptoScreenSupport.succeeded(
                As100IdentityExportMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to token,
                    CryptoFields.IDENTITY_TOKEN to token,
                    CryptoFields.CERTIFICATE to certificate,
                    CryptoFields.FINGERPRINT to fingerprint,
                    CryptoFields.FORMAT to "methodmesh.identity.openpgp.v1 JSON + OpenPGP certificate",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId,
                        "succeeded",
                        sourceSha256 = HashEngine.hex(certBytes),
                        format = "public OpenPGP identity token",
                        keyFingerprints = listOf(fingerprint),
                        extra = mapOf("display_name" to displayName, "private_material" to false)
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100IdentityExportMethod, context, it) }

        PgpScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; exportIdentity() }) {
            Text("Write the identity token and public certificate to QR/NFC using the existing transport capability. Verification compares the signature fingerprint to this token.")
            OutlinedTextField(displayName, { displayName = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(certificate, { certificate = it }, label = { Text("OpenPGP public certificate") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(fingerprintInput, { fingerprintInput = it }, label = { Text("OpenPGP fingerprint") }, modifier = Modifier.fillMaxWidth())
            Text("For MethodMesh-generated keys this fingerprint is returned by Create OpenPGP identity. For imported certificates, obtain it from the originating OpenPGP tool and verify it out-of-band.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = ::exportIdentity, enabled = fingerprintInput.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create public identity token") }
            if (token.isNotBlank()) Text(token, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private class SignOrVerifyScreen(private val verify: Boolean) : CapabilityScreenSpec {
    override val capabilityId = if (verify) As100VerifySignatureMethod.id else As100SignMethod.id
    override val title = if (verify) "Verify signature" else "Sign content"
    override val description = if (verify) "Verify a detached OpenPGP signature." else "Create a detached OpenPGP signature."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val resolver = androidContext.contentResolver
        var text by rememberSaveable { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var uriText by rememberSaveable { mutableStateOf(context.action.settings["input_uri"] ?: "") }
        var sourceName by rememberSaveable { mutableStateOf("") }
        var keyText by rememberSaveable { mutableStateOf(context.action.settings[if (verify) "certificate" else "secret_key"] ?: "") }
        var keyPassword by rememberSaveable { mutableStateOf(context.action.settings["key_password"] ?: "") }
        var signature by rememberSaveable { mutableStateOf(context.action.settings["signature"] ?: "") }
        var expectedFingerprint by rememberSaveable { mutableStateOf(context.action.settings["expected_fingerprint"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uriText = uri?.toString().orEmpty(); sourceName = uri?.let { CryptoScreenSupport.sourceName(resolver, it) }.orEmpty() }

        fun openSource(): ByteArray = if (uriText.isNotBlank()) resolver.openInputStream(Uri.parse(uriText)).use { requireNotNull(it).readBytes() } else text.toByteArray(Charsets.UTF_8)
        fun execute() = runCatching {
            val source = openSource(); require(source.isNotEmpty()) { "Content is required." }; require(keyText.isNotBlank()) { "OpenPGP key/certificate is required." }
            if (verify) {
                require(signature.isNotBlank()) { "Detached signature is required." }
                val fingerprints = OpenPgpEngine.detachedVerify(ByteArrayInputStream(source), signature.toByteArray(Charsets.UTF_8), keyText.toByteArray(Charsets.UTF_8))
                require(fingerprints.isNotEmpty()) { "No valid signature was found." }
                if (expectedFingerprint.isNotBlank()) {
                    val expected = expectedFingerprint.filterNot(Char::isWhitespace).uppercase()
                    require(fingerprints.any { it.filterNot(Char::isWhitespace).uppercase() == expected }) {
                        "Signature is valid, but the signer fingerprint does not match the supplied NFC/QR identity fingerprint."
                    }
                }
                result = CryptoScreenSupport.succeeded(As100VerifySignatureMethod, context, mapOf(
                    CryptoFields.VALUE to "valid",
                    CryptoFields.FINGERPRINT to fingerprints.joinToString(","),
                    CryptoFields.SOURCE_SHA256 to HashEngine.hex(source),
                    CryptoFields.FORMAT to "OpenPGP detached signature",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", HashEngine.hex(source), format = "OpenPGP detached signature", keyFingerprints = fingerprints)
                ))
            } else {
                require(keyPassword.isNotBlank()) { "Key password is required." }
                val out = ByteArrayOutputStream(); OpenPgpEngine.detachedSign(ByteArrayInputStream(source), keyText.toByteArray(Charsets.UTF_8), keyPassword, out)
                signature = out.toByteArray().toString(Charsets.UTF_8)
                val fingerprint = OpenPgpEngine.fingerprintForSecretKey(keyText.toByteArray(Charsets.UTF_8), keyPassword)
                result = CryptoScreenSupport.succeeded(As100SignMethod, context, mapOf(
                    CryptoFields.SIGNATURE to signature,
                    CryptoFields.FINGERPRINT to fingerprint,
                    CryptoFields.SOURCE_SHA256 to HashEngine.hex(source),
                    CryptoFields.FORMAT to "OpenPGP detached signature",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", HashEngine.hex(source), outputSha256 = HashEngine.hex(out.toByteArray()), format = "OpenPGP detached signature", keyFingerprints = listOf(fingerprint))
                ))
            }
        }.onFailure { result = CryptoScreenSupport.failed(if (verify) As100VerifySignatureMethod else As100SignMethod, context, it) }

        PgpScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; execute() }) {
            OutlinedTextField(text, { text = it }, label = { Text("Text (or choose a file)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) { Text(if (sourceName.isBlank()) "Choose file instead" else sourceName) }
            OutlinedTextField(keyText, { keyText = it }, label = { Text(if (verify) "Signer public certificate" else "Signing secret key") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            if (!verify) OutlinedTextField(keyPassword, { keyPassword = it }, label = { Text("Key password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            if (verify) {
                OutlinedTextField(signature, { signature = it }, label = { Text("Detached signature") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(expectedFingerprint, { expectedFingerprint = it }, label = { Text("Expected fingerprint from NFC/QR identity (optional)") }, modifier = Modifier.fillMaxWidth())
            }
            Button(onClick = ::execute, modifier = Modifier.fillMaxWidth()) { Text(if (verify) "Verify" else "Sign") }
            if (!verify && signature.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(signature, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

val SignCapabilityScreen: CapabilityScreenSpec = SignOrVerifyScreen(false)
val VerifySignatureCapabilityScreen: CapabilityScreenSpec = SignOrVerifyScreen(true)

object ChallengeRespondCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ChallengeRespondMethod.id
    override val title = "Respond to challenge"
    override val description = "Sign an expiring challenge with an OpenPGP identity."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var challenge by rememberSaveable { mutableStateOf(context.action.settings["challenge"] ?: "") }
        var secretKey by rememberSaveable { mutableStateOf(context.action.settings["secret_key"] ?: "") }
        var keyPassword by rememberSaveable { mutableStateOf(context.action.settings["key_password"] ?: "") }
        var signature by rememberSaveable { mutableStateOf("") }; var result by remember { mutableStateOf<ExecutionResult?>(null) }
        fun respond() = runCatching {
            ChallengeEngine.validate(challenge)
            val out = ByteArrayOutputStream(); OpenPgpEngine.detachedSign(ByteArrayInputStream(challenge.toByteArray(Charsets.UTF_8)), secretKey.toByteArray(Charsets.UTF_8), keyPassword, out)
            signature = out.toByteArray().toString(Charsets.UTF_8)
            val fp = OpenPgpEngine.fingerprintForSecretKey(secretKey.toByteArray(Charsets.UTF_8), keyPassword)
            result = CryptoScreenSupport.succeeded(As100ChallengeRespondMethod, context, mapOf(CryptoFields.SIGNATURE to signature, CryptoFields.FINGERPRINT to fp, CryptoFields.FORMAT to "OpenPGP detached signature over methodmesh.challenge.v1", CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", sourceSha256 = HashEngine.hex(challenge.toByteArray(Charsets.UTF_8)), outputSha256 = HashEngine.hex(out.toByteArray()), format = "OpenPGP detached signature", keyFingerprints = listOf(fp))))
        }.onFailure { result = CryptoScreenSupport.failed(As100ChallengeRespondMethod, context, it) }
        PgpScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; respond() }) {
            OutlinedTextField(challenge, { challenge = it }, label = { Text("Challenge JSON") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(secretKey, { secretKey = it }, label = { Text("Signing secret key") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(keyPassword, { keyPassword = it }, label = { Text("Key password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button(onClick = ::respond, modifier = Modifier.fillMaxWidth()) { Text("Sign challenge") }
            if (signature.isNotBlank()) Text(signature, style = MaterialTheme.typography.bodySmall)
        }
    }
}

object ChallengeVerifyCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ChallengeVerifyMethod.id
    override val title = "Verify challenge response"
    override val description = "Verify signature, expiry and optional audience."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var challenge by rememberSaveable { mutableStateOf(context.action.settings["challenge"] ?: "") }
        var signature by rememberSaveable { mutableStateOf(context.action.settings["signature"] ?: "") }
        var certificate by rememberSaveable { mutableStateOf(context.action.settings["certificate"] ?: "") }
        var audience by rememberSaveable { mutableStateOf(context.action.settings["audience"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        fun verifyNow() = runCatching {
            ChallengeEngine.validate(challenge, audience.ifBlank { null })
            val fps = OpenPgpEngine.detachedVerify(ByteArrayInputStream(challenge.toByteArray(Charsets.UTF_8)), signature.toByteArray(Charsets.UTF_8), certificate.toByteArray(Charsets.UTF_8))
            require(fps.isNotEmpty()) { "Challenge signature is invalid." }
            result = CryptoScreenSupport.succeeded(As100ChallengeVerifyMethod, context, mapOf(CryptoFields.VALUE to "valid", CryptoFields.FINGERPRINT to fps.joinToString(","), CryptoFields.FORMAT to "verified proof-of-key-possession", CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", sourceSha256 = HashEngine.hex(challenge.toByteArray(Charsets.UTF_8)), format = "challenge verification", keyFingerprints = fps)))
        }.onFailure { result = CryptoScreenSupport.failed(As100ChallengeVerifyMethod, context, it) }
        PgpScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; verifyNow() }) {
            OutlinedTextField(challenge, { challenge = it }, label = { Text("Challenge JSON") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(signature, { signature = it }, label = { Text("Detached signature") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(certificate, { certificate = it }, label = { Text("Signer public certificate") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(audience, { audience = it }, label = { Text("Expected audience (optional)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::verifyNow, modifier = Modifier.fillMaxWidth()) { Text("Verify response") }
        }
    }
}
