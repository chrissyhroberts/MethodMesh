# Fix v0.1.4 — remove direct Bouncy Castle OpenPGP imports

## Compile failure

`OpenPgpEngine.kt`: `Unresolved reference 'openpgp'`.

## Root cause

The MethodMesh OpenPGP adapter directly imported `org.bouncycastle.openpgp.*` only to
parse a certificate fingerprint. That made compilation depend on the host app exposing
Bouncy Castle's `bcpg` API directly. Adding PGPainless Core did not guarantee that host
compile-classpath contract.

## Fix

`OpenPgpEngine.kt` now uses only the public Stateless OpenPGP API plus
`org.pgpainless.sop.SOPImpl`. There are no direct `org.bouncycastle.openpgp` imports.

For keys controlled by MethodMesh, the canonical fingerprint is obtained through the
SOP API itself: MethodMesh signs a fixed in-memory probe, verifies that signature with
the extracted public certificate, and reads `signingCertFingerprint` from the SOP
verification result. No probe or signature is persisted.

For an imported public certificate, `crypto.identity.export` now requires the caller to
provide the certificate fingerprint explicitly. That value should be obtained from the
originating OpenPGP tool and verified out-of-band. MethodMesh normalises and validates
40-hex (v4) or 64-hex fingerprints.

Recipient encryption no longer parses a recipient certificate merely to decorate
provenance with its fingerprint. Encryption itself remains unchanged and interoperable.

## Dependency

Only the SOP implementation is required by this source package:

```kotlin
implementation("org.pgpainless:pgpainless-sop:2.0.4")
```
