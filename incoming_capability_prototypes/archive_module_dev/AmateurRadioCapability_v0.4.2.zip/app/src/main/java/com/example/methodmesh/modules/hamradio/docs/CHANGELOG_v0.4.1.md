# Amateur Radio v0.4.1

## Changed

- Standardised the public/display name on **Amateur Radio**.
- Renamed the dashboard display title to **Amateur Radio dashboard**.
- Added formal RIL/search phrases `show amateur radio dashboard` and `recommend amateur radio band`.
- Retained `show ham radio dashboard` and `recommend ham band` as colloquial aliases.
- Preserved `hamradio`, all `ham.*` method IDs, and all `ham_*` output field names as stable compatibility identifiers.
- Updated the example XLSForm labels and form title to Amateur Radio terminology.
