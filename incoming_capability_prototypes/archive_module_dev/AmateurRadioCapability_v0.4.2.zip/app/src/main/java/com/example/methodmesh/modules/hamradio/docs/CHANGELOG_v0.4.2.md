# Amateur Radio v0.4.2

## Persistent dashboard behaviour

- Aligned `ham.dashboard` to the MethodMesh persistent-dashboard capability pattern.
- Native presets now remain on the live dashboard after refresh even when launched with `IntentLaunch`.
- Internal `intent_test` launches remain interactive for permission/cache/provider troubleshooting.
- External/ODK/protocol/sequence execution still uses the normal single-shot scaffold result path.
- The dashboard retains the latest successful `ExecutionResult` separately from the scaffold-visible result.
- Native preset completion is labelled **Finish**; normal native dashboard completion remains **Use this snapshot**.
- Refresh does not commit graph/output history.
- Snapshot settings are saved alongside values so the exact successful result can be reconstructed after configuration recreation.

No stable IDs changed: module `hamradio`, methods `ham.*`, and outputs `ham_*` remain compatible.
