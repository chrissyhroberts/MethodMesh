#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-app/build.gradle.kts}"
DEPENDENCY='implementation("org.pgpainless:pgpainless-sop:2.0.4")'
ANCHOR='implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")'

if [[ ! -f "$TARGET" ]]; then
  echo "ERROR: $TARGET not found" >&2
  exit 2
fi

if grep -Fq "$DEPENDENCY" "$TARGET"; then
  echo "PGPainless dependency already present in $TARGET"
  exit 0
fi

if ! grep -Fq "$ANCHOR" "$TARGET"; then
  echo "ERROR: expected MethodMesh Bouncy Castle dependency anchor not found in $TARGET" >&2
  echo "Add this line inside dependencies { ... }:" >&2
  echo "    $DEPENDENCY" >&2
  exit 3
fi

python3 - "$TARGET" "$ANCHOR" "$DEPENDENCY" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
anchor = sys.argv[2]
dep = sys.argv[3]
text = path.read_text()
needle = "    " + anchor
replacement = needle + "\n    " + dep
if needle not in text:
    raise SystemExit("anchor not found")
path.write_text(text.replace(needle, replacement, 1))
PY

echo "Added PGPainless SOP dependency to $TARGET"
