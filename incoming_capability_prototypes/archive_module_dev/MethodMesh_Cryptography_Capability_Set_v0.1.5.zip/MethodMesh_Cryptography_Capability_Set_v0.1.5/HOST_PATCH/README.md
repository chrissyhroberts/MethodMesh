# Required host Gradle patch — v0.1.5

The cryptography module uses the public Stateless OpenPGP API implemented by PGPainless.
The MethodMesh host app must therefore include this dependency in its real `app/build.gradle.kts`:

```kotlin
implementation("org.pgpainless:pgpainless-sop:2.0.4")
```

This release was checked against the current `chrissyhroberts/MethodMesh` `master` branch, whose
`app/build.gradle.kts` already contains Bouncy Castle `bcprov-jdk18on` and `bcpkix-jdk18on` but does
not contain PGPainless.

Apply from the MethodMesh repository root with either:

```bash
patch -p1 < path/to/HOST_PATCH/app_build.gradle.kts.patch
```

or:

```bash
bash path/to/HOST_PATCH/apply_methodmesh_crypto_dependency.sh app/build.gradle.kts
```

The shell helper is idempotent and will not add the dependency twice.

After applying, refresh Gradle dependencies and compile:

```bash
./gradlew :app:compileDebugKotlin
```

If the dependency is not applied to the host app, `OpenPgpEngine.kt` will fail with unresolved
references to `org.pgpainless`, `sop`, `SOP`, `SOPImpl`, and all chained SOP methods.
