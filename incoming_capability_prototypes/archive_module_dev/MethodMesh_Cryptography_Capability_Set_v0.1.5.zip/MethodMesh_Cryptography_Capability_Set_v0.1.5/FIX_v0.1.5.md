# Fix v0.1.5 — host Gradle integration

## Failure

`OpenPgpEngine.kt` failed with unresolved references to `pgpainless`, `sop`, `SOP`, `SOPImpl`,
`encrypt`, `decrypt`, `generateKey`, `extractCert`, `detachedSign`, and `detachedVerify`.

## Root cause

Previous releases included Gradle dependency *instructions* under `cryptography/integration/`, but
those text files are not Gradle inputs. The live MethodMesh `app/build.gradle.kts` did not contain the
PGPainless dependency, so the OpenPGP API was absent from `:app`'s Kotlin compile classpath.

## Fix

v0.1.5 adds a machine-applicable host patch under `HOST_PATCH/` that inserts:

```kotlin
implementation("org.pgpainless:pgpainless-sop:2.0.4")
```

inside the real `dependencies {}` block.

The source remains on the public SOP API only:

```kotlin
import org.pgpainless.sop.SOPImpl
import sop.SOP
```

No direct `org.bouncycastle.openpgp.*` imports are present.
