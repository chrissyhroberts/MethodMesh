# UnlockEd

**Learn to unlock.**

UnlockEd is an Android learning gate for selected social, video and leisure apps. It is deliberately **allow-by-default**: the parent explicitly chooses which apps receive educational friction; ordinary device use remains untouched.

## v0.2 vertical slice

The current prototype implements:

- native Kotlin + Jetpack Compose;
- discovery of launcher apps without `QUERY_ALL_PACKAGES`;
- explicit parent selection of gated apps;
- hard runtime exclusion of UnlockEd, launcher, Android Settings, default dialler and default SMS app;
- parent PIN protection for settings;
- an `AccessibilityService` listening only for top-level window-state changes;
- `canRetrieveWindowContent=false` and `isAccessibilityTool=false`;
- multiplication-table challenges;
- three correct answers by default;
- a fixed 10-second delay after a wrong answer;
- display of the correct fact during that delay;
- mandatory later recovery of every missed fact;
- 15 minutes of earned **foreground-use time**, not 15 minutes of wall-clock time;
- monotonic usage accounting, resistant to clock changes;
- screen-off pausing;
- fail-safe return to Home if Android refuses to display the gate;
- visible disclosure before Accessibility settings are opened.

## Core behaviour

```text
Parent selects Instagram
        ↓
Child opens Instagram
        ↓
UnlockEd gate appears
        ↓
7 × 8 = ?
   ├─ correct → progress
   └─ wrong   → show "7 × 8 = 56"
               → 10 second pause
               → fresh retrieval
               → missed fact returns later
        ↓
Minimum correct count reached
AND all missed facts recovered
        ↓
15 minutes cumulative foreground use
        ↓
Leaving app pauses allowance
Screen off pauses allowance
        ↓
Allowance reaches zero
        ↓
Gate returns
```

Pressing **Not now** returns to Home. Wrong answers add delay and retrieval work; they never create permanent denial.

## Safety boundary

UnlockEd is a learning-friction product, **not a general device lock**.

Only explicitly selected apps can be gated. Runtime enforcement ignores core packages even if preferences somehow contain them. UnlockEd should never be marketed as tamper-proof: a normal Android user can disable an AccessibilityService, and v0.x does not attempt to turn the phone into a managed/device-owner environment.

## Privacy architecture

The prototype is local-only. It has no account, analytics, advertising, location access, message access, screen-content access, screen recording or cloud backend. Backups are disabled.

The accessibility service exists solely to detect when a parent-selected app becomes the active top-level app. UnlockEd is not represented as an accessibility tool for disability support.

## Build

Requirements:

- Android Studio compatible with Android Gradle Plugin 9.4;
- Gradle 9.6;
- JDK 17;
- Android SDK / compile SDK 37.

The project uses:

- Android Gradle Plugin 9.4.0;
- Kotlin Compose plugin 2.4.10 with AGP 9 built-in Kotlin;
- Compose BOM 2026.08.00;
- `minSdk 28`;
- `targetSdk 37`.

This source bundle does not include generated Gradle wrapper binaries. On a development machine with Gradle available, run:

```bash
gradle wrapper --gradle-version 9.6.0
./gradlew test
./gradlew assembleDebug
```

Or open the repository in Android Studio and allow it to configure/sync the project.

## First device test

1. Install UnlockEd.
2. Create a parent PIN.
3. Select one non-essential test app.
4. Read and accept the Accessibility disclosure.
5. Enable **UnlockEd app gate** in Android Accessibility settings.
6. Return Home and open the selected app.
7. Confirm the learning gate appears.
8. Deliberately answer incorrectly and verify the correction and countdown.
9. Use Recents to try returning directly to the target while the gate is visible; the gate must reappear.
10. Complete the challenge and confirm the target opens.
11. Leave and reopen it; earned foreground time should remain.
12. Turn the screen off for a while; earned use should not materially fall while the device is asleep.

## Important release blocker

The current enforcement mechanism raises a normal Activity from an AccessibilityService. Modern Android imposes strong background-activity-start restrictions, so this must be validated on real devices and multiple Android versions before more UI is built around it. If it proves unreliable, the next candidate is an Accessibility overlay, not increasingly invasive permissions.

See **[ADVERSARIAL_REVIEW.md](ADVERSARIAL_REVIEW.md)** for the full multi-round review and unresolved risks.

## Next milestones

- physical-device enforcement test matrix;
- per-app rule editor (tables, question count, earned minutes, delay);
- parent PIN change/recovery;
- adaptive mastery model;
- flashcard challenge engine;
- stronger OEM compatibility testing;
- privacy policy / Data Safety / Accessibility declaration package;
- permanent Play `applicationId`;
- signed Android App Bundle and closed-test release.

## Licence

MIT.
