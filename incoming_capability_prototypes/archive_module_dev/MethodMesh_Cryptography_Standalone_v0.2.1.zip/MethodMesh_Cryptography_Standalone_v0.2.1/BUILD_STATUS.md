# Build status — standalone v0.2.1

## Dependency boundary

PASS: there is no `HOST_PATCH/` directory and no Gradle dependency instruction.

PASS: source scan finds no `pgpainless`, Bouncy Castle, OpenPGP, or other cryptography-library imports.

The module uses only:
- MethodMesh's existing module, transport and Compose UI contracts;
- Android platform APIs (`AndroidKeyStore`, platform `BiometricPrompt`, `SharedPreferences`, content URIs);
- JDK/JCA/JCE APIs (`SecureRandom`, `MessageDigest`, `Mac`, `Signature`, `Cipher`, `PBKDF2WithHmacSHA256`).

## Executable primitive tests

PASS: RFC 3394 AES Key Wrap known-answer vector.

PASS: JWE encrypt/decrypt and wrong-password authentication failure.

PASS: independent Python `cryptography` decryption of Kotlin-generated JWE.

PASS: RFC 6238 SHA-1 known-answer vector at T=59 (`94287082`).

PASS: 100 randomized Shamir 3-of-5 recovery trials.

PASS: ES256 detached JWS round-trip and tamper rejection.

PASS: independent Python `cryptography` verification of Kotlin-generated JWS and RFC 7638 thumbprint.

## Android integration validation

The environment used to assemble this package has no Android SDK and cannot clone the live repository over the container network, so a full `:app:compileDebugKotlin` was not executable here. Source signatures and module conventions were aligned to the current MethodMesh repository interface, and no host-file edit is required by design.

## Deliberately deferred

- recipient public-key encryption (JWE ECDH/RSA profile);
- large streaming file encryption (compact JWE is intentionally not presented as a streaming format);
- hardware-NFC private-key operations;
- biometric-gated signing (the signing key is device-bound, not biometric-gated in v0.2.1);
- bundling the existing RFC 3161 TSA implementation, because that is an independent capability and importing it would violate the zero-dependency rule.

Shamir is marked Development pending external cryptographic review; it is not represented as audited production cryptography.
