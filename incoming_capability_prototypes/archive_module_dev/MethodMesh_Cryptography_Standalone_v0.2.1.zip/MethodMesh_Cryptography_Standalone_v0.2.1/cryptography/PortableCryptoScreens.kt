package com.example.methodmesh.modules.cryptography

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

@Composable
private fun PortableScaffold(
    title: String,
    capabilityId: String,
    context: CapabilityScreenContext,
    result: ExecutionResult?,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    body: @Composable () -> Unit
) {
    CapabilityScreenScaffold(
        title = title,
        capabilityId = capabilityId,
        context = context,
        canGoBack = context.stepNumber > 1,
        capturedResult = result,
        resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
        onBack = onBack,
        onRetry = onRetry,
        onConfirm = { result?.let(onConfirmed) },
        onCancel = onCancel
    ) { body() }
}

private class FileJweScreen(
    override val capabilityId: String,
    override val title: String,
    override val description: String,
    private val decrypting: Boolean
) : CapabilityScreenSpec {
    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        var uriText by rememberSaveable { mutableStateOf(context.action.settings["input_uri"] ?: "") }
        var password by remember { mutableStateOf(context.action.settings["password"] ?: "") }
        var p2c by rememberSaveable { mutableStateOf(context.action.settings["p2c"] ?: JweEngine.DEFAULT_P2C.toString()) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("") }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) uriText = uri.toString()
        }

        fun runCrypto() = runCatching {
            require(uriText.isNotBlank()) { "Input file URI is required." }
            require(password.isNotEmpty()) { "Password is required." }
            val uri = Uri.parse(uriText)
            val resolver = androidContext.contentResolver
            val sourceName = CryptoScreenSupport.sourceName(resolver, uri)
            val inputBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Unable to read input URI.")

            if (decrypting) {
                val compact = inputBytes.toString(Charsets.US_ASCII)
                inputBytes.fill(0)
                val clear = JweEngine.decrypt(compact, password.toCharArray())
                val outName = sourceName.removeSuffix(".jwe").ifBlank { "decrypted" } + ".decrypted"
                val file = CryptoScreenSupport.cacheFile(androidContext, outName).apply { writeBytes(clear) }
                clear.fill(0)
                status = "Decrypted ${sourceName}."
                result = CryptoScreenSupport.succeeded(
                    As100FileDecryptMethod,
                    context,
                    mapOf(
                        CryptoFields.OUTPUT_URI to CryptoScreenSupport.shareableUri(androidContext, file),
                        CryptoFields.OUTPUT_FILENAME to file.name,
                        CryptoFields.FORMAT to "decrypted file from JWE",
                        CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                            capabilityId,
                            "succeeded",
                            format = "JWE Compact Serialization",
                            protection = "PBES2-HS256+A128KW / A256GCM",
                            extra = mapOf("plaintext_hash_returned" to false)
                        )
                    )
                )
            } else {
                val compact = JweEngine.encrypt(
                    inputBytes,
                    password.toCharArray(),
                    p2c.toIntOrNull() ?: JweEngine.DEFAULT_P2C
                )
                inputBytes.fill(0)
                val outBytes = compact.toByteArray(Charsets.US_ASCII)
                val file = CryptoScreenSupport.cacheFile(androidContext, "$sourceName.jwe").apply { writeBytes(outBytes) }
                val outputSha = HashEngine.hex(outBytes)
                status = "Encrypted ${sourceName} as JWE."
                result = CryptoScreenSupport.succeeded(
                    As100FileEncryptMethod,
                    context,
                    mapOf(
                        CryptoFields.OUTPUT_URI to CryptoScreenSupport.shareableUri(androidContext, file),
                        CryptoFields.OUTPUT_FILENAME to file.name,
                        CryptoFields.OUTPUT_SHA256 to outputSha,
                        CryptoFields.FORMAT to "JWE Compact Serialization (.jwe)",
                        CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                            capabilityId,
                            "succeeded",
                            outputSha256 = outputSha,
                            format = "JWE Compact Serialization",
                            protection = "PBES2-HS256+A128KW / A256GCM",
                            extra = mapOf(
                                "p2c" to (p2c.toIntOrNull() ?: JweEngine.DEFAULT_P2C),
                                "standalone_max_input_bytes" to JweEngine.MAX_INPUT_BYTES,
                                "plaintext_hash_returned" to false
                            )
                        )
                    )
                )
            }
        }.onSuccess {
            password = ""
        }.onFailure {
            result = CryptoScreenSupport.failed(
                if (decrypting) As100FileDecryptMethod else As100FileEncryptMethod,
                context,
                it
            )
        }

        LaunchedEffect(context.startsImmediately) {
            if (context.startsImmediately && uriText.isNotBlank() && password.isNotEmpty()) runCrypto()
        }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; runCrypto() }) {
            Text("Standard JWE; no MethodMesh-only ciphertext container. Standalone file mode is intentionally limited to ${JweEngine.MAX_INPUT_BYTES / (1024 * 1024)} MiB because compact JWE is not a streaming format.")
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(uriText, { uriText = it }, label = { Text("Input file URI") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { picker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) { Text("Choose file") }
            OutlinedTextField(password, { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            if (!decrypting) {
                OutlinedTextField(p2c, { p2c = it.filter(Char::isDigit) }, label = { Text("PBES2 iterations") }, modifier = Modifier.fillMaxWidth())
            }
            Button(onClick = ::runCrypto, enabled = uriText.isNotBlank() && password.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Text(if (decrypting) "Decrypt file" else "Encrypt file")
            }
            if (status.isNotBlank()) Text(status)
        }
    }
}

val FileEncryptCapabilityScreen: CapabilityScreenSpec = FileJweScreen(
    As100FileEncryptMethod.id,
    "Encrypt file",
    "Encrypt a small/medium file as standard password-protected JWE.",
    false
)
val FileDecryptCapabilityScreen: CapabilityScreenSpec = FileJweScreen(
    As100FileDecryptMethod.id,
    "Decrypt file",
    "Decrypt a standard password-protected JWE file.",
    true
)

object KeyGenerateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100KeyGenerateMethod.id
    override val title = "Create signing identity"
    override val description = "Create a device-bound ES256 identity and export only its public JWK."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var alias by rememberSaveable { mutableStateOf(context.action.settings["key_alias"] ?: JwsIdentityEngine.DEFAULT_ALIAS) }
        var jwk by rememberSaveable { mutableStateOf("") }
        var fingerprint by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun generate() = runCatching {
            jwk = JwsIdentityEngine.ensureIdentity(alias)
            fingerprint = JwsIdentityEngine.thumbprint(jwk)
            result = CryptoScreenSupport.succeeded(
                As100KeyGenerateMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to jwk,
                    CryptoFields.JWK to jwk,
                    CryptoFields.KEY_ALIAS to alias,
                    CryptoFields.FINGERPRINT to fingerprint,
                    CryptoFields.FORMAT to "RFC 7517 EC P-256 JWK",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId,
                        "succeeded",
                        format = "JWK",
                        protection = "Android Keystore device-bound private key",
                        keyFingerprints = listOf(fingerprint),
                        extra = mapOf("private_key_exported" to false, "jws_alg" to "ES256")
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100KeyGenerateMethod, context, it) }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; generate() }) {
            Text("The private key never leaves Android Keystore. The returned JWK and thumbprint are public and may be transferred by QR/NFC.")
            OutlinedTextField(alias, { alias = it }, label = { Text("Local key alias") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::generate, enabled = alias.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create / load identity") }
            if (fingerprint.isNotBlank()) {
                Text("JWK thumbprint: $fingerprint", style = MaterialTheme.typography.bodySmall)
                Text(jwk, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

object IdentityExportCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100IdentityExportMethod.id
    override val title = "Export crypto identity"
    override val description = "Create a public identity token for NFC/QR. No private material is included."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var displayName by rememberSaveable { mutableStateOf(context.action.settings["display_name"] ?: "") }
        var jwk by rememberSaveable { mutableStateOf(context.action.settings["jwk"] ?: "") }
        var token by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun export() = runCatching {
            require(displayName.isNotBlank()) { "Display name is required." }
            if (jwk.isBlank()) jwk = JwsIdentityEngine.ensureIdentity()
            val fp = JwsIdentityEngine.thumbprint(jwk)
            token = CryptoJson.identityToken(displayName, jwk)
            result = CryptoScreenSupport.succeeded(
                As100IdentityExportMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to token,
                    CryptoFields.IDENTITY_TOKEN to token,
                    CryptoFields.JWK to jwk,
                    CryptoFields.FINGERPRINT to fp,
                    CryptoFields.FORMAT to "methodmesh.identity.jwk.v1 JSON",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId, "succeeded", format = "JWK identity token", keyFingerprints = listOf(fp),
                        extra = mapOf("private_material" to false)
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100IdentityExportMethod, context, it) }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; export() }) {
            OutlinedTextField(displayName, { displayName = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(jwk, { jwk = it }, label = { Text("Public JWK (blank = local identity)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::export, enabled = displayName.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Create NFC/QR identity token") }
            if (token.isNotBlank()) Text(token, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun readContentBytes(androidContext: android.content.Context, uriText: String, text: String): ByteArray {
    if (uriText.isNotBlank()) {
        return androidContext.contentResolver.openInputStream(Uri.parse(uriText))?.use { it.readBytes() }
            ?: error("Unable to read input URI.")
    }
    return text.toByteArray(Charsets.UTF_8)
}

object SignCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignMethod.id
    override val title = "Sign content"
    override val description = "Create an ES256 detached JWS using the device-bound identity."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        var text by remember { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var uriText by rememberSaveable { mutableStateOf(context.action.settings["input_uri"] ?: "") }
        var alias by rememberSaveable { mutableStateOf(context.action.settings["key_alias"] ?: JwsIdentityEngine.DEFAULT_ALIAS) }
        var signature by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) uriText = uri.toString() }

        fun sign() = runCatching {
            val data = readContentBytes(androidContext, uriText, text)
            signature = JwsIdentityEngine.signDetached(data, alias)
            val jwk = JwsIdentityEngine.publicJwk(alias)
            val fp = JwsIdentityEngine.thumbprint(jwk)
            data.fill(0)
            result = CryptoScreenSupport.succeeded(
                As100SignMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to signature,
                    CryptoFields.SIGNATURE to signature,
                    CryptoFields.JWK to jwk,
                    CryptoFields.FINGERPRINT to fp,
                    CryptoFields.FORMAT to "RFC 7515 detached JWS / ES256",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId, "succeeded", format = "detached JWS", protection = "Android Keystore", keyFingerprints = listOf(fp)
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100SignMethod, context, it) }

        LaunchedEffect(context.startsImmediately) { if (context.startsImmediately && (text.isNotBlank() || uriText.isNotBlank())) sign() }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; sign() }) {
            OutlinedTextField(text, { text = it }, label = { Text("Text (or choose a file)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(uriText, { uriText = it }, label = { Text("Input file URI") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { picker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) { Text("Choose file") }
            OutlinedTextField(alias, { alias = it }, label = { Text("Local key alias") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::sign, enabled = text.isNotBlank() || uriText.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Sign") }
            if (signature.isNotBlank()) Text(signature, style = MaterialTheme.typography.bodySmall)
        }
    }
}

object VerifySignatureCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100VerifySignatureMethod.id
    override val title = "Verify signature"
    override val description = "Verify an ES256 detached JWS using a public P-256 JWK."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        var text by remember { mutableStateOf(context.action.settings["input_text"] ?: "") }
        var uriText by rememberSaveable { mutableStateOf(context.action.settings["input_uri"] ?: "") }
        var signature by rememberSaveable { mutableStateOf(context.action.settings["signature"] ?: "") }
        var jwk by rememberSaveable { mutableStateOf(context.action.settings["jwk"] ?: "") }
        var expected by rememberSaveable { mutableStateOf(context.action.settings["expected_fingerprint"] ?: "") }
        var verified by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) uriText = uri.toString() }

        fun verify() = runCatching {
            require(signature.isNotBlank()) { "Detached JWS is required." }
            require(jwk.isNotBlank()) { "Public JWK is required." }
            val data = readContentBytes(androidContext, uriText, text)
            val fp = JwsIdentityEngine.verifyDetached(data, signature, jwk)
            data.fill(0)
            if (expected.isNotBlank()) require(fp == expected.trim()) { "Signature is valid but signer thumbprint does not match expected identity." }
            verified = "Valid signature · $fp"
            result = CryptoScreenSupport.succeeded(
                As100VerifySignatureMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to "valid",
                    CryptoFields.FINGERPRINT to fp,
                    CryptoFields.JWK to jwk,
                    CryptoFields.FORMAT to "RFC 7515 detached JWS / ES256",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId, "succeeded", format = "detached JWS verification", keyFingerprints = listOf(fp),
                        extra = mapOf("expected_thumbprint_checked" to expected.isNotBlank())
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100VerifySignatureMethod, context, it) }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; verify() }) {
            OutlinedTextField(text, { text = it }, label = { Text("Text (or choose a file)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(uriText, { uriText = it }, label = { Text("Input file URI") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { picker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) { Text("Choose file") }
            OutlinedTextField(signature, { signature = it }, label = { Text("Detached JWS") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(jwk, { jwk = it }, label = { Text("Public JWK / from NFC or QR identity") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(expected, { expected = it }, label = { Text("Expected JWK thumbprint (optional)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::verify, enabled = signature.isNotBlank() && jwk.isNotBlank() && (text.isNotBlank() || uriText.isNotBlank()), modifier = Modifier.fillMaxWidth()) { Text("Verify") }
            if (verified.isNotBlank()) Text(verified, style = MaterialTheme.typography.titleMedium)
        }
    }
}

object ChallengeRespondCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ChallengeRespondMethod.id
    override val title = "Respond to challenge"
    override val description = "Validate and sign a current challenge with the local ES256 identity."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var challenge by rememberSaveable { mutableStateOf(context.action.settings["challenge"] ?: "") }
        var alias by rememberSaveable { mutableStateOf(context.action.settings["key_alias"] ?: JwsIdentityEngine.DEFAULT_ALIAS) }
        var signature by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun respond() = runCatching {
            ChallengeEngine.validate(challenge)
            signature = JwsIdentityEngine.signDetached(challenge.toByteArray(Charsets.UTF_8), alias)
            val jwk = JwsIdentityEngine.publicJwk(alias)
            val fp = JwsIdentityEngine.thumbprint(jwk)
            result = CryptoScreenSupport.succeeded(
                As100ChallengeRespondMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to signature,
                    CryptoFields.SIGNATURE to signature,
                    CryptoFields.JWK to jwk,
                    CryptoFields.FINGERPRINT to fp,
                    CryptoFields.FORMAT to "ES256 detached JWS challenge response",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(capabilityId, "succeeded", format = "JWS challenge response", keyFingerprints = listOf(fp))
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100ChallengeRespondMethod, context, it) }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; respond() }) {
            OutlinedTextField(challenge, { challenge = it }, label = { Text("Challenge JSON") }, minLines = 5, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(alias, { alias = it }, label = { Text("Local key alias") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::respond, enabled = challenge.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Sign challenge") }
            if (signature.isNotBlank()) Text(signature, style = MaterialTheme.typography.bodySmall)
        }
    }
}

object ChallengeVerifyCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ChallengeVerifyMethod.id
    override val title = "Verify challenge response"
    override val description = "Verify an ES256 challenge response and its expiry/audience."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var challenge by rememberSaveable { mutableStateOf(context.action.settings["challenge"] ?: "") }
        var signature by rememberSaveable { mutableStateOf(context.action.settings["signature"] ?: "") }
        var jwk by rememberSaveable { mutableStateOf(context.action.settings["jwk"] ?: "") }
        var audience by rememberSaveable { mutableStateOf(context.action.settings["audience"] ?: "") }
        var status by rememberSaveable { mutableStateOf("") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }

        fun verify() = runCatching {
            val fp = JwsIdentityEngine.verifyDetached(challenge.toByteArray(Charsets.UTF_8), signature, jwk)
            ChallengeEngine.validate(challenge, audience.ifBlank { null })
            status = "Valid current response · $fp"
            result = CryptoScreenSupport.succeeded(
                As100ChallengeVerifyMethod,
                context,
                mapOf(
                    CryptoFields.VALUE to "valid",
                    CryptoFields.FINGERPRINT to fp,
                    CryptoFields.FORMAT to "ES256 detached JWS challenge verification",
                    CryptoFields.PROVENANCE_JSON to CryptoJson.provenance(
                        capabilityId, "succeeded", format = "JWS challenge verification", keyFingerprints = listOf(fp),
                        extra = mapOf("audience_checked" to audience.isNotBlank())
                    )
                )
            )
        }.onFailure { result = CryptoScreenSupport.failed(As100ChallengeVerifyMethod, context, it) }

        PortableScaffold(title, capabilityId, context, result, onBack, onConfirmed, onCancel, { result = null; verify() }) {
            OutlinedTextField(challenge, { challenge = it }, label = { Text("Challenge JSON") }, minLines = 5, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(signature, { signature = it }, label = { Text("Detached JWS response") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(jwk, { jwk = it }, label = { Text("Public JWK") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(audience, { audience = it }, label = { Text("Expected audience (optional)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = ::verify, enabled = challenge.isNotBlank() && signature.isNotBlank() && jwk.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Verify response") }
            if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.titleMedium)
        }
    }
}
