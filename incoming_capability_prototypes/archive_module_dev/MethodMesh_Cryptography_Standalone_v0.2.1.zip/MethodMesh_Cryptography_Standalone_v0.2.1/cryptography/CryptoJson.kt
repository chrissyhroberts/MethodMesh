package com.example.methodmesh.modules.cryptography

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

object CryptoJson {
    fun provenance(
        methodId: String,
        status: String,
        sourceSha256: String? = null,
        outputSha256: String? = null,
        format: String? = null,
        protection: String? = null,
        keyFingerprints: List<String> = emptyList(),
        extra: Map<String, Any?> = emptyMap()
    ): String {
        val obj = JSONObject()
        obj.put("schema", "methodmesh.crypto.provenance.v2")
        obj.put("method_id", methodId)
        obj.put("status", status)
        obj.put("created_time_iso", Instant.now().toString())
        sourceSha256?.let { obj.put("source_sha256", it) }
        outputSha256?.let { obj.put("output_sha256", it) }
        format?.let { obj.put("format", it) }
        protection?.let { obj.put("protection", it) }
        if (keyFingerprints.isNotEmpty()) obj.put("key_fingerprints", JSONArray(keyFingerprints))
        extra.forEach { (key, value) -> obj.put(key, value) }
        return obj.toString()
    }

    /** Public identity token for QR/NFC. It contains only display metadata + public JWK. */
    fun identityToken(displayName: String, jwk: String): String = JSONObject().apply {
        put("schema", "methodmesh.identity.jwk.v1")
        put("display_name", displayName)
        put("jwk", JSONObject(jwk))
        put("jwk_thumbprint_sha256", JwsIdentityEngine.thumbprint(jwk))
    }.toString()
}
