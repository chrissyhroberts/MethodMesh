# Astronomy v0.4.2 validation

## Completed in this package build

- Added `astronomy.dashboard` as an experimental dashboard-style capability with explicit refresh, preview-only refresh semantics, structured ODK outputs, current weather/dew/Moon cards, a six-hour cloud strip, and a GFS 300/250/200 hPa upper-atmosphere panel.
- Added `openmeteo.astronomy_jetstream`, executed through shared `api.get`; Open-Meteo documents wind speed/direction on the 300, 250 and 200 hPa pressure levels.
- Dashboard upper-atmosphere interpretation remains a heuristic planning proxy and is not labelled as a direct seeing estimate.

- `AstronomyMath.kt` + `AstronomyMathSmoke.kt` compile/smoke-test material is retained from v0.2.
- Open-Meteo astronomy API declarations use the shared `ApiDefinitionRepository` + `api.get` execution boundary.
- standalone `astronomy.dew_risk` defaults to GPS + Open-Meteo, then manual fallback.
- `astronomy.dew_risk` also accepts `temperature_c` and `relative_humidity_pct` when those fields are already present in the current action context. This supports the existing multi-step `ExternalWorkflowActivity` forwarding mechanism, including a preceding AHT20 `sensor.read` step. It is **not** evidence of a general user-facing pipe.
- `sensorread` has therefore been removed from astronomy's declared module dependencies.
- `astronomy.imaging_window` accepts a supplied full `plus_code` and resolves its centroid using the existing Open Location Code implementation; otherwise it obtains live GPS.
- native conditions/dew/imaging screens implement automatic GPS/API behaviour with manual fallback.
- `astronomy.sky_test` specifies flat screen-down/rear-camera-up use.
- `astronomy.focus` is explicitly restricted to eyepiece/optical-train use.

## Still required in the actual repository

1. `./gradlew :app:assembleDebug`
2. open `astronomy.dashboard` on a physical phone and verify native dashboard presentation, refresh, GPS permission flow and the six-hour cloud strip
3. invoke `astronomy.dashboard` from an external workflow/ODK and verify automatic return of structured outputs
4. compare the 200/250/300 hPa values with an independent GFS/Metcheck-style jet chart
5. verify refresh does not write repeated graph observations before **Use this snapshot**
6. architecture/module tests
7. physical Android validation of GPS permission flow and API refresh
8. multi-step workflow test: `sensor.read(AHT20)` followed by `astronomy.dew_risk`
9. standalone dew test confirming it does **not** imply or attempt an AHT20 read
10. Plus Code input test for `astronomy.imaging_window`
11. camera sensitivity testing for bright-star sky test on representative phones
12. optical-adapter validation before treating `astronomy.focus` as production-ready

Status remains **Development**.
