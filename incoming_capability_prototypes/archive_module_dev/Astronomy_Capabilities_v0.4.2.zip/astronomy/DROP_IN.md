# Drop-in instructions — Astronomy v0.4.2

Copy this whole `astronomy/` directory to:

`app/src/main/java/com/example/methodmesh/modules/astronomy/`

The normal generated MethodMesh module index should discover `AstronomyModule` automatically.

## Module dependencies

The module directly reuses:

- `apiget` — all Open-Meteo calls go through `api.get`;
- `pluscodecapture` — Plus Code decoding/location interoperability.

`sensorread` is **not** an astronomy module dependency. `astronomy.dew_risk` merely accepts the same canonical fields (`temperature_c`, `relative_humidity_pct`) when they have genuinely arrived from an earlier step of the same multi-step external workflow. There is not yet a general user-facing MethodMesh pipe that lets a standalone astronomy screen invoke or subscribe to `sensor.read`.

Standalone dew-risk acquisition therefore uses:

1. supplied/upstream values if already present in the current workflow;
2. otherwise GPS + Open-Meteo;
3. otherwise manual temperature/humidity fallback.

## API definitions

No manual import is required. `AstronomyApiDefinitions.ensureInstalled()` installs the astronomy-specific Open-Meteo declarations into the normal API registry on first use. The JSON export in `docs/` is retained as an inspectable/portable reference.

## Validation

Run the normal Android build and architecture tests after dropping in the folder. Camera/GPS behaviour still requires physical-device testing.
