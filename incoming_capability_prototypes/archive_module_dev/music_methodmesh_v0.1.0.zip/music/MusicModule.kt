package com.example.methodmesh.modules.music

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object MusicModule : MethodMeshModule {
    override val moduleId = "music"
    override val displayName = "Music"
    override val summary = "Tempo, pitch, harmony, temperament, practice and live set-list utilities for musicians."

    override fun as100Methods() = listOf(
        As100TapTempoMethod,
        As100MetronomeMethod,
        As100NoteFrequencyMethod,
        As100TransposeMethod,
        As100IntervalMethod,
        As100ChordMethod,
        As100ChordGuideMethod,
        As100TempoConvertMethod,
        As100DelayTimeMethod,
        As100TemperamentMethod,
        As100PolyrhythmMethod,
        As100TempoTrainerMethod,
        As100HarmonicsMethod,
        As100SetListTimingMethod,
        As100MusicReferenceMethod,
        As100PracticeDashboardMethod,
        As100PerformanceDashboardMethod,
        As100ReferenceDashboardMethod
    )

    override fun rilBindings() = listOf(
        RilBinding("tap tempo", As100TapTempoMethod.ID, "Tap repeatedly to estimate BPM"),
        RilBinding("run metronome", As100MetronomeMethod.ID, "Run an audio, visual and haptic metronome"),
        RilBinding("convert note frequency", As100NoteFrequencyMethod.ID, "Convert between scientific pitch notation and frequency"),
        RilBinding("transpose music", As100TransposeMethod.ID, "Transpose notes or chord symbols"),
        RilBinding("identify interval", As100IntervalMethod.ID, "Identify the interval between two notes"),
        RilBinding("identify chord", As100ChordMethod.ID, "Build or identify a chord"),
        RilBinding("show chord shape", As100ChordGuideMethod.ID, "Show a compact guitar chord fingering"),
        RilBinding("convert tempo", As100TempoConvertMethod.ID, "Convert BPM to note durations"),
        RilBinding("calculate delay time", As100DelayTimeMethod.ID, "Calculate tempo-synchronised delay time"),
        RilBinding("calculate temperament", As100TemperamentMethod.ID, "Calculate an equal-temperament step"),
        RilBinding("generate polyrhythm", As100PolyrhythmMethod.ID, "Generate an A:B polyrhythm cycle"),
        RilBinding("train tempo", As100TempoTrainerMethod.ID, "Generate a stepped practice tempo progression"),
        RilBinding("explore harmonics", As100HarmonicsMethod.ID, "Calculate a harmonic series"),
        RilBinding("time set list", As100SetListTimingMethod.ID, "Calculate total performance duration"),
        RilBinding("music reference", As100MusicReferenceMethod.ID, "Show scale notes and diatonic triads"),
        RilBinding("open practice dashboard", As100PracticeDashboardMethod.ID, "Open the live music practice dashboard"),
        RilBinding("open performance dashboard", As100PerformanceDashboardMethod.ID, "Open the persistent set-list dashboard"),
        RilBinding("open music reference dashboard", As100ReferenceDashboardMethod.ID, "Open the key, scale and chord reference dashboard")
    )

    override fun capabilityScreens() = listOf(
        TapTempoCapabilityScreen,
        MetronomeCapabilityScreen,
        NoteFrequencyCapabilityScreen,
        TransposeCapabilityScreen,
        IntervalCapabilityScreen,
        ChordCapabilityScreen,
        ChordGuideCapabilityScreen,
        TempoConvertCapabilityScreen,
        DelayTimeCapabilityScreen,
        TemperamentCapabilityScreen,
        PolyrhythmCapabilityScreen,
        TempoTrainerCapabilityScreen,
        HarmonicsCapabilityScreen,
        SetListTimingCapabilityScreen,
        MusicReferenceCapabilityScreen,
        PracticeDashboardCapabilityScreen,
        PerformanceDashboardCapabilityScreen,
        ReferenceDashboardCapabilityScreen
    )

    override fun capabilitySettings() = mapOf(
        As100TapTempoMethod.ID to listOf(
            MethodSetting.TextSetting("tap_intervals_ms", "Tap intervals", "Optional comma-separated millisecond intervals for ODK/protocol use.", defaultValue = "")
        ),
        As100MetronomeMethod.ID to listOf(
            MethodSetting.FloatSetting("bpm", "Tempo", defaultValue = 120f, minimum = 20f, maximum = 400f, step = 1f, unit = "BPM", decimals = 1),
            MethodSetting.IntSetting("beats_per_bar", "Beats per bar", defaultValue = 4, minimum = 1, maximum = 16, step = 1),
            MethodSetting.ChoiceSetting("subdivision", "Subdivision", defaultValue = "quarter", choices = subdivisionChoices),
            MethodSetting.TextSetting("accent_pattern", "Accent beats", "Comma-separated beat numbers; 1 accents the downbeat.", defaultValue = "1"),
            MethodSetting.BooleanSetting("audio_enabled", "Audio click", defaultValue = true),
            MethodSetting.BooleanSetting("visual_enabled", "Visual pulse", defaultValue = true),
            MethodSetting.BooleanSetting("haptic_enabled", "Haptic pulse", defaultValue = false)
        ),
        As100NoteFrequencyMethod.ID to listOf(
            MethodSetting.ChoiceSetting("mode", "Conversion", defaultValue = "note_to_frequency", choices = listOf("note_to_frequency", "frequency_to_note")),
            MethodSetting.TextSetting("note", "Note", "Scientific pitch notation, e.g. A4 or C#3.", defaultValue = "A4"),
            MethodSetting.FloatSetting("frequency_hz", "Frequency", defaultValue = 440f, minimum = 0.01f, maximum = 50000f, step = 0.1f, unit = "Hz", decimals = 3),
            MethodSetting.FloatSetting("reference_a4_hz", "Reference A4", defaultValue = 440f, minimum = 400f, maximum = 480f, step = 0.1f, unit = "Hz", decimals = 1),
            MethodSetting.BooleanSetting("prefer_flats", "Prefer flat note names", defaultValue = false)
        ),
        As100TransposeMethod.ID to listOf(
            MethodSetting.TextSetting("input", "Notes / chords", defaultValue = "C G Am F"),
            MethodSetting.ChoiceSetting("input_type", "Input type", defaultValue = "chords", choices = listOf("chords", "notes")),
            MethodSetting.IntSetting("semitones", "Semitones", defaultValue = 0, minimum = -24, maximum = 24, step = 1),
            MethodSetting.TextSetting("from_key", "From key", "Optional; when both keys are supplied they determine the shift.", defaultValue = ""),
            MethodSetting.TextSetting("to_key", "To key", defaultValue = ""),
            MethodSetting.BooleanSetting("prefer_flats", "Prefer flat note names", defaultValue = false)
        ),
        As100IntervalMethod.ID to listOf(
            MethodSetting.TextSetting("note_a", "First note", defaultValue = "C4"),
            MethodSetting.TextSetting("note_b", "Second note", defaultValue = "G4")
        ),
        As100ChordMethod.ID to listOf(
            MethodSetting.ChoiceSetting("mode", "Mode", defaultValue = "build", choices = listOf("build", "identify")),
            MethodSetting.TextSetting("root", "Root", defaultValue = "C"),
            MethodSetting.ChoiceSetting("quality", "Chord quality", defaultValue = "", choices = chordQualities),
            MethodSetting.TextSetting("notes", "Notes", "Space- or comma-separated notes for identification.", defaultValue = "C E G"),
            MethodSetting.BooleanSetting("prefer_flats", "Prefer flat note names", defaultValue = false)
        ),
        As100ChordGuideMethod.ID to listOf(
            MethodSetting.ChoiceSetting("instrument", "Instrument", defaultValue = "guitar", choices = listOf("guitar")),
            MethodSetting.TextSetting("chord", "Chord", defaultValue = "C")
        ),
        As100TempoConvertMethod.ID to tempoSubdivisionSettings(),
        As100DelayTimeMethod.ID to tempoSubdivisionSettings(defaultSubdivision = "dotted_eighth"),
        As100TemperamentMethod.ID to listOf(
            MethodSetting.IntSetting("divisions", "Equal divisions of octave", defaultValue = 12, minimum = 1, maximum = 120, step = 1),
            MethodSetting.IntSetting("step", "Step", defaultValue = 0, minimum = -240, maximum = 240, step = 1),
            MethodSetting.FloatSetting("reference_hz", "Reference frequency", defaultValue = 440f, minimum = 0.01f, maximum = 50000f, step = 0.1f, unit = "Hz", decimals = 3),
            MethodSetting.IntSetting("reference_step", "Reference step", defaultValue = 0, minimum = -240, maximum = 240, step = 1)
        ),
        As100PolyrhythmMethod.ID to listOf(
            MethodSetting.IntSetting("ratio_a", "Pulse count A", defaultValue = 3, minimum = 1, maximum = 32, step = 1),
            MethodSetting.IntSetting("ratio_b", "Pulse count B", defaultValue = 2, minimum = 1, maximum = 32, step = 1),
            MethodSetting.FloatSetting("bpm", "Cycle tempo", defaultValue = 60f, minimum = 10f, maximum = 300f, step = 1f, unit = "BPM", decimals = 1),
            MethodSetting.BooleanSetting("audio_enabled", "Audio", defaultValue = true),
            MethodSetting.BooleanSetting("haptic_enabled", "Haptics", defaultValue = false)
        ),
        As100TempoTrainerMethod.ID to listOf(
            MethodSetting.FloatSetting("start_bpm", "Start tempo", defaultValue = 80f, minimum = 20f, maximum = 400f, step = 1f, unit = "BPM", decimals = 1),
            MethodSetting.FloatSetting("target_bpm", "Target tempo", defaultValue = 120f, minimum = 20f, maximum = 400f, step = 1f, unit = "BPM", decimals = 1),
            MethodSetting.FloatSetting("increment_bpm", "Increment", defaultValue = 2f, minimum = 0.1f, maximum = 50f, step = 0.5f, unit = "BPM", decimals = 1),
            MethodSetting.IntSetting("bars_per_step", "Bars per step", defaultValue = 4, minimum = 1, maximum = 64, step = 1)
        ),
        As100HarmonicsMethod.ID to listOf(
            MethodSetting.FloatSetting("fundamental_hz", "Fundamental", defaultValue = 110f, minimum = 0.01f, maximum = 20000f, step = 0.1f, unit = "Hz", decimals = 3),
            MethodSetting.IntSetting("count", "Harmonics", defaultValue = 8, minimum = 1, maximum = 64, step = 1),
            MethodSetting.FloatSetting("reference_a4_hz", "Reference A4", defaultValue = 440f, minimum = 400f, maximum = 480f, step = 0.1f, unit = "Hz", decimals = 1),
            MethodSetting.BooleanSetting("prefer_flats", "Prefer flats", defaultValue = false)
        ),
        As100SetListTimingMethod.ID to listOf(
            MethodSetting.TextSetting("durations", "Song durations", "Comma-separated mm:ss values.", defaultValue = "3:30,4:00,3:45"),
            MethodSetting.TextSetting("gaps", "Gaps", "Optional comma-separated gap durations.", defaultValue = "0:20,0:20"),
            MethodSetting.TextSetting("start_time", "Start time", "Optional display/audit value.", defaultValue = "")
        ),
        As100MusicReferenceMethod.ID to referenceSettings(),
        As100PracticeDashboardMethod.ID to listOf(
            MethodSetting.FloatSetting("bpm", "Tempo", defaultValue = 100f, minimum = 20f, maximum = 400f, step = 1f, unit = "BPM", decimals = 1),
            MethodSetting.IntSetting("beats_per_bar", "Beats per bar", defaultValue = 4, minimum = 1, maximum = 16, step = 1),
            MethodSetting.ChoiceSetting("subdivision", "Subdivision", defaultValue = "quarter", choices = subdivisionChoices),
            MethodSetting.FloatSetting("reference_a4_hz", "Reference A4", defaultValue = 440f, minimum = 400f, maximum = 480f, step = 0.1f, unit = "Hz", decimals = 1),
            MethodSetting.TextSetting("exercise", "Exercise", defaultValue = ""),
            MethodSetting.FloatSetting("target_bpm", "Target tempo", defaultValue = 120f, minimum = 20f, maximum = 400f, step = 1f, unit = "BPM", decimals = 1)
        ),
        As100PerformanceDashboardMethod.ID to listOf(
            MethodSetting.TextSetting("set_name", "Set name", defaultValue = "Tonight's set"),
            MethodSetting.TextSetting("planned_start", "Planned start", defaultValue = ""),
            MethodSetting.TextSetting("curfew", "Curfew / end time", defaultValue = "")
        ),
        As100ReferenceDashboardMethod.ID to referenceSettings()
    )

    private val subdivisionChoices = listOf("whole", "half", "quarter", "eighth", "sixteenth", "thirty_second", "dotted_half", "dotted_quarter", "dotted_eighth", "quarter_triplet", "eighth_triplet", "sixteenth_triplet")
    private val chordQualities = listOf("", "m", "dim", "aug", "sus2", "sus4", "6", "m6", "7", "maj7", "m7", "mMaj7", "dim7", "m7b5", "add9", "9", "maj9", "m9")

    private fun tempoSubdivisionSettings(defaultSubdivision: String = "quarter") = listOf(
        MethodSetting.FloatSetting("bpm", "Tempo", defaultValue = 120f, minimum = 20f, maximum = 400f, step = 1f, unit = "BPM", decimals = 1),
        MethodSetting.ChoiceSetting("subdivision", "Subdivision", defaultValue = defaultSubdivision, choices = subdivisionChoices)
    )

    private fun referenceSettings() = listOf(
        MethodSetting.TextSetting("root", "Root", defaultValue = "C"),
        MethodSetting.ChoiceSetting("scale", "Scale", defaultValue = "major", choices = listOf("major", "natural_minor", "harmonic_minor", "melodic_minor", "major_pentatonic", "minor_pentatonic", "blues", "dorian", "mixolydian")),
        MethodSetting.BooleanSetting("prefer_flats", "Prefer flats", defaultValue = false)
    )
}
