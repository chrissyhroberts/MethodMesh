# MethodMesh Music module

**Status:** Development · **Version:** 0.1.0

Self-contained MethodMesh music utilities under `modules/music/`. The module deliberately concentrates on deterministic music calculations, phone-native physical interaction, practice support and live set timing rather than DAW/notation features.

## Capability map

- Rhythm: Tap tempo, Metronome, Tempo converter, Delay time, Polyrhythm, Tempo trainer.
- Pitch/theory: Note ↔ frequency, Transpose, Interval, Chord, Chord guide, Temperament, Harmonics, Music reference.
- Persistence/dashboard: Practice dashboard, Performance/set-list dashboard, Music reference dashboard.
- Live tuning: reuse existing `acoustic.tune`; do not duplicate microphone capture/DSP.

## Architecture

`MusicAlgorithms.kt` owns pure deterministic calculations. `MusicMethod.kt` exposes them as stable AS100 methods. `MusicCapabilityScreen.kt` owns ordinary native screens and physical interactions. `MusicDashboardCapabilityScreen.kt` owns the three persistent dashboards. `SetListRepository.kt` owns local set-list persistence. No capability-specific shared-shell changes are required.

## Delivery/installation

Copy the complete `music/` folder to `app/src/main/java/com/example/methodmesh/modules/music/`. Module discovery should pick up `MusicModule.kt` automatically.

## Validation status

This is a source prototype generated without the full MethodMesh repository/build environment. It is intentionally marked Development. In the target repo run focused algorithm tests and `./gradlew :app:assembleDebug`, then exercise native preset, protocol, schedule and ODK paths before promotion.
