# Performance / set-list dashboard

**Method ID:** `music.performance_dashboard`  
**Status:** Development  
**Version:** 0.1.0

## What it does

Persistent set list with running elapsed/remaining time and actual song durations.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `set_name`
- `planned_start`
- `curfew; native dashboard additionally uses locally stored songs`

## Outputs

- `music_performance_dashboard_result`
- `music_performance_dashboard_set_name`
- `music_performance_dashboard_song_count`
- `music_performance_dashboard_planned_seconds`
- `music_performance_dashboard_planned_formatted`
- `music_performance_dashboard_completed_count`
- `music_performance_dashboard_elapsed_seconds`
- `music_performance_dashboard_remaining_seconds`
- `music_performance_dashboard_variance_seconds`
- `music_performance_dashboard_songs_json`
- `music_performance_dashboard_status`
- `music_performance_dashboard_audit_json`
- `music_performance_dashboard_error`

## Main result

`music_performance_dashboard_result` is the compact native/share result. `music_performance_dashboard_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_PerformanceDashboard.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Native songs are stored locally in capability-owned SharedPreferences. External callers receive/return snapshots and should not depend on native interactive editing.
