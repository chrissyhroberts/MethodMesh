# Music module roadmap note

## Added in Development v0.1.0

Tap tempo; metronome; note/frequency conversion; transposition; interval/chord identification; guitar chord guide; tempo/subdivision and delay-time calculators; EDO temperament; polyrhythm; tempo trainer; harmonics; set-list timing; music reference; practice, performance and reference dashboards.

## Open issues before Production

- Build and instrumentation validation in the full MethodMesh repository.
- Add focused unit tests for `MusicAlgorithms`.
- Validate all ODK example forms against the target ODK Collect/MethodMesh intent contract.
- Expand chord-shape libraries beyond common guitar chords.
- Decide whether tempo trainer should auto-advance the live metronome after N bars.
- Add differentiated stereo/haptic polyrhythm playback if desired.
- Confirm vibration behaviour/API policy on supported Android versions.
- Consider fret-position/string-tension tools as a later luthiery subfamily.
- Consider MIDI clock/BPM utilities only if they remain lightweight and do not turn MethodMesh into a sequencer.
- Reuse `acoustic.tune` for live tuner integration rather than duplicating microphone/DSP code.
