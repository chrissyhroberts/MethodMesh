# Interval identifier

**Method ID:** `music.interval`  
**Status:** Development  
**Version:** 0.1.0

## What it does

Identify chromatic interval between two notes.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `note_a`
- `note_b`

## Outputs

- `music_interval_result`
- `music_interval_note_a`
- `music_interval_note_b`
- `music_interval_semitones`
- `music_interval_interval_name`
- `music_interval_status`
- `music_interval_audit_json`
- `music_interval_error`

## Main result

`music_interval_result` is the compact native/share result. `music_interval_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_Interval.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Enharmonic spelling is normalised chromatically; v0.1 does not distinguish diatonic spellings such as augmented fourth vs diminished fifth.
