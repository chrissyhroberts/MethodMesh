package com.example.methodmesh.modules.music

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

internal object PracticeDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PracticeDashboardMethod.ID
    override val title = "Practice dashboard"
    override val description = "Live tempo, exercise and tuning-reference dashboard."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) = PracticeDashboardUi(context,onBack,onConfirmed,onCancel)
}
internal object PerformanceDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PerformanceDashboardMethod.ID
    override val title = "Performance / set list"
    override val description = "Persistent running order with planned and actual timing."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) = PerformanceDashboardUi(context,onBack,onConfirmed,onCancel)
}
internal object ReferenceDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ReferenceDashboardMethod.ID
    override val title = "Music reference dashboard"
    override val description = "Live key, scale and diatonic-chord reference."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) = ReferenceDashboardUi(context,onBack,onConfirmed,onCancel)
}

@Composable
private fun PracticeDashboardUi(context: CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit) {
    var bpm by rememberSaveable { mutableStateOf(context.action.settings["bpm"] ?: "100") }
    var beats by rememberSaveable { mutableStateOf(context.action.settings["beats_per_bar"] ?: "4") }
    var subdivision by rememberSaveable { mutableStateOf(context.action.settings["subdivision"] ?: "quarter") }
    var a4 by rememberSaveable { mutableStateOf(context.action.settings["reference_a4_hz"] ?: "440") }
    var exercise by rememberSaveable { mutableStateOf(context.action.settings["exercise"] ?: "") }
    var target by rememberSaveable { mutableStateOf(context.action.settings["target_bpm"] ?: "120") }
    var result by remember { mutableStateOf<ExecutionResult?>(null) }
    var values by remember { mutableStateOf<Map<String,String>>(emptyMap()) }
    var sessionStart by rememberSaveable { mutableStateOf(SystemClock.elapsedRealtime()) }
    var elapsed by rememberSaveable { mutableStateOf(0L) }
    LaunchedEffect(sessionStart) { while(true){ elapsed=(SystemClock.elapsedRealtime()-sessionStart)/1000; delay(1000) } }
    fun refresh(){
        val settings=mapOf("bpm" to bpm,"beats_per_bar" to beats,"subdivision" to subdivision,"reference_a4_hz" to a4,"exercise" to exercise,"target_bpm" to target)
        values=As100PracticeDashboardMethod.calculate(settings)
        result=dashboardExecution(As100PracticeDashboardMethod,context,values)
    }
    LaunchedEffect(bpm,beats,subdivision,a4,exercise,target){ refresh() }
    val keepLive=context.presentationMode==CapabilityPresentationMode.Dashboard || context.isNativePresetRun
    val scaffoldResult=if(keepLive)null else result
    CapabilityScreenScaffold(title="Practice dashboard",capabilityId=As100PracticeDashboardMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=scaffoldResult,resultPreview=scaffoldResult?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={refresh()},onConfirm={result?.let(onConfirmed)},onCancel=onCancel){
        Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("${MusicAlgorithms.formatDuration(elapsed.toInt())} practice",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("$bpm BPM · $beats/4 · ${subdivision.replace('_',' ')}");if(exercise.isNotBlank())Text(exercise)}}
            if(context.settingShouldBeShown("bpm"))OutlinedTextField(bpm,{bpm=it},label={Text("Tempo (BPM)")},modifier=Modifier.fillMaxWidth())
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={bpm=((bpm.toDoubleOrNull()?:100.0)-1).coerceAtLeast(20.0).toString()},modifier=Modifier.weight(1f)){Text("−1 BPM")};Button(onClick={bpm=((bpm.toDoubleOrNull()?:100.0)+1).coerceAtMost(400.0).toString()},modifier=Modifier.weight(1f)){Text("+1 BPM")}}
            if(context.settingShouldBeShown("exercise"))OutlinedTextField(exercise,{exercise=it},label={Text("Current exercise")},modifier=Modifier.fillMaxWidth())
            if(context.settingShouldBeShown("target_bpm"))OutlinedTextField(target,{target=it},label={Text("Target BPM")},modifier=Modifier.fillMaxWidth())
            if(context.settingShouldBeShown("reference_a4_hz"))OutlinedTextField(a4,{a4=it},label={Text("Reference A4 (Hz)")},modifier=Modifier.fillMaxWidth())
            Text("Live tuner: use the existing Acoustics → Instrument tuner capability (acoustic.tune).",style=MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick={sessionStart=SystemClock.elapsedRealtime();elapsed=0},modifier=Modifier.fillMaxWidth()){Text("Reset session timer")}
            if(keepLive && result!=null)Button(onClick={result?.let(onConfirmed)},modifier=Modifier.fillMaxWidth()){Text(if(context.isNativePresetRun)"Finish" else "Use this snapshot")}
        }
    }
}

@Composable
private fun PerformanceDashboardUi(context: CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    val androidContext=LocalContext.current
    val repository=remember{SetListRepository(androidContext)}
    val songs=remember{mutableStateListOf<SetListRepository.Song>().apply{addAll(repository.load())}}
    var setName by rememberSaveable{mutableStateOf(context.action.settings["set_name"]?:"Tonight's set")}
    var newTitle by rememberSaveable{mutableStateOf("")};var newDuration by rememberSaveable{mutableStateOf("3:30")};var newBpm by rememberSaveable{mutableStateOf("")};var newKey by rememberSaveable{mutableStateOf("")}
    var currentIndex by rememberSaveable{mutableIntStateOf(0)};var running by rememberSaveable{mutableStateOf(false)};var startedAt by rememberSaveable{mutableStateOf(0L)};var elapsed by rememberSaveable{mutableStateOf(0L)};var songStartedAt by rememberSaveable{mutableStateOf(0L)}
    var result by remember{mutableStateOf<ExecutionResult?>(null)};var values by remember{mutableStateOf<Map<String,String>>(emptyMap())}
    fun save(){repository.save(songs.toList())}
    fun snapshot(){
        val planned=songs.sumOf{it.durationSeconds+it.gapAfterSeconds};val completed=currentIndex.coerceAtMost(songs.size);val remaining=(planned-elapsed.toInt()).coerceAtLeast(0);val plannedElapsed=songs.take(completed).sumOf{it.durationSeconds+it.gapAfterSeconds};val variance=elapsed.toInt()-plannedElapsed
        val arr=JSONArray();songs.forEachIndexed{i,s->arr.put(JSONObject().put("index",i+1).put("title",s.title).put("duration_seconds",s.durationSeconds).put("bpm",s.bpm?:JSONObject.NULL).put("key",s.key).put("gap_after_seconds",s.gapAfterSeconds).put("actual_duration_seconds",s.actualDurationSeconds?:JSONObject.NULL))}
        values=As100PerformanceDashboardMethod.calculate(mapOf("set_name" to setName,"song_count" to songs.size.toString(),"planned_seconds" to planned.toString(),"completed_count" to completed.toString(),"elapsed_seconds" to elapsed.toString(),"remaining_seconds" to remaining.toString(),"variance_seconds" to variance.toString(),"songs_json" to arr.toString()))
        result=dashboardExecution(As100PerformanceDashboardMethod,context,values)
    }
    LaunchedEffect(running,startedAt){while(running){elapsed=(SystemClock.elapsedRealtime()-startedAt)/1000;snapshot();delay(1000)}}
    LaunchedEffect(songs.size,currentIndex,setName){snapshot()}
    val keepLive=context.presentationMode==CapabilityPresentationMode.Dashboard||context.isNativePresetRun;val scaffoldResult=if(keepLive)null else result
    CapabilityScreenScaffold(title="Performance / set list",capabilityId=As100PerformanceDashboardMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=scaffoldResult,resultPreview=scaffoldResult?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={snapshot()},onConfirm={result?.let(onConfirmed)},onCancel=onCancel){
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            OutlinedTextField(setName,{setName=it},label={Text("Set name")},modifier=Modifier.fillMaxWidth())
            val planned=songs.sumOf{it.durationSeconds+it.gapAfterSeconds};val remaining=(planned-elapsed.toInt()).coerceAtLeast(0)
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("${MusicAlgorithms.formatDuration(elapsed.toInt())} elapsed",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("${MusicAlgorithms.formatDuration(remaining)} remaining · ${MusicAlgorithms.formatDuration(planned)} planned");Text(if(currentIndex<songs.size)"NOW: ${songs[currentIndex].title}" else "Set complete")}}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={if(!running){running=true;startedAt=SystemClock.elapsedRealtime()-elapsed*1000;songStartedAt=SystemClock.elapsedRealtime()}else running=false},modifier=Modifier.weight(1f)){Text(if(running)"PAUSE" else "START")};Button(enabled=songs.isNotEmpty()&&currentIndex<songs.size,onClick={val now=SystemClock.elapsedRealtime();val actual=if(songStartedAt>0)((now-songStartedAt)/1000).toInt() else null;if(actual!=null){songs[currentIndex]=songs[currentIndex].copy(actualDurationSeconds=actual)};currentIndex=(currentIndex+1).coerceAtMost(songs.size);songStartedAt=now;save();snapshot()},modifier=Modifier.weight(1f)){Text("NEXT SONG")}}
            LazyColumn(modifier=Modifier.height(220.dp)){itemsIndexed(songs){index,song->Card(Modifier.fillMaxWidth().padding(vertical=3.dp)){Row(Modifier.padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Text(if(index<currentIndex)"✓" else if(index==currentIndex)"▶" else "${index+1}");Column(Modifier.weight(1f)){Text(song.title,fontWeight=if(index==currentIndex)FontWeight.Bold else FontWeight.Normal);Text("${MusicAlgorithms.formatDuration(song.durationSeconds)}${song.bpm?.let{" · ${"%.0f".format(it)} BPM"}.orEmpty()}${if(song.key.isNotBlank())" · ${song.key}" else ""}",style=MaterialTheme.typography.bodySmall)};OutlinedButton(onClick={songs.removeAt(index);if(currentIndex>songs.size)currentIndex=songs.size;save();snapshot()}){Text("×")}}}}}
            Text("Add song",style=MaterialTheme.typography.titleSmall);OutlinedTextField(newTitle,{newTitle=it},label={Text("Title")},modifier=Modifier.fillMaxWidth());Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(newDuration,{newDuration=it},label={Text("Duration")},modifier=Modifier.weight(1f));OutlinedTextField(newBpm,{newBpm=it},label={Text("BPM")},modifier=Modifier.weight(1f));OutlinedTextField(newKey,{newKey=it},label={Text("Key")},modifier=Modifier.weight(1f))}
            OutlinedButton(onClick={val seconds=MusicAlgorithms.parseDuration(newDuration);if(newTitle.isNotBlank()&&seconds!=null){songs.add(SetListRepository.Song(UUID.randomUUID().toString(),newTitle,seconds,newBpm.toDoubleOrNull(),newKey,"",20));newTitle="";save();snapshot()}},modifier=Modifier.fillMaxWidth()){Text("Add to set")}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={currentIndex=0;elapsed=0;running=false;startedAt=0;songStartedAt=0;snapshot()},modifier=Modifier.weight(1f)){Text("Reset run")};OutlinedButton(onClick={songs.clear();repository.clear();currentIndex=0;elapsed=0;snapshot()},modifier=Modifier.weight(1f)){Text("Clear set")}}
            if(keepLive&&result!=null)Button(onClick={result?.let(onConfirmed)},modifier=Modifier.fillMaxWidth()){Text(if(context.isNativePresetRun)"Finish" else "Use this snapshot")}
        }
    }
}

@Composable
private fun ReferenceDashboardUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    var root by rememberSaveable{mutableStateOf(context.action.settings["root"]?:"C")};var scale by rememberSaveable{mutableStateOf(context.action.settings["scale"]?:"major")};var flats by rememberSaveable{mutableStateOf(context.action.settings["prefer_flats"]?:"false")};var result by remember{mutableStateOf<ExecutionResult?>(null)};var values by remember{mutableStateOf<Map<String,String>>(emptyMap())}
    fun refresh(){values=As100ReferenceDashboardMethod.calculate(mapOf("root" to root,"scale" to scale,"prefer_flats" to flats));result=dashboardExecution(As100ReferenceDashboardMethod,context,values)}
    LaunchedEffect(root,scale,flats){refresh()};val keepLive=context.presentationMode==CapabilityPresentationMode.Dashboard||context.isNativePresetRun;val scaffoldResult=if(keepLive)null else result
    CapabilityScreenScaffold(title="Music reference dashboard",capabilityId=As100ReferenceDashboardMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=scaffoldResult,resultPreview=scaffoldResult?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={refresh()},onConfirm={result?.let(onConfirmed)},onCancel=onCancel){Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("$root ${scale.replace('_',' ')}",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(values[As100ReferenceDashboardMethod.fields.field("notes")].orEmpty(),style=MaterialTheme.typography.titleLarge);val triads=values[As100ReferenceDashboardMethod.fields.field("triads")].orEmpty();if(triads.isNotBlank()){Spacer(Modifier.height(8.dp));Text("Diatonic triads",fontWeight=FontWeight.Bold);Text(triads)}}}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={val pc=MusicAlgorithms.parsePitchClass(root)?:0;root=MusicAlgorithms.pitchClassName(pc-1,flats.toBoolean())},modifier=Modifier.weight(1f)){Text("← semitone")};Button(onClick={val pc=MusicAlgorithms.parsePitchClass(root)?:0;root=MusicAlgorithms.pitchClassName(pc+1,flats.toBoolean())},modifier=Modifier.weight(1f)){Text("semitone →")}}
        OutlinedTextField(root,{root=it},label={Text("Root")},modifier=Modifier.fillMaxWidth());OutlinedTextField(scale,{scale=it},label={Text("Scale")},modifier=Modifier.fillMaxWidth());Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={flats="false"},modifier=Modifier.weight(1f)){Text("Sharps")};OutlinedButton(onClick={flats="true"},modifier=Modifier.weight(1f)){Text("Flats")}}
        if(keepLive&&result!=null)Button(onClick={result?.let(onConfirmed)},modifier=Modifier.fillMaxWidth()){Text(if(context.isNativePresetRun)"Finish" else "Use this snapshot")}
    }}
}

private fun dashboardExecution(method:MusicPureMethod,context:CapabilityScreenContext,values:Map<String,String>):ExecutionResult{val request=method.request(action=method.id,context=context.request.invocationContext.asMap(method.id)+context.action.settings+values,signals=emptyList(),inputs=emptyList());return method.result(request,values,context.request.invocationContext)}
