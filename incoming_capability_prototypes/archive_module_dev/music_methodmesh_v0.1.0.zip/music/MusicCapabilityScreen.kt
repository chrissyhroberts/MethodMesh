package com.example.methodmesh.modules.music

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.delay
import org.json.JSONObject

internal data class InputSpec(val key: String, val label: String, val default: String, val choices: List<String> = emptyList(), val hint: String = "")

private val subdivisions = listOf("whole", "half", "quarter", "eighth", "sixteenth", "dotted_quarter", "dotted_eighth", "quarter_triplet", "eighth_triplet")
private val chordQualities = listOf("", "m", "dim", "aug", "sus2", "sus4", "6", "m6", "7", "maj7", "m7", "m7b5", "add9", "9", "maj9", "m9")

internal object TapTempoCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TapTempoMethod.ID
    override val title = "Tap tempo"
    override val description = "Tap the large pad repeatedly to estimate tempo and timing stability."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        TapTempoUi(context, onBack, onConfirmed, onCancel)
}

internal object MetronomeCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MetronomeMethod.ID
    override val title = "Metronome"
    override val description = "Audio, visual and optional haptic metronome."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        MetronomeUi(context, onBack, onConfirmed, onCancel)
}

internal abstract class SimpleMusicScreen(
    private val method: MusicPureMethod,
    override val title: String,
    override val description: String,
    private val inputs: List<InputSpec>
) : CapabilityScreenSpec {
    override val capabilityId = method.id
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) =
        SimpleMusicUi(method, title, context, inputs, onBack, onConfirmed, onCancel)
}

internal object NoteFrequencyCapabilityScreen : SimpleMusicScreen(As100NoteFrequencyMethod, "Note ↔ frequency", "Convert note names and frequencies.", listOf(
    InputSpec("mode","Conversion","note_to_frequency", listOf("note_to_frequency","frequency_to_note")), InputSpec("note","Note","A4"), InputSpec("frequency_hz","Frequency (Hz)","440"), InputSpec("reference_a4_hz","Reference A4 (Hz)","440"), InputSpec("prefer_flats","Prefer flats","false", listOf("false","true"))))
internal object TransposeCapabilityScreen : SimpleMusicScreen(As100TransposeMethod, "Transpose", "Transpose notes or chord symbols.", listOf(
    InputSpec("input","Notes / chords","C G Am F"), InputSpec("input_type","Input type","chords", listOf("chords","notes")), InputSpec("semitones","Semitones","0"), InputSpec("from_key","From key (optional)",""), InputSpec("to_key","To key (optional)",""), InputSpec("prefer_flats","Prefer flats","false", listOf("false","true"))))
internal object IntervalCapabilityScreen : SimpleMusicScreen(As100IntervalMethod, "Interval identifier", "Identify the interval between two notes.", listOf(InputSpec("note_a","First note","C4"), InputSpec("note_b","Second note","G4")))
internal object ChordCapabilityScreen : SimpleMusicScreen(As100ChordMethod, "Chord builder / identifier", "Build chord tones or identify exact chord matches.", listOf(
    InputSpec("mode","Mode","build", listOf("build","identify")), InputSpec("root","Root","C"), InputSpec("quality","Quality","", chordQualities), InputSpec("notes","Notes","C E G"), InputSpec("prefer_flats","Prefer flats","false", listOf("false","true"))))
internal object ChordGuideCapabilityScreen : SimpleMusicScreen(As100ChordGuideMethod, "Chord / tab guide", "Show compact guitar chord fingering.", listOf(InputSpec("instrument","Instrument","guitar", listOf("guitar")), InputSpec("chord","Chord","C")))
internal object TempoConvertCapabilityScreen : SimpleMusicScreen(As100TempoConvertMethod, "Tempo converter", "Convert BPM to note/subdivision durations.", listOf(InputSpec("bpm","Tempo (BPM)","120"), InputSpec("subdivision","Subdivision","quarter", subdivisions)))
internal object DelayTimeCapabilityScreen : SimpleMusicScreen(As100DelayTimeMethod, "Delay-time calculator", "Calculate tempo-synchronised effect delay.", listOf(InputSpec("bpm","Tempo (BPM)","120"), InputSpec("subdivision","Subdivision","dotted_eighth", subdivisions)))
internal object TemperamentCapabilityScreen : SimpleMusicScreen(As100TemperamentMethod, "Temperament calculator", "Calculate EDO step size and frequency.", listOf(InputSpec("divisions","Divisions of octave","12"), InputSpec("step","Step","0"), InputSpec("reference_hz","Reference frequency (Hz)","440"), InputSpec("reference_step","Reference step","0")))
internal object PolyrhythmCapabilityScreen : SimpleMusicScreen(As100PolyrhythmMethod, "Polyrhythm", "Generate pulse positions for an A:B rhythm.", listOf(InputSpec("ratio_a","A pulses","3"), InputSpec("ratio_b","B pulses","2")))
internal object TempoTrainerCapabilityScreen : SimpleMusicScreen(As100TempoTrainerMethod, "Tempo trainer", "Build a stepped practice tempo progression.", listOf(InputSpec("start_bpm","Start BPM","80"), InputSpec("target_bpm","Target BPM","120"), InputSpec("increment_bpm","Increment BPM","2"), InputSpec("bars_per_step","Bars per step","4")))
internal object HarmonicsCapabilityScreen : SimpleMusicScreen(As100HarmonicsMethod, "Harmonic series", "Explore harmonics and nearest tempered pitches.", listOf(InputSpec("fundamental_hz","Fundamental (Hz)","110"), InputSpec("count","Harmonic count","8"), InputSpec("reference_a4_hz","Reference A4 (Hz)","440"), InputSpec("prefer_flats","Prefer flats","false", listOf("false","true"))))
internal object SetListTimingCapabilityScreen : SimpleMusicScreen(As100SetListTimingMethod, "Set-list timing", "Add song durations and gaps.", listOf(InputSpec("durations","Song durations","3:30,4:00,3:45", hint="Comma-separated mm:ss"), InputSpec("gaps","Gaps","0:20,0:20"), InputSpec("start_time","Start time (optional)","")))
internal object MusicReferenceCapabilityScreen : SimpleMusicScreen(As100MusicReferenceMethod, "Music reference", "Scale notes and diatonic chords for a key.", listOf(InputSpec("root","Root","C"), InputSpec("scale","Scale","major", listOf("major","natural_minor","harmonic_minor","melodic_minor","major_pentatonic","minor_pentatonic","blues","dorian","mixolydian")), InputSpec("prefer_flats","Prefer flats","false", listOf("false","true"))))

@Composable
private fun SimpleMusicUi(method: MusicPureMethod, title: String, context: CapabilityScreenContext, specs: List<InputSpec>, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
    val state = remember(context.action.canonicalId) { mutableStateMapOf<String, String>().apply { specs.forEach { spec -> put(spec.key, context.action.settings[spec.key] ?: context.action.settings["input_${spec.key}"] ?: spec.default) } } }
    var resultJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
    val restored = resultJson?.let { json ->
        val o = JSONObject(json); val values = method.fields.outputs.associateWith { o.optString(it, "") }
        executionFor(method, context, values)
    }
    fun run() {
        val values = method.calculate(state.toMap())
        resultJson = JSONObject(values).toString()
    }
    LaunchedEffect(context.startsImmediately) { if (context.startsImmediately && resultJson == null) run() }
    CapabilityScreenScaffold(
        title = title, capabilityId = method.id, context = context, canGoBack = context.stepNumber > 1,
        capturedResult = restored, resultPreview = restored?.let { OutputFormatter.fields(it, false) }.orEmpty(),
        onBack = onBack, onRetry = { resultJson = null }, onConfirm = { restored?.let(onConfirmed) }, onCancel = onCancel
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            specs.forEach { spec ->
                if (context.settingShouldBeShown(spec.key)) {
                    if (spec.choices.isNotEmpty()) ChoiceInput(spec.label, state[spec.key].orEmpty(), spec.choices) { state[spec.key] = it }
                    else OutlinedTextField(value = state[spec.key].orEmpty(), onValueChange = { state[spec.key] = it }, label = { Text(spec.label) }, supportingText = if (spec.hint.isNotBlank()) ({ Text(spec.hint) }) else null, modifier = Modifier.fillMaxWidth())
                }
            }
            Button(onClick = ::run, modifier = Modifier.fillMaxWidth()) { Text("Calculate") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable private fun ChoiceInput(label: String, selected: String, choices: List<String>, onSelected: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            choices.forEach { value -> if (selected == value) Button(onClick = { onSelected(value) }) { Text(if (value.isBlank()) "major" else value.replace('_',' ')) } else OutlinedButton(onClick = { onSelected(value) }) { Text(if (value.isBlank()) "major" else value.replace('_',' ')) } }
        }
    }
}

@Composable
private fun TapTempoUi(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
    var tapsCsv by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var resultJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
    val taps = tapsCsv.split(',').mapNotNull { it.toLongOrNull() }
    fun currentValues(): Map<String, String>? = if (taps.size >= 2) As100TapTempoMethod.calculate(mapOf("tap_times_ms" to taps.joinToString(","))) else null
    val live = currentValues()
    val restored = resultJson?.let { json -> val o = JSONObject(json); executionFor(As100TapTempoMethod, context, As100TapTempoMethod.fields.outputs.associateWith { o.optString(it, "") }) }
    LaunchedEffect(context.startsImmediately) {
        val supplied = context.action.settings["tap_intervals_ms"] ?: context.action.settings["input_tap_intervals_ms"]
        if (context.startsImmediately && !supplied.isNullOrBlank() && resultJson == null) resultJson = JSONObject(As100TapTempoMethod.calculate(mapOf("tap_intervals_ms" to supplied))).toString()
    }
    CapabilityScreenScaffold(title = "Tap tempo", capabilityId = As100TapTempoMethod.ID, context = context, canGoBack = context.stepNumber > 1, capturedResult = restored, resultPreview = restored?.let { OutputFormatter.fields(it,false) }.orEmpty(), onBack = onBack, onRetry = { resultJson = null; tapsCsv = "" }, onConfirm = { restored?.let(onConfirmed) }, onCancel = onCancel) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text(live?.get(As100TapTempoMethod.fields.field("bpm"))?.let { "$it BPM" } ?: "— BPM", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                Text(if (taps.size < 2) "Tap at least twice" else "${taps.size} taps · CV ${live?.get(As100TapTempoMethod.fields.field("cv")).orEmpty()}")
            } }
            Button(onClick = { val now = android.os.SystemClock.elapsedRealtime(); tapsCsv = (taps + now).takeLast(16).joinToString(",") }, modifier = Modifier.fillMaxWidth().height(180.dp)) { Text("TAP", style = MaterialTheme.typography.displayMedium) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { tapsCsv = "" }, modifier = Modifier.weight(1f)) { Text("Reset") }
                Button(enabled = live != null, onClick = { live?.let { resultJson = JSONObject(it).toString() } }, modifier = Modifier.weight(1f)) { Text("Use tempo") }
            }
        }
    }
}

@Suppress("DEPRECATION")
@Composable
private fun MetronomeUi(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
    val androidContext = LocalContext.current
    var bpm by rememberSaveable { mutableStateOf(context.action.settings["bpm"] ?: "120") }
    var beats by rememberSaveable { mutableStateOf(context.action.settings["beats_per_bar"] ?: "4") }
    var subdivision by rememberSaveable { mutableStateOf(context.action.settings["subdivision"] ?: "quarter") }
    var running by rememberSaveable { mutableStateOf(false) }
    var pulse by remember { mutableStateOf(false) }
    var beatIndex by rememberSaveable { mutableStateOf(0) }
    var resultJson by rememberSaveable { mutableStateOf<String?>(null) }
    val tone = remember { ToneGenerator(AudioManager.STREAM_MUSIC, 75) }
    val vibrator = remember { if (Build.VERSION.SDK_INT >= 31) (androidContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator else androidContext.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator }
    DisposableEffect(Unit) { onDispose { tone.release() } }
    val restored = resultJson?.let { json -> val o=JSONObject(json); executionFor(As100MetronomeMethod, context, As100MetronomeMethod.fields.outputs.associateWith { o.optString(it,"") }) }
    LaunchedEffect(running, bpm, subdivision, beats) {
        while (running) {
            pulse = true; beatIndex = (beatIndex % (beats.toIntOrNull() ?: 4).coerceAtLeast(1)) + 1
            tone.startTone(if (beatIndex == 1) ToneGenerator.TONE_PROP_BEEP2 else ToneGenerator.TONE_PROP_BEEP, 35)
            val haptic = context.action.settings["haptic_enabled"]?.toBoolean() ?: false
            if (haptic && vibrator.hasVibrator()) { if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(if (beatIndex==1) 45 else 22, VibrationEffect.DEFAULT_AMPLITUDE)) else vibrator.vibrate(if (beatIndex==1) 45 else 22) }
            delay(55); pulse = false
            val interval = runCatching { MusicAlgorithms.delayMs(bpm.toDouble(), subdivision).toLong() }.getOrDefault(500L)
            delay((interval - 55).coerceAtLeast(10))
        }
    }
    LaunchedEffect(context.startsImmediately) { if (context.startsImmediately && resultJson == null) resultJson = JSONObject(As100MetronomeMethod.calculate(mapOf("bpm" to bpm,"beats_per_bar" to beats,"subdivision" to subdivision,"accent_pattern" to "1"))).toString() }
    CapabilityScreenScaffold(title="Metronome", capabilityId=As100MetronomeMethod.ID, context=context, canGoBack=context.stepNumber>1, capturedResult=restored, resultPreview=restored?.let{OutputFormatter.fields(it,false)}.orEmpty(), onBack=onBack, onRetry={resultJson=null}, onConfirm={restored?.let(onConfirmed)}, onCancel={running=false;onCancel()}) {
        Surface(tonalElevation = if (pulse) 12.dp else 1.dp) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Beat $beatIndex", style=MaterialTheme.typography.displaySmall, textAlign=TextAlign.Center, modifier=Modifier.fillMaxWidth())
            if (context.settingShouldBeShown("bpm")) OutlinedTextField(value=bpm,onValueChange={bpm=it},label={Text("BPM")},modifier=Modifier.fillMaxWidth())
            if (context.settingShouldBeShown("beats_per_bar")) OutlinedTextField(value=beats,onValueChange={beats=it},label={Text("Beats per bar")},modifier=Modifier.fillMaxWidth())
            if (context.settingShouldBeShown("subdivision")) ChoiceInput("Subdivision",subdivision,subdivisions){subdivision=it}
            Button(onClick={running=!running},modifier=Modifier.fillMaxWidth().height(72.dp)){Text(if(running)"STOP" else "START")}
            OutlinedButton(onClick={ resultJson=JSONObject(As100MetronomeMethod.calculate(mapOf("bpm" to bpm,"beats_per_bar" to beats,"subdivision" to subdivision,"accent_pattern" to "1"))).toString() },modifier=Modifier.fillMaxWidth()){Text("Use these settings")}
        } }
    }
}

private fun executionFor(method: MusicPureMethod, context: CapabilityScreenContext, values: Map<String, String>): ExecutionResult {
    val request = method.request(action = method.id, context = context.request.invocationContext.asMap(method.id) + context.action.settings + values, signals = emptyList(), inputs = emptyList())
    return method.result(request, values, context.request.invocationContext)
}
