package com.example.methodmesh.modules.music

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class SetListRepository(context: Context) {
    data class Song(
        val id: String,
        val title: String,
        val durationSeconds: Int,
        val bpm: Double?,
        val key: String,
        val notes: String,
        val gapAfterSeconds: Int,
        val actualDurationSeconds: Int? = null
    )

    private val prefs = context.applicationContext.getSharedPreferences("methodmesh_music_setlist", Context.MODE_PRIVATE)

    fun load(): List<Song> {
        val raw = prefs.getString("songs", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(Song(
                        id = o.optString("id", i.toString()),
                        title = o.optString("title", "Song ${i + 1}"),
                        durationSeconds = o.optInt("durationSeconds", 0),
                        bpm = if (o.has("bpm") && !o.isNull("bpm")) o.optDouble("bpm") else null,
                        key = o.optString("key", ""),
                        notes = o.optString("notes", ""),
                        gapAfterSeconds = o.optInt("gapAfterSeconds", 0),
                        actualDurationSeconds = if (o.has("actualDurationSeconds") && !o.isNull("actualDurationSeconds")) o.optInt("actualDurationSeconds") else null
                    ))
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(songs: List<Song>) {
        val array = JSONArray()
        songs.forEach { song ->
            array.put(JSONObject().apply {
                put("id", song.id); put("title", song.title); put("durationSeconds", song.durationSeconds)
                if (song.bpm != null) put("bpm", song.bpm) else put("bpm", JSONObject.NULL)
                put("key", song.key); put("notes", song.notes); put("gapAfterSeconds", song.gapAfterSeconds)
                if (song.actualDurationSeconds != null) put("actualDurationSeconds", song.actualDurationSeconds) else put("actualDurationSeconds", JSONObject.NULL)
            })
        }
        prefs.edit().putString("songs", array.toString()).apply()
    }

    fun clear() = prefs.edit().remove("songs").apply()
}
