# Aviation v0.1 build / validation report

## Validation completed in this environment

The following pure Kotlin files compile together with `kotlinc`:

- `AviationCalculations.kt`
- `AviationCsv.kt`
- `AviationAirfieldRepository.kt`

Focused smoke checks passed for:

- direct headwind calculation;
- 90-degree crosswind calculation and left/right source indication;
- direct tailwind calculation;
- standard sea-level pressure/density-altitude baseline;
- E6B time from distance/speed;
- E6B range from fuel/burn/speed;
- great-circle distance and initial bearing;
- CSV quoted-comma parsing;
- cached airfield search using a synthetic OurAirports-format catalogue;
- nearest-airfield ordering.

`AviationMethod.kt` and `AviationModule.kt` also compile against local stubs matching the current public MethodMesh method/module/settings contracts fetched from the live repository. This is a syntax/contract-shape check, not a substitute for the Android Gradle build.

The Compose screen source was passed through the Kotlin compiler without Android/Compose dependencies. The expected unresolved dependency errors were produced, with no Kotlin parser/syntax errors detected.

## Validation not possible here

The execution environment cannot clone the GitHub repository over the network, and the connected GitHub integration allowed reads but returned HTTP 403 when asked to create a feature branch. Therefore this environment could not run the canonical Android validation command:

```bash
./gradlew :app:assembleDebug
```

It also could not run the capabilities on an Android device/emulator to verify:

- runtime location permission flow;
- Fused Location Provider behaviour;
- first-run OurAirports catalogue download;
- Compose layout on small/large screens;
- orientation restoration in a real activity;
- ODK Collect external-app round trips.

## Required integration checks before Production

1. Copy the `aviation/` folder to `app/src/main/java/com/example/methodmesh/modules/aviation/`.
2. Run `./gradlew :app:assembleDebug`.
3. Run/add unit tests for `AviationCalculations`, `AviationCsv` and `AviationAirfieldRepository` in the real test tree.
4. On a device, test nearby-airfield lookup with location denied, coarse permission and fine permission.
5. Test first online run, cached offline run, stale-cache fallback and force refresh.
6. Import `docs/example_odk_Aviation.xlsx` into ODK Central/Collect and exercise all four external-app groups.
7. Rotate the device after a result is captured and confirm that result content survives.
8. Confirm native share surfaces the useful `*_value` result rather than the full audit JSON.
9. Keep the module marked Development until these checks pass.
