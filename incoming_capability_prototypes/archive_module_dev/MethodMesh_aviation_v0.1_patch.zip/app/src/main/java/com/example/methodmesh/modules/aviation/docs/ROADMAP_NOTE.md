# Suggested `000_Roadmap.md` note

## Aviation capability pack — Development

- Added initial self-contained `aviation` module prototype.
- `aviation.airfield.nearby`: GPS/supplied-coordinate nearby aerodrome lookup with locally cached public-domain OurAirports catalogue; coordinates remain on-device.
- `aviation.runway.wind`: offline headwind/tailwind/crosswind components, optional gust.
- `aviation.altitude.calculate`: pressure altitude + planning density-altitude approximation; can consume nearest-airfield elevation.
- `aviation.e6b.calculate`: time/distance/speed/fuel/endurance/range calculations.
- Native input UX uses dropdowns, multi-choice/check boxes and numeric controls rather than free-text enumerations.
- Added module-owned docs and ODK/XLSForm example.
- Open work before Production: Android Gradle/device validation, ODK round-trip validation, real-location permission testing, catalogue refresh/offline tests.
- Later aviation tranche: METAR/TAF, SIGMET/route warnings, provider-specific NOTAM integration, runway/frequency details, route planning, aircraft profiles/weight & balance, flight tracking/logbook and optional ADS-B reference traffic.
