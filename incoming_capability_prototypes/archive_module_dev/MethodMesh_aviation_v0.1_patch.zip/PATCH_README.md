# MethodMesh aviation capability patch

Drop-in prototype for `chrissyhroberts/MethodMesh`, status **Development**.

## Contents

- `app/src/main/java/com/example/methodmesh/modules/aviation/`
  - module, methods, native Compose screens, calculations, CSV parser, airfield repository
  - module-owned README, build report, roadmap note and ODK XLSForm example
- `app/src/test/java/com/example/methodmesh/modules/aviation/`
  - pure calculation and cached-airfield repository tests

## Install

Copy the `app/` directory over the root of a MethodMesh checkout. No central module registration or manifest permission change should be required against the repository state inspected on 2026-09-04: module discovery is automatic, location/internet permissions already exist, and Play Services Location is already a dependency.

Then run:

```bash
./gradlew :app:testDebugUnitTest --tests 'com.example.methodmesh.modules.aviation.*'
./gradlew :app:assembleDebug
```

See `app/src/main/java/com/example/methodmesh/modules/aviation/docs/BUILD_REPORT.md` for what was and was not validated in the construction environment.
