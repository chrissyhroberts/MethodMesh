package com.example.methodmesh.modules.time_tools.stopwatch

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.methodmesh.modules.time_tools.timing.StopwatchViewModel
import com.example.methodmesh.modules.time_tools.timing.TimeFormatting
import com.example.methodmesh.modules.time_tools.timing.TimerStatus
import kotlinx.coroutines.delay

@Composable
fun StopwatchCapabilityScreen(
    vm: StopwatchViewModel = viewModel(),
    onCompleted: ((String) -> Unit)? = null
) {
    val state by vm.state.collectAsState()
    var elapsed by remember { mutableLongStateOf(0L) }
    LaunchedEffect(state.status) {
        while (state.status == TimerStatus.Running) {
            elapsed = vm.elapsedMs()
            delay(50L)
        }
        elapsed = vm.elapsedMs()
        if (state.status == TimerStatus.Completed) onCompleted?.invoke(TimeFormatting.duration(elapsed, true))
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(TimeFormatting.duration(elapsed, true), fontSize = 56.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 20.dp)) {
            when (state.status) {
                TimerStatus.Configured -> Button(onClick = vm::start) { Text("START") }
                TimerStatus.Running -> {
                    Button(onClick = vm::lap) { Text("LAP") }
                    Button(onClick = vm::pause) { Text("PAUSE") }
                    Button(onClick = vm::stop) { Text("STOP") }
                }
                TimerStatus.Paused -> {
                    Button(onClick = vm::resume) { Text("RESUME") }
                    Button(onClick = vm::stop) { Text("STOP") }
                }
                else -> Unit
            }
        }
        state.laps.takeLast(8).forEach { lap ->
            Text("Lap ${lap.index}   ${TimeFormatting.duration(lap.lapDurationMs, true)}   ${TimeFormatting.duration(lap.totalDurationMs, true)}")
        }
    }
}
