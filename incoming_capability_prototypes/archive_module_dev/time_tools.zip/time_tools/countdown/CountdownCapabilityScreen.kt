package com.example.methodmesh.modules.time_tools.countdown

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.methodmesh.modules.time_tools.timing.CountdownViewModel
import com.example.methodmesh.modules.time_tools.timing.TimeFormatting
import com.example.methodmesh.modules.time_tools.timing.TimerStatus

@Composable
fun CountdownCapabilityScreen(
    initialDurationMs: Long = 5 * 60_000L,
    onCompleted: ((String) -> Unit)? = null,
    vm: CountdownViewModel = viewModel()
) {
    val state by vm.state.collectAsState()
    LaunchedEffect(Unit) {
        if (state == null) vm.configure(initialDurationMs)
    }
    val current = state
    val remaining = vm.remainingMs()

    LaunchedEffect(current?.status) {
        if (current?.status == TimerStatus.Completed) {
            onCompleted?.invoke(TimeFormatting.duration(current.finalElapsedMs ?: current.requestedDurationMs))
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(TimeFormatting.duration(remaining), fontSize = 56.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 20.dp)) {
            Button(onClick = { vm.addTime(-60_000L) }, enabled = current?.status is TimerStatus.Running || current?.status is TimerStatus.Paused) { Text("−1 min") }
            Button(onClick = { vm.addTime(60_000L) }, enabled = current?.status is TimerStatus.Running || current?.status is TimerStatus.Paused) { Text("+1 min") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 12.dp)) {
            when (current?.status) {
                TimerStatus.Configured -> Button(onClick = vm::start) { Text("START") }
                TimerStatus.Running -> Button(onClick = vm::pause) { Text("PAUSE") }
                TimerStatus.Paused -> Button(onClick = vm::resume) { Text("RESUME") }
                else -> Unit
            }
            if (current?.status is TimerStatus.Running || current?.status is TimerStatus.Paused) {
                Button(onClick = vm::cancel) { Text("CANCEL") }
            }
        }
    }
}
