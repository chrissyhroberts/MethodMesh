package com.example.methodmesh.modules.time_tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TimeToolsDashboardScreen(onLaunchMethod: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Time Tools")
        Button(onClick = { onLaunchMethod(TimeToolsContract.COUNTDOWN) }) { Text("Timer") }
        Button(onClick = { onLaunchMethod(TimeToolsContract.STOPWATCH) }) { Text("Stopwatch") }
        Button(onClick = { onLaunchMethod(TimeToolsContract.INTERVAL) }) { Text("Intervals") }
        Button(onClick = { onLaunchMethod(TimeToolsContract.UNTIL) }) { Text("Until…") }
        Button(onClick = { onLaunchMethod(TimeToolsContract.ELAPSED) }) { Text("Elapsed time") }
        Button(onClick = { onLaunchMethod(TimeToolsContract.DURATION_CALCULATE) }) { Text("Duration calculator") }
    }
}
