package com.example.methodmesh.modules.time_tools.timing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private class FakeClock(var time: Long = 0L) : MonotonicClock {
    override fun nowMs(): Long = time
}

class TimerEngineTest {
    @Test fun countdownUsesMonotonicTime() {
        val clock = FakeClock(1000)
        val engine = TimerEngine(clock)
        var timer = engine.start(engine.newCountdown(10_000))
        clock.time = 4_000
        assertEquals(3_000, engine.elapsedMs(timer))
        assertEquals(7_000, engine.remainingMs(timer))
        clock.time = 11_000
        timer = engine.refresh(timer)
        assertTrue(timer.status == TimerStatus.Completed)
    }

    @Test fun pauseIsExcluded() {
        val clock = FakeClock(0)
        val engine = TimerEngine(clock)
        var timer = engine.start(engine.newCountdown(10_000))
        clock.time = 2_000
        timer = engine.pause(timer)
        clock.time = 7_000
        timer = engine.resume(timer)
        clock.time = 9_000
        assertEquals(4_000, engine.elapsedMs(timer))
    }

    @Test fun intervalFindsCorrectPhase() {
        val engine = TimerEngine(FakeClock())
        val program = IntervalProgram(listOf(IntervalPhase("A", 1000), IntervalPhase("B", 2000)), cycles = 2)
        val p = engine.intervalPosition(program, 3500)
        assertEquals(1, p.cycleIndex)
        assertEquals(0, p.phaseIndex)
        assertEquals(500, p.elapsedInPhaseMs)
    }
}
