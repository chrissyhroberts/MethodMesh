package com.example.methodmesh.modules.time_tools.timing

import org.json.JSONArray
import org.json.JSONObject
import java.time.Duration
import java.time.Instant

object TimeResultPayloads {
    fun countdown(state: MonotonicTimerState, elapsedMs: Long): Map<String, Any?> {
        val formatted = TimeFormatting.duration(elapsedMs)
        return linkedMapOf(
            "formatted_duration" to formatted,
            "duration_ms" to elapsedMs,
            "requested_duration_ms" to state.requestedDurationMs,
            "actual_elapsed_ms" to elapsedMs,
            "started_at" to state.startedAt?.toString(),
            "completed_at" to state.completedAt?.toString(),
            "completion_status" to state.status.javaClass.simpleName.lowercase()
        )
    }

    fun stopwatch(state: StopwatchState, elapsedMs: Long): Map<String, Any?> {
        val laps = JSONArray().apply {
            state.laps.forEach { lap ->
                put(JSONObject().apply {
                    put("index", lap.index)
                    put("lap_duration_ms", lap.lapDurationMs)
                    put("total_duration_ms", lap.totalDurationMs)
                    put("lap_formatted", TimeFormatting.duration(lap.lapDurationMs, true))
                    put("total_formatted", TimeFormatting.duration(lap.totalDurationMs, true))
                })
            }
        }
        return linkedMapOf(
            "formatted_duration" to TimeFormatting.duration(elapsedMs, true),
            "duration_ms" to elapsedMs,
            "lap_count" to state.laps.size,
            "laps_json" to laps.toString(),
            "started_at" to state.startedAt?.toString(),
            "completed_at" to state.completedAt?.toString(),
            "completion_status" to state.status.javaClass.simpleName.lowercase()
        )
    }

    fun elapsed(start: Instant, end: Instant): Map<String, Any?> {
        val duration = Duration.between(start, end)
        return linkedMapOf(
            "formatted_duration" to TimeFormatting.duration(duration.toMillis()),
            "duration_ms" to duration.toMillis(),
            "start_timestamp" to start.toString(),
            "end_timestamp" to end.toString()
        )
    }

    fun fullJson(core: Map<String, Any?>, methodId: String): String = JSONObject().apply {
        put("schema", "methodmesh.time_tools.v1")
        put("method_id", methodId)
        put("generated_at", Instant.now().toString())
        core.forEach { (key, value) -> put(key, value) }
    }.toString()
}
