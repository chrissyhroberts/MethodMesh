package com.example.methodmesh.modules.time_tools.timing

import android.os.SystemClock
import java.time.Clock
import java.time.Instant

interface MonotonicClock {
    fun nowMs(): Long
}

object AndroidMonotonicClock : MonotonicClock {
    override fun nowMs(): Long = SystemClock.elapsedRealtime()
}

class WallClock(private val clock: Clock = Clock.systemUTC()) {
    fun now(): Instant = clock.instant()
}
