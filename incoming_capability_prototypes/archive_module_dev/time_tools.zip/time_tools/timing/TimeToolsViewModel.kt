package com.example.methodmesh.modules.time_tools.timing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class CountdownViewModel(
    private val engine: TimerEngine = TimerEngine()
) : ViewModel() {
    private val _state = MutableStateFlow<MonotonicTimerState?>(null)
    val state: StateFlow<MonotonicTimerState?> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            while (isActive) {
                _state.value?.let { current ->
                    val refreshed = engine.refresh(current)
                    if (refreshed != current) _state.value = refreshed
                }
                delay(100L)
            }
        }
    }

    fun configure(durationMs: Long, label: String? = null) { _state.value = engine.newCountdown(durationMs, label) }
    fun start() { _state.value = _state.value?.let(engine::start) }
    fun pause() { _state.value = _state.value?.let(engine::pause) }
    fun resume() { _state.value = _state.value?.let(engine::resume) }
    fun cancel() { _state.value = _state.value?.let(engine::cancel) }
    fun addTime(deltaMs: Long) { _state.value = _state.value?.let { engine.addDuration(it, deltaMs) } }
    fun remainingMs(): Long = _state.value?.let(engine::remainingMs) ?: 0L
}

class StopwatchViewModel(
    private val engine: TimerEngine = TimerEngine()
) : ViewModel() {
    private val _state = MutableStateFlow(engine.newStopwatch())
    val state: StateFlow<StopwatchState> = _state.asStateFlow()

    fun start() { _state.value = engine.start(_state.value) }
    fun pause() { _state.value = engine.pause(_state.value) }
    fun resume() { _state.value = engine.resume(_state.value) }
    fun lap() { _state.value = engine.lap(_state.value) }
    fun stop() { _state.value = engine.stop(_state.value) }
    fun cancel() { _state.value = engine.cancel(_state.value) }
    fun elapsedMs(): Long = engine.stopwatchElapsedMs(_state.value)
}
