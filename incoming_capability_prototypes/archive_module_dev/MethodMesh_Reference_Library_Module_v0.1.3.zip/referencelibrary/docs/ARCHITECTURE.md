# Reference Library architecture

The module owns document metadata, SAF import, shelf/search presentation and selection results. It does not require shared-shell special cases.

`ReferenceLibraryModule.kt` declares the MethodMesh module, settings and RIL bindings.  
`ReferenceLibraryMethod.kt` defines the stable method contract and output fields.  
`ReferenceLibraryCapabilityScreen.kt` implements the shelf-first native control centre.  
`ReferenceLibraryModel.kt` implements device-local metadata persistence.

The current reader boundary intentionally delegates native display to an Android `ACTION_VIEW` handler. External/ODK-style runs do not launch a second viewer: they select and return the document result through the normal MethodMesh closeout path. Direct MethodMesh use now bypasses the generic capture/result scaffold entirely: opening a document records recency and hands off to the Android viewer, then naturally resumes the library dashboard. External/ODK/preset/protocol launches continue to use the normal MethodMesh select/return closeout contract. Reference Library v0.1.3 declares a dependency on the existing `documentscanner` module. `Scan to shelf` resolves `document.scan` through `MethodMeshModuleRegistry.screenFor(...)`, supplies an automatic-return dependency context, and consumes the scanner output without copying scanner implementation details. This preserves launch-origin clarity while keeping the scanner independently owned. A later in-module reader can replace the native display boundary without changing method IDs or repository metadata.

The repository checks stored URI readability before use. Missing/revoked content is represented explicitly as `not_found` or `unavailable`; it is never silently treated as a successful selection. Re-importing the same URI updates its existing library record rather than creating duplicates.


## Scan-to-shelf persistence boundary

Document Scanner currently emits FileProvider URIs backed by its cache. Reference Library therefore treats scanner output as transient input, not durable shelf storage. After the user chooses a custom name and shelf, `ReferenceLibraryRepository.importManagedCopy()` copies the preferred searchable PDF (or scanner PDF fallback) into `filesDir/reference_library/scans/`, then creates a new FileProvider URI for the managed copy. The library record points only to that durable copy.

Existing documents selected through Android Storage Access Framework continue to remain in place and use persisted read permission. The two storage models are deliberately distinct and are disclosed in the dashboard text.
