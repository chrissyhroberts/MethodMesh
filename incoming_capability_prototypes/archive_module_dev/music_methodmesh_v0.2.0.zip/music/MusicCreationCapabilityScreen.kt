package com.example.methodmesh.modules.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONArray
import org.json.JSONObject

internal object EuclideanRhythmCapabilityScreen : SimpleMusicScreen(As100EuclideanRhythmMethod,"Euclidean rhythm","Distribute hits evenly over a step grid.",listOf(InputSpec("steps","Steps","16"),InputSpec("pulses","Hits","5"),InputSpec("rotation","Rotation","0")))
internal object PatternMutationCapabilityScreen : SimpleMusicScreen(As100PatternMutationMethod,"Pattern mutation","Make reproducible rhythmic variations.",listOf(InputSpec("pattern","Pattern","x...x...x...x..."),InputSpec("mode","Mutation","random",listOf("random","sparser","denser","invert","rotate_left","rotate_right","half_time","double_time")),InputSpec("amount","Amount 0–1","0.25"),InputSpec("seed","Seed","1")))
internal object ProbabilityPatternCapabilityScreen : SimpleMusicScreen(As100ProbabilityPatternMethod,"Probability sequencer","Turn trigger probabilities into a reproducible evolving rhythm.",listOf(InputSpec("probabilities","Step probabilities","1,0,0.4,0,1,0,0.25,0"),InputSpec("seed","Seed","1")))
internal object ChordProgressionCapabilityScreen : SimpleMusicScreen(As100ChordProgressionMethod,"Chord progression","Build from Roman numerals or generate a diatonic progression.",listOf(InputSpec("root","Root","C"),InputSpec("mode","Mode","major",listOf("major","minor")),InputSpec("roman","Roman numerals (optional)","I V vi IV"),InputSpec("bars","Generated bars","4"),InputSpec("seed","Seed","1"),InputSpec("prefer_flats","Prefer flats","false",listOf("false","true"))))
internal object ArpeggiatorCapabilityScreen : SimpleMusicScreen(As100ArpeggiatorMethod,"Arpeggiator","Turn a chord into a note sequence.",listOf(InputSpec("chord","Chord","Am"),InputSpec("pattern","Pattern","up",listOf("up","down","up_down","outside_in")),InputSpec("octaves","Octaves","2"),InputSpec("base_octave","Base octave","3"),InputSpec("prefer_flats","Prefer flats","false",listOf("false","true"))))
internal object BasslineCapabilityScreen : SimpleMusicScreen(As100BasslineMethod,"Bassline generator","Generate a simple bassline from chord symbols.",listOf(InputSpec("progression","Chords","Am F C G"),InputSpec("style","Style","root_fifth",listOf("roots","root_fifth","octaves","walking")),InputSpec("octave","Octave","2"),InputSpec("prefer_flats","Prefer flats","false",listOf("false","true"))))
internal object MelodySequencerCapabilityScreen : SimpleMusicScreen(As100MelodySequencerMethod,"Scale-locked melody","Map scale degrees to notes in a chosen key.",listOf(InputSpec("root","Root","C"),InputSpec("scale","Scale","minor_pentatonic",listOf("major","natural_minor","minor_pentatonic","major_pentatonic","dorian","mixolydian","blues")),InputSpec("degrees","Scale degrees","1,3,4,5,3,2,1"),InputSpec("octave","Octave","4"),InputSpec("prefer_flats","Prefer flats","false",listOf("false","true"))))
internal object MotifGeneratorCapabilityScreen : SimpleMusicScreen(As100MotifGeneratorMethod,"Motif variations","Retrograde, invert and transpose a short motif.",listOf(InputSpec("notes","Motif notes","C4 E4 G4 A4"),InputSpec("transpose_semitones","Transpose semitones","2")))
internal object SongSketchCapabilityScreen : SimpleMusicScreen(As100SongSketchMethod,"Song sketch","Bundle tempo, harmony, rhythm and structure into a compact composition sketch.",listOf(InputSpec("title","Title","Untitled sketch"),InputSpec("bpm","BPM","100"),InputSpec("root","Root","C"),InputSpec("mode","Mode","major",listOf("major","minor")),InputSpec("progression","Progression","C | G | Am | F"),InputSpec("beat","Beat","x...x...x...x..."),InputSpec("bassline","Bassline",""),InputSpec("melody","Melody",""),InputSpec("structure","Structure","Intro 4; Verse 8; Chorus 8")))

internal object RhythmCaptureCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100RhythmCaptureMethod.ID; override val title="Tap a rhythm"; override val description="Tap a rhythm, infer its pulse, and retain both raw and quantised timing."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit)=RhythmCaptureUi(context,onBack,onConfirmed,onCancel)
}

internal object DrumMachineCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100DrumMachineMethod.ID; override val title="Drum machine"; override val description="Four-lane synthesized step sequencer with tempo and swing."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit)=DrumMachineUi(context,onBack,onConfirmed,onCancel)
}

internal object BeatPadsCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100BeatPadsMethod.ID; override val title="Beat pads"; override val description="Finger-drum synthesized percussion and capture the hit sequence."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit)=BeatPadsUi(context,onBack,onConfirmed,onCancel)
}

internal object LiveLooperCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100LiveLooperMethod.ID; override val title="Live looper"; override val description="Record a master phrase, then overdub independently mutable microphone layers."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit)=LiveLooperUi(context,onBack,onConfirmed,onCancel)
}

@Composable private fun RhythmCaptureUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    var tapsCsv by rememberSaveable(context.action.canonicalId){mutableStateOf("")}; var steps by rememberSaveable{mutableStateOf(context.action.settings["steps_per_beat"]?:"4")}; var bars by rememberSaveable{mutableStateOf(context.action.settings["bars"]?:"1")}; var human by rememberSaveable{mutableStateOf(1f)}; var resultJson by rememberSaveable{mutableStateOf<String?>(null)}
    val taps=tapsCsv.split(',').mapNotNull{it.toDoubleOrNull()}; val live=if(taps.size>=2)As100RhythmCaptureMethod.calculate(mapOf("tap_times_ms" to taps.joinToString(","),"steps_per_beat" to steps,"bars" to bars,"beats_per_bar" to "4")) else null
    val restored=resultJson?.let{json->val o=JSONObject(json);creationExecution(As100RhythmCaptureMethod,context,As100RhythmCaptureMethod.fields.outputs.associateWith{o.optString(it,"")})}
    LaunchedEffect(context.startsImmediately){val supplied=context.action.settings["tap_times_ms"]?:context.action.settings["input_tap_times_ms"];if(context.startsImmediately&&!supplied.isNullOrBlank()&&resultJson==null)resultJson=JSONObject(As100RhythmCaptureMethod.calculate(context.action.settings+mapOf("tap_times_ms" to supplied))).toString()}
    CapabilityScreenScaffold(title=titleFor(As100RhythmCaptureMethod),capabilityId=As100RhythmCaptureMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=restored,resultPreview=restored?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={resultJson=null;tapsCsv=""},onConfirm={restored?.let(onConfirmed)},onCancel=onCancel){
        Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
            Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(live?.get(As100RhythmCaptureMethod.fields.field("bpm"))?.let{"$it BPM"}?:"Tap your rhythm",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(live?.get(As100RhythmCaptureMethod.fields.field("pattern"))?:"The first tap becomes step zero.",style=MaterialTheme.typography.titleMedium)}}
            Button(onClick={val now=SystemClock.elapsedRealtime().toDouble();tapsCsv=(taps+now).takeLast(64).joinToString(",")},modifier=Modifier.fillMaxWidth().height(170.dp)){Text("TAP",style=MaterialTheme.typography.displayMedium)}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(steps,{steps=it},label={Text("Steps / beat")},modifier=Modifier.weight(1f));OutlinedTextField(bars,{bars=it},label={Text("Bars")},modifier=Modifier.weight(1f))}
            Text("Human ←→ Tight   ${"%.0f".format(human*100)}% quantised");Slider(value=human,onValueChange={human=it},valueRange=0f..1f)
            Text("The slider is a preview strength: raw and fully quantised timing are both retained in the returned audit data.",style=MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={tapsCsv=""},modifier=Modifier.weight(1f)){Text("Reset")};Button(enabled=live?.get(As100RhythmCaptureMethod.fields.status)=="succeeded",onClick={live?.let{resultJson=JSONObject(it).toString()}},modifier=Modifier.weight(1f)){Text("Use rhythm")}}
        }
    }
}

@Composable private fun DrumMachineUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    var bpm by rememberSaveable{mutableStateOf(context.action.settings["bpm"]?:"110")}; var swing by rememberSaveable{mutableStateOf((context.action.settings["swing"]?:"0").toFloatOrNull()?:0f)}; var playing by rememberSaveable{mutableStateOf(false)}; var resultJson by rememberSaveable{mutableStateOf<String?>(null)}
    val voices=listOf("kick","snare","hat","clap"); val patterns=remember{voices.associateWith{voice->mutableStateListOf<Boolean>().apply{addAll(MusicCreationAlgorithms.parsePattern(when(voice){"kick"->"x...x...x...x...";"snare"->"....x.......x...";"hat"->"x.x.x.x.x.x.x.x.";else->"................"}))}}}; val engine=remember{DrumSynthEngine()};DisposableEffect(Unit){onDispose{engine.stop()}}
    fun snapshot():Map<String,String>{val settings=mapOf("bpm" to bpm,"steps" to "16","swing" to swing.toString())+voices.associateWith{MusicCreationAlgorithms.patternString(patterns[it]!!.toList())};return As100DrumMachineMethod.calculate(settings)}
    fun togglePlay(){if(playing){engine.stop();playing=false}else{val b=bpm.toDoubleOrNull()?:110.0;engine.playPattern(b,16,swing.toDouble(),voices.associateWith{patterns[it]!!.toList()});playing=true}}
    val restored=resultJson?.let{json->val o=JSONObject(json);creationExecution(As100DrumMachineMethod,context,As100DrumMachineMethod.fields.outputs.associateWith{o.optString(it,"")})}
    CapabilityScreenScaffold(title="Drum machine",capabilityId=As100DrumMachineMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=restored,resultPreview=restored?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={resultJson=null},onConfirm={restored?.let(onConfirmed)},onCancel={engine.stop();onCancel()}){
        Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(bpm,{bpm=it},label={Text("BPM")},modifier=Modifier.weight(1f));Column(Modifier.weight(2f)){Text("Swing ${"%.0f".format(swing*100)}%");Slider(swing,{swing=it},valueRange=0f..0.5f)}}
            voices.forEach{voice->Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){Text(voice.uppercase(),modifier=Modifier.weight(1.2f));patterns[voice]!!.forEachIndexed{i,on->Card(Modifier.weight(1f).height(34.dp).clickable{patterns[voice]!![i]=!on}){Spacer(Modifier.fillMaxWidth().height(34.dp).background(if(on)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant))}}}}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={togglePlay()},modifier=Modifier.weight(1f)){Text(if(playing)"STOP" else "PLAY")};OutlinedButton(onClick={voices.forEach{v->patterns[v]!!.indices.forEach{i->patterns[v]!![i]=false}}},modifier=Modifier.weight(1f)){Text("CLEAR")}}
            Button(onClick={resultJson=JSONObject(snapshot()).toString()},modifier=Modifier.fillMaxWidth()){Text("Use beat")}
        }
    }
}

@Composable private fun BeatPadsUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    val engine=remember{DrumSynthEngine()};DisposableEffect(Unit){onDispose{engine.stop()}}; val hits=remember{mutableStateListOf<JSONObject>()}; var recording by rememberSaveable{mutableStateOf(false)}; var startedAt by rememberSaveable{mutableStateOf(0L)}; var resultJson by rememberSaveable{mutableStateOf<String?>(null)}
    val restored=resultJson?.let{json->val o=JSONObject(json);creationExecution(As100BeatPadsMethod,context,As100BeatPadsMethod.fields.outputs.associateWith{o.optString(it,"")})}
    fun hit(voice:String){engine.playVoice(voice);if(recording){if(startedAt==0L)startedAt=SystemClock.elapsedRealtime();hits+=JSONObject().put("voice",voice).put("at_ms",SystemClock.elapsedRealtime()-startedAt)}}
    CapabilityScreenScaffold(title="Beat pads",capabilityId=As100BeatPadsMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=restored,resultPreview=restored?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={resultJson=null;hits.clear()},onConfirm={restored?.let(onConfirmed)},onCancel=onCancel){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        listOf(listOf("kick","snare","hat"),listOf("clap","tom","click")).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){row.forEach{voice->Button(onClick={hit(voice)},modifier=Modifier.weight(1f).height(92.dp)){Text(voice.uppercase())}}}}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={recording=!recording;if(recording){hits.clear();startedAt=0L}},modifier=Modifier.weight(1f)){Text(if(recording)"STOP CAPTURE" else "CAPTURE")};OutlinedButton(onClick={hits.clear();startedAt=0L},modifier=Modifier.weight(1f)){Text("CLEAR")}}
        Text("${hits.size} captured hits")
        Button(enabled=hits.isNotEmpty(),onClick={val arr=JSONArray();hits.forEach{arr.put(it)};resultJson=JSONObject(As100BeatPadsMethod.calculate(mapOf("hits_json" to arr.toString()))).toString()},modifier=Modifier.fillMaxWidth()){Text("Use sequence")}
    }}
}

@Composable private fun LiveLooperUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    val androidContext=LocalContext.current; val engine=remember{PcmLooperEngine()}; val mainHandler=remember{Handler(Looper.getMainLooper())}; var revision by rememberSaveable{mutableStateOf(0)}; var permission by remember{mutableStateOf(ContextCompat.checkSelfPermission(androidContext,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)}; var resultJson by rememberSaveable{mutableStateOf<String?>(null)}
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){permission=it};DisposableEffect(Unit){onDispose{engine.clear()}}
    val layers=remember(revision){engine.layerSnapshot()}; val restored=resultJson?.let{json->val o=JSONObject(json);creationExecution(As100LiveLooperMethod,context,As100LiveLooperMethod.fields.outputs.associateWith{o.optString(it,"")})}
    fun snapshot():Map<String,String>{val arr=JSONArray();engine.layerSnapshot().forEach{arr.put(JSONObject().put("id",it.id).put("muted",it.muted))};return As100LiveLooperMethod.calculate(mapOf("loop_ms" to engine.loopMs.toString(),"layer_count" to engine.layerCount.toString(),"playing" to engine.isPlaying().toString(),"layers_json" to arr.toString()))}
    CapabilityScreenScaffold(title="Live looper",capabilityId=As100LiveLooperMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=restored,resultPreview=restored?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={resultJson=null},onConfirm={restored?.let(onConfirmed)},onCancel={engine.clear();onCancel()}){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(if(engine.layerCount==0)"Ready for first loop" else "${engine.layerCount} layers · ${MusicAlgorithms.formatDuration((engine.loopMs/1000).toInt())}",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(if(engine.isRecording())"Recording…" else if(engine.isPlaying())"Playing" else "Stopped")}}
        if(!permission)Button(onClick={launcher.launch(Manifest.permission.RECORD_AUDIO)},modifier=Modifier.fillMaxWidth()){Text("Allow microphone")}
        Button(enabled=permission,onClick={ if(engine.isRecording()){ engine.stopRecording(); revision++ } else { engine.startRecording{ mainHandler.post{ revision++; if(engine.layerCount==1&&!engine.isPlaying()) engine.startPlayback() } }; revision++ } },modifier=Modifier.fillMaxWidth().height(90.dp)){Text(if(engine.isRecording())"CLOSE LAYER" else if(engine.layerCount==0)"RECORD FIRST LOOP" else "OVERDUB")}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(enabled=engine.layerCount>0,onClick={if(engine.isPlaying())engine.stopPlayback() else engine.startPlayback();revision++},modifier=Modifier.weight(1f)){Text(if(engine.isPlaying())"STOP" else "PLAY")};OutlinedButton(enabled=engine.layerCount>0,onClick={engine.undo();revision++},modifier=Modifier.weight(1f)){Text("UNDO")}}
        LazyColumn(Modifier.height(170.dp)){itemsIndexed(layers){_,layer->Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Text("Layer ${layer.id}",modifier=Modifier.weight(1f));OutlinedButton(onClick={engine.toggleMute(layer.id);revision++}){Text(if(layer.muted)"UNMUTE" else "MUTE")}}}}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={engine.clear();revision++},modifier=Modifier.weight(1f)){Text("CLEAR ALL")};Button(enabled=engine.layerCount>0,onClick={resultJson=JSONObject(snapshot()).toString()},modifier=Modifier.weight(1f)){Text("Use loop")}}
        Text("Development audio engine: device latency and Bluetooth routing must be validated before Production promotion.",style=MaterialTheme.typography.bodySmall)
    }}
}

private fun creationExecution(method:MusicPureMethod,context:CapabilityScreenContext,values:Map<String,String>):ExecutionResult{val request=method.request(action=method.id,context=context.request.invocationContext.asMap(method.id)+context.action.settings+values,signals=emptyList(),inputs=emptyList());return method.result(request,values,context.request.invocationContext)}
private fun titleFor(method:MusicPureMethod)=method.descriptor.name
