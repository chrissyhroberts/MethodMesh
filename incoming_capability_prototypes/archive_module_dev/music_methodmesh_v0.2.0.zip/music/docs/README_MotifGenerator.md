# Motif variations

**Method ID:** `music.motif_generator`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Produces classic motivic transformations: retrograde, inversion, retrograde-inversion and transposition.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `notes`
- `transpose_semitones`

## Outputs

- `music_motif_result`
- `music_motif_original`
- `music_motif_retrograde`
- `music_motif_inversion`
- `music_motif_retrograde_inversion`
- `music_motif_transposed`
- `music_motif_variations_json`
- `music_motif_status`
- `music_motif_audit_json`
- `music_motif_error`

## ODK/XLSForm

The nested `example_odk_MotifGenerator.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
