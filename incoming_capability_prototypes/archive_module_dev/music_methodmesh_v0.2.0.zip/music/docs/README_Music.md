# MethodMesh Music module

**Status:** Development · **Version:** 0.2.0

Self-contained MethodMesh music utilities under `modules/music/`. Version 0.2 adds a lightweight creation/performance layer without turning MethodMesh into a DAW.

## Capability map

- **Tempo/practice:** Tap tempo, Metronome, Tempo converter, Delay time, Polyrhythm, Tempo trainer.
- **Pitch/theory:** Note ↔ frequency, Transpose, Interval, Chord, Chord guide, Temperament, Harmonics, Music reference.
- **Creation – rhythm:** Tap a rhythm, Euclidean rhythm, Probability sequencer, Pattern mutation, Drum machine, Beat pads.
- **Creation – harmony/melody:** Chord progression, Scale-locked melody, Arpeggiator, Bassline generator, Motif variations.
- **Creation – audio:** Live looper with a PCM master loop and independent overdub layers.
- **Composition:** Song sketch capability plus persistent Song Sketch dashboard.
- **Dashboards:** Practice, Performance/set list, Reference, Jam/creation, Song Sketch.
- **Live tuning:** reuse existing `acoustic.tune`; do not duplicate its microphone pitch DSP.

## Creation architecture

`MusicCreationAlgorithms.kt` owns deterministic rhythm/harmony/melody generation. `MusicCreationMethod.kt` exposes stable AS100 methods. `MusicCreationAudio.kt` owns asset-free synthesized percussion and the Development PCM looper. `MusicCreationCapabilityScreen.kt` owns creation interactions. `MusicCreationDashboardScreen.kt` implements the Jam and Song Sketch persistent dashboards. `MusicCreationRepository.kt` persists lightweight jam/sketch state.

The creation workflow is intentionally composable:

`tap → infer/quantise → pattern → beat → progression/bass/melody → loop/performance → song sketch`

## Audio design

The drum machine and pads synthesize simple percussion voices directly, avoiding bundled copyrighted samples. The looper records mono PCM; the first layer fixes loop length and later overdubs are trimmed/padded to it while remaining separately mutable. This is intentionally small and auditable rather than a multitrack DAW.

## Delivery

Copy the complete `music/` folder to `app/src/main/java/com/example/methodmesh/modules/music/`. Module discovery should pick up `MusicModule.kt` automatically.

## Validation status

Pure music-creation algorithms compile and have been exercised with a standalone Kotlin smoke test. The complete Android module has not been built against the target MethodMesh repository in this environment. Real-time audio components remain Development pending on-device latency/audio-route testing and a target-repo `./gradlew :app:assembleDebug` build.
