# Arpeggiator

**Method ID:** `music.arpeggiator`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Turns a chord symbol into an ordered arpeggio across one or more octaves.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `chord`
- `pattern`
- `octaves`
- `base_octave`
- `prefer_flats`

## Outputs

- `music_arpeggiator_result`
- `music_arpeggiator_chord`
- `music_arpeggiator_pattern`
- `music_arpeggiator_octaves`
- `music_arpeggiator_notes`
- `music_arpeggiator_notes_json`
- `music_arpeggiator_status`
- `music_arpeggiator_audit_json`
- `music_arpeggiator_error`

## ODK/XLSForm

The nested `example_odk_Arpeggiator.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
