# Jam / creation dashboard

**Method ID:** `music.jam_dashboard`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Persistent live beat/rhythm scratchpad. Native and preset launches stay on the dashboard until Finish / Use this snapshot.

## Native workflow

This is a persistent dashboard. Native dashboard/preset execution withholds `capturedResult` from the generic scaffold until the user explicitly chooses **Finish** / **Use this snapshot**.

## Inputs

- `bpm`
- `drum_pattern_json`
- `loop_ms`
- `loop_layers`
- `captured_pattern`

## Outputs

- `music_jam_dashboard_result`
- `music_jam_dashboard_bpm`
- `music_jam_dashboard_drum_pattern_json`
- `music_jam_dashboard_loop_ms`
- `music_jam_dashboard_loop_layers`
- `music_jam_dashboard_captured_pattern`
- `music_jam_dashboard_snapshot_json`
- `music_jam_dashboard_status`
- `music_jam_dashboard_audit_json`
- `music_jam_dashboard_error`

## ODK/XLSForm

The nested `example_odk_JamDashboard.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
