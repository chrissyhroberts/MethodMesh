# Pattern mutation

**Method ID:** `music.pattern_mutation`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Creates reproducible rhythmic variations using seeded mutations.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `pattern`
- `mode`
- `amount`
- `seed`

## Outputs

- `music_pattern_mutation_result`
- `music_pattern_mutation_input_pattern`
- `music_pattern_mutation_mode`
- `music_pattern_mutation_amount`
- `music_pattern_mutation_seed`
- `music_pattern_mutation_output_pattern`
- `music_pattern_mutation_output_json`
- `music_pattern_mutation_status`
- `music_pattern_mutation_audit_json`
- `music_pattern_mutation_error`

## ODK/XLSForm

The nested `example_odk_PatternMutation.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
