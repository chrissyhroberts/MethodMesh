# Tempo trainer

**Method ID:** `music.tempo_trainer`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Generate a stepped BPM practice sequence.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `start_bpm`
- `target_bpm`
- `increment_bpm`
- `bars_per_step`

## Outputs

- `music_tempo_trainer_result`
- `music_tempo_trainer_start_bpm`
- `music_tempo_trainer_target_bpm`
- `music_tempo_trainer_increment_bpm`
- `music_tempo_trainer_bars_per_step`
- `music_tempo_trainer_step_count`
- `music_tempo_trainer_sequence_json`
- `music_tempo_trainer_status`
- `music_tempo_trainer_audit_json`
- `music_tempo_trainer_error`

## Main result

`music_tempo_trainer_result` is the compact native/share result. `music_tempo_trainer_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_TempoTrainer.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

v0.1 generates the progression; automatic metronome advancement after N bars is the next logical native enhancement.
