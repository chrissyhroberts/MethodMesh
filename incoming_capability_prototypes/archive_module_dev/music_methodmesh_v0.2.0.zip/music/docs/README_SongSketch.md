# Song sketch

**Method ID:** `music.song_sketch`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Bundles the key musical ingredients of an idea into a compact interoperable sketch.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `title`
- `bpm`
- `root`
- `mode`
- `progression`
- `beat`
- `bassline`
- `melody`
- `structure`

## Outputs

- `music_song_sketch_result`
- `music_song_sketch_title`
- `music_song_sketch_bpm`
- `music_song_sketch_key`
- `music_song_sketch_progression`
- `music_song_sketch_beat`
- `music_song_sketch_bassline`
- `music_song_sketch_melody`
- `music_song_sketch_structure`
- `music_song_sketch_sketch_json`
- `music_song_sketch_status`
- `music_song_sketch_audit_json`
- `music_song_sketch_error`

## ODK/XLSForm

The nested `example_odk_SongSketch.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
