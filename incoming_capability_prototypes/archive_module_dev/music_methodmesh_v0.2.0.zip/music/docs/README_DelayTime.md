# Delay-time calculator

**Method ID:** `music.delay_time`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Calculate tempo-synchronised delay time.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `bpm`
- `subdivision`

## Outputs

- `music_delay_time_result`
- `music_delay_time_bpm`
- `music_delay_time_subdivision`
- `music_delay_time_delay_ms`
- `music_delay_time_status`
- `music_delay_time_audit_json`
- `music_delay_time_error`

## Main result

`music_delay_time_result` is the compact native/share result. `music_delay_time_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_DelayTime.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Pure local calculation; suitable for effects-pedal/rack settings.
