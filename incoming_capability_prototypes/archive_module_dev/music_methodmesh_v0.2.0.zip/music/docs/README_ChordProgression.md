# Chord progression

**Method ID:** `music.chord_progression`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Builds a progression from Roman numerals or generates a seeded diatonic progression.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `root`
- `mode`
- `roman`
- `bars`
- `seed`
- `prefer_flats`

## Outputs

- `music_progression_result`
- `music_progression_key`
- `music_progression_mode`
- `music_progression_source`
- `music_progression_chords`
- `music_progression_chords_json`
- `music_progression_seed`
- `music_progression_status`
- `music_progression_audit_json`
- `music_progression_error`

## ODK/XLSForm

The nested `example_odk_ChordProgression.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
