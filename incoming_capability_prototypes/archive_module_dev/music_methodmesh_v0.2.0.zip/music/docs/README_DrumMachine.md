# Drum machine

**Method ID:** `music.drum_machine`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Four-lane step sequencer with asset-free synthesized kick/snare/hat/clap voices.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `bpm`
- `steps`
- `kick`
- `snare`
- `hat`
- `clap`
- `swing`

## Outputs

- `music_drum_machine_result`
- `music_drum_machine_bpm`
- `music_drum_machine_steps`
- `music_drum_machine_kick`
- `music_drum_machine_snare`
- `music_drum_machine_hat`
- `music_drum_machine_clap`
- `music_drum_machine_swing`
- `music_drum_machine_pattern_json`
- `music_drum_machine_status`
- `music_drum_machine_audit_json`
- `music_drum_machine_error`

## ODK/XLSForm

The nested `example_odk_DrumMachine.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
