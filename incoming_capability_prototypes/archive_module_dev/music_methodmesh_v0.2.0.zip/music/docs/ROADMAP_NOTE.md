# Music module roadmap after v0.2.0

## Implemented in v0.2.0

Creation layer now includes tap-rhythm capture/quantisation, Euclidean rhythms, probability sequencing, pattern mutation, drum machine, beat pads, live PCM looper, chord progressions, scale-locked melodies, arpeggios, basslines, motif transformations, Song Sketch, Jam dashboard and Song Sketch dashboard.

## Sensible next work

- On-device latency calibration and audio-route validation for the looper/drum engine.
- Optional count-in and bar-quantised loop close.
- One-shot sample import with explicit provenance/licensing metadata.
- Scene launcher combining beat + loop + composition snapshot.
- Groove-template capture and application using preserved microtiming.
- MIDI import/export only if it can remain dependency-light and generic.
- Shared transport clock if MethodMesh later introduces a framework-level clock useful beyond music.

Do not expand into waveform editing, plugin hosting, a piano roll, multitrack production or other DAW-scale features unless MethodMesh intentionally changes scope.
