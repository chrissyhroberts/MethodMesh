# Bassline generator

**Method ID:** `music.bassline`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Generates root, root-fifth, octave or walking bass material from chord symbols.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `progression`
- `style`
- `octave`
- `prefer_flats`

## Outputs

- `music_bassline_result`
- `music_bassline_progression`
- `music_bassline_style`
- `music_bassline_notes`
- `music_bassline_notes_json`
- `music_bassline_status`
- `music_bassline_audit_json`
- `music_bassline_error`

## ODK/XLSForm

The nested `example_odk_Bassline.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
