# Scale-locked melody

**Method ID:** `music.melody_sequence`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Maps scale degrees to pitches while locking a phrase to a selected key/scale.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `root`
- `scale`
- `degrees`
- `octave`
- `prefer_flats`

## Outputs

- `music_melody_sequence_result`
- `music_melody_sequence_root`
- `music_melody_sequence_scale`
- `music_melody_sequence_degrees`
- `music_melody_sequence_notes`
- `music_melody_sequence_notes_json`
- `music_melody_sequence_status`
- `music_melody_sequence_audit_json`
- `music_melody_sequence_error`

## ODK/XLSForm

The nested `example_odk_MelodySequence.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
