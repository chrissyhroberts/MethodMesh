# Chord builder / identifier

**Method ID:** `music.chord`  
**Status:** Development  
**Version:** 0.2.0

## What it does

Build common chord tones or identify exact pitch-class chord matches.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `mode`
- `root`
- `quality`
- `notes`
- `prefer_flats`

## Outputs

- `music_chord_result`
- `music_chord_mode`
- `music_chord_symbol`
- `music_chord_notes`
- `music_chord_matches_json`
- `music_chord_status`
- `music_chord_audit_json`
- `music_chord_error`

## Main result

`music_chord_result` is the compact native/share result. `music_chord_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_Chord.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Identification is exact-set matching against the built-in v0.1 chord dictionary; it does not rank partial/voicing-dependent jazz interpretations.
