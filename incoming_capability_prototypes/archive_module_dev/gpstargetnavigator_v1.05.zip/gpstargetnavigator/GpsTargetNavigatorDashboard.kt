package com.example.methodmesh.modules.gpstargetnavigator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
internal fun NavigationTargetCard(
    targetName: String,
    targetPlusCode: String,
    targetLatitude: Float,
    targetLongitude: Float,
    arrivalRadiusMeters: Float
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("DESTINATION", style = MaterialTheme.typography.labelMedium)
                    Text(
                        targetName.ifBlank { "Target location" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        "±${arrivalRadiusMeters.roundToInt()} m",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            if (targetPlusCode.isNotBlank()) {
                CopyableNavigationValue(
                    label = "Plus Code",
                    displayValue = targetPlusCode,
                    clipboardValue = targetPlusCode,
                    context = context,
                    monospace = true
                )
                Spacer(Modifier.height(6.dp))
            }
            CopyableNavigationValue(
                label = "Coordinates",
                displayValue = "${formatCoordinateValue(targetLatitude)}, ${formatCoordinateValue(targetLongitude)}",
                clipboardValue = "${formatCoordinateValue(targetLatitude)},${formatCoordinateValue(targetLongitude)}",
                context = context,
                monospace = true
            )
        }
    }
}

@Composable
internal fun NavigationHeroCard(
    distanceMeters: Float,
    bearingDegrees: Float,
    headingDegrees: Float?,
    relativeBearingDegrees: Float,
    accuracyMeters: Float,
    hasLocationFix: Boolean,
    hasHeading: Boolean,
    arrived: Boolean,
    lifecycleLabel: String
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (arrived) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                lifecycleLabel.uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (hasLocationFix) formatNavigationDistance(distanceMeters) else "Waiting for GPS",
                modifier = if (hasLocationFix) Modifier.clickable {
                    copyNavigationValue(context, formatRawFloat(distanceMeters))
                } else Modifier,
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Text(
                if (hasHeading) arTurnInstruction(relativeBearingDegrees, arrived) else "Waiting for compass heading",
                modifier = if (hasHeading) Modifier.clickable {
                    copyNavigationValue(context, formatRawFloat(relativeBearingDegrees))
                } else Modifier,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            if (hasLocationFix) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)) {
                        Text(
                            "Bearing ${bearingDegrees.roundToInt()}°",
                            modifier = Modifier
                                .clickable { copyNavigationValue(context, formatRawFloat(bearingDegrees)) }
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    if (accuracyMeters > 0f) {
                        Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)) {
                            Text(
                                "GPS ±${accuracyMeters.roundToInt()} m",
                                modifier = Modifier
                                    .clickable { copyNavigationValue(context, formatRawFloat(accuracyMeters)) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun NavigationCompassDashboard(
    bearingDegrees: Float,
    headingDegrees: Float?,
    relativeBearingDegrees: Float,
    hasLocationFix: Boolean,
    arrived: Boolean
) {
    val context = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val outline = MaterialTheme.colorScheme.outline
    val arrivedColor = MaterialTheme.colorScheme.tertiary

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("TARGET VECTOR", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .size(250.dp)
                    .clickable(enabled = hasLocationFix) {
                        copyNavigationValue(context, formatRawFloat(bearingDegrees))
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(240.dp)) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.minDimension / 2f - 10.dp.toPx()

                    drawCircle(
                        color = outline,
                        radius = radius,
                        center = center,
                        style = Stroke(width = 2.dp.toPx())
                    )
                    drawCircle(
                        color = outline.copy(alpha = 0.35f),
                        radius = radius * 0.63f,
                        center = center,
                        style = Stroke(width = 1.dp.toPx())
                    )

                    repeat(24) { index ->
                        rotate(index * 15f, center) {
                            val major = index % 6 == 0
                            drawLine(
                                color = if (major) onSurface else outline,
                                start = Offset(center.x, center.y - radius),
                                end = Offset(center.x, center.y - radius + (if (major) 14.dp.toPx() else 7.dp.toPx())),
                                strokeWidth = if (major) 2.5.dp.toPx() else 1.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    if (headingDegrees != null) {
                        rotate(-headingDegrees, center) {
                            drawLine(
                                color = outline,
                                start = Offset(center.x, center.y - radius * 0.72f),
                                end = Offset(center.x, center.y - radius * 0.94f),
                                strokeWidth = 5.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    if (hasLocationFix && headingDegrees != null) {
                        rotate(relativeBearingDegrees, center) {
                            val arrowColor = if (arrived) arrivedColor else primary
                            drawLine(
                                color = arrowColor,
                                start = Offset(center.x, center.y + radius * 0.18f),
                                end = Offset(center.x, center.y - radius * 0.69f),
                                strokeWidth = 10.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = arrowColor,
                                start = Offset(center.x, center.y - radius * 0.69f),
                                end = Offset(center.x - 15.dp.toPx(), center.y - radius * 0.49f),
                                strokeWidth = 8.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                            drawLine(
                                color = arrowColor,
                                start = Offset(center.x, center.y - radius * 0.69f),
                                end = Offset(center.x + 15.dp.toPx(), center.y - radius * 0.49f),
                                strokeWidth = 8.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }

                    drawCircle(color = onSurface, radius = 6.dp.toPx(), center = center)
                }

                if (!hasLocationFix) {
                    Text("GPS", style = MaterialTheme.typography.titleMedium)
                } else if (headingDegrees == null) {
                    Text("COMPASS", style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                if (headingDegrees == null) {
                    "Hold the phone normally; waiting for heading"
                } else {
                    "Arrow points to target • heading ${headingDegrees.roundToInt()}°"
                },
                modifier = if (headingDegrees != null) Modifier.clickable {
                    copyNavigationValue(context, formatRawFloat(headingDegrees))
                } else Modifier,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
internal fun NavigationTelemetryGrid(
    currentLatitude: Float,
    currentLongitude: Float,
    accuracyMeters: Float,
    bearingDegrees: Float,
    headingDegrees: Float?,
    relativeBearingDegrees: Float,
    updateCount: Int,
    hasLocationFix: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NavigationMetricCard(
                label = "Latitude",
                value = if (hasLocationFix) formatCoordinateValue(currentLatitude) else "Waiting",
                clipboardValue = if (hasLocationFix) formatCoordinateValue(currentLatitude) else null,
                modifier = Modifier.weight(1f),
                monospace = true
            )
            NavigationMetricCard(
                label = "Longitude",
                value = if (hasLocationFix) formatCoordinateValue(currentLongitude) else "Waiting",
                clipboardValue = if (hasLocationFix) formatCoordinateValue(currentLongitude) else null,
                modifier = Modifier.weight(1f),
                monospace = true
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NavigationMetricCard(
                label = "Accuracy",
                value = if (accuracyMeters > 0f) "±${accuracyMeters.roundToInt()} m" else "Waiting",
                clipboardValue = if (accuracyMeters > 0f) formatRawFloat(accuracyMeters) else null,
                modifier = Modifier.weight(1f)
            )
            NavigationMetricCard(
                label = "Updates",
                value = updateCount.toString(),
                clipboardValue = updateCount.toString(),
                modifier = Modifier.weight(1f)
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NavigationMetricCard(
                label = "Target bearing",
                value = "${bearingDegrees.roundToInt()}°",
                clipboardValue = if (hasLocationFix) formatRawFloat(bearingDegrees) else null,
                modifier = Modifier.weight(1f)
            )
            NavigationMetricCard(
                label = "Turn",
                value = headingDegrees?.let { "${relativeBearingDegrees.roundToInt()}°" } ?: "Waiting",
                clipboardValue = headingDegrees?.let { formatRawFloat(relativeBearingDegrees) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
internal fun NavigationMetricCard(
    label: String,
    value: String,
    clipboardValue: String?,
    modifier: Modifier = Modifier,
    monospace: Boolean = false
) {
    val context = LocalContext.current
    Card(
        modifier = modifier.clickable(enabled = clipboardValue != null) {
            clipboardValue?.let { copyNavigationValue(context, it) }
        }
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(3.dp))
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                fontFamily = if (monospace) FontFamily.Monospace else FontFamily.Default
            )
        }
    }
}

@Composable
internal fun CopyableNavigationValue(
    label: String,
    displayValue: String,
    clipboardValue: String,
    context: Context = LocalContext.current,
    monospace: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { copyNavigationValue(context, clipboardValue) }
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.width(104.dp), style = MaterialTheme.typography.labelMedium)
        Text(
            displayValue,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge,
            fontFamily = if (monospace) FontFamily.Monospace else FontFamily.Default,
            textAlign = TextAlign.End
        )
    }
}

internal fun copyNavigationValue(context: Context, value: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("MethodMesh navigation value", value))
    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
}

internal fun formatNavigationDistance(distanceMeters: Float): String =
    if (distanceMeters >= 1000f) "%.2f km".format(distanceMeters / 1000f) else "${distanceMeters.roundToInt()} m"

internal fun formatCoordinateValue(value: Float): String = "%.6f".format(value)

internal fun formatRawFloat(value: Float): String = when {
    value.isNaN() || value.isInfinite() -> ""
    kotlin.math.abs(value - value.roundToInt()) < 0.0001f -> value.roundToInt().toString()
    else -> "%.6f".format(value).trimEnd('0').trimEnd('.')
}
