# Attribution and external components

GPS target navigator is primarily module-owned MethodMesh code using Android platform/device services.

## Google Play Services Location

The module uses the Fused Location Provider (`com.google.android.gms.location`) for device location updates. Distribution must comply with the Google Play services SDK terms applicable to the host MethodMesh application.

Location fixes are consumed locally by this capability; the module itself does not send the target or location to a remote navigation service.

## Open Location Code / Plus Codes

Full Plus Code decoding is performed locally through MethodMesh's existing `OpenLocationCode` implementation from the `pluscodecapture` module. The host repository should retain the attribution/licence notice associated with that implementation and the Open Location Code project.

## Android camera and sensors

The optional AR navigator uses MethodMesh's shared `LiveCameraPreview` and `PhoneSensorRepository`, which in turn use Android camera/sensor facilities. No remote AR/localisation service is introduced by this module.
