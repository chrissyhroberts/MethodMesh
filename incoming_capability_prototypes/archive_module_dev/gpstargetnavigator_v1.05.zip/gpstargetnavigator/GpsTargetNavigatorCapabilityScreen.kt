package com.example.methodmesh.modules.gpstargetnavigator

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.modules.pluscodecapture.OpenLocationCode
import com.example.methodmesh.settings.MethodSetting
import com.example.methodmesh.settings.SettingsState
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import org.json.JSONObject

object GpsTargetNavigatorCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId: String = As100LocateTargetMethod.ID
    override val title: String = "Target navigator"
    override val description: String = "Live GPS guidance to a coordinate or full Plus Code."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val action = context.action
        val request = context.request
        val androidContext = LocalContext.current
        val nativePresetRun = context.isNativePresetRun
        val interaction = remember { GpsTargetNavigatorInteraction() }
        val settings = remember(action.canonicalId) {
            SettingsState(interaction.settings) { key, value ->
                context.onSettingsChanged(mapOf(key to value.toString()))
            }.also { applyParameters(it, interaction.settings, action.settings) }
        }

        var resultFieldsJson by rememberSaveable(action.canonicalId) { mutableStateOf<String?>(null) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var startRequested by rememberSaveable(action.canonicalId) { mutableStateOf(false) }

        val coordinateKeysPresent = listOf("target_latitude", "input_target_latitude", "latitude", "lat").any(action.settings::containsKey) &&
            listOf("target_longitude", "input_target_longitude", "longitude", "lon", "lng").any(action.settings::containsKey)
        val hasConfiguredTarget = settings.getString("target_plus_code").isNotBlank() || coordinateKeysPresent ||
            settings.getFloat("target_latitude") != 0f || settings.getFloat("target_longitude") != 0f
        val destinationHasRuntimeSettings = listOf(
            "target_plus_code",
            "target_name",
            "target_latitude",
            "target_longitude",
            "arrival_radius_m"
        ).any(context::settingIsRuntimeInput)
        var destinationReady by rememberSaveable(action.canonicalId) {
            mutableStateOf(hasConfiguredTarget && (!nativePresetRun || !destinationHasRuntimeSettings))
        }

        val plusCodeRuntime = context.settingIsRuntimeInput("target_plus_code")
        val coordinateRuntime = context.settingIsRuntimeInput("target_latitude") || context.settingIsRuntimeInput("target_longitude")
        var targetMode by rememberSaveable(action.canonicalId) {
            mutableStateOf(
                if (settings.getString("target_plus_code").isNotBlank() || (plusCodeRuntime && !coordinateRuntime)) "plus_code"
                else "coordinates"
            )
        }
        var plusCodeText by rememberSaveable(action.canonicalId) {
            mutableStateOf(settings.getString("target_plus_code"))
        }
        var targetLatitudeText by rememberSaveable(action.canonicalId) {
            mutableStateOf(settings.getFloat("target_latitude").takeIf { it != 0f }?.toString().orEmpty())
        }
        var targetLongitudeText by rememberSaveable(action.canonicalId) {
            mutableStateOf(settings.getFloat("target_longitude").takeIf { it != 0f }?.toString().orEmpty())
        }
        var targetNameText by rememberSaveable(action.canonicalId) {
            mutableStateOf(settings.getString("target_name").ifBlank { "Target location" })
        }
        var arrivalRadiusText by rememberSaveable(action.canonicalId) {
            mutableStateOf(settings.getFloat("arrival_radius_m").toString())
        }
        var targetStatus by rememberSaveable(action.canonicalId) { mutableStateOf("") }

        val restoredResult = remember(resultFieldsJson) {
            resultFieldsJson
                ?.let(::gpsNavigatorFieldsFromJson)
                ?.let { As100LocateTargetMethod.navigationOutcomeResult(it) }
                ?.withInvocationContext(request.invocationContext)
        }
        val capturedResult = result ?: restoredResult

        fun storeResult(execution: ExecutionResult): ExecutionResult {
            val withContext = execution.withInvocationContext(request.invocationContext)
            result = withContext
            resultFieldsJson = gpsNavigatorFieldsToJson(OutputFormatter.fields(withContext, includeProvenance = false))
            return withContext
        }

        fun submitDestination(): Boolean {
            val targetName = targetNameText.trim().ifBlank { "Target location" }
            val radius = arrivalRadiusText.trim().toFloatOrNull()
            if (radius == null || radius !in 1f..500f) {
                targetStatus = "Arrival radius must be between 1 and 500 metres."
                return false
            }
            settings.setFloat("arrival_radius_m", radius)
            settings.setString("target_name", targetName)

            if (targetMode == "plus_code") {
                val plusCode = plusCodeText.trim().uppercase()
                if (plusCode.isBlank()) {
                    targetStatus = "Enter a full Plus Code."
                    return false
                }
                val area = runCatching { OpenLocationCode.decode(plusCode) }.getOrElse { error ->
                    targetStatus = error.message ?: "Plus Code is not valid."
                    return false
                }
                settings.setString("target_plus_code", plusCode)
                settings.setFloat("target_latitude", area.centerLatitude.toFloat())
                settings.setFloat("target_longitude", area.centerLongitude.toFloat())
                targetLatitudeText = "%.7f".format(area.centerLatitude)
                targetLongitudeText = "%.7f".format(area.centerLongitude)
                targetStatus = "Destination resolved locally from Plus Code."
            } else {
                val latitude = targetLatitudeText.trim().toFloatOrNull()
                val longitude = targetLongitudeText.trim().toFloatOrNull()
                if (latitude == null || latitude !in -90f..90f) {
                    targetStatus = "Latitude must be between −90 and 90."
                    return false
                }
                if (longitude == null || longitude !in -180f..180f) {
                    targetStatus = "Longitude must be between −180 and 180."
                    return false
                }
                settings.setString("target_plus_code", "")
                settings.setFloat("target_latitude", latitude)
                settings.setFloat("target_longitude", longitude)
                targetStatus = "Destination set."
            }

            destinationReady = true
            startRequested = true
            return true
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = action.canonicalId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = capturedResult,
            resultPreview = emptyMap(),
            onBack = onBack,
            onRetry = {
                result = null
                resultFieldsJson = null
                startRequested = false
                destinationReady = hasConfiguredTarget && nativePresetRun && !destinationHasRuntimeSettings
                targetStatus = ""
            },
            onConfirm = { capturedResult?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            if (!destinationReady) {
                DestinationDashboardEditor(
                    context = context,
                    targetMode = targetMode,
                    onTargetModeChanged = { targetMode = it },
                    plusCodeText = plusCodeText,
                    onPlusCodeChanged = { plusCodeText = it.uppercase() },
                    targetNameText = targetNameText,
                    onTargetNameChanged = { targetNameText = it },
                    targetLatitudeText = targetLatitudeText,
                    onTargetLatitudeChanged = { targetLatitudeText = it },
                    targetLongitudeText = targetLongitudeText,
                    onTargetLongitudeChanged = { targetLongitudeText = it },
                    arrivalRadiusText = arrivalRadiusText,
                    onArrivalRadiusChanged = { arrivalRadiusText = it },
                    targetStatus = targetStatus,
                    onUseCurrentPosition = {
                        targetStatus = "Getting current position…"
                        useCurrentPosition(
                            context = androidContext,
                            onLocation = { latitude, longitude ->
                                targetMode = "coordinates"
                                targetLatitudeText = latitude.toString()
                                targetLongitudeText = longitude.toString()
                                plusCodeText = ""
                                settings.setString("target_plus_code", "")
                                settings.setFloat("target_latitude", latitude.toFloat())
                                settings.setFloat("target_longitude", longitude.toFloat())
                                settings.setString("target_name", "Current position")
                                targetNameText = "Current position"
                                targetStatus = "Current position loaded as the destination."
                            },
                            onError = { targetStatus = it }
                        )
                    },
                    onStart = { submitDestination() }
                )
            } else {
                NavigationTargetCard(
                    targetName = settings.getString("target_name"),
                    targetPlusCode = settings.getString("target_plus_code"),
                    targetLatitude = settings.getFloat("target_latitude"),
                    targetLongitude = settings.getFloat("target_longitude"),
                    arrivalRadiusMeters = settings.getFloat("arrival_radius_m")
                )
                Spacer(Modifier.height(10.dp))

                val navigationStartsImmediately = context.submitsImmediately ||
                    (nativePresetRun && destinationReady) || startRequested
                interaction.Render(
                    settingsState = settings,
                    startsImmediately = navigationStartsImmediately,
                    onNavigationCommitted = { execution ->
                        val withContext = execution.withInvocationContext(request.invocationContext)
                        if (context.submitsImmediately) {
                            onConfirmed(withContext)
                        } else {
                            storeResult(withContext)
                        }
                    }
                )
            }

            if (capturedResult != null) {
                Spacer(Modifier.height(10.dp))
                CommittedNavigationResultCard(
                    fields = OutputFormatter.fields(capturedResult, includeProvenance = false)
                )
            }
        }
    }

    @Composable
    private fun DestinationDashboardEditor(
        context: CapabilityScreenContext,
        targetMode: String,
        onTargetModeChanged: (String) -> Unit,
        plusCodeText: String,
        onPlusCodeChanged: (String) -> Unit,
        targetNameText: String,
        onTargetNameChanged: (String) -> Unit,
        targetLatitudeText: String,
        onTargetLatitudeChanged: (String) -> Unit,
        targetLongitudeText: String,
        onTargetLongitudeChanged: (String) -> Unit,
        arrivalRadiusText: String,
        onArrivalRadiusChanged: (String) -> Unit,
        targetStatus: String,
        onUseCurrentPosition: () -> Unit,
        onStart: () -> Unit
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("SET DESTINATION", style = MaterialTheme.typography.labelMedium)
                Text(
                    "Where are you going?",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (targetMode == "plus_code") {
                        Button(modifier = Modifier.weight(1f), onClick = { onTargetModeChanged("plus_code") }) {
                            Text("Plus Code")
                        }
                        OutlinedButton(modifier = Modifier.weight(1f), onClick = { onTargetModeChanged("coordinates") }) {
                            Text("Coordinates")
                        }
                    } else {
                        OutlinedButton(modifier = Modifier.weight(1f), onClick = { onTargetModeChanged("plus_code") }) {
                            Text("Plus Code")
                        }
                        Button(modifier = Modifier.weight(1f), onClick = { onTargetModeChanged("coordinates") }) {
                            Text("Coordinates")
                        }
                    }
                }

                if (!context.settingIsFixedInNativePreset("target_name")) {
                    OutlinedTextField(
                        value = targetNameText,
                        onValueChange = onTargetNameChanged,
                        label = { Text("Destination name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                if (targetMode == "plus_code") {
                    if (!context.settingIsFixedInNativePreset("target_plus_code")) {
                        OutlinedTextField(
                            value = plusCodeText,
                            onValueChange = onPlusCodeChanged,
                            label = { Text("Full Plus Code") },
                            supportingText = { Text("Resolved on-device; no network lookup is required.") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!context.settingIsFixedInNativePreset("target_latitude")) {
                            OutlinedTextField(
                                value = targetLatitudeText,
                                onValueChange = onTargetLatitudeChanged,
                                label = { Text("Latitude") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                        if (!context.settingIsFixedInNativePreset("target_longitude")) {
                            OutlinedTextField(
                                value = targetLongitudeText,
                                onValueChange = onTargetLongitudeChanged,
                                label = { Text("Longitude") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = onUseCurrentPosition) {
                        Text("Use my current position")
                    }
                }

                if (!context.settingIsFixedInNativePreset("arrival_radius_m")) {
                    OutlinedTextField(
                        value = arrivalRadiusText,
                        onValueChange = onArrivalRadiusChanged,
                        label = { Text("Arrival radius (m)") },
                        supportingText = { Text("Arrival is flagged when current distance is within this radius.") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                if (targetStatus.isNotBlank()) {
                    Text(targetStatus, style = MaterialTheme.typography.bodyMedium)
                }

                Button(modifier = Modifier.fillMaxWidth(), onClick = onStart) {
                    Text("Start navigation")
                }
            }
        }
    }

    @Composable
    private fun CommittedNavigationResultCard(fields: Map<String, Any?>) {
        val finalDistance = fields["final_distance_m"]?.toString()?.toFloatOrNull()
            ?: fields["distance_m"]?.toString()?.toFloatOrNull()
        val arrived = fields["navigation_completed"]?.toString()
            ?: fields["arrived"]?.toString().orEmpty()
        val latitude = fields["arrival_latitude"]?.toString()
            ?: fields["current_latitude"]?.toString().orEmpty()
        val longitude = fields["arrival_longitude"]?.toString()
            ?: fields["current_longitude"]?.toString().orEmpty()

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("COMMITTED", style = MaterialTheme.typography.labelMedium)
                Text("Navigation result frozen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                if (finalDistance != null) {
                    NavigationMetricCard(
                        label = "Final distance",
                        value = formatNavigationDistance(finalDistance),
                        clipboardValue = formatRawFloat(finalDistance),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NavigationMetricCard(
                        label = "Arrived",
                        value = arrived.ifBlank { "false" },
                        clipboardValue = arrived.ifBlank { "false" },
                        modifier = Modifier.weight(1f)
                    )
                    NavigationMetricCard(
                        label = "Samples",
                        value = fields["sample_count"]?.toString().orEmpty().ifBlank { "0" },
                        clipboardValue = fields["sample_count"]?.toString().orEmpty().ifBlank { "0" },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (latitude.isNotBlank() && longitude.isNotBlank()) {
                    CopyableNavigationValue(
                        label = "Final fix",
                        displayValue = "$latitude, $longitude",
                        clipboardValue = "$latitude,$longitude",
                        monospace = true
                    )
                }
                Text(
                    "Share/save/Done actions are supplied by the MethodMesh result shell; technical JSON remains optional.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    private fun gpsNavigatorFieldsToJson(values: Map<String, Any?>): String =
        JSONObject().apply {
            values.toSortedMap().forEach { (key, value) -> put(key, value?.toString().orEmpty()) }
        }.toString()

    private fun gpsNavigatorFieldsFromJson(json: String): Map<String, Any?> = runCatching {
        val root = JSONObject(json.ifBlank { "{}" })
        buildMap<String, Any?> { root.keys().forEach { key -> put(key, root.optString(key)) } }
    }.getOrDefault(emptyMap())

    private fun applyParameters(
        settingsState: SettingsState,
        settings: List<MethodSetting>,
        parameters: Map<String, String>
    ) {
        val targetPlusCode = parameters["target_plus_code"]
            ?: parameters["input_target_plus_code"]
            ?: parameters["plus_code"]
            ?: parameters["input_plus_code"]
        if (!targetPlusCode.isNullOrBlank()) {
            settingsState.setString("target_plus_code", targetPlusCode.trim().uppercase())
            runCatching { OpenLocationCode.decode(targetPlusCode) }.onSuccess { area ->
                settingsState.setFloat("target_latitude", area.centerLatitude.toFloat())
                settingsState.setFloat("target_longitude", area.centerLongitude.toFloat())
                if (settingsState.getString("target_name").isBlank()) {
                    settingsState.setString("target_name", targetPlusCode.trim().uppercase())
                }
            }
        }
        settings.forEach { setting ->
            val raw = parameters[setting.id]
                ?: parameters["input_${setting.id}"]
                ?: (if (setting.id == "arrival_radius_m") parameters["arrival_radius"] else null)
                ?: (if (setting.id == "arrival_radius_m") parameters["input_arrival_radius"] else null)
                ?: (if (setting.id == "target_latitude") parameters["latitude"] ?: parameters["lat"] else null)
                ?: (if (setting.id == "target_longitude") parameters["longitude"] ?: parameters["lon"] ?: parameters["lng"] else null)
                ?: return@forEach
            when (setting) {
                is MethodSetting.BooleanSetting -> settingsState.setBoolean(setting.id, raw.toBooleanStrictOrNull() ?: raw == "1")
                is MethodSetting.IntSetting -> raw.toIntOrNull()?.let { settingsState.setInt(setting.id, it) }
                is MethodSetting.FloatSetting -> raw.toFloatOrNull()?.let { settingsState.setFloat(setting.id, it) }
                is MethodSetting.TextSetting -> settingsState.setString(setting.id, raw)
                is MethodSetting.ChoiceSetting -> settingsState.setString(setting.id, raw)
                is MethodSetting.MultiChoiceSetting -> settingsState.setString(setting.id, raw)
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun useCurrentPosition(
        context: Context,
        onLocation: (Double, Double) -> Unit,
        onError: (String) -> Unit
    ) {
        val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) {
            onError("Grant location permission in the navigator, then try again.")
            return
        }
        val cancellation = CancellationTokenSource()
        LocationServices.getFusedLocationProviderClient(context)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cancellation.token)
            .addOnSuccessListener { location ->
                if (location == null) onError("A current GPS position is not available yet.")
                else onLocation(location.latitude, location.longitude)
            }
            .addOnFailureListener { error ->
                onError("Could not get current position: ${error.message ?: "location error"}")
            }
    }
}
