# Ham Radio v0.2.0 — deterministic test vectors

| Function | Input | Expected / tolerance |
|---|---|---|
| Maidenhead encode | lat `51.5074`, lon `-0.1278`, precision `6` | `IO91wm` |
| Maidenhead decode/roundtrip | `IO91wm` | centre within roughly 0.03° latitude / 0.05° longitude |
| Great-circle path | London -> NYC | ~5570 km; initial bearing ~288° |
| Dipole | `14.2 MHz`, factor `0.95` | total ~10.03 m; leg ~5.02 m |
| SWR | forward `100 W`, reflected `4 W` | gamma `0.2`; SWR `1.5:1` |
| FSPL | `145 MHz`, `25 km` | ~103.63 dB |
| Horizon | TX/RX heights `10 m` | radio horizon > optical horizon |
| Daylight DX heuristic | London, 2026-06-21 12:00Z, 5000 km, Kp 2, F10.7 180, R0, SSB | top band in 20/17/15/12/10 m set |
| Short-path night heuristic | London, 2026-12-21 00:00Z, 300 km, Kp 2, F10.7 90, R0 | top band in 160/80/60/40 m set |

## PSK Reporter hard-gate vector

Use a fake HTTP client and mutable UTC clock, starting `2026-09-04T10:00:00Z`.

| Step | Query/time | Expected | Upstream GETs |
|---|---|---|---:|
| 1 | `M0AAA`, T+0 | `succeeded` | 1 |
| 2 | same query, T+60 s | cached `succeeded`, retry-after 360 | 1 |
| 3 | `M0CCC`, T+60 s | `rate_limited`, retry-after 360 | 1 |
| 4 | same time through a new repository instance | `rate_limited`; instance cannot bypass gate | unchanged |
| 5 | `M0CCC`, T+420 s | `succeeded` | +1 |
| 6 | forced HTTP failure when gate next opens | `failed`; slot still reserved | +1 |
| 7 | different query +60 s after failure | `rate_limited`; no GET | unchanged |

Also assert the public rate-limit field is exactly `420`, matching cached reports may be returned without a GET during lockout, and concurrent calls cannot create two upstream requests inside the interval.

HF heuristic tests should assert broad ordering rather than every score; score-weight changes require an explicit heuristic-version change.
