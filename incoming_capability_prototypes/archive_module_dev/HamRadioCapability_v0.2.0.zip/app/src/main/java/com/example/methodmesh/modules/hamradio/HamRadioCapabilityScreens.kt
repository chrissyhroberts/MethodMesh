package com.example.methodmesh.modules.hamradio

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

private data class HamScreenField(
    val key: String,
    val label: String,
    val defaultValue: String,
    val help: String = "",
    val numeric: Boolean = false,
    val visibleWhen: (Map<String, String>) -> Boolean = { true }
)

private class HamRadioFormScreen(
    override val capabilityId: String,
    override val title: String,
    override val description: String,
    private val method: As100Method,
    private val fields: List<HamScreenField>,
    private val actionLabel: String,
    private val network: Boolean,
    private val supportingText: String = "",
    private val resultBuilder: (ExecutionRequest, Map<String, String>, InvocationContext?) -> ExecutionResult
) : CapabilityScreenSpec {
    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        fun initial(key: String, default: String): String =
            context.action.settings[key] ?: context.action.settings["input_$key"] ?: default

        fun encode(values: Map<String, String>): String = JSONObject(values).toString()
        fun decode(json: String): Map<String, String> {
            if (json.isBlank()) return emptyMap()
            val obj = JSONObject(json)
            return obj.keys().asSequence().associateWith { key -> obj.optString(key, "") }
        }

        val initialSettings = remember(context.action.canonicalId) {
            fields.associate { it.key to initial(it.key, it.defaultValue) }
        }
        var settingsJson by rememberSaveable(context.action.canonicalId) { mutableStateOf(encode(initialSettings)) }
        var valuesJson by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        // Running is deliberately not saveable. If Android recreates the screen while a
        // blocking provider call is in flight, the new composition may safely retry when
        // no result values were saved. Provider-side gates (notably PSK Reporter) remain
        // authoritative at the network boundary.
        var running by remember { mutableStateOf(false) }
        var localStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        val scope = rememberCoroutineScope()

        fun currentSettings(): Map<String, String> = decode(settingsJson)
        fun update(key: String, value: String) {
            val next = currentSettings().toMutableMap().apply { this[key] = value }
            settingsJson = encode(next)
            context.onSettingsChanged(mapOf(key to value))
        }
        fun requestFor(settings: Map<String, String>) = method.request(
            action = capabilityId,
            context = context.request.invocationContext.asMap(capabilityId) + context.action.settings + settings,
            signals = emptyList(),
            inputs = emptyList()
        )

        val reconstructedResult: ExecutionResult? = remember(valuesJson, settingsJson, context.action.canonicalId) {
            if (valuesJson.isBlank()) null else resultBuilder(
                requestFor(currentSettings()),
                decode(valuesJson),
                context.request.invocationContext
            )
        }

        fun runCapability() {
            if (running) return
            val settings = currentSettings()
            val request = requestFor(settings)
            running = true
            localStatus = if (network) "Retrieving…" else "Calculating…"
            scope.launch {
                val execution = runCatching {
                    withContext(if (network) Dispatchers.IO else Dispatchers.Default) {
                        method.execute(request, settingsState = null, transport = null)
                    }
                }
                execution.onSuccess { result ->
                    val values = OutputFormatter.fields(result, includeProvenance = false)
                        .mapValues { (_, value) -> value?.toString().orEmpty() }
                    valuesJson = encode(values)
                    localStatus = values.entries.firstOrNull { it.key.endsWith("_status") }?.value.orEmpty().ifBlank { "Done." }
                }.onFailure { error ->
                    localStatus = "Error: ${error.message ?: "execution failed"}"
                }
                running = false
            }
        }

        LaunchedEffect(context.presentationMode, context.completionMode, context.action.settings, valuesJson) {
            if (
                context.submitsImmediately &&
                context.presentationMode == CapabilityPresentationMode.IntentLaunch &&
                valuesJson.isBlank() &&
                !running
            ) {
                runCapability()
            }
        }

        val preview = reconstructedResult?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty()
        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = reconstructedResult,
            resultPreview = preview,
            onBack = onBack,
            onRetry = { valuesJson = ""; localStatus = "" },
            onConfirm = { reconstructedResult?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text(description, style = MaterialTheme.typography.bodyMedium)
            if (supportingText.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(supportingText, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.height(10.dp))

            val settings = currentSettings()
            fields.filter { field -> field.visibleWhen(settings) && context.settingShouldBeShown(field.key) }.forEach { field ->
                OutlinedTextField(
                    value = settings[field.key].orEmpty(),
                    onValueChange = { raw -> update(field.key, if (field.numeric) raw.numericText() else raw) },
                    label = { Text(field.label) },
                    supportingText = if (field.help.isBlank()) null else ({ Text(field.help) }),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    singleLine = true
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { runCapability() }, enabled = !running, modifier = Modifier.fillMaxWidth()) {
                Text(if (running) "Working…" else if (reconstructedResult == null) actionLabel else "$actionLabel again")
            }
            if (localStatus.isNotBlank()) Text(localStatus, modifier = Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun String.numericText(): String = filter { it.isDigit() || it == '-' || it == '.' }.let { filtered ->
    val minus = if (filtered.startsWith("-")) "-" else ""
    val body = filtered.removePrefix("-")
    minus + body.split('.').let { parts ->
        parts.firstOrNull().orEmpty() + if (parts.size > 1) "." + parts.drop(1).joinToString("") else ""
    }
}

val HamSpaceWeatherCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamSpaceWeatherMethod.ID,
    title = "Space weather",
    description = "Read current Kp, solar flux, NOAA G/R/S scales and solar-wind context.",
    method = As100HamSpaceWeatherMethod,
    fields = listOf(HamScreenField("refresh_mode", "Refresh mode", "cache_preferred", "cache_preferred or fresh_required")),
    actionLabel = "Read space weather",
    network = true,
    supportingText = "Provider: NOAA SWPC. Your QTH is not sent to NOAA.",
    resultBuilder = As100HamSpaceWeatherMethod::result
)

val HamPskReporterCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamPskReporterMethod.ID,
    title = "PSK Reporter activity",
    description = "Read recent observed reception reports for a callsign or Maidenhead grid.",
    method = As100HamPskReporterMethod,
    fields = listOf(
        HamScreenField("subject_type", "Subject type", "callsign", "callsign or grid"),
        HamScreenField("subject", "Callsign or grid", "", "This value is sent to PSK Reporter."),
        HamScreenField("direction", "Direction", "sent", "sent, received or either"),
        HamScreenField("lookback_minutes", "Look back (minutes)", "30", "5–1440", numeric = true),
        HamScreenField("mode", "Mode filter", "", "Blank = any; examples: FT8, FT4, CW"),
        HamScreenField("min_frequency_mhz", "Minimum frequency (MHz)", "0", "0 = no frequency filter", numeric = true),
        HamScreenField("max_frequency_mhz", "Maximum frequency (MHz)", "0", "0 = no frequency filter", numeric = true),
        HamScreenField("record_limit", "Maximum reports", "100", "1–100", numeric = true),
        HamScreenField("include_no_locator", "Include reports without locator", "no", "no or yes")
    ),
    actionLabel = "Read PSK Reporter",
    network = true,
    supportingText = "Hard upstream request floor: one PSK Reporter request per 7 minutes (420 s). Identical requests reuse cache during the lockout; uncached alternatives return retry-after rather than bypassing the gate.",
    resultBuilder = As100HamPskReporterMethod::result
)

val HamBandAdviceCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamBandAdviceMethod.ID,
    title = "Best HF bands now",
    description = "Rank HF bands using path length, local solar geometry and live/manual space weather.",
    method = As100HamBandAdviceMethod,
    fields = listOf(
        HamScreenField("location_mode", "QTH input", "locator", "locator or coordinates"),
        HamScreenField("origin_locator", "Origin Maidenhead locator", "", visibleWhen = { it["location_mode"] != "coordinates" }),
        HamScreenField("latitude", "Origin latitude", "0", numeric = true, visibleWhen = { it["location_mode"] == "coordinates" }),
        HamScreenField("longitude", "Origin longitude", "0", numeric = true, visibleWhen = { it["location_mode"] == "coordinates" }),
        HamScreenField("target_locator", "Target locator", "", "Optional"),
        HamScreenField("target_distance_km", "Target distance (km)", "2000", "Used when target locator is blank", numeric = true),
        HamScreenField("conditions_source", "Conditions", "live_noaa", "live_noaa or manual"),
        HamScreenField("kp", "Manual Kp", "2", numeric = true, visibleWhen = { it["conditions_source"] == "manual" }),
        HamScreenField("f107", "Manual F10.7", "100", numeric = true, visibleWhen = { it["conditions_source"] == "manual" }),
        HamScreenField("r_scale", "Manual NOAA R scale", "0", numeric = true, visibleWhen = { it["conditions_source"] == "manual" }),
        HamScreenField("mode", "Mode", "mixed", "mixed, ssb, cw, ft8, ft4 or digital"),
        HamScreenField("when_iso", "UTC ISO time", "", "Blank = now")
    ),
    actionLabel = "Rank bands",
    network = true,
    supportingText = "The score is a lightweight heuristic, not MUF/VOACAP/reliability or permission to transmit on the representative frequency.",
    resultBuilder = As100HamBandAdviceMethod::result
)

val HamMaidenheadCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamMaidenheadMethod.ID,
    title = "Maidenhead converter",
    description = "Encode WGS84 coordinates to a locator or decode a locator to its cell centre.",
    method = As100HamMaidenheadMethod,
    fields = listOf(
        HamScreenField("operation", "Operation", "encode", "encode or decode"),
        HamScreenField("latitude", "Latitude", "0", numeric = true, visibleWhen = { it["operation"] != "decode" }),
        HamScreenField("longitude", "Longitude", "0", numeric = true, visibleWhen = { it["operation"] != "decode" }),
        HamScreenField("precision", "Locator characters", "6", "2, 4, 6 or 8", numeric = true, visibleWhen = { it["operation"] != "decode" }),
        HamScreenField("locator", "Locator", "", visibleWhen = { it["operation"] == "decode" })
    ),
    actionLabel = "Convert",
    network = false,
    resultBuilder = As100HamMaidenheadMethod::result
)

val HamPathCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamPathMethod.ID,
    title = "Radio path",
    description = "Calculate great-circle distance and initial bearings between Maidenhead locator cell centres.",
    method = As100HamPathMethod,
    fields = listOf(
        HamScreenField("origin_locator", "Origin locator", ""),
        HamScreenField("destination_locator", "Destination locator", "")
    ),
    actionLabel = "Calculate path",
    network = false,
    resultBuilder = As100HamPathMethod::result
)

val HamAntennaCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamAntennaMethod.ID,
    title = "Antenna length",
    description = "Calculate wavelength-derived starting dimensions; cut long and tune in the real installation.",
    method = As100HamAntennaMethod,
    fields = listOf(
        HamScreenField("frequency_mhz", "Frequency (MHz)", "14.2", numeric = true),
        HamScreenField("design", "Design", "dipole", "quarter_wave, half_wave, dipole, five_eighths or full_wave"),
        HamScreenField("velocity_factor", "Velocity/end-effect factor", "0.95", numeric = true)
    ),
    actionLabel = "Calculate antenna",
    network = false,
    resultBuilder = As100HamAntennaMethod::result
)

val HamSwrCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamSwrMethod.ID,
    title = "SWR calculator",
    description = "Calculate reflection coefficient, SWR, return loss and mismatch loss from power readings.",
    method = As100HamSwrMethod,
    fields = listOf(
        HamScreenField("forward_power_w", "Forward power (W)", "100", numeric = true),
        HamScreenField("reflected_power_w", "Reflected power (W)", "4", numeric = true)
    ),
    actionLabel = "Calculate SWR",
    network = false,
    resultBuilder = As100HamSwrMethod::result
)

val HamLinkCapabilityScreen: CapabilityScreenSpec = HamRadioFormScreen(
    capabilityId = As100HamLinkMethod.ID,
    title = "RF link / Fresnel",
    description = "Calculate free-space path loss, horizon and midpoint first-Fresnel radius with optional TX-side link budget.",
    method = As100HamLinkMethod,
    fields = listOf(
        HamScreenField("frequency_mhz", "Frequency (MHz)", "145", numeric = true),
        HamScreenField("distance_km", "Distance (km)", "25", numeric = true),
        HamScreenField("tx_height_m", "TX antenna height (m)", "10", numeric = true),
        HamScreenField("rx_height_m", "RX antenna height (m)", "10", numeric = true),
        HamScreenField("tx_power_w", "TX power (W)", "0", "0 = omit EIRP/received-power calculation", numeric = true),
        HamScreenField("antenna_gain_dbi", "TX antenna gain (dBi)", "0", numeric = true),
        HamScreenField("feedline_loss_db", "TX feedline loss (dB)", "0", numeric = true)
    ),
    actionLabel = "Calculate link",
    network = false,
    resultBuilder = As100HamLinkMethod::result
)
