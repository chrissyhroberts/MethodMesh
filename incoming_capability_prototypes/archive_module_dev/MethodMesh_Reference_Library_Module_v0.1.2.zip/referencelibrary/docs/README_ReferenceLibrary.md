# MethodMesh Reference Library

**Module ID:** `referencelibrary`  
**Method ID:** `reference.library.open`  
**Status:** Development  
**Version:** 0.1.2

## Purpose

Reference Library is the offline-first home for useful documents inside MethodMesh. It is deliberately not an emergency-monitoring capability. Its job is narrower: make manuals, field guides, procedures, reference cards and user documents quick to find and open.

The native surface is a library, not a settings form. Search, recent documents, shelf filters and document cards are shown on one screen. Imported files use Android's Storage Access Framework and persist read permission, so the app does not need to duplicate large PDFs into private storage.

## Shelves

- First aid
- Medical
- Safety
- Fieldwork
- Equipment
- Travel
- Personal

Shelves are presentation metadata, not hard security boundaries.

## Native workflow

Direct MethodMesh use is dashboard-style and persistent. It does **not** create a generic MethodMesh result merely because the operator opens a document.

1. Open Reference Library.
2. Search or select a shelf.
3. Tap a document card to open it with an Android document viewer.
4. Return from the viewer to the same Reference Library dashboard state.
5. Star frequently used documents.
6. Use **Add document** to import a PDF, text file or image.

The most recently opened documents are promoted into **Continue reading**. Direct dashboard use has no library-specific Confirm/Done conclusion step. Result/closeout behaviour is reserved for presets, protocols, ODK and other external launches that need a selected document returned to their caller.

## Persistence

The repository stores metadata in module-owned SharedPreferences and requests retained SAF read access to imported URIs. The original document remains in its original Android storage location. If the selected document provider does not support persistable access, the library reports that long-term access depends on that provider. Removing the library entry does not delete the underlying file.

This v0.1.2 implementation does **not** copy user documents into MethodMesh storage and does not synchronize them to cloud services.

## Presets and protocols

A preset may supply `document_id`, `query` and `shelf`. Fixed preset settings are transported through the normal MethodMesh capability context. A known `document_id` can resolve directly when the capability is launched by an intent.

Library entries are device-local. A `document_id` is therefore not portable between phones unless a future managed pack installs stable IDs.

## ODK / XLSForm

External callers use method ID `reference.library.open`.

Inputs:

- `input_document_id` — optional device-local document ID
- `input_query` — optional search string
- `input_shelf` — optional shelf ID

Outputs:

- `library_status`
- `library_document_id`
- `library_document_title`
- `library_document_uri`
- `library_document_mime`
- `library_shelf`
- `library_source`
- `library_version`
- `library_error`

The main useful result is the selected document URI/title. The URI remains subject to Android URI permission semantics; callers should not assume permanent cross-app access beyond the normal MethodMesh transport grant.

## Deliberate boundaries

This module does not contain:

- hazard monitoring or RAG status;
- emergency navigation or exit strategy;
- emergency numbers;
- location tracking;
- persistent emergency notifications;
- an encrypted identity-document vault.

Those belong in a separate Emergency capability. Emergency may later deep-link to stable Reference Library document IDs/packs rather than duplicating content.

## Next implementation steps

Before Production: add managed/bundled document packs with stable IDs and manifests; add a first-party in-app PDF/text reader; add document metadata editing; add pack provenance/checksum/version UI; test URI persistence across reboot/provider changes; test native/preset/protocol/ODK roundtrips and rotation; confirm accessibility and large-library performance.


## v0.1.1 review changes

- separates native **open/read** behaviour from external/ODK **select/return** behaviour;
- returns explicit `not_found` and `unavailable` results for broken device-local document IDs;
- verifies URI readability before opening or auto-returning a stored document;
- avoids duplicate library entries when the same URI is imported again;
- adds remove-from-library without deleting the source file;
- adds shelf counts, selected-state feedback and clearer empty/search states;
- adds document `source` and `version` outputs for future managed packs;
- preserves existing records while adding an `added` timestamp field;
- updates the ODK example output schema to match the method contract.


## v0.1.2 dashboard-flow changes

- direct MethodMesh dashboard use no longer creates a capture result when a document is opened;
- direct dashboard use bypasses the generic `CapabilityScreenScaffold` confirm/result surface, removing the Cancel/Done conclusion controls from the library itself;
- opening a document records recency, launches the Android reader and returns naturally to the same dashboard state;
- adding a document in direct dashboard use stays in the library instead of immediately producing a selected-document result;
- unreadable documents in direct dashboard use report an inline library status rather than routing to a failed result screen;
- intent, ODK, preset and protocol launches retain the established select/return closeout contract;
- method and XLSForm example versions updated to 0.1.2.
