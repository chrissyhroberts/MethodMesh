# Reference Library architecture — v0.2.0

## Boundary

`referencelibrary` owns document-library metadata, shelves, dashboard presentation, scanner-to-shelf persistence, local document resolution and the generic document-email handoff. It does not own document scanning internals, electronic-signature logic, PDF merge logic, ODK form data, study-specific consent language, SMTP infrastructure or delivery confirmation.

## Public methods

### `reference.library.open`

Resolves/returns one local reference document. Direct dashboard reading does not create a result; external/preset/protocol/ODK launches use the MethodMesh result contract.

### `reference.library.email`

Resolves library IDs plus optional piped attachment URIs and performs a user-visible Android `ACTION_SEND_MULTIPLE` handoff. It can populate To/Cc/Bcc/subject/body. Return semantics deliberately distinguish **mail-app handoff** from **email delivery**.

## Composition pattern for consent

The intended composition is capability-to-capability rather than monolithic consent code:

`ODK fields -> signature/witness capability -> PDF merge/final document URI -> reference.library.email`

Static study documents can come from library IDs while the participant-specific signed PDF comes from a piped URI. This keeps study configuration in ODK/protocols and document storage in the library.

## UI doctrine

The native dashboard is a persistent control surface. It avoids per-document cards with stacked buttons. Rows are primarily for reading; secondary actions are hidden behind one overflow affordance. Continue reading uses compact tiles. Search and shelf filtering dominate the top of the screen. Scan/Add are the only persistent action buttons.

## Storage

External documents retain their Android content URIs. Scanner results are cache-backed and are therefore copied to `filesDir/reference_library/scans` before shelving. FileProvider exposes managed copies through the existing app provider.

## Stable built-in shelves

`first_aid`, `medical`, `safety`, `fieldwork`, `equipment`, `travel`, `personal`.

Custom shelf IDs are persisted locally and are intentionally not declared as fixed `ChoiceSetting` values, because dynamic user-created choices cannot be part of the static capability settings contract. External callers should use known built-in shelf IDs or stable document IDs.
