package com.example.methodmesh.modules.referencelibrary

import android.app.Activity
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

object ReferenceLibraryEmailCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ReferenceLibraryEmailMethod.ID
    override val title = "Email library documents"
    override val description = "Prepare an email with selected library documents or piped attachment URIs."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val repository = remember { ReferenceLibraryRepository(appContext) }
        fun initial(key: String): String = context.action.settings[key] ?: context.action.settings["input_$key"] ?: ""

        var documentIdsText by rememberSaveable { mutableStateOf(initial("document_ids")) }
        var attachmentUrisText by rememberSaveable { mutableStateOf(initial("attachment_uris")) }
        var recipient by rememberSaveable { mutableStateOf(initial("recipient")) }
        var cc by rememberSaveable { mutableStateOf(initial("cc")) }
        var bcc by rememberSaveable { mutableStateOf(initial("bcc")) }
        var subject by rememberSaveable { mutableStateOf(initial("subject")) }
        var body by rememberSaveable { mutableStateOf(initial("body")) }
        var chooserTitle by rememberSaveable { mutableStateOf(initial("chooser_title").ifBlank { "Send document copies" }) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var pendingDocumentIds by remember { mutableStateOf<List<String>>(emptyList()) }
        var pendingUris by remember { mutableStateOf<List<String>>(emptyList()) }
        var pendingMissing by remember { mutableStateOf<List<String>>(emptyList()) }
        var status by rememberSaveable { mutableStateOf("Ready to prepare email.") }

        fun settingsMap() = mapOf(
            "document_ids" to documentIdsText,
            "attachment_uris" to attachmentUrisText,
            "recipient" to recipient,
            "cc" to cc,
            "bcc" to bcc,
            "subject" to subject,
            "body" to body,
            "chooser_title" to chooserTitle
        )

        fun buildResult(statusValue: String, handoff: String, error: String = ""): ExecutionResult {
            val request = As100ReferenceLibraryEmailMethod.request(
                action = As100ReferenceLibraryEmailMethod.ID,
                context = context.request.invocationContext.asMap(As100ReferenceLibraryEmailMethod.ID) + context.action.settings + settingsMap(),
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100ReferenceLibraryEmailMethod.result(
                request,
                As100ReferenceLibraryEmailMethod.values(
                    status = statusValue,
                    recipient = recipient.trim(),
                    subject = subject,
                    documentIds = pendingDocumentIds,
                    attachmentUris = pendingUris,
                    missingDocumentIds = pendingMissing,
                    handoff = handoff,
                    error = error
                ),
                context.request.invocationContext
            )
        }

        val mailLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { activityResult ->
            val handoff = if (activityResult.resultCode == Activity.RESULT_CANCELED) "returned_from_mail_app" else "returned_from_mail_app"
            val execution = buildResult("handoff_returned", handoff)
            result = execution
            status = "Returned from mail app. MethodMesh cannot verify that the message was sent or delivered."
            if (context.submitsImmediately) onConfirmed(execution)
        }

        fun launchEmail() {
            val requestedIds = As100ReferenceLibraryEmailMethod.parseIds(documentIdsText)
            val resolved = requestedIds.mapNotNull(repository::document).filter(repository::isReadable)
            val resolvedIds = resolved.map { it.id }
            val missing = requestedIds.filterNot { it in resolvedIds }
            val directUris = As100ReferenceLibraryEmailMethod.parseUris(attachmentUrisText)
            val uris = (resolved.map { it.uri } + directUris).distinct()

            pendingDocumentIds = resolvedIds
            pendingMissing = missing
            pendingUris = uris

            val validationError = when {
                recipient.isBlank() -> "Recipient email is required."
                uris.isEmpty() -> "At least one readable library document or attachment URI is required."
                missing.isNotEmpty() -> "Some requested library documents are missing or unreadable: ${missing.joinToString(", ")}"
                else -> ""
            }
            if (validationError.isNotBlank()) {
                val execution = buildResult("failed", "not_started", validationError)
                result = execution
                status = validationError
                if (context.submitsImmediately) onConfirmed(execution)
                return
            }

            val parsedUris = uris.map(Uri::parse)
            val sendIntent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = if (resolved.all { it.mimeType == "application/pdf" } && directUris.isEmpty()) "application/pdf" else "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(parsedUris))
                putExtra(Intent.EXTRA_EMAIL, parseAddresses(recipient))
                if (cc.isNotBlank()) putExtra(Intent.EXTRA_CC, parseAddresses(cc))
                if (bcc.isNotBlank()) putExtra(Intent.EXTRA_BCC, parseAddresses(bcc))
                if (subject.isNotBlank()) putExtra(Intent.EXTRA_SUBJECT, subject)
                if (body.isNotBlank()) putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                parsedUris.firstOrNull()?.let { first ->
                    clipData = ClipData.newUri(appContext.contentResolver, "MethodMesh document", first).also { clip ->
                        parsedUris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
                    }
                }
            }
            runCatching {
                mailLauncher.launch(Intent.createChooser(sendIntent, chooserTitle.ifBlank { "Send document copies" }))
                status = "Opening mail app…"
            }.onFailure { error ->
                val execution = buildResult("failed", "not_started", error.message ?: "No compatible mail app is available.")
                result = execution
                status = error.message ?: "No compatible mail app is available."
                if (context.submitsImmediately) onConfirmed(execution)
            }
        }

        val runtimeSettingsVisible = listOf(
            "document_ids", "attachment_uris", "recipient", "cc", "bcc", "subject", "body", "chooser_title"
        ).any(context::settingIsRuntimeInput)

        LaunchedEffect(documentIdsText, attachmentUrisText, recipient, cc, bcc, subject, body, chooserTitle) {
            context.onSettingsChanged(settingsMap())
        }

        LaunchedEffect(context.startsImmediately, runtimeSettingsVisible, context.action.settings) {
            if (context.startsImmediately && !runtimeSettingsVisible && !launched) {
                launched = true
                launchEmail()
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { launched = true; launchEmail() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text(
                "Choose library document IDs and/or pass attachment URIs from an earlier MethodMesh step. The final message is handed to an installed mail app for the user to review and send.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(10.dp))
            if (!context.settingIsFixedInNativePreset("document_ids")) {
                OutlinedTextField(documentIdsText, { documentIdsText = it }, label = { Text("Library document IDs") }, modifier = Modifier.fillMaxWidth())
            }
            if (!context.settingIsFixedInNativePreset("attachment_uris")) {
                OutlinedTextField(attachmentUrisText, { attachmentUrisText = it }, label = { Text("Additional attachment URIs") }, modifier = Modifier.fillMaxWidth())
            }
            if (!context.settingIsFixedInNativePreset("recipient")) {
                OutlinedTextField(recipient, { recipient = it }, label = { Text("To") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (!context.settingIsFixedInNativePreset("cc")) {
                OutlinedTextField(cc, { cc = it }, label = { Text("Cc") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (!context.settingIsFixedInNativePreset("bcc")) {
                OutlinedTextField(bcc, { bcc = it }, label = { Text("Bcc") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (!context.settingIsFixedInNativePreset("subject")) {
                OutlinedTextField(subject, { subject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (!context.settingIsFixedInNativePreset("body")) {
                OutlinedTextField(body, { body = it }, label = { Text("Message") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
            }
            Spacer(Modifier.height(10.dp))
            if (!context.startsImmediately || runtimeSettingsVisible || result != null) {
                Button(onClick = { launched = true; launchEmail() }, modifier = Modifier.fillMaxWidth()) { Text("Review email") }
            }
            Text(status, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun parseAddresses(raw: String): Array<String> = raw
    .split(',', ';', '\n')
    .map { it.trim() }
    .filter { it.isNotBlank() }
    .toTypedArray()
