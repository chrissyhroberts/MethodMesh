# GameDeck v0.050

GameDeck is MethodMesh's lightweight tabletop, puzzle and GameLab capability. It uses the normal MethodMesh module/method/screen discovery model: the runtime does not know what GameDeck is.

## Presentation invariants

- Active games use the generic `CapabilityHostPresentation.Immersive` host contract.
- Gameplay surfaces do not scroll. The launcher may scroll as the shelf grows.
- Two humans sharing one device own opposite ends of the table. Player 2's player-facing rail is rotated 180 degrees; Player 1's is upright.
- CPU opponents use the far rail but remain upright, because nobody is physically sitting opposite the device.
- The board remains stable unless a game's mechanics genuinely require rotation.
- Game-management actions stay behind the small tabletop menu rather than consuming board space.
- Winner/result state is explicit and overlaid rather than appended below the board.

## Playable games

### Original shelf

- Connect Four — 2P tabletop
- Snakes & Ladders — 2P, Chance-backed D6, manual token movement
- Mancala / Kalah — 1P CPU or 2P
- Minesweeper / GameLab — procedural validated boards

### v0.050 expansion

- Tic Tac Toe — 1P CPU or 2P
- Reversi — 1P CPU or 2P
- Nim — 1P CPU or 2P
- Memory Pairs — 2P
- Lights Out — solo puzzle
- 15 Puzzle — solvable shuffled solo puzzle
- Shut the Box — Chance-backed dice puzzle
- Codebreaker — four-symbol deduction puzzle

## CPU framework

`GameDeckAgents.kt` introduces named CPU profiles and a shared game-agent boundary. The first adapters cover Tic Tac Toe, Reversi and Nim. Agents choose actions; they do not own game state. The rules engine remains authoritative.

This is deliberately the same separation required for future remote/P2P play: human input, CPU input and peer input should all become ordered actions applied by the same deterministic rules layer.

## CPU Arena / simulator

`GameDeckSimulator.kt` runs headless matches using the same rules functions used by the visible games. The launcher exposes **CPU Arena**, currently supporting Tic Tac Toe, Nim and Reversi. A 100-match series reports P1/P2 wins, draws and mean move count.

This is the first executable slice of GameLab's broader simulation model:

1. generate or select a state/ruleset;
2. assign agents;
3. simulate;
4. measure outcomes and decision structure;
5. reject/accept generated scenarios or compare rule variants.

## Player record

`GameDeckStatsStore` provides a small local-first record using Android `SharedPreferences`. Finishing games records games/wins/losses/draws and per-game play counts. It also accumulates coarse cross-game skill evidence such as planning, tactics, spatial reasoning, deduction, memory and resource management.

This is intentionally evidence, not a hidden difficulty score. The roadmap is to add uncertainty/confidence, difficulty-adjusted evidence, high scores, achievements and explicit player profiles.

## Randomness

GameDeck does not duplicate MethodMesh's Chance engine. Dice and seeded/shuffled setup call the public Chance method boundary (`As100DiceSimulationMethod`). Secure runtime randomness and fixed-seed reproducibility remain distinct concepts.

## External snapshot contract

Method: `gamedeck.snapshot`

Native dashboard/preset use remains live until the user explicitly finishes. External/ODK use returns a structured snapshot including the complete JSON game state and audit metadata. See `example_odk_GameDeck.xlsx`.

## Architecture rule

> Games own mechanics. GameDeck owns identity, persistence, input, animation, randomness, records and presentation.

And the MethodMesh golden rule remains intact:

> Capabilities may describe how they want to be hosted; the host must not know why.
