package com.example.methodmesh.modules.gamedeck

/** Shared CPU-player vocabulary. Games expose legal actions; agents choose among them. */
enum class GameDeckCpuLevel { Casual, Standard, Sharp }

data class GameDeckAgentProfile(
    val id: String,
    val label: String,
    val level: GameDeckCpuLevel,
    val description: String
)

object GameDeckAgents {
    val CASUAL = GameDeckAgentProfile("casual", "Casual CPU", GameDeckCpuLevel.Casual, "Takes legal moves with only immediate tactics.")
    val STANDARD = GameDeckAgentProfile("standard", "Standard CPU", GameDeckCpuLevel.Standard, "Uses game-specific heuristics and obvious blocks.")
    val SHARP = GameDeckAgentProfile("sharp", "Sharp CPU", GameDeckCpuLevel.Sharp, "Uses stronger deterministic look-ahead where the game adapter supports it.")
    val profiles = listOf(CASUAL, STANDARD, SHARP)

    fun choose(game: String, stateJson: String, profile: GameDeckAgentProfile = STANDARD): String? = when (game) {
        GameDeckExtraEngine.TIC_TAC_TOE -> GameDeckExtraEngine.ticTacToeCpuChoice(stateJson).takeIf { it >= 0 }?.toString()
        GameDeckExtraEngine.REVERSI -> GameDeckExtraEngine.reversiCpuChoice(stateJson).takeIf { it >= 0 }?.toString()
        GameDeckExtraEngine.NIM -> GameDeckExtraEngine.nimCpuChoice(stateJson).let { (heap, take) -> if (heap >= 0) "$heap:$take" else null }
        else -> null
    }
}
