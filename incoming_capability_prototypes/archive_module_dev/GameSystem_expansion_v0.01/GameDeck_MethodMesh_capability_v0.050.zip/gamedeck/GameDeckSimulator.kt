package com.example.methodmesh.modules.gamedeck

import org.json.JSONObject

/** Headless CPU-vs-CPU simulator. The same rules functions used by the UI are used here. */
data class SimMatchResult(val winner: String, val moves: Int)
data class SimSeriesResult(val game: String, val games: Int, val p1Wins: Int, val p2Wins: Int, val draws: Int, val meanMoves: Double)

object GameDeckSimulator {
    fun runSeries(game: String, games: Int = 100): SimSeriesResult {
        var p1 = 0; var p2 = 0; var draws = 0; var totalMoves = 0
        repeat(games.coerceIn(1, 5000)) {
            val r = runMatch(game)
            when (r.winner) { "1" -> p1++; "2" -> p2++; else -> draws++ }
            totalMoves += r.moves
        }
        val n = games.coerceIn(1, 5000)
        return SimSeriesResult(game, n, p1, p2, draws, totalMoves.toDouble() / n)
    }

    fun runMatch(game: String, maxMoves: Int = 512): SimMatchResult {
        var state = GameDeckExtraEngine.newStateJson(game, "fixed_seed", "sim")
        var guard = 0
        while (JSONObject(state).optString("winner").isBlank() && guard++ < maxMoves) {
            state = when (game) {
                GameDeckExtraEngine.TIC_TAC_TOE -> {
                    val cell = GameDeckExtraEngine.ticTacToeCpuChoice(state, JSONObject(state).optInt("turn", 1))
                    if (cell < 0) state else GameDeckExtraEngine.ticTacToeMove(state, cell)
                }
                GameDeckExtraEngine.REVERSI -> {
                    val p = JSONObject(state).optInt("turn", 1)
                    val cell = GameDeckExtraEngine.reversiCpuChoice(state, p)
                    if (cell < 0) break else GameDeckExtraEngine.reversiMove(state, cell)
                }
                GameDeckExtraEngine.NIM -> {
                    val (heap, take) = GameDeckExtraEngine.nimCpuChoice(state)
                    if (heap < 0) state else GameDeckExtraEngine.nimMove(state, heap, take)
                }
                else -> return SimMatchResult("unsupported", guard - 1)
            }
        }
        val s = JSONObject(state)
        return SimMatchResult(s.optString("winner").ifBlank { "draw" }, s.optInt("moves", guard))
    }
}
