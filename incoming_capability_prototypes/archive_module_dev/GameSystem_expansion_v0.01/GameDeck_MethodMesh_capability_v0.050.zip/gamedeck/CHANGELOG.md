# Changelog

## v0.050

- Expanded from four games to twelve playable games/puzzles.
- Added Tic Tac Toe, Reversi, Nim, Memory Pairs, Lights Out, 15 Puzzle, Shut the Box and Codebreaker.
- Added game-agent profiles and first CPU adapters.
- Added CPU Arena for headless agent-vs-agent simulation.
- Added local player record with per-game counts and coarse cross-game skill evidence.
- Launcher now scrolls; active games remain fixed non-scrolling tabletop surfaces.
- New two-human games follow opposite-end player ownership and far-player rotation.
- Extra-game procedural setup uses the public MethodMesh Chance method boundary.
- Updated XLSForm game choices and version.

## v0.046

- Rebuilt active play around a measured fixed tabletop surface.
- Moved game management to an overlay menu.
- Strengthened opposite-end two-human presentation.
