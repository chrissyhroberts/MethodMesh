package com.example.methodmesh.modules.gamedeck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Lightweight local-first player record. No account, network, or capability-specific runtime support required. */
data class GameDeckStatsSnapshot(
    val games: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val byGame: Map<String, Int>,
    val bestMoves: Map<String, Int>,
    val skillEvidence: Map<String, Int>,
    val achievements: Set<String>
)

class GameDeckStatsStore(context: Context) {
    private val prefs = context.getSharedPreferences("methodmesh_gamedeck_stats", Context.MODE_PRIVATE)

    fun record(game: String, winner: String, humanPlayer: Int = 1, moves: Int = 0, score: Int? = null) {
        val outcome = when {
            winner == "draw" -> "draws"
            winner == humanPlayer.toString() || winner == "cleared" -> "wins"
            else -> "losses"
        }
        val editor = prefs.edit()
            .putInt("games", prefs.getInt("games", 0) + 1)
            .putInt(outcome, prefs.getInt(outcome, 0) + 1)
            .putInt("game.$game", prefs.getInt("game.$game", 0) + 1)

        if ((winner == humanPlayer.toString() || winner == "cleared") && moves > 0) {
            val old = prefs.getInt("bestmoves.$game", Int.MAX_VALUE)
            if (moves < old) editor.putInt("bestmoves.$game", moves)
        }
        score?.let {
            val old = prefs.getInt("high.$game", Int.MIN_VALUE)
            if (it > old) editor.putInt("high.$game", it)
        }
        skillTags(game).forEach { skill -> editor.putInt("skill.$skill", prefs.getInt("skill.$skill", 0) + 1) }

        val achievementSet = currentAchievements().toMutableSet()
        val gamesAfter = prefs.getInt("games", 0) + 1
        if (gamesAfter >= 1) achievementSet += "first_game"
        if (gamesAfter >= 10) achievementSet += "table_regular"
        if (gamesAfter >= 50) achievementSet += "game_shelf_veteran"
        if (outcome == "wins") achievementSet += "first_win"
        if (prefs.getInt("game.$game", 0) + 1 >= 10) achievementSet += "specialist:$game"
        editor.putString("achievements", JSONArray(achievementSet.toList().sorted()).toString())

        val history = loadRecent().toMutableList()
        history.add(0, JSONObject().put("game", game).put("winner", winner).put("moves", moves).put("score", score ?: JSONObject.NULL).toString())
        while (history.size > 20) history.removeAt(history.lastIndex)
        editor.putString("recent", JSONArray(history).toString())
        editor.apply()
    }

    fun snapshot(): GameDeckStatsSnapshot {
        val all = prefs.all
        fun ints(prefix: String) = all.filterKeys { it.startsWith(prefix) }
            .mapKeys { it.key.removePrefix(prefix) }
            .mapValues { (it.value as? Int) ?: 0 }
        return GameDeckStatsSnapshot(
            games = prefs.getInt("games",0), wins = prefs.getInt("wins",0), losses = prefs.getInt("losses",0), draws = prefs.getInt("draws",0),
            byGame = ints("game."), bestMoves = ints("bestmoves."), skillEvidence = ints("skill."), achievements = currentAchievements()
        )
    }

    fun toJson(): String {
        val s=snapshot()
        return JSONObject().put("games",s.games).put("wins",s.wins).put("losses",s.losses).put("draws",s.draws)
            .put("by_game",JSONObject(s.byGame)).put("best_moves",JSONObject(s.bestMoves)).put("skill_evidence",JSONObject(s.skillEvidence))
            .put("achievements",JSONArray(s.achievements.toList())).put("recent",JSONArray(loadRecent())).toString()
    }

    private fun currentAchievements(): Set<String> {
        val raw = prefs.getString("achievements", "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }.toSet()
    }

    private fun loadRecent(): List<String> {
        val arr = runCatching { JSONArray(prefs.getString("recent", "[]") ?: "[]") }.getOrElse { JSONArray() }
        return (0 until arr.length()).map { arr.optString(it) }
    }

    private fun skillTags(game:String)=when(game){
        GameDeckEngine.CONNECT_FOUR, GameDeckExtraEngine.TIC_TAC_TOE, GameDeckExtraEngine.REVERSI -> listOf("planning","tactics","spatial")
        GameDeckEngine.MANCALA, GameDeckExtraEngine.NIM, GameDeckExtraEngine.SHUT_THE_BOX -> listOf("planning","resource_management")
        GameDeckEngine.MINESWEEPER, GameDeckExtraEngine.LIGHTS_OUT, GameDeckExtraEngine.CODEBREAKER -> listOf("deduction","planning")
        GameDeckExtraEngine.MEMORY -> listOf("memory")
        GameDeckExtraEngine.FIFTEEN -> listOf("spatial","planning")
        else -> listOf("probability")
    }
}
