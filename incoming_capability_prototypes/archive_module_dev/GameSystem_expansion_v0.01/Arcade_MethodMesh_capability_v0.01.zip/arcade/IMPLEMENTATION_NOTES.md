# Arcade implementation notes — v0.01

- This is a separate MethodMesh module/capability; no central registration should be added.
- It uses the generic immersive host declaration only.
- Snake food selection uses the existing Chance public method boundary.
- Pong is portrait-oriented so same-device two-human play follows GameDeck's opposite-end tabletop convention.
- The fixed-step interface is the architectural centre: state simulation must remain independent of rendering cadence.
- Arcade currently keeps its own lightweight state. Do not import GameDeck private/internal classes across capability boundaries.
- Cross-capability player records, achievements and controller mapping should become a public game-system service rather than copied capability internals.
