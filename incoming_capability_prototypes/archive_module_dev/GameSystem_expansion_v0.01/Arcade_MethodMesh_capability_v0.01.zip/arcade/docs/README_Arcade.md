# Arcade v0.01

Arcade is a separate MethodMesh capability for low-weight real-time games. It is deliberately distinct from GameDeck's turn-based tabletop/puzzle surface while following the same player identity, action, simulation and provenance direction.

## Included vertical slices

- **Snake Sprint** — fixed-grid real-time loop with Chance-backed seeded food placement.
- **Pong Table** — portrait tabletop Pong with Player 1 at the near end and CPU or Player 2 at the far end. In 2P mode the far player rail rotates 180 degrees.

These are proving games for the framework, not an attempt to become a full emulator/runtime in v0.01.

## Framework

`ArcadeFramework.kt` establishes:

- `ArcadeGameSpec<S>` — initial state, deterministic simulation step and frame metadata;
- `ArcadeInput` — device-independent input vector/action;
- `ArcadeCpuController<S>` — CPU input adapter;
- `ArcadeFixedStep` — 16 ms simulation step target.

The core rule is that rendering cadence is not game state. Simulation advances in explicit steps, which is required for replays, CPU simulation, future network synchronization and reproducibility.

## Presentation

Arcade requests the generic `CapabilityHostPresentation.Immersive` contract. The MethodMesh host must not contain an Arcade special case.

## Roadmap

- input abstraction for touch, keyboard and BLE HID controllers;
- pause/resume and deterministic replay stream;
- player stats/high-score bridge through a future public game-system service;
- additional CPU controllers;
- Breakout, Asteroids-like vector game, maze chase, falling blocks and one-button reaction games;
- optional isolated emulator/runtime packs with licensing boundaries kept explicit.

## External snapshot

Method: `arcade.snapshot`

`example_odk_Arcade.xlsx` demonstrates the external snapshot boundary. Real-time play is primarily native.
