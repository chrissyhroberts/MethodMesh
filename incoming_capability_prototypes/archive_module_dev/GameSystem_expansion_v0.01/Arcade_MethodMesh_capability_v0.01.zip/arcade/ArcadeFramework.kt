package com.example.methodmesh.modules.arcade

/** Generic real-time arcade contract. Rendering is intentionally separate from simulation state. */
data class ArcadeInput(val x: Float = 0f, val y: Float = 0f, val action: Boolean = false)
data class ArcadeFrameMeta(val tick: Long, val elapsedMs: Long, val score: Int, val lives: Int, val finished: Boolean)

interface ArcadeGameSpec<S> {
    val id: String
    fun initial(seed: String = ""): S
    fun step(state: S, input: ArcadeInput, dtSeconds: Float): S
    fun frameMeta(state: S): ArcadeFrameMeta
}

interface ArcadeCpuController<S> {
    fun input(state: S): ArcadeInput
}

/** Fixed-step helper: gameplay uses deterministic simulation increments even if rendering cadence jitters. */
object ArcadeFixedStep {
    const val STEP_MS = 16L
    const val STEP_SECONDS = 0.016f
}
