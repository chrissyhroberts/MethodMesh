package com.example.methodmesh.modules.arcade

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityHostPresentation
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.delay
import org.json.JSONObject

/** Arcade v0.01: fixed-step full-surface prototypes and real-time game framework. */
object ArcadeCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ArcadeMethod.ID
    override val title = "Arcade"
    override val description = "A lightweight fixed-step arcade runtime."
    override val hostPresentation = CapabilityHostPresentation.Immersive

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var game by rememberSaveable { mutableStateOf(context.action.settings["game"] ?: ArcadeEngine.LAUNCHER) }
        var seed by rememberSaveable { mutableStateOf(context.action.settings["seed"].orEmpty()) }
        var soundEnabled by rememberSaveable { mutableStateOf((context.action.settings["sound"] ?: "true").equals("true", true)) }
        var state by rememberSaveable(game) { mutableStateOf(ArcadeEngine.newState(game, seed)) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var menu by rememberSaveable { mutableStateOf(false) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun buildResult(): ExecutionResult {
            val values = As100ArcadeMethod.snapshot(game, state)
            val req = As100ArcadeMethod.request(
                As100ArcadeMethod.ID,
                context.request.invocationContext.asMap(As100ArcadeMethod.ID) + context.action.settings +
                    mapOf("game" to game, "state_json" to state, "seed" to seed, "sound" to soundEnabled.toString()),
                emptyList(),
                emptyList()
            )
            return As100ArcadeMethod.result(req, values, context.request.invocationContext)
        }
        fun refresh() { result = buildResult() }
        fun open(g:String){ game=g;state=ArcadeEngine.newState(g,seed);result=null;menu=false }
        fun reset(){state=ArcadeEngine.newState(game,seed);refresh()}
        val live = context.presentationMode == CapabilityPresentationMode.Dashboard || context.isNativePresetRun

        LaunchedEffect(game, seed, soundEnabled) {
            context.onSettingsChanged(mapOf("game" to game, "seed" to seed, "sound" to soundEnabled.toString()))
        }
        LaunchedEffect(context.presentationMode, context.submitsImmediately, context.request.source) {
            val genuineExternalAutoSubmit = context.submitsImmediately && !context.request.source.equals("intent_test", ignoreCase = true)
            if (genuineExternalAutoSubmit && !launched) {
                launched = true
                onConfirmed(buildResult())
            } else if (!launched) {
                launched = true
                refresh()
            }
        }
        val arcadeState = runCatching { JSONObject(state) }.getOrElse { JSONObject() }
        LaunchedEffect(arcadeState.optInt("score"), arcadeState.optBoolean("finished"), soundEnabled) {
            if (arcadeState.optBoolean("finished")) ArcadeSound.gameOver(soundEnabled)
            else if (arcadeState.optInt("score") > 0) ArcadeSound.score(soundEnabled)
        }

        val content: @Composable () -> Unit = {
            Box(Modifier.fillMaxSize().padding(8.dp)) {
                when(game){
                    ArcadeEngine.LAUNCHER -> ArcadeLauncher(::open,onCancel)
                    ArcadeEngine.SNAKE -> SnakeArcade(state,seed){state=it}
                    ArcadeEngine.PONG -> PongArcade(state){state=it}
                }
                if(game!=ArcadeEngine.LAUNCHER){
                    Box(Modifier.fillMaxSize(), contentAlignment=Alignment.TopEnd){OutlinedButton(onClick={menu=!menu}){Text("⋮",fontWeight=FontWeight.Black)}}
                    if(menu){Box(Modifier.fillMaxSize().padding(top=52.dp),contentAlignment=Alignment.TopEnd){Surface(shape=RoundedCornerShape(18.dp),tonalElevation=8.dp){Column(Modifier.padding(8.dp)){OutlinedButton(onClick={reset();menu=false}){Text("New")};OutlinedButton(onClick={open(ArcadeEngine.LAUNCHER)}){Text("Games")};if(live)Button(onClick={onConfirmed(buildResult())}){Text("Finish")}}}}}
                }
            }
        }
        if (live) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
        } else {
            CapabilityScreenScaffold(
                title = title,
                capabilityId = capabilityId,
                context = context,
                canGoBack = context.stepNumber > 1,
                capturedResult = result,
                resultPreview = result?.let { mapOf(ArcadeFields.RESULT to As100ArcadeMethod.snapshot(game, state)[ArcadeFields.RESULT].orEmpty()) }.orEmpty(),
                onBack = onBack,
                onRetry = { reset() },
                onConfirm = { result?.let(onConfirmed) },
                onCancel = onCancel
            ) { content() }
        }
    }
}

@Composable
private fun ArcadeLauncher(onOpen:(String)->Unit,onExit:()->Unit){Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("Arcade",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Black);Text("FIXED STEP • LOCAL FIRST • LOW WEIGHT")};OutlinedButton(onClick=onExit){Text("MethodMesh")}};ArcadeTile("Snake Sprint","10×10 deterministic grid loop","1P"){onOpen(ArcadeEngine.SNAKE)};ArcadeTile("Pong Table","Portrait tabletop Pong: CPU or opposite human","1P/2P"){onOpen(ArcadeEngine.PONG)};Surface(shape=RoundedCornerShape(24.dp),color=MaterialTheme.colorScheme.surfaceVariant){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text("Framework ready",fontWeight=FontWeight.Black);Text("ArcadeGameSpec • fixed-step loop • CPU controller hook • state snapshots • immersive host")}}}}
@Composable private fun ArcadeTile(title:String,subtitle:String,badge:String,onClick:()->Unit){Card(onClick=onClick,shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.fillMaxWidth().padding(20.dp).height(116.dp),verticalArrangement=Arrangement.SpaceBetween){Column{Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Black);Text(subtitle)};Text(badge,fontWeight=FontWeight.Black)}}}

@Composable
private fun SnakeArcade(stateJson:String,seed:String,onState:(String)->Unit){val s=JSONObject(stateJson);LaunchedEffect(stateJson){if(!s.optBoolean("finished")){delay(125);onState(ArcadeEngine.snakeStep(stateJson,seed))}};Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.SpaceBetween){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("SNAKE",fontWeight=FontWeight.Black);Text("SCORE ${s.optInt("score")}",fontWeight=FontWeight.Black)};BoxWithConstraints(contentAlignment=Alignment.Center){val side=minOf(maxWidth,maxHeight);Canvas(Modifier.size(side)){val cell=size.width/10f;drawRect(Color(0xFF1F2A27));for(i in 0..10){drawLine(Color(0x2233FFAA),Offset(i*cell,0f),Offset(i*cell,size.height));drawLine(Color(0x2233FFAA),Offset(0f,i*cell),Offset(size.width,i*cell))};val body=s.getJSONArray("body");for(i in 0 until body.length()){val c=body.optInt(i)%10;val r=body.optInt(i)/10;drawRoundRect(Color(0xFF7BE495),Offset(c*cell+2,r*cell+2),Size(cell-4,cell-4))};val food=s.optInt("food");drawCircle(Color(0xFFFFC857),cell*.32f,Offset((food%10+.5f)*cell,(food/10+.5f)*cell))}};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={onState(ArcadeEngine.snakeTurn(stateJson,3))}){Text("←")};Column{OutlinedButton(onClick={onState(ArcadeEngine.snakeTurn(stateJson,0))}){Text("↑")};OutlinedButton(onClick={onState(ArcadeEngine.snakeTurn(stateJson,2))}){Text("↓")}};OutlinedButton(onClick={onState(ArcadeEngine.snakeTurn(stateJson,1))}){Text("→")}};Text(if(s.optBoolean("finished"))"GAME OVER" else "Swipe controls come next",fontWeight=FontWeight.Bold)} }

@Composable
private fun PongArcade(stateJson:String,onState:(String)->Unit){val s=JSONObject(stateJson);val cpu=s.optBoolean("cpu",true);LaunchedEffect(stateJson){if(!s.optBoolean("finished")){delay(ArcadeFixedStep.STEP_MS);onState(ArcadeEngine.pongStep(stateJson))}};BoxWithConstraints(Modifier.fillMaxSize()){val rail=78.dp;val play=(maxHeight-rail*2-8.dp).coerceAtLeast(180.dp);Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally){PongRail("${if(cpu)"CPU" else "PLAYER 2"}  ${s.optInt("p2_score")}",top=true,human=!cpu,onCpu={onState(ArcadeEngine.pongSetCpu(stateJson,!cpu))});Spacer(Modifier.height(4.dp));Box(Modifier.fillMaxWidth().height(play).pointerInput(cpu){detectDragGestures{change,_->val frac=(change.position.x/size.width).coerceIn(0f,1f);val player=if(change.position.y<size.height/2&&!cpu)2 else 1;onState(ArcadeEngine.pongPaddle(stateJson,player,frac))}}){Canvas(Modifier.fillMaxSize()){drawRect(Color(0xFF142824));drawLine(Color(0x557BE495),Offset(0f,size.height/2),Offset(size.width,size.height/2));val p1=s.optDouble("p1",.5).toFloat()*size.width;val p2=s.optDouble("p2",.5).toFloat()*size.width;drawRoundRect(Color(0xFFE84A5F),Offset(p1-size.width*.14f,size.height*.94f),Size(size.width*.28f,12f));drawRoundRect(Color(0xFFFFC857),Offset(p2-size.width*.14f,size.height*.04f),Size(size.width*.28f,12f));drawCircle(Color.White,10f,Offset(s.optDouble("ball_x",.5).toFloat()*size.width,s.optDouble("ball_y",.5).toFloat()*size.height))}};Spacer(Modifier.height(4.dp));PongRail("PLAYER 1  ${s.optInt("p1_score")}",top=false,human=true,onCpu=null)}}}
@Composable private fun PongRail(label:String,top:Boolean,human:Boolean,onCpu:(()->Unit)?){Surface(Modifier.fillMaxWidth().height(78.dp).graphicsLayer{rotationZ=if(top&&human)180f else 0f},RoundedCornerShape(22.dp),color=if(top)Color(0x33FFC857) else Color(0x33E84A5F)){Row(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontWeight=FontWeight.Black);onCpu?.let{OutlinedButton(onClick=it){Text(if(human)"2P" else "CPU")}}}}}
