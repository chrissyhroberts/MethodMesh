# Changelog

## v0.01

- Initial Arcade capability framework.
- Added generic fixed-step game contract and CPU-controller hook.
- Added playable Snake Sprint vertical slice.
- Added playable portrait Pong Table vertical slice with CPU/2P mode.
- Added MethodMesh snapshot method and external XLSForm example.
