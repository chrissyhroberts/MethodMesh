package com.example.methodmesh.modules.arcade

import com.example.methodmesh.modules.chance.As100DiceSimulationMethod
import com.example.methodmesh.modules.chance.DiceSimulationFields
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

object ArcadeEngine {
    const val LAUNCHER = "launcher"
    const val SNAKE = "snake"
    const val PONG = "pong"

    fun newState(game: String, seed: String = ""): String = when (game) {
        SNAKE -> snakeInitial(seed)
        PONG -> pongInitial()
        else -> JSONObject().put("game", LAUNCHER).put("score", 0).put("lives", 0).put("tick", 0).put("finished", false).toString()
    }

    // ---- Snake ----
    private fun snakeInitial(seed:String):String {
        val body = JSONArray(listOf(42,41,40))
        return JSONObject().put("game",SNAKE).put("body",body).put("dir",1).put("food",chanceCell(seed, body))
            .put("score",0).put("lives",1).put("tick",0).put("finished",false).toString()
    }

    fun snakeTurn(stateJson:String, dir:Int):String {
        val s=JSONObject(stateJson); val current=s.optInt("dir",1); val opposite=(current+2)%4
        if(dir in 0..3 && dir!=opposite) s.put("dir",dir)
        return s.toString()
    }

    fun snakeStep(stateJson:String, seed:String=""):String {
        val s=JSONObject(stateJson); if(s.optBoolean("finished")) return stateJson
        val body=s.getJSONArray("body"); val list=MutableList(body.length()){body.optInt(it)}; val head=list.first(); val r=head/10; val c=head%10
        val next=when(s.optInt("dir",1)){0->(r-1) to c;1->r to (c+1);2->(r+1) to c;else->r to (c-1)}
        if(next.first !in 0..9 || next.second !in 0..9){s.put("finished",true);return s.toString()}
        val cell=next.first*10+next.second; if(cell in list){s.put("finished",true);return s.toString()}
        list.add(0,cell); val food=s.optInt("food"); if(cell==food){s.put("score",s.optInt("score")+10);s.put("food",chanceCell("$seed|${s.optInt("tick")}",JSONArray(list)))}else list.removeAt(list.lastIndex)
        s.put("body",JSONArray(list)).put("tick",s.optLong("tick")+1);return s.toString()
    }

    private fun chanceCell(seed:String, occupied:JSONArray):Int {
        val used=(0 until occupied.length()).map{occupied.optInt(it)}.toSet(); val free=(0 until 100).filter{it !in used}; if(free.isEmpty()) return 0
        val out=As100DiceSimulationMethod.generate(mapOf("expression" to "d${free.size}","roll_count" to "1","player_count" to "1","history_output" to "false","rng_mode" to "fixed_seed","seed" to seed.ifBlank{"arcade-snake"},"animation_mode" to "off"))
        val i=((out[DiceSimulationFields.TOTAL]?.toIntOrNull()?:1)-1).coerceIn(0,free.lastIndex);return free[i]
    }

    // ---- Pong ----
    // Portrait tabletop orientation: P2 paddle at the far/top end, P1 at the near/bottom end.
    private fun pongInitial():String = JSONObject().put("game",PONG).put("ball_x",.5).put("ball_y",.5).put("vx",.27).put("vy",.42)
        .put("p1",.5).put("p2",.5).put("p1_score",0).put("p2_score",0).put("score",0).put("lives",0).put("tick",0).put("finished",false).put("cpu",true).toString()

    fun pongSetCpu(stateJson:String,cpu:Boolean):String=JSONObject(stateJson).put("cpu",cpu).toString()
    fun pongPaddle(stateJson:String,player:Int,x:Float):String=JSONObject(stateJson).put(if(player==1)"p1" else "p2",x.coerceIn(.14f,.86f).toDouble()).toString()
    fun pongStep(stateJson:String,dt:Float=ArcadeFixedStep.STEP_SECONDS):String{
        val s=JSONObject(stateJson);if(s.optBoolean("finished"))return stateJson
        var x=s.optDouble("ball_x",.5);var y=s.optDouble("ball_y",.5);var vx=s.optDouble("vx",.27);var vy=s.optDouble("vy",.42);val p1=s.optDouble("p1",.5);var p2=s.optDouble("p2",.5)
        if(s.optBoolean("cpu",true)){val d=x-p2;p2+=(d.coerceIn(-.018,.018))}
        x+=vx*dt;y+=vy*dt;if(x<.04){x=.04;vx=abs(vx)}else if(x>.96){x=.96;vx=-abs(vx)}
        val paddleHalf=.14
        if(y>.93&&vy>0&&abs(x-p1)<paddleHalf){y=.93;vy=-abs(vy)*1.015;vx+=(x-p1)*.30}
        if(y<.07&&vy<0&&abs(x-p2)<paddleHalf){y=.07;vy=abs(vy)*1.015;vx+=(x-p2)*.30}
        var a=s.optInt("p1_score");var b=s.optInt("p2_score")
        if(y<0){a++;x=.5;y=.5;vy=.42;vx=.22}else if(y>1){b++;x=.5;y=.5;vy=-.42;vx=-.22}
        s.put("ball_x",x).put("ball_y",y).put("vx",vx).put("vy",vy).put("p1",p1).put("p2",p2).put("p1_score",a).put("p2_score",b).put("score",a).put("tick",s.optLong("tick")+1).put("finished",a>=7||b>=7)
        return s.toString()
    }
}
