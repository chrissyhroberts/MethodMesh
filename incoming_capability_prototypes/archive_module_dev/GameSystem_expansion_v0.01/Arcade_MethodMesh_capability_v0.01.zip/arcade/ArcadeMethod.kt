package com.example.methodmesh.modules.arcade

import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONObject
import java.time.Instant

object ArcadeFields { const val STATUS="arcade_status";const val GAME="arcade_game";const val STATE="arcade_state_json";const val SCORE="arcade_score";const val RESULT="arcade_result";const val GENERATED="arcade_generated_time_iso";const val ERROR="arcade_error";val outputs=listOf(STATUS,GAME,STATE,SCORE,RESULT,GENERATED,ERROR) }

object As100ArcadeMethod:As100Method{
    const val ID="arcade.snapshot";private const val VERSION="0.0.1"
    override val id=ID;override val ref=ArchitectureRef(ArchitectureId(ID),"Method","Arcade snapshot")
    override val descriptor=MethodDescriptor(id=ArchitectureId(ID),methodType=MethodObjectType.Calculation,name="Arcade",version=VERSION,description="Return the current lightweight arcade state snapshot.",outputs=ArcadeFields.outputs,graphOutputs=listOf(ID),parameters=mapOf("category" to "Development","status" to "Development"))
    override val contract=MethodContract(method=ref,producedKnowledgeTypes=listOf(KnowledgeObjectType.Observation),producedFields=descriptor.outputs,producedGraphOutputs=descriptor.graphOutputs)
    override fun request(action:String,context:Map<String,String>,signals:List<Signal>,inputs:List<ArchitectureRef>)=As100ExecutionEngine.request(
        action = action, method = ref, context = context, signals = signals, inputs = inputs
    )
    override fun execute(request:ExecutionRequest,settingsState:SettingsState?,transport:String?):ExecutionResult{
        val game=request.context["game"]?:request.context["input_game"]?:ArcadeEngine.LAUNCHER
        val seed=request.context["seed"]?:request.context["input_seed"]?:""
        val state=request.context["state_json"]?:request.context["input_state_json"]?:ArcadeEngine.newState(game,seed)
        return result(request,snapshot(game,state),InvocationContext.from(request.context))
    }
    fun snapshot(game:String,state:String):Map<String,String>{val s=runCatching{JSONObject(state)}.getOrElse{JSONObject()};val at=Instant.now().toString();return linkedMapOf(ArcadeFields.STATUS to "succeeded",ArcadeFields.GAME to game,ArcadeFields.STATE to state,ArcadeFields.SCORE to s.optInt("score",0).toString(),ArcadeFields.RESULT to "$game — score ${s.optInt("score",0)}",ArcadeFields.GENERATED to at,ArcadeFields.ERROR to "")}
    fun result(request:ExecutionRequest,values:Map<String,String>,invocation:InvocationContext?):ExecutionResult{val observation=Observation(phenomenon=ID,subject=null,values=values,temporalContext=request.temporalContext,provenance=ProvenanceContext("methodmesh.arcade",ID,VERSION));val transformation=Transformation(action=ID,method=ref,outputs=listOf(ArchitectureRef(observation.id,observation.objectType,observation.phenomenon)),status=TransformationStatus.Succeeded,temporalContext=request.temporalContext,provenance=ProvenanceContext("methodmesh.arcade",ID,VERSION));return As100ExecutionEngine.complete(request,TransformationStatus.Succeeded,observations=listOf(observation),transformations=listOf(transformation)).withInvocationContext(invocation)}
}
