package com.example.methodmesh.modules.arcade
import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting
object ArcadeModule:MethodMeshModule{
 override val moduleId="arcade";override val displayName="Arcade";override val summary="A lightweight fixed-step arcade runtime with local CPU and two-player foundations."
 override fun as100Methods()=listOf(As100ArcadeMethod);override fun capabilityScreens()=listOf(ArcadeCapabilityScreen)
 override fun rilBindings()=listOf(RilBinding("open arcade",As100ArcadeMethod.ID,"Open Arcade"))
 override fun capabilitySettings()=mapOf(As100ArcadeMethod.ID to listOf(MethodSetting.ChoiceSetting("game", "Game", defaultValue = ArcadeEngine.LAUNCHER, choices = listOf(ArcadeEngine.LAUNCHER, ArcadeEngine.SNAKE, ArcadeEngine.PONG)), MethodSetting.TextSetting("seed", "Seed", defaultValue = ""), MethodSetting.BooleanSetting("sound", "8-bit sounds", defaultValue = true)))
}
