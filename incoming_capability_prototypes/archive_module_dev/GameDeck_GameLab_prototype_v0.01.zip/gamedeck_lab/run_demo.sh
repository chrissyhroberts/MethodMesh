#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/build"
mkdir -p "$OUT"
kotlinc \
  "$ROOT/vendor/chance/DiceSimulatorEngine.kt" \
  $(find "$ROOT/src/main/kotlin" -name '*.kt' | sort) \
  -include-runtime -d "$OUT/gamedeck-demo.jar"
java -cp "$OUT/gamedeck-demo.jar" com.methodmesh.gamedeck.MainKt
