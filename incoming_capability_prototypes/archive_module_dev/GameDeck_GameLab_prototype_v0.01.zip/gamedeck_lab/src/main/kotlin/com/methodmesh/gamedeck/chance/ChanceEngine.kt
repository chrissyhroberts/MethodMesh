package com.methodmesh.gamedeck.chance

import com.example.methodmesh.modules.chance.DiceSimulatorEngine

/** Stable GameDeck-facing adapter around the existing MethodMesh Chance dice/coin engine. */
class ChanceEngine private constructor(
    private val mode: String,
    private val baseSeed: String?
) {
    companion object {
        fun runtime(): ChanceEngine = ChanceEngine("secure_random", null)
        fun deterministic(seed: String): ChanceEngine = ChanceEngine("fixed_seed", seed)
    }

    data class Roll(
        val expression: String,
        val total: Int,
        val algorithm: String,
        val algorithmVersion: String,
        val seed: String?,
        val primitiveDrawCount: Int
    )

    data class Coins(
        val tosses: List<Boolean>,
        val heads: Int,
        val tails: Int,
        val algorithm: String,
        val algorithmVersion: String,
        val seed: String?
    )

    fun roll(expression: String, stream: String = "default"): Roll {
        val seed = derivedSeed(stream)
        val result = DiceSimulatorEngine.simulate(expression, 1, mode, seed)
        val round = result.rounds.single()
        return Roll(
            expression = result.canonicalExpression,
            total = round.total,
            algorithm = result.algorithm,
            algorithmVersion = result.algorithmVersion,
            seed = result.seed,
            primitiveDrawCount = round.primitiveDraws.size
        )
    }

    fun tossCoins(count: Int, stream: String = "default"): Coins {
        val seed = derivedSeed(stream)
        val result = DiceSimulatorEngine.tossCoins(count, mode, seed)
        return Coins(result.tosses, result.heads, result.tails, result.algorithm, result.algorithmVersion, result.seed)
    }

    private fun derivedSeed(stream: String): String? = when (mode) {
        "fixed_seed" -> "${baseSeed ?: "gamedeck"}::$stream"
        else -> null
    }
}
