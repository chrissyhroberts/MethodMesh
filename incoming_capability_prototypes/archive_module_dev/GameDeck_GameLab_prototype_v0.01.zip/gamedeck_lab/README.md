# GameDeck / GameLab prototype

First executable vertical slice derived from `GameDeck_GameLab_Specification_v0.02.md`.

## What exists

- pure-Kotlin GameDeck game contracts;
- event/replay model;
- thin `ChanceEngine` adapter over the existing MethodMesh `DiceSimulatorEngine`;
- explicit secure-runtime vs fixed-seed deterministic randomness;
- Connect Four proving game;
- Snakes & Ladders stochastic proving game using Chance rather than its own RNG;
- headless GameLab simulation;
- random and heuristic Connect Four agents;
- deterministic/replay regression tests.

This deliberately does **not** recreate the existing Android/Compose Chance visuals. Those remain upstream MethodMesh components and should be reused when this headless core is integrated into the app.

## Run

Requires JDK + Kotlin compiler (`kotlinc`).

```bash
./run_tests.sh
./run_demo.sh
```

## Architecture proven here

```text
Game Module -> GameDeck contracts -> shared Chance adapter
                           |
                           +-> event/replay
                           +-> headless GameLab agents/simulation
```

## Next implementation steps

1. Integrate the full `ChanceSelectionEngine` through an adapter in the real MethodMesh/Android project (cards, spinner, weighted choice, pick-one).
2. Add versioned JSON persistence for players, saves and replays.
3. Add a generic parameter-definition contract for GameLab.
4. Turn Connect Four into the first parameter/simulation dashboard.
5. Add Minesweeper as the first procedural validation problem.
6. Only then add player skills/adaptive generation and P2P.

## Upstream Chance

The prototype vendors only `DiceSimulatorEngine.kt` so it can compile headlessly without Android or `org.json`. The supplied MethodMesh Chance package already contains richer modules and UI and remains the source of truth for those components.
