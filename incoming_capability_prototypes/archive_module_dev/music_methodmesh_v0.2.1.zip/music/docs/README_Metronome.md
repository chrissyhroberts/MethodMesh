# Metronome

**Method ID:** `music.metronome`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Run or describe a tempo/subdivision pulse pattern.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `bpm`
- `beats_per_bar`
- `subdivision`
- `accent_pattern`
- `audio_enabled`
- `visual_enabled`
- `haptic_enabled`

## Outputs

- `music_metronome_result`
- `music_metronome_bpm`
- `music_metronome_beat_interval_ms`
- `music_metronome_beats_per_bar`
- `music_metronome_subdivision`
- `music_metronome_subdivision_interval_ms`
- `music_metronome_accent_pattern`
- `music_metronome_status`
- `music_metronome_audit_json`
- `music_metronome_error`

## Main result

`music_metronome_result` is the compact native/share result. `music_metronome_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_Metronome.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Native playback uses Android ToneGenerator and optional vibration. ODK returns the calculated pattern; it does not keep a metronome running.
