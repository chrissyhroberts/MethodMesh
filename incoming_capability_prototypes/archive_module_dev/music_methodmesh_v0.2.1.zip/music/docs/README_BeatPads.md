# Beat pads

**Method ID:** `music.beat_pads`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Large finger-drum pads with synthesized one-shots and optional hit-sequence capture.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `hits_json`

## Outputs

- `music_beat_pads_result`
- `music_beat_pads_hit_count`
- `music_beat_pads_hits_json`
- `music_beat_pads_duration_ms`
- `music_beat_pads_status`
- `music_beat_pads_audit_json`
- `music_beat_pads_error`

## ODK/XLSForm

The nested `example_odk_BeatPads.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
