# Polyrhythm generator

**Method ID:** `music.polyrhythm`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Generate pulse positions for an A:B polyrhythm.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `ratio_a`
- `ratio_b`

## Outputs

- `music_polyrhythm_result`
- `music_polyrhythm_ratio_a`
- `music_polyrhythm_ratio_b`
- `music_polyrhythm_pulse_count`
- `music_polyrhythm_pulses_json`
- `music_polyrhythm_status`
- `music_polyrhythm_audit_json`
- `music_polyrhythm_error`

## Main result

`music_polyrhythm_result` is the compact native/share result. `music_polyrhythm_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_Polyrhythm.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

The calculation is deterministic. Native sonification/haptic differentiation can be extended in a later UI pass.
