# Euclidean rhythm

**Method ID:** `music.euclidean_rhythm`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Evenly distributes hits across a step grid with optional rotation.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `steps`
- `pulses`
- `rotation`

## Outputs

- `music_euclidean_result`
- `music_euclidean_steps`
- `music_euclidean_pulses`
- `music_euclidean_rotation`
- `music_euclidean_pattern`
- `music_euclidean_pattern_json`
- `music_euclidean_status`
- `music_euclidean_audit_json`
- `music_euclidean_error`

## ODK/XLSForm

The nested `example_odk_EuclideanRhythm.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
