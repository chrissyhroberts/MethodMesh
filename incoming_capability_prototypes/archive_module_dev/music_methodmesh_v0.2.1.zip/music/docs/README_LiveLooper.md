# Live looper

**Method ID:** `music.live_looper`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Records a master PCM phrase then overdubs separately mutable loop layers. Native use requires microphone permission.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `loop_ms`
- `layer_count`
- `layers_json`

## Outputs

- `music_live_looper_result`
- `music_live_looper_loop_ms`
- `music_live_looper_layer_count`
- `music_live_looper_playing`
- `music_live_looper_layers_json`
- `music_live_looper_status`
- `music_live_looper_audit_json`
- `music_live_looper_error`

## ODK/XLSForm

The nested `example_odk_LiveLooper.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

Requires `RECORD_AUDIO` for native microphone capture. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.

## Looper-specific limitations in v0.2.0

- The first recorded layer fixes loop length; subsequent layers are trimmed or zero-padded to that duration.
- Loop closing is manual rather than bar-quantised in this version; count-in and N-bar auto-close are roadmap items.
- Playback while overdubbing can bleed from the device speaker back into the microphone; headphones or an external audio interface are preferable.
- Loop audio is session state only in v0.2.0. The returned MethodMesh result contains loop duration/layer metadata, not the PCM audio buffers.
- No destructive waveform editing, time-stretching or plugin effects are implemented.
