# Tap a rhythm

**Method ID:** `music.rhythm_capture`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Infers pulse from human taps and returns both raw and quantised timing so groove is not silently destroyed.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `tap_times_ms`
- `steps_per_beat`
- `bars`
- `beats_per_bar`
- `bpm`

## Outputs

- `music_rhythm_capture_result`
- `music_rhythm_capture_bpm`
- `music_rhythm_capture_steps_per_beat`
- `music_rhythm_capture_pattern`
- `music_rhythm_capture_pattern_json`
- `music_rhythm_capture_raw_offsets_ms_json`
- `music_rhythm_capture_quantized_offsets_ms_json`
- `music_rhythm_capture_mean_error_ms`
- `music_rhythm_capture_status`
- `music_rhythm_capture_audit_json`
- `music_rhythm_capture_error`

## ODK/XLSForm

The nested `example_odk_RhythmCapture.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
