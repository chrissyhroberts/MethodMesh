# Set-list timing

**Method ID:** `music.setlist_timing`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Calculate total duration from song durations and gaps.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `durations`
- `gaps`
- `start_time`

## Outputs

- `music_setlist_timing_result`
- `music_setlist_timing_song_count`
- `music_setlist_timing_song_seconds`
- `music_setlist_timing_gap_seconds`
- `music_setlist_timing_total_seconds`
- `music_setlist_timing_total_formatted`
- `music_setlist_timing_end_time_note`
- `music_setlist_timing_status`
- `music_setlist_timing_audit_json`
- `music_setlist_timing_error`

## Main result

`music_setlist_timing_result` is the compact native/share result. `music_setlist_timing_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_SetListTiming.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

For persistent running order and actual-vs-planned timing use the Performance dashboard.
