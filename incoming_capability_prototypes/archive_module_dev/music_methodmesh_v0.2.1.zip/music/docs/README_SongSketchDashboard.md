# Song sketch dashboard

**Method ID:** `music.song_sketch_dashboard`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Persistent composition board for harmony, rhythm, bass, melody and arrangement structure.

## Native workflow

This is a persistent dashboard. Native dashboard/preset execution withholds `capturedResult` from the generic scaffold until the user explicitly chooses **Finish** / **Use this snapshot**.

## Inputs

- `title`
- `bpm`
- `key`
- `progression`
- `beat`
- `bassline`
- `melody`
- `structure`

## Outputs

- `music_song_sketch_dashboard_result`
- `music_song_sketch_dashboard_title`
- `music_song_sketch_dashboard_bpm`
- `music_song_sketch_dashboard_key`
- `music_song_sketch_dashboard_progression`
- `music_song_sketch_dashboard_beat`
- `music_song_sketch_dashboard_bassline`
- `music_song_sketch_dashboard_melody`
- `music_song_sketch_dashboard_structure`
- `music_song_sketch_dashboard_snapshot_json`
- `music_song_sketch_dashboard_status`
- `music_song_sketch_dashboard_audit_json`
- `music_song_sketch_dashboard_error`

## ODK/XLSForm

The nested `example_odk_SongSketchDashboard.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
