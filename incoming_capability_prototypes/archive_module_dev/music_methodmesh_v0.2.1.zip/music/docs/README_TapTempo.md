# Tap tempo

**Method ID:** `music.tap_tempo`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Estimate BPM and timing stability from repeated taps.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `tap_intervals_ms (ODK/protocol) or native taps`

## Outputs

- `music_tap_tempo_result`
- `music_tap_tempo_bpm`
- `music_tap_tempo_mean_interval_ms`
- `music_tap_tempo_sd_interval_ms`
- `music_tap_tempo_cv`
- `music_tap_tempo_tap_count`
- `music_tap_tempo_status`
- `music_tap_tempo_audit_json`
- `music_tap_tempo_error`

## Main result

`music_tap_tempo_result` is the compact native/share result. `music_tap_tempo_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_TapTempo.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Native screen uses a large full-width tap pad; no permissions are required.
