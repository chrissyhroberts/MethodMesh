# Probability sequencer

**Method ID:** `music.probability_pattern`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Realises per-step trigger probabilities using a reproducible seed.

## Native workflow

The native screen confirms a result before handing it to the generic MethodMesh close-out flow.

## Inputs

- `probabilities`
- `seed`

## Outputs

- `music_probability_result`
- `music_probability_probabilities_json`
- `music_probability_seed`
- `music_probability_pattern`
- `music_probability_pattern_json`
- `music_probability_status`
- `music_probability_audit_json`
- `music_probability_error`

## ODK/XLSForm

The nested `example_odk_ProbabilityPattern.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies declared values as `input_*` extras, and projects the returned MethodMesh fields into XLSForm fields.

## Permissions / services

No special Android permission is required. The capability is offline and does not depend on network services. Drum playback is synthesized in-process rather than bundled as third-party samples.

## Development limitations

Real-time audio timing, microphone latency, Bluetooth routing and audio-focus behaviour must be validated on representative Android devices before any audio capability is promoted to Production. Algorithmic outputs are deterministic when a seed is supplied.
