# Music reference

**Method ID:** `music.reference`  
**Status:** Development  
**Version:** 0.2.1

## What it does

Return scale notes, relative note and diatonic triads.

## Native workflow

Open the capability, supply any runtime inputs not fixed by a preset, perform the interaction/calculation, then confirm the useful result. Fixed preset values are hidden where the screen can determine that they are fixed. Dashboard capabilities remain on the dashboard until **Finish** / **Use this snapshot**.

## Preset workflow

Configure and test normally, save fixed configuration into a preset, and leave genuinely variable values as runtime inputs. Native preset execution should not ask again for fixed values.

## Inputs

- `root`
- `scale`
- `prefer_flats`

## Outputs

- `music_reference_result`
- `music_reference_root`
- `music_reference_scale`
- `music_reference_notes`
- `music_reference_triads`
- `music_reference_relative_note`
- `music_reference_status`
- `music_reference_audit_json`
- `music_reference_error`

## Main result

`music_reference_result` is the compact native/share result. `music_reference_audit_json` contains the audit/metadata JSON. Status/error fields remain separately projected for ODK and protocol use.

## ODK/XLSForm

The nested `example_odk_MusicReference.xlsx` uses an XLSForm group with a `body::intent` call to `com.example.methodmesh.EXECUTE_METHOD`, supplies inputs as `input_*` extras, and declares the output fields returned by MethodMesh. External calls should run automatically rather than opening extra native dialogs.

## Permissions / services

No network service is required. Ordinary calculations require no Android permission. Metronome haptics use the device vibrator when enabled; live pitch/tuning is deliberately delegated to the existing `acoustic.tune` capability, which owns microphone permission and DSP.

## Offline behaviour

Fully offline.

## Known limitations

Diatonic triads are provided for major and natural minor. Other scales return note sets only in v0.1.
