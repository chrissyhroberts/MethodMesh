package com.example.methodmesh.modules.music

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONObject

internal object JamDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100JamDashboardMethod.ID; override val title="Jam / creation"; override val description="Live beat and rhythm scratchpad for making an idea quickly."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit)=JamDashboardUi(context,onBack,onConfirmed,onCancel)
}
internal object SongSketchDashboardCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId=As100SongSketchDashboardMethod.ID; override val title="Song sketch"; override val description="Persistent composition board for harmony, rhythm, bass, melody and structure."
    @Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit)=SongSketchDashboardUi(context,onBack,onConfirmed,onCancel)
}

@Composable private fun JamDashboardUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    val androidContext=LocalContext.current; val repo=remember{MusicCreationRepository(androidContext)}; val stored=remember{repo.loadJam()}; val engine=remember{DrumSynthEngine()}; DisposableEffect(Unit){onDispose{engine.stop()}}
    var bpm by rememberSaveable{mutableStateOf(context.action.settings["bpm"]?:stored["bpm"].takeUnless{it.isNullOrBlank()}?:"110")}; var playing by rememberSaveable{mutableStateOf(false)}; var tapsCsv by rememberSaveable{mutableStateOf("")}; var result by remember{mutableStateOf<ExecutionResult?>(null)}
    val voices=listOf("kick","snare","hat","clap"); val defaults=mapOf("kick" to "x...x...x...x...","snare" to "....x.......x...","hat" to "x.x.x.x.x.x.x.x.","clap" to "................")
    val patterns=remember{voices.associateWith{v->mutableStateListOf<Boolean>().apply{addAll(MusicCreationAlgorithms.parsePattern(stored[v].takeUnless{it.isNullOrBlank()}?:defaults[v]!!))}}}
    val taps=tapsCsv.split(',').mapNotNull{it.toDoubleOrNull()}; val captured=if(taps.size>=2)runCatching{MusicCreationAlgorithms.captureRhythm(taps)}.getOrNull() else null
    fun save(){repo.saveJam(mapOf("bpm" to bpm)+voices.associateWith{MusicCreationAlgorithms.patternString(patterns[it]!!.toList())}+mapOf("captured_pattern" to (captured?.let{MusicCreationAlgorithms.patternString(it.pattern)}?:"")))}
    fun snapshot(){save();val drum=JSONObject().put("kick",MusicCreationAlgorithms.patternString(patterns["kick"]!!.toList())).put("snare",MusicCreationAlgorithms.patternString(patterns["snare"]!!.toList())).put("hat",MusicCreationAlgorithms.patternString(patterns["hat"]!!.toList())).put("clap",MusicCreationAlgorithms.patternString(patterns["clap"]!!.toList()));val values=As100JamDashboardMethod.calculate(mapOf("bpm" to bpm,"drum_pattern_json" to drum.toString(),"loop_ms" to "0","loop_layers" to "0","captured_pattern" to (captured?.let{MusicCreationAlgorithms.patternString(it.pattern)}?:"")));result=creationDashboardExecution(As100JamDashboardMethod,context,values)}
    LaunchedEffect(bpm,tapsCsv){snapshot()}; val keep=context.presentationMode==CapabilityPresentationMode.Dashboard||context.isNativePresetRun; val scaffold=if(keep)null else result
    CapabilityScreenScaffold(title="Jam / creation",capabilityId=As100JamDashboardMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=scaffold,resultPreview=scaffold?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={snapshot()},onConfirm={result?.let(onConfirmed)},onCancel={engine.stop();onCancel()}){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("$bpm BPM",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(captured?.let{"Captured: ${MusicCreationAlgorithms.patternString(it.pattern)}"}?:"Tap an idea or build the beat below")}}
        OutlinedTextField(bpm,{bpm=it},label={Text("Tempo")},modifier=Modifier.fillMaxWidth())
        Button(onClick={val now=SystemClock.elapsedRealtime().toDouble();tapsCsv=(taps+now).takeLast(64).joinToString(",")},modifier=Modifier.fillMaxWidth().height(92.dp)){Text("TAP RHYTHM")}
        if(captured!=null)Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={val p=captured.pattern;patterns["kick"]!!.indices.forEach{i->patterns["kick"]!![i]=p.getOrElse(i){false}};save();snapshot()},modifier=Modifier.fillMaxWidth()){Text("→ KICK")};OutlinedButton(onClick={tapsCsv=""},modifier=Modifier.fillMaxWidth()){Text("CLEAR TAPS")}}
        voices.forEach{voice->Column(verticalArrangement=Arrangement.spacedBy(3.dp)){Text(voice.uppercase());Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(3.dp)){patterns[voice]!!.forEachIndexed{i,on->Card(Modifier.width(28.dp).height(32.dp).clickable{patterns[voice]!![i]=!on;save();snapshot()}){Spacer(Modifier.fillMaxWidth().height(32.dp).background(if(on)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant))}}}}}
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={if(playing){engine.stop();playing=false}else{engine.playPattern(bpm.toDoubleOrNull()?:110.0,16,0.0,voices.associateWith{patterns[it]!!.toList()});playing=true}},modifier=Modifier.fillMaxWidth()){Text(if(playing)"STOP BEAT" else "PLAY BEAT")};OutlinedButton(onClick={voices.forEach{v->val e=MusicCreationAlgorithms.euclidean(16,when(v){"kick"->4;"snare"->2;"hat"->8;else->3},if(v=="snare")4 else 0);patterns[v]!!.indices.forEach{i->patterns[v]!![i]=e[i]}};save();snapshot()},modifier=Modifier.fillMaxWidth()){Text("EUCLIDEAN")}}
        Text("Live Looper remains a dedicated full-screen capability because microphone recording needs its own transport and permission lifecycle.",style=MaterialTheme.typography.bodySmall)
        if(keep&&result!=null)Button(onClick={result?.let(onConfirmed)},modifier=Modifier.fillMaxWidth()){Text(if(context.isNativePresetRun)"Finish" else "Use this snapshot")}
    }}
}

@Composable private fun SongSketchDashboardUi(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){
    val androidContext=LocalContext.current; val repo=remember{MusicCreationRepository(androidContext)}; val stored=remember{repo.loadSketch()}
    var title by rememberSaveable{mutableStateOf(context.action.settings["title"]?:stored["title"].takeUnless{it.isNullOrBlank()}?:"Untitled sketch")}; var bpm by rememberSaveable{mutableStateOf(context.action.settings["bpm"]?:stored["bpm"].takeUnless{it.isNullOrBlank()}?:"100")}; var key by rememberSaveable{mutableStateOf(context.action.settings["key"]?:stored["key"].takeUnless{it.isNullOrBlank()}?:"C major")}; var progression by rememberSaveable{mutableStateOf(stored["progression"].takeUnless{it.isNullOrBlank()}?:"C | G | Am | F")}; var beat by rememberSaveable{mutableStateOf(stored["beat"].takeUnless{it.isNullOrBlank()}?:"x...x...x...x...")}; var bass by rememberSaveable{mutableStateOf(stored["bassline"].takeUnless{it.isNullOrBlank()}?:"")}; var melody by rememberSaveable{mutableStateOf(stored["melody"].takeUnless{it.isNullOrBlank()}?:"")}; var structure by rememberSaveable{mutableStateOf(stored["structure"].takeUnless{it.isNullOrBlank()}?:"Intro 4; Verse 8; Chorus 8")}; var result by remember{mutableStateOf<ExecutionResult?>(null)}
    fun values()=mapOf("title" to title,"bpm" to bpm,"key" to key,"progression" to progression,"beat" to beat,"bassline" to bass,"melody" to melody,"structure" to structure)
    fun snapshot(){repo.saveSketch(values());val calc=As100SongSketchDashboardMethod.calculate(values());result=creationDashboardExecution(As100SongSketchDashboardMethod,context,calc)}
    LaunchedEffect(title,bpm,key,progression,beat,bass,melody,structure){snapshot()}; val keep=context.presentationMode==CapabilityPresentationMode.Dashboard||context.isNativePresetRun; val scaffold=if(keep)null else result
    CapabilityScreenScaffold(title="Song sketch",capabilityId=As100SongSketchDashboardMethod.ID,context=context,canGoBack=context.stepNumber>1,capturedResult=scaffold,resultPreview=scaffold?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack=onBack,onRetry={snapshot()},onConfirm={result?.let(onConfirmed)},onCancel=onCancel){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("$bpm BPM · $key");if(progression.isNotBlank())Text(progression,style=MaterialTheme.typography.titleMedium)}}
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("Title")},modifier=Modifier.fillMaxWidth());OutlinedTextField(bpm,{bpm=it},label={Text("BPM")},modifier=Modifier.fillMaxWidth())};OutlinedTextField(key,{key=it},label={Text("Key")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(progression,{progression=it},label={Text("Chord progression")},modifier=Modifier.fillMaxWidth());Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={val parts=key.split(" ");val root=parts.firstOrNull()?:"C";val mode=if(parts.getOrNull(1)?.contains("minor",true)==true)"minor" else "major";progression=MusicCreationAlgorithms.generateProgression(root,mode,4,System.currentTimeMillis()).joinToString(" | ")},modifier=Modifier.fillMaxWidth()){Text("GENERATE CHORDS")};OutlinedButton(onClick={bass=MusicCreationAlgorithms.bassline(progression.split("|").map{it.trim()}.filter{it.isNotBlank()},"root_fifth").joinToString(" ")},modifier=Modifier.fillMaxWidth()){Text("MAKE BASS")}}
        OutlinedTextField(beat,{beat=it},label={Text("Beat pattern")},modifier=Modifier.fillMaxWidth());OutlinedButton(onClick={beat=MusicCreationAlgorithms.patternString(MusicCreationAlgorithms.euclidean(16,5,(0..15).random()))},modifier=Modifier.fillMaxWidth()){Text("GENERATE RHYTHM")}
        OutlinedTextField(bass,{bass=it},label={Text("Bassline")},modifier=Modifier.fillMaxWidth());OutlinedTextField(melody,{melody=it},label={Text("Melody / motif")},modifier=Modifier.fillMaxWidth());OutlinedTextField(structure,{structure=it},label={Text("Structure")},modifier=Modifier.fillMaxWidth())
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={val parts=key.split(" ");val root=parts.firstOrNull()?:"C";val scale=if(parts.getOrNull(1)?.contains("minor",true)==true)"natural_minor" else "major";melody=MusicCreationAlgorithms.melodyFromDegrees(root,scale,listOf(1,3,5,6,5,3,2,1)).joinToString(" ")},modifier=Modifier.fillMaxWidth()){Text("MAKE MELODY")};OutlinedButton(onClick={title="Untitled sketch";progression="";beat="";bass="";melody="";structure="";snapshot()},modifier=Modifier.fillMaxWidth()){Text("NEW")}}
        if(keep&&result!=null)Button(onClick={result?.let(onConfirmed)},modifier=Modifier.fillMaxWidth()){Text(if(context.isNativePresetRun)"Finish" else "Use this snapshot")}
    }}
}

private fun creationDashboardExecution(method:MusicPureMethod,context:CapabilityScreenContext,values:Map<String,String>):ExecutionResult{val request=method.request(action=method.id,context=context.request.invocationContext.asMap(method.id)+context.action.settings+values,signals=emptyList(),inputs=emptyList());return method.result(request,values,context.request.invocationContext)}
