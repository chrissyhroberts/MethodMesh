# MethodMesh aviation v0.2 patch

This archive overlays the existing MethodMesh repository with the Development aviation capability pack.

v0.2 adds a persistent `aviation.dashboard` on top of the v0.1 atomic aviation methods.

## New dashboard behaviour

- current GPS or supplied/piped location;
- nearest and nearby airfields from cached OurAirports data;
- runway-end context from cached OurAirports runway data;
- GPS accuracy, GNSS altitude, groundspeed and track when available;
- optional runway wind and density-altitude cards using the existing shared engines;
- native/browser dashboard remains visible during refresh;
- native presets remain visible until **Finish**;
- external/ODK calls remain single-shot and automatically return a structured snapshot;
- `intent_test` stays interactive;
- refresh does not itself commit graph history.

## Overlay

Copy the archive contents over the root of a current MethodMesh checkout. The aviation module remains self-contained under:

```text
app/src/main/java/com/example/methodmesh/modules/aviation/
```

No shared dashboard/scaffold modifications are included.

## Validate

```bash
./gradlew :app:testDebugUnitTest --tests 'com.example.methodmesh.modules.aviation.*'
./gradlew :app:assembleDebug
```

See `app/src/main/java/com/example/methodmesh/modules/aviation/docs/BUILD_REPORT.md` for the device/integration checklist.
