# Aviation v0.2 build / validation report

## Added in v0.2

- `aviation.dashboard` persistent dashboard capability.
- Persistent native/preset semantics following `METHODMESH_PERSISTENT_DASHBOARD_CAPABILITY.md`.
- GPS telemetry cards for accuracy, GNSS altitude, groundspeed and track when Android Location supplies them.
- Tappable nearby-airfield strip.
- OurAirports `runways.csv` cache and dynamic runway-end selector.
- Shared-engine runway-wind and density-altitude cards.
- Single-shot external/ODK dashboard result.
- Updated XLSForm exercising `aviation.dashboard` as an external call.

## Validation completed in this environment

The following pure Kotlin files compile together with `kotlinc`:

- `AviationCalculations.kt`
- `AviationCsv.kt`
- `AviationAirfieldRepository.kt`

Focused smoke checks pass for:

- direct headwind, crosswind and tailwind calculations;
- standard sea-level pressure/density-altitude baseline;
- E6B time and range;
- great-circle distance and bearing;
- quoted CSV parsing;
- cached airport filtering and nearest ordering;
- cached runway lookup;
- creation of both runway ends;
- numbered runway-designator heading conversion (`09L` -> `90`, `27R` -> `270`, `36` -> `360`);
- fallback to published true heading for non-numeric runway identifiers.

`AviationMethod.kt` and `AviationDashboard.kt` compile against local stubs matching the current public MethodMesh method/runtime/settings contracts fetched from the live repository. This is a syntax/contract-shape check, not a substitute for the Android Gradle build.

`AviationDashboardCapabilityScreen.kt` was passed through the Kotlin compiler without Android/Compose dependencies. The expected unresolved Android/Compose dependency errors are produced; no Kotlin parser/local-function syntax error was detected in that pass.

The updated XLSForm was produced with `artifact_tool`, inspected after modification, and scanned for obvious formula errors; none were found.

## Persistent-dashboard checks implemented in source

- `context.isNativePresetRun` is explicitly considered.
- Native dashboard use remains on the dashboard after refresh.
- Native preset use remains on the dashboard after refresh.
- `intent_test` stays interactive.
- `capturedResult` is `null` while persistent dashboard presentation is active.
- The genuine latest `ExecutionResult` remains in capability-owned state.
- **Use this snapshot** / **Finish** explicitly calls `onConfirmed(result)`.
- The action is unavailable until a successful snapshot exists.
- Refresh replaces local snapshot state; it does not call `onConfirmed`.
- External/ODK presentation receives the real result through the normal scaffold auto-return contract.
- Protocol/sequence presentation is not classified as persistent unless it is a native preset.
- Dashboard calculations use the same repository/calculation engines as the atomic aviation methods.

## Validation not possible here

This environment still does not have a complete Android checkout/build environment for the repository. The connected GitHub integration previously allowed reads but returned HTTP 403 when asked to create a feature branch. Therefore the canonical integration checks were not run here:

```bash
./gradlew :app:testDebugUnitTest --tests 'com.example.methodmesh.modules.aviation.*'
./gradlew :app:assembleDebug
```

## Required integration checks before Production

1. Overlay the patch onto a current MethodMesh checkout.
2. Run the two Gradle commands above.
3. Verify the persistent dashboard on a real device in:
   - normal dashboard/browser mode;
   - native preset mode;
   - `intent_test` mode;
   - ODK/external mode;
   - a multi-step protocol/sequence.
4. Confirm refresh never creates duplicate graph history until **Use this snapshot / Finish**.
5. Test first online runway-catalogue download and subsequent offline `cache_only` use.
6. Test airfields with multiple runways, a single runway, missing runway records and non-numeric runway identifiers.
7. Rotate the device and verify settings/selections are preserved or safely refreshed.
8. Test layout on narrow and large Android screens.
9. Import `docs/example_odk_Aviation.xlsx` and verify the `aviation.dashboard` group returns automatically without requiring a native Finish press.
10. Keep the module marked Development until these checks pass.
