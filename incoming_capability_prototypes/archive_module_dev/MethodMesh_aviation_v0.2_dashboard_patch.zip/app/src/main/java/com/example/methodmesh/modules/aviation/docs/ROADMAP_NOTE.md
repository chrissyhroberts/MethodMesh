# Aviation roadmap after v0.2

v0.2 establishes the persistent flight-deck surface and the shared location/airfield/runway plumbing.

Recommended next tranche:

1. **METAR/TAF provider** using MethodMesh online-data infrastructure, with raw report preservation and age/freshness indicators.
2. Feed METAR wind/QNH/OAT into `aviation.dashboard` so the existing conditions panel can switch from manual/supplied inputs to structured current-weather inputs.
3. **SIGMET / aviation warning intersection** for current location and later routes.
4. Route planner with waypoint/aerodrome selectors, leg distance/bearing, ETE and fuel estimate.
5. Aircraft profiles + weight/balance.
6. GPS track recorder / flight log.
7. Provider-specific NOTAM adapters only where licensing and operational-use terms permit.

Do not replace the dashboard with a monolith. New data sources should feed the dashboard through shared engines/repositories and retain atomic MethodMesh methods for composition, ODK and protocol use.
