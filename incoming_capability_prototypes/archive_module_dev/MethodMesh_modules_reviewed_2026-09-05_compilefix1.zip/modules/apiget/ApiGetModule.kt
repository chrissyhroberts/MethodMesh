package com.example.methodmesh.modules.apiget

import com.example.methodmesh.core.onlinedata.BundledApiDefinitions
import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object ApiGetModule : MethodMeshModule {
    override val moduleId = "apiget"
    override val displayName = "Online data and HTTP"
    override val summary = "Run declared API links or explicit bounded HTTP(S) requests with compact results and audit metadata."

    override fun as100Methods() = listOf(As100ApiGetMethod, As100ApiRequestMethod)

    override fun rilBindings() = listOf(
        RilBinding("get online api data", As100ApiGetMethod.ID, "Run a declared online API definition"),
        RilBinding("fetch api", As100ApiGetMethod.ID, "Fetch data from a declared API link"),
        RilBinding("send http request", As100ApiRequestMethod.ID, "Send an explicit HTTP(S) request"),
        RilBinding("call url", As100ApiRequestMethod.ID, "Send an explicit HTTP(S) request")
    )

    override fun capabilityScreens() = listOf(ApiGetCapabilityScreen, ApiRequestCapabilityScreen)

    override fun capabilitySettings() = mapOf(
        As100ApiGetMethod.ID to listOf(
            MethodSetting.ChoiceSetting(
                id = "definition_id",
                label = "API link",
                defaultValue = BundledApiDefinitions.openMeteoCurrentWeather.id,
                choices = BundledApiDefinitions.all.map { it.id },
                group = "Request"
            ),
            MethodSetting.TextSetting(
                id = "latitude",
                label = "Latitude",
                defaultValue = "52.0779",
                group = "Request"
            ),
            MethodSetting.TextSetting(
                id = "longitude",
                label = "Longitude",
                defaultValue = "-0.0580",
                group = "Request"
            ),
            MethodSetting.MultiChoiceSetting(
                id = "result_paths",
                label = "Returned fields",
                description = "Tree paths to return as useful values.",
                defaultValue = "current.temperature_2m|current.relative_humidity_2m",
                choices = BundledApiDefinitions.all.flatMap { definition ->
                    As100ApiGetMethod.resultPathOptions(definition).map { it.path }
                }.distinct(),
                delimiter = "|",
                group = "Return"
            ),
            MethodSetting.TextSetting(
                id = "fallback_value",
                label = "Fallback value",
                description = "Optional value to return if the selected path is blank or missing.",
                defaultValue = "",
                group = "Return"
            )
        ),
        As100ApiRequestMethod.ID to listOf(
            MethodSetting.TextSetting("url", "HTTP(S) URL", defaultValue = "", group = "Request"),
            MethodSetting.ChoiceSetting("http_method", "HTTP method", defaultValue = "GET", choices = listOf("GET", "POST", "PUT", "DELETE", "HEAD"), group = "Request"),
            MethodSetting.TextSetting("headers_json", "Request headers JSON", defaultValue = "{}", group = "Request"),
            MethodSetting.TextSetting("body", "Request body", defaultValue = "", group = "Request"),
            MethodSetting.IntSetting("timeout_ms", "Timeout", defaultValue = 10000, minimum = 1000, maximum = 30000, unit = "ms", group = "Limits"),
            MethodSetting.IntSetting("max_response_chars", "Maximum response characters", defaultValue = 100000, minimum = 256, maximum = 1000000, group = "Limits")
        )
    )
}