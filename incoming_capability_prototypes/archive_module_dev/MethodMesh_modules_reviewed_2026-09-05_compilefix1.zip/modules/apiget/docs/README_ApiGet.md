# Online data and HTTP

The existing `api.get` declared-provider capability remains unchanged. This module additionally contains a deliberately Development-stage general request utility.

## `api.request`

`api.request` performs one bounded, explicitly declared HTTP(S) request using `GET`, `POST`, `PUT`, `DELETE` or `HEAD`. It accepts a URL, request headers/body, timeout and maximum returned response characters. It returns status code, final URL, response headers/body, truncation indicator and elapsed time.

## Security boundary

This is **not a secret-storage boundary**. Probable credential-bearing header names (`Authorization`, `Proxy-Authorization`, `Cookie`, `Set-Cookie`, `X-API-Key`) are rejected. Audit metadata records request-header names, not header values, and stores a SHA-256 of the request body rather than copying that body into audit JSON.

Callers needing managed credentials should use a declared provider/secret mechanism rather than embedding secrets in this utility. The current implementation should therefore be used for public or otherwise non-secret requests.

## Limits and failures

- only absolute `http://` or `https://` URLs;
- timeout bounded to 1–30 seconds;
- response-body capture bounded to 256–1,000,000 characters;
- redirects/final URL are reported through the underlying HTTP connection behaviour;
- network and HTTP failures return explicit diagnostics.

Fixed preset settings are hidden with `settingShouldBeShown(...)`.

See `docs/example_odk_api.request.xlsx`.
