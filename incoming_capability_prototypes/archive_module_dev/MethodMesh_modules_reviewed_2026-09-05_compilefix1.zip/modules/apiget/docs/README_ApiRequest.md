# Generic HTTP request

**Status:** Development  
**Module:** `apiget`  
**Method:** `api.request`  
**Version:** `0.1.0`

## What it does
Runs one bounded HTTP(S) `GET`, `POST`, `PUT`, `DELETE` or `HEAD` request and returns status, final URL, response headers/body, truncation state and elapsed time.

## Native workflow
Enter URL/method, optional non-secret headers/body and limits; confirm; inspect the compact response result.

## Preset workflow
All request settings are declared by the module and fixed preset values are hidden with `settingShouldBeShown(...)`.

## ODK / XLSForm workflow
Use the grouped intent in `example_odk_api.request.xlsx`; ODK supplies values directly and receives response fields plus the standard FULL envelope when requested.

## Inputs
`url`, `http_method`, `headers_json`, `body`, `timeout_ms`, `max_response_chars`.

## Outputs
`api_request_status`, method/URL/final URL, HTTP status, content type, body, response headers JSON, truncation flag, duration, retrieval time, `api_request_audit_json`, and error.

## Main result
HTTP status and bounded response body.

## Audit / full metadata
Header **names**, not values, are recorded in audit. Request body is represented by SHA-256 rather than copied into audit metadata. Standard MethodMesh FULL payload mode remains available.

## Permissions/services and offline/online behaviour
This capability is online when executed: it requires network access to the explicitly supplied HTTP(S) endpoint. No third-party service is implicit.

## Security boundary / limitations
This is not a secret store. Credential-bearing headers including Authorization, Proxy-Authorization, Cookie/Set-Cookie and X-API-Key are rejected. Timeout is bounded to 1–30 seconds and body capture to 256–1,000,000 characters. Use declared provider/secret mechanisms for authenticated integrations.
