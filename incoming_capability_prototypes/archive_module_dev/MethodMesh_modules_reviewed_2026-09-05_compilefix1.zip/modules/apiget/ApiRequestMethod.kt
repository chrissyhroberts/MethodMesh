package com.example.methodmesh.modules.apiget

import com.example.methodmesh.core.crypto.Digests
import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.nio.charset.StandardCharsets
import java.time.Instant

object ApiRequestFields {
    const val STATUS = "api_request_status"
    const val METHOD = "api_request_method"
    const val URL = "api_request_url"
    const val FINAL_URL = "api_request_final_url"
    const val HTTP_STATUS = "api_request_http_status"
    const val CONTENT_TYPE = "api_request_content_type"
    const val RESPONSE_BODY = "api_request_response_body"
    const val RESPONSE_HEADERS_JSON = "api_request_response_headers_json"
    const val TRUNCATED = "api_request_response_truncated"
    const val DURATION_MS = "api_request_duration_ms"
    const val RETRIEVED_TIME_ISO = "api_request_retrieved_time_iso"
    const val AUDIT_JSON = "api_request_audit_json"
    const val ERROR = "api_request_error"
    val outputs = listOf(STATUS, METHOD, URL, FINAL_URL, HTTP_STATUS, CONTENT_TYPE, RESPONSE_BODY, RESPONSE_HEADERS_JSON, TRUNCATED, DURATION_MS, RETRIEVED_TIME_ISO, AUDIT_JSON, ERROR)
}

object As100ApiRequestMethod : As100Method {
    const val ID = "api.request"
    private const val VERSION = "0.1.0"
    private val allowedMethods = setOf("GET", "POST", "PUT", "DELETE", "HEAD")

    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "HTTP request")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID),
        methodType = MethodObjectType.Workflow,
        name = "HTTP request",
        version = VERSION,
        description = "Send a user-declared HTTP(S) request and return the bounded response plus audit metadata.",
        inputs = listOf("url", "http_method", "headers_json", "body"),
        outputs = ApiRequestFields.outputs,
        graphOutputs = listOf(ID),
        parameters = mapOf("category" to "Online data", "status" to "Development")
    )
    override val contract = MethodContract(
        method = ref,
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult =
        result(request, runRequest(request.context), InvocationContext.from(request.context))

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[ApiRequestFields.STATUS] == "succeeded"
        val entity = Entity(ArchitectureId("api-request:${System.currentTimeMillis()}"), "HttpResponse", temporalContext = request.temporalContext)
        val provenance = ProvenanceContext("java.net.HttpURLConnection", ID, VERSION)
        val observation = Observation(
            phenomenon = ID,
            subject = ArchitectureRef(entity.id, entity.objectType, ID),
            values = values,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        val transformation = Transformation(
            action = ID,
            method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request,
            if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOf(entity),
            observations = listOf(observation),
            transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf(ApiRequestFields.ERROR to values[ApiRequestFields.ERROR].orEmpty())
        ).withInvocationContext(invocation)
    }

    fun runRequest(settings: Map<String, String>): Map<String, String> {
        val started = System.nanoTime()
        val rawUrl = settings.requestValue("url")
        val method = settings.requestValue("http_method").ifBlank { "GET" }.uppercase()
        val timeoutMs = settings.requestValue("timeout_ms").toIntOrNull()?.coerceIn(1000, 30000) ?: 10000
        val maxChars = settings.requestValue("max_response_chars").toIntOrNull()?.coerceIn(256, 1_000_000) ?: 100_000
        val body = settings.requestValue("body")
        val headersText = settings.requestValue("headers_json")
        var connection: HttpURLConnection? = null
        return runCatching {
            require(rawUrl.isNotBlank()) { "URL is required." }
            require(method in allowedMethods) { "HTTP method must be one of ${allowedMethods.joinToString()}." }
            val uri = URI(rawUrl)
            require(uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank()) { "Only absolute HTTP or HTTPS URLs are supported." }
            val headers = parseHeaders(headersText)
            connection = URL(rawUrl).openConnection() as HttpURLConnection
            val conn = requireNotNull(connection)
            conn.requestMethod = method
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.instanceFollowRedirects = true
            conn.useCaches = false
            headers.forEach { (name, value) -> conn.setRequestProperty(name, value) }
            if (body.isNotEmpty() && method in setOf("POST", "PUT", "DELETE")) {
                conn.doOutput = true
                if (headers.keys.none { it.equals("Content-Type", ignoreCase = true) }) {
                    val inferred = if (body.trimStart().startsWith("{") || body.trimStart().startsWith("[")) "application/json; charset=UTF-8" else "text/plain; charset=UTF-8"
                    conn.setRequestProperty("Content-Type", inferred)
                }
                val bytes = body.toByteArray(StandardCharsets.UTF_8)
                conn.setFixedLengthStreamingMode(bytes.size)
                conn.outputStream.use { it.write(bytes) }
            }
            val statusCode = conn.responseCode
            val stream = if (statusCode >= 400) conn.errorStream else conn.inputStream
            val rawResponse = if (method == "HEAD" || stream == null) "" else stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val truncated = rawResponse.length > maxChars
            val response = if (truncated) rawResponse.take(maxChars) else rawResponse
            val responseHeaders = linkedMapOf<String, String>()
            conn.headerFields.orEmpty().forEach { (key, values) ->
                if (key != null) responseHeaders[key] = values.orEmpty().joinToString(", ")
            }
            val finalUrl = conn.url?.toString().orEmpty().ifBlank { rawUrl }
            val elapsedMs = (System.nanoTime() - started) / 1_000_000L
            val audit = JSONObject().apply {
                put("method_id", ID)
                put("version", VERSION)
                put("http_method", method)
                put("request_url", rawUrl)
                put("final_url", finalUrl)
                put("http_status", statusCode)
                put("request_header_names", org.json.JSONArray(headers.keys.toList()))
                put("request_body_sha256", if (body.isBlank()) JSONObject.NULL else Digests.sha256Hex(body))
                put("response_truncated", truncated)
                put("response_character_limit", maxChars)
                put("duration_ms", elapsedMs)
                put("retrieved_time_iso", Instant.now().toString())
            }.toString()
            linkedMapOf(
                ApiRequestFields.STATUS to if (statusCode in 200..399) "succeeded" else "failed",
                ApiRequestFields.METHOD to method,
                ApiRequestFields.URL to rawUrl,
                ApiRequestFields.FINAL_URL to finalUrl,
                ApiRequestFields.HTTP_STATUS to statusCode.toString(),
                ApiRequestFields.CONTENT_TYPE to conn.contentType.orEmpty(),
                ApiRequestFields.RESPONSE_BODY to response,
                ApiRequestFields.RESPONSE_HEADERS_JSON to JSONObject(responseHeaders as Map<*, *>).toString(),
                ApiRequestFields.TRUNCATED to truncated.toString(),
                ApiRequestFields.DURATION_MS to elapsedMs.toString(),
                ApiRequestFields.RETRIEVED_TIME_ISO to Instant.now().toString(),
                ApiRequestFields.AUDIT_JSON to audit,
                ApiRequestFields.ERROR to if (statusCode in 200..399) "" else "HTTP $statusCode"
            )
        }.getOrElse { error ->
            val elapsedMs = (System.nanoTime() - started) / 1_000_000L
            linkedMapOf(
                ApiRequestFields.STATUS to "failed",
                ApiRequestFields.METHOD to method,
                ApiRequestFields.URL to rawUrl,
                ApiRequestFields.FINAL_URL to "",
                ApiRequestFields.HTTP_STATUS to "",
                ApiRequestFields.CONTENT_TYPE to "",
                ApiRequestFields.RESPONSE_BODY to "",
                ApiRequestFields.RESPONSE_HEADERS_JSON to "{}",
                ApiRequestFields.TRUNCATED to "false",
                ApiRequestFields.DURATION_MS to elapsedMs.toString(),
                ApiRequestFields.RETRIEVED_TIME_ISO to Instant.now().toString(),
                ApiRequestFields.AUDIT_JSON to JSONObject().apply {
                    put("method_id", ID); put("version", VERSION); put("http_method", method); put("request_url", rawUrl); put("duration_ms", elapsedMs); put("error", error.message.orEmpty())
                }.toString(),
                ApiRequestFields.ERROR to (error.message ?: "HTTP request failed.")
            )
        }.also { connection?.disconnect() }
    }

    private fun parseHeaders(raw: String): Map<String, String> {
        if (raw.isBlank()) return emptyMap()
        val json = JSONObject(raw)
        return buildMap {
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = json.optString(key, "")
                require(key.isNotBlank() && !key.contains('\n') && !key.contains('\r')) { "Invalid header name." }
                require(!value.contains('\n') && !value.contains('\r')) { "Header values cannot contain line breaks." }
                require(key.lowercase() !in setOf("authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key")) {
                    "Secret-bearing authentication/cookie headers are intentionally not accepted by this Development-stage utility. Use a declared API provider with an appropriate secret boundary instead."
                }
                put(key, value)
            }
        }
    }

    private fun Map<String, String>.requestValue(key: String): String = (this[key] ?: this["input_$key"]).orEmpty()
}
