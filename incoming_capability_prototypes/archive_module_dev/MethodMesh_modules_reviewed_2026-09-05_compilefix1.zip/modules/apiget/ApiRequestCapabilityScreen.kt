package com.example.methodmesh.modules.apiget

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object ApiRequestCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100ApiRequestMethod.ID
    override val title = "HTTP request"
    override val description = "Send a bounded HTTP(S) request and inspect the returned status, headers and body."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val scope = rememberCoroutineScope()
        var url by rememberSaveable { mutableStateOf(context.setting("url", "")) }
        var method by rememberSaveable { mutableStateOf(context.setting("http_method", "GET")) }
        var headers by rememberSaveable { mutableStateOf(context.setting("headers_json", "{}")) }
        var body by rememberSaveable { mutableStateOf(context.setting("body", "")) }
        var timeout by rememberSaveable { mutableStateOf(context.setting("timeout_ms", "10000")) }
        var maxChars by rememberSaveable { mutableStateOf(context.setting("max_response_chars", "100000")) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var running by rememberSaveable { mutableStateOf(false) }
        var attempted by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun settings() = mapOf("url" to url, "http_method" to method, "headers_json" to headers, "body" to body, "timeout_ms" to timeout, "max_response_chars" to maxChars)

        LaunchedEffect(url, method, headers, body, timeout, maxChars) { context.onSettingsChanged(settings()) }

        fun runRequest() {
            if (running) return
            running = true
            scope.launch {
                val request = As100ApiRequestMethod.request(
                    action = As100ApiRequestMethod.ID,
                    context = context.request.invocationContext.asMap(As100ApiRequestMethod.ID) + context.request.settings + context.action.settings + settings(),
                    signals = emptyList(),
                    inputs = emptyList()
                )
                val execution = withContext(Dispatchers.IO) { As100ApiRequestMethod.execute(request, null, context.request.source) }
                result = execution
                running = false
                if (context.submitsImmediately) onConfirmed(execution)
            }
        }

        LaunchedEffect(context.startsImmediately, url, method, headers, body, timeout, maxChars) {
            if (context.startsImmediately && !attempted && url.isNotBlank()) {
                attempted = true
                runRequest()
            }
        }

        val preview = result?.let { fields ->
            val all = OutputFormatter.fields(fields, includeProvenance = false)
            linkedMapOf<String, Any?>().apply {
                listOf(ApiRequestFields.STATUS, ApiRequestFields.HTTP_STATUS, ApiRequestFields.CONTENT_TYPE, ApiRequestFields.RESPONSE_BODY, ApiRequestFields.TRUNCATED, ApiRequestFields.ERROR).forEach { key ->
                    all[key]?.let { put(key, it) }
                }
            }
        }.orEmpty()

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = preview,
            onBack = onBack,
            onRetry = { runRequest() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            Text("This is an explicit operator/API workbench. Header names are auditable, but secret-bearing authentication/cookie headers are rejected by this Development-stage utility rather than being persisted as ordinary capability settings.")
            Spacer(Modifier.height(8.dp))
            if (context.settingShouldBeShown("url")) OutlinedTextField(url, { url = it }, label = { Text("HTTP(S) URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            if (context.settingShouldBeShown("http_method")) ApiRequestMethodChooser(method) { method = it }
            if (context.settingShouldBeShown("headers_json")) OutlinedTextField(headers, { headers = it }, label = { Text("Request headers JSON") }, minLines = 2, modifier = Modifier.fillMaxWidth())
            if (method in setOf("POST", "PUT", "DELETE") && context.settingShouldBeShown("body")) OutlinedTextField(body, { body = it }, label = { Text("Request body") }, minLines = 4, modifier = Modifier.fillMaxWidth())
            if (context.settingShouldBeShown("timeout_ms")) OutlinedTextField(timeout, { timeout = it.filter(Char::isDigit) }, label = { Text("Timeout (ms)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            if (context.settingShouldBeShown("max_response_chars")) OutlinedTextField(maxChars, { maxChars = it.filter(Char::isDigit) }, label = { Text("Maximum response characters") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { runRequest() }, enabled = !running && url.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (running) "Sending…" else "Send request") }
        }
    }
}

@Composable
private fun ApiRequestMethodChooser(selected: String, onSelected: (String) -> Unit) {
    Text("HTTP method")
    listOf("GET", "POST", "PUT", "DELETE", "HEAD").chunked(3).forEach { row ->
        androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth()) {
            row.forEach { choice ->
                if (choice == selected) androidx.compose.material3.Button(onClick = { onSelected(choice) }, modifier = Modifier.weight(1f)) { Text("✓ $choice") }
                else androidx.compose.material3.OutlinedButton(onClick = { onSelected(choice) }, modifier = Modifier.weight(1f)) { Text(choice) }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

private fun CapabilityScreenContext.setting(key: String, fallback: String): String =
    action.settings[key] ?: action.settings["input_$key"] ?: request.settings[key] ?: request.settings["input_$key"] ?: fallback
