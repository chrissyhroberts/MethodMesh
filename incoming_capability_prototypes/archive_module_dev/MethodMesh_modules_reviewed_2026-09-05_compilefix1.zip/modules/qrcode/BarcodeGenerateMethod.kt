package com.example.methodmesh.modules.qrcode

import com.example.methodmesh.core.crypto.Digests
import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import java.time.Instant

object BarcodeGenerateFields {
    const val STATUS = "barcode_generate_status"
    const val PAYLOAD = "barcode_generate_payload"
    const val FORMAT = "barcode_generate_format"
    const val IMAGE_URI = "barcode_generate_image_uri"
    const val IMAGE_NAME = "barcode_generate_image_name"
    const val WIDTH_PX = "barcode_generate_width_px"
    const val HEIGHT_PX = "barcode_generate_height_px"
    const val PAYLOAD_SHA256 = "barcode_generate_payload_sha256"
    const val GENERATED_TIME_ISO = "barcode_generate_time_iso"
    const val ERROR = "barcode_generate_error"
    val outputs = listOf(STATUS, PAYLOAD, FORMAT, IMAGE_URI, IMAGE_NAME, WIDTH_PX, HEIGHT_PX, PAYLOAD_SHA256, GENERATED_TIME_ISO, ERROR)
}

object As100BarcodeGenerateMethod : As100Method {
    const val ID = "barcode.generate"
    private const val VERSION = "0.1.0"

    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Generate QR or barcode")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID),
        methodType = MethodObjectType.Calculation,
        name = "Generate QR or barcode",
        version = VERSION,
        description = "Render supplied text as a QR, Data Matrix, or common 1D barcode image.",
        outputs = BarcodeGenerateFields.outputs,
        graphOutputs = listOf("barcode.generated"),
        parameters = mapOf("category" to "Codes", "status" to "Development")
    )
    override val contract = MethodContract(
        method = ref,
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult =
        result(
            request,
            failure("Barcode rendering requires the capability screen so Android can create and expose the image file."),
            InvocationContext.from(request.context)
        )

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[BarcodeGenerateFields.STATUS] == "succeeded"
        val provenance = ProvenanceContext("methodmesh.barcode", ID, VERSION)
        val observation = Observation(
            phenomenon = "barcode.generated",
            subject = invocation?.subjectRef(),
            values = values,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        val transformation = Transformation(
            action = ID,
            method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request = request,
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            observations = listOf(observation),
            transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf(BarcodeGenerateFields.ERROR to values[BarcodeGenerateFields.ERROR].orEmpty())
        ).withInvocationContext(invocation)
    }

    fun success(payload: String, format: String, imageUri: String, imageName: String, width: Int, height: Int): Map<String, String> = linkedMapOf(
        BarcodeGenerateFields.STATUS to "succeeded",
        BarcodeGenerateFields.PAYLOAD to payload,
        BarcodeGenerateFields.FORMAT to format,
        BarcodeGenerateFields.IMAGE_URI to imageUri,
        BarcodeGenerateFields.IMAGE_NAME to imageName,
        BarcodeGenerateFields.WIDTH_PX to width.toString(),
        BarcodeGenerateFields.HEIGHT_PX to height.toString(),
        BarcodeGenerateFields.PAYLOAD_SHA256 to Digests.sha256Hex(payload),
        BarcodeGenerateFields.GENERATED_TIME_ISO to Instant.now().toString(),
        BarcodeGenerateFields.ERROR to ""
    )

    fun failure(message: String): Map<String, String> = linkedMapOf(
        BarcodeGenerateFields.STATUS to "failed",
        BarcodeGenerateFields.PAYLOAD to "",
        BarcodeGenerateFields.FORMAT to "",
        BarcodeGenerateFields.IMAGE_URI to "",
        BarcodeGenerateFields.IMAGE_NAME to "",
        BarcodeGenerateFields.WIDTH_PX to "",
        BarcodeGenerateFields.HEIGHT_PX to "",
        BarcodeGenerateFields.PAYLOAD_SHA256 to "",
        BarcodeGenerateFields.GENERATED_TIME_ISO to Instant.now().toString(),
        BarcodeGenerateFields.ERROR to message
    )
}
