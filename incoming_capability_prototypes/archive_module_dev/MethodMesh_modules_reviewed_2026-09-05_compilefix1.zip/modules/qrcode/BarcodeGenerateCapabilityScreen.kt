package com.example.methodmesh.modules.qrcode

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.File
import java.io.FileOutputStream

object BarcodeGenerateCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100BarcodeGenerateMethod.ID
    override val title = "Generate QR or barcode"
    override val description = "Render text as a QR, Data Matrix, or common 1D barcode image."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        var payload by rememberSaveable { mutableStateOf(context.action.settings["payload"] ?: context.action.settings["input_payload"] ?: "") }
        var format by rememberSaveable { mutableStateOf(context.action.settings["format"] ?: context.action.settings["input_format"] ?: "QR_CODE") }
        var size by rememberSaveable { mutableStateOf(context.action.settings["size_px"] ?: context.action.settings["input_size_px"] ?: "512") }
        var margin by rememberSaveable { mutableStateOf(context.action.settings["margin_modules"] ?: context.action.settings["input_margin_modules"] ?: "2") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var preview by remember { mutableStateOf<Bitmap?>(null) }
        var ranImmediately by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        LaunchedEffect(payload, format, size, margin) {
            context.onSettingsChanged(mapOf("payload" to payload, "format" to format, "size_px" to size, "margin_modules" to margin))
        }

        fun generate() {
            val execution = runCatching {
                require(payload.isNotEmpty()) { "Payload is required." }
                val barcodeFormat = BarcodeFormat.valueOf(format)
                val requestedSize = size.toIntOrNull()?.coerceIn(128, 2048) ?: 512
                val marginModules = margin.toIntOrNull()?.coerceIn(0, 20) ?: 2
                val isOneDimensional = barcodeFormat in setOf(
                    BarcodeFormat.CODE_128,
                    BarcodeFormat.CODE_39,
                    BarcodeFormat.EAN_13,
                    BarcodeFormat.EAN_8,
                    BarcodeFormat.UPC_A,
                    BarcodeFormat.UPC_E
                )
                val width = if (isOneDimensional) requestedSize.coerceAtLeast(320) else requestedSize
                val height = if (isOneDimensional) (requestedSize / 3).coerceAtLeast(120) else requestedSize
                val matrix = MultiFormatWriter().encode(
                    payload,
                    barcodeFormat,
                    width,
                    height,
                    mapOf(EncodeHintType.MARGIN to marginModules)
                )
                val pixels = IntArray(width * height)
                for (y in 0 until height) {
                    val rowOffset = y * width
                    for (x in 0 until width) {
                        pixels[rowOffset + x] = if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
                    }
                }
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                    setPixels(pixels, 0, width, 0, 0, width, height)
                }
                val safeFormat = format.lowercase().replace(Regex("[^a-z0-9]+"), "-")
                val file = File(appContext.cacheDir, "methodmesh-$safeFormat-${System.currentTimeMillis()}.png")
                FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.fileprovider", file).toString()
                preview = bitmap
                val request = As100BarcodeGenerateMethod.request(
                    action = As100BarcodeGenerateMethod.ID,
                    context = context.request.invocationContext.asMap(As100BarcodeGenerateMethod.ID) + context.action.settings + mapOf(
                        "payload" to payload,
                        "format" to format,
                        "size_px" to requestedSize.toString(),
                        "margin_modules" to marginModules.toString()
                    ),
                    signals = emptyList(),
                    inputs = emptyList()
                )
                As100BarcodeGenerateMethod.result(
                    request,
                    As100BarcodeGenerateMethod.success(payload, format, uri, file.name, width, height),
                    context.request.invocationContext
                )
            }.getOrElse { error ->
                preview = null
                val request = As100BarcodeGenerateMethod.request(
                    action = As100BarcodeGenerateMethod.ID,
                    context = context.request.invocationContext.asMap(As100BarcodeGenerateMethod.ID) + context.action.settings,
                    signals = emptyList(),
                    inputs = emptyList()
                )
                As100BarcodeGenerateMethod.result(
                    request,
                    As100BarcodeGenerateMethod.failure(error.message ?: "Barcode generation failed."),
                    context.request.invocationContext
                )
            }
            result = execution
            if (context.submitsImmediately) onConfirmed(execution)
        }

        LaunchedEffect(context.startsImmediately, payload, format, size, margin) {
            if (context.startsImmediately && !ranImmediately && payload.isNotEmpty()) {
                ranImmediately = true
                generate()
            }
        }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = result,
            resultPreview = result?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { generate() },
            onConfirm = { result?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            if (context.settingShouldBeShown("payload")) {
                OutlinedTextField(payload, { payload = it }, label = { Text("Payload") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            }
            if (context.settingShouldBeShown("format")) {
                BarcodeGenerateChoice("Format", format, listOf("QR_CODE", "DATA_MATRIX", "CODE_128", "CODE_39", "EAN_13", "EAN_8", "UPC_A", "UPC_E")) { format = it }
            }
            if (context.settingShouldBeShown("size_px")) {
                OutlinedTextField(size, { size = it.filter(Char::isDigit) }, label = { Text("Image size (px)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (context.settingShouldBeShown("margin_modules")) {
                OutlinedTextField(margin, { margin = it.filter(Char::isDigit) }, label = { Text("Quiet-zone margin (modules)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = ::generate, enabled = payload.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text(if (result == null) "Generate" else "Generate again") }
            preview?.let {
                Spacer(Modifier.height(14.dp))
                Image(bitmap = it.asImageBitmap(), contentDescription = "Generated code", modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun BarcodeGenerateChoice(label: String, selected: String, choices: List<String>, onSelected: (String) -> Unit) {
    Text(label)
    choices.chunked(2).forEach { row ->
        androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth()) {
            row.forEach { choice ->
                val selectedChoice = choice == selected
                if (selectedChoice) {
                    Button(onClick = { onSelected(choice) }, modifier = Modifier.weight(1f)) { Text("✓ ${choice.replace('_', ' ')}") }
                } else {
                    androidx.compose.material3.OutlinedButton(onClick = { onSelected(choice) }, modifier = Modifier.weight(1f)) { Text(choice.replace('_', ' ')) }
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}
