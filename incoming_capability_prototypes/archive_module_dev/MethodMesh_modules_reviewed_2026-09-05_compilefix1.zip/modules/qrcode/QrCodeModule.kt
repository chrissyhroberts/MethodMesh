package com.example.methodmesh.modules.qrcode

import com.example.methodmesh.modules.ModuleExample
import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object QrCodeModule : MethodMeshModule {
    override val moduleId: String = "barcode"
    override val displayName: String = "Automatic code scanner"
    override val summary: String = "Automatically capture QR, Data Matrix, and common 1D barcode evidence."

    override fun as100Methods() = listOf(As100BarcodeScanMethod, As100BarcodeGenerateMethod)

    override fun rilBindings() = listOf(
        RilBinding("scan qr", As100BarcodeScanMethod.ID, "Capture a QR token as verifiable workflow evidence"),
        RilBinding("read qr", As100BarcodeScanMethod.ID, "Capture a QR token as verifiable workflow evidence"),
        RilBinding("capture qr", As100BarcodeScanMethod.ID, "Capture a QR token as verifiable workflow evidence"),
        RilBinding("scan qr token", As100BarcodeScanMethod.ID, "Capture a QR token as verifiable workflow evidence"),
        RilBinding("scan code", As100BarcodeScanMethod.ID, "Automatically capture a supported 1D or 2D code"),
        RilBinding("scan barcode", As100BarcodeScanMethod.ID, "Automatically capture a supported 1D or 2D code"),
        RilBinding("scan data matrix", As100BarcodeScanMethod.ID, "Capture a Data Matrix code"),
        RilBinding("generate qr", As100BarcodeGenerateMethod.ID, "Render supplied text as a QR code image"),
        RilBinding("generate barcode", As100BarcodeGenerateMethod.ID, "Render supplied text as a supported 1D or 2D code")
    )

    override fun capabilityScreens() = listOf(BarcodeScanCapabilityScreen, BarcodeGenerateCapabilityScreen)

    private val scannerSettings = listOf(
        MethodSetting.MultiChoiceSetting(
            "barcode_formats",
            "Accepted code formats",
            "Leave automatic on to accept every supported format, or choose specific barcode formats.",
            "Scanner",
            "",
            listOf(
                "QR_CODE",
                "DATA_MATRIX",
                "CODE_128",
                "CODE_39",
                "EAN_13",
                "EAN_8",
                "UPC_A",
                "UPC_E"
            ),
            emptyMeansAll = true
        )
    )

    override fun capabilitySettings() = mapOf(
        As100BarcodeScanMethod.ID to scannerSettings,
        As100BarcodeGenerateMethod.ID to listOf(
            MethodSetting.TextSetting("payload", "Payload", defaultValue = ""),
            MethodSetting.ChoiceSetting("format", "Code format", defaultValue = "QR_CODE", choices = listOf("QR_CODE", "DATA_MATRIX", "CODE_128", "CODE_39", "EAN_13", "EAN_8", "UPC_A", "UPC_E")),
            MethodSetting.IntSetting("size_px", "Image size", defaultValue = 512, minimum = 128, maximum = 2048, unit = "px"),
            MethodSetting.IntSetting("margin_modules", "Quiet-zone margin", defaultValue = 2, minimum = 0, maximum = 20)
        )
    )

    override fun examples() = listOf(
        ModuleExample(
            title = "Capture a QR, Data Matrix, or barcode token",
            ril = "WHAT; scan barcode; WHERE; participant/P001; RESULT; return barcode_payload, barcode_format; format json",
            notes = "This is a standalone code-scanning capability so other modules, including attestation, can depend on captured code evidence rather than reimplementing scanner behaviour."
        ),
        ModuleExample(
            title = "Generate a QR code",
            ril = "WHAT; generate qr; WITH; payload=https://example.org; RESULT; return barcode_generate_image_uri, barcode_generate_payload; format json",
            notes = "Generation is paired with scanning in the same code module and returns a shareable PNG URI plus auditable payload metadata."
        )
    )
}
