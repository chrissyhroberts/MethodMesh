# Barcode generation

**Status:** Development  
**Module:** `barcode` (`modules/qrcode`)  
**Method:** `barcode.generate`

## What it does
Generates a local PNG for QR Code, Data Matrix, Code 128, Code 39, EAN-13, EAN-8 or UPC-A payloads using the barcode facilities already available to the module.

## Native workflow
Choose format, payload and size, generate, preview and use/share the resulting image.

## Preset workflow
Format/size can be fixed in presets; runtime payload can remain unfixed. Fixed settings are hidden by the capability screen.

## ODK / XLSForm workflow
`example_odk_barcode.generate.xlsx` supplies a grouped intent and receives the generated media URI plus structured fields.

## Inputs
Barcode `format`, payload/content and requested output dimension according to the module settings.

## Outputs and main result
Status, format/payload metadata, generated image URI/name/dimensions, payload fingerprint/provenance and error. The generated PNG is the main result.

## Audit / full metadata
Structured generation metadata is returned; standard MethodMesh FULL mode can retain the complete execution envelope.

## Permissions/services and offline behaviour
Fully offline. No camera permission is required for generation.

## Known limitations
Format-specific payload rules still apply (for example numeric/check-digit constraints for EAN/UPC). Generation does not assert that a downstream scanner will accept non-conformant payloads.
