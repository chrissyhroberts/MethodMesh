# Phone sensors

**Status:** Development  
**Module:** `phonesensors`  
**Method:** `phone.sensor.measure`  
**Version:** `0.1.0`

## What it does

Provides generic snapshot or bounded time-series measurement from the existing shared Android `PhoneSensorRepository`. It does not add a new sensor listener stack and does not change MethodMesh core.

Supported metrics are acceleration magnitude in g, magnetic-field magnitude in µT, pressure in hPa, pitch, roll and magnetic/device heading in degrees.

## Native workflow

Choose metric and snapshot/record mode. Snapshot captures the current shared sensor value. Record mode samples for a bounded duration/interval and returns the series plus summary statistics.

## Preset workflow

Metric/mode/duration/interval are declared settings. Fixed preset values disappear through `settingShouldBeShown(...)`.

## ODK / XLSForm workflow

The supplied workbook demonstrates snapshot and bounded-record grouped intent calls.

## Inputs

| Input | Meaning |
|---|---|
| `metric` | One of the declared sensor-derived metrics. |
| `mode` | `snapshot` or `record`. |
| `duration_ms` | Bounded record duration, maximum 60 seconds. |
| `sample_interval_ms` | Sampling interval, minimum 100 ms. |

## Outputs

Status, metric/mode, current value/unit, sample count, mean/min/max/SD, duration/interval, samples JSON, sensor availability/accuracy, capture time and error fields.

## Main result

Snapshot: current value + unit. Record: compact summary statistics; `phone_sensor_samples_json` carries the bounded trace when needed.

## Audit / full metadata

The method descriptor records `PhoneSensorRepository` as the sensor boundary. Normal MethodMesh FULL payload mode provides the execution audit envelope.

## Permissions and services

Uses the existing MethodMesh phone-sensor boundary. Standard accelerometer/magnetometer/barometer/orientation sensors do not require runtime permission, but availability varies by device.

## Offline / online behaviour

Fully offline.

## Known limitations

- Values are phone instrumentation, not certified/calibrated scientific measurements unless separately calibrated/validated.
- Magnetic readings are vulnerable to nearby magnets/steel/electronics.
- Pressure sensors are not present on all phones.
- Acceleration magnitude is reported as acceleration magnitude; the capability does not mislabel it as a calibrated vibration meter.

## ODK example

`docs/example_odk_PhoneSensors.xlsx`
