# Sun and Moon utility

**Status:** Development  
**Module:** `astronomy`  
**Method:** `astronomy.sun_moon`

## What it does
Calculates current Sun/Moon altitude and azimuth plus next sunrise, sunset, civil/nautical/astronomical twilight, moonrise and moonset for a supplied/resolved location and time.

## Native workflow
Resolve or enter location/time, calculate, then use the compact Sun/Moon result and event times.

## Preset workflow
Location/time settings can be fixed or supplied at runtime using the existing Astronomy setting/preset machinery; fixed values are hidden by the module's screen logic.

## ODK / XLSForm workflow
`example_odk_astronomy.sun_moon.xlsx` makes a grouped MethodMesh intent and returns the useful event fields.

## Inputs
Latitude/longitude and observation date/time through the existing Astronomy setting context; the screen can use the module's existing location-resolution paths where available.

## Outputs and main result
`astronomy.sun_moon` returns a human-readable result plus solar/lunar altitude/azimuth and next event timestamps, with explicit error/status fields. The human-readable result and event timestamps are the primary result.

## Audit / full metadata
Normal Astronomy/MethodMesh provenance and FULL payload handling apply.

## Permissions/services and offline behaviour
The astronomical calculation itself is deterministic/offline. Location acquisition, when the operator elects to use it, follows the existing Astronomy/MethodMesh location boundary and permission model.

## Known limitations
Rise/set events depend on location/date and standard geometric definitions; the capability is not a navigational almanac certification service.
