package com.example.methodmesh.modules.texttools

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.*

object TextTransformCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextTransformMethod.id; override val title = "Text transformer"; override val description = "Case, whitespace, line and replacement tools."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var operation by rememberSaveable { mutableStateOf(context.setting("operation", "trim")) }; var text by rememberSaveable { mutableStateOf(context.setting("text", "")) }; var find by rememberSaveable { mutableStateOf(context.setting("find", "")) }; var replace by rememberSaveable { mutableStateOf(context.setting("replace", "")) }
        TextToolScaffold(context, As100TextTransformMethod, title, onBack, onConfirmed, onCancel, { mapOf("operation" to operation, "text" to text, "find" to find, "replace" to replace) }) {
            if (context.settingShouldBeShown("operation")) {
                SimpleChoice(listOf("uppercase","lowercase","title_case","trim","normalize_whitespace","sort_lines","deduplicate_lines","reverse_lines","find_replace"), operation) { operation = it }
            }
            if (context.settingShouldBeShown("text")) {
                OutlinedTextField(text, { text = it }, label = { Text("Text") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
            }
            if (operation == "find_replace" && context.settingShouldBeShown("find")) {
                OutlinedTextField(find, { find = it }, label = { Text("Find") }, modifier = Modifier.fillMaxWidth())
            }
            if (operation == "find_replace" && context.settingShouldBeShown("replace")) {
                OutlinedTextField(replace, { replace = it }, label = { Text("Replace with") }, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
object TextStatsCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextStatsMethod.id; override val title = "Text statistics"; override val description = "Character, word, line and unique-word counts."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var text by rememberSaveable { mutableStateOf(context.setting("text", "")) }
        TextToolScaffold(context, As100TextStatsMethod, title, onBack, onConfirmed, onCancel, { mapOf("text" to text) }) {
            if (context.settingShouldBeShown("text")) OutlinedTextField(text, { text = it }, label = { Text("Text") }, modifier = Modifier.fillMaxWidth(), minLines = 6)
        }
    }
}
object TextDiffCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextDiffMethod.id; override val title = "Line diff"; override val description = "Compare two texts line by line."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var left by rememberSaveable { mutableStateOf(context.setting("left", "")) }; var right by rememberSaveable { mutableStateOf(context.setting("right", "")) }
        TextToolScaffold(context, As100TextDiffMethod, title, onBack, onConfirmed, onCancel, { mapOf("left" to left, "right" to right) }) {
            if (context.settingShouldBeShown("left")) OutlinedTextField(left, { left = it }, label = { Text("Original") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
            if (context.settingShouldBeShown("right")) OutlinedTextField(right, { right = it }, label = { Text("Revised") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
        }
    }
}
@Composable private fun TextToolScaffold(context: CapabilityScreenContext, method: BaseTextToolMethod, title: String, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit, settings: () -> Map<String,String>, content: @Composable () -> Unit) {
    var result by remember { mutableStateOf<ExecutionResult?>(null) }; var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
    fun run() { val input=settings(); context.onSettingsChanged(input); val req=method.request(method.id, context.request.invocationContext.asMap(method.id)+context.request.settings+context.action.settings+input, emptyList(), emptyList()); result=method.result(req, method.calculate(input), context.request.invocationContext); if(context.submitsImmediately) result?.let(onConfirmed) }
    LaunchedEffect(context.startsImmediately) { if(context.startsImmediately && !launched){launched=true;run()} }
    CapabilityScreenScaffold(title,method.id,context,context.stepNumber>1,result,result?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack,{run()},{result?.let(onConfirmed)},onCancel){ Column(Modifier.fillMaxWidth()){content();Spacer(Modifier.height(8.dp));Button({run()},Modifier.fillMaxWidth()){Text("Run")}} }
}
@Composable private fun SimpleChoice(choices: List<String>, selected: String, onSelect: (String)->Unit) { choices.forEach { c -> androidx.compose.material3.OutlinedButton(onClick={onSelect(c)},modifier=Modifier.fillMaxWidth()){Text(if(c==selected) "✓ ${c.replace('_',' ')}" else c.replace('_',' '))} } }
private fun CapabilityScreenContext.setting(key:String,fallback:String)=action.settings[key]?:action.settings["input_$key"]?:request.settings[key]?:request.settings["input_$key"]?:fallback
