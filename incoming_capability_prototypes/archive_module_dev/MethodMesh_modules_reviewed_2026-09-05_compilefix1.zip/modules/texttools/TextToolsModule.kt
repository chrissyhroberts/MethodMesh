package com.example.methodmesh.modules.texttools
import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting
object TextToolsModule : MethodMeshModule {
    override val moduleId="texttools"; override val displayName="Text tools"; override val summary="Offline text transforms, counts and line-by-line comparison."
    override fun as100Methods()=listOf(As100TextTransformMethod,As100TextStatsMethod,As100TextDiffMethod)
    override fun rilBindings()=listOf(RilBinding("transform text",As100TextTransformMethod.id),RilBinding("clean text",As100TextTransformMethod.id),RilBinding("count words",As100TextStatsMethod.id),RilBinding("text statistics",As100TextStatsMethod.id),RilBinding("compare text",As100TextDiffMethod.id),RilBinding("diff text",As100TextDiffMethod.id))
    override fun capabilityScreens()=listOf(TextTransformCapabilityScreen,TextStatsCapabilityScreen,TextDiffCapabilityScreen)
    override fun capabilitySettings()=mapOf(
        As100TextTransformMethod.id to listOf(MethodSetting.ChoiceSetting("operation","Operation",defaultValue="trim",choices=listOf("uppercase","lowercase","title_case","trim","normalize_whitespace","sort_lines","deduplicate_lines","reverse_lines","find_replace")),MethodSetting.TextSetting("text","Text",defaultValue=""),MethodSetting.TextSetting("find","Find",defaultValue=""),MethodSetting.TextSetting("replace","Replace",defaultValue="")),
        As100TextStatsMethod.id to listOf(MethodSetting.TextSetting("text","Text",defaultValue="")),
        As100TextDiffMethod.id to listOf(MethodSetting.TextSetting("left","Original text",defaultValue=""),MethodSetting.TextSetting("right","Revised text",defaultValue=""))
    )
}
