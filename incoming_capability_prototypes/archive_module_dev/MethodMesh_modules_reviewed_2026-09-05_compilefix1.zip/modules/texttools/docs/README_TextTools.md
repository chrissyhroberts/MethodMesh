# Text tools

**Status:** Development  
**Module:** `texttools`  
**Methods:** `text.transform`, `text.stats`, `text.diff`  
**Version:** `0.1.0`

## What it does

Offline transformations and inspection for small text values.

- `text.transform`: uppercase/lowercase/title case, trim, whitespace normalisation, line sorting, line deduplication, line reversal, find/replace.
- `text.stats`: character, non-space, word, line and unique-word counts.
- `text.diff`: bounded line-level added/removed/unchanged comparison.

## Native workflow

Enter or receive text, choose the declared operation, then run. The transformed text or compact statistics are the primary result.

## Preset workflow

Settings are declared by the module. Fixed operation/search values disappear during native preset execution; runtime text can remain unfixed and requested at run time.

## ODK / XLSForm workflow

The supplied workbook demonstrates grouped intent calls for transform, statistics and diff.

## Inputs

`text.transform`: `operation`, `text`, optional `find`, optional `replace`.  
`text.stats`: `text`.  
`text.diff`: `left`, `right`.

## Outputs

Outputs include status, operation, SHA-256 of source input, transformed text, text counts, diff counts, `texttool_audit_json`, and `texttool_error`.

## Main result

The transformed text for `text.transform`; compact counts for `text.stats`; added/removed/unchanged counts for `text.diff`.

## Audit / full metadata

Raw source text is not copied into audit metadata merely for provenance. The module emits an input SHA-256 and compact audit JSON; standard MethodMesh FULL payload mode remains available.

## Permissions and services

None.

## Offline / online behaviour

Fully offline.

## Known limitations

- Diff is intentionally a bounded line comparison, not a source-control merge engine.
- Title casing and word counting use pragmatic local rules rather than full linguistic tokenisation.
- Very large documents should use a document-specific capability rather than this small-value utility.

## ODK example

`docs/example_odk_TextTools.xlsx`
