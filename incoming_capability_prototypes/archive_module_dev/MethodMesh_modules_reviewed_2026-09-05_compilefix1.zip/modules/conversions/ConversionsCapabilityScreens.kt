package com.example.methodmesh.modules.conversions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.*

object UnitConvertCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100UnitConvertMethod.id
    override val title = "Unit converter"
    override val description = "Convert common physical and digital units offline."

    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var category by rememberSaveable { mutableStateOf(context.setting("category", "length")) }
        var value by rememberSaveable { mutableStateOf(context.setting("value", "1")) }
        var from by rememberSaveable { mutableStateOf(context.setting("from_unit", UnitConversionEngine.units(category).firstOrNull().orEmpty())) }
        var to by rememberSaveable { mutableStateOf(context.setting("to_unit", UnitConversionEngine.units(category).getOrNull(1).orEmpty())) }
        CalculationScaffold(context, As100UnitConvertMethod, title, onBack, onConfirmed, onCancel, settings = { mapOf("category" to category, "value" to value, "from_unit" to from, "to_unit" to to) }) {
            if (context.settingShouldBeShown("category")) {
                Text("Category")
                ChoiceRows(listOf("length", "area", "volume", "mass", "temperature", "speed", "pressure", "energy", "power", "data_size", "angle"), category) { selected ->
                    category = selected
                    val available = UnitConversionEngine.units(selected)
                    if (from !in available) from = available.firstOrNull().orEmpty()
                    if (to !in available) to = available.getOrNull(1) ?: available.firstOrNull().orEmpty()
                }
            }
            if (context.settingShouldBeShown("value")) {
                OutlinedTextField(value, { value = it }, label = { Text("Value") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (context.settingShouldBeShown("from_unit")) {
                Text("From")
                ChoiceRows(UnitConversionEngine.units(category), from) { from = it }
            }
            if (context.settingShouldBeShown("to_unit")) {
                Text("To")
                ChoiceRows(UnitConversionEngine.units(category), to) { to = it }
            }
        }
    }
}

object DateDifferenceCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100DateDifferenceMethod.id
    override val title = "Date/time difference"
    override val description = "Difference between ISO dates or UTC timestamps."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var start by rememberSaveable { mutableStateOf(context.setting("start", "2026-01-01")) }
        var end by rememberSaveable { mutableStateOf(context.setting("end", "2026-01-02")) }
        CalculationScaffold(context, As100DateDifferenceMethod, title, onBack, onConfirmed, onCancel, settings = { mapOf("start" to start, "end" to end) }) {
            if (context.settingShouldBeShown("start")) {
                OutlinedTextField(start, { start = it }, label = { Text("Start (YYYY-MM-DD or ISO instant)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (context.settingShouldBeShown("end")) {
                OutlinedTextField(end, { end = it }, label = { Text("End (YYYY-MM-DD or ISO instant)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        }
    }
}

object PercentRatioCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PercentRatioMethod.id
    override val title = "Percentage and ratio"
    override val description = "Percent-of, percent change, ratio and proportion calculations."
    @Composable override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var operation by rememberSaveable { mutableStateOf(context.setting("operation", "percentage_of")) }
        var a by rememberSaveable { mutableStateOf(context.setting("a", "10")) }
        var b by rememberSaveable { mutableStateOf(context.setting("b", "100")) }
        CalculationScaffold(context, As100PercentRatioMethod, title, onBack, onConfirmed, onCancel, settings = { mapOf("operation" to operation, "a" to a, "b" to b) }) {
            if (context.settingShouldBeShown("operation")) {
                ChoiceRows(listOf("percentage_of", "what_percent", "percentage_change", "ratio", "proportion"), operation) { operation = it }
            }
            if (context.settingShouldBeShown("a")) {
                OutlinedTextField(a, { a = it }, label = { Text("A") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            if (context.settingShouldBeShown("b")) {
                OutlinedTextField(b, { b = it }, label = { Text("B") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        }
    }
}

@Composable
private fun CalculationScaffold(
    context: CapabilityScreenContext,
    method: BaseConversionMethod,
    title: String,
    onBack: () -> Unit,
    onConfirmed: (ExecutionResult) -> Unit,
    onCancel: () -> Unit,
    settings: () -> Map<String, String>,
    content: @Composable () -> Unit
) {
    var result by remember { mutableStateOf<ExecutionResult?>(null) }
    var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
    fun run() {
        val input = settings()
        context.onSettingsChanged(input)
        val req = method.request(method.id, context.request.invocationContext.asMap(method.id) + context.request.settings + context.action.settings + input, emptyList(), emptyList())
        result = method.result(req, method.calculate(input), context.request.invocationContext)
        if (context.submitsImmediately) result?.let(onConfirmed)
    }
    LaunchedEffect(context.startsImmediately) { if (context.startsImmediately && !launched) { launched = true; run() } }
    CapabilityScreenScaffold(title, method.id, context, context.stepNumber > 1, result, result?.let { OutputFormatter.fields(it, false) }.orEmpty(), onBack, { run() }, { result?.let(onConfirmed) }, onCancel) {
        Column(Modifier.fillMaxWidth()) { content(); Spacer(Modifier.height(8.dp)); Button({ run() }, Modifier.fillMaxWidth()) { Text("Calculate") } }
    }
}

@Composable private fun ChoiceRows(choices: List<String>, selected: String, onSelect: (String) -> Unit) {
    choices.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row.forEach { choice -> if (choice == selected) Button({ onSelect(choice) }, Modifier.weight(1f)) { Text("✓ ${choice.replace('_',' ')}") } else OutlinedButton({ onSelect(choice) }, Modifier.weight(1f)) { Text(choice.replace('_',' ')) } }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}
private fun CapabilityScreenContext.setting(key: String, fallback: String): String = action.settings[key] ?: action.settings["input_$key"] ?: request.settings[key] ?: request.settings["input_$key"] ?: fallback
