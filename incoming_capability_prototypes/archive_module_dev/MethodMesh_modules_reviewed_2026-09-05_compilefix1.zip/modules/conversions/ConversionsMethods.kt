package com.example.methodmesh.modules.conversions

import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale
import kotlin.math.abs

object ConversionFields {
    const val STATUS = "conversion_status"
    const val OPERATION = "conversion_operation"
    const val CATEGORY = "conversion_category"
    const val INPUT_VALUE = "conversion_input_value"
    const val INPUT_UNIT = "conversion_input_unit"
    const val OUTPUT_VALUE = "conversion_output_value"
    const val OUTPUT_UNIT = "conversion_output_unit"
    const val START = "conversion_start"
    const val END = "conversion_end"
    const val DIFFERENCE_SECONDS = "conversion_difference_seconds"
    const val DIFFERENCE_MINUTES = "conversion_difference_minutes"
    const val DIFFERENCE_HOURS = "conversion_difference_hours"
    const val DIFFERENCE_DAYS = "conversion_difference_days"
    const val VALUE_A = "conversion_value_a"
    const val VALUE_B = "conversion_value_b"
    const val RESULT = "conversion_result"
    const val AUDIT_JSON = "conversion_audit_json"
    const val ERROR = "conversion_error"
    val outputs = listOf(STATUS, OPERATION, CATEGORY, INPUT_VALUE, INPUT_UNIT, OUTPUT_VALUE, OUTPUT_UNIT, START, END, DIFFERENCE_SECONDS, DIFFERENCE_MINUTES, DIFFERENCE_HOURS, DIFFERENCE_DAYS, VALUE_A, VALUE_B, RESULT, AUDIT_JSON, ERROR)
}

abstract class BaseConversionMethod(
    final override val id: String,
    private val name: String,
    private val description: String
) : As100Method {
    override val ref = ArchitectureRef(ArchitectureId(id), "Method", name)
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(id), methodType = MethodObjectType.Calculation, name = name, version = "0.1.0",
        description = description, outputs = ConversionFields.outputs, graphOutputs = listOf(id),
        parameters = mapOf("category" to "Conversion and calculation", "status" to "Development")
    )
    override val contract = MethodContract(method = ref, producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation), producedFields = descriptor.outputs, producedGraphOutputs = descriptor.graphOutputs)
    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) = As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)
    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult = result(request, calculate(request.context), InvocationContext.from(request.context))
    abstract fun calculate(context: Map<String, String>): Map<String, String>

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[ConversionFields.STATUS] == "succeeded"
        val provenance = ProvenanceContext("methodmesh.conversions", id, "0.1.0")
        val obs = Observation(phenomenon = id, subject = null, values = values, temporalContext = request.temporalContext, provenance = provenance)
        val tx = Transformation(action = id, method = ref, outputs = listOf(ArchitectureRef(obs.id, obs.objectType, obs.phenomenon)), status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, temporalContext = request.temporalContext, provenance = provenance)
        return As100ExecutionEngine.complete(request, if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, observations = listOf(obs), transformations = listOf(tx), diagnostics = if (ok) emptyMap() else mapOf(ConversionFields.ERROR to values[ConversionFields.ERROR].orEmpty())).withInvocationContext(invocation)
    }
}

object UnitConversionEngine {
    data class UnitDef(val key: String, val category: String, val toBase: (Double) -> Double, val fromBase: (Double) -> Double)
    private fun linear(key: String, category: String, factor: Double) = UnitDef(key, category, { it * factor }, { it / factor })
    private val units = listOf(
        linear("mm", "length", 0.001), linear("cm", "length", 0.01), linear("m", "length", 1.0), linear("km", "length", 1000.0), linear("in", "length", 0.0254), linear("ft", "length", 0.3048), linear("yd", "length", 0.9144), linear("mi", "length", 1609.344), linear("nmi", "length", 1852.0),
        linear("mm2", "area", 1e-6), linear("cm2", "area", 1e-4), linear("m2", "area", 1.0), linear("ha", "area", 10000.0), linear("km2", "area", 1e6), linear("ft2", "area", 0.09290304), linear("acre", "area", 4046.8564224),
        linear("mL", "volume", 1e-6), linear("L", "volume", 0.001), linear("m3", "volume", 1.0), linear("tsp_us", "volume", 4.92892159375e-6), linear("tbsp_us", "volume", 14.78676478125e-6), linear("fl_oz_us", "volume", 29.5735295625e-6), linear("cup_us", "volume", 236.5882365e-6), linear("gal_us", "volume", 0.003785411784), linear("pt_uk", "volume", 0.00056826125), linear("gal_uk", "volume", 0.00454609),
        linear("mg", "mass", 1e-6), linear("g", "mass", 0.001), linear("kg", "mass", 1.0), linear("tonne", "mass", 1000.0), linear("oz", "mass", 0.028349523125), linear("lb", "mass", 0.45359237), linear("stone", "mass", 6.35029318),
        UnitDef("C", "temperature", { it + 273.15 }, { it - 273.15 }), UnitDef("K", "temperature", { it }, { it }), UnitDef("F", "temperature", { (it - 32.0) * 5.0 / 9.0 + 273.15 }, { (it - 273.15) * 9.0 / 5.0 + 32.0 }),
        linear("m_s", "speed", 1.0), linear("km_h", "speed", 1.0 / 3.6), linear("mph", "speed", 0.44704), linear("knot", "speed", 0.514444444444), linear("ft_s", "speed", 0.3048),
        linear("Pa", "pressure", 1.0), linear("hPa", "pressure", 100.0), linear("kPa", "pressure", 1000.0), linear("bar", "pressure", 100000.0), linear("atm", "pressure", 101325.0), linear("psi", "pressure", 6894.757293168), linear("mmHg", "pressure", 133.322387415),
        linear("J", "energy", 1.0), linear("kJ", "energy", 1000.0), linear("Wh", "energy", 3600.0), linear("kWh", "energy", 3.6e6), linear("cal", "energy", 4.184), linear("kcal", "energy", 4184.0),
        linear("W", "power", 1.0), linear("kW", "power", 1000.0), linear("MW", "power", 1e6), linear("hp_mech", "power", 745.6998715822702),
        linear("B", "data_size", 1.0), linear("KB", "data_size", 1000.0), linear("MB", "data_size", 1e6), linear("GB", "data_size", 1e9), linear("KiB", "data_size", 1024.0), linear("MiB", "data_size", 1048576.0), linear("GiB", "data_size", 1073741824.0),
        linear("deg", "angle", 1.0), linear("rad", "angle", 180.0 / Math.PI), linear("grad", "angle", 0.9)
    )
    fun units(category: String): List<String> = units.filter { it.category == category }.map { it.key }
    fun allUnits(): List<String> = units.map { it.key }.distinct()
    fun convert(category: String, value: Double, from: String, to: String): Double {
        val a = units.firstOrNull { it.category == category && it.key == from } ?: error("Unknown $category unit '$from'.")
        val b = units.firstOrNull { it.category == category && it.key == to } ?: error("Unknown $category unit '$to'.")
        return b.fromBase(a.toBase(value))
    }
}

object As100UnitConvertMethod : BaseConversionMethod("units.convert", "Unit converter", "Convert a numeric value between supported units.") {
    override fun calculate(context: Map<String, String>): Map<String, String> {
        val category = context.value("category") ?: "length"
        val value = context.value("value")?.toDoubleOrNull()
        val from = context.value("from_unit") ?: UnitConversionEngine.units(category).firstOrNull().orEmpty()
        val to = context.value("to_unit") ?: UnitConversionEngine.units(category).getOrNull(1).orEmpty()
        return runCatching {
            require(value != null && value.isFinite()) { "A finite numeric value is required." }
            val converted = UnitConversionEngine.convert(category, value, from, to)
            success("unit_convert", category, mapOf(ConversionFields.INPUT_VALUE to fmt(value), ConversionFields.INPUT_UNIT to from, ConversionFields.OUTPUT_VALUE to fmt(converted), ConversionFields.OUTPUT_UNIT to to), JSONObject().put("formula", "canonical-base conversion").put("category", category).toString())
        }.getOrElse { failure("unit_convert", category, it.message.orEmpty()) }
    }
}

object As100DateDifferenceMethod : BaseConversionMethod("date.difference", "Date and time difference", "Calculate a signed difference between ISO dates or timestamps.") {
    override fun calculate(context: Map<String, String>): Map<String, String> {
        val startText = context.value("start")?.trim().orEmpty()
        val endText = context.value("end")?.trim().orEmpty()
        return runCatching {
            val start = parseInstant(startText)
            val end = parseInstant(endText)
            val seconds = Duration.between(start, end).toMillis() / 1000.0
            success("date_difference", "time", mapOf(
                ConversionFields.START to startText, ConversionFields.END to endText,
                ConversionFields.DIFFERENCE_SECONDS to fmt(seconds), ConversionFields.DIFFERENCE_MINUTES to fmt(seconds / 60.0),
                ConversionFields.DIFFERENCE_HOURS to fmt(seconds / 3600.0), ConversionFields.DIFFERENCE_DAYS to fmt(seconds / 86400.0),
                ConversionFields.RESULT to "${fmt(seconds / 86400.0)} days"
            ), JSONObject().put("calendar", "ISO-8601").put("date_only_zone", "UTC").toString())
        }.getOrElse { failure("date_difference", "time", it.message ?: "Invalid ISO date/time.") }
    }

    private fun parseInstant(text: String): Instant = runCatching { Instant.parse(text) }.getOrElse {
        LocalDate.parse(text).atStartOfDay().toInstant(ZoneOffset.UTC)
    }
}

object As100PercentRatioMethod : BaseConversionMethod("calculator.percent_ratio", "Percentage and ratio calculator", "Calculate percentages, percentage change, ratios and proportions.") {
    override fun calculate(context: Map<String, String>): Map<String, String> {
        val op = context.value("operation") ?: "percentage_of"
        val a = context.value("a")?.toDoubleOrNull()
        val b = context.value("b")?.toDoubleOrNull()
        return runCatching {
            require(a != null && a.isFinite() && b != null && b.isFinite()) { "Two finite numeric values are required." }
            val result = when (op) {
                "percentage_of" -> a / 100.0 * b
                "what_percent" -> { require(b != 0.0) { "The denominator cannot be zero." }; a / b * 100.0 }
                "percentage_change" -> { require(a != 0.0) { "The starting value cannot be zero." }; (b - a) / abs(a) * 100.0 }
                "ratio" -> { require(b != 0.0) { "The denominator cannot be zero." }; a / b }
                "proportion" -> { require(a + b != 0.0) { "The total cannot be zero." }; a / (a + b) }
                else -> error("Unknown operation '$op'.")
            }
            success(op, "percentage_ratio", mapOf(ConversionFields.VALUE_A to fmt(a), ConversionFields.VALUE_B to fmt(b), ConversionFields.RESULT to fmt(result)), JSONObject().put("operation", op).toString())
        }.getOrElse { failure(op, "percentage_ratio", it.message.orEmpty()) }
    }
}

private fun Map<String, String>.value(key: String): String? = (this[key] ?: this["input_$key"])?.takeIf { it.isNotBlank() }
private fun fmt(v: Double?): String = v?.let { if (it % 1.0 == 0.0) it.toLong().toString() else "%.10f".format(Locale.US, it).trimEnd('0').trimEnd('.') }.orEmpty()
private fun success(op: String, category: String, extra: Map<String, String>, audit: String): Map<String, String> = linkedMapOf(ConversionFields.STATUS to "succeeded", ConversionFields.OPERATION to op, ConversionFields.CATEGORY to category) + extra + mapOf(ConversionFields.AUDIT_JSON to audit, ConversionFields.ERROR to "")
private fun failure(op: String, category: String, error: String): Map<String, String> = linkedMapOf(ConversionFields.STATUS to "failed", ConversionFields.OPERATION to op, ConversionFields.CATEGORY to category, ConversionFields.AUDIT_JSON to "{}", ConversionFields.ERROR to error)
