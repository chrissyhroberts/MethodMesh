package com.example.methodmesh.modules.conversions

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object ConversionsModule : MethodMeshModule {
    override val moduleId = "conversions"
    override val displayName = "Conversions and calculators"
    override val summary = "Offline unit, date/time, percentage and ratio calculations."
    override fun as100Methods() = listOf(As100UnitConvertMethod, As100DateDifferenceMethod, As100PercentRatioMethod)
    override fun rilBindings() = listOf(
        RilBinding("convert units", As100UnitConvertMethod.id), RilBinding("unit conversion", As100UnitConvertMethod.id),
        RilBinding("date difference", As100DateDifferenceMethod.id), RilBinding("time difference", As100DateDifferenceMethod.id),
        RilBinding("calculate percentage", As100PercentRatioMethod.id), RilBinding("calculate ratio", As100PercentRatioMethod.id)
    )
    override fun capabilityScreens() = listOf(UnitConvertCapabilityScreen, DateDifferenceCapabilityScreen, PercentRatioCapabilityScreen)
    override fun capabilitySettings() = mapOf(
        As100UnitConvertMethod.id to listOf(
            MethodSetting.ChoiceSetting("category", "Category", defaultValue = "length", choices = listOf("length","area","volume","mass","temperature","speed","pressure","energy","power","data_size","angle")),
            MethodSetting.FloatSetting("value", "Value", defaultValue = 1f),
            MethodSetting.ChoiceSetting("from_unit", "From unit", defaultValue = "m", choices = UnitConversionEngine.allUnits()),
            MethodSetting.ChoiceSetting("to_unit", "To unit", defaultValue = "ft", choices = UnitConversionEngine.allUnits())
        ),
        As100DateDifferenceMethod.id to listOf(MethodSetting.TextSetting("start", "Start ISO date/time", defaultValue = "2026-01-01"), MethodSetting.TextSetting("end", "End ISO date/time", defaultValue = "2026-01-02")),
        As100PercentRatioMethod.id to listOf(MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "percentage_of", choices = listOf("percentage_of","what_percent","percentage_change","ratio","proportion")), MethodSetting.FloatSetting("a", "A", defaultValue = 10f), MethodSetting.FloatSetting("b", "B", defaultValue = 100f))
    )
}
