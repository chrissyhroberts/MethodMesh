# Conversions and calculators

**Status:** Development  
**Module:** `conversions`  
**Methods:** `units.convert`, `date.difference`, `calculator.percent_ratio`  
**Version:** `0.1.0`

## What it does

Small deterministic offline calculations that do not belong to a specialist scientific module.

- `units.convert`: length, area, volume, mass, temperature, speed, pressure, energy, power, data size and angle.
- `date.difference`: difference between ISO date/date-time values.
- `calculator.percent_ratio`: percentage-of, what-percent, percentage change, ratio and proportion calculations.

## Native workflow

Choose the relevant capability, enter the runtime values, and confirm the calculation. The main numerical result is shown before verbose metadata.

## Preset workflow

All configuration is declared through `capabilitySettings()`. Fixed preset values are hidden with `settingShouldBeShown(...)`; runtime values remain editable.

## ODK / XLSForm workflow

The supplied workbook contains grouped MethodMesh intent examples for all three methods and captures their main outputs.

## Inputs

`units.convert`: `category`, `value`, `from_unit`, `to_unit`.  
`date.difference`: `start`, `end` as ISO date/date-time strings.  
`calculator.percent_ratio`: `operation`, `a`, `b`.

## Outputs

Common outputs include `conversion_status`, operation/category, input/output values and units, date differences in seconds/minutes/hours/days, `conversion_result`, `conversion_audit_json`, and `conversion_error`.

## Main result

`conversion_output_value` for unit conversion; `conversion_difference_*` for date differences; `conversion_result` for percentage/ratio calculations.

## Audit / full metadata

`conversion_audit_json` records deterministic calculation inputs/operation. Standard MethodMesh FULL payload mode may also be retained by external callers.

## Permissions and services

None.

## Offline / online behaviour

Fully offline and deterministic.

## Known limitations

- Unit catalogue is deliberately bounded rather than attempting every specialist unit system.
- ISO date parsing is not a natural-language date parser.
- Financial/currency conversion is intentionally excluded because current exchange rates would require a separately declared online data source.

## ODK example

`docs/example_odk_Conversions.xlsx`
