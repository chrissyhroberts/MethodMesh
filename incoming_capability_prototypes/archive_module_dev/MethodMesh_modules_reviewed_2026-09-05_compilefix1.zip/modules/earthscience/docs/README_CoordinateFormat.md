# Coordinate format conversion

**Status:** Development  
**Module:** `earthscience`  
**Method:** `geodesy.coordinate_format`

## What it does
Converts latitude/longitude between signed decimal degrees and degree-minute-second (DMS) text while validating geographic ranges and hemisphere signs.

## Native workflow
Choose conversion direction, enter the coordinates, run, and copy/use the formatted result.

## Preset workflow
Conversion mode and values are module settings; fixed preset values are hidden by the Earth Science capability screen.

## ODK / XLSForm workflow
`example_odk_geodesy.coordinate_format.xlsx` contains a grouped intent example.

## Inputs
`input_mode` plus decimal `latitude`/`longitude` or DMS `latitude_dms`/`longitude_dms` according to mode.

## Outputs and main result
Validated decimal coordinates and formatted DMS strings plus status/error and normal Earth Science audit fields. The converted coordinate pair is the main result.

## Permissions/services and offline behaviour
No permission and no network access are required.

## Known limitations
This is coordinate **format** conversion, not datum transformation, geocoding, or coordinate-reference-system inference. Use the existing Earth Science UTM/WGS84 methods for those conversions.
