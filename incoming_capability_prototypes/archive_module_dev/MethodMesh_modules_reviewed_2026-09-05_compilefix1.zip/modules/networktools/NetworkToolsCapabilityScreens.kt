package com.example.methodmesh.modules.networktools
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private enum class NetworkMode(val method:BaseNetworkMethod,val titleText:String,val fields:List<Pair<String,String>>){DNS(As100NetworkResolveMethod,"DNS lookup",listOf("host" to "Host name")),TCP(As100TcpReachabilityMethod,"TCP reachability",listOf("host" to "Host","port" to "Port","timeout_ms" to "Timeout ms")),SUBNET(As100Ipv4SubnetMethod,"IPv4 subnet",listOf("cidr" to "IPv4 CIDR")),LOCAL(As100LocalInterfacesMethod,"Local interfaces",emptyList())}
object NetworkResolveCapabilityScreen:CapabilityScreenSpec by NetworkSpec(NetworkMode.DNS)
object NetworkTcpCapabilityScreen:CapabilityScreenSpec by NetworkSpec(NetworkMode.TCP)
object NetworkSubnetCapabilityScreen:CapabilityScreenSpec by NetworkSpec(NetworkMode.SUBNET)
object NetworkLocalInterfacesCapabilityScreen:CapabilityScreenSpec by NetworkSpec(NetworkMode.LOCAL)
private class NetworkSpec(private val mode:NetworkMode):CapabilityScreenSpec{override val capabilityId=mode.method.id;override val title=mode.titleText;override val description="Bounded network diagnostic utility."
@Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){var values by rememberSaveable{mutableStateOf(mode.fields.associate{it.first to context.setting(it.first,defaultFor(it.first))})};var result by remember{mutableStateOf<ExecutionResult?>(null)};var busy by remember{mutableStateOf(false)};var launched by rememberSaveable(context.action.canonicalId){mutableStateOf(false)};val scope=rememberCoroutineScope()
suspend fun execute(){busy=true;val input=values;context.onSettingsChanged(input);val execution=withContext(Dispatchers.IO){val req=mode.method.request(mode.method.id,context.request.invocationContext.asMap(mode.method.id)+context.request.settings+context.action.settings+input,emptyList(),emptyList());mode.method.result(req,mode.method.run(input),context.request.invocationContext)};result=execution;busy=false;if(context.submitsImmediately)onConfirmed(execution)}
LaunchedEffect(context.startsImmediately){if(context.startsImmediately&&!launched){launched=true;execute()}}
CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,result,result?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack,{},{result?.let(onConfirmed)},onCancel){Column(Modifier.fillMaxWidth()){mode.fields.forEach{(key,label)->if(context.settingShouldBeShown(key)) OutlinedTextField(values[key].orEmpty(),{x->values=values.toMutableMap().apply{put(key,x)}},label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true)};Spacer(Modifier.height(8.dp));Button({scope.launch{execute()}},Modifier.fillMaxWidth(),enabled=!busy){Text(if(busy)"Working…" else "Run")}}}}
private fun defaultFor(k:String)=when(k){"port"->"443";"timeout_ms"->"3000";"cidr"->"192.168.1.10/24";else->""}}
private fun CapabilityScreenContext.setting(k:String,f:String)=action.settings[k]?:action.settings["input_$k"]?:request.settings[k]?:request.settings["input_$k"]?:f
