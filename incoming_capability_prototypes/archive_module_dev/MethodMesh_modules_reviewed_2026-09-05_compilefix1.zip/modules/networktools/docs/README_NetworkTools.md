# Network diagnostics

**Status:** Development  
**Module:** `networktools`  
**Methods:** `network.resolve`, `network.tcp_check`, `network.ipv4_subnet`, `network.local_interfaces`  
**Version:** `0.1.0`

## What it does

Provides bounded diagnostic primitives rather than a network-scanning suite.

- `network.resolve`: DNS/name resolution for one host.
- `network.tcp_check`: connection test to one explicitly supplied host and TCP port.
- `network.ipv4_subnet`: local deterministic IPv4 CIDR/network/broadcast/host calculations.
- `network.local_interfaces`: inspect network interfaces/addresses exposed to the app.

## Native workflow

Enter the target host/port or CIDR where applicable, run one diagnostic, and use the compact result.

## Preset workflow

Target values and limits are declared settings. The generic capability screen uses `settingShouldBeShown(key)` so fixed preset values are not shown again.

## ODK / XLSForm workflow

The supplied workbook contains one grouped MethodMesh intent for each method.

## Inputs

`network.resolve`: `host`.  
`network.tcp_check`: `host`, `port`, `timeout_ms`.  
`network.ipv4_subnet`: `cidr`.  
`network.local_interfaces`: no runtime inputs.

## Outputs

Outputs include status/operation, host/port, resolved addresses JSON, reachability and latency, subnet/network/broadcast/host ranges, interface JSON, check time, `network_audit_json`, and `network_error`.

## Main result

The resolved address list, reachable/latency result, subnet summary, or local-interface summary depending on method.

## Audit / full metadata

`network_audit_json` and standard MethodMesh FULL payload mode provide provenance for the diagnostic. The module does not persist credentials.

## Permissions and services

Network operations use standard Java/Android networking and the application's normal network capability. IPv4 subnet calculation is entirely local. No location permission is requested.

## Offline / online behaviour

- `network.ipv4_subnet` and local interface inspection are offline/local.
- DNS and TCP checks require appropriate network connectivity to the requested endpoint.

## Deliberately excluded from v0.1

Bulk port scanning, indiscriminate LAN host discovery, packet capture, exploitation and credential handling are not included. The module is intended for ordinary diagnostics and explicitly targeted connectivity checks.

## Known limitations

Network visibility is constrained by Android version, VPNs, interface policy and upstream network configuration. A successful TCP connection shows reachability of that endpoint, not application-level correctness.

## ODK example

`docs/example_odk_NetworkTools.xlsx`
