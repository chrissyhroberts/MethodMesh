# Data tools

**Status:** Development  
**Module:** `datatools`  
**Method:** `data.transform`  
**Version:** `0.1.0`

## What it does

Performs small offline structured-data and encoding transformations. Supported operations are JSON pretty/minify/validate, Base64 encode/decode, URL encode/decode, hex encode/decode, epoch-to-ISO, and ISO-to-epoch seconds/milliseconds.

Cryptographic hashing remains in the `cryptography` module: encoding is not cryptography.

## Native workflow

Choose an operation, provide the input value, run, and use the transformed value/validation result.

## Preset workflow

The fixed operation can be saved in a preset and hidden; the input can remain a runtime value. The screen obeys `settingShouldBeShown(...)`.

## ODK / XLSForm workflow

The supplied grouped-intent workbook demonstrates `data.transform` and returns the transformed value plus status fields.

## Inputs

| Input | Meaning |
|---|---|
| `operation` | One of the declared fixed operations. |
| `input` | Small text/structured value to transform. |

## Outputs

`datatool_status`, `datatool_operation`, input SHA-256, `datatool_output`, validation flag/type, `datatool_audit_json`, and `datatool_error`.

## Main result

`datatool_output` or, for validation, the validity/type fields.

## Audit / full metadata

The input is represented by SHA-256 in audit metadata rather than gratuitously duplicated. Standard MethodMesh FULL payload mode can retain the complete execution envelope.

## Permissions and services

None.

## Offline / online behaviour

Fully offline.

## Known limitations

- Intended for small values, not streaming multi-gigabyte file conversion.
- Structured conversion between JSON/CSV/YAML/XML is not claimed in v0.1.
- JSON validation follows the Android/local JSON parser used by the implementation.

## ODK example

`docs/example_odk_DataTools.xlsx`
