package com.example.methodmesh.modules.datatools
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.*
object DataToolsCapabilityScreen:CapabilityScreenSpec{override val capabilityId=As100DataTransformMethod.ID;override val title="Data tools";override val description="JSON, Base64, URL, hex and timestamp transforms."
@Composable override fun Render(context:CapabilityScreenContext,onBack:()->Unit,onConfirmed:(ExecutionResult)->Unit,onCancel:()->Unit){var op by rememberSaveable{mutableStateOf(context.setting("operation","json_pretty"))};var input by rememberSaveable{mutableStateOf(context.setting("input",""))};var result by remember{mutableStateOf<ExecutionResult?>(null)};var launched by rememberSaveable(context.action.canonicalId){mutableStateOf(false)}
fun run(){val s=mapOf("operation" to op,"input" to input);context.onSettingsChanged(s);val req=As100DataTransformMethod.request(As100DataTransformMethod.ID,context.request.invocationContext.asMap(As100DataTransformMethod.ID)+context.request.settings+context.action.settings+s,emptyList(),emptyList());result=As100DataTransformMethod.result(req,As100DataTransformMethod.calculate(s),context.request.invocationContext);if(context.submitsImmediately)result?.let(onConfirmed)}
LaunchedEffect(context.startsImmediately){if(context.startsImmediately&&!launched){launched=true;run()}}
CapabilityScreenScaffold(title,capabilityId,context,context.stepNumber>1,result,result?.let{OutputFormatter.fields(it,false)}.orEmpty(),onBack,{run()},{result?.let(onConfirmed)},onCancel){Column(Modifier.fillMaxWidth()){
if(context.settingShouldBeShown("operation")){listOf("json_pretty","json_minify","json_validate","base64_encode","base64_decode","url_encode","url_decode","hex_encode","hex_decode","epoch_to_iso","iso_to_epoch_seconds","iso_to_epoch_millis").chunked(3).forEach{row->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){row.forEach{c->OutlinedButton({op=c},Modifier.weight(1f)){Text(if(c==op)"✓ ${c.replace('_',' ')}" else c.replace('_',' '))}};repeat(3-row.size){Spacer(Modifier.weight(1f))}}}}
if(context.settingShouldBeShown("input"))OutlinedTextField(input,{input=it},label={Text("Input")},modifier=Modifier.fillMaxWidth(),minLines=5)
Spacer(Modifier.height(8.dp));Button({run()},Modifier.fillMaxWidth()){Text("Transform")}}}}
private fun CapabilityScreenContext.setting(key:String,fallback:String)=action.settings[key]?:action.settings["input_$key"]?:request.settings[key]?:request.settings["input_$key"]?:fallback}
