package com.example.methodmesh.modules.datatools

import android.util.Base64
import com.example.methodmesh.core.crypto.Digests
import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.Locale

object DataToolFields { const val STATUS="datatool_status"; const val OPERATION="datatool_operation"; const val INPUT_SHA256="datatool_input_sha256"; const val OUTPUT="datatool_output"; const val VALID="datatool_valid"; const val TYPE="datatool_type"; const val AUDIT_JSON="datatool_audit_json"; const val ERROR="datatool_error"; val outputs=listOf(STATUS,OPERATION,INPUT_SHA256,OUTPUT,VALID,TYPE,AUDIT_JSON,ERROR) }

object As100DataTransformMethod : As100Method {
    const val ID="data.transform"; private const val VERSION="0.1.0"
    override val id=ID; override val ref=ArchitectureRef(ArchitectureId(ID),"Method","Data transformer")
    override val descriptor=MethodDescriptor(id=ArchitectureId(ID),methodType=MethodObjectType.Calculation,name="Data transformer",version=VERSION,description="Format, validate, encode and convert small structured values offline.",outputs=DataToolFields.outputs,graphOutputs=listOf(ID),parameters=mapOf("category" to "Data utilities","status" to "Development"))
    override val contract=MethodContract(method=ref,producedKnowledgeTypes=listOf(KnowledgeObjectType.Observation),producedFields=descriptor.outputs,producedGraphOutputs=descriptor.graphOutputs)
    override fun request(action:String,context:Map<String,String>,signals:List<Signal>,inputs:List<ArchitectureRef>)=As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)
    override fun execute(request:ExecutionRequest,settingsState:SettingsState?,transport:String?)=result(request,calculate(request.context),InvocationContext.from(request.context))
    fun result(request:ExecutionRequest,values:Map<String,String>,invocation:InvocationContext?):ExecutionResult { val ok=values[DataToolFields.STATUS]=="succeeded"; val p=ProvenanceContext("methodmesh.datatools",ID,VERSION); val o=Observation(phenomenon=ID,subject=null,values=values,temporalContext=request.temporalContext,provenance=p); val t=Transformation(action=ID,method=ref,outputs=listOf(ArchitectureRef(o.id,o.objectType,o.phenomenon)),status=if(ok)TransformationStatus.Succeeded else TransformationStatus.Failed,temporalContext=request.temporalContext,provenance=p); return As100ExecutionEngine.complete(request,if(ok)TransformationStatus.Succeeded else TransformationStatus.Failed,observations=listOf(o),transformations=listOf(t),diagnostics=if(ok) emptyMap() else mapOf(DataToolFields.ERROR to values[DataToolFields.ERROR].orEmpty())).withInvocationContext(invocation) }
    fun calculate(context:Map<String,String>):Map<String,String>{ val op=context.value("operation")?:"json_pretty"; val input=context.valueAllowBlank("input")?:""; return runCatching { require(input.length<=1_000_000){"Input is limited to 1,000,000 characters."}; val (output,type)=when(op){
        "json_pretty" -> formatJson(input,2) to "json"; "json_minify" -> formatJson(input,0) to "json"; "json_validate" -> { val parsed=parseJson(input); "valid ${jsonType(parsed)}" to "json" }
        "base64_encode" -> Base64.encodeToString(input.toByteArray(StandardCharsets.UTF_8),Base64.NO_WRAP) to "base64"; "base64_decode" -> String(Base64.decode(input,Base64.DEFAULT),StandardCharsets.UTF_8) to "text"
        "url_encode" -> URLEncoder.encode(input,"UTF-8") to "url_encoded"; "url_decode" -> URLDecoder.decode(input,"UTF-8") to "text"
        "hex_encode" -> input.toByteArray(StandardCharsets.UTF_8).joinToString(""){"%02x".format(Locale.US,it.toInt() and 0xff)} to "hex"; "hex_decode" -> decodeHex(input) to "text"
        "epoch_to_iso" -> epochToIso(input) to "iso8601"; "iso_to_epoch_seconds" -> Instant.parse(input.trim()).epochSecond.toString() to "epoch_seconds"; "iso_to_epoch_millis" -> Instant.parse(input.trim()).toEpochMilli().toString() to "epoch_millis"
        else -> error("Unknown data operation '$op'.") }
        linkedMapOf(DataToolFields.STATUS to "succeeded",DataToolFields.OPERATION to op,DataToolFields.INPUT_SHA256 to Digests.sha256Hex(input),DataToolFields.OUTPUT to output,DataToolFields.VALID to "true",DataToolFields.TYPE to type,DataToolFields.AUDIT_JSON to JSONObject().put("operation",op).put("input_length",input.length).put("output_length",output.length).toString(),DataToolFields.ERROR to "")
    }.getOrElse{ linkedMapOf(DataToolFields.STATUS to "failed",DataToolFields.OPERATION to op,DataToolFields.INPUT_SHA256 to Digests.sha256Hex(input),DataToolFields.OUTPUT to "",DataToolFields.VALID to "false",DataToolFields.TYPE to "",DataToolFields.AUDIT_JSON to "{}",DataToolFields.ERROR to (it.message?:it::class.java.simpleName)) } }
    private fun parseJson(input:String):Any { val value=JSONTokener(input).nextValue(); require(value is JSONObject || value is JSONArray){"JSON root must be an object or array."}; return value }
    private fun formatJson(input:String,indent:Int):String=when(val p=parseJson(input)){is JSONObject->if(indent>0)p.toString(indent) else p.toString();is JSONArray->if(indent>0)p.toString(indent) else p.toString();else->error("Unsupported JSON root.")}
    private fun jsonType(v:Any)=if(v is JSONObject)"object" else "array"
    private fun decodeHex(input:String):String { val clean=input.filterNot(Char::isWhitespace); require(clean.length%2==0){"Hex input must contain an even number of digits."}; require(clean.all{it.digitToIntOrNull(16)!=null}){"Hex input contains a non-hexadecimal character."}; return String(ByteArray(clean.length/2){i->clean.substring(i*2,i*2+2).toInt(16).toByte()},StandardCharsets.UTF_8) }
    private fun epochToIso(input:String):String { val raw=input.trim().toLongOrNull()?:error("Epoch value must be an integer."); val millis=if(kotlin.math.abs(raw)>=100_000_000_000L)raw else Math.multiplyExact(raw,1000L); return Instant.ofEpochMilli(millis).toString() }
}
private fun Map<String,String>.value(key:String):String?=(this[key]?:this["input_$key"])?.takeIf{it.isNotBlank()}; private fun Map<String,String>.valueAllowBlank(key:String):String?=this[key]?:this["input_$key"]
