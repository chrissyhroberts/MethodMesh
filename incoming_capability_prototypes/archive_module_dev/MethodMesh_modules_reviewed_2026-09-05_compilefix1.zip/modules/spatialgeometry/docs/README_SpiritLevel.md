# Spirit level

**Status:** Development  
**Module:** `spatialgeometry`  
**Method:** `spirit_level_measurement`

## What it does
Uses both phone orientation axes to report top/bottom and left/right tilt, overall level deviation, and whether the device is within a configurable angular tolerance.

## Native workflow
Place the phone on the surface, wait for an orientation reading, capture both axes, and confirm the calculated level result.

## Preset workflow
Tolerance and any supplied angles are declared module settings. Fixed values are hidden by the capability screen using the existing Spatial Geometry settings visibility logic.

## ODK / XLSForm workflow
`example_odk_spirit_level_measurement.xlsx` demonstrates a grouped intent and returned level fields.

## Inputs
`slope_angle_deg`, `tilt_angle_deg`, `level_tolerance_deg`; native capture normally obtains the two angles from the existing shared phone orientation boundary.

## Outputs and main result
Measurement type/validity, both tilt angles, `level_deviation_deg`, `level_within_tolerance`, sensor source, timestamp and formula/provenance fields. Deviation plus within-tolerance state are the main result.

## Audit / full metadata
Uses the existing Spatial Geometry observation/provenance model and normal MethodMesh FULL envelope.

## Permissions/services and offline behaviour
No runtime permission is required for the orientation sensors. Fully offline.

## Known limitations
Phone chassis/sensor alignment and surface contact limit accuracy. This Development capability is not a calibrated machinist's level or survey instrument.
