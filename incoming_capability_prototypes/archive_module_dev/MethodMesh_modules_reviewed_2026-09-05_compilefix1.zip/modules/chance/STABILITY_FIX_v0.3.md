# Chance v0.3 stability/layout fix

Based on device feedback from Chance v0.2.

## Crash fixes

The new Pick one, Spinner and Weighted choice result experiences all created their own `verticalScroll` container. MethodMesh renders dashboard capability content inside its own scrolling host, so these nested full-height scrollables are unsafe and can trigger Compose infinite-height measurement failures.

v0.3 removes the nested page scrollers. Chance result experiences now grow naturally and leave vertical scrolling to the MethodMesh host.

Additional defensive changes:
- Pick one and wheel execution/reveal paths catch unexpected runtime exceptions and return a visible failed state instead of terminating the app.
- Pick one interactive intent launches lay out concealed cards when no selected position has been supplied; automatic external calls still require `selected_position`.
- selection method generation now converts unexpected runtime configuration/parsing exceptions to failed Chance results.

## Draw cards

Card draws no longer use a horizontal strip. The deck and cards are placed into responsive rows based on available width. More cards add rows vertically; the MethodMesh host handles scrolling when the rows exceed the viewport.

## Dice containment

The v0.6 dice animation state machine and wireframe renderer remain intact.

Layout containment changes only:
- maximum four base dice per row;
- base dice already wrap to subsequent rows;
- explosion/reroll descendants now wrap two per inset row underneath their parent die;
- up to eight descendants are shown per parent, then `+N more` is shown;
- the Dice result experience grows vertically instead of forcing the tray into a fixed-height full-screen column;
- long expressions wrap across the available width.

This prevents pathological exploding-dice configurations from widening a parent slot and falling off the right edge.

## Validation in this environment

- Kotlin parser pass: no syntax/parser errors detected in the modified Compose screen sources (Android/Compose symbols are unresolved here because the Android project classpath is not present).
- ChanceSelectionEngine fixed-seed smoke test passed for card draw uniqueness/replay, Pick one permutation, Spinner bounds and Weighted choice.
- Full `./gradlew :app:assembleDebug` still requires the real MethodMesh checkout/build environment.
