# Chance

**MethodMesh module:** `chance`  
**Status:** Development  
**Umbrella purpose:** visual randomisation and concealed-choice tools

Chance groups lightweight randomisation capabilities that share secure randomness, deterministic replay when requested, concise native results, and structured provenance. It deliberately does **not** contain persistent tabletop state such as HP, mana, EXP, leaderboards or campaign records.

## Public capabilities

| Capability | Method ID | Core behaviour |
|---|---|---|
| Dice | `dice.simulate` | simple and advanced RPG dice expressions with staged visual resolution |
| Coin toss | `coin.toss` | one or many fair coins; casual single-coin mode available natively |
| Draw cards | `chance.cards.draw` | draw from a standard 52-card deck, optionally with two jokers, without replacement |
| Pick one | `chance.pick.one` | Chance conceals a random arrangement; the **user chooses the position** to reveal |
| Spinner | `chance.spinner.spin` | equally likely labelled wheel segments |
| Weighted choice | `chance.weighted.choose` | labelled choices selected in proportion to positive numeric weights |

The former Dice Simulator package is incorporated rather than discarded. Its dice engine, full-screen tray, RPG rules, cascading explosion visuals and cat/MethodMesh coin remain part of Chance.

## Randomness model

Normal operation uses operating-system-seeded cryptographically strong pseudorandomness (`java.security.SecureRandom`). Fixed-seed mode exists for tests and reproducible demonstrations. Chance does not claim that a phone contains a physical true-random generator.

For Dice and Coin, the existing engine semantics remain unchanged. The new card/selection engine records every bounded primitive integer draw used to select, shuffle or weight outcomes. Structured audit output records RNG mode, algorithm/version, seed hash where applicable and primitive draws.

Animation never determines an outcome. The random event is generated first and the UI reveals it afterwards.

## Dice

Dice keeps the known-good animated implementation restored from Dice Simulator v0.6, with the later stability fixes retained. The native screen remains beginner-first, with dice groups and friendly Roll options, while advanced notation supports mechanics including:

- `4d6kh3` / `4d6dl1` keep/drop;
- `d20r1` and repeated rerolls such as `d6rr<3`;
- cascading explosions such as `d6!` or `d12!>=6`;
- success pools such as `8d6cs>=5`;
- arithmetic, percentile dice and Fate/Fudge dice;
- final roll-over/roll-under comparisons.

The full-screen tray resolves rules in stages: ordinary dice settle first, rerolls resolve, explosion triggers flash and spawn child rolls, then dropped dice are marked. Explosion children remain owned by their base-die slot so pathological chains cannot widen the main tray indefinitely.

See `DICE_ENGINE_TEST_VECTORS.md` for the existing deterministic vectors.

### Multiplayer Dice

Dice can use the same configured expression for multiple players. `player_count` accepts 1–20. Up to four players can choose **Around table**, which orients results towards people sitting around the device; **Take turns** gives each player the full-screen animated tray in sequence and is forced for larger groups. All player outcomes are generated before presentation, and fixed-seed mode derives a stable per-player seed from the supplied base seed. Structured output includes `dice_player_count` and `dice_players_json`; the original single-player fields remain compatible and describe Player 1 when a multiplayer roll is used.

## Coin toss

Coin toss uses a deliberately simple MethodMesh visual language:

- the face-on coin is always a true circle; only the flip animation squashes it horizontally;
- Heads: a large charcoal `:3` on a warm off-white face;
- Tails: the MethodMesh three-bar mark;
- both faces use the MethodMesh teal rim and established dark/neutral palette;
- 1–10 coins animate individually and settle at staggered times;
- larger batches use compact aggregate presentation;
- native one-coin **Just toss** mode can be repeated indefinitely without accumulating a recorded series;
- recorded mode proceeds to the normal MethodMesh result/provenance screen.

## Draw cards

`chance.cards.draw` deals cards without replacement from one newly instantiated shared deck for each execution.

Settings:

- `draw_count`: cards per player (for one player this is simply cards to draw);
- `player_count`: 1–20 players;
- `player_mode`: `take_turns` or `around_table`; around-table presentation is available for up to four players, with larger groups automatically using take-turns;
- `include_jokers`: add two distinguishable jokers;
- `rng_mode`, `seed`, `animation_mode`.

For multiplayer deals, cards are assigned round-robin from one random deal sequence, so no card can appear in two hands. Native **Take turns** mode gives each player a full-screen hand, then hides it behind a pass screen before the next player reveals theirs. **Around the table** visibly orients up to four hands towards people around the device. Card rows wrap to available width and grow vertically rather than overflowing sideways.

Main output is a concise human-readable deal. Structured output includes `card_cards_json`, `card_player_hands_json` and `card_audit_json`.

## Pick one

`chance.pick.one` has different semantics from Dice, Spinner and Weighted choice.

**Chance randomises the concealed arrangement; the person chooses the position.**

Native flow:

1. Choose a visual/value set.
2. Press **Lay out cards**.
3. Chance prepares and records a random hidden arrangement.
4. Identical face-down cards are displayed.
5. The user taps whichever position they want.
6. That position flips over.
7. Optionally reveal the remaining positions.
8. Continue to the MethodMesh result screen.

Built-in sets:

- Numbers;
- Colours;
- card suits;
- Wiggly / abstract MethodMesh-style marks;
- classic playing cards;
- custom text (2–12 entries).

The built-in abstract values have textual descriptions as well as graphics, so the result is not dependent on vision alone.

### External / ODK semantics

An external caller must provide `selected_position` (1-based). Chance then generates the concealed arrangement and returns the value at that position. It does **not** silently pick a position on the caller's behalf. This preserves the distinction between human selection and system selection.

Native mode additionally passes an internal `prepared_pick_json` so the arrangement shown before the user's tap is exactly the arrangement recorded in the final result.

Outputs include the selected position/value plus the complete arrangement in structured JSON/audit output.

## Spinner

`chance.spinner.spin` accepts 2–60 non-empty labels. Native mode renders an equal-segment wheel, spins/decelerates and lands on the already-determined segment. Labels are rendered directly on sensible-sized wheels; dense wheels keep full labels in result/details rather than becoming unreadable.

Main output: the selected label.

## Weighted choice

`chance.weighted.choose` accepts one choice per line in the form:

```text
Attack:5
Defend:3
Run away:1
```

Weights:

- must be positive finite numbers;
- do not need to be percentages;
- do not need to sum to 1 or 100.

Chance normalises them internally. In the example above, effective probabilities are 5/9, 3/9 and 1/9. Selection uses a 53-bit uniform fraction assembled from two recorded bounded integer draws, so arbitrary finite positive totals do not need to be rescaled onto a small integer lattice. Native mode reuses the wheel metaphor, with angular segment size proportional to weight.

Outputs include selected label, selected weight, total weight, effective probability, normalized option metadata and audit JSON.

## Native UX and presets

Each capability owns its screen and settings. Fixed preset values should be hidden during native preset runs through `CapabilityScreenContext.settingShouldBeShown(...)`. ODK/external intent launches receive their values through intent settings and do not depend on native configuration dialogs.

The main MethodMesh result remains intentionally small. Audit JSON and detailed traces remain in structured fields/details/export rather than dominating the primary result screen.

## Development validation

Before promotion to Production:

1. place the folder under `incoming_capability_prototypes/chance/`;
2. review it against the current repository APIs;
3. move it into `modules/chance/` only for the integration build;
4. run `./gradlew :app:assembleDebug`;
5. test all six native screens on a phone-sized emulator/device;
6. test orientation changes during configure, animation and reveal stages;
7. test native presets with fixed/runtime fields;
8. test secure and fixed-seed modes;
9. test ODK Collect round trips from `example_odk_Chance.xlsx`;
10. only then change descriptor status from Development to Production.

The development package has been pure-Kotlin smoke-tested for fixed-seed card replay, no duplicate card draws, Pick-one shuffling, spinner bounds and weighted-choice bounds. A full Android build is still required in the MethodMesh repository.
