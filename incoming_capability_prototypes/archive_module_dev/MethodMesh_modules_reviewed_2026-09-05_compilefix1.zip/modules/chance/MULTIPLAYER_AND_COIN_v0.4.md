# Chance v0.4 — multiplayer + coin polish

This revision builds on the v0.3 stability baseline.

## Dice
- 1–20 players can use one shared dice setup.
- Take-turns mode preserves the full v0.6 dice animation for each player sequentially.
- Around-table mode is available for 2–4 players and orients player panels towards device edges.
- New structured fields: `dice_player_count`, `dice_players_json`.
- Existing single-player result fields remain compatible and refer to Player 1 in multiplayer runs.

## Draw cards
- 1–20 players.
- `draw_count` is cards per player when multiplayer is active.
- One shared deck is dealt round-robin without replacement.
- Take-turns mode hides each hand before the device is passed to the next player.
- Around-table mode supports 2–4 visible hands.
- New structured fields: `card_player_count`, `card_cards_per_player`, `card_player_hands_json`.

## Coin
- Face-on geometry is a true circle.
- Heads is now the deliberately simple `:3` face.
- Tails keeps the MethodMesh three-bar mark.
- Warm face, teal rim, charcoal/neutral details match the app palette.

## Validation
- Pure Kotlin Chance engines compile.
- Dice and Chance method layers compile against synthetic stubs matching their current public contracts.
- Smoke test: 4-player × 3-card deal produced 12 unique cards and equal hand sizes.
- Smoke test: 4 fixed-seed player dice simulations completed with per-player derived seeds.
- A real Android `./gradlew :app:assembleDebug` build is still required before promotion from Development.
