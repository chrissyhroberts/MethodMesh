package com.example.methodmesh.modules.documentscanner

import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import java.time.Instant

object DocumentScannerFields {
    const val STATUS = "document_scan_status"
    const val PAGE_COUNT = "document_scan_page_count"
    const val PAGE_IMAGE_URIS_JSON = "document_scan_page_image_uris_json"
    const val SCANNER_PDF_URI = "document_scan_pdf_uri"
    const val SEARCHABLE_PDF_URI = "document_scan_searchable_pdf_uri"
    const val OCR_TEXT = "document_scan_ocr_text"
    const val OCR_TEXT_FILE_URI = "document_scan_ocr_text_file_uri"
    const val OCR_PAGE_COUNT = "document_scan_ocr_page_count"
    const val SCANNER_MODE = "document_scan_mode"
    const val GALLERY_IMPORT_ALLOWED = "document_scan_gallery_import_allowed"
    const val PAGE_LIMIT = "document_scan_page_limit"
    const val SCANNED_TIME_ISO = "document_scan_time_iso"
    const val ERROR = "document_scan_error"

    val outputs = listOf(
        STATUS,
        PAGE_COUNT,
        PAGE_IMAGE_URIS_JSON,
        SCANNER_PDF_URI,
        SEARCHABLE_PDF_URI,
        OCR_TEXT,
        OCR_TEXT_FILE_URI,
        OCR_PAGE_COUNT,
        SCANNER_MODE,
        GALLERY_IMPORT_ALLOWED,
        PAGE_LIMIT,
        SCANNED_TIME_ISO,
        ERROR
    )
}

object As100DocumentScannerMethod : As100Method {
    const val ID = "document.scan"
    private const val VERSION = "1.0.0"

    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Document scan")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID),
        methodType = MethodObjectType.SignalInterpreter,
        name = "Document scanner",
        version = VERSION,
        description = "Scan paper documents using ML Kit document scanner, OCR pages, and return PDF/text attachments.",
        outputs = DocumentScannerFields.outputs,
        graphOutputs = listOf("document.scan"),
        parameters = mapOf(
            "category" to "Recognition",
            "status" to "Production",
            "core_return" to "document_scan_searchable_pdf_uri, document_scan_ocr_text",
            "audit_return" to "scanner mode, gallery import flag, page limit, page count, original scanner PDF, OCR text file, timestamp, error"
        )
    )
    override val contract = MethodContract(
        method = ref,
        requiredContext = emptyList(),
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult =
        As100ExecutionEngine.complete(
            request,
            TransformationStatus.Unsupported,
            diagnostics = mapOf("reason" to "Document scanning requires the Android ML Kit document scanner boundary.")
        )

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[DocumentScannerFields.STATUS] == "succeeded"
        val entity = Entity(ArchitectureId("document-scan:${System.currentTimeMillis()}"), "DocumentScan", temporalContext = request.temporalContext)
        val provenance = ProvenanceContext("mlkit.document_scanner", ID, VERSION)
        val observation = Observation(
            phenomenon = "document.scan",
            subject = ArchitectureRef(entity.id, entity.objectType, ID),
            values = values + (DocumentScannerFields.SCANNED_TIME_ISO to (values[DocumentScannerFields.SCANNED_TIME_ISO] ?: Instant.now().toString())),
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        val transformation = Transformation(
            action = ID,
            method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request,
            if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOf(entity),
            observations = listOf(observation),
            transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf("document_scan_error" to (values[DocumentScannerFields.ERROR] ?: "Document scan failed."))
        ).withInvocationContext(invocation)
    }
}
