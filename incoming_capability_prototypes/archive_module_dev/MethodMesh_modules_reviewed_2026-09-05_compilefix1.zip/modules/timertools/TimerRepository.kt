package com.example.methodmesh.modules.timertools

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.UUID

internal data class TimerRecord(
    val id: String,
    val name: String,
    val type: String,
    val durationMs: Long,
    val accumulatedMs: Long,
    val running: Boolean,
    val startedAtEpochMs: Long?,
    val laps: List<Long>,
    val updatedTimeIso: String
) {
    fun elapsed(nowEpochMs: Long = System.currentTimeMillis()): Long {
        val live = if (running && startedAtEpochMs != null) (nowEpochMs - startedAtEpochMs).coerceAtLeast(0L) else 0L
        return (accumulatedMs + live).coerceAtLeast(0L)
    }

    fun remaining(nowEpochMs: Long = System.currentTimeMillis()): Long =
        if (type == "countdown") (durationMs - elapsed(nowEpochMs)).coerceAtLeast(0L) else 0L

    fun completed(nowEpochMs: Long = System.currentTimeMillis()): Boolean =
        type == "countdown" && durationMs > 0L && elapsed(nowEpochMs) >= durationMs
}

internal data class TimerWorkspace(
    val id: String,
    val timers: List<TimerRecord>
)

internal class TimerRepository(context: Context) {
    private val root = File(context.filesDir, "methodmesh-timers").apply { mkdirs() }

    fun load(workspaceId: String): TimerWorkspace {
        val safe = safeId(workspaceId.ifBlank { "default" })
        val file = File(root, "$safe.json")
        val loaded = if (!file.exists()) {
            TimerWorkspace(safe, emptyList())
        } else {
            runCatching { decode(JSONObject(file.readText())) }
                .getOrElse { TimerWorkspace(safe, emptyList()) }
        }
        return normalise(loaded)
    }

    fun save(workspace: TimerWorkspace): TimerWorkspace {
        val normalised = workspace.copy(id = safeId(workspace.id.ifBlank { "default" }))
        val file = File(root, "${normalised.id}.json")
        val temp = File(root, ".${normalised.id}.${UUID.randomUUID()}.tmp")
        temp.writeText(encode(normalised).toString(2))
        if (file.exists() && !file.delete()) error("Could not replace timer workspace.")
        if (!temp.renameTo(file)) {
            temp.copyTo(file, overwrite = true)
            temp.delete()
        }
        return normalised
    }

    fun create(
        workspace: TimerWorkspace,
        name: String,
        type: String,
        durationMs: Long
    ): Pair<TimerWorkspace, TimerRecord> {
        require(type in setOf("stopwatch", "countdown")) { "Timer type must be stopwatch or countdown." }
        if (type == "countdown") {
            require(durationMs in MIN_COUNTDOWN_MS..MAX_COUNTDOWN_MS) { "Countdown duration must be between 1 second and 7 days." }
        }
        val now = Instant.now().toString()
        val timer = TimerRecord(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifBlank { "Timer" },
            type = type,
            durationMs = if (type == "countdown") durationMs else 0L,
            accumulatedMs = 0L,
            running = false,
            startedAtEpochMs = null,
            laps = emptyList(),
            updatedTimeIso = now
        )
        val saved = save(workspace.copy(timers = workspace.timers + timer))
        return saved to timer
    }

    fun start(workspace: TimerWorkspace, timerId: String): Pair<TimerWorkspace, TimerRecord> {
        val nowMs = System.currentTimeMillis()
        return mutate(workspace, timerId) { timer ->
            if (timer.running) return@mutate timer
            val base = if (timer.completed(nowMs)) timer.copy(accumulatedMs = 0L, laps = emptyList()) else timer
            base.copy(running = true, startedAtEpochMs = nowMs, updatedTimeIso = Instant.now().toString())
        }
    }

    fun pause(workspace: TimerWorkspace, timerId: String): Pair<TimerWorkspace, TimerRecord> {
        val nowMs = System.currentTimeMillis()
        return mutate(workspace, timerId) { timer ->
            if (!timer.running) return@mutate timer
            val elapsed = timer.elapsed(nowMs)
            timer.copy(
                accumulatedMs = if (timer.type == "countdown") elapsed.coerceAtMost(timer.durationMs) else elapsed,
                running = false,
                startedAtEpochMs = null,
                updatedTimeIso = Instant.now().toString()
            )
        }
    }

    fun reset(workspace: TimerWorkspace, timerId: String): Pair<TimerWorkspace, TimerRecord> =
        mutate(workspace, timerId) { timer ->
            timer.copy(
                accumulatedMs = 0L,
                running = false,
                startedAtEpochMs = null,
                laps = emptyList(),
                updatedTimeIso = Instant.now().toString()
            )
        }

    fun lap(workspace: TimerWorkspace, timerId: String): Pair<TimerWorkspace, TimerRecord> {
        val nowMs = System.currentTimeMillis()
        return mutate(workspace, timerId) { timer ->
            require(timer.type == "stopwatch") { "Laps are available only for stopwatches." }
            timer.copy(
                laps = (timer.laps + timer.elapsed(nowMs)).takeLast(MAX_LAPS),
                updatedTimeIso = Instant.now().toString()
            )
        }
    }

    fun delete(workspace: TimerWorkspace, timerId: String): TimerWorkspace {
        require(workspace.timers.any { it.id == timerId }) { "Timer '$timerId' was not found." }
        return save(workspace.copy(timers = workspace.timers.filterNot { it.id == timerId }))
    }

    fun normalise(workspace: TimerWorkspace): TimerWorkspace {
        val nowMs = System.currentTimeMillis()
        var changed = false
        val timers = workspace.timers.map { timer ->
            if (timer.running && timer.completed(nowMs)) {
                changed = true
                timer.copy(
                    accumulatedMs = timer.durationMs,
                    running = false,
                    startedAtEpochMs = null,
                    updatedTimeIso = Instant.now().toString()
                )
            } else timer
        }
        return if (changed) save(workspace.copy(timers = timers)) else workspace
    }

    fun values(
        workspace: TimerWorkspace,
        selected: TimerRecord? = null,
        error: String = ""
    ): Map<String, String> {
        val nowMs = System.currentTimeMillis()
        val timer = selected ?: workspace.timers.firstOrNull()
        return linkedMapOf(
            TimerFields.STATUS to if (error.isBlank()) "succeeded" else "failed",
            TimerFields.WORKSPACE_ID to workspace.id,
            TimerFields.TIMER_ID to timer?.id.orEmpty(),
            TimerFields.TIMER_NAME to timer?.name.orEmpty(),
            TimerFields.TIMER_TYPE to timer?.type.orEmpty(),
            TimerFields.RUNNING to (timer?.running ?: false).toString(),
            TimerFields.COMPLETED to (timer?.completed(nowMs) ?: false).toString(),
            TimerFields.ELAPSED_MS to timer?.elapsed(nowMs)?.toString().orEmpty(),
            TimerFields.REMAINING_MS to timer?.remaining(nowMs)?.toString().orEmpty(),
            TimerFields.DURATION_MS to timer?.durationMs?.toString().orEmpty(),
            TimerFields.LAP_COUNT to timer?.laps?.size?.toString().orEmpty(),
            TimerFields.LAPS_JSON to JSONArray(timer?.laps ?: emptyList<Long>()).toString(),
            TimerFields.TIMER_COUNT to workspace.timers.size.toString(),
            TimerFields.TIMERS_JSON to JSONArray(workspace.timers.map { timerJson(it, nowMs) }).toString(),
            TimerFields.UPDATED_TIME_ISO to (timer?.updatedTimeIso ?: Instant.now().toString()),
            TimerFields.ERROR to error
        )
    }

    private fun mutate(
        workspace: TimerWorkspace,
        timerId: String,
        update: (TimerRecord) -> TimerRecord
    ): Pair<TimerWorkspace, TimerRecord> {
        val old = workspace.timers.firstOrNull { it.id == timerId } ?: error("Timer '$timerId' was not found.")
        val updated = update(old)
        val saved = save(workspace.copy(timers = workspace.timers.map { if (it.id == timerId) updated else it }))
        return saved to updated
    }

    private fun encode(workspace: TimerWorkspace): JSONObject = JSONObject()
        .put("workspace_id", workspace.id)
        .put("timers", JSONArray(workspace.timers.map { timerJson(it, System.currentTimeMillis()) }))

    private fun decode(json: JSONObject): TimerWorkspace {
        val timersJson = json.optJSONArray("timers") ?: JSONArray()
        val timers = (0 until timersJson.length()).mapNotNull { index ->
            val item = timersJson.optJSONObject(index) ?: return@mapNotNull null
            val lapsJson = item.optJSONArray("laps") ?: JSONArray()
            TimerRecord(
                id = item.optString("id"),
                name = item.optString("name"),
                type = item.optString("type", "stopwatch"),
                durationMs = item.optLong("duration_ms", 0L),
                accumulatedMs = item.optLong("accumulated_ms", 0L),
                running = item.optBoolean("running", false),
                startedAtEpochMs = if (item.isNull("started_at_epoch_ms")) null else item.optLong("started_at_epoch_ms"),
                laps = (0 until lapsJson.length()).map { lapsJson.optLong(it) },
                updatedTimeIso = item.optString("updated_time_iso", Instant.now().toString())
            )
        }
        return TimerWorkspace(safeId(json.optString("workspace_id", "default")), timers)
    }

    private fun timerJson(timer: TimerRecord, nowMs: Long): JSONObject = JSONObject()
        .put("id", timer.id)
        .put("name", timer.name)
        .put("type", timer.type)
        .put("duration_ms", timer.durationMs)
        .put("accumulated_ms", timer.accumulatedMs)
        .put("running", timer.running)
        .put("started_at_epoch_ms", timer.startedAtEpochMs ?: JSONObject.NULL)
        .put("elapsed_ms", timer.elapsed(nowMs))
        .put("remaining_ms", timer.remaining(nowMs))
        .put("laps", JSONArray(timer.laps))
        .put("updated_time_iso", timer.updatedTimeIso)

    private fun safeId(value: String): String = value.trim().lowercase()
        .replace(Regex("[^a-z0-9._-]+"), "-")
        .trim('-')
        .ifBlank { "default" }
        .take(64)

    companion object {
        private const val MIN_COUNTDOWN_MS = 1_000L
        private const val MAX_COUNTDOWN_MS = 604_800_000L
        private const val MAX_LAPS = 100
    }
}
