# Timers

**Status:** Development  
**Module:** `timertools`  
**Method:** `timer.manage`  
**Version:** `0.1.0`

## What it does

Provides persistent stopwatches and countdowns with pause/resume, reset, stopwatch laps, stable timer IDs, and multiple timers in one local workspace.

## Native workflow

Native use opens a persistent dashboard. Running timers are reconstructed from persisted elapsed/start state rather than relying on a screen-only counter. Stopwatch laps can be recorded and recent laps displayed. The latest `ExecutionResult` is held locally while the dashboard remains active and is submitted only when the operator explicitly finishes, following the persistent-dashboard rule.

## Preset workflow

Presets can fix the workspace and timer-creation defaults. Fixed settings are hidden at runtime. Native use remains a live timer workspace; automatic/external callers use the single-operation interface.

## External / ODK workflow

Supported operations are `snapshot`, `create`, `start`, `pause`, `reset`, `lap`, and `delete`. External calls run one operation and return structured state immediately.

## Inputs

| Input | Meaning |
|---|---|
| `workspace_id` | Stable local timer workspace. |
| `operation` | Single operation for external/protocol use. |
| `timer_id` | Existing timer identifier. |
| `timer_name` | Name for a new timer. |
| `timer_type` | `stopwatch` or `countdown`. |
| `duration_seconds` | Countdown duration when creating a countdown. |

## Outputs

Outputs include status, workspace/timer IDs and name, timer type, running/completed flags, elapsed/remaining/duration milliseconds, lap count and `timer_laps_json`, workspace `timer_timers_json`, update time, and error detail.

## Main result

Native use emphasises the live timer display. External callers normally project elapsed or remaining time plus timer ID/status.

## Audit / full metadata

The capability returns structured timer/workspace state. Standard MethodMesh FULL payload mode provides transport audit metadata; the timer repository keeps capability-owned persisted state and laps.

## Permissions and services

No Android runtime permission is required. Local app storage is used.

## Offline / online behaviour

Fully offline.

## Known limitations

- This capability does **not** claim background alarm, notification, wake-lock, or exact-alarm behaviour.
- A countdown is reliable while MethodMesh is used to inspect/update it because persisted epoch/elapsed state is reconstructed, but it is not an Android alarm clock.
- Development-stage; full-project/device testing remains required.

## ODK example

`docs/example_odk_Timers.xlsx`
