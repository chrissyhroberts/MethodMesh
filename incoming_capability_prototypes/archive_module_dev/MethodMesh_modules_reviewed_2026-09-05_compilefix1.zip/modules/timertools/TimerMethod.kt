package com.example.methodmesh.modules.timertools

import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState

object TimerFields {
    const val STATUS = "timer_status"
    const val WORKSPACE_ID = "timer_workspace_id"
    const val TIMER_ID = "timer_id"
    const val TIMER_NAME = "timer_name"
    const val TIMER_TYPE = "timer_type"
    const val RUNNING = "timer_running"
    const val COMPLETED = "timer_completed"
    const val ELAPSED_MS = "timer_elapsed_ms"
    const val REMAINING_MS = "timer_remaining_ms"
    const val DURATION_MS = "timer_duration_ms"
    const val LAP_COUNT = "timer_lap_count"
    const val LAPS_JSON = "timer_laps_json"
    const val TIMER_COUNT = "timer_count"
    const val TIMERS_JSON = "timer_timers_json"
    const val UPDATED_TIME_ISO = "timer_updated_time_iso"
    const val ERROR = "timer_error"

    val outputs = listOf(
        STATUS, WORKSPACE_ID, TIMER_ID, TIMER_NAME, TIMER_TYPE, RUNNING, COMPLETED,
        ELAPSED_MS, REMAINING_MS, DURATION_MS, LAP_COUNT, LAPS_JSON, TIMER_COUNT,
        TIMERS_JSON, UPDATED_TIME_ISO, ERROR
    )
}

object As100TimerManageMethod : As100Method {
    const val ID = "timer.manage"
    private const val VERSION = "0.1.0"

    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Persistent timers")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID),
        methodType = MethodObjectType.Workflow,
        name = "Timers",
        version = VERSION,
        description = "Create and operate persistent stopwatch and countdown timers.",
        outputs = TimerFields.outputs,
        graphOutputs = listOf(ID),
        parameters = mapOf("category" to "Time utilities", "status" to "Development")
    )
    override val contract = MethodContract(
        method = ref,
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    override fun request(
        action: String,
        context: Map<String, String>,
        signals: List<Signal>,
        inputs: List<ArchitectureRef>
    ) = As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    override fun execute(
        request: ExecutionRequest,
        settingsState: SettingsState?,
        transport: String?
    ): ExecutionResult = As100ExecutionEngine.complete(
        request,
        TransformationStatus.Unsupported,
        diagnostics = mapOf("reason" to "Persistent timers require the Android local-storage/time boundary.")
    )

    fun result(
        request: ExecutionRequest,
        values: Map<String, String>,
        invocation: InvocationContext?
    ): ExecutionResult {
        val ok = values[TimerFields.STATUS] == "succeeded"
        val provenance = ProvenanceContext("methodmesh.timertools.local", ID, VERSION)
        val entity = Entity(
            id = ArchitectureId("timer-snapshot:${System.currentTimeMillis()}"),
            entityType = "TimerSnapshot",
            attributes = mapOf(
                TimerFields.WORKSPACE_ID to values[TimerFields.WORKSPACE_ID].orEmpty(),
                TimerFields.TIMER_ID to values[TimerFields.TIMER_ID].orEmpty()
            ),
            temporalContext = request.temporalContext
        )
        val observation = Observation(
            phenomenon = ID,
            subject = ArchitectureRef(entity.id, entity.objectType, values[TimerFields.TIMER_NAME].orEmpty()),
            values = values,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        val transformation = Transformation(
            action = ID,
            method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request = request,
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOf(entity),
            observations = listOf(observation),
            transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf(TimerFields.ERROR to values[TimerFields.ERROR].orEmpty())
        ).withInvocationContext(invocation ?: InvocationContext.from(emptyMap()))
    }
}
