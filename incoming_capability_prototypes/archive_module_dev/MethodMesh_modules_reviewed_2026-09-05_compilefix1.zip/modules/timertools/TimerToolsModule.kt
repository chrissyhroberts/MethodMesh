package com.example.methodmesh.modules.timertools

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object TimerToolsModule : MethodMeshModule {
    override val moduleId = "timertools"
    override val displayName = "Timers"
    override val summary = "Persistent stopwatches and countdowns with laps and machine-friendly single operations."

    override fun as100Methods() = listOf(As100TimerManageMethod)

    override fun rilBindings() = listOf(
        RilBinding("open stopwatch", As100TimerManageMethod.ID, "Open a persistent timer workspace"),
        RilBinding("start timer", As100TimerManageMethod.ID, "Start a persistent timer"),
        RilBinding("countdown", As100TimerManageMethod.ID, "Create or operate a countdown"),
        RilBinding("lap timer", As100TimerManageMethod.ID, "Record a stopwatch lap")
    )

    override fun capabilityScreens() = listOf(TimerCapabilityScreen)

    override fun capabilitySettings() = mapOf(
        As100TimerManageMethod.ID to listOf(
            MethodSetting.TextSetting(
                id = "workspace_id",
                label = "Workspace",
                description = "Stable local timer workspace. Use the same value to return to the same timers.",
                group = "Workspace",
                defaultValue = "default"
            ),
            MethodSetting.ChoiceSetting(
                id = "operation",
                label = "Operation",
                description = "Single operation for ODK, protocols and other automatic callers. Native use opens the live timer workspace.",
                group = "Action",
                defaultValue = "snapshot",
                choices = listOf("snapshot", "create", "start", "pause", "reset", "lap", "delete")
            ),
            MethodSetting.TextSetting(
                id = "timer_id",
                label = "Timer ID",
                description = "Stable timer identifier returned by create/snapshot operations.",
                group = "Action",
                defaultValue = ""
            ),
            MethodSetting.TextSetting(
                id = "timer_name",
                label = "Timer name",
                group = "Create",
                defaultValue = "Timer"
            ),
            MethodSetting.ChoiceSetting(
                id = "timer_type",
                label = "Timer type",
                group = "Create",
                defaultValue = "stopwatch",
                choices = listOf("stopwatch", "countdown")
            ),
            MethodSetting.FloatSetting(
                id = "duration_seconds",
                label = "Countdown duration",
                description = "Used only when creating a countdown.",
                group = "Create",
                defaultValue = 60f,
                minimum = 1f,
                maximum = 604800f,
                unit = "s"
            )
        )
    )
}
