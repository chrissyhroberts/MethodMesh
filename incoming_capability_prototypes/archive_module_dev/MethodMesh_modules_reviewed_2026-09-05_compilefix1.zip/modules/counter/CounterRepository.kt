package com.example.methodmesh.modules.counter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.UUID

internal data class CounterRecord(
    val id: String,
    val name: String,
    val value: Double,
    val step: Double,
    val minimum: Double?,
    val maximum: Double?,
    val updatedTimeIso: String
)

internal data class CounterEvent(
    val timeIso: String,
    val counterId: String,
    val operation: String,
    val before: Double?,
    val after: Double?
)

internal data class CounterWorkspace(
    val id: String,
    val counters: List<CounterRecord>,
    val events: List<CounterEvent>
)

internal class CounterRepository(context: Context) {
    private val root = File(context.filesDir, "methodmesh-counter").apply { mkdirs() }

    fun load(workspaceId: String): CounterWorkspace {
        val safe = safeId(workspaceId.ifBlank { "default" })
        val file = File(root, "$safe.json")
        if (!file.exists()) return CounterWorkspace(safe, emptyList(), emptyList())
        return runCatching { decode(JSONObject(file.readText())) }.getOrElse { CounterWorkspace(safe, emptyList(), emptyList()) }
    }

    fun save(workspace: CounterWorkspace): CounterWorkspace {
        val normalised = workspace.copy(id = safeId(workspace.id.ifBlank { "default" }))
        val file = File(root, "${normalised.id}.json")
        val temp = File(root, ".${normalised.id}.${UUID.randomUUID()}.tmp")
        temp.writeText(encode(normalised).toString(2))
        if (file.exists() && !file.delete()) error("Could not replace counter workspace.")
        if (!temp.renameTo(file)) {
            temp.copyTo(file, overwrite = true)
            temp.delete()
        }
        return normalised
    }

    fun create(workspace: CounterWorkspace, name: String, value: Double, step: Double, minimum: Double?, maximum: Double?): Pair<CounterWorkspace, CounterRecord> {
        require(name.isNotBlank()) { "Counter name is required." }
        require(step.isFinite() && step > 0.0) { "Step must be greater than zero." }
        validateBounds(value, minimum, maximum)
        val now = Instant.now().toString()
        val counter = CounterRecord(UUID.randomUUID().toString(), name.trim(), value, step, minimum, maximum, now)
        val event = CounterEvent(now, counter.id, "create", null, value)
        val saved = save(workspace.copy(counters = workspace.counters + counter, events = (workspace.events + event).takeLast(MAX_EVENTS)))
        return saved to counter
    }

    fun adjust(workspace: CounterWorkspace, counterId: String, delta: Double): Pair<CounterWorkspace, CounterRecord> =
        mutate(workspace, counterId, "adjust") { it.value + delta }

    fun set(workspace: CounterWorkspace, counterId: String, value: Double): Pair<CounterWorkspace, CounterRecord> =
        mutate(workspace, counterId, "set") { value }

    fun reset(workspace: CounterWorkspace, counterId: String, value: Double = 0.0): Pair<CounterWorkspace, CounterRecord> =
        mutate(workspace, counterId, "reset") { value }

    fun delete(workspace: CounterWorkspace, counterId: String): CounterWorkspace {
        val old = workspace.counters.firstOrNull { it.id == counterId } ?: error("Counter '$counterId' was not found.")
        val now = Instant.now().toString()
        return save(
            workspace.copy(
                counters = workspace.counters.filterNot { it.id == counterId },
                events = (workspace.events + CounterEvent(now, counterId, "delete", old.value, null)).takeLast(MAX_EVENTS)
            )
        )
    }

    private fun mutate(workspace: CounterWorkspace, counterId: String, operation: String, newValue: (CounterRecord) -> Double): Pair<CounterWorkspace, CounterRecord> {
        val old = workspace.counters.firstOrNull { it.id == counterId } ?: error("Counter '$counterId' was not found.")
        val candidate = newValue(old)
        require(candidate.isFinite()) { "Counter value must be finite." }
        validateBounds(candidate, old.minimum, old.maximum)
        val now = Instant.now().toString()
        val updated = old.copy(value = candidate, updatedTimeIso = now)
        val saved = save(
            workspace.copy(
                counters = workspace.counters.map { if (it.id == counterId) updated else it },
                events = (workspace.events + CounterEvent(now, counterId, operation, old.value, candidate)).takeLast(MAX_EVENTS)
            )
        )
        return saved to updated
    }

    fun values(workspace: CounterWorkspace, selected: CounterRecord? = null, error: String = ""): Map<String, String> {
        val counter = selected ?: workspace.counters.firstOrNull()
        return linkedMapOf(
            CounterFields.STATUS to if (error.isBlank()) "succeeded" else "failed",
            CounterFields.WORKSPACE_ID to workspace.id,
            CounterFields.COUNTER_ID to counter?.id.orEmpty(),
            CounterFields.COUNTER_NAME to counter?.name.orEmpty(),
            CounterFields.VALUE to counter?.value.format(),
            CounterFields.STEP to counter?.step.format(),
            CounterFields.MINIMUM to counter?.minimum.format(),
            CounterFields.MAXIMUM to counter?.maximum.format(),
            CounterFields.COUNTER_COUNT to workspace.counters.size.toString(),
            CounterFields.COUNTERS_JSON to JSONArray(workspace.counters.map(::counterJson)).toString(),
            CounterFields.EVENT_COUNT to workspace.events.size.toString(),
            CounterFields.LAST_EVENT to workspace.events.lastOrNull()?.let(::eventJson)?.toString().orEmpty(),
            CounterFields.UPDATED_TIME_ISO to (counter?.updatedTimeIso ?: workspace.events.lastOrNull()?.timeIso ?: Instant.now().toString()),
            CounterFields.ERROR to error
        )
    }

    private fun validateBounds(value: Double, minimum: Double?, maximum: Double?) {
        require(value.isFinite()) { "Counter value must be finite." }
        if (minimum != null) require(minimum.isFinite()) { "Minimum must be finite." }
        if (maximum != null) require(maximum.isFinite()) { "Maximum must be finite." }
        if (minimum != null && maximum != null) require(minimum <= maximum) { "Minimum cannot exceed maximum." }
        if (minimum != null) require(value >= minimum) { "Value cannot be below the minimum ($minimum)." }
        if (maximum != null) require(value <= maximum) { "Value cannot exceed the maximum ($maximum)." }
    }

    private fun encode(workspace: CounterWorkspace): JSONObject = JSONObject()
        .put("workspace_id", workspace.id)
        .put("counters", JSONArray(workspace.counters.map(::counterJson)))
        .put("events", JSONArray(workspace.events.map(::eventJson)))

    private fun decode(json: JSONObject): CounterWorkspace {
        val counters = json.optJSONArray("counters") ?: JSONArray()
        val events = json.optJSONArray("events") ?: JSONArray()
        return CounterWorkspace(
            id = safeId(json.optString("workspace_id", "default")),
            counters = (0 until counters.length()).mapNotNull { i -> counters.optJSONObject(i)?.let(::counterFromJson) },
            events = (0 until events.length()).mapNotNull { i -> events.optJSONObject(i)?.let(::eventFromJson) }
        )
    }

    private fun counterJson(c: CounterRecord) = JSONObject()
        .put("id", c.id).put("name", c.name).put("value", c.value).put("step", c.step)
        .put("minimum", c.minimum ?: JSONObject.NULL).put("maximum", c.maximum ?: JSONObject.NULL)
        .put("updated_time_iso", c.updatedTimeIso)

    private fun eventJson(e: CounterEvent) = JSONObject()
        .put("time_iso", e.timeIso).put("counter_id", e.counterId).put("operation", e.operation)
        .put("before", e.before ?: JSONObject.NULL).put("after", e.after ?: JSONObject.NULL)

    private fun counterFromJson(j: JSONObject) = CounterRecord(
        id = j.optString("id"), name = j.optString("name"), value = j.optDouble("value", 0.0),
        step = j.optDouble("step", 1.0).takeIf { it > 0.0 } ?: 1.0,
        minimum = j.nullableDouble("minimum"), maximum = j.nullableDouble("maximum"),
        updatedTimeIso = j.optString("updated_time_iso", Instant.now().toString())
    )

    private fun eventFromJson(j: JSONObject) = CounterEvent(
        timeIso = j.optString("time_iso"), counterId = j.optString("counter_id"), operation = j.optString("operation"),
        before = j.nullableDouble("before"), after = j.nullableDouble("after")
    )

    private fun JSONObject.nullableDouble(key: String): Double? = if (!has(key) || isNull(key)) null else optDouble(key).takeIf { it.isFinite() }
    private fun safeId(value: String): String = value.trim().lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-').ifBlank { "default" }.take(64)
    private fun Double?.format(): String = this?.let { if (it % 1.0 == 0.0) it.toLong().toString() else "%.6f".format(java.util.Locale.US, it).trimEnd('0').trimEnd('.') }.orEmpty()

    companion object { private const val MAX_EVENTS = 1000 }
}
