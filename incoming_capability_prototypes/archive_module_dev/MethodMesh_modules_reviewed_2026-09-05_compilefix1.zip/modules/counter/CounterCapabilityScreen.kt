package com.example.methodmesh.modules.counter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityPresentationMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

object CounterCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100CounterManageMethod.ID
    override val title = "Counter"
    override val description = "Persistent named counters with adjustable steps, bounds and history."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val appContext = LocalContext.current
        val repository = remember { CounterRepository(appContext.applicationContext) }
        var workspaceId by rememberSaveable { mutableStateOf(context.setting("workspace_id", "default")) }
        var workspace by remember { mutableStateOf(repository.load(workspaceId)) }
        var selectedId by rememberSaveable { mutableStateOf(context.setting("counter_id", "")) }
        var latestExecution by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("Ready.") }
        var newName by rememberSaveable { mutableStateOf(context.setting("counter_name", "Counter")) }
        var newValue by rememberSaveable { mutableStateOf(context.setting("initial_value", "0")) }
        var newStep by rememberSaveable { mutableStateOf(context.setting("step", "1")) }
        var newMin by rememberSaveable { mutableStateOf(context.setting("minimum", "")) }
        var newMax by rememberSaveable { mutableStateOf(context.setting("maximum", "")) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        val keepLiveDashboard = context.presentationMode == CapabilityPresentationMode.Dashboard || context.isNativePresetRun || context.request.source.equals("intent_test", ignoreCase = true)

        fun resultFor(selected: CounterRecord? = null, error: String = ""): ExecutionResult {
            val input = context.request.invocationContext.asMap(As100CounterManageMethod.ID) + context.request.settings + context.action.settings + mapOf("workspace_id" to workspaceId)
            val request = As100CounterManageMethod.request(As100CounterManageMethod.ID, input, emptyList(), emptyList())
            return As100CounterManageMethod.result(request, repository.values(workspace, selected, error), context.request.invocationContext)
                .withInvocationContext(context.request.invocationContext)
        }

        fun snapshot(selected: CounterRecord? = workspace.counters.firstOrNull { it.id == selectedId }) {
            latestExecution = resultFor(selected)
            status = if (selected == null) "Workspace snapshot: ${workspace.counters.size} counters." else "${selected.name}: ${format(selected.value)}"
        }

        fun selectFallback() {
            if (workspace.counters.none { it.id == selectedId }) selectedId = workspace.counters.firstOrNull()?.id.orEmpty()
        }

        fun performExternal() {
            val operation = context.setting("operation", "snapshot")
            val requestedId = context.setting("counter_id", "")
            val requestedName = context.setting("counter_name", "Counter")
            val value = context.setting("value", context.setting("initial_value", "0")).toDoubleOrNull()
            val step = context.setting("step", "1").toDoubleOrNull() ?: 1.0
            val delta = context.setting("delta", "").toDoubleOrNull()
            val minimum = context.setting("minimum", "").toDoubleOrNull()
            val maximum = context.setting("maximum", "").toDoubleOrNull()
            val execution = runCatching {
                workspace = repository.load(workspaceId)
                val selected = when (operation) {
                    "create" -> {
                        val pair = repository.create(workspace, requestedName, value ?: 0.0, step, minimum, maximum)
                        workspace = pair.first; pair.second
                    }
                    "adjust" -> {
                        val pair = repository.adjust(workspace, requestedId, delta ?: step)
                        workspace = pair.first; pair.second
                    }
                    "set" -> {
                        val pair = repository.set(workspace, requestedId, value ?: error("A value is required for set."))
                        workspace = pair.first; pair.second
                    }
                    "reset" -> {
                        val pair = repository.reset(workspace, requestedId, value ?: 0.0)
                        workspace = pair.first; pair.second
                    }
                    "delete" -> { workspace = repository.delete(workspace, requestedId); null }
                    "snapshot" -> workspace.counters.firstOrNull { it.id == requestedId }.takeIf { requestedId.isNotBlank() } ?: workspace.counters.firstOrNull()
                    else -> error("Unsupported counter operation '$operation'.")
                }
                resultFor(selected)
            }.getOrElse { error -> resultFor(null, error.message ?: "Counter operation failed.") }
            latestExecution = execution
            if (context.submitsImmediately) onConfirmed(execution)
        }

        LaunchedEffect(workspaceId) {
            workspace = repository.load(workspaceId)
            selectFallback()
            context.onSettingsChanged(mapOf("workspace_id" to workspaceId))
            if (keepLiveDashboard) snapshot()
        }

        LaunchedEffect(context.presentationMode, context.action.settings) {
            if (!keepLiveDashboard && !launched) {
                launched = true
                performExternal()
            }
        }

        val scaffoldResult = if (keepLiveDashboard) null else latestExecution
        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = scaffoldResult,
            resultPreview = scaffoldResult?.let { OutputFormatter.fields(it, includeProvenance = false) }.orEmpty(),
            onBack = onBack,
            onRetry = { if (keepLiveDashboard) snapshot() else performExternal() },
            onConfirm = { latestExecution?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            if (!keepLiveDashboard) {
                Text(status)
                return@CapabilityScreenScaffold
            }

            Column(Modifier.fillMaxWidth()) {
                if (context.settingShouldBeShown("workspace_id")) {
                    OutlinedTextField(workspaceId, { workspaceId = it }, label = { Text("Workspace") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                }

                workspace.counters.forEach { counter ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(counter.name, style = MaterialTheme.typography.titleMedium)
                            Text(format(counter.value), style = MaterialTheme.typography.headlineMedium)
                            Text("Step ${format(counter.step)}${counter.minimum?.let { " • min ${format(it)}" }.orEmpty()}${counter.maximum?.let { " • max ${format(it)}" }.orEmpty()}", style = MaterialTheme.typography.bodySmall)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(onClick = {
                                    runCatching { repository.adjust(workspace, counter.id, -counter.step) }
                                        .onSuccess { (w, c) -> workspace = w; selectedId = c.id; snapshot(c) }
                                        .onFailure { status = it.message.orEmpty() }
                                }, modifier = Modifier.weight(1f)) { Text("− ${format(counter.step)}") }
                                Button(onClick = {
                                    runCatching { repository.adjust(workspace, counter.id, counter.step) }
                                        .onSuccess { (w, c) -> workspace = w; selectedId = c.id; snapshot(c) }
                                        .onFailure { status = it.message.orEmpty() }
                                }, modifier = Modifier.weight(1f)) { Text("+ ${format(counter.step)}") }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = {
                                    runCatching { repository.reset(workspace, counter.id) }
                                        .onSuccess { (w, c) -> workspace = w; selectedId = c.id; snapshot(c) }
                                        .onFailure { status = it.message.orEmpty() }
                                }, modifier = Modifier.weight(1f)) { Text("Reset") }
                                OutlinedButton(onClick = {
                                    runCatching { repository.delete(workspace, counter.id) }
                                        .onSuccess { w -> workspace = w; selectFallback(); snapshot() }
                                        .onFailure { status = it.message.orEmpty() }
                                }, modifier = Modifier.weight(1f)) { Text("Delete") }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Add counter", style = MaterialTheme.typography.titleMedium)
                if (context.settingShouldBeShown("counter_name")) {
                    OutlinedTextField(newName, { newName = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (context.settingShouldBeShown("initial_value")) {
                        OutlinedTextField(newValue, { newValue = it.numeric() }, label = { Text("Initial") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    if (context.settingShouldBeShown("step")) {
                        OutlinedTextField(newStep, { newStep = it.numeric() }, label = { Text("Step") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (context.settingShouldBeShown("minimum")) {
                        OutlinedTextField(newMin, { newMin = it.numeric() }, label = { Text("Min (optional)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    if (context.settingShouldBeShown("maximum")) {
                        OutlinedTextField(newMax, { newMax = it.numeric() }, label = { Text("Max (optional)") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                }
                Button(onClick = {
                    runCatching {
                        repository.create(workspace, newName, newValue.toDoubleOrNull() ?: 0.0, newStep.toDoubleOrNull() ?: 1.0, newMin.toDoubleOrNull(), newMax.toDoubleOrNull())
                    }.onSuccess { (w, c) -> workspace = w; selectedId = c.id; newName = "Counter"; snapshot(c) }
                        .onFailure { status = it.message.orEmpty() }
                }, modifier = Modifier.fillMaxWidth()) { Text("Add counter") }
                Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
                OutlinedButton(onClick = { snapshot() }, modifier = Modifier.fillMaxWidth()) { Text("Refresh snapshot") }
                if (latestExecution != null) {
                    Button(onClick = { latestExecution?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (context.isNativePresetRun) "Finish" else "Use this snapshot")
                    }
                }
            }
        }
    }
}

private fun CapabilityScreenContext.setting(key: String, fallback: String): String =
    action.settings[key] ?: action.settings["input_$key"] ?: request.settings[key] ?: request.settings["input_$key"] ?: fallback

private fun String.numeric(): String = filter { it.isDigit() || it == '-' || it == '.' }
private fun format(value: Double): String = if (value % 1.0 == 0.0) value.toLong().toString() else "%.6f".format(java.util.Locale.US, value).trimEnd('0').trimEnd('.')
