package com.example.methodmesh.modules.counter

import com.example.methodmesh.core.methodmesh.ArchitectureId
import com.example.methodmesh.core.methodmesh.ArchitectureRef
import com.example.methodmesh.core.methodmesh.Entity
import com.example.methodmesh.core.methodmesh.ExecutionRequest
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.core.methodmesh.KnowledgeObjectType
import com.example.methodmesh.core.methodmesh.MethodContract
import com.example.methodmesh.core.methodmesh.MethodDescriptor
import com.example.methodmesh.core.methodmesh.MethodObjectType
import com.example.methodmesh.core.methodmesh.Observation
import com.example.methodmesh.core.methodmesh.ProvenanceContext
import com.example.methodmesh.core.methodmesh.Signal
import com.example.methodmesh.core.methodmesh.Transformation
import com.example.methodmesh.core.methodmesh.TransformationStatus
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState

object CounterFields {
    const val STATUS = "counter_status"
    const val WORKSPACE_ID = "counter_workspace_id"
    const val COUNTER_ID = "counter_id"
    const val COUNTER_NAME = "counter_name"
    const val VALUE = "counter_value"
    const val STEP = "counter_step"
    const val MINIMUM = "counter_minimum"
    const val MAXIMUM = "counter_maximum"
    const val COUNTER_COUNT = "counter_count"
    const val COUNTERS_JSON = "counter_counters_json"
    const val EVENT_COUNT = "counter_event_count"
    const val LAST_EVENT = "counter_last_event"
    const val UPDATED_TIME_ISO = "counter_updated_time_iso"
    const val ERROR = "counter_error"

    val outputs = listOf(
        STATUS, WORKSPACE_ID, COUNTER_ID, COUNTER_NAME, VALUE, STEP, MINIMUM, MAXIMUM,
        COUNTER_COUNT, COUNTERS_JSON, EVENT_COUNT, LAST_EVENT, UPDATED_TIME_ISO, ERROR
    )
}

object As100CounterManageMethod : As100Method {
    const val ID = "counter.manage"
    private const val VERSION = "0.1.0"

    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Persistent counter")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID),
        methodType = MethodObjectType.Workflow,
        name = "Counter",
        version = VERSION,
        description = "Create, adjust, reset and snapshot persistent named counters.",
        outputs = CounterFields.outputs,
        graphOutputs = listOf(ID),
        parameters = mapOf("category" to "Utility state", "status" to "Development")
    )
    override val contract = MethodContract(
        method = ref,
        producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation),
        producedFields = descriptor.outputs,
        producedGraphOutputs = descriptor.graphOutputs
    )

    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) =
        As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)

    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult =
        As100ExecutionEngine.complete(
            request,
            TransformationStatus.Unsupported,
            diagnostics = mapOf("reason" to "Persistent counter operations require the Android local-storage boundary.")
        )

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[CounterFields.STATUS] == "succeeded"
        val entity = Entity(
            ArchitectureId("counter-snapshot:${System.currentTimeMillis()}"),
            "CounterSnapshot",
            attributes = mapOf(
                CounterFields.WORKSPACE_ID to values[CounterFields.WORKSPACE_ID].orEmpty(),
                CounterFields.COUNTER_ID to values[CounterFields.COUNTER_ID].orEmpty()
            ),
            temporalContext = request.temporalContext
        )
        val provenance = ProvenanceContext("methodmesh.counter.local", ID, VERSION)
        val observation = Observation(
            phenomenon = ID,
            subject = ArchitectureRef(entity.id, entity.objectType, values[CounterFields.COUNTER_NAME].orEmpty()),
            values = values,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        val transformation = Transformation(
            action = ID,
            method = ref,
            outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)),
            status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            temporalContext = request.temporalContext,
            provenance = provenance
        )
        return As100ExecutionEngine.complete(
            request,
            if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed,
            entities = listOf(entity),
            observations = listOf(observation),
            transformations = listOf(transformation),
            diagnostics = if (ok) emptyMap() else mapOf(CounterFields.ERROR to values[CounterFields.ERROR].orEmpty())
        ).withInvocationContext(invocation ?: InvocationContext.from(emptyMap()))
    }
}
