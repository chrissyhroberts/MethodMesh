# Counter

**Status:** Development  
**Module:** `counter`  
**Method:** `counter.manage`  
**Version:** `0.1.0`

## What it does

Provides persistent, named numeric counters for general-purpose tallying: repetitions, inventory, footfall, scores, observations, event counts, or any other operator-maintained numeric state. This is intentionally separate from `tabletoputilities`, whose counters belong to game workspaces.

A workspace can contain multiple counters. Each counter has a stable ID, display name, current value, step, optional minimum/maximum bounds, update timestamp, and an auditable local event history.

## Native workflow

Native use opens a persistent live dashboard. The operator can create counters, increment/decrement by the configured step, set/reset values, and delete counters. The live dashboard retains the latest real `ExecutionResult` locally but does not pass it to the generic MethodMesh result scaffold until the operator explicitly chooses **Use this snapshot / Finish**. This follows the persistent-dashboard rule and avoids recording a graph result for every button press.

## Preset workflow

A preset may fix the workspace and creation defaults. Fixed values are hidden with `settingShouldBeShown(...)`. Native preset execution still opens the live dashboard; it does not silently auto-finish because the useful object is the persistent workspace state.

## External / ODK workflow

External callers perform one declared operation and return immediately. Supported `operation` values are:

- `snapshot`
- `create`
- `adjust`
- `set`
- `reset`
- `delete`

The supplied XLSForm demonstrates grouped intent calls that create a counter and then adjust the returned ID.

## Inputs

| Input | Meaning |
|---|---|
| `workspace_id` | Stable local workspace ID. |
| `operation` | One operation from the list above. |
| `counter_id` | Stable counter ID for operations on an existing counter. |
| `counter_name` | Name used when creating a counter. |
| `initial_value` | Starting value for create. |
| `value` | Explicit value for set. |
| `delta` | Signed adjustment for adjust. |
| `step` | Positive native increment/decrement step. |
| `minimum` | Optional lower bound. |
| `maximum` | Optional upper bound. |

## Outputs

Core outputs include `counter_status`, workspace/counter identifiers, `counter_name`, `counter_value`, `counter_step`, optional bounds, number of counters, `counter_counters_json`, event count, last event, update time, and `counter_error`.

## Main result

Native use prioritises the live counter dashboard and current values. External use should normally project `counter_value` plus the counter ID/name required by the caller.

## Audit / full metadata

Counter state is stored locally under the capability-owned repository. Event history records timestamp, operation and before/after values. Normal MethodMesh FULL payload mode remains the transport-level audit envelope; callers that need the complete workspace snapshot can retain `counter_counters_json` as well.

## Permissions and services

No Android runtime permission is required. Persistence uses capability-owned app-local storage.

## Offline / online behaviour

Fully offline. No network request or third-party service is used.

## Known limitations

- Development-stage; physical-device and full-project integration testing remain required.
- Counters are numeric `Double` values rather than arbitrary typed state.
- Persistence is device-local and is not a synchronisation system.
- The bounded event history is an operational history, not a cryptographic append-only ledger.

## ODK example

`docs/example_odk_Counter.xlsx`
