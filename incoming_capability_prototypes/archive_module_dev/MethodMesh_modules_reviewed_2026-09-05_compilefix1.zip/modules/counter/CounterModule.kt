package com.example.methodmesh.modules.counter

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object CounterModule : MethodMeshModule {
    override val moduleId = "counter"
    override val displayName = "Counters"
    override val summary = "Persistent named counters for tallying, scores, inventory, repetitions and arbitrary state."

    override fun as100Methods() = listOf(As100CounterManageMethod)

    override fun rilBindings() = listOf(
        RilBinding("open counter", As100CounterManageMethod.ID),
        RilBinding("count things", As100CounterManageMethod.ID),
        RilBinding("increment counter", As100CounterManageMethod.ID),
        RilBinding("tally", As100CounterManageMethod.ID)
    )

    override fun capabilityScreens() = listOf(CounterCapabilityScreen)

    override fun capabilitySettings() = mapOf(
        As100CounterManageMethod.ID to listOf(
            MethodSetting.TextSetting("workspace_id", "Workspace", defaultValue = "default"),
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "snapshot", choices = listOf("snapshot", "create", "adjust", "set", "reset", "delete")),
            MethodSetting.TextSetting("counter_id", "Counter ID", defaultValue = ""),
            MethodSetting.TextSetting("counter_name", "Counter name", defaultValue = "Counter"),
            MethodSetting.FloatSetting("initial_value", "Initial value", defaultValue = 0f),
            MethodSetting.FloatSetting("value", "Value", defaultValue = 0f),
            MethodSetting.FloatSetting("delta", "Adjustment", defaultValue = 1f),
            MethodSetting.FloatSetting("step", "Step", defaultValue = 1f, minimum = 0.000001f),
            MethodSetting.TextSetting("minimum", "Minimum (optional)", defaultValue = ""),
            MethodSetting.TextSetting("maximum", "Maximum (optional)", defaultValue = "")
        )
    )
}
