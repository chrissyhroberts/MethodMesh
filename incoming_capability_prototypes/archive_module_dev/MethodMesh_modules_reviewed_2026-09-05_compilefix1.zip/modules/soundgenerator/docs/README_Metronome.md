# Metronome

**Status:** Development  
**Module:** `soundgenerator`  
**Method:** `sound.metronome`

## What it does
Generates and plays a bounded metronome sequence through the module's existing local audio synthesis/playback boundary.

## Native workflow
Set tempo, beat count, click frequency/duration and digital level; start playback; stop/cancel if required; use the playback result after the bounded sequence completes.

## Preset workflow
All settings are declared and fixed preset values are hidden with `settingShouldBeShown(...)`.

## ODK / XLSForm workflow
`example_odk_sound.metronome.xlsx` demonstrates grouped intent invocation and returned playback metadata.

## Inputs
`bpm`, `beats`, `frequency_hz`, `click_ms`, `level_dbfs`.

## Outputs and main result
Playback status, declared tempo/beat/click parameters, timing/provenance and error fields. The primary result is completion/stopped status with the declared tempo and beats.

## Audit / full metadata
Uses the Sound Generator provenance model and standard MethodMesh FULL payload mode.

## Permissions/services and offline behaviour
Local Android audio only; no network service is used.

## Known limitations
Runs are intentionally bounded to at most 60 seconds in v0.1. This is a local timing stimulus, not a calibrated acoustic output level: dBFS is digital amplitude, not SPL.
