package com.example.methodmesh.modules.soundgenerator

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.*
import kotlin.math.roundToInt

object MetronomeCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100MetronomeMethod.ID
    override val title = "Metronome"
    override val description = "Play a bounded, reproducible click sequence."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val app = LocalContext.current
        val player = remember { AndroidSoundPlayer(app.applicationContext) }
        var bpm by rememberSaveable { mutableStateOf(context.setting("bpm", "120")) }
        var beats by rememberSaveable { mutableStateOf(context.setting("beats", "16")) }
        var frequency by rememberSaveable { mutableStateOf(context.setting("frequency_hz", "1000")) }
        var clickMs by rememberSaveable { mutableStateOf(context.setting("click_ms", "40")) }
        var level by rememberSaveable { mutableStateOf(context.setting("level_dbfs", "-24")) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var status by rememberSaveable { mutableStateOf("Ready.") }
        var busy by remember { mutableStateOf(false) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun play() {
            val bpmValue = bpm.toDoubleOrNull()
            val beatsValue = beats.toIntOrNull()
            val clickValue = clickMs.toIntOrNull()
            val frequencyValue = frequency.toDoubleOrNull()
            val levelValue = level.toDoubleOrNull()
            val error = when {
                bpmValue == null || bpmValue !in 30.0..300.0 -> "BPM must be 30–300."
                beatsValue == null || beatsValue !in 1..128 -> "Beats must be 1–128."
                clickValue == null || clickValue !in 10..200 -> "Click duration must be 10–200 ms."
                frequencyValue == null || frequencyValue !in 100.0..8000.0 -> "Frequency must be 100–8000 Hz."
                levelValue == null || levelValue !in -80.0..0.0 -> "Level must be -80 to 0 dBFS."
                else -> null
            }
            if (error != null) { status = error; return }
            val interval = (60_000.0 / bpmValue!!).roundToInt().coerceAtLeast(clickValue!!)
            val duration = interval.toLong() * beatsValue!!
            if (duration > 60_000L) { status = "This bounded metronome run would exceed 60 seconds; reduce beats or increase BPM."; return }
            val spec = SoundSpec(
                stimulusType = "tone", waveform = "sine", frequencyHz = frequencyValue!!, levelDbfs = levelValue!!,
                durationMs = duration.toInt().coerceAtLeast(20), channel = "both", fadeMs = minOf(5, clickValue / 2),
                gateMode = "pulsed", pulseOnMs = clickValue, pulseOffMs = (interval - clickValue).coerceAtLeast(0), sampleRateHz = 48000
            )
            val input = mapOf("bpm" to bpm, "beats" to beats, "frequency_hz" to frequency, "click_ms" to clickMs, "level_dbfs" to level)
            context.onSettingsChanged(input)
            busy = true; status = "Playing…"
            player.play(spec, PlaybackSettings()) { rendered, outcome ->
                busy = false
                val values = linkedMapOf(
                    MetronomeFields.STATUS to outcome.status,
                    MetronomeFields.BPM to bpm,
                    MetronomeFields.BEATS to beats,
                    MetronomeFields.BEAT_INTERVAL_MS to interval.toString(),
                    MetronomeFields.CLICK_MS to clickMs,
                    MetronomeFields.FREQUENCY_HZ to frequency,
                    MetronomeFields.LEVEL_DBFS to level,
                    MetronomeFields.DURATION_MS to duration.toString(),
                    MetronomeFields.PCM_SHA256 to rendered?.pcmSha256.orEmpty(),
                    MetronomeFields.WRITTEN_PCM_SHA256 to outcome.writtenPcmSha256,
                    MetronomeFields.FRAMES_PLAYED to outcome.framesPlayed.toString(),
                    MetronomeFields.ROUTED_DEVICE to outcome.routedDevice,
                    MetronomeFields.STARTED_TIME_ISO to outcome.startedTimeIso,
                    MetronomeFields.FINISHED_TIME_ISO to outcome.finishedTimeIso,
                    MetronomeFields.ERROR to outcome.error
                )
                val req = As100MetronomeMethod.request(capabilityId, context.request.invocationContext.asMap(capabilityId) + context.request.settings + context.action.settings + input, emptyList(), emptyList())
                val execution = As100MetronomeMethod.result(req, values, context.request.invocationContext)
                result = execution
                status = if (outcome.status == "played") "Played $beats beats at $bpm BPM." else outcome.error.ifBlank { outcome.status }
                if (context.submitsImmediately) onConfirmed(execution)
            }
        }

        LaunchedEffect(context.startsImmediately) { if (context.startsImmediately && !launched) { launched = true; play() } }
        DisposableEffect(Unit) { onDispose { if (player.isPlaying()) player.stop() } }

        CapabilityScreenScaffold(title, capabilityId, context, context.stepNumber > 1, result, result?.let { OutputFormatter.fields(it, false) }.orEmpty(), onBack, { play() }, { result?.let(onConfirmed) }, onCancel) {
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (context.settingShouldBeShown("bpm")) OutlinedTextField(bpm, { bpm = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("BPM") }, modifier = Modifier.weight(1f), singleLine = true)
                    if (context.settingShouldBeShown("beats")) OutlinedTextField(beats, { beats = it.filter(Char::isDigit) }, label = { Text("Beats") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (context.settingShouldBeShown("frequency_hz")) OutlinedTextField(frequency, { frequency = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Click Hz") }, modifier = Modifier.weight(1f), singleLine = true)
                    if (context.settingShouldBeShown("click_ms")) OutlinedTextField(clickMs, { clickMs = it.filter(Char::isDigit) }, label = { Text("Click ms") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                if (context.settingShouldBeShown("level_dbfs")) OutlinedTextField(level, { level = it.filter { c -> c.isDigit() || c == '-' || c == '.' } }, label = { Text("Level dBFS") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                Button({ if (busy) player.stop() else play() }, Modifier.fillMaxWidth()) { Text(if (busy) "Stop" else "Play metronome") }
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun CapabilityScreenContext.setting(key: String, fallback: String): String = action.settings[key] ?: action.settings["input_$key"] ?: request.settings[key] ?: request.settings["input_$key"] ?: fallback
