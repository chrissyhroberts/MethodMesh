# Arcade implementation notes — v0.02

## Capability boundary

Arcade is a separate MethodMesh capability:

```text
arcade/
```

It is discovered through its normal `MethodMeshModule`. No MethodMesh runtime code should branch on `arcade`, `Arcade`, Snake, Pong, or any game type.

Arcade requests the generic:

```kotlin
CapabilityHostPresentation.Immersive
```

The host knows only the presentation contract.

Arcade also does **not** import GameDeck persistence or rules internals. GameDeck and Arcade should eventually share player identity / record / replay services through a public game-system boundary rather than coupling capability folders.

## Real-time rule

Rendering cadence is not authoritative game state.

Arcade advances gameplay through explicit fixed steps:

```text
input → state transition → fixed step → new state → render
```

A delayed UI frame can make a run appear slower, but it must not silently change the magnitude of a physics step.

Current fixed steps:

- Pong: 16 ms simulation step.
- Snake: 120 ms grid movement step.

## Modal pause rule

Opening:

- MENU
- How to Play

pauses real-time state advancement. Closing the modal resumes from the same state.

A modal must also intercept touches so paddle/snake input cannot pass through it.

## Interaction rule

A hidden gesture may be a shortcut, but not the only route to a core action.

Snake therefore supports:

- swipe;
- visible arrow controls.

Pong supports:

- drag;
- tap positioning.

## Snake invariants

- `dir` is the committed direction.
- `queued_dir` is applied on the next movement step.
- Requested direction is validated against committed direction, preventing two rapid intermediate turns from producing a hidden 180° reversal.
- The current tail cell is not treated as occupied when that tail will vacate on a non-growth step.
- Food placement uses MethodMesh Chance through `As100DiceSimulationMethod`.
- `secure_random` is normal play.
- `fixed_seed` is reproducible testing/demo mode.
- Full-board occupancy terminates as `cleared`.

## Pong invariants

- The local/near paddle is P1.
- The far paddle is P2 or CPU.
- In two-human mode the far rail rotates 180°.
- In CPU mode the far rail remains upright.
- A drag chooses its owning paddle at drag start; crossing the centre line cannot transfer control.
- Match mode may be changed only before START MATCH.
- First to seven wins.
- A short centre serve pause follows each point.

## Local records

`ArcadeRecordStore` is intentionally small:

- total finished games;
- Snake best score;
- Snake longest length;
- Pong CPU wins/losses;
- shared two-player Pong matches.

This is not the final cross-capability player service. When that service exists, Arcade should migrate through its public interface.

## Validation

The authoritative project checks remain:

```bash
./gradlew :app:compileDebugKotlin
./gradlew :app:assembleDebug
```


## Source layout

The real-time UI is deliberately split so Arcade does not repeat GameDeck's early monolithic-screen problem:

```text
ArcadeCapabilityScreen.kt   lifecycle/orchestration
ArcadeChrome.kt             launcher/menu/help/results
ArcadeSnakeScreen.kt        Snake presentation/input
ArcadePongScreen.kt         Pong presentation/input
ArcadeEngine.kt             authoritative state transitions
ArcadeFramework.kt          generic fixed-step contracts
ArcadeRecords.kt            provisional local records
ArcadeUxCatalog.kt          launcher/help copy
```
