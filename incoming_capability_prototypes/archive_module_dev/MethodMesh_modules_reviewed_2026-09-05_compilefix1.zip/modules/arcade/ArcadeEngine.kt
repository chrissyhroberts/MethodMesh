package com.example.methodmesh.modules.arcade

import com.example.methodmesh.modules.chance.As100DiceSimulationMethod
import com.example.methodmesh.modules.chance.DiceSimulationFields
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

object ArcadeEngine {
    const val LAUNCHER = "launcher"
    const val SNAKE = "snake"
    const val PONG = "pong"

    fun newState(
        game: String,
        rngMode: String = "secure_random",
        seed: String = ""
    ): String = when (game) {
        SNAKE -> snakeInitial(rngMode, seed)
        PONG -> pongInitial()
        else -> JSONObject()
            .put("game", LAUNCHER)
            .put("score", 0)
            .put("lives", 0)
            .put("tick", 0L)
            .put("started", false)
            .put("finished", false)
            .put("winner", "")
            .toString()
    }

    fun summary(stateJson: String): ArcadeSummary {
        val s = runCatching { JSONObject(stateJson) }.getOrElse { JSONObject() }
        val game = s.optString("game", LAUNCHER)
        val detail = when (game) {
            SNAKE -> {
                val length = s.optJSONArray("body")?.length() ?: 0
                "Score ${s.optInt("score", 0)} • length $length"
            }
            PONG -> "P1 ${s.optInt("p1_score", 0)} : ${s.optInt("p2_score", 0)} P2"
            else -> ""
        }
        return ArcadeSummary(
            game = game,
            score = s.optInt("score", 0),
            tick = s.optLong("tick", 0L),
            finished = s.optBoolean("finished", false),
            winner = s.optString("winner", ""),
            detail = detail
        )
    }

    // -----------------------------------------------------------------
    // Snake Sprint
    // -----------------------------------------------------------------

    private fun snakeInitial(rngMode: String, seed: String): String {
        val body = JSONArray(listOf(42, 41, 40))
        return JSONObject()
            .put("game", SNAKE)
            .put("body", body)
            .put("dir", 1)
            .put("queued_dir", 1)
            .put("food_index", 0)
            .put("food", chanceCell(rngMode, seed, 0, body))
            .put("score", 0)
            .put("lives", 1)
            .put("tick", 0L)
            .put("started", false)
            .put("finished", false)
            .put("winner", "")
            .put("reason", "")
            .toString()
    }

    fun snakeStart(stateJson: String): String {
        val s = JSONObject(stateJson)
        if (!s.optBoolean("finished", false)) s.put("started", true)
        return s.toString()
    }

    /**
     * Queue a turn without changing the committed direction until the next step.
     * This prevents two rapid taps between ticks from producing a hidden 180° turn.
     */
    fun snakeTurn(stateJson: String, requestedDir: Int): String {
        val s = JSONObject(stateJson)
        if (s.optBoolean("finished", false) || requestedDir !in 0..3) return stateJson

        val committed = s.optInt("dir", 1).coerceIn(0, 3)
        val opposite = (committed + 2) % 4
        if (requestedDir != opposite) {
            s.put("queued_dir", requestedDir)
        }
        return s.toString()
    }

    fun snakeStep(
        stateJson: String,
        rngMode: String = "secure_random",
        seed: String = ""
    ): String {
        val s = JSONObject(stateJson)
        if (s.optBoolean("finished", false) || !s.optBoolean("started", false)) {
            return stateJson
        }

        val bodyJson = s.getJSONArray("body")
        val body = MutableList(bodyJson.length()) { bodyJson.optInt(it) }
        if (body.isEmpty()) return s.put("finished", true).put("reason", "invalid_body").toString()

        val dir = s.optInt("queued_dir", s.optInt("dir", 1)).coerceIn(0, 3)
        val head = body.first()
        val row = head / 10
        val col = head % 10

        val next = when (dir) {
            0 -> (row - 1) to col
            1 -> row to (col + 1)
            2 -> (row + 1) to col
            else -> row to (col - 1)
        }

        val nextTick = s.optLong("tick", 0L) + 1L
        if (next.first !in 0..9 || next.second !in 0..9) {
            return s
                .put("dir", dir)
                .put("queued_dir", dir)
                .put("tick", nextTick)
                .put("started", false)
                .put("finished", true)
                .put("winner", "failed")
                .put("reason", "wall")
                .toString()
        }

        val cell = next.first * 10 + next.second
        val food = s.optInt("food", -1)
        val grows = cell == food

        // The tail vacates on a normal move, so entering the current tail cell is
        // legal when the snake is not growing.
        val collisionBody = if (grows) body else body.dropLast(1)
        if (cell in collisionBody) {
            return s
                .put("dir", dir)
                .put("queued_dir", dir)
                .put("tick", nextTick)
                .put("started", false)
                .put("finished", true)
                .put("winner", "failed")
                .put("reason", "self")
                .toString()
        }

        body.add(0, cell)

        if (grows) {
            val score = s.optInt("score", 0) + 10
            val nextFoodIndex = s.optInt("food_index", 0) + 1

            s.put("score", score)
                .put("food_index", nextFoodIndex)

            if (body.size >= 100) {
                return s
                    .put("body", JSONArray(body))
                    .put("dir", dir)
                    .put("queued_dir", dir)
                    .put("tick", nextTick)
                    .put("started", false)
                    .put("finished", true)
                    .put("winner", "cleared")
                    .put("reason", "board_cleared")
                    .toString()
            }

            s.put(
                "food",
                chanceCell(rngMode, seed, nextFoodIndex, JSONArray(body))
            )
        } else {
            body.removeAt(body.lastIndex)
        }

        return s
            .put("body", JSONArray(body))
            .put("dir", dir)
            .put("queued_dir", dir)
            .put("tick", nextTick)
            .toString()
    }

    private fun chanceCell(
        rngMode: String,
        seed: String,
        foodIndex: Int,
        occupied: JSONArray
    ): Int {
        val used = (0 until occupied.length()).map { occupied.optInt(it) }.toSet()
        val free = (0 until 100).filter { it !in used }
        if (free.isEmpty()) return 0

        val mode = if (rngMode.equals("fixed_seed", ignoreCase = true)) {
            "fixed_seed"
        } else {
            "secure_random"
        }

        val out = As100DiceSimulationMethod.generate(
            mapOf(
                "expression" to "d${free.size}",
                "roll_count" to "1",
                "player_count" to "1",
                "history_output" to "false",
                "rng_mode" to mode,
                "seed" to if (mode == "fixed_seed") "$seed|arcade-snake|food|$foodIndex" else "",
                "animation_mode" to "off"
            )
        )
        val index = ((out[DiceSimulationFields.TOTAL]?.toIntOrNull() ?: 1) - 1)
            .coerceIn(0, free.lastIndex)
        return free[index]
    }

    // -----------------------------------------------------------------
    // Pong Table
    // -----------------------------------------------------------------

    private fun pongInitial(): String = JSONObject()
        .put("game", PONG)
        .put("ball_x", .5)
        .put("ball_y", .5)
        .put("vx", .30)
        .put("vy", .44)
        .put("p1", .5)
        .put("p2", .5)
        .put("p1_score", 0)
        .put("p2_score", 0)
        .put("score", 0)
        .put("lives", 0)
        .put("tick", 0L)
        .put("started", false)
        .put("finished", false)
        .put("winner", "")
        .put("cpu", true)
        .put("serve_ticks", 0)
        .put("last_point", 0)
        .toString()

    fun pongSetCpu(stateJson: String, cpu: Boolean): String {
        val s = JSONObject(stateJson)
        if (!s.optBoolean("started", false) &&
            s.optInt("p1_score", 0) == 0 &&
            s.optInt("p2_score", 0) == 0
        ) {
            s.put("cpu", cpu)
        }
        return s.toString()
    }

    fun pongStart(stateJson: String): String {
        val s = JSONObject(stateJson)
        if (!s.optBoolean("finished", false)) {
            s.put("started", true)
                .put("serve_ticks", 42)
        }
        return s.toString()
    }

    fun pongPaddle(stateJson: String, player: Int, x: Float): String {
        val s = JSONObject(stateJson)
        if (s.optBoolean("finished", false)) return stateJson
        if (player == 2 && s.optBoolean("cpu", true)) return stateJson

        val key = if (player == 2) "p2" else "p1"
        s.put(key, x.coerceIn(.14f, .86f).toDouble())
        return s.toString()
    }

    fun pongStep(
        stateJson: String,
        dt: Float = ArcadeFixedStep.STEP_SECONDS
    ): String {
        val s = JSONObject(stateJson)
        if (s.optBoolean("finished", false) || !s.optBoolean("started", false)) {
            return stateJson
        }

        var x = s.optDouble("ball_x", .5)
        var y = s.optDouble("ball_y", .5)
        var vx = s.optDouble("vx", .30)
        var vy = s.optDouble("vy", .44)
        val p1 = s.optDouble("p1", .5)
        var p2 = s.optDouble("p2", .5)
        val nextTick = s.optLong("tick", 0L) + 1L

        if (s.optBoolean("cpu", true)) {
            val delta = x - p2
            p2 += delta.coerceIn(-.018, .018)
        }

        val serveTicks = s.optInt("serve_ticks", 0)
        if (serveTicks > 0) {
            return s
                .put("p2", p2)
                .put("serve_ticks", serveTicks - 1)
                .put("tick", nextTick)
                .toString()
        }

        x += vx * dt
        y += vy * dt

        if (x < .04) {
            x = .04
            vx = abs(vx)
        } else if (x > .96) {
            x = .96
            vx = -abs(vx)
        }

        val paddleHalf = .14
        if (y > .93 && vy > 0 && abs(x - p1) < paddleHalf) {
            y = .93
            vy = -abs(vy) * 1.015
            vx += (x - p1) * .30
        }

        if (y < .07 && vy < 0 && abs(x - p2) < paddleHalf) {
            y = .07
            vy = abs(vy) * 1.015
            vx += (x - p2) * .30
        }

        var p1Score = s.optInt("p1_score", 0)
        var p2Score = s.optInt("p2_score", 0)
        var lastPoint = 0

        if (y < 0) {
            p1Score++
            lastPoint = 1
            x = .5
            y = .5
            vx = .24
            vy = .44
        } else if (y > 1) {
            p2Score++
            lastPoint = 2
            x = .5
            y = .5
            vx = -.24
            vy = -.44
        }

        val finished = p1Score >= 7 || p2Score >= 7
        val winner = when {
            p1Score >= 7 -> "1"
            p2Score >= 7 -> "2"
            else -> ""
        }

        return s
            .put("ball_x", x)
            .put("ball_y", y)
            .put("vx", vx)
            .put("vy", vy)
            .put("p1", p1)
            .put("p2", p2)
            .put("p1_score", p1Score)
            .put("p2_score", p2Score)
            .put("score", p1Score)
            .put("last_point", lastPoint)
            .put("serve_ticks", if (!finished && lastPoint != 0) 42 else 0)
            .put("tick", nextTick)
            .put("started", !finished)
            .put("finished", finished)
            .put("winner", winner)
            .toString()
    }
}
