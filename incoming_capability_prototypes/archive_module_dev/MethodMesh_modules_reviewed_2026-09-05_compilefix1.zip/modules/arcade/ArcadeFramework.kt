package com.example.methodmesh.modules.arcade

/** Input abstraction for future controller / P2P adapters. */
data class ArcadeInput(
    val x: Float = 0f,
    val y: Float = 0f,
    val action: Boolean = false
)

data class ArcadeFrameMeta(
    val tick: Long,
    val elapsedMs: Long,
    val score: Int,
    val lives: Int,
    val finished: Boolean
)

data class ArcadeSummary(
    val game: String,
    val score: Int,
    val tick: Long,
    val finished: Boolean,
    val winner: String,
    val detail: String
)

/**
 * Generic real-time game contract.
 *
 * Rendering is intentionally separate from simulation. The rules state owns the
 * result; animation/render cadence never decides game outcomes.
 */
interface ArcadeGameSpec<S> {
    val id: String
    fun initial(seed: String = ""): S
    fun step(state: S, input: ArcadeInput, dtSeconds: Float): S
    fun frameMeta(state: S): ArcadeFrameMeta
}

interface ArcadeCpuController<S> {
    fun input(state: S): ArcadeInput
}

/**
 * Fixed-step constants. A delayed frame can make the game appear slower, but it
 * does not change the size of an authoritative simulation step.
 */
object ArcadeFixedStep {
    const val STEP_MS = 16L
    const val STEP_SECONDS = 0.016f

    const val SNAKE_STEP_MS = 120L
}
