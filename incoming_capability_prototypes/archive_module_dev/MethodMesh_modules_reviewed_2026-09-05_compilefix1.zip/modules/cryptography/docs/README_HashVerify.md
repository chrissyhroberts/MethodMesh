# Checksum verification

**Status:** Development  
**Module:** `cryptography`  
**Method:** `crypto.hash.verify`

## What it does
Calculates SHA-256 or SHA-512 over supplied text or selected file bytes and compares the result with an expected hexadecimal digest.

## Native workflow
Choose text/file source, algorithm and expected digest; run verification; use the direct match/non-match result.

## Preset workflow
Algorithm/source settings are declared by Cryptography; fixed preset values are hidden in the capability screen.

## ODK / XLSForm workflow
`example_odk_crypto.hash.verify.xlsx` demonstrates grouped intent execution and returned verification fields.

## Inputs
Source text or `input_uri`, `algorithm`, expected hexadecimal digest.

## Outputs and main result
Calculated digest, expected digest, algorithm, boolean match, source metadata/provenance and error/status. The boolean match plus calculated digest are the main result.

## Audit / full metadata
Uses the Cryptography module's existing provenance model and MethodMesh FULL envelope. Secret plaintext is not introduced into provenance merely for verification.

## Permissions/services and offline behaviour
Fully offline. File access uses Android content-URI permission granted by the selected document source.

## Known limitations
Digest equality proves byte equality with the supplied expected digest; it does not prove authorship, identity or trustworthiness of the expected digest.
