# Image tools

**Status:** Development  
**Module:** `imagetools`  
**Methods:** `image.inspect`, `image.transform`  
**Version:** `0.1.0`

## What it does

General deterministic image utilities that are intentionally separate from scientific scaled photography and evidence redaction.

- `image.inspect`: dimensions, MIME/size, SHA-256, limited EXIF orientation/date, and pixel colour sampling by percentage coordinate.
- `image.transform`: rotation, centre crop, maximum-dimension resize, JPEG/PNG re-encoding and output attachment generation.

## Native workflow

Select an image through the capability-owned picker, inspect it or choose transform settings, then confirm the useful result/output image.

## Preset workflow

Transform/inspection settings are declared through the module. Fixed preset values use `settingShouldBeShown(...)`; file selection can remain a runtime input.

## ODK / XLSForm workflow

The example workbook demonstrates grouped intent calls for inspection and transformation. Media-producing workflows should retain the returned output URI/attachment according to the normal MethodMesh external transport contract.

## Inputs

`image.inspect`: `image_uri`, `sample_x_percent`, `sample_y_percent`.  
`image.transform`: `image_uri`, `max_dimension_px`, `rotation_deg`, `crop_mode`, `format`, `quality`.

## Outputs

Outputs include source/output URI and output name, MIME type, dimensions, bytes, limited EXIF values, sampled RGB/hex colour, transform parameters, SHA-256, metadata policy, and error/status fields.

## Main result

For inspection: dimensions/sample colour and selected metadata. For transformation: the transformed image attachment/URI.

## Audit / full metadata

Inspection reports SHA-256 of the source bytes. Transformation reports SHA-256 of the generated output and `imagetool_metadata_policy=stripped_by_decode_reencode`.

## Permissions and services

Uses Android content selection, bitmap decoding/encoding and FileProvider output. It does not require the camera because it operates on existing image content.

## Offline / online behaviour

Fully offline.

## Metadata policy

Transforming an image decodes and re-encodes it; original metadata is therefore not silently preserved. This is reported explicitly. `image.inspect` is inspection-only and does not modify the source.

## Known limitations

- Re-encoding can be memory intensive for very large images; v0.1 is a practical utility rather than a tiled image-processing engine.
- EXIF inspection is deliberately limited.
- This module is not a provenance-safe redaction tool; use `imageredaction` for that domain.

## ODK example

`docs/example_odk_ImageTools.xlsx`
