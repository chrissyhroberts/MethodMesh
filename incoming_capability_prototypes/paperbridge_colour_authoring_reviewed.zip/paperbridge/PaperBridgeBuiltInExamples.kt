package com.example.methodmesh.modules.paperbridge

import android.content.Context
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.GZIPInputStream
import java.security.MessageDigest

/**
 * Runtime copies of the canonical demo assets kept in this module's docs/ folder.
 *
 * Module documentation files are not guaranteed to be packaged as Android assets.
 * To keep the shipped example usable without a manual import step, the exact docs
 * PDF/XLSX bytes are embedded here in compressed form and materialised into the
 * app's private files directory on demand. The docs copies remain the human-facing
 * source artifacts in the module handoff.
 */
internal object PaperBridgeBuiltInExamples {
    const val DEMO_TEMPLATE_ID = "paperbridge_designer_demo"
    const val DEMO_TEMPLATE_VERSION = "1"
    const val PAPER_FILENAME = "example_paper_form_for_designer.pdf"
    const val XLSFORM_FILENAME = "example_odk_showcase_paper_form_transcribe.xlsx"
    const val PAPER_SHA256 = "bce47af494812361fe443c6d7fdd7bd7c265a06c35755cf221396d51fd6b9a3e"
    const val XLSFORM_SHA256 = "9fb4c8614dbc25ef0ec5df069b31b8f7547746aeca7abc88b5b13a2c7c325d25"

    fun isDemo(template: PaperTemplate): Boolean =
        template.templateId == DEMO_TEMPLATE_ID && template.version == DEMO_TEMPLATE_VERSION

    fun paperSource(context: Context): PaperDesignSource {
        val file = materialise(context, PAPER_FILENAME, PAPER_GZIP_BASE64, PAPER_SHA256)
        return PaperDesignSource(
            path = file.absolutePath,
            mimeType = "application/pdf",
            displayName = "Paper Bridge example questionnaire"
        )
    }

    fun odkSchema(): PaperOdkSchema = PaperXlsFormReader.readBytes(decodeGzip(XLSFORM_GZIP_BASE64))

    fun xlsFormFile(context: Context): File = materialise(context, XLSFORM_FILENAME, XLSFORM_GZIP_BASE64, XLSFORM_SHA256)

    private fun materialise(context: Context, filename: String, encoded: String, expectedSha256: String): File {
        val dir = File(context.filesDir, "paperbridge/builtin").apply { mkdirs() }
        val file = File(dir, filename)
        val expected = decodeGzip(encoded)
        val currentMatches = file.exists() &&
            file.length() == expected.size.toLong() &&
            runCatching { sha256(file) == expectedSha256 }.getOrDefault(false)
        if (!currentMatches) {
            val temporary = File(dir, ".$filename.tmp")
            temporary.outputStream().use { it.write(expected) }
            require(sha256(temporary) == expectedSha256) { "Built-in Paper Bridge example '$filename' failed integrity check." }
            if (file.exists()) file.delete()
            require(temporary.renameTo(file)) { "Could not install Paper Bridge built-in example '$filename'." }
        }
        return file
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun decodeGzip(encoded: String): ByteArray {
        val compressed = Base64.decode(encoded, Base64.DEFAULT)
        return GZIPInputStream(ByteArrayInputStream(compressed)).use { it.readBytes() }
    }

    private val PAPER_GZIP_BASE64 =
            "H4sIALvioWoC/71a23LcuBF951fgxVX2lo0hbiSQ2tqUrrEqvkWaZCsV7wM1A424niFnOZRXyk/mIX+Q/EgaJNHAkCOt7VStVeuZPWo2+jRwGg3Qzz6cnr9i" +
            "VCbP/vPff/07YSQl9fXPyfffJ7MPTb28W9iGPN8+bJc3L5IffkhstXS/5pHZ/GFryexDsbK7ZHZS31UtYcnsz+VyR/5BJBhekp+iR8Xk0ZOiLdb1Kul9EOf7" +
            "MnpARg+c1FVrq3ZHVGc0e2uXZXFc38NIKfwooyjPVUa0ZFRro2Hk2aXd1XfNAjw7D+fgof/CSNY7OWevUpLjd0b08J0T42NxyVhc2RYGml1sIM7j4fNk+LyA" +
            "FJyek9nc3rc939ll3RatJSnwbIqqG97BIV/J7Kiq6tbl6SfHvgFqE/oqov/GVqv2luSaa2exaxtbbJJf4Id1/Pu/FxtCjufEMWSczG8Ik1SS+RtyNgc799Os" +
            "kuqRhDWW3HyXpN1vnVkiNM0zkWuiU005k5xsIowJyrTMiZA0F1JIQPLeihu0GZBFwsHKCM4jq3TsKSB+PHguYIJyKTKCnnJjRuMhskgwKsQiNoOnKb9FAhmo" +
            "EpVLqhjbIx4wH67KUyo1j4irTHkbJK6ylCrJIuJKZWNPiIRAImwIFz0hJRwvIo5RBavAxnua8BsTF4JmuVImJg7pymTGVCAu+WCFgSASEQ9WnlLwhIgIz3mM" +
            "w/SkKhWBOEz9aDxEIuLBykcePE34DcRxKUTEA+bDxUWFlHDpRcRxgQardOwpICEQxDBc9ISUcLyIOEaFGEaOnqb8OuIo9q5ocMKyrmjAwhmKBuC+vrh6IWVq" +
            "SJ6DM6nJfEOefyi2sEscN+VyZcnSbmryy53dtWVdVUXZ2Bdk/jOZfzd4cmVJU9UNkeIQlBvppoSK7g98as2FGqKajp5xmivOuuGP10X1iWy7ID7bZgfjkpsa" +
            "vpe7u2JNNsV2W1YrUlRLslsUVQVmrQuvWkWRjZNghgD1UzkQGc0UROmiuDg9eze/OL84OZpfvH835czSzuOTOeWwERujhqQ2bbkotwXsCRenkb8KXOWUSZOR" +
            "TMNEMulWEqfCCKjDjBrDNHN1/CoeRBhNtZDZ/iB/K3dlS6q7zbVt9oaQsGiU0TIMoQxV3VYxGeJL05UJRTOe9Wtm/v706O/flKUMSihLFe/cvC4+W/JQ3xEL" +
            "W21F2npZPPyRzMvFJ/L+3Rk9nDaVK6oVz9zGqDXTnTZ56mZynDYGUnF5VZpTpfO8G/Rd3d7ur57YOQiegeFX+JaaGjYs5iOyLtt2bR9xDqVapUx+jXcGiRNZ" +
            "P99X9eYRzxKKouZKf4VnqRmFqmyGuG/u1iA2W6y/aVYlFDWRiX5xXD1stm292e3N59GbN6S9LVoCel4/PDK1UDYoYzDSl9MQBkxlJrqRz+3nkRJECgtfCvE1" +
            "rgUUBiHSkW/ojVe3j4StQFSpMV8TtnLbSD+tp2XRNLe1LR6J/Mu9h8gj969tsSwWt5NC/mWyF7AA81T30nl7dnT118uzt1Arr8iMXH04O7mA//mmJcMN7PVD" +
            "HZjbDZT/or0DQh+fn3x8cTjPXBiamiyPostpKiHESSagI4JNycC2C42H0apfmSf7kWLaXFGVGnZWGIm7Prpbxlu7KDdQlq6LZlEv95WHj/A0oxyWCIMdFcpM" +
            "Dr04NIRDL371xJYpmclS2DKlhO3dEFcYTMZGW6aATX/oHsDtsGEf3dyU9z4qsi6u7bqT7wMpq10JENS3Hbmu7w9tkFQP42qhYNeGT6Vdx3X5J2CFeWWw5pRM" +
            "oWmGopXS1KUYsXXEy7EyNPu2PoAJWAKG9yXoHPb8boOH2vwH8snaLSmgJN3A6Y9crwsoIYu6cbv/pmg+7Vx7UF6vLSWnNYFTGPm1KeG0Vn927cGt3bOlh2c9" +
            "hAE9fKZUX8FP7a5cVXYJxYvYe9ssyp0l708uoem4b19Chlu7ss1LaJRgcRTrl2QH8a7tq8VtXS7A8u3lS7K5W7fldg/s+hc/ZYti65Y6PTQ/JEn+ksCREJJO" +
            "3H+HznjJj9Du7p8ZgdhwFO4OjclwaEziQ2P/xU10IvPpsTBgDEqlUlB5oFNNpYFp5tn4WOiRRQKtpuYctijEGBt7Ckg4rSCWQ3PDc0HQUQ6lYXwqTPFU6INC" +
            "DAP3jqbsok4Z+EMdJb+6LHBqJllADAqfguLS1RgFWwHwA82PsjAg0PlzKqGj5AFjcAba9xSQKAsBg0Lljj7eUQ4zn46yMCCQBR8UYhGZ3tGU3SK52rsbEFP6" +
            "AYNapaD8QKWjqXZfNONj+h4B+jkUMsliK4X0B08Bie4GAgZdnYEON3hK5Yg/IsAfo/JYxGbwNOXXLQPezX00h9KTj7DhgTVkLLLNDZ/Y5nrPVqoDyjJjrLeF" +
            "ujOxPWh6SMIKWvvJBQdiXniuWYZd1gRxhguOIGGlAMuhbwhWoKGRJ0SiCw6PeeWhIxRndL+RhvuNIahg5QNHRxN2hyWs3EF2cs3jMS88lXOq00ibURJQwQp6" +
            "Js5ZHlkpOJftO0IkvuVBrBceOkJtRklABfuYglGgMviZcBsJWGVmSh4xLzuV5bDZMxmkGd1xoYBBhZSZ7nIPrZhnj57YlH3ABtkFT16aYbwg4BBVsEI26MlM" +
            "EoACjqZQBvKI7Qktyj+f2I4ErNy5aKIrNcIGW1D2xFYesn1SwfFNncekO7hnOQ8KhvZrdHOGSKTgYOW1GTx5JL6p8xgX7gaqu8gcPMGaH42HSCThYOUjD54m" +
            "/H5Dw3s3lgMmQQsZjIYalhnVowtLj0QaDlZencGRR/YuLAcM6p/QqlP64AkOW3J0YemRIOJg5OMOjibsHlNxTB8xRY1RzAQVw84/4o9IpOLIatBn5IlN+SMG" +
            "nwCZoGLY6Mb8TeDvo4qsfOTBk5kkYKpiUFIg79e3f2CkYpZPbdnI1qt4T1tqhI1UHNvKQ7ZPttLR04ih9rBrRX1iAxGpGDtgxLBJRk+IROlEDLWHnlCfOF6k" +
            "YowKMYwcPU35/UYzHefBYyg+7FtRoOH6PcgYe2DEsE1GT4jEefAYqg89oULD9XuQMUaFGEaOnqb8Hmun4/cPiHn1YeOKCsWAIh1jExysfKOMngISvX9AzKsP" +
            "PaFCQwKCjjEqxELk3tOU36F2OtJxWOH7egsrMZ/ajnSM7XS8qswYG7XTke1BUzhg/1+HbPbEIbtKDGgUujdh4EF3MdWphXIFI3ENfwnZ34fg62rw1F+hJN0F" +
            "RRIuKMCRu/JJ9i5HPqZQBfbvRxq7KndtU7iXNqQtmpVt8YbkYwq8Dl+SDJbOwl1FJPPvXAQuO7ZaDq+nh/fYWfQe+7jY2e5F/Oy1XX+2bbkoktlZtaiX7kXN" +
            "7MeyOqp2pQeS2btiY91tUTK7urtuu/fn7i068y/Tna/olXn++w2lf7+hzNNDvTqu18svGY9/4Xj3jb2B6sTSJMU/JFPu1viGIAYLtP9NFTAlJxhjYopBUR1j" +
            "EvqlEaa5mWIynYyhYbedYBnULcRgfZdr23QZvCr/aR232WUNy1r0/+LjorqpO61e9v+8omjaLgs6F2ny7NnZ+/Pkfx0Wr7EwIwAA"

    private val XLSFORM_GZIP_BASE64 =
            "H4sIAAAAAAAC/41ZBVhUW7QeQEJppBsEJGeG7ka6u2tm6B66S0RCEKRTulNAuqSlU0mlQUmRhof3vvd88u593zvznXO+fWav/+yz1r/WXnttVQWkB/gAAAAN" +
            "8EWQ2cio4avy8V1LFBEAwL67e9qBPBxdbM0dHW2BnvZ2dRNKDiFgHOSVUt1aUG9QKtVzaLxSQ2sQ+6op8nw/RN37ssT6WU5F04DDD0KVrB8WAYaLHyqIB1CW" +
            "g/pdTLfciMtEParojtW7D6tM5mNwQH5oRPVNAxrN7uACrob0eMpxpsGuKH+3+IfjxVJ64ZbKcCnusfDkhQ8eXsBGjZluj2W2/O/mxvzfAhM9e1RMG77Zb4kB" +
            "IsspBDxBLuXPTLjUc5jHic8SPtzKBrNrrzJt9bxVEX0THi/P40n6XbHjzCSSMmRaFjt5MczaeFiV6ZNmHT7MeKgQgqZRc3NVxMSjlBUpXSqvmYALYzp5zHXV" +
            "Rtwu2v0FXfUP/VTaKQecIQAAkVgAAObf+oG7etnB4L+0s66j5jhPjXPDEn7aw2A9w1hikK8V+3Mi6adZ5YderAkEwtiPnyqzAH0/BWC2JfT2mu1nex/9fNNF" +
            "D843Kl4H1i/ovtUKG2DsCS81JJLQIll6fzSEsby4xAXfde/ImkkXnJJVdV+Cen43FFbBS6tshLrn2VaQPsznieMXnCiQt7PnYylTiY+NmvxhS5uiOvckUZ8/" +
            "0qVVDdi9CsRnuHxZj8GhiCb9EpuRwQtDGIzUtY2jchF17UfQd4sQazuGkmKTYPbZuDLEAZOMARdAsWoNZQVctVqMOOcWAcTKr1tKvcIStFsk7VBvOYs57GR6" +
            "J3OPy1DUpIynu516QpW3p81jePtvVc6GSDJYkwq7C2ddxS0D+hyjDwq0P+MvtKjqYPQ2LM3L8QpshSIJeRUHgJrt8GrS8Iqj8yb8WDjSzde0qnmRxWyli2Ze" +
            "bkn2X+NL/tht6OKFiY4eAqCAjh1S9xiyxq9hYYtklC8Yp222HgYuNWObdgawPT98y52ejHjOih/cDlBjGvA5rPEDXIPL/DeUQiMQ7QdjVHyGoh83iubDK8h5" +
            "z86ek6t/IeH91X2kQMKlk1nIMzOg4yJrk8VF/nP8UNnPNY5SP7eUaZEvib4a8YltGutNG9M6Fd/NUL/bWlma/OgzIj8XLcEQ9X514JMk8C3M3ulyeXDe5E+K" +
            "XBgi6CEhAQCf7/jx+G+KuFrB7GF/X9l/EaVVZ94lDYx/RSC9j8kLPw6F4vU5UE1YFw5g91OLReNQyr3KaN+ndkCMWuVy/4aqYD766dlmVddsw2W6VWW4s+EY" +
            "TrIOyhhOdATxJNcDg9e+x53fh7nTIzHWZXPBMjS6UFXf22uMd37KjFndOFAJu42mkVyM9VgTAjKpU365R4mSnZWPEnfYQwQVJ9O3Es3ee2OxI9sv0Yvz5wQn" +
            "oeOaqYwj1BzpX5knil5Fg9AmjWkedmJNvp8Tzm0FkAYZsqKhB9GIik06VpzwRIS/NKV3ohdVMqXAbdfliM3f5ZnQ1b/5+I2YLjic3Wk7aRmYK9XBKPEuMTdY" +
            "qY/btxSBpcjGk9pnJeUntZhZVR9GkI/j8AUCnham5SqZEfIQaiEVtdr0GAnyAsmMn+kpEl0JaVNu4KejkdrEa8DLQbQCEOT97nnbfIeBonosFeph0C7pkmTI" +
            "vmnThI0WIrN39CmLnFModHn9wLFTG5mgZlDVtORlA6a8qSYPI53ncNXP8ElFWUo+mQMKsQ8xiD8QLF9tNyO+UqWisd8WQDFaxGjkbkz2pXus2B/v+WTrtYJz" +
            "CzWfsZnEmpR0Xf4cFL2LtIsSDKsiOxbQGqxT6pQ0DRwwnBAHE0yn7nKrCKfH29/Uhu8W8BoIBsKxnnl0OuFnWZGssa6XhOF51GCNZo6Nj2O6zT3difVwqcFZ" +
            "vqqKXSnCMWLC7tQMWWf68tGmeR2XjhGIrv10K+GElR7LQsMD6uduq8LIPmoaldrS+yau2GK36QDjmXae540ZvTiYJm+hRAFfj2oe4e11Sj3LeevG3s0QK09U" +
            "JGp/7aOnoLpNFi0rxO5zRNLShZSh8a1uYSm5YFr26gklqsaiWvKWKz1XfqZ6xOpC1iVr2xpYgCk5Yh8nBZIV+0YOUyAhZKZu9Ow6x+AFNL7z84APtv3zpNVE" +
            "DVyWdYz80826r25NAkPOJ/5THXUF32bS/PFATiIog415ZzIrAVMaLKVCp9XFO6rrSqTlwjSjbbHj7kbnbmECdp8mIGmz7PxkV0E22g43CH/6DCZl4xbsrgW/" +
            "O/H/M6xambnAoBquLtYOln9FV+ROtUfd1BiAsVLZG8sFkd7Yz5nPPr97xEAYjxnTfppo7wIXJdVvpvO8ALyC7ssksHTOjvSh1rulqE0vrDGQWgabu8tILaI7" +
            "ay87xg18/xZSW7y/KtGKui6J/tq5WwfNcc0Qmbwi4M9hEe3Qx648AgCOQAAA8e/ZEG4Fg7nCQX/d/vLnfH1bx1UewmuWBwZcGmLOrApHpW6RG+tzmdaRI64N" +
            "c7QsY3j2ziyvgXL0h1hHy0R5UIMIOeX04STd0yNyoyPDiJacttvD4v5OpI1gsECQfyE6QsFDhYdGKqZMOpuSZ6vYy6LRVCS3ClBihQPNNc2oLAZwvAtn23sc" +
            "uTB0OgG7kG2N15XEoFh8it5ZIvNudnnusn6Q96LDbY5YqMSzovKGpsNK8jzP54OGN72U+2A9SxfEa7Rg9GmwWWPRbUhwETUN41j8za2seoqSKSiU+ol1xPYD" +
            "dxpZeRq9w9HBTSorZs/KsNMlFGwbT6dAbJXAF9xCC90hGnuU0wdW2KcqjT7tYafYB3sPD8QxqVowRcq+dDdgLhaFxSyh6LzV9pr0e9IpcoiVQuT3euVrbKfA" +
            "euVrqZ3gWpkOrSd+2CfHT6kQ3+YnPGakm818QbXmHkIwJNlT5+hv7aCsZmbnD3PIzKUfUfpeOfydUyK/+Dy6kf+zHfhrOENvssMw9atb4MO+4occdeKqg1Zt" +
            "3OJ7H2ND1Wj4a35Y/qRXNTSlGfs8V9lIYii6phj+nKQauu0uxKD5lUjNeOuBzZpa5WsZ4eH8iZYMEsXUxwMT/iE8ySB+uVk+Bk0XC0UW9DMdZJQkUkx1Q+LO" +
            "WcKDwii0Dk95xq8G1PI3gQ1Ecr2ywciqLONx1e1iQdA4MwRoWGdNnvUrjWwICh5RGrncAgLnQzypTrwQ9RV81oZsgrknr0lY6M/Wvb8gFCS+VRqp50OWBUh1" +
            "Uu2LlhA8ErJILuEJRBueZB8JzB2ZGsXO2AZuTq23wPktgZsL64bEGTLWBGLZhKvGjqd286DRaF/0j8zyV9CPJwoKPuVGLZPAmxjTqWTnoFyDWeBm9HrvNNIV" +
            "udpheOMh/7p5hr5ugy5xljSwImWIv2Fhi7Os3tQJA52VM5FQF0ohnJqBSuXtJJpH9xwylz7DRAhVYo+ZxnhOWcYb7ITB/aqfvJvdlz2JJTxzaiyE7F2v0xXJ" +
            "DjL7klBn9fK+u3DyttR4mHEllZAPzjgdxLCoF/FJJvQwIldq59JNsHUshGNVF8qqstqieX2YW4GKLiGnRlgtS9zXtH7wKYQl+Fiz4zAr663+oWv7e7qHn6iZ" +
            "tWSEi5J4KG6WECxmS0zmoxGrpGDz8aGUa1F3HRdfUZWIVs4fXqtNxbQ4PN0pFoVte7wI8cHeI3zKl9jyYcc7OmuF+OZ88rx97DygeTP37Oqmdv+ky3JLvITn" +
            "PT/ujn9cPKI3TkJcD6PcgXTX4aN1RFGfS2UhHHGo4pD5S69c9FtViypeXoHsmbA6nr0LMN9ONzgip2h/S1KckfySkjU2rtLDe45YThEyoP7OXsrvBSV4rgbP" +
            "indsj4rsC5EQYWgFHCNG8nNhsPoC1Q4xJIg3PNeo1/WSEkrmprXeiTSo0KNA0hPN6G/B8cTVXr2RF03aPxvFQrWUfKHU+HuyC+00Bp/T9YOfBU9qOnTs2GrA" +
            "aKjdhLmmz+L3IW5eH/NDbdQwL3OtxnL0E7yWHimRiAWpOZhjNJvhYKW9MRvDDNm6OV8KYRz99EQZolSOAhcNa16acd71WeINJZo3f6JHk+pXopSwZN8YyZEE" +
            "PZZwylCkLOuBkb+iCbzVQSk7kLS9WJiZlcnFO7/OJuORoX/k09nviOnaNeg2Y9pcUulhdynzIZMt4qMik3i6JUYuyrxbtzt5Fq0dvRUX+fl3umGwvFoc9+TO" +
            "nqkAlouMHrLeOAnclDei+YY3d3n5XQqGTUYn+UDcKp916PG2Kep+RZu9aId6emxXeq1fxg/mS49O7KnQR3YqVdTfXHdf6BIXZRWK9H6QRg6xbpESMrO2LZgB" +
            "OjlNZ/AR/4S07osFEGNN5ZFhoSBdQ8DEZyFV00HM4T7cI9OJOuZ14J3AEnpOZXACealcmHwKu/KWwJJTPa2Nlzvb7cMhPb19RKlglw8QRSqnEdc1EyPs6yF/" +
            "nXOnV49JOCMMbhw8+EgNKa+at+dtXOHz7TvMcd7U+iNbDOHA6cXSRZ8WspHKqyIqI6apZXpCGxQdheq24otJFbRqM80Vz2i9IPrl+pYXr1U7dPvLl0pZp/eC" +
            "VkMJkAuYtC8Bxupyj8h1QnDbyc8tIcKELTY+ZcaL/Q+jJGZ/8pUVeYNsBVsYuIzh2g5RzVB0RbrwXn2j1Y254IuikuwSvs+YfM9CyXY7bdH7fDQn6GyJVMML" +
            "AiF6LiVDYPFMsbc2N/iaZFzwfGhjUFj6phTxUNj8E0344z2XpcZ0ziT4nguQdVFWd7xTpWhu7f1k8mvegAXD65tthhun4+29pF2PhKcM22tlqaU7PdYyLlLP" +
            "ugbwsrxCHeRJyEpyBmazMGc2Sal1Bx6TE7H2xNc+IEjOpdBZ/UJUG6wyMtU9uaV4tqaoEiNJPJ/+9l1B6/X19SVnJV4bT7kL3WibW3teOGktbQkKyNd+3Mp6" +
            "eemErDAU+RMQPerxF7RPrAxs70yADGxiCq18wuXnGfmNQI0lNyGnn46S+Ucn6Ovu8G6Jn80dHaL7z6n71M2BLU1cuJSM1hGNwOmpyzd2zQNgbpEHGxWdRnex" +
            "8XzKcU1jmdzGiIpEYxDResa0N7RmJfVZKnvGRYXrTjt3xkVh/qT18D7rsOBKWt2VA6JvK6JrB29j2w5JbX+XsyT9BiDoRe/7IAJL5IMgaMd+ynEvd0TkTemR" +
            "xVh/WhD/++5XaFwR8+8reKK2oWY2HdGfoEEkkZYQfUxDa25PW31MZYXSydTlRvPMxnR4EpzdM+GqO+xKsvCqGRM0N9048qDKeVo394JQsTmcZ1DEdUDEt/Qb" +
            "cGb7gOu1keHfFgqrxPOawvGCvmoGCkfr61OX480yFiGf5aDwMAu4MAl4l+bkTjIc3X2B9N4JDZoBuhQxMVG4TpSe2qPiV86JuiLmih4fzAAVH4dCbcFEuTr5" +
            "scv2lCPuw+IzWpXsL+2Sk/ZJol5Ckdp9H5sp5kOcOJPspkyUGZ7uT/XaKlA+nf+4nSHYil57qvtl5rA5wFzOHEmzJyVWNnHjRRvmHHP597NdiK+C0e3wTpNn" +
            "IY9xaROwPmVS0MObyGK/umlY0lmrgAw9tMslPMBacupIG1ZP4A8LCZgSy15aDfRAzin23mzlrkTrI2d76+NI+LlHsO5Q/7l79XD6UuNkM9gn5jlWqgTqU3SK" +
            "96EbfK+hz5x2Jj53HZAZP6Zh1zHBV33jiIwrRpHsr3fWweR7YPHFqEWDrFLLk+j3mM+qmHw9v3qg8YjlC8bh0esFnRSK4OXL0l7yPuQp2Xnpn40oyFy7g5pY" +
            "8JlwT6fI/mva57My5jRdC+ndBSujd+V9zDzL6CX7Iioa44h8Ld7R09X5koLonahKBwiRZQL6GQFX65a1dq/V6reGa1LOCnhESu0YElPGBXj1iex3q+2GZx39" +
            "l8kpCopXo7rDBMhdPiSnLu/wZEePBkTNkOWezFhlkJZ7SO9+tMogK4+sP/EEp+3nXXW+NDn4BCh39COuYzVGmq219aB9u+wTGFoMwYTjz/LkLP/gR1AWd6vH" +
            "4NM2CULKGYkKB+ysIOEw510o/hD0e/UmW+ipa3n7icH6N9wqGeaOCNU3LHhxOyoAV2TGQZh46IXNgO/MFNpOztvWAQFu/f2omf8ar/JlJJHJg9LoTtQPs6GP" +
            "YlcT0jscLAEIlcr4J44DPBc6Dzrj5AYiFhMEYvoMjZBxyojjLyN3wi5HTwPOqP7MilFWrwN+IgAAZaj/mhVz/MqKMxLGHe5WuWIBPUeXEhLycdL0WjMlO0MF" +
            "1j5bkLUu5LJPbf1tclvLKrFcsN5trsyqbv4NgJyvx7JVD5ZphlT80SfoIEkyBtx68M1+8VnN19O0Zgs/qct5LcAH0vIoA16myvAdN/zGMkS2hQe24GhtZH22" +
            "fqWxxNelbOEtk+8ivm674lrTYDoSfRPx21mhSlxXDW/NyfL0RdHTfnOk16U3FUzC7CHCwTYvO/LOqmlVbUMzX0iZrxSaGSJ3/qbWbh/tZGh74RskJZ4y68Qz" +
            "XUR09/h2LDemecvhUi3W6ilhzMd6VY/n7u8znDfUM52kmTygzZwvouNeuUtbWSUJpBO28Jl0j3BffRmk/8BS1H5WhP7Nrbd1ZG5SHCeZwgy45K4bL7UaXN5m" +
            "ORbK4ncgqE6vdO71pUWHj0pvy0cer9gpN8ZBD0AptfSD1lFa+iKzmwU0jxpwvkIN2l6nf3LsWznHQvDxuJPNVq1A/Gq1+f2WFvDqxWGBrcR3EaUf+YhYpiHR" +
            "Iudc1KhuQ8aLLooZINh7UKlphooIRr/4YolOA6nGpkIj/ow2Gq3u1mSMuLeq13xpC4XGtgJBuCFU68zja/cozVkr+9FNn61aF6+ZgjW5hqrqYGE8veXPd/Fu" +
            "kK4mMvr0VlrcnVM9A+T6jGF+FpxtDn578qRoj2PUP7mijtQhUHLHFeYH/8oVzr+4Eq9mOw/G6WsfdMaoESd7qlyboFrIygYBhVQlCZP2CMybJ0LzFMyJr/ck" +
            "a9Lce8nKVJri904bbjYnF/0KyfheHw+mYiQdIyOmdMnDSjBiDI2Xv17/rJhPL7/ctqUNU+btdWzCsN1wj6drK5JDF21gS1HmzXfTr8oy0KFvc6ODfnCNz4vs" +
            "6ZNCh4HRehdB1Z77YupMrzADGjYr80pSOQ0rcONUded6sVmsCIAvs58RzdbGGVomL9FOyctzkABxInItSwN+WA4RpVCqoAr5kbWRHkzPH6QhtJ9jC3lZS3z7" +
            "nGuKi2c5uiKhdiWBJgrC9Q2zfTAyVhv5tND+7Ck/iwOjVYZ3D/q7S9S8NfxDsBIGhOuZkPLjQU/CguwFtOvNxTir/YShHwlDrnS1RGz8c/z0LIhyxlphXYrW" +
            "gtseUQ0IolICAQXH7ePYEG/+bQ9DLV0NNH/R+f0KS52DPR0W8lKJui6nirVJgo8X1/FHEXD4FKqLChWDQVxUbzYBgd/jCvVeSUl6y/fJARJO14IR7PM80rah" +
            "IbD6C/5SOVkXGgOaNzNH9Nube0ffGtr/e+EO+Mu+0yfag4x39v11ot89M3GB2cFBwF/X/eZ2IdE701K7w1zg1o4OwrTsQDAtNcwB4gi9W9ML07q5WrDx0YqK" +
            "CKnD7Mxc73rArayd4NR3Ig5wYVorV1cnARAIDrGC2ZvBgY5OMIe7fywcXezNXO+aLpYgJzOIrZklDMQBBvOAXP4nBu2fmNSaXk6w/w+io4WFNQQm5Qhxs4c5" +
            "uP4D8L0etNSaZi6WMFdhWtC9QjkttRxUmFadl5eD3QxmBubg5rXg4uOA0FKDRIRAf3yvyJ8O87hXd5vjTpngO4ch/dth/tbp/0T/S793C0blbjAx8kqp1NLL" +
            "7x+cyafeoaPbbiPfCLTHF1VT9ADzLCErsoYIajjyuEgK+UDKzPzCUZWjy915G855Gq9eph9L06GFUXRb7xy9Z2fWiIczaNNObCKRPiw1j51AZC0E36vGA3sP" +
            "MyeyBd/hqIvmpH03vYLShE2psFGIU2XfJVgM2+++USdlDOxxfQ0gbWVv7UWtjCE0uspNDvMkBcdCUTUiqxlcKdtqXeuR5CjTUu0QiNcKBtzeikEvo+h+2GTP" +
            "ve1RGOW/EDiX0MqOQ4yI0xIioo60LZFAfcyj4rxjdOlTvj4d3Eewof+QSd4YrWeN2wvkLxCKxW484f91FJW6d92bfzJ1/1he/kFQ7wIAZHBQ0sVF31+iGYde" +
            "4GDW6ts5z2lszeilRwoMnbKkbD073cX+U9N+aRiRVHeahj34u05rIOno4HpnVJNfbIEb/dLz8JtOeSR2nDAT2IAWz6dyatrm7+KtJdkgnJra5rcDdNACt0s7" +
            "Sl86E/FUeVxc+WpkUMrQ2m3bLQeV4/6w+VGFriQtWRVBXZkUgpWEpbNVT8TlkT7rxvAQAyJBvIdsOXHKarQ6VPogFRoeGO/hJ2vMORCLQlCnt4MwVVZS8eZh" +
            "f6DhEY/kxzTBrZNBZ2dR9hUsQa+nEfOLS4TTjyhya6VrMYtm5q4D37zdLw8CJiegQuXYg/asHpjuQzMnbCOJ+HWvBxVXtvi2dFhSOtYpSO3zhL86YzJ9wop4" +
            "mnEm7mP1PDWddomP2utrGP8PnFSZgyqfXVH0teQQmExGts8G1JnPa3P/0wspY0n9jZi8oyIV1tpRUW3oTxMp4Cgw52g8OQBRVQEBER/p3zeP/uvICwL8762k" +
            "+8L3d1Z+C1Mj3NtnuS96v+L+W1QS6R/r7/cB7pcffwN4oPxzMfI+wv1K4W8ELNR/rxveR7mfWf1GocP79zzrPsr9Ofc3iir+v8/Av1H+ObL/RgET/hHn77/+" +
            "fgT7LRhE9H/Fs/s49/3zN84u8T96q6oCMsqvDo/ufjF3FBT86+3/AVRAcYrgHAAA"
}
