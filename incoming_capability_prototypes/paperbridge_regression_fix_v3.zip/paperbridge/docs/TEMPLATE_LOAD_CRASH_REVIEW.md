# Template-load crash review

## Reproduced code-path defect

The Designer had two independent mechanisms that started the same template load:

1. the `OpenDocument` picker callback called `loadSource(imported)` directly;
2. `loadSource()` called `setSource(imported)`, which changed `source?.path` and triggered `LaunchedEffect(source?.path)` while `sourceBitmap` was still null;
3. that effect called `loadSource(current)` a second time.

A single file selection could therefore run two bitmap decodes and two registration/detection pipelines concurrently. On a phone this creates a large transient heap spike and can cause Android to kill the process without a recoverable Kotlin exception.

## Additional load-time memory work removed

Template selection also automatically:

- scanned the complete authoring image for AprilTag markers; and
- ran neutral printed-box detection immediately after installation.

Neither is required merely to display a new authoring template. PaperBridge's APRILTAG8 design model adds the marker border when the schema is saved/exported, while `AUTO DETECT` is the explicit analysis action.

The patched flow is now:

`pick file -> persist source -> source path changes -> one decode -> display canonical artwork`

Then, only on **AUTO DETECT**:

`colour analysis / box detection -> mapping proposals`

Ordinary opaque image templates are decoded as `RGB_565` rather than `ARGB_8888`, halving their resident pixel memory. PDFs remain ARGB because `PdfRenderer` requires a compatible render bitmap.

## UI invariant

A new schema continues to show **Choose template** and **Choose XLSForm** together on the first screen. Either may be supplied first.
