# PaperBridge Designer regression fix v3

This patch corrects two regressions introduced while addressing template/XLSForm import crashes.

## 1. New-schema setup is now symmetric

A new schema requires two independent inputs:

1. paper template (PDF/image)
2. XLSForm workbook

The setup screen remains visible until **both** inputs are ready. Either input may be selected first. Selecting the template alone must not advance to the mapping canvas or hide the XLSForm chooser.

Expected states:

- neither selected: `Choose template` + `Choose XLSForm`
- template only: `Template ✓` + `Choose XLSForm`
- XLSForm only: `Choose template` + `XLSForm ✓`
- both ready: mapping canvas opens

## 2. AUTO DETECT restored

The v2 memory mitigation changed raster image decoding from `ARGB_8888` to `RGB_565`. That is inappropriate for the designer analysis bitmap because the same bitmap is consumed by the fixed-palette colour detector and ML Kit OCR. The designer is restored to `ARGB_8888`.

The earlier re-entrant template-load fix remains: selecting a template starts only one decode pipeline. Therefore the original reason for trying `RGB_565` no longer applies.

`AUTO DETECT` retains colour-template analysis when an XLSForm is loaded. If no colour envelopes are recovered, it now falls back to the established neutral printed-box detector rather than silently yielding no mapping candidates.

## Non-regression requirements

- Selecting a template must not automatically run AUTO DETECT.
- Selecting a template must not trigger two decode/load jobs.
- Selecting either prerequisite first must leave the other chooser visible.
- The built-in colour-authoring example must remain analysable by AUTO DETECT.
- Ordinary black/white legacy templates should still get response-box candidates from AUTO DETECT.
- XLSForm choices remain collapsed in the setup UI to avoid constructing hundreds of Compose rows at import time.
