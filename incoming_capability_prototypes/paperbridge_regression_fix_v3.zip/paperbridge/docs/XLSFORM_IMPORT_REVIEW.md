# XLSForm import review — 2026-09-14

## Observed defects

1. A new schema rendered only the paper-template picker in the empty canvas. The XLSForm picker existed only in the hidden **SETUP** pane because `showSetup` defaults to `false`.
2. Workbook parsing itself succeeds on the representative full questionnaire and daily PaperBridge workbook. The failure path is downstream: after import, the mapping pane eagerly composed every field and every choice row in a normal `Column` with `verticalScroll`.
   - representative full form: 43 compatible fields / 256 choice options;
   - `Q110` alone: 78 choices.
   This creates a large synchronous Compose tree immediately after import and is a plausible phone-side ANR/crash path.
3. The import-success code selected `fields.firstOrNull()` after replacing the field state, which can still refer to the pre-import state. It now selects from `schema.fields` directly.
4. Kobo/ODK HTML labels were passed through verbatim. This inflated UI text and harmed colour-template OCR matching. Simple markup is now stripped for display/matching, and `${...}` substitutions are ignored by the OCR label normaliser.
5. `readBytes()` was called only after unbounded `InputStream.readBytes()`. The importer now bounds the source workbook at 25 MB before allocation and gives a clear non-XLSX error.

## UX change

The new-schema empty state now presents **Choose template** and **Choose XLSForm** side by side immediately. The SETUP pane remains available for later replacement/configuration but is no longer required to supply the two fundamental inputs.

## Rendering change

Imported select fields remain compact until selected. Choice rows are expanded only for the selected field. This avoids composing hundreds of choice controls immediately after XLSForm import.

## Verification performed

`PaperXlsFormReader.readBytes()` was compiled and exercised on:

- the supplied full XLSForm: 43 compatible fields, 256 total choice options;
- the generated daily PaperBridge round-trip XLSForm: 12 compatible fields, 39 total choice options.

Both parse successfully with the patched reader. Host-app Android compilation/device execution still needs to be run after inserting this module into the MethodMesh app tree.
