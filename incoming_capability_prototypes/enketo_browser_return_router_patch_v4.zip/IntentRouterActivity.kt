package com.example.methodmesh.transport.android

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/**
 * Public Android/ODK entry point for MethodMesh.
 *
 * ODK/other Android callers use the normal Activity result channel. Browser
 * deep links are different: Chrome/Enketo is not waiting for an Activity
 * result, so simply finishing this activity can expose an older MethodMesh
 * MainActivity underneath it. For BROWSABLE methodmesh:// launches we remember
 * the browser package and explicitly bring that browser back to the foreground
 * after the transient workflow completes.
 */
class IntentRouterActivity : ComponentActivity() {
    private var browserLaunch: Boolean = false
    private var browserCallerPackage: String? = null

    private val workflowLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        setResult(result.resultCode, result.data)
        if (browserLaunch) {
            returnToCallingBrowser()
        } else {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        browserLaunch = intent.action == Intent.ACTION_VIEW &&
            intent.categories?.contains(Intent.CATEGORY_BROWSABLE) == true &&
            intent.data?.scheme.equals("methodmesh", ignoreCase = true)

        if (browserLaunch) {
            // Chrome and several Android browsers include the historical
            // Browser.EXTRA_APPLICATION_ID value. getReferrer() is a useful
            // fallback and commonly has the form android-app://<package>.
            browserCallerPackage = intent
                .getStringExtra("com.android.browser.application_id")
                ?.takeIf { it.isNotBlank() }
                ?: referrer
                    ?.takeIf { it.scheme == "android-app" }
                    ?.host
                    ?.takeIf { it.isNotBlank() }
        }

        workflowLauncher.launch(
            Intent(intent).apply {
                setClass(this@IntentRouterActivity, ExternalWorkflowActivity::class.java)
            }
        )
    }

    private fun returnToCallingBrowser() {
        val caller = browserCallerPackage
        if (!caller.isNullOrBlank()) {
            val browserIntent = packageManager.getLaunchIntentForPackage(caller)
            if (browserIntent != null) {
                browserIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                        Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                )
                val relaunched = runCatching { startActivity(browserIntent) }.isSuccess
                if (relaunched) {
                    finish()
                    return
                }
            }
        }

        // Fallback for browsers that do not identify themselves. A BROWSABLE
        // MethodMesh launch is transient; putting its task behind the previous
        // task is preferable to exposing MethodMesh Home after verification.
        moveTaskToBack(true)
        finish()
    }
}
