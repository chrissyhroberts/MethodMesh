# Changelog

## 0.2.0 — speech-provider hot-switching

- Added a provider abstraction underneath the continuous meeting session.
- Added Android, ML Kit Basic and ML Kit GenAI/Advanced recognition providers.
- Added `Automatic` routing for fixed-language mode: GenAI → Basic → Android, with visible fallback.
- Kept automatic-language mode on Android 14+ language detection/switching.
- Added live engine selector and safe utterance-boundary hot-switching.
- Added per-segment recognition-engine provenance and session-level requested/last-engine/switch-count outputs.
- Added ML Kit speech model status/download handling.
- Updated presets/protocol settings and both ODK XLSForms with speech-engine input/output fields.
- Kept manual speaker attribution; no recognizer is treated as a diarisation provider.

## 0.1.0 — initial live meeting translation

- Fixed source-language → target-language live translation.
- Android 14+ automatic source-language detection/switching mode.
- Live partial/final feed, transcript controls, speaker tags, Commit lifecycle and ODK round-trip examples.
