# Live Stream Translation — dependency addition

Version 0.2.0 adds optional ML Kit streaming speech providers. The host MethodMesh app must include Google's alpha speech-recognition artifact:

```kotlin
implementation("com.google.mlkit:genai-speech-recognition:1.0.0-alpha1")
```

The module already depends on the existing MethodMesh ML Kit translation stack for text translation.

## Provider requirements

- **Android**: platform `SpeechRecognizer`; automatic language detection/switching requires Android 14+ and recognition-service support.
- **ML Kit Basic**: microphone streaming requires Android 12/API 31+.
- **ML Kit GenAI / Advanced**: currently device-limited; availability is checked at runtime with `checkStatus()` and required features are downloaded when Google reports them as downloadable.
- **Automatic**: in fixed-language mode, MethodMesh tries GenAI → Basic → Android and falls back visibly. In detect-language mode it selects Android because the ML Kit alpha API is configured with a fixed locale and does not expose Android-style language switching.

The ML Kit API is alpha. Its public contract may change, so the provider is isolated behind `LiveSpeechRecognitionProvider` rather than leaking ML Kit types into MethodMesh method contracts.
