package com.example.methodmesh.modules.textdocuments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.example.methodmesh.ui.theme.MethodMeshTheme
import kotlinx.coroutines.launch

/**
 * Android VIEW/EDIT entry point for supported text documents.
 *
 * This is an additional launch origin for the same module-owned document surface;
 * it is not the MethodMesh capability registry boundary.
 */
class DocumentActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MethodMeshTheme {
                ExternalDocumentRoute(
                    incomingUri = intent?.data,
                    incomingMime = intent?.type,
                    incomingFlags = intent?.flags ?: 0,
                    onFinish = { finish() }
                )
            }
        }
    }
}

@Composable
private fun ExternalDocumentRoute(
    incomingUri: Uri?,
    incomingMime: String?,
    incomingFlags: Int,
    onFinish: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var loaded by rememberSaveable { mutableStateOf(false) }
    var loadError by rememberSaveable { mutableStateOf<String?>(null) }
    var title by rememberSaveable { mutableStateOf("Document") }
    var formatName by rememberSaveable { mutableStateOf(DocumentFormat.TEXT.contractValue) }
    var text by rememberSaveable { mutableStateOf("") }
    var writable by rememberSaveable { mutableStateOf(false) }
    var currentUri by rememberSaveable { mutableStateOf(incomingUri?.toString()) }
    var pendingSaveAsText by rememberSaveable { mutableStateOf<String?>(null) }
    var status by rememberSaveable { mutableStateOf<String?>(null) }

    val saveAs = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uri = result.data?.data
        val body = pendingSaveAsText
        pendingSaveAsText = null
        if (uri != null && body != null) {
            DocumentIo.retainAccess(context, uri, result.data?.flags ?: 0)
            scope.launch {
                DocumentIo.write(context, uri, body).fold(
                    onSuccess = {
                        currentUri = uri.toString()
                        title = DocumentIo.displayName(context, uri) ?: title
                        text = body
                        writable = true
                        status = "Saved"
                    },
                    onFailure = { error -> status = "Save failed: ${error.message ?: "unknown error"}" }
                )
            }
        }
    }

    fun requestSaveAs(body: String) {
        pendingSaveAsText = body
        saveAs.launch(DocumentIo.createIntent(DocumentFormat.fromContract(formatName), title))
    }

    LaunchedEffect(incomingUri) {
        if (incomingUri == null) {
            loadError = "No document was supplied by the calling app."
            loaded = true
            return@LaunchedEffect
        }
        DocumentIo.retainAccess(context, incomingUri, incomingFlags)
        DocumentIo.read(context, incomingUri, incomingMime).fold(
            onSuccess = { document ->
                title = document.title
                formatName = document.format.contractValue
                text = document.text
                writable = incomingFlags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0
                currentUri = incomingUri.toString()
                loaded = true
            },
            onFailure = { error ->
                loadError = "MethodMesh could not open this document: ${error.message ?: "unknown error"}"
                loaded = true
            }
        )
    }

    if (!loaded) {
        Surface(Modifier.fillMaxSize()) {
            Text("Opening document…", modifier = Modifier.padding(24.dp))
        }
        return
    }

    if (loadError != null) {
        Surface(Modifier.fillMaxSize()) {
            androidx.compose.foundation.layout.Column(Modifier.padding(24.dp)) {
                Text("Unable to open document", style = MaterialTheme.typography.headlineSmall)
                Text(loadError.orEmpty(), modifier = Modifier.padding(top = 10.dp))
                androidx.compose.material3.Button(onClick = onFinish, modifier = Modifier.padding(top = 18.dp)) {
                    Text("Return")
                }
            }
        }
        return
    }

    DocumentSurface(
        title = title,
        initialText = text,
        format = DocumentFormat.fromContract(formatName),
        writable = writable,
        statusMessage = status,
        onClose = { onFinish() },
        onSave = { body ->
            val uri = currentUri?.let(Uri::parse)
            if (uri == null || !writable) {
                requestSaveAs(body)
            } else {
                scope.launch {
                    DocumentIo.write(context, uri, body).fold(
                        onSuccess = { text = body; status = "Saved" },
                        onFailure = { error -> status = "Save failed: ${error.message ?: "unknown error"}" }
                    )
                }
            }
        },
        onSaveAs = ::requestSaveAs
    )
}
