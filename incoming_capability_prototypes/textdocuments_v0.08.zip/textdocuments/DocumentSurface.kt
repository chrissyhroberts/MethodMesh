package com.example.methodmesh.modules.textdocuments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.TextView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon

enum class DocumentMode { RENDERED, SOURCE }

@Composable
fun DocumentSurface(
    title: String,
    initialText: String,
    format: DocumentFormat,
    writable: Boolean,
    committedText: String? = null,
    statusMessage: String? = null,
    onClose: (dirty: Boolean) -> Unit,
    onSave: (String) -> Unit,
    onSaveAs: (String) -> Unit,
    onCommit: ((String) -> Unit)? = null,
    onDone: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val androidContext = LocalContext.current
    var text by rememberSaveable(title, initialText) { mutableStateOf(initialText) }
    var savedText by rememberSaveable(title, initialText) { mutableStateOf(initialText) }
    var mode by rememberSaveable(format.contractValue) {
        mutableStateOf(if (format == DocumentFormat.MARKDOWN) DocumentMode.RENDERED else DocumentMode.SOURCE)
    }
    var menuOpen by rememberSaveable { mutableStateOf(false) }
    var findOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var closePrompt by rememberSaveable { mutableStateOf(false) }

    val dirty = text != savedText
    val changedSinceCommit = committedText != null && text != committedText

    fun requestClose() {
        if (dirty) closePrompt = true else onClose(false)
    }

    BackHandler { requestClose() }

    Surface(
        modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .imePadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 8.dp, end = 14.dp, top = 12.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = ::requestClose) { Text("Close") }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                    Text(
                        format.label + when {
                            committedText != null && changedSinceCommit -> " · changed since Commit"
                            committedText != null -> " · committed"
                            dirty -> " · unsaved"
                            else -> ""
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (mode == DocumentMode.RENDERED) {
                    MarkdownDocument(text, Modifier.fillMaxSize())
                } else {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .verticalScroll(rememberScrollState()),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            fontFamily = FontFamily.Monospace
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary)
                    )
                }

                Column(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        if (format == DocumentFormat.MARKDOWN) {
                            DropdownMenuItem(
                                text = { Text(if (mode == DocumentMode.RENDERED) "Edit source" else "Preview") },
                                onClick = {
                                    mode = if (mode == DocumentMode.RENDERED) DocumentMode.SOURCE else DocumentMode.RENDERED
                                    menuOpen = false
                                }
                            )
                        }
                        DropdownMenuItem(text = { Text("Find") }, onClick = { findOpen = true; menuOpen = false })
                        DropdownMenuItem(text = { Text("Copy all") }, onClick = {
                            copyText(androidContext, title, text); menuOpen = false
                        })
                        if (writable) {
                            DropdownMenuItem(text = { Text("Save") }, onClick = {
                                onSave(text); menuOpen = false
                            })
                        }
                        DropdownMenuItem(text = { Text("Save as…") }, onClick = {
                            onSaveAs(text); menuOpen = false
                        })
                    }
                    FloatingActionButton(onClick = { menuOpen = true }, modifier = Modifier.size(48.dp)) {
                        Text("⋮", style = MaterialTheme.typography.titleLarge)
                    }
                }
            }

            if (findOpen) {
                val count = remember(query, text) {
                    if (query.isBlank()) 0 else Regex(Regex.escape(query), RegexOption.IGNORE_CASE).findAll(text).count()
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        decorationBox = { inner ->
                            if (query.isBlank()) Text("Find…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            inner()
                        }
                    )
                    Text(if (query.isBlank()) "" else "$count", modifier = Modifier.padding(horizontal = 8.dp))
                    TextButton(onClick = { findOpen = false }) { Text("Close") }
                }
            }

            statusMessage?.takeIf { it.isNotBlank() }?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            if (onCommit != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (committedText == null || changedSinceCommit) {
                        Button(onClick = { onCommit(text) }, modifier = Modifier.weight(1f)) { Text("Commit") }
                    } else {
                        OutlinedButton(onClick = { copyText(androidContext, title, committedText) }) { Text("Copy") }
                        if (onDone != null) Button(onClick = onDone, modifier = Modifier.weight(1f)) { Text("Done") }
                    }
                }
            }
        }
    }

    if (closePrompt) {
        AlertDialog(
            onDismissRequest = { closePrompt = false },
            title = { Text("Unsaved changes") },
            text = { Text("Save your working document before closing?") },
            confirmButton = {
                TextButton(onClick = {
                    closePrompt = false
                    if (writable) {
                        onSave(text)
                    } else {
                        onSaveAs(text)
                    }
                }) { Text(if (writable) "Save" else "Save as…") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { closePrompt = false }) { Text("Cancel") }
                    TextButton(onClick = { closePrompt = false; onClose(true) }) { Text("Discard") }
                }
            }
        )
    }
}

@Composable
private fun MarkdownDocument(markdown: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val markwon = remember(context) { Markwon.create(context) }
    AndroidView(
        factory = { viewContext: Context ->
            TextView(viewContext).apply {
                textSize = 17f
                setLineSpacing(0f, 1.18f)
                setTextIsSelectable(true)
            }
        },
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 10.dp),
        update = { view: TextView -> markwon.setMarkdown(view, markdown) }
    )
}

private fun copyText(context: Context, label: String, text: String) {
    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
        .setPrimaryClip(ClipData.newPlainText(label, text))
}
