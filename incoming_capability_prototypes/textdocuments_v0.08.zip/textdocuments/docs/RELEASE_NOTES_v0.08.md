# Text documents v0.08

Compile repair over v0.07.

- removes the two leftover `verticalScroll(rememberScrollState())` calls from the internal capability workspace;
- keeps that workspace deliberately non-scrollable because the MethodMesh capability host owns scrolling;
- preserves the v0.07 runtime-layout repair and all Master Book conformance work.
