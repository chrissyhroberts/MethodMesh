package com.example.methodmesh.modules.textdocuments

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

data class RecentTextDocument(
    val uri: String,
    val title: String,
    val mimeType: String,
    val openedAt: Long
)

class TextDocumentRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("textdocuments_recent_v1", Context.MODE_PRIVATE)

    fun recent(): List<RecentTextDocument> = runCatching {
        val array = JSONArray(prefs.getString("items", "[]").orEmpty())
        (0 until array.length()).mapNotNull { index ->
            array.optJSONObject(index)?.let { item ->
                RecentTextDocument(
                    uri = item.optString("uri"),
                    title = item.optString("title"),
                    mimeType = item.optString("mime"),
                    openedAt = item.optLong("openedAt")
                )
            }
        }.filter { it.uri.isNotBlank() }.sortedByDescending { it.openedAt }
    }.getOrDefault(emptyList())

    fun remember(uri: Uri, title: String, mimeType: String) {
        val next = listOf(RecentTextDocument(uri.toString(), title, mimeType, System.currentTimeMillis())) +
            recent().filterNot { it.uri == uri.toString() }
        val array = JSONArray()
        next.take(20).forEach { document ->
            array.put(
                JSONObject()
                    .put("uri", document.uri)
                    .put("title", document.title)
                    .put("mime", document.mimeType)
                    .put("openedAt", document.openedAt)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }

    fun forget(uri: String) {
        val array = JSONArray()
        recent().filterNot { it.uri == uri }.forEach { document ->
            array.put(
                JSONObject()
                    .put("uri", document.uri)
                    .put("title", document.title)
                    .put("mime", document.mimeType)
                    .put("openedAt", document.openedAt)
            )
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
