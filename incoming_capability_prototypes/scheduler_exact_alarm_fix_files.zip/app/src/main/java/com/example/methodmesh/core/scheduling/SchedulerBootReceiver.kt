package com.example.methodmesh.core.scheduling

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.AlarmManager

/** Re-arms persisted schedules after boot and system-clock changes. */
class SchedulerBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                SchedulerRepository.rescheduleAll(context)
                SchedulePlanRuntime.rescheduleAll(context)
            }
        }
        if (intent.action == "android.intent.action.TIME_SET" || intent.action == "android.intent.action.TIMEZONE_CHANGED") {
            SchedulerRepository.rescheduleAll(context)
            SchedulePlanRuntime.rescheduleAll(context)
        }
    }
}
