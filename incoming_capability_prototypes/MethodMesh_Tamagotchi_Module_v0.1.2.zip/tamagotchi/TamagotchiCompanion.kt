package com.example.methodmesh.modules.tamagotchi

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.core.app.NotificationCompat
import androidx.fragment.app.FragmentActivity
import com.example.methodmesh.core.methodmesh.InvocationContext
import com.example.methodmesh.transport.ReturnMode
import com.example.methodmesh.transport.workflow.ExternalActionRequest
import com.example.methodmesh.transport.workflow.ExternalWorkflowRequest
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.ui.theme.MethodMeshTheme
import kotlin.math.abs

object TamagotchiCompanionController {
    fun canDraw(context: Context) = Settings.canDrawOverlays(context)

    fun requestPermission(activity: Activity): Result<Unit> = runCatching {
        activity.startActivity(Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${activity.packageName}")
        ))
    }

    fun start(context: Context, sessionId: String): Result<Unit> = runCatching {
        require(sessionId.isNotBlank()) { "No Tamagotchi session is available for Companion Mode." }
        require(Settings.canDrawOverlays(context)) { "Display over other apps permission has not been granted." }
        val intent = Intent(context, TamagotchiCompanionService::class.java).putExtra("session_id", sessionId)
        check(context.packageManager.resolveService(intent, 0) != null) {
            "Companion Mode is not installed in the app manifest. Merge docs/AndroidManifest.fragment.xml first."
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
        Unit
    }

    fun stop(context: Context): Result<Unit> = runCatching {
        context.stopService(Intent(context, TamagotchiCompanionService::class.java))
        Unit
    }
}

class TamagotchiCompanionService : Service() {
    private lateinit var windowManager: WindowManager
    private var sprite: TamagotchiSpriteView? = null
    private var params: WindowManager.LayoutParams? = null
    private var sessionId: String = ""

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WindowManager::class.java)
        if (runCatching { startForeground(41873, foregroundNotification()) }.isFailure) {
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        sessionId = intent?.getStringExtra("session_id") ?: TamagotchiStore(this).activeSessionId().orEmpty()
        if (sessionId.isBlank() || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val shown = runCatching { showSprite() }.getOrDefault(false)
        if (!shown) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        sprite?.let { runCatching { windowManager.removeView(it) } }
        sprite = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun showSprite(): Boolean {
        sprite?.let { old -> runCatching { windowManager.removeView(old) } }
        val store = TamagotchiStore(this)
        val session = store.loadAndAdvance(sessionId) ?: return false
        val creature = TamagotchiCatalog.creature(session.creatureId)
        val scenario = TamagotchiCatalog.scenario(session.scenarioId)
        val prefs = getSharedPreferences("methodmesh_tamagotchi_companion", MODE_PRIVATE)
        val p = WindowManager.LayoutParams(
            dp(108),
            dp(118),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", 24)
            y = prefs.getInt("y", 360)
        }
        params = p
        val view = TamagotchiSpriteView(this, creature, TamagotchiEngine.phenotype(session, scenario, creature))
        view.onClickSprite = {
            runCatching {
                val open = Intent(this, TamagotchiCompanionActivity::class.java)
                    .putExtra("session_id", sessionId)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                check(packageManager.resolveActivity(open, 0) != null) {
                    "Tamagotchi companion activity is not declared in the app manifest."
                }
                startActivity(open)
            }
        }
        view.onDrag = { dx, dy ->
            val lp = params
            if (lp != null) {
                lp.x += dx.toInt()
                lp.y += dy.toInt()
                runCatching { windowManager.updateViewLayout(view, lp) }
                prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
            }
        }
        val added = runCatching { windowManager.addView(view, p) }.isSuccess
        if (added) sprite = view
        return added
    }

    private fun foregroundNotification(): android.app.Notification {
        val channelId = "tamagotchi_companion"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(NotificationChannel(channelId, "Tamagotchi companion", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Keeps the optional Tamagotchi companion sprite available"
                setSound(null, null)
            })
        }
        val open = PendingIntent.getActivity(
            this, 41874,
            Intent(this, TamagotchiCompanionActivity::class.java).putExtra("session_id", sessionId),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.btn_star_big_on)
            .setContentTitle("Tamagotchi companion")
            .setContentText("Your creature can sit quietly on screen.")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}

private class TamagotchiSpriteView(
    context: Context,
    private val creature: CreatureDefinition,
    private val phenotype: Phenotype
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prefs = context.getSharedPreferences("methodmesh_tamagotchi_companion", Context.MODE_PRIVATE)
    var onClickSprite: (() -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragged = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX; downY = event.rawY; lastX = event.rawX; lastY = event.rawY; dragged = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - lastX
                val dy = event.rawY - lastY
                if (abs(event.rawX - downX) + abs(event.rawY - downY) > 8f) dragged = true
                if (dragged) onDrag?.invoke(dx, dy)
                lastX = event.rawX; lastY = event.rawY
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragged) onClickSprite?.invoke()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        paint.color = Color.argb(42, 0, 0, 0)
        canvas.drawOval(RectF(w * .20f, h * .82f, w * .82f, h * .95f), paint)
        paint.color = creature.bodyHue.toInt()
        canvas.drawOval(RectF(w * .16f, h * .24f, w * .84f, h * .84f), paint)
        paint.color = creature.accentHue.toInt()
        when (creature.id) {
            "mossbit" -> {
                val leaf = Path().apply { moveTo(w*.28f,h*.34f); quadTo(w*.04f,h*.08f,w*.42f,h*.18f); close() }
                canvas.drawPath(leaf, paint)
                val leaf2 = Path().apply { moveTo(w*.72f,h*.34f); quadTo(w*.96f,h*.08f,w*.58f,h*.18f); close() }
                canvas.drawPath(leaf2, paint)
            }
            "nib" -> repeat(5) { i -> canvas.drawCircle(w*(.24f+i*.13f), h*.29f, w*.06f, paint) }
            "pip" -> {
                canvas.drawOval(RectF(w*.22f,h*.02f,w*.38f,h*.40f), paint)
                canvas.drawOval(RectF(w*.62f,h*.02f,w*.78f,h*.40f), paint)
            }
            "sprig" -> {
                canvas.drawOval(RectF(w*.34f,h*.08f,w*.50f,h*.34f), paint)
                canvas.drawOval(RectF(w*.50f,h*.08f,w*.66f,h*.34f), paint)
            }
        }
        paint.color = Color.rgb(52,45,55)
        val eyeY = h * .48f
        if (phenotype.sleeping) {
            paint.strokeWidth = w*.025f; paint.style = Paint.Style.STROKE
            canvas.drawArc(RectF(w*.31f,eyeY,w*.43f,eyeY+h*.06f), 0f, 180f, false, paint)
            canvas.drawArc(RectF(w*.57f,eyeY,w*.69f,eyeY+h*.06f), 0f, 180f, false, paint)
            paint.style = Paint.Style.FILL
        } else {
            canvas.drawCircle(w*.37f, eyeY, w*.026f, paint)
            canvas.drawCircle(w*.63f, eyeY, w*.026f, paint)
        }
        paint.strokeWidth = w*.018f; paint.style = Paint.Style.STROKE
        val mouth = RectF(w*.43f,h*.57f,w*.57f,h*.67f)
        canvas.drawArc(mouth, if (phenotype.unwell) 180f else 0f, 180f, false, paint)
        paint.style = Paint.Style.FILL
        if (creature.id == "mossbit" && phenotype.mood > 65) {
            paint.color = Color.rgb(116,100,80)
            canvas.drawCircle(w*.79f,h*.71f,w*.055f,paint)
            paint.color = Color.rgb(240,224,190)
            canvas.drawCircle(w*.79f,h*.71f,w*.018f,paint)
        }
    }
}

class TamagotchiCompanionActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionId = intent.getStringExtra("session_id") ?: TamagotchiStore(this).activeSessionId().orEmpty()
        val action = ExternalActionRequest(
            requestedId = As100TamagotchiSessionMethod.ID,
            canonicalId = As100TamagotchiSessionMethod.ID,
            settings = if (sessionId.isBlank()) emptyMap() else mapOf("session_id" to sessionId)
        )
        val request = ExternalWorkflowRequest(
            actions = listOf(action),
            invocationContext = InvocationContext(caller = "tamagotchi_companion"),
            returns = emptyList(),
            returnMode = ReturnMode.Json,
            settings = action.settings,
            source = "dashboard"
        )
        setContent {
            MethodMeshTheme {
                TamagotchiSessionCapabilityScreen.Render(
                    context = CapabilityScreenContext(action, request, 1, 1),
                    onBack = { finish() },
                    onConfirmed = { finish() },
                    onCancel = { finish() }
                )
            }
        }
    }
}
