# Tamagotchi Lab validation notes

Module revision: **0.1.2**.

## Completed checks

- Reviewed against the current MethodMesh `MethodMeshModule` self-contained module contract.
- Canonical capability IDs are unique within this module.
- Dashboard composition is separate from canonical capability exposure.
- Persistent session history uses the current MethodMesh appendable persistent artifact boundary.
- Pure Kotlin model/catalog/simulation engine compiled successfully with minimal `org.json` stubs on 2026-09-08; this catches Kotlin/JVM syntax/type errors in the deterministic simulation core.
- Procedural generation uses a stored numeric seed and records generated option parameters to latent history.
- Care-visible state and latent state are separated.
- `analyse` and latent export remain locked until the care period is ended.
- Notification suppression reasons are represented as explicit ledger events.
- Companion Mode is optional and has no effect on core session persistence.
- v0.1.2 hardening: canonical screens keep live working results in-place (`capturedResult = null`) and expose explicit Commit rather than falling into the legacy generic result-screen flow.
- v0.1.2 hardening: missing/stale session IDs, invalid interventions/measurements, export failures and care-dashboard mutations are caught and shown as in-place errors rather than escaping as app-process exceptions.
- v0.1.2 hardening: Companion Mode checks manifest service availability before launch and catches overlay/service/window failures. Notification scheduling/receiver work is also failure-contained.
- XLSForm workbook was created with `survey`, `choices`, and `settings` sheets and checked for workbook formula-error tokens.

## Host integration not executable in this isolated module package

A complete `:app:compileDebugKotlin` was not run here because the full MethodMesh Android source/dependency tree is not mounted in this execution environment and outbound Git clone is unavailable. The module was therefore checked against current repository interfaces retrieved from the linked GitHub repository plus the pure-engine Kotlin compile above.

Before release, run at app root:

```text
./gradlew :app:compileDebugKotlin
./gradlew test
```

Also validate the XLSForm with the project's normal ODK/XLSForm validation path.

## Required app-level integration

`docs/AndroidManifest.fragment.xml` must be merged for:

- `TamagotchiCompanionActivity`
- `TamagotchiCompanionService`
- `TamagotchiReminderReceiver`
- overlay / notification / foreground-service permissions

If the build's `methodmesh_module_index` is generated separately, include the line from `docs/module_index_entry.txt`.

## v0.1.2 static hardening checks

Performed after the interaction/crash report:

- no `session!!` / `!!` remains in module Kotlin;
- no canonical screen passes a non-null live value into `CapabilityScreenScaffold.capturedResult`;
- intervention, observation, measurement, manual advance, session end and export UI paths wrap runtime/state failures and surface messages in-place;
- Companion Mode verifies its service is resolvable before launch and contains service/window/activity failures;
- reminder scheduler and receiver failures are contained rather than allowed to escape onto the app process;
- pure `TamagotchiModels.kt` + `TamagotchiCatalog.kt` + `TamagotchiEngine.kt` compile: **PASS** with minimal `org.json` stubs after v0.1.2 changes.
