# Text tools

Status: **Development**

Offline transformations for short or medium text payloads.

## Capabilities

- `text.tools` — upper/lower/title case, trim, whitespace cleanup, find/replace, line sorting/deduplication/reversal, counts, line-oriented diff, regex test and regex extraction.

## Android intent

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='text.tools',input_operation='whitespace_cleanup',input_text='  hello    world  ',return_mode='flat')
```

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='text.tools',input_operation='regex_extract',input_text='A12 B34',input_pattern='[A-Z](\\d+)',return_mode='flat')
```

## Inputs

- `input_operation` — required operation selector.
- `input_text` — main runtime text.
- `input_text2` — comparison text for `diff`.
- `input_find`, `input_replace` — literal find/replace strings.
- `input_pattern` — Kotlin/JVM regular expression for `regex_test` or `regex_extract`.

## Outputs

Core outputs:

- `texttool_output`
- `texttool_matches_json`
- `texttool_word_count`
- `texttool_character_count`
- `texttool_line_count`
- `texttool_changed`

Audit-priority outputs:

- `texttool_status`
- `texttool_error`

Full metadata:

- `texttool_metadata_json`

## ODK example

`example_odk_text.tools.xlsx` demonstrates runtime text cleanup and return of transformed text plus counts.

## Permissions and offline behaviour

No permissions, no files and no network access are required.

## Known limitations

- Diff is a deliberately lightweight line-by-line comparison, not a minimal edit/Myers diff implementation.
- Regex execution uses the JVM regex engine; pathological regular expressions can still be computationally expensive.
