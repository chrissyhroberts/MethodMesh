package com.example.methodmesh.modules.texttools

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.*

object TextToolsCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100TextToolsMethod.ID
    override val title = "Text tools"
    override val description = "Offline text transformations and inspection."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        var operation by rememberSaveable { mutableStateOf(context.action.settings["operation"] ?: context.action.settings["input_operation"] ?: "trim") }
        var text by rememberSaveable { mutableStateOf(context.action.settings["text"] ?: context.action.settings["input_text"] ?: "") }
        var text2 by rememberSaveable { mutableStateOf(context.action.settings["text2"] ?: context.action.settings["input_text2"] ?: "") }
        var find by rememberSaveable { mutableStateOf(context.action.settings["find"] ?: context.action.settings["input_find"] ?: "") }
        var replace by rememberSaveable { mutableStateOf(context.action.settings["replace"] ?: context.action.settings["input_replace"] ?: "") }
        var pattern by rememberSaveable { mutableStateOf(context.action.settings["pattern"] ?: context.action.settings["input_pattern"] ?: "") }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        var launched by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }

        fun run() {
            val settings = mapOf("operation" to operation, "text" to text, "text2" to text2, "find" to find, "replace" to replace, "pattern" to pattern)
            val request = As100TextToolsMethod.request(capabilityId, context.request.invocationContext.asMap(capabilityId) + context.action.settings + settings, emptyList(), emptyList())
            result = As100TextToolsMethod.result(request, As100TextToolsMethod.transform(settings), context.request.invocationContext)
            if (context.submitsImmediately) result?.let(onConfirmed)
        }
        LaunchedEffect(operation, text, text2, find, replace, pattern) { context.onSettingsChanged(mapOf("operation" to operation, "text" to text, "text2" to text2, "find" to find, "replace" to replace, "pattern" to pattern)) }
        LaunchedEffect(context.presentationMode) { if (context.presentationMode == CapabilityPresentationMode.IntentLaunch && !launched) { launched = true; run() } }

        CapabilityScreenScaffold(title, capabilityId, context, context.stepNumber > 1, result, result?.let { OutputFormatter.fields(it, false) }.orEmpty(), onBack, { run() }, { result?.let(onConfirmed) }, onCancel) {
            if (context.settingShouldBeShown("operation")) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    listOf("uppercase", "lowercase", "titlecase", "trim", "whitespace_cleanup", "find_replace", "sort_lines", "deduplicate_lines", "reverse_lines", "count", "diff", "regex_test", "regex_extract").forEach { op ->
                        FilterChip(operation == op, { operation = op }, { Text(op.replace('_', ' ')) }, modifier = Modifier.padding(2.dp))
                    }
                }
            } else {
                Text("Operation: ${operation.replace('_', ' ')}", style = MaterialTheme.typography.bodySmall)
            }
            if (context.settingShouldBeShown("text")) {
                OutlinedTextField(text, { text = it }, label = { Text("Text") }, modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp), minLines = 5)
            }
            when (operation) {
                "find_replace" -> {
                    if (context.settingShouldBeShown("find")) OutlinedTextField(find, { find = it }, label = { Text("Find") }, modifier = Modifier.fillMaxWidth())
                    if (context.settingShouldBeShown("replace")) OutlinedTextField(replace, { replace = it }, label = { Text("Replace") }, modifier = Modifier.fillMaxWidth())
                }
                "diff" -> if (context.settingShouldBeShown("text2")) OutlinedTextField(text2, { text2 = it }, label = { Text("Comparison text") }, modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), minLines = 4)
                "regex_test", "regex_extract" -> if (context.settingShouldBeShown("pattern")) OutlinedTextField(pattern, { pattern = it }, label = { Text("Regular expression") }, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(8.dp)); Button(onClick = ::run, modifier = Modifier.fillMaxWidth()) { Text("Run") }
        }
    }
}
