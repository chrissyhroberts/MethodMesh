package com.example.methodmesh.modules.texttools

import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.core.methodmesh.withInvocationContext
import com.example.methodmesh.settings.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object TextToolsFields {
    const val STATUS = "texttool_status"
    const val OUTPUT = "texttool_output"
    const val MATCHES_JSON = "texttool_matches_json"
    const val WORD_COUNT = "texttool_word_count"
    const val CHARACTER_COUNT = "texttool_character_count"
    const val LINE_COUNT = "texttool_line_count"
    const val CHANGED = "texttool_changed"
    const val METADATA_JSON = "texttool_metadata_json"
    const val ERROR = "texttool_error"
    val outputs = listOf(STATUS, OUTPUT, MATCHES_JSON, WORD_COUNT, CHARACTER_COUNT, LINE_COUNT, CHANGED, METADATA_JSON, ERROR)
}

object As100TextToolsMethod : As100Method {
    const val ID = "text.tools"
    private const val VERSION = "0.1.0"
    override val id = ID
    override val ref = ArchitectureRef(ArchitectureId(ID), "Method", "Text tools")
    override val descriptor = MethodDescriptor(
        id = ArchitectureId(ID), methodType = MethodObjectType.Calculation,
        name = "Text tools", version = VERSION,
        description = "Offline text cleanup, line operations, counts, diff and regular-expression tools.",
        outputs = TextToolsFields.outputs, graphOutputs = listOf(ID),
        parameters = mapOf("category" to "Text", "status" to "Development")
    )
    override val contract = MethodContract(method = ref, producedKnowledgeTypes = listOf(KnowledgeObjectType.Observation), producedFields = descriptor.outputs, producedGraphOutputs = descriptor.graphOutputs)
    override fun request(action: String, context: Map<String, String>, signals: List<Signal>, inputs: List<ArchitectureRef>) = As100ExecutionEngine.request(action = action, method = ref, context = context, signals = signals, inputs = inputs)
    override fun execute(request: ExecutionRequest, settingsState: SettingsState?, transport: String?): ExecutionResult = result(request, transform(request.context), InvocationContext.from(request.context))

    fun transform(settings: Map<String, String>): Map<String, String> = runCatching {
        val operation = settings.value("operation") ?: "trim"
        val input = settings.value("text").orEmpty()
        val second = settings.value("text2").orEmpty()
        val find = settings.value("find").orEmpty()
        val replace = settings.value("replace").orEmpty()
        val pattern = settings.value("pattern").orEmpty()
        var matches = JSONArray()
        val output = when (operation) {
            "uppercase" -> input.uppercase(Locale.ROOT)
            "lowercase" -> input.lowercase(Locale.ROOT)
            "titlecase" -> titleCase(input)
            "trim" -> input.trim()
            "whitespace_cleanup" -> input.lines().joinToString("\n") { it.trim().replace(Regex("[\\t ]+"), " ") }.trim()
            "find_replace" -> if (find.isEmpty()) input else input.replace(find, replace)
            "sort_lines" -> input.lines().sorted().joinToString("\n")
            "deduplicate_lines" -> input.lines().distinct().joinToString("\n")
            "reverse_lines" -> input.lines().reversed().joinToString("\n")
            "count" -> input
            "diff" -> simpleDiff(input, second)
            "regex_test" -> {
                val regex = Regex(pattern)
                matches = JSONArray(regex.findAll(input).map { it.value }.toList())
                if (matches.length() > 0) "true" else "false"
            }
            "regex_extract" -> {
                val regex = Regex(pattern)
                val found = regex.findAll(input).map { match -> match.groupValues.drop(1).firstOrNull().takeUnless { it.isNullOrEmpty() } ?: match.value }.toList()
                matches = JSONArray(found)
                found.joinToString("\n")
            }
            else -> error("Unsupported text operation: $operation")
        }
        val words = if (output.isBlank()) 0 else output.trim().split(Regex("\\s+")).size
        val lines = if (output.isEmpty()) 0 else output.lines().size
        val metadata = JSONObject().apply { put("operation", operation); put("offline", true); put("input_characters", input.length); put("output_characters", output.length) }
        linkedMapOf(
            TextToolsFields.STATUS to "succeeded", TextToolsFields.OUTPUT to output, TextToolsFields.MATCHES_JSON to matches.toString(),
            TextToolsFields.WORD_COUNT to words.toString(), TextToolsFields.CHARACTER_COUNT to output.length.toString(), TextToolsFields.LINE_COUNT to lines.toString(),
            TextToolsFields.CHANGED to (output != input).toString(), TextToolsFields.METADATA_JSON to metadata.toString(), TextToolsFields.ERROR to ""
        )
    }.getOrElse { linkedMapOf(TextToolsFields.STATUS to "failed", TextToolsFields.OUTPUT to "", TextToolsFields.MATCHES_JSON to "[]", TextToolsFields.WORD_COUNT to "0", TextToolsFields.CHARACTER_COUNT to "0", TextToolsFields.LINE_COUNT to "0", TextToolsFields.CHANGED to "false", TextToolsFields.METADATA_JSON to "{}", TextToolsFields.ERROR to (it.message ?: "Text operation failed.")) }

    private fun titleCase(input: String): String = buildString {
        var startWord = true
        input.lowercase(Locale.ROOT).forEach { c ->
            if (startWord && c.isLetter()) {
                append(c.titlecaseChar())
                startWord = false
            } else {
                append(c)
                if (c.isLetterOrDigit()) startWord = false
            }
            if (c.isWhitespace()) startWord = true
        }
    }

    private fun simpleDiff(a: String, b: String): String {
        val left = a.lines(); val right = b.lines(); val max = maxOf(left.size, right.size)
        return buildString {
            for (i in 0 until max) {
                val l = left.getOrNull(i); val r = right.getOrNull(i)
                when {
                    l == r && l != null -> append("  ").append(l).append('\n')
                    l != null && r != null -> { append("- ").append(l).append('\n'); append("+ ").append(r).append('\n') }
                    l != null -> append("- ").append(l).append('\n')
                    r != null -> append("+ ").append(r).append('\n')
                }
            }
        }.trimEnd()
    }

    fun result(request: ExecutionRequest, values: Map<String, String>, invocation: InvocationContext?): ExecutionResult {
        val ok = values[TextToolsFields.STATUS] == "succeeded"
        val observation = Observation(phenomenon = ID, subject = null, values = values, temporalContext = request.temporalContext, provenance = ProvenanceContext("methodmesh.texttools", ID, VERSION))
        val transformation = Transformation(action = ID, method = ref, outputs = listOf(ArchitectureRef(observation.id, observation.objectType, observation.phenomenon)), status = if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, temporalContext = request.temporalContext, provenance = ProvenanceContext("methodmesh.texttools", ID, VERSION))
        return As100ExecutionEngine.complete(request, if (ok) TransformationStatus.Succeeded else TransformationStatus.Failed, observations = listOf(observation), transformations = listOf(transformation), diagnostics = if (ok) emptyMap() else mapOf(TextToolsFields.ERROR to values[TextToolsFields.ERROR].orEmpty())).withInvocationContext(invocation)
    }
    private fun Map<String, String>.value(key: String) = (this[key] ?: this["input_$key"])?.takeIf { it.isNotBlank() }
}
