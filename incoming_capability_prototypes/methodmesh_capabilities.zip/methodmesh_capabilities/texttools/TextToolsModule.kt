package com.example.methodmesh.modules.texttools

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object TextToolsModule : MethodMeshModule {
    override val moduleId = "texttools"
    override val displayName = "Text tools"
    override val summary = "Case conversion, cleanup, line operations, counts, diff and regex testing/extraction."
    override val iconKey = "text"
    override fun as100Methods() = listOf(As100TextToolsMethod)
    override fun rilBindings() = listOf(RilBinding("transform text", As100TextToolsMethod.ID, "Run an offline text operation"))
    override fun capabilityScreens() = listOf(TextToolsCapabilityScreen)
    override fun capabilitySettings() = mapOf(
        As100TextToolsMethod.ID to listOf(
            MethodSetting.ChoiceSetting("operation", "Operation", defaultValue = "trim", choices = listOf("uppercase", "lowercase", "titlecase", "trim", "whitespace_cleanup", "find_replace", "sort_lines", "deduplicate_lines", "reverse_lines", "count", "diff", "regex_test", "regex_extract")),
            MethodSetting.TextSetting("text", "Text", defaultValue = ""),
            MethodSetting.TextSetting("text2", "Comparison text", defaultValue = ""),
            MethodSetting.TextSetting("find", "Find", defaultValue = ""),
            MethodSetting.TextSetting("replace", "Replace", defaultValue = ""),
            MethodSetting.TextSetting("pattern", "Regular expression", defaultValue = "")
        )
    )
}
