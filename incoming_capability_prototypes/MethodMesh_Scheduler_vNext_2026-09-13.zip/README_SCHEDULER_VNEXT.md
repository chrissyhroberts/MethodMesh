# MethodMesh Scheduler vNext

This bundle is a replacement set for the current scheduler work. It preserves the fixes already made in this thread and adds first-class recurrence types.

## User-facing schedule patterns

- **Once** — run once when the schedule starts.
- **Interval** — repeat by elapsed time from the start trigger. `Run immediately` is on by default, so `every 1 hour` started at 16:20 runs at 16:20, 17:20, 18:20…
- **Daily**
  - **From start time** — calendar-day recurrence anchored to the trigger. Started at 16:20, it runs immediately at 16:20 and then 16:20 local time each following day, preserving local wall-clock time across DST.
  - **Fixed times** — one or more explicit local times each day.
- **Weekly** — selected weekdays, with per-day time overrides.
- **Monthly** — chosen day of month and activity time. Shorter months use their final day.
- **Day sequence** — existing Day 1 / 2 / 3 / … schedule painting.
- **Cron** — advanced five-field calendar rule per activity.

## Start and end behaviour

Starts:
- Manual trigger
- Start now
- On date/time

Ends:
- After duration
- After N occurrences
- Forever

Once schedules naturally end after their one occurrence per activity.

## Important behaviour retained

- Exact-alarm permission and exact Android alarm scheduling.
- High-priority lock-screen / notification-shade reminders.
- Preset actions, including WebActions Kobo Enketo presets.
- Scheduled work runs in a transient task and returns to whatever the user was doing before MethodMesh.
- Editing a live plan cancels its old generated alarms/instance and re-arms the edited plan.
- Existing stored RelativeDays / Weekly / Cron / MonthlyNth / Intraday timing data remains decodable.
- New timing rules are stored backward-compatibly alongside the existing rule types.

## Implementation notes

`ElapsedInterval` is deliberately not cron: it is anchored to elapsed time from the trigger.

`AnchoredCalendarDays` is deliberately calendar-based: it preserves the same local clock time across daylight-saving changes.

Forever schedules use rolling occurrence chunks rather than materialising an unbounded schedule in one go. Finite schedules also roll if a high-frequency schedule reaches the per-instance materialisation cap before its actual end.

## Files

Replace the corresponding files under `app/src/main/` with the files in this bundle, then rebuild/install.
