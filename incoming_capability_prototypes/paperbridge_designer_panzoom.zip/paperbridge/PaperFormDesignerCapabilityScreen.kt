package com.example.methodmesh.modules.paperbridge

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

internal data class PaperDesignOptionDraft(
    val value: String,
    val label: String,
    val roi: NormalisedRoi? = null
)

internal data class PaperDesignFieldDraft(
    val name: String,
    val label: String,
    val type: PaperFieldType,
    val roi: NormalisedRoi? = null,
    val options: List<PaperDesignOptionDraft> = emptyList(),
    val required: Boolean = false,
    val regex: String? = null,
    val minimum: Double? = null,
    val maximum: Double? = null,
    val fromOdk: Boolean = false,
    val included: Boolean = true
)

private data class PaperDesignTarget(val fieldName: String, val optionValue: String? = null)
private enum class PaperDesignSeverity { ERROR, WARNING }
private data class PaperDesignIssue(val severity: PaperDesignSeverity, val message: String)

object PaperFormDesignCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100PaperFormDesignMethod.ID
    override val title = "Design a paper form"
    override val description = "Draw answer regions on a blank questionnaire and map them to ODK-safe fields."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val app = LocalContext.current
        PaperFormDesignerSurface(
            initialTemplate = null,
            onBack = onCancel,
            onSaved = { template, source, issueCounts, odkCount ->
                val request = As100PaperFormDesignMethod.request(
                    action = As100PaperFormDesignMethod.ID,
                    context = context.request.invocationContext.asMap(As100PaperFormDesignMethod.ID),
                    signals = emptyList(),
                    inputs = emptyList()
                )
                val values = linkedMapOf(
                    PaperDesignFields.STATUS to "succeeded",
                    PaperDesignFields.TEMPLATE_JSON to template.rawJson,
                    PaperDesignFields.TEMPLATE_ID to template.templateId,
                    PaperDesignFields.TEMPLATE_VERSION to template.version,
                    PaperDesignFields.FIELD_COUNT to template.fields.size.toString(),
                    PaperDesignFields.ODK_FIELD_COUNT to odkCount.toString(),
                    PaperDesignFields.ERROR_COUNT to issueCounts.first.toString(),
                    PaperDesignFields.WARNING_COUNT to issueCounts.second.toString(),
                    PaperDesignFields.SOURCE_TYPE to source.mimeType,
                    PaperDesignFields.ERROR to ""
                )
                onConfirmed(As100PaperFormDesignMethod.result(request, values, context.request.invocationContext))
            }
        )
    }
}

@Composable
internal fun PaperFormDesignerSurface(
    initialTemplate: PaperTemplate?,
    onBack: () -> Unit,
    onSaved: (PaperTemplate, PaperDesignSource, Pair<Int, Int>, Int) -> Unit
) {
    val app = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by rememberSaveable { mutableStateOf(initialTemplate?.title ?: "New paper form") }
    var templateId by rememberSaveable { mutableStateOf(initialTemplate?.templateId ?: "paper_form") }
    var version by rememberSaveable { mutableStateOf(initialTemplate?.version ?: "1") }
    var source by remember { mutableStateOf(initialTemplate?.let { PaperDesignSourceStore.sourceFor(app, it) }) }
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var sourceStatus by rememberSaveable { mutableStateOf("Choose the blank questionnaire PDF or image.") }
    var anchorsOk by rememberSaveable { mutableStateOf(false) }
    var anchorMessage by rememberSaveable { mutableStateOf("Anchors not checked yet.") }
    var odkSchema by remember { mutableStateOf<PaperOdkSchema?>(null) }
    var odkStatus by rememberSaveable { mutableStateOf("Optional: import the matching XLSForm to fill variable names, types and choices automatically.") }
    var fields by remember { mutableStateOf(initialTemplate?.fields?.map(::designFieldFromTemplate).orEmpty()) }
    var selectedField by rememberSaveable { mutableStateOf(fields.firstOrNull()?.name.orEmpty()) }
    var selectedOption by rememberSaveable { mutableStateOf("") }
    var drawTarget by remember { mutableStateOf<PaperDesignTarget?>(null) }
    var addOpen by rememberSaveable { mutableStateOf(false) }
    var addName by rememberSaveable { mutableStateOf("") }
    var addLabel by rememberSaveable { mutableStateOf("") }
    var addType by rememberSaveable { mutableStateOf(PaperFieldType.OCR_TEXT.name) }
    var addTypeMenu by rememberSaveable { mutableStateOf(false) }
    var addChoices by rememberSaveable { mutableStateOf("yes|Yes\nno|No") }
    var testStatus by rememberSaveable { mutableStateOf("") }
    var testLines by remember { mutableStateOf(emptyList<String>()) }
    var saving by rememberSaveable { mutableStateOf(false) }
    var pageSize by remember { mutableStateOf(IntSize.Zero) }

    fun loadSource(imported: PaperDesignSource) {
        source = imported
        sourceStatus = "Loading ${imported.displayName}…"
        anchorsOk = false
        anchorMessage = "Checking four registration marks…"
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { renderDesignSource(imported) } }
                .onFailure { sourceStatus = "Could not load blank form: ${it.message ?: "unsupported file"}" }
                .onSuccess { bitmap ->
                    sourceBitmap = bitmap
                    sourceStatus = "${imported.displayName} · ${bitmap.width}×${bitmap.height} design canvas"
                    val check = runCatching {
                        withContext(Dispatchers.Default) {
                            val probe = PaperTemplate(
                                schema = "methodmesh.paper.v1",
                                templateId = "anchor_probe",
                                version = "1",
                                title = "Anchor probe",
                                pageWidthPx = 800,
                                pageHeightPx = (800f * bitmap.height.toFloat() / bitmap.width.toFloat().coerceAtLeast(1f))
                                    .roundToInt()
                                    .coerceIn(600, 6000),
                                anchors = PaperAnchorSpec(),
                                fields = emptyList(),
                                rawJson = "{}"
                            )
                            PaperImageEngine.rectify(bitmap, probe)
                        }
                    }
                    check.onFailure {
                        anchorsOk = false
                        anchorMessage = "Registration marks not ready: ${it.message ?: "four anchors not detected"}"
                    }.onSuccess { rectified ->
                        anchorsOk = true
                        val scores = rectified.anchors.joinToString(" · ") { "${it.corner} ${(it.score * 100).roundToInt()}%" }
                        anchorMessage = "Four registration marks detected · $scores"
                        if (!rectified.bitmap.isRecycled) rectified.bitmap.recycle()
                    }
                }
        }
    }

    LaunchedEffect(source?.path) {
        val current = source
        if (current != null && sourceBitmap == null) loadSource(current)
    }

    val sourcePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { PaperDesignSourceStore.import(app, uri) } }
                .onFailure { sourceStatus = "Import failed: ${it.message ?: "storage error"}" }
                .onSuccess { imported -> loadSource(imported) }
        }
    }
    val xlsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            odkStatus = "Reading XLSForm…"
            runCatching { withContext(Dispatchers.IO) { PaperXlsFormReader.read(app, uri) } }
                .onFailure { odkStatus = "XLSForm not imported: ${it.message ?: "invalid XLSForm"}" }
                .onSuccess { schema ->
                    odkSchema = schema
                    title = schema.title
                    templateId = safeTemplateId(schema.formId)
                    version = schema.version
                    fields = schema.fields.map(::designFieldFromOdk)
                    selectedField = fields.firstOrNull()?.name.orEmpty()
                    selectedOption = ""
                    drawTarget = null
                    odkStatus = "${schema.fields.size} compatible ODK fields loaded" +
                        if (schema.warnings.isEmpty()) "." else " · ${schema.warnings.size} import warning${if (schema.warnings.size == 1) "" else "s"}."
                }
        }
    }

    val issues = remember(source?.path, anchorsOk, anchorMessage, fields, templateId, title, version) {
        validatePaperDesign(source, anchorsOk, anchorMessage, fields, templateId, title, version)
    }
    val errors = issues.filter { it.severity == PaperDesignSeverity.ERROR }
    val warnings = issues.filter { it.severity == PaperDesignSeverity.WARNING }
    val canBuild = errors.isEmpty() && sourceBitmap != null && source != null

    val testPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val bitmap = sourceBitmap ?: return@rememberLauncherForActivityResult
        val manifest = runCatching { buildPaperManifest(templateId, version, title, bitmap.width, bitmap.height, fields) }.getOrNull()
            ?: return@rememberLauncherForActivityResult
        scope.launch {
            testStatus = "Testing extraction…"
            testLines = emptyList()
            runCatching {
                val stable = withContext(Dispatchers.IO) { PaperBridgeFiles.copyIntoCache(app, uri, "designer-test") }
                PaperExtractionEngine.extract(
                    context = app,
                    sourceUri = stable,
                    template = PaperTemplate.parse(manifest),
                    settings = PaperExtractionSettings(autoAcceptOmr = true, autoAcceptOcr = false),
                    manualQuarterTurns = 0,
                    scanTimeIso = java.time.Instant.now().toString()
                )
            }.onFailure { testStatus = "Test failed: ${it.message ?: "could not read completed page"}" }
                .onSuccess { session ->
                    val unresolved = session.results.count { !it.resolved }
                    testStatus = if (unresolved == 0) "Test passed: all ${session.results.size} fields resolved." else "Test completed: $unresolved field${if (unresolved == 1) "" else "s"} would be sent to review."
                    testLines = session.results.map { result ->
                        val candidate = result.finalValue?.takeIf { it.isNotBlank() }
                            ?: result.candidate.takeIf { it.isNotBlank() }
                            ?: "—"
                        "${result.spec.name}: $candidate · ${if (result.resolved) "ready" else "review"}"
                    }
                }
        }
    }

    fun updateField(name: String, transform: (PaperDesignFieldDraft) -> PaperDesignFieldDraft) {
        fields = fields.map { if (it.name == name) transform(it) else it }
    }

    fun applyDrawnRoi(target: PaperDesignTarget, roi: NormalisedRoi) {
        updateField(target.fieldName) { field ->
            if (target.optionValue == null) field.copy(roi = roi)
            else field.copy(options = field.options.map { option -> if (option.value == target.optionValue) option.copy(roi = roi) else option })
        }
        drawTarget = null
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Paper Form Designer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Blank page → ODK fields → draw regions → test → save", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("Back", modifier = Modifier.clickable(onClick = onBack).padding(8.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(14.dp))
            Text("1 · BLANK PAPER FORM", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(sourceStatus, modifier = Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { sourcePicker.launch(arrayOf("application/pdf", "image/*")) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(if (source == null) "Choose PDF or image" else "Replace blank form")
            }
            source?.let {
                Text(anchorMessage, modifier = Modifier.padding(top = 7.dp), style = MaterialTheme.typography.bodySmall,
                    color = if (anchorsOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(16.dp))
            Text("2 · ODK MAPPING", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(odkStatus, modifier = Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { xlsPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(if (odkSchema == null) "Import matching XLSForm" else "Replace XLSForm")
            }
            odkSchema?.warnings?.forEach { warning ->
                Text("• $warning", modifier = Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary)
            }

            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Form name") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(version, { version = it }, label = { Text("Version") }, modifier = Modifier.weight(0.45f), singleLine = true)
            }
            OutlinedTextField(templateId, { templateId = safeTemplateId(it) }, label = { Text("Form ID") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true)

            sourceBitmap?.let { bitmap ->
                Spacer(Modifier.height(18.dp))
                Text("3 · DRAW ANSWER REGIONS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    drawTarget?.let { target ->
                        if (target.optionValue == null) "Position the page with Navigate, then drag a box over ${target.fieldName}."
                        else "Position the page with Navigate, then drag a box over ${target.fieldName} = ${target.optionValue}."
                    } ?: "Pinch to zoom and drag to pan in Navigate. Select a field below, then choose Draw and drag its answer region.",
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (drawTarget != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                DesignerPageCanvas(
                    bitmap = bitmap,
                    fields = fields,
                    target = drawTarget,
                    onSize = { pageSize = it },
                    onDrawn = ::applyDrawnRoi
                )
                if (pageSize.width > 0) {
                    Text("Pinch to zoom · drag to pan in Navigate · drawn boxes remain locked to scale-independent page coordinates.", modifier = Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("FIELDS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (fields.isEmpty()) {
                Text("No fields yet. Import the XLSForm or add a field manually.", modifier = Modifier.padding(top = 6.dp), style = MaterialTheme.typography.bodySmall)
            }
            fields.forEach { field ->
                DesignerFieldCard(
                    field = field,
                    selected = selectedField == field.name,
                    selectedOption = selectedOption,
                    onSelect = { selectedField = field.name; selectedOption = "" },
                    onDrawField = { drawTarget = PaperDesignTarget(field.name); selectedField = field.name; selectedOption = "" },
                    onDrawOption = { value -> drawTarget = PaperDesignTarget(field.name, value); selectedField = field.name; selectedOption = value },
                    onRequired = { required -> updateField(field.name) { it.copy(required = required) } },
                    onIncluded = { included ->
                        updateField(field.name) { it.copy(included = included) }
                        if (!included && drawTarget?.fieldName == field.name) drawTarget = null
                    },
                    onDelete = {
                        fields = fields.filterNot { it.name == field.name }
                        if (selectedField == field.name) selectedField = fields.firstOrNull()?.name.orEmpty()
                        if (drawTarget?.fieldName == field.name) drawTarget = null
                    }
                )
            }

            OutlinedButton(onClick = { addOpen = !addOpen }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(if (addOpen) "Hide manual field" else "Add field manually")
            }
            if (addOpen) {
                Surface(Modifier.fillMaxWidth().padding(top = 8.dp), shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)) {
                    Column(Modifier.padding(12.dp)) {
                        OutlinedTextField(addName, { addName = safeVariableName(it) }, label = { Text("Variable name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(addLabel, { addLabel = it }, label = { Text("Question label") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true)
                        Box(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                            OutlinedButton(onClick = { addTypeMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("Type: ${prettyType(PaperFieldType.valueOf(addType))}") }
                            DropdownMenu(expanded = addTypeMenu, onDismissRequest = { addTypeMenu = false }) {
                                PaperFieldType.values().forEach { type ->
                                    DropdownMenuItem(text = { Text(prettyType(type)) }, onClick = { addType = type.name; addTypeMenu = false })
                                }
                            }
                        }
                        if (PaperFieldType.valueOf(addType) in setOf(PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE)) {
                            OutlinedTextField(
                                value = addChoices,
                                onValueChange = { addChoices = it },
                                label = { Text("Return options · one value|label per line") },
                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                minLines = 3
                            )
                        }
                        Button(
                            onClick = {
                                val name = addName.trim()
                                if (name.isNotBlank()) {
                                    val type = PaperFieldType.valueOf(addType)
                                    val options = if (type in setOf(PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE)) parseManualOptions(addChoices) else emptyList()
                                    fields = fields + PaperDesignFieldDraft(name, addLabel.ifBlank { name }, type, options = options)
                                    selectedField = name
                                    addName = ""; addLabel = ""; addOpen = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            enabled = addName.isNotBlank() && fields.none { it.name == addName.trim() }
                        ) { Text("Add field") }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text("4 · CHECK DESIGN", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Surface(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                shape = RoundedCornerShape(16.dp),
                color = when {
                    errors.isNotEmpty() -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f)
                    warnings.isNotEmpty() -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f)
                    else -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                }
            ) {
                Column(Modifier.padding(13.dp)) {
                    Text(
                        when {
                            errors.isNotEmpty() -> "${errors.size} problem${if (errors.size == 1) "" else "s"} must be fixed"
                            warnings.isNotEmpty() -> "Ready with ${warnings.size} warning${if (warnings.size == 1) "" else "s"}"
                            else -> "Design checks passed"
                        },
                        fontWeight = FontWeight.Bold
                    )
                    issues.forEach { issue -> Text("${if (issue.severity == PaperDesignSeverity.ERROR) "✕" else "!"} ${issue.message}", modifier = Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodySmall) }
                }
            }

            OutlinedButton(onClick = { testPicker.launch("image/*") }, enabled = canBuild, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) {
                Text("Test with completed page")
            }
            if (testStatus.isNotBlank()) Text(testStatus, modifier = Modifier.padding(top = 7.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            testLines.forEach { Text(it, modifier = Modifier.padding(top = 3.dp), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace) }

            Button(
                onClick = {
                    val bitmap = sourceBitmap ?: return@Button
                    val currentSource = source ?: return@Button
                    saving = true
                    runCatching {
                        val json = buildPaperManifest(templateId, version, title, bitmap.width, bitmap.height, fields)
                        val template = PaperBridgeWorkspace.saveAndActivateTemplate(app, json)
                        PaperDesignSourceStore.bind(app, template, currentSource)
                        template
                    }.onFailure { saving = false; testStatus = "Save failed: ${it.message ?: "invalid design"}" }
                        .onSuccess { saved ->
                            saving = false
                            onSaved(saved, currentSource, errors.size to warnings.size, odkSchema?.fields?.size ?: 0)
                        }
                },
                enabled = canBuild && !saving,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) { Text(if (saving) "Saving…" else "Save Paper Bridge form") }
        }
    }
}

private enum class PaperDesignerCanvasMode { NAVIGATE, DRAW }

private data class PaperDesignViewportLayout(
    val originX: Float,
    val originY: Float,
    val scaledWidth: Float,
    val scaledHeight: Float,
    val panX: Float,
    val panY: Float
)

private fun paperDesignViewportLayout(
    viewport: IntSize,
    bitmapWidth: Int,
    bitmapHeight: Int,
    zoom: Float,
    pan: Offset
): PaperDesignViewportLayout? {
    if (viewport.width <= 0 || viewport.height <= 0 || bitmapWidth <= 0 || bitmapHeight <= 0) return null
    val baseScale = min(
        viewport.width.toFloat() / bitmapWidth.toFloat(),
        viewport.height.toFloat() / bitmapHeight.toFloat()
    )
    val safeZoom = zoom.coerceIn(1f, 16f)
    val scaledWidth = bitmapWidth * baseScale * safeZoom
    val scaledHeight = bitmapHeight * baseScale * safeZoom
    val maxPanX = ((scaledWidth - viewport.width) / 2f).coerceAtLeast(0f)
    val maxPanY = ((scaledHeight - viewport.height) / 2f).coerceAtLeast(0f)
    val clampedPanX = pan.x.coerceIn(-maxPanX, maxPanX)
    val clampedPanY = pan.y.coerceIn(-maxPanY, maxPanY)
    return PaperDesignViewportLayout(
        originX = viewport.width / 2f - scaledWidth / 2f + clampedPanX,
        originY = viewport.height / 2f - scaledHeight / 2f + clampedPanY,
        scaledWidth = scaledWidth,
        scaledHeight = scaledHeight,
        panX = clampedPanX,
        panY = clampedPanY
    )
}

private fun toPaperNormalisedPoint(position: Offset, layout: PaperDesignViewportLayout?): Offset? {
    layout ?: return null
    if (layout.scaledWidth <= 0f || layout.scaledHeight <= 0f) return null
    val x = (position.x - layout.originX) / layout.scaledWidth
    val y = (position.y - layout.originY) / layout.scaledHeight
    if (x !in 0f..1f || y !in 0f..1f) return null
    return Offset(x, y)
}

@Composable
private fun DesignerPageCanvas(
    bitmap: Bitmap,
    fields: List<PaperDesignFieldDraft>,
    target: PaperDesignTarget?,
    onSize: (IntSize) -> Unit,
    onDrawn: (PaperDesignTarget, NormalisedRoi) -> Unit
) {
    var measured by remember { mutableStateOf(IntSize.Zero) }
    var zoom by rememberSaveable(bitmap.width, bitmap.height) { mutableStateOf(1f) }
    var panX by rememberSaveable(bitmap.width, bitmap.height) { mutableStateOf(0f) }
    var panY by rememberSaveable(bitmap.width, bitmap.height) { mutableStateOf(0f) }
    var modeName by rememberSaveable(bitmap.width, bitmap.height) { mutableStateOf(PaperDesignerCanvasMode.NAVIGATE.name) }
    val mode = PaperDesignerCanvasMode.valueOf(modeName)
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    var dragEnd by remember { mutableStateOf<Offset?>(null) }
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.tertiary
    val surface = MaterialTheme.colorScheme.surface
    val ratio = bitmap.width.toFloat() / bitmap.height.toFloat().coerceAtLeast(1f)
    val allRois = remember(fields) {
        fields.flatMap { field ->
            if (field.type in setOf(PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE)) {
                field.options.mapNotNull { option -> option.roi?.let { Triple(field.name, option.value, it) } }
            } else listOfNotNull(field.roi?.let { Triple(field.name, "", it) })
        }
    }

    LaunchedEffect(target) {
        modeName = if (target == null) PaperDesignerCanvasMode.NAVIGATE.name else PaperDesignerCanvasMode.DRAW.name
        dragStart = null
        dragEnd = null
    }

    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
            .background(surface, RoundedCornerShape(12.dp))
            .onSizeChanged { measured = it; onSize(it) }
            .pointerInput(modeName, target, measured, bitmap.width, bitmap.height) {
                if (measured.width <= 0 || measured.height <= 0) return@pointerInput
                when (mode) {
                    PaperDesignerCanvasMode.NAVIGATE -> detectTransformGestures { _, pan, gestureZoom, _ ->
                        val newZoom = (zoom * gestureZoom).coerceIn(1f, 16f)
                        val layout = paperDesignViewportLayout(
                            measured,
                            bitmap.width,
                            bitmap.height,
                            newZoom,
                            Offset(panX + pan.x, panY + pan.y)
                        )
                        zoom = newZoom
                        if (layout != null) {
                            panX = layout.panX
                            panY = layout.panY
                        }
                    }
                    PaperDesignerCanvasMode.DRAW -> {
                        val activeTarget = target ?: return@pointerInput
                        detectDragGestures(
                            onDragStart = { position ->
                                val layout = paperDesignViewportLayout(measured, bitmap.width, bitmap.height, zoom, Offset(panX, panY))
                                toPaperNormalisedPoint(position, layout)?.let { point ->
                                    dragStart = point
                                    dragEnd = point
                                }
                            },
                            onDragEnd = {
                                val start = dragStart
                                val end = dragEnd
                                if (start != null && end != null) {
                                    val left = min(start.x, end.x).coerceIn(0f, 1f)
                                    val right = max(start.x, end.x).coerceIn(0f, 1f)
                                    val top = min(start.y, end.y).coerceIn(0f, 1f)
                                    val bottom = max(start.y, end.y).coerceIn(0f, 1f)
                                    if (right - left > 0.004f && bottom - top > 0.004f) {
                                        onDrawn(activeTarget, NormalisedRoi(left, top, right, bottom))
                                        modeName = PaperDesignerCanvasMode.NAVIGATE.name
                                    }
                                }
                                dragStart = null
                                dragEnd = null
                            },
                            onDragCancel = { dragStart = null; dragEnd = null },
                            onDrag = { change, _ ->
                                val layout = paperDesignViewportLayout(measured, bitmap.width, bitmap.height, zoom, Offset(panX, panY))
                                toPaperNormalisedPoint(change.position, layout)?.let { dragEnd = it }
                            }
                        )
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val viewport = IntSize(size.width.roundToInt(), size.height.roundToInt())
            val layout = paperDesignViewportLayout(viewport, bitmap.width, bitmap.height, zoom, Offset(panX, panY))
                ?: return@Canvas
            drawImage(
                image = bitmap.asImageBitmap(),
                dstOffset = IntOffset(layout.originX.roundToInt(), layout.originY.roundToInt()),
                dstSize = IntSize(layout.scaledWidth.roundToInt(), layout.scaledHeight.roundToInt())
            )

            fun pagePoint(p: Offset) = Offset(
                layout.originX + p.x * layout.scaledWidth,
                layout.originY + p.y * layout.scaledHeight
            )

            allRois.forEach { (fieldName, optionValue, roi) ->
                val selected = target?.fieldName == fieldName && (target.optionValue ?: "") == optionValue
                val color = if (selected) secondary else primary.copy(alpha = 0.78f)
                val topLeft = pagePoint(Offset(roi.left, roi.top))
                val bottomRight = pagePoint(Offset(roi.right, roi.bottom))
                drawRect(
                    color = color,
                    topLeft = topLeft,
                    size = Size(bottomRight.x - topLeft.x, bottomRight.y - topLeft.y),
                    style = Stroke(width = if (selected) 5f else 3f)
                )
            }
            val start = dragStart
            val end = dragEnd
            if (start != null && end != null) {
                val a = pagePoint(start)
                val b = pagePoint(end)
                drawRect(
                    color = secondary,
                    topLeft = Offset(min(a.x, b.x), min(a.y, b.y)),
                    size = Size(kotlin.math.abs(b.x - a.x), kotlin.math.abs(b.y - a.y)),
                    style = Stroke(width = 5f)
                )
            }
        }

        Surface(
            modifier = Modifier.align(Alignment.TopCenter).padding(8.dp),
            shape = RoundedCornerShape(50),
            tonalElevation = 4.dp,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = mode == PaperDesignerCanvasMode.NAVIGATE,
                    onClick = { modeName = PaperDesignerCanvasMode.NAVIGATE.name; dragStart = null; dragEnd = null },
                    label = { Text("Navigate") }
                )
                FilterChip(
                    selected = mode == PaperDesignerCanvasMode.DRAW,
                    enabled = target != null,
                    onClick = { if (target != null) modeName = PaperDesignerCanvasMode.DRAW.name },
                    label = { Text("Draw box") }
                )
                Text(
                    "Fit",
                    modifier = Modifier.clickable {
                        zoom = 1f
                        panX = 0f
                        panY = 0f
                        modeName = PaperDesignerCanvasMode.NAVIGATE.name
                    }.padding(horizontal = 8.dp, vertical = 7.dp),
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
            shape = RoundedCornerShape(50),
            color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = 0.86f)
        ) {
            Text(
                when {
                    mode == PaperDesignerCanvasMode.DRAW && target != null -> "Draw region · ${String.format("%.1f", zoom)}×"
                    zoom <= 1.01f -> "Drag to pan · pinch to zoom"
                    else -> "Navigate · ${String.format("%.1f", zoom)}×"
                },
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                color = MaterialTheme.colorScheme.inverseOnSurface,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

@Composable
private fun DesignerFieldCard(
    field: PaperDesignFieldDraft,
    selected: Boolean,
    selectedOption: String,
    onSelect: () -> Unit,
    onDrawField: () -> Unit,
    onDrawOption: (String) -> Unit,
    onRequired: (Boolean) -> Unit,
    onIncluded: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    val mapped = if (field.type in setOf(PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE)) field.options.count { it.roi != null } else if (field.roi != null) 1 else 0
    val needed = if (field.type in setOf(PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE)) field.options.size else 1
    Surface(
        modifier = Modifier.fillMaxWidth().padding(top = 7.dp).clickable(onClick = onSelect),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(field.label, fontWeight = FontWeight.SemiBold)
                    Text("${field.name} · ${prettyType(field.type)} · $mapped/$needed regions", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(if (field.fromOdk) "ODK" else "MANUAL", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            if (field.fromOdk) {
                Row(Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Read this ODK field from paper", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Switch(checked = field.included, onCheckedChange = onIncluded)
                }
            }
            if (field.included) {
                Row(Modifier.fillMaxWidth().padding(top = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Required", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Switch(checked = field.required, onCheckedChange = onRequired)
                }
            }
            if (field.included && field.type in setOf(PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE)) {
                field.options.forEach { option ->
                    Row(Modifier.fillMaxWidth().padding(top = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(option.label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("return: ${option.value}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                        }
                        FilterChip(
                            selected = selectedOption == option.value,
                            onClick = { onDrawOption(option.value) },
                            label = { Text(if (option.roi == null) "Draw" else "Redraw") }
                        )
                    }
                }
            } else if (field.included) {
                OutlinedButton(onClick = onDrawField, modifier = Modifier.fillMaxWidth().padding(top = 7.dp)) { Text(if (field.roi == null) "Draw answer box" else "Redraw answer box") }
            } else {
                Text("Excluded from the paper mapping.", modifier = Modifier.padding(top = 7.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!field.fromOdk) {
                Text("Delete field", modifier = Modifier.clickable(onClick = onDelete).padding(top = 8.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun designFieldFromOdk(field: PaperOdkField): PaperDesignFieldDraft = PaperDesignFieldDraft(
    name = field.name,
    label = field.label,
    type = field.type,
    options = field.options.map { (value, label) -> PaperDesignOptionDraft(value, label) },
    required = field.required,
    regex = field.regex,
    minimum = field.minimum,
    maximum = field.maximum,
    fromOdk = true
)

private fun designFieldFromTemplate(field: PaperFieldSpec): PaperDesignFieldDraft = PaperDesignFieldDraft(
    name = field.name,
    label = field.label,
    type = field.type,
    roi = field.roi,
    options = field.options.map { PaperDesignOptionDraft(it.value, it.label, it.roi) },
    required = field.required,
    regex = field.regex,
    minimum = field.minimum,
    maximum = field.maximum,
    fromOdk = false
)

private fun parseManualOptions(raw: String): List<PaperDesignOptionDraft> = raw.lines().mapNotNull { line ->
    val cleaned = line.trim()
    if (cleaned.isBlank()) return@mapNotNull null
    val value = cleaned.substringBefore('|').trim()
    if (value.isBlank()) return@mapNotNull null
    val label = cleaned.substringAfter('|', value).trim().ifBlank { value }
    PaperDesignOptionDraft(value, label)
}

private fun safeVariableName(raw: String): String = raw.trim().replace(Regex("[^A-Za-z0-9_]+"), "_").trim('_').let { value ->
    when {
        value.isBlank() -> ""
        value.first().isDigit() -> "v_$value"
        else -> value
    }
}

private fun safeTemplateId(raw: String): String = safeVariableName(raw.lowercase()).ifBlank { "paper_form" }

private fun prettyType(type: PaperFieldType): String = when (type) {
    PaperFieldType.OMR_SINGLE -> "Single choice"
    PaperFieldType.OMR_MULTIPLE -> "Multiple choice"
    PaperFieldType.OCR_TEXT -> "Text"
    PaperFieldType.OCR_INTEGER -> "Integer"
    PaperFieldType.OCR_DECIMAL -> "Decimal"
    PaperFieldType.BARCODE -> "Barcode"
}

private fun validatePaperDesign(
    source: PaperDesignSource?,
    anchorsOk: Boolean,
    anchorMessage: String,
    fields: List<PaperDesignFieldDraft>,
    templateId: String,
    title: String,
    version: String
): List<PaperDesignIssue> {
    val issues = mutableListOf<PaperDesignIssue>()
    if (source == null) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "Choose the blank paper questionnaire.")
    if (source != null && !anchorsOk) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, anchorMessage)
    if (title.isBlank()) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "Form name is blank.")
    if (!Regex("^[A-Za-z_][A-Za-z0-9_]*$").matches(templateId)) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "Form ID must be a safe identifier.")
    if (version.isBlank()) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "Version is blank.")
    if (fields.none { it.included }) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "Include at least one field in the paper mapping.")
    val duplicates = fields.filter { it.included }.groupBy { it.name }.filterValues { it.size > 1 }.keys
    duplicates.forEach { issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "Duplicate variable '$it'.") }

    val regions = mutableListOf<Pair<String, NormalisedRoi>>()
    fields.filter { it.included }.forEach { field ->
        if (!Regex("^[A-Za-z_][A-Za-z0-9_]*$").matches(field.name)) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${field.name}: invalid ODK variable name.")
        if (field.name.startsWith("paper_") || field.name.startsWith("methodmesh_")) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${field.name}: reserved MethodMesh return prefix.")
        when (field.type) {
            PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE -> {
                if (field.options.isEmpty()) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${field.name}: add return options.")
                val duplicateOptions = field.options.groupBy { it.value }.filterValues { it.size > 1 }.keys
                duplicateOptions.forEach { value -> issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${field.name}: duplicate return option '$value'.") }
                field.options.forEach { option ->
                    val roi = option.roi
                    if (roi == null) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${field.name} = ${option.value}: draw its mark box.")
                    else regions += "${field.name}=${option.value}" to roi
                }
            }
            else -> {
                val roi = field.roi
                if (roi == null) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${field.name}: draw its answer box.")
                else regions += field.name to roi
            }
        }
    }
    regions.forEach { (label, roi) ->
        if (!validRoi(roi)) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "$label: region is outside the page or inverted.")
        val area = (roi.right - roi.left) * (roi.bottom - roi.top)
        if (area in 0f..0.00025f) issues += PaperDesignIssue(PaperDesignSeverity.WARNING, "$label: region is very small; recognition may be fragile.")
        if (touchesAnchorZone(roi)) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "$label: region intrudes into a reserved corner-anchor zone.")
    }
    for (i in regions.indices) for (j in i + 1 until regions.size) {
        val a = regions[i]
        val b = regions[j]
        val overlap = overlapFraction(a.second, b.second)
        if (overlap > 0.35f) issues += PaperDesignIssue(PaperDesignSeverity.ERROR, "${a.first} overlaps ${b.first}; redraw one of the regions.")
    }
    return issues.distinctBy { it.severity to it.message }
}

private fun validRoi(roi: NormalisedRoi): Boolean =
    roi.left in 0f..1f && roi.right in 0f..1f && roi.top in 0f..1f && roi.bottom in 0f..1f && roi.left < roi.right && roi.top < roi.bottom

private fun touchesAnchorZone(roi: NormalisedRoi): Boolean {
    val zones = listOf(
        NormalisedRoi(0f, 0f, 0.13f, 0.13f),
        NormalisedRoi(0.87f, 0f, 1f, 0.13f),
        NormalisedRoi(0.87f, 0.87f, 1f, 1f),
        NormalisedRoi(0f, 0.87f, 0.13f, 1f)
    )
    return zones.any { overlapArea(roi, it) > 0f }
}

private fun overlapFraction(a: NormalisedRoi, b: NormalisedRoi): Float {
    val intersection = overlapArea(a, b)
    if (intersection <= 0f) return 0f
    val aArea = (a.right - a.left) * (a.bottom - a.top)
    val bArea = (b.right - b.left) * (b.bottom - b.top)
    return intersection / min(aArea, bArea).coerceAtLeast(0.000001f)
}

private fun overlapArea(a: NormalisedRoi, b: NormalisedRoi): Float {
    val width = (min(a.right, b.right) - max(a.left, b.left)).coerceAtLeast(0f)
    val height = (min(a.bottom, b.bottom) - max(a.top, b.top)).coerceAtLeast(0f)
    return width * height
}

private fun buildPaperManifest(
    templateId: String,
    version: String,
    title: String,
    width: Int,
    height: Int,
    fields: List<PaperDesignFieldDraft>
): String {
    val root = JSONObject()
        .put("schema", "methodmesh.paper.v1")
        .put("template_id", templateId)
        .put("version", version)
        .put("title", title)
        .put("page", JSONObject().put("width_px", width.coerceIn(600, 4000)).put("height_px", height.coerceIn(600, 6000)))
        .put("anchors", JSONObject().put("search_fraction", 0.24).put("threshold_luma", 150).put("minimum_score", 0.28))
    val array = JSONArray()
    fields.filter { it.included }.forEach { field ->
        val item = JSONObject()
            .put("name", field.name)
            .put("label", field.label)
            .put("type", when (field.type) {
                PaperFieldType.OMR_SINGLE -> "omr_single"
                PaperFieldType.OMR_MULTIPLE -> "omr_multiple"
                PaperFieldType.OCR_TEXT -> "ocr_text"
                PaperFieldType.OCR_INTEGER -> "ocr_integer"
                PaperFieldType.OCR_DECIMAL -> "ocr_decimal"
                PaperFieldType.BARCODE -> "barcode"
            })
            .put("required", field.required)
        field.regex?.takeIf(String::isNotBlank)?.let { item.put("regex", it) }
        field.minimum?.let { item.put("min", it) }
        field.maximum?.let { item.put("max", it) }
        when (field.type) {
            PaperFieldType.OMR_SINGLE, PaperFieldType.OMR_MULTIPLE -> {
                item.put("threshold", 0.18).put("min_separation", 0.06)
                    .put("allowed_values", JSONArray().apply { field.options.forEach { put(it.value) } })
                val options = JSONArray()
                field.options.forEach { option ->
                    val roi = requireNotNull(option.roi) { "${field.name}=${option.value} is not mapped." }
                    options.put(JSONObject().put("value", option.value).put("label", option.label).put("roi", roiJson(roi)))
                }
                item.put("options", options)
            }
            else -> {
                val roi = requireNotNull(field.roi) { "${field.name} is not mapped." }
                item.put("roi", roiJson(roi))
                if (field.type != PaperFieldType.BARCODE) item.put("normalise", "trim").put("auto_accept", false)
            }
        }
        array.put(item)
    }
    root.put("fields", array)
    val json = root.toString()
    PaperTemplate.parse(json) // final schema-level assertion
    return json
}

private fun roiJson(roi: NormalisedRoi): JSONArray = JSONArray().put(roi.left.toDouble()).put(roi.top.toDouble()).put(roi.right.toDouble()).put(roi.bottom.toDouble())

private fun renderDesignSource(source: PaperDesignSource): Bitmap {
    val file = File(source.path)
    require(file.exists()) { "Blank form source is no longer available." }
    if (source.mimeType == "application/pdf" || file.extension.equals("pdf", true)) {
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                require(renderer.pageCount > 0) { "PDF has no pages." }
                val page = renderer.openPage(0)
                try {
                    val targetWidth = 1600
                    val scale = targetWidth.toFloat() / page.width.toFloat().coerceAtLeast(1f)
                    val targetHeight = (page.height * scale).roundToInt().coerceAtLeast(600)
                    val bitmap = Bitmap.createBitmap(targetWidth, targetHeight.coerceAtMost(6000), Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    return bitmap
                } finally {
                    page.close()
                }
            }
        }
    }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Image could not be decoded." }
    require(bounds.outWidth <= 30_000 && bounds.outHeight <= 30_000) { "Image dimensions are too large for the designer." }

    var sample = 1
    while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 3200) sample *= 2
    val options = BitmapFactory.Options().apply {
        inSampleSize = sample.coerceAtLeast(1)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    val decoded = BitmapFactory.decodeFile(file.absolutePath, options)
        ?: throw IllegalArgumentException("Image could not be decoded.")
    val longest = max(decoded.width, decoded.height)
    val scale = when {
        longest < 1200 -> 1200f / longest.toFloat().coerceAtLeast(1f)
        longest > 2400 -> 2400f / longest.toFloat()
        else -> 1f
    }
    if (kotlin.math.abs(scale - 1f) < 0.01f) return decoded
    val targetWidth = (decoded.width * scale).roundToInt().coerceAtLeast(1)
    val targetHeight = (decoded.height * scale).roundToInt().coerceAtLeast(1)
    val scaled = Bitmap.createScaledBitmap(decoded, targetWidth, targetHeight, true)
    if (scaled !== decoded) decoded.recycle()
    return scaled
}
