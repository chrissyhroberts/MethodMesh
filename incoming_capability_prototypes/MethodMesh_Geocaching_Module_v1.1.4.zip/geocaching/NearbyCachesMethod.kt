package com.example.methodmesh.modules.geocaching

object As100NearbyCachesMethod:GeocachingMethodBase("geocache.nearby","Nearby caches","Find nearby saved caches or query an OpenCaching provider.",GeocachingContracts.nearby,connectivity="ONLINE_OFFLINE")
