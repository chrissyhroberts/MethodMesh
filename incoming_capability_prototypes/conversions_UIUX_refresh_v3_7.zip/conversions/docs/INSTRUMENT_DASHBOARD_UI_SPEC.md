# MethodMesh Instrument Dashboard UI — compact specification

Version: 0.4  
Status: working design rule

## Purpose

Interactive MethodMesh capabilities should feel like purpose-built instruments rather than generic settings forms. The Emergency Instruments and Compass surfaces are the reference direction: strong information hierarchy, a controlled visual identity, compact controls, immediate live state and a clear primary result.

This specification applies to instrument-like capability panels such as conversions, navigation, sensing, scoring, timing and other tools with live or rapidly changing values.

## 1. One coherent working surface

- Prefer one primary screen for configure/interact → live result → Commit.
- Do not navigate to a second screen merely to show a calculated result.
- Avoid wizard language for a direct single-capability run.
- Keep the current result visible in the same instrument while settings change.
- The shared MethodMesh shell may remain around the capability, but the capability-owned panel does not need to resemble the generic MethodSetting UI.

## 2. Visual hierarchy

The panel should read in this order:

1. **Instrument identity and current mode** — compact, not a large page title.
2. **Mode / major control selection** — immediately visible and quickly switchable.
3. **Task controls** — only the controls relevant to the selected mode.
4. **Primary live result** — visually strongest output, normally high in the panel like a calculator display.
5. **Task controls and value entry** — directly below the display, within thumb/keyboard reach.
6. **Working / secondary values** — subordinate to the primary result.
7. **Commit / finish** — compact and persistent, without competing with the working surface.

Avoid repeated headings that restate information already visible in the selected mode.

## 3. Instrument visual language

- Use a dark neutral instrument surface when it materially improves legibility and identity.
- Use one warm reference/accent colour for labels and instrument markings.
- Use the MethodMesh teal/green family selectively for active controls, successful state and actionable values.
- Reserve red/amber for warnings and degraded state.
- Prefer thin borders, quiet surfaces and deliberate spacing over nested cards and large filled buttons.
- Numeric readouts may use a monospaced treatment where it improves scanning and alignment.
- Large typography is reserved for the primary value, not navigation controls.

The goal is **technical, calm and field-ready**, not decorative dashboard chrome.

## 4. Density and touch behaviour

- Keep related controls adjacent; do not waste vertical space between labels and selectors.
- Visually compact selectors are encouraged when there are many bounded options.
- Controls must remain reliably tappable even if their visible treatment is small.
- Avoid horizontal carousels for core modes or commonly used units when all options can fit in a compact grid or row.
- Important modes should be visible without swiping.
- Do not turn every choice into a large card.

## 5. Live values and copying

- Recalculate immediately when inputs change if calculation is cheap and deterministic.
- Tapping the primary result copies the useful answer, including its unit when appropriate.
- Tapping the working/formula copies the working plus final answer.
- Copy confirmation should be subtle and transient.
- Do not require a dedicated Copy button where direct tap-to-copy is available.

## 6. Precision and transient controls

Controls that primarily alter presentation of the current result belong next to the result.

For example, numeric precision should be expressed as a small inline stepper beside the result header, not as a separate settings section. Changes apply immediately to both the displayed result and the copied working.

## 7. Conversions-specific projection

The Conversions capability uses this layout:

- compact instrument header: **CONVERSIONS / current mode / LOCAL · OFFLINE**;
- all conversion/calculator families visible at once in a dense mode matrix;
- for unit conversions, **FROM** and **TO** rows directly adjacent, with swap available in the same control area;
- value input immediately below the unit rows;
- live result immediately below the instrument header, calculator-style;
- decimal-place stepper beside the Result label;
- FROM and TO rows immediately beneath the result, followed by a larger value-entry field;
- the lower approximately one-third of the handset is treated as the expected software-keyboard zone rather than useful dashboard real estate;
- tap answer = copy answer;
- tap working = copy full working + answer;
- no Calculate button and no result navigation.

Special modes such as percentage, ratio, date arithmetic, age and geometry use the same instrument frame and result treatment; only their task controls change.

## 8. Contract boundary

The visual projection must not create a second capability contract. Dashboard/direct-native/preset/protocol/ODK surfaces continue to use the canonical method settings and return fields. Presentation-only controls such as decimal precision may be canonical settings where they affect the returned human-readable result, but visual styling remains local to the native surface.


## Density and use of space

Instrument dashboards should behave like instruments, not like stacked forms. On a handset, the primary live workflow should normally fit within one screen before the system keyboard is shown, and should remain as compact as practical when the keyboard is visible.

- Prefer one compact status/header line over a title block with multiple stacked labels.
- Mode switching should consume the minimum vertical space consistent with legibility. Where many modes must remain simultaneously visible, use a dense two-row matrix with short, unambiguous labels rather than large cards.
- Secondary unselected controls should be visually quiet: transparent or near-transparent backgrounds and low-contrast borders. Selection, not every control, should carry the accent colour.
- Related controls belong on the same visual axis. For unit conversion, `FROM` and `TO` are consecutive rows with the same geometry; the swap control belongs within that pair.
- Input fields should not automatically occupy full card-height form rows. A compact labelled inline field is preferred when only one primary value is required.
- The result is the primary visual anchor. For calculator-like instruments it should sit near the top, remain visible while editing, and carry precision controls locally when precision can be changed interactively.
- Avoid decorative whitespace between mode selection, input controls and result. Spacing should communicate grouping rather than act as padding for its own sake.
- A dashboard may deliberately ignore generic MethodMesh form styling inside its instrument surface when doing so improves instrument legibility and density, while preserving the MethodMesh capability lifecycle and contracts around it.


## Full-bleed instrument mode

For capabilities whose primary interaction is an instrument rather than a form, the capability may replace the generic `CapabilityScreenScaffold` with a capability-owned full-bleed surface. This is preferred when the shared scaffold would spend more screen area on step/status/version chrome than on the instrument itself.

- The instrument should consume the full capability viewport available beneath the app-level navigation.
- Generic step badges, repeated capability title/ID, module version/development badges, Retry and large footer actions should not be duplicated inside the instrument view.
- Lifecycle actions still have to exist. Back, cancel and commit/use may be projected as compact controls in the instrument header.
- Live calculation removes the need for a Retry action.
- The instrument should not manufacture empty vertical space merely to fill the viewport. Calculator-like instruments should use the upper working region efficiently and assume the software keyboard may occupy roughly the lower third while editing.
- The capability contract, settings visibility rules, invocation context, Commit lifecycle, presets/protocols and ODK behaviour remain unchanged. This is a presentation override, not a new execution path.

For Conversions specifically, the dark instrument surface is the capability body rather than a card inside the generic white capability card. The host may still provide global navigation such as Home or the application bottom bar.


## Keyboard-aware calculator layout

For calculator-style capabilities such as Conversions, design around the on-screen keyboard rather than treating it as an exceptional overlay.

- The result/display sits near the top of the instrument and remains visible while a value is being entered.
- Mode selection follows the display, then paired selectors such as FROM/TO, then the editable value field.
- The value field should be comfortably larger than compact selectors because it is the primary typing target.
- The lower roughly one-third of a handset should be considered the keyboard zone. Do not anchor essential output or controls there.
- Avoid large flexible spacers whose only effect is to push the result or value field toward the keyboard.
- When the keyboard is hidden, the instrument may simply end above the unused lower region; density is preferable to stretching controls vertically.
- The design target is that result, selected mode, units and active value entry remain simultaneously understandable when the keyboard is shown.
