# Barcode clone

**Canonical MethodMesh authority:** Master Book v1.22 (2026-09-15)  
**Module ID:** `barcode`  
**Method ID:** `barcode.clone`  
**Method version:** `1.0.0`  
**Maturity:** Development  
**Connectivity:** Offline

`barcode.clone` is the camera-to-code bridge: point the camera at a supported barcode/2D code, capture its exact decoded payload, immediately re-present that payload, then swipe through other compatible symbologies and share the committed clone.

## Native UX

On entry the capability invokes the established scanner acquisition boundary; it does not implement a second decoder. Once a code is captured, the large code renderer replaces the camera flow and shows `source format → clone format` around the exact payload.

`SOURCE` starts with the detected source symbology when ZXing can encode the exact payload in that format. Swipe, previous/next and optional Cycle move only through compatible formats. A fixed incompatible clone format is not silently replaced and Commit is disabled. **Commit** freezes the exact payload, source format, selected clone format, source scan time and clone commit time.

The clone renderer deliberately leaves even QR symbols pristine: branding belongs to `barcode.generate`; cloning prioritises scanner and future print fidelity. Native Share includes a PNG of the committed clone plus exact payload text.

## Cross-surface exposure

`barcode.clone` is a first-class capability, independently addressable through direct native use, capability discovery/dashboard, presets, protocols, supported schedules/widgets and ODK/XLSForm. It composes the established scanner boundary for acquisition but returns its own canonical clone observation.

## Inputs/settings

| Key | Type | Required | Meaning |
|---|---|---:|---|
| `barcode_clone_format` | choice | No | `SOURCE` or a specific target symbology. |
| `barcode_auto_cycle` | boolean | No | Start timed cycling through compatible target formats. |

Target values: `SOURCE`, `QR_CODE`, `CODE_128`, `DATA_MATRIX`, `AZTEC`, `PDF_417`, `CODE_39`, `EAN_13`, `EAN_8`, `UPC_A`, `UPC_E`.

Camera acquisition supplies the exact payload, source format and scan timestamp. The payload is never truncated, padded or rewritten during conversion.

## Canonical outputs

| Output | Meaning |
|---|---|
| `barcode_payload` | Exact scanned/re-presented payload; core result. |
| `barcode_payload_kind` | `text` or `url`. |
| `barcode_payload_url` | Safe absolute HTTP/HTTPS payload when applicable. |
| `barcode_source_format` | Symbology detected during acquisition. |
| `barcode_clone_format` | Symbology committed for the clone. |
| `barcode_payload_sha256` | SHA-256 of the exact payload. |
| `verification_evidence_format` | `barcode_payload_utf8_sha256_v1`. |
| `verification_evidence_hash` | Evidence hash. |
| `barcode_scan_time_iso` | Source scan timestamp. |
| `barcode_clone_time_iso` | Clone commit timestamp. |
| `barcode_source` | Normally `camera_zxing_clone`. |

## ODK Integration Card

### Capability

`barcode.clone`

### Intent call

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='barcode.clone',input_barcode_clone_format=${barcode_clone_format_input},input_barcode_auto_cycle=${barcode_clone_auto_cycle_input},input_payload_mode='FULL',return_mode='flat')
```

### Canonical returns

`barcode_payload`, `barcode_payload_kind`, `barcode_payload_url`, `barcode_source_format`, `barcode_clone_format`, `barcode_payload_sha256`, `verification_evidence_format`, `verification_evidence_hash`, `barcode_scan_time_iso`, `barcode_clone_time_iso`, `barcode_source`, plus shared `methodmesh_status` and `methodmesh_full_json`.

Canonical showcase: `docs/example_odk_showcase_barcode_clone.xlsx`. It contains one MethodMesh call, uses canonical unprefixed return fields and sets no return namespace. Camera acquisition is interactive; Commit returns the clone contract to ODK.

The shared metadata JSON is always captured by the canonical form. The native PNG share rendering is not declared as an ODK attachment because it is not currently a canonical clone output.

## Permissions, persistence and roadmap

Camera permission is required; core operation is offline. The capability owns no history repository.

Physical clone printing is a roadmap transport/export path, not current behaviour. A future Bluetooth/label-printer action should consume the committed exact payload + clone format and preserve printer-specific concerns outside this capability contract. See `ROADMAP_NOTE.md`.
