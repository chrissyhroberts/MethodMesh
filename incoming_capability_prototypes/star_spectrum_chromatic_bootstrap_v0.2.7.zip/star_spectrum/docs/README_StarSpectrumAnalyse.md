# Star spectrum analyser

**Module:** `star_spectrum`  
**Capability:** `astronomy.spectrum.analyse`  
**Version:** `0.2.7`  
**Maturity:** `DEVELOPMENT`  
**Connectivity:** `OFFLINE`

## Purpose

`astronomy.spectrum.analyse` turns a raster astronomical image containing a slitless stellar spectrum into a traced, background-corrected and contamination-aware one-dimensional spectrum.

The operator selects only an approximate line over the dispersed spectrum. MethodMesh then searches within a ribbon around that line, optimises the spatial trace, estimates local background from sidebands, models the target's cross-dispersion profile, identifies likely point-source/field-star contamination, extracts corrected intensity, optionally applies a previously saved wavelength solution, detects emission and/or absorption features, and exports the result.

The capability is intentionally an **analysis instrument**, not an automatic stellar-classification or elemental-identification system.

## Canonical surfaces

The capability contract is declared once in `StarSpectrumAnalyseMethod.kt` and `StarSpectrumModule.kt`.

It remains independently addressable through:

- direct native capability use;
- the generic MethodMesh dashboard presence;
- presets;
- protocols and protocol pipes;
- schedules/widgets when authored to show this interactive capability;
- ODK/XLSForm through the normal MethodMesh Android-intent roundtrip.

There is no dashboard-only implementation and no shared-shell special case.

## Native workflow

The native screen is one continuous tool surface.

1. Choose a spectrum image, or accept an image URI supplied by the caller.
2. Select an optional saved wavelength reference.
3. Pinch/zoom and pan the image.
4. Tap **Select trace** and tap the origin and far end of the dispersed spectrum.
5. MethodMesh displays the trace-search ribbon.
6. Tap **Analyse**.
7. The same screen displays the optimised trace, likely contaminants, extracted spectrum, quality metrics and detected features.
8. Adjust extraction/detection settings and re-run while the result is still working state.
9. Tap **Commit analysis** to freeze the canonical payload.
10. In committed state, Share, Save, copy the feature list, optionally include full JSON, then Done.

The screen deliberately does not navigate to a generic result page after analysis or Commit.

## Image interaction

The image surface supports:

- pinch zoom up to 8×;
- pan by drag when not selecting a trace;
- a dedicated select/reselect mode so one-finger trace placement is unambiguous;
- reset view;
- display of the user's original line;
- display of the trace-search ribbon;
- display of the optimised trace after analysis;
- orange spatial-contamination markers;
- yellow detected-feature markers.

Trace coordinates are stored in source-image pixel coordinates, not screen coordinates, so zoom/pan do not alter the scientific geometry.

## 2-D extraction model

The analyser now follows an established Horne-style optimal-extraction sequence rather than the earlier experimental template-amplitude method.

For each observation it:

1. uses the RED → VIOLET endpoints as an initial trace geometry;
2. refines that geometry with a robust quadratic fit to cross-dispersion centroids;
3. rectifies a 2-D ribbon around the fitted trace so dispersion is horizontal;
4. fits a sigma-clipped **two-sided local background** at each dispersion sample;
5. preserves a simple background-subtracted **boxcar extraction**;
6. estimates a smoothly varying empirical cross-dispersion spatial profile in dispersion bins;
7. performs iterative variance-weighted **Horne-style optimal extraction**;
8. rejects pixels that deviate strongly from the fitted target spatial profile and recomputes the optimal flux.

This is the standard conceptual architecture used by astronomical extraction packages such as Astropy `specreduce`. For processed JPEG/PNG input, MethodMesh must use an empirical relative variance proxy because detector gain/read-noise data are unavailable.

The field-star failure mode is therefore addressed spatially before collapse to 1-D: a crossing source that does not follow the target's cross-dispersion profile can be rejected as a deviant pixel/cluster rather than being silently absorbed into the target spectrum.

## Intensity semantics

The exported signal is **relative detector/image intensity**.

JPEG/PNG/WebP pixel values must not be described as calibrated photon counts. Compression, gamma/tone curves, demosaicing, white balance and other camera processing can alter proportionality between incident photons and stored pixel values.

A future FITS/raw-linear path can support stronger photometric semantics. The v0.2 interface therefore labels its amplitude generically as signal/intensity and records this limitation in `spectrum_intensity_semantics` and metadata JSON.

## Background and contamination outputs

Every row of the spectrum CSV retains:

- raw aperture signal;
- estimated background signal;
- contamination-corrected target signal;
- fitted continuum;
- continuum residual;
- local noise estimate;
- local S/N;
- contamination fraction;
- contamination probability;
- validity flag.

Downstream R analysis can therefore choose whether to exclude, down-weight or model contaminated points rather than receiving only a cosmetically cleaned curve.

## Wavelength calibration

A run may use a reference created by `astronomy.spectrum.reference.create`.

The stored reference contains the user's own pixel-to-wavelength polynomial, calibration anchors, source image dimensions and calibration RMS. The target run applies the stored solution after accounting for image-dimension scaling and the per-observation `registration_offset_px`.

If the target/reference aspect ratio differs materially, MethodMesh reduces calibration confidence and exposes a warning rather than silently treating the reference as exact.

A blank `reference_id` is valid. The spectrum then remains in distance/pixel coordinates.

## Feature detection

Feature detection is performed on the continuum-subtracted spectrum.

- continuum: rolling robust median;
- local spectral noise: rolling MAD × 1.4826, combined conservatively with extraction-sideband noise;
- candidate type: local emission maxima and/or absorption minima;
- threshold: configurable local sigma threshold;
- stability: candidate persistence across `threshold - 0.5σ`, `threshold`, and `threshold + 0.5σ`;
- confidence: weighted combination of S/N, prominence, multi-threshold stability and low contamination.

`confidence` is **not** a literal ROC probability and is not an elemental-identification probability. It is a bounded feature-stability/evidence score.

No automatic atomic/molecular identification is performed in v0.2.

## Settings / runtime inputs

| Key | Type | Default | Meaning |
|---|---|---:|---|
| `source_image_uri` | text | blank | Optional caller-supplied image URI. Blank opens the native picker. |
| `reference_id` | text | blank | Saved wavelength reference; blank means pixel coordinates. |
| `registration_offset_px` | float | 0 | Per-observation shift applied to the saved reference solution. |
| `ribbon_half_width_px` | int | 28 | Half-width of trace search ribbon. |
| `aperture_half_width_px` | int | 5 | Half-width of central extraction aperture. |
| `background_gap_px` | int | 4 | Gap before background sidebands. |
| `continuum_window` | int | 51 | Robust continuum window in samples. |
| `detection_sigma` | float | 3.5 | Feature significance threshold. |
| `detection_mode` | choice | `both` | `both`, `emission`, or `absorption`. |

Preset-fixed settings are not presented as editable runtime configuration. Operational image manipulation and trace placement remain part of the interactive measurement.

## Canonical outputs

### Primary beef

| Field | Normally shown | Description |
|---|---:|---|
| `spectrum_annotated_image_uri` | yes | Marked-up source image with user trace, optimised trace, contamination markers and detected feature markers. |
| `spectrum_data_uri` | yes | Analysis-ready CSV containing one row per spectral sample. |
| `spectrum_features_uri` | yes | CSV containing one row per detected feature. |
| `spectrum_features_text` | yes | Human-readable detected-feature list. |
| `spectrum_feature_count` | yes | Number of detected features. |

### Contractually available detail

| Field | Description |
|---|---|
| `spectrum_source_image_uri` | Conditional source attachment. Populated only when MethodMesh acquired the source image rather than receiving it from the caller. |
| `spectrum_source_image_sha256` | SHA-256 of the conditional returned source attachment. |
| `spectrum_metadata_uri` | Domain metadata JSON artefact for the analysis. |
| `spectrum_annotated_image_sha256` | SHA-256 of the annotated PNG bytes. |
| `spectrum_data_sha256` | SHA-256 of the spectrum CSV bytes. |
| `spectrum_features_sha256` | SHA-256 of the feature CSV bytes. |
| `spectrum_features_json` | Structured detected-feature array. |
| `spectrum_reference_id` | Saved reference ID used for calibration, if any. |
| `spectrum_reference_name` | Human name of reference used. |
| `spectrum_calibration_rms_nm` | Stored reference calibration RMS. |
| `spectrum_calibration_confidence` | Target/reference geometry + RMS confidence score. |
| `spectrum_calibration_warning` | Geometry/rescaling warning if applicable. |
| `spectrum_wavelength_min_nm` / `spectrum_wavelength_max_nm` | Calibrated wavelength range; blank if uncalibrated. |
| `spectrum_trace_quality` | Bounded quality score for trace geometry/signal support. |
| `spectrum_trace_mean_correction_px` | Mean distance between user estimate and refined trace. |
| `spectrum_mean_snr` | Mean local residual S/N diagnostic. |
| `spectrum_contaminated_fraction` | Fraction of spectral samples with contamination probability ≥ 0.5. |
| `spectrum_source_width_px` / `spectrum_source_height_px` | Decoded analysis dimensions. |
| `spectrum_intensity_semantics` | Explicit relative-intensity caveat. |
| `spectrum_metadata_json` | Module-owned structured metadata. |
| `spectrum_status` | `succeeded` / `failed`. |
| `spectrum_error` | Failure diagnostic. |

Shared transport adds `methodmesh_full_json` when FULL output is requested.

## CSV schema

`spectrum_data_uri` contains:

```text
index,distance_px,trace_x_px,trace_y_px,wavelength_nm,
raw_signal,background_signal,boxcar_signal,optimal_signal,optimal_variance,
continuum,residual,local_noise,local_snr,rejected_fraction,
contamination_probability,valid,is_feature,feature_id
```

`spectrum_features_uri` contains:

```text
feature_id,index,distance_px,wavelength_nm,type,signal,continuum,
amplitude,prominence,fwhm_px,fwhm_nm,snr,stability,
contamination_probability,confidence
```

Both are ordinary UTF-8 CSVs designed for direct import into R/Python.

## ODK Integration Card

### Method

`astronomy.spectrum.analyse`

### Canonical call

The supplied showcase intentionally asks MethodMesh to acquire the source file interactively:

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='astronomy.spectrum.analyse',
  input_payload_mode='FULL',
  return_mode='flat'
)
```

A user-authored form may instead supply any declared setting through the normal `input_<key>` mapping.

### Return semantics

The showcase captures:

- `methodmesh_status`;
- `spectrum_status`;
- `spectrum_source_image_uri` as an image attachment because MethodMesh acquires it in this showcase;
- `spectrum_annotated_image_uri` as an image attachment;
- `spectrum_data_uri` as a file attachment;
- `spectrum_features_uri` as a file attachment;
- `spectrum_metadata_uri` as a file attachment;
- feature/calibration/quality scalar returns;
- `methodmesh_full_json`.

If ODK supplied the source image itself, `spectrum_source_image_uri` remains blank so MethodMesh does not return a gratuitous duplicate.

### Workbook

`docs/example_odk_showcase_astronomy_spectrum_analyse.xlsx`

The workbook contains exactly one MethodMesh invocation, uses canonical unprefixed return fields and does not use `methodmesh_return_namespace`.

## Persistence

Analysis runs are transient by default.

Generated source-copy/annotated/CSV/JSON files live in MethodMesh cache as transport sources. Explicit Save/Export persists copies to Downloads. ODK receives the applicable attachments through the shared transport layer.

The analysis capability does not silently create its own results database.

## Offline / privacy

Fully offline. No astronomical image, pixel data, spectrum, reference name or derived feature is sent to a network service.

## Dependencies

Uses Android/Jetpack components already present in MethodMesh plus Kotlin/Java standard APIs:

- Jetpack Compose / Material 3;
- Android raster bitmap APIs;
- Android Storage Access Framework;
- existing MethodMesh `FileProvider`, `Digests`, canonical runtime and output/export infrastructure.

No new Maven library is introduced by v0.2.

## v0.2 limitations

- Raster image import only; FITS/raw-linear import is future work.
- Calibration reuse assumes substantially stable camera/grating geometry and a repeatable trace origin; `registration_offset_px` handles simple longitudinal shifts, not arbitrary affine/distortion changes.
- Optimal extraction rejects profile-inconsistent pixels but is not a full multi-source PSF deblender.
- No atmospheric extinction correction, instrumental response correction, heliocentric/barycentric velocity correction, redshift fitting or line identification.
- Feature confidence is an internal evidence/stability score rather than a calibrated posterior probability.

See `VALIDATION.md` for current validation status.


## Optimal extraction and visible QA

The primary 1-D science signal now comes from a Horne-style optimal extraction rather than the earlier experimental template-amplitude correction.

The native UI deliberately exposes the intermediate products used to construct that spectrum:

1. **Rectified trace** — fitted spectrum transformed to a horizontal dispersion axis.
2. **Two-sided background** — sigma-clipped local background estimated outside the target aperture.
3. **Background subtracted** — target ribbon after local-background removal.
4. **Spatial profile weights** — current unit-normalized empirical cross-dispersion profile.
5. **Fitted target model** — optimal 1-D flux multiplied by the current spatial profile.
6. **Data − fitted model residual** — signed raw mismatch.
7. **Standardized residual z-map** — mismatch divided by the local variance proxy; this is the rejection statistic.
8. **Cleaned optimal aperture** — rejected pixels highlighted and replaced only for the QA display.
9. **Boxcar versus optimal** — simple aperture sum compared with Horne-style optimal flux.

The spectrum CSV preserves both boxcar and optimal signals. For JPEG/PNG input, the variance used for optimal weighting is an empirical relative proxy because detector gain/read noise are not available. This limitation is explicit in metadata.

Balmer wavelength anchors are placed on the optimally extracted 1-D spectrum.


### Extraction residual QA

The extraction QA sequence now distinguishes the empirical unit-normalized spatial profile from the fitted 2-D target model. The residual panel shows `background-subtracted data − fitted target model` with a zero-centred greyscale and overlays rejected pixels in orange. The current iterative outlier rule is shown explicitly in the UI (`> 5.0σ residual` by default).


### Iterative profile refinement

The optimal extractor now alternates between flux extraction, standardized-residual rejection and **re-estimation of the empirical spatial profile from surviving pixels**. The profile is therefore not held fixed while the rejection loop proceeds.

At each pass MethodMesh:

1. extracts optimal 1-D flux with the current spatial profile;
2. calculates per-pixel standardized residuals;
3. rejects at most the strongest `|z| > 5σ` outlier in each dispersion column;
4. rebuilds the empirical spatial profile from the surviving pixels;
5. re-extracts using the revised profile.

The rejection threshold is deliberately not lowered merely because coherent residual structure remains. The QA panel exposes `% |z| > 3σ`, `% |z| > 5σ`, maximum `|z|` and the number of profile-update passes so model inadequacy remains visible rather than being converted automatically into contamination.


### Fixed-scale standardized-residual QA

The standardized-residual z-map uses a **fixed −5σ to +5σ greyscale**. Zero is always mid-grey, so a quiet residual field remains visually quiet rather than being stretched to black and white. Pixels with `|z| ≥ 3σ` are highlighted in yellow, pixels with `|z| ≥ 5σ` in magenta, and pixels actually rejected by the extractor remain orange.

The signed raw residual panel remains percentile auto-scaled because its purpose is to reveal subtle spatial structure. This revision changes QA rendering only; it does not alter trace fitting, background estimation, variance proxy, spatial-profile estimation, Horne extraction or rejection decisions.


### Reliable line finder and constrained Balmer placement

The calibration **Line finder** no longer divides every pixel by a rolling-median continuum.

It now:

1. starts from the Horne-optimally extracted 1-D signal;
2. applies only light display smoothing;
3. requires a minimum extracted signal and approximate signal-to-noise before a sample can participate;
4. estimates a broad **upper-envelope continuum** using a high rolling percentile, so broad absorption troughs are not fitted downward into the continuum;
5. leaves low-information / colour-channel-handover regions blank rather than dividing by near-zero values;
6. normalizes only reliable samples.

The UI reports the proportion of the spectrum that remains reliable for line finding.

Once at least **two Balmer anchors** have been placed, MethodMesh fits a provisional wavelength solution using the currently requested polynomial order where the number of anchors permits it. Unplaced Hα/Hβ/Hγ/Hδ positions are shown as **gold provisional markers**. The active predicted line also receives a dedicated local zoomed trough view with:

- predicted position in gold;
- an independent white placement cursor;
- tap/drag positioning;
- ±1 and ±5 sample nudging;
- an explicit **Set Hα/Hβ/Hγ/Hδ here** action.

Predicted positions are calibration aids only. They are never committed automatically and do not replace manual placement on the observed local absorption minimum.


### Chromatic wavelength bootstrap

For processed colour photographs, MethodMesh now uses the photographed VIOLET → RED colour progression as a **coarse wavelength prior** before Balmer-line confirmation.

The bootstrap:

1. samples RGB colour along the optimised spectrum trace;
2. converts each sample to brightness-independent RGB chromaticity;
3. down-weights dark or weakly chromatic samples;
4. aligns the observed colour sequence monotonically against an approximate ideal visible spectral-colour locus;
5. searches several plausible violet/red endpoint ranges rather than assuming the user's taps are exact physical wavelengths;
6. returns a smooth monotonic wavelength-by-pixel prior;
7. uses that prior only to predict where Hα/Hβ/Hγ/Hδ should be inspected.

The UI shows the observed photographic strip, the aligned ideal-colour strip, coarse wavelength ticks, a chromatic fit score and the fraction of the trace carrying useful colour information.

This is **not** the final scientific wavelength calibration. Camera spectral response, white balance, demosaicing, JPEG processing and atmosphere can distort apparent colour. Confirmed Balmer absorption lines supersede the chromatic prior as soon as sufficient anchors are available. Two confirmed lines define a provisional wavelength solution; at least three confirmed Balmer anchors are required before a reference can be saved.
