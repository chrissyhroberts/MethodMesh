import json,hashlib,binascii

def c(v):return json.dumps(v).replace(": ",":").replace(", ",",")
def h(s):return binascii.hexlify(hashlib.sha256(s.encode()).digest()).decode()
def nt(n):return h(n)[:8]
def at(t,k):return h(k+"|"+t+"|"+k)[:16]
def ap(p,k):
 q=dict(p);q.pop("a",None);return at(c(q),k)

def fragment(t,n,k,m):
 r=h(t)[:12];a=at(t,k);g=nt(n);o=[];p=0;s=0
 while p<len(t):
  z=min(112,len(t)-p)
  while z>8:
   d=t[p:p+z];q={"f":1,"n":g,"i":r,"s":s,"z":1 if p+z>=len(t) else 0,"d":d,"a":a};e=c(q).encode()
   if len(e)<=m:break
   z-=8
  if z<=8:raise ValueError("fragment too large")
  o.append(e);p+=z;s+=1
 return o

class Reassembler:
 def __init__(s):s.x={}
 def accept(s,q,n,k):
  if q.get("f")!=1 or q.get("n")!=nt(n):return None
  r=str(q.get("i",""));i=int(q.get("s",-1))
  if not r or i<0:return None
  v=s.x.get(r)
  if v is None:
   if len(s.x)>=8:s.x={}
   v={"p":{},"l":-1,"a":str(q.get("a",""))};s.x[r]=v
  v["p"][i]=str(q.get("d",""))
  if q.get("z"):v["l"]=i
  l=v["l"]
  if l<0 or any(j not in v["p"] for j in range(l+1)):return None
  t="".join(v["p"][j] for j in range(l+1));del s.x[r]
  return t if at(t,k)==v["a"] else None
