# Weather module v0.2.0 drop-in

Target location:

```text
app/src/main/java/com/example/methodmesh/modules/weather/
```

The folder is self-contained module-owned source, documentation and canonical XLSForm showcases. No shared MethodMesh source edit is intended for discovery; MethodMesh module discovery should pick up `WeatherModule` using the normal module contract.

After copying this `weather/` root into a current MethodMesh checkout, run:

```text
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
./gradlew generateMethodMeshOdkTemplateAssets
```

Then perform the device/ODK smoke matrix in `docs/VALIDATION.md`.
