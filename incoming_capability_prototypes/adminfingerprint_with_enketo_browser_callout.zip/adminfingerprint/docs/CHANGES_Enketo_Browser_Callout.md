# Enketo browser biometric call-out addition

Added without changing the behaviour of the existing `admin_fingerprint_confirmation` capability.

## New capability

`admin_browser_biometric_callout`

- biometric-only;
- intended for invocation from a browser/Enketo link;
- starts the Android biometric prompt immediately for an external invocation;
- records ordinary MethodMesh execution/provenance output;
- explicitly makes no person-identity claim;
- explicitly does not claim that stock Enketo can receive an Android activity result.

## New test assets

- `example_enketo_browser_biometric_callout.xlsx`
- `README_Enketo_Browser_Biometric_Test.md`
- `enketo_browser_callout_manifest_snippet.xml`

The XLSForm uses the standard `text` + `appearance=url` pattern with an Android `intent:` URI. It is designed as an integration probe rather than a production authentication protocol.
