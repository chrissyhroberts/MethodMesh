# Enketo browser biometric call-out test

This is a deliberately small integration probe for **stock Enketo**. It does not require custom JavaScript or changes to the Enketo deployment.

## What the test proves

- Enketo renders an `appearance=url` question containing an Android `intent:` URI.
- A user tap can leave the browser and open MethodMesh.
- MethodMesh can start the `admin_browser_biometric_callout` capability immediately.
- Android can show the biometric prompt.
- After MethodMesh finishes/closes, the user can return to the still-open Enketo form.

It does **not** test automatic return of `confirmed=true` into an Enketo field. Stock Enketo has no general browser-to-native activity-result bridge for this.

## Files

- `example_enketo_browser_biometric_callout.xlsx` — upload this XLSForm to Kobo/ODK Central and open it in Enketo.
- `enketo_browser_callout_manifest_snippet.xml` — app-shell requirement if the existing MethodMesh external-intent activity is not already BROWSABLE.

## Test procedure

1. Install the MethodMesh build containing `admin_browser_biometric_callout` on an Android device with an enrolled biometric.
2. Confirm that the activity receiving `com.example.methodmesh.EXECUTE_METHOD` is exported appropriately and includes `android.intent.category.BROWSABLE`.
3. Upload `example_enketo_browser_biometric_callout.xlsx` to the form server and open the form in **Chrome on the same Android device**.
4. Tap **Open MethodMesh biometric confirmation**.
5. Expected result: Chrome hands the request to MethodMesh and MethodMesh immediately opens the biometric prompt.
6. Complete the biometric prompt.
7. Return to Chrome/Enketo and answer the three diagnostic questions.

## Expected first-test limitations

- Desktop browsers cannot perform this Android app call-out.
- iOS requires a separate iOS deep-link/app implementation.
- If Chrome does nothing, first check the MethodMesh manifest/dispatcher. Chrome only launches a resolvable BROWSABLE activity after a user gesture.
- Some Enketo deployments may reject or neutralise non-HTTP URL schemes. If that happens, the form has still usefully identified the next constraint: use an HTTPS trampoline/App Link rather than changing Enketo itself.
- The diagnostic yes/no fields are test instrumentation only; they are not security evidence.

## Intent URI used by the XLSForm

```text
intent:#Intent;action=com.example.methodmesh.EXECUTE_METHOD;category=android.intent.category.DEFAULT;category=android.intent.category.BROWSABLE;package=com.example.methodmesh;S.method_id=admin_browser_biometric_callout;S.input_caller=enketo;S.input_confirmation_reason=enketo_browser_test;end
```

If MethodMesh uses a different installed application ID/package name in the target build, change the `package=` value in the XLSForm before testing.
