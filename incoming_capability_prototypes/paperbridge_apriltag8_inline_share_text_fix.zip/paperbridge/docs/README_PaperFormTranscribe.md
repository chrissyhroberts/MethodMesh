# Paper Bridge — `paper.form.transcribe`

**Maturity:** Development  
**Connectivity:** Offline  
**Canonical method:** `paper.form.transcribe`

Paper Bridge turns a photographed registered paper questionnaire into the same named values that an XLSForm/ODK workflow expects. The capability is the single implementation used by Dashboard/direct native use, Presets, Protocols and ODK/external round-trips.

## Operator workflow

1. Select a Paper Bridge schema or receive one from the caller/preset.
2. Acquire a page from camera/document scan, image picker, or caller-supplied image.
3. Register the page into the schema's canonical coordinate system.
4. Extract the schema's declared ROIs.
5. Auto-accept only values that satisfy the schema's confidence/constraint rules.
6. Review every unresolved field on the same capability surface.
7. **Commit** when the transcription is correct.

Before Commit the working result is mutable. Commit freezes the canonical return payload. Commit itself does **not** save an archive or write an output copy.

## Registration

New schemas use `APRILTAG8` with the `tag36h11` family:

- tag 0 — top left;
- tag 1 — top centre;
- tag 2 — top right;
- tag 3 — left centre;
- tag 4 — right centre;
- tag 5 — bottom left;
- tag 6 — bottom centre;
- tag 7 — bottom right.

All detected tag corners are used as geometric correspondences. Paper Bridge estimates a robust page homography, validates spatial distribution and reprojection error, rectifies the acquired page once into the canonical page coordinate frame, and only then applies saved ROIs. Missing tags are tolerated only when the remaining geometry is sufficient for trustworthy registration. Legacy `QR4` and `BULLSEYE4` schemas remain readable.

The technical panel exposes registration mode, detected tags/points and reprojection diagnostics. ROI coordinates are never individually nudged to compensate for bad registration.

## Inputs

| Input | Meaning |
| --- | --- |
| `paper_template_json` | Versioned Paper Bridge template/manifest. |
| `source_mode` | `camera` or `file_picker` for native acquisition. |
| `source_image_uri` | Optional caller-supplied image. |
| `auto_accept_omr` | Permit unambiguous OMR auto-acceptance. |
| `auto_accept_ocr` | Permit constrained numeric OCR auto-acceptance. Free text still requires review. |
| `return_source_image` | Legacy compatibility input; retained for stable contract compatibility. |
| `return_rectified_image` | Legacy compatibility input; retained for stable contract compatibility. |

The canonical showcase call uses only the inputs relevant to the demonstrated workflow.

## Canonical stable returns

`paper_status`, `paper_template_id`, `paper_template_version`, `paper_values_json`, `paper_dynamic_fields_json`, `paper_field_count`, `paper_auto_accepted_count`, `paper_reviewed_count`, `paper_unresolved_count`, `paper_source_image`, `paper_rectified_image`, `paper_template_sha256`, `paper_source_sha256`, `paper_rectified_sha256`, `paper_extraction_audit_json`, `paper_attachment_metadata_json`, `paper_scan_time_iso`, `paper_error`.

The versioned paper manifest additionally declares **dynamic flat return keys**. For example a manifest field named `participant_id` returns as `participant_id`; a manifest image field named `site_sketch` returns as `site_sketch`. The complete structured equivalents remain available in `paper_values_json`, `paper_dynamic_fields_json` and the shared full JSON projection.

## Native committed state

After Commit, native use remains on the Paper Bridge capability screen and exposes:

- every scalar/text result as tap-to-copy;
- image returns as meaningful attachment cards rather than raw URI text;
- **Share**;
- **Save** to the shared MethodMesh **Files** surface;
- optional **Include full JSON / audit**;
- **Done** / origin-aware closeout;
- **Edit** to reopen the working result;
- explicit copy of the full JSON audit payload.

Share and Save default to one human-readable transcription plus the human-facing media products: the registered/canonical completed form and any image/file fields cropped from that form. The raw acquisition/source page remains in the committed audit/ODK contract but is not duplicated into native Share/Save. When media are shared, the transcription remains ordinary Android share text (`EXTRA_TEXT`); only the form image and cropped image/file fields are attachments. Save copies the same frozen set into the shared MethodMesh Files/ArtifactStore as one collection so Files can preview members and export/share the collection as a bundle. Full JSON is optional. Commit does not implicitly persist a duplicate output package.

## Evidence/media semantics

The registered analysis page is a derived output. Manifest-defined image ROIs are media outputs. The source scan is also available to native use.

For ODK/external round-trips:

- when MethodMesh acquires the source image on the caller's behalf, the source image is returned as an attachment;
- when the caller supplied `source_image_uri`, Paper Bridge does not gratuitously return a duplicate of that same source attachment;
- the registered page and manifest-defined image outputs are returned when produced;
- hashes remain available even when an already-owned source attachment is not returned again.

`paper_attachment_metadata_json` contains attachment roles, hashes and registration metadata without embedding private/local URI strings.

## ODK/external behaviour

ODK owns its form instance and submission persistence. An ODK launch uses the normal polished Paper Bridge acquisition/review surface. **Commit returns immediately to the calling form** through the canonical MethodMesh transport; native Share/Save controls are suppressed in that round-trip mode. Paper Bridge does not create an extra MethodMesh output-folder copy merely because ODK invoked it.

See `ODK_INTEGRATION.md` and `example_odk_showcase_paper_form_transcribe.xlsx`.

Dynamic image-field names require the generic MethodMesh return transport to recognise returned `content://` values as binary attachments independently of the field name. The required shared-framework patch is documented in `SHARED_FRAMEWORK_DEPENDENCY.md`; Paper Bridge deliberately does not rename XLSForm fields to work around shared transport.

## State and parity

Working acquisition/review state and the committed payload are distinct. The committed payload is serialised into saveable UI state so normal Activity recreation does not silently mutate or lose it. Configuration settings are projected through the normal capability settings contract, so the same canonical method remains available to direct native use, presets, protocols and ODK.

## Status

The module remains **Development** until representative-device ODK/Kobo attachment round-trips and the target-app integration build have been exercised. The AprilTag8 registration pipeline itself is implemented and bundled examples are intended as deterministic smoke fixtures, not as a Production claim.
