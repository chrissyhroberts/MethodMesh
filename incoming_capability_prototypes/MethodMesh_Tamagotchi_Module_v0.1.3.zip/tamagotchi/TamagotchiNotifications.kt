package com.example.methodmesh.modules.tamagotchi

import android.content.Context
import com.example.methodmesh.core.scheduling.ResearchSchedule
import com.example.methodmesh.core.scheduling.SchedulerFrequency
import com.example.methodmesh.core.scheduling.SchedulerRepository
import com.example.methodmesh.core.scheduling.SchedulerTarget
import org.json.JSONObject
import kotlin.math.abs

/**
 * Module adapter over MethodMesh's existing core Scheduler.
 *
 * Tamagotchi deliberately owns no BroadcastReceiver, Service, notification host,
 * overlay permission or app-manifest component. The module only registers ordinary
 * capability schedules with the core service already owned by MethodMesh.
 */
object TamagotchiReminderScheduler {
    private const val PREFIX = "tamagotchi_care_"
    private const val STEP_MINUTES = 15

    fun schedule(context: Context, session: TamagotchiSession): Result<Unit> = runCatching {
        cancel(context, session.id).getOrThrow()
        if (!session.attentionPolicy.enabled || session.ended || session.attentionPolicy.maxPerDay <= 0) {
            return@runCatching
        }

        plannedSlots(session).forEachIndexed { index, minuteOfDay ->
            SchedulerRepository.save(
                context,
                ResearchSchedule(
                    id = scheduleId(session.id, index),
                    name = "${session.creatureName} care check",
                    target = SchedulerTarget.CAPABILITY,
                    targetValue = "teaching.tamagotchi.session",
                    targetSettings = JSONObject()
                        .put("session_id", session.id)
                        .toString(),
                    frequency = SchedulerFrequency.DAILY,
                    hour = minuteOfDay / 60,
                    minute = minuteOfDay % 60,
                    notificationTitle = "${session.creatureName} is ready for a check-in",
                    notificationMessage = "Open MethodMesh when you have a moment.",
                    enabled = true
                )
            )
        }
    }

    fun cancel(context: Context, sessionId: String): Result<Unit> = runCatching {
        SchedulerRepository.all(context)
            .filter { it.id.startsWith(sessionPrefix(sessionId)) }
            .forEach { SchedulerRepository.remove(context, it.id) }
    }

    /**
     * Conservative daily slots chosen only from times allowed by the session policy.
     * School suppression is applied every day rather than trying to special-case
     * weekends; this errs toward fewer interruptions for child/classroom profiles.
     */
    fun plannedSlots(session: TamagotchiSession): List<Int> {
        val policy = session.attentionPolicy
        if (!policy.enabled || policy.maxPerDay <= 0) return emptyList()

        val candidates = (0 until 24 * 60 step STEP_MINUTES)
            .filter { minute -> isAllowed(policy, minute) }
        if (candidates.isEmpty()) return emptyList()

        val requested = policy.maxPerDay.coerceAtMost(candidates.size)
        val spacing = policy.minimumSpacingMinutes.coerceAtLeast(0)
        val selected = mutableListOf<Int>()

        for (ordinal in 1..requested) {
            val targetIndex = ((ordinal.toDouble() / (requested + 1)) * candidates.lastIndex)
                .toInt()
                .coerceIn(0, candidates.lastIndex)
            val target = candidates[targetIndex]
            val available = candidates
                .asSequence()
                .filter { candidate -> selected.all { previous -> circularDistance(candidate, previous) >= spacing } }
                .minByOrNull { candidate -> abs(candidate - target) }
                ?: continue
            selected += available
        }
        return selected.sorted()
    }

    private fun isAllowed(policy: AttentionPolicy, minute: Int): Boolean {
        if (inWrappedRange(minute, policy.quietStartMinutes, policy.quietEndMinutes)) return false
        if (!policy.allowDuringSchool && inWrappedRange(minute, policy.schoolStartMinutes, policy.schoolEndMinutes)) return false
        return true
    }

    private fun inWrappedRange(minute: Int, start: Int, end: Int): Boolean =
        if (start <= end) minute in start until end else minute >= start || minute < end

    private fun circularDistance(a: Int, b: Int): Int {
        val direct = abs(a - b)
        return minOf(direct, 24 * 60 - direct)
    }

    private fun sessionPrefix(sessionId: String) = "$PREFIX${sessionId}_"
    private fun scheduleId(sessionId: String, index: Int) = "${sessionPrefix(sessionId)}$index"
}
