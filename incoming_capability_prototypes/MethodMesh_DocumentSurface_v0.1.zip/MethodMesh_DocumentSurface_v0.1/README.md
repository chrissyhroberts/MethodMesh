# MethodMesh Document Surface v0.1

First implementation vertical slice for the Text & Markdown work.

## Included

- Platform-owned `DocumentSurface` composable.
- Full-screen/minimal document presentation.
- Markdown rendered by the open-source Markwon renderer.
- Source editor for Markdown and plain text.
- Keyboard-aware floating HUD anchored above IME.
- Find strip immediately above the keyboard.
- Copy all.
- Dirty-state indicator and explicit Save in the HUD.
- External Android `ACTION_VIEW` / `ACTION_EDIT` activity using `content://` streams.
- Close returns to the originating Android app rather than the MethodMesh dashboard.
- Self-discovered `TextDocumentsModule` shell.

## Deliberately not in v0.1

- Generic file/capability dispatch.
- Help wiring across all MethodMesh modules.
- Canonical executable Methods/preset/protocol/ODK contracts for document creation/editing.
- Syntax highlighting in the source editor.
- Interactive rendered task-list mutation.
- Save As / conflict detection / recovery journal.
- Recent-document library.

These are intentionally deferred until the basic phone UX has been built and exercised.

## Apply

Copy the `app/` tree into the repository, then apply the two small patches under `patches/` to `app/build.gradle.kts` and `AndroidManifest.xml`.

The module-index Gradle task will discover `TextDocumentsModule.kt` automatically because it follows the existing `*Module.kt` convention.

## First test

1. Build/install MethodMesh.
2. In Android Files, open a `.md` file and choose MethodMesh / Text & Markdown.
3. Confirm rendered Markdown opens directly with no dashboard detour.
4. Tap the HUD dot, choose Edit, then tap in the document to summon the keyboard.
5. Confirm the HUD remains above the keyboard.
6. Use Find and confirm the strip is visible immediately above the keyboard.
7. Edit and Save where the provider grants write permission.
8. Close and confirm Android returns to Files.
9. Reopen the file and confirm the saved change.

## Known v0.1 limitation

Android providers do not consistently advertise Markdown with `text/markdown`; some use `text/plain` or a generic MIME type. v0.1 intentionally accepts `text/plain` but does not claim generic binary MIME types. We should test Files, Chrome downloads, Drive and other actual providers before broadening the filters.
