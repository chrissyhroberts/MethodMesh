package com.example.methodmesh.modules.textdocuments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import com.example.methodmesh.platform.documents.DocumentFormat
import com.example.methodmesh.platform.documents.DocumentSurface
import com.example.methodmesh.ui.theme.MethodMeshTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Focused external-document entry point. Back/close returns to the originating Android app. */
class DocumentActivity : FragmentActivity() {
    private lateinit var documentUri: Uri
    private var writable: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent?.data ?: run { finish(); return }
        documentUri = uri
        writable = intent.action == Intent.ACTION_EDIT || intent.flags and Intent.FLAG_GRANT_WRITE_URI_PERMISSION != 0
        val title = queryDisplayName(uri) ?: uri.lastPathSegment ?: "Document"
        val format = detectFormat(title, intent.type)
        val initial = runCatching { contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty() }
            .getOrElse { "Unable to open document: ${it.message ?: "unknown error"}" }

        setContent {
            MethodMeshTheme {
                DocumentSurface(
                    title = title,
                    initialText = initial,
                    format = format,
                    writable = writable,
                    onBack = { finish() },
                    onSave = { body -> save(uri, body) }
                )
            }
        }
    }

    private suspend fun save(uri: Uri, body: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            check(writable) { "Document is read-only" }
            contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(body) }
                ?: error("Provider did not supply a writable stream")
        }
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private fun detectFormat(name: String, mime: String?): DocumentFormat =
        if (mime == "text/markdown" || name.endsWith(".md", true) || name.endsWith(".markdown", true)) DocumentFormat.MARKDOWN else DocumentFormat.TEXT
}
