package com.example.methodmesh.modules.textdocuments

import com.example.methodmesh.modules.MethodMeshModule

/** First vertical slice: external Markdown/text document handling. Canonical Methods follow after UX validation. */
object TextDocumentsModule : MethodMeshModule {
    override val moduleId = "textdocuments"
    override val displayName = "Text & Markdown"
    override val summary = "Open, read and edit Markdown and plain-text documents with a focused full-screen surface."
    override val iconKey = "document"
}
