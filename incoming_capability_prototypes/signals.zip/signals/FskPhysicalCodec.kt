package com.example.methodmesh.modules.signals

import java.nio.charset.StandardCharsets
import kotlin.math.roundToInt

/**
 * Slow, deliberately simple binary-FSK framing used on top of MMS/1.
 *
 * Physical framing is only for symbol synchronisation. MMS/1 remains the data
 * integrity/recovery layer and validates every decoded ASCII frame itself.
 */
object FskPhysicalCodec {
    private val PREAMBLE = ByteArray(8) { 0x55.toByte() }
    private val SYNC = byteArrayOf(0xD3.toByte(), 0x91.toByte())
    const val MAX_FRAME_BYTES = 4096

    fun encodeFrame(frame: String): BooleanArray {
        val payload = frame.toByteArray(StandardCharsets.UTF_8)
        require(payload.size <= MAX_FRAME_BYTES) { "FSK frame is too large (${payload.size} bytes)." }
        val packet = ByteArray(PREAMBLE.size + SYNC.size + 2 + payload.size)
        var p = 0
        PREAMBLE.copyInto(packet, p); p += PREAMBLE.size
        SYNC.copyInto(packet, p); p += SYNC.size
        packet[p++] = ((payload.size ushr 8) and 0xFF).toByte()
        packet[p++] = (payload.size and 0xFF).toByte()
        payload.copyInto(packet, p)
        return bytesToBits(packet)
    }

    fun bytesToBits(bytes: ByteArray): BooleanArray {
        val bits = BooleanArray(bytes.size * 8)
        var j = 0
        bytes.forEach { raw ->
            val value = raw.toInt() and 0xFF
            for (shift in 7 downTo 0) bits[j++] = ((value ushr shift) and 1) != 0
        }
        return bits
    }

    fun bitsToByte(bits: List<Boolean>, offset: Int): Int {
        var value = 0
        for (i in 0 until 8) value = (value shl 1) or if (bits[offset + i]) 1 else 0
        return value
    }

    fun syncBits(): BooleanArray = bytesToBits(SYNC)
}

/** Scans an arbitrary bit stream for FSK sync words and extracts complete MMS/1 frames. */
class FskBitstreamParser {
    private val bits = ArrayList<Boolean>(16_384)
    private val sync = FskPhysicalCodec.syncBits()

    var framesExtracted: Int = 0
        private set
    var invalidLengths: Int = 0
        private set

    fun reset() {
        bits.clear()
        framesExtracted = 0
        invalidLengths = 0
    }

    fun feed(newBits: Iterable<Boolean>): List<String> {
        bits.addAll(newBits)
        val out = mutableListOf<String>()
        var cursor = 0
        while (true) {
            val syncAt = findSync(cursor)
            if (syncAt < 0) break
            val lengthAt = syncAt + sync.size
            if (bits.size < lengthAt + 16) {
                trimBefore(syncAt)
                break
            }
            val length = (readByte(lengthAt) shl 8) or readByte(lengthAt + 8)
            if (length <= 0 || length > FskPhysicalCodec.MAX_FRAME_BYTES) {
                invalidLengths++
                cursor = syncAt + 1
                continue
            }
            val payloadAt = lengthAt + 16
            val need = payloadAt + length * 8
            if (bits.size < need) {
                trimBefore(syncAt)
                break
            }
            val bytes = ByteArray(length)
            var bitAt = payloadAt
            for (i in bytes.indices) {
                bytes[i] = readByte(bitAt).toByte()
                bitAt += 8
            }
            out += bytes.toString(StandardCharsets.UTF_8)
            framesExtracted++
            bits.subList(0, need).clear()
            cursor = 0
        }
        // Avoid unbounded growth if we are listening to unrelated sound.
        if (bits.size > 65_536) bits.subList(0, bits.size - 4096).clear()
        return out
    }

    private fun findSync(from: Int): Int {
        if (bits.size < sync.size) return -1
        outer@ for (i in from..bits.size - sync.size) {
            for (j in sync.indices) if (bits[i + j] != sync[j]) continue@outer
            return i
        }
        return -1
    }

    private fun readByte(offset: Int): Int = FskPhysicalCodec.bitsToByte(bits, offset)

    private fun trimBefore(index: Int) {
        if (index > 0) bits.subList(0, index).clear()
    }
}

/**
 * Converts a noisy sequence of dominant FSK tones into runs of bits. The parser
 * does not need a global byte boundary because it scans for the sync word.
 */
class FskToneRunDecoder(private var bitMs: Int) {
    private var current: Boolean? = null
    private var runStartMs: Long = 0
    private var lastTimestampMs: Long = 0

    fun setBitMs(value: Int) { bitMs = value.coerceAtLeast(5) }

    fun reset() {
        current = null
        runStartMs = 0
        lastTimestampMs = 0
    }

    fun feed(tone: Boolean?, timestampMs: Long): List<Boolean> {
        if (lastTimestampMs == 0L) lastTimestampMs = timestampMs
        if (current == null) {
            current = tone
            runStartMs = timestampMs
            lastTimestampMs = timestampMs
            return emptyList()
        }
        lastTimestampMs = timestampMs
        if (tone == current) return emptyList()
        val emitted = emitRun(timestampMs)
        current = tone
        runStartMs = timestampMs
        return emitted
    }

    fun flush(timestampMs: Long = lastTimestampMs): List<Boolean> {
        val out = emitRun(timestampMs)
        current = null
        runStartMs = timestampMs
        return out
    }

    private fun emitRun(endMs: Long): List<Boolean> {
        val value = current ?: return emptyList()
        val duration = (endMs - runStartMs).coerceAtLeast(0L)
        if (duration < bitMs * 0.45) return emptyList()
        val count = (duration.toDouble() / bitMs).roundToInt().coerceIn(1, 1024)
        return List(count) { value }
    }
}
