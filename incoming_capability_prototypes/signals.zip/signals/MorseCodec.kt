package com.example.methodmesh.modules.signals

import kotlin.math.max

object MorseCodec {
    private val encodeMap: Map<Char, String> = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '/' to "-..-.",
        '=' to "-...-", '+' to ".-.-.", '-' to "-....-", '(' to "-.--.", ')' to "-.--.-",
        ':' to "---...", ';' to "-.-.-.", '@' to ".--.-."
    )
    private val decodeMap = encodeMap.entries.associate { (k, v) -> v to k }

    sealed interface Element {
        data class Mark(val symbol: Char, val units: Int, val sourceChar: Char) : Element
        data class Gap(val units: Int, val kind: GapKind) : Element
    }

    enum class GapKind { ELEMENT, LETTER, WORD, LOOP }

    fun encode(text: String): String = text
        .uppercase()
        .trim()
        .split(Regex("\\s+"))
        .joinToString(" / ") { word ->
            word.mapNotNull { encodeMap[it] }.joinToString(" ")
        }

    fun decode(notation: String): String = notation
        .trim()
        .split(Regex("\\s*/\\s*"))
        .joinToString(" ") { word ->
            word.trim().split(Regex("\\s+")).mapNotNull { decodeMap[it] }.joinToString("")
        }

    fun timeline(text: String, loopGapUnits: Int = 10): List<Element> {
        val words = text.uppercase().trim().split(Regex("\\s+")).filter(String::isNotBlank)
        val out = mutableListOf<Element>()
        words.forEachIndexed { wordIndex, word ->
            val supported = word.filter { encodeMap.containsKey(it) }
            supported.forEachIndexed { charIndex, char ->
                val code = encodeMap.getValue(char)
                code.forEachIndexed { markIndex, mark ->
                    out += Element.Mark(mark, if (mark == '.') 1 else 3, char)
                    if (markIndex < code.lastIndex) out += Element.Gap(1, GapKind.ELEMENT)
                }
                if (charIndex < supported.lastIndex) out += Element.Gap(3, GapKind.LETTER)
            }
            if (wordIndex < words.lastIndex) out += Element.Gap(7, GapKind.WORD)
        }
        if (out.isNotEmpty() && loopGapUnits > 0) out += Element.Gap(loopGapUnits, GapKind.LOOP)
        return out
    }

    fun dotDurationMs(wpm: Int): Long = (1200.0 / max(1, wpm)).toLong().coerceAtLeast(20L)

    fun decodeMark(durationMs: Long, dotMs: Long): Char? = when {
        durationMs < dotMs * 0.35 -> null
        durationMs < dotMs * 2.0 -> '.'
        durationMs < dotMs * 5.0 -> '-'
        else -> null
    }

    fun gapKind(durationMs: Long, dotMs: Long): GapKind = when {
        durationMs >= dotMs * 6 -> GapKind.WORD
        durationMs >= dotMs * 2 -> GapKind.LETTER
        else -> GapKind.ELEMENT
    }

    fun decodeSymbols(symbols: List<String>): String = symbols.mapNotNull { decodeMap[it] }.joinToString("")
}

/** Stateful transition-based decoder shared by lux, camera-luma and microphone Morse receivers. */
class MorseTimingDecoder(
    initialDotMs: Long = 120L,
    private val autoTiming: Boolean = true
) {
    data class Snapshot(
        val decodedText: String,
        val currentSymbols: String,
        val dotMs: Long,
        val pulsesSeen: Int,
        val quality: String
    )

    private var dotMs = initialDotMs.coerceAtLeast(20L)
    private var currentState = false
    private var lastTransitionMs: Long? = null
    private val pulseDurations = mutableListOf<Long>()
    private val dotEstimates = mutableListOf<Long>()
    private val currentSymbols = StringBuilder()
    private val decoded = StringBuilder()
    private var pulses = 0

    fun reset(nowMs: Long? = null) {
        currentState = false
        lastTransitionMs = nowMs
        pulseDurations.clear()
        dotEstimates.clear()
        currentSymbols.clear()
        decoded.clear()
        pulses = 0
    }

    fun update(isOn: Boolean, timestampMs: Long): Snapshot {
        val last = lastTransitionMs
        if (last == null) {
            currentState = isOn
            lastTransitionMs = timestampMs
            return snapshot()
        }
        if (isOn == currentState) return snapshot()

        val duration = (timestampMs - last).coerceAtLeast(1L)
        if (currentState) {
            MorseCodec.decodeMark(duration, dotMs)?.let { symbol ->
                currentSymbols.append(symbol)
                pulseDurations += duration
                // Normalise each classified mark to one Morse unit before adapting.
                // Otherwise dash-only traffic teaches the receiver that a dash is a dot.
                dotEstimates += if (symbol == '-') (duration / 3L).coerceAtLeast(1L) else duration
                pulses++
                if (autoTiming) updateDotEstimate()
            }
        } else {
            when (MorseCodec.gapKind(duration, dotMs)) {
                MorseCodec.GapKind.WORD -> {
                    flushLetter()
                    if (decoded.isNotEmpty() && decoded.last() != ' ') decoded.append(' ')
                }
                MorseCodec.GapKind.LETTER -> flushLetter()
                else -> Unit
            }
        }
        currentState = isOn
        lastTransitionMs = timestampMs
        return snapshot()
    }

    fun flush(timestampMs: Long): Snapshot {
        val last = lastTransitionMs
        if (last != null && !currentState) {
            val duration = timestampMs - last
            if (duration >= dotMs * 2) flushLetter()
        }
        return snapshot()
    }

    private fun flushLetter() {
        if (currentSymbols.isEmpty()) return
        val char = MorseCodec.decode(currentSymbols.toString())
        if (char.isNotBlank()) decoded.append(char)
        currentSymbols.clear()
    }

    private fun updateDotEstimate() {
        if (dotEstimates.size < 3) return
        val recent = dotEstimates.takeLast(24).sorted()
        val median = recent[recent.size / 2]
        if (median in 20..2000) dotMs = ((dotMs * 3 + median) / 4).coerceIn(20, 2000)
    }

    private fun snapshot(): Snapshot {
        val quality = when {
            pulses < 3 -> "Acquiring timing"
            pulseDurations.isEmpty() -> "Waiting"
            else -> "Tracking ~${dotMs} ms dot"
        }
        return Snapshot(decoded.toString(), currentSymbols.toString(), dotMs, pulses, quality)
    }
}
