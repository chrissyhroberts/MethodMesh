package com.example.methodmesh.modules.signals

import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.journeyapps.barcodescanner.DecoratedBarcodeView
import com.journeyapps.barcodescanner.DefaultDecoderFactory
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

class SignalTorchController(context: Context) {
    private val manager = context.applicationContext.getSystemService(CameraManager::class.java)
    private val cameraId: String? = manager?.cameraIdList?.firstOrNull { id ->
        val c = manager.getCameraCharacteristics(id)
        c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK &&
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    } ?: manager?.cameraIdList?.firstOrNull { id ->
        manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }

    val available: Boolean get() = cameraId != null

    fun set(enabled: Boolean) {
        val id = cameraId ?: return
        manager?.setTorchMode(id, enabled)
    }

    fun off() = runCatching { set(false) }
}

/** Relative centre-of-frame camera luminance. This is not calibrated illuminance. */
data class CameraLumaSample(val timestampMs: Long, val luma: Double)

class SignalCameraLumaAnalyzer(
    private val roiFraction: Double = 0.45,
    private val onSample: (CameraLumaSample) -> Unit
) : ImageAnalysis.Analyzer {
    private val main = Handler(Looper.getMainLooper())

    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes.firstOrNull() ?: return
            val w = image.width
            val h = image.height
            val rw = (w * roiFraction).toInt().coerceAtLeast(16)
            val rh = (h * roiFraction).toInt().coerceAtLeast(16)
            val x0 = ((w - rw) / 2).coerceAtLeast(0)
            val y0 = ((h - rh) / 2).coerceAtLeast(0)
            val x1 = minOf(w, x0 + rw)
            val y1 = minOf(h, y0 + rh)
            val buffer = plane.buffer
            var sum = 0.0
            var count = 0
            for (y in y0 until y1 step 4) {
                for (x in x0 until x1 step 4) {
                    val index = y * plane.rowStride + x * plane.pixelStride
                    if (index in 0 until buffer.limit()) {
                        sum += (buffer.get(index).toInt() and 0xFF)
                        count++
                    }
                }
            }
            if (count > 0) {
                val sample = CameraLumaSample(System.currentTimeMillis(), sum / count)
                main.post { onSample(sample) }
            }
        } finally {
            image.close()
        }
    }
}

@Composable
fun SignalCameraLumaPreview(
    modifier: Modifier = Modifier,
    onSample: (CameraLumaSample) -> Unit,
    onError: (String) -> Unit
) {
    val currentSample by rememberUpdatedState(onSample)
    val currentError by rememberUpdatedState(onError)
    val analysisExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    val previewViewHolder = remember { arrayOfNulls<PreviewView>(1) }
    val providerHolder = remember { arrayOfNulls<ProcessCameraProvider>(1) }

    Box(modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PreviewView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    previewViewHolder[0] = this
                    val owner = context.findLifecycleOwner()
                    if (owner == null) {
                        currentError("Camera preview could not find an Android lifecycle owner.")
                    } else {
                        val future = ProcessCameraProvider.getInstance(context)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                providerHolder[0] = provider
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(surfaceProvider) }
                                val analysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also { it.setAnalyzer(analysisExecutor, SignalCameraLumaAnalyzer(onSample = { sample -> currentSample(sample) })) }
                                provider.unbindAll()
                                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                            }.onFailure { currentError(it.message ?: "Camera receiver failed to start.") }
                        }, ContextCompat.getMainExecutor(context))
                    }
                }
            }
        )
        Canvas(Modifier.fillMaxSize()) {
            val fraction = 0.45f
            val w = size.width * fraction
            val h = size.height * fraction
            val left = (size.width - w) / 2f
            val top = (size.height - h) / 2f
            drawRect(
                color = SignalAmber.copy(alpha = 0.88f),
                topLeft = Offset(left, top),
                size = Size(w, h),
                style = Stroke(width = 3f)
            )
            val cx = size.width / 2f
            val cy = size.height / 2f
            drawLine(SignalAmber.copy(alpha = 0.7f), Offset(cx - 22f, cy), Offset(cx + 22f, cy), strokeWidth = 2f)
            drawLine(SignalAmber.copy(alpha = 0.7f), Offset(cx, cy - 22f), Offset(cx, cy + 22f), strokeWidth = 2f)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { providerHolder[0]?.unbindAll() }
            analysisExecutor.shutdownNow()
        }
    }
}

/** Adaptive high/low detector for uncontrolled optical amplitude. */
class AdaptiveLevelDetector(
    private val minimumSpan: Double,
    private val hysteresisFraction: Double = 0.10
) {
    private var low = Double.POSITIVE_INFINITY
    private var high = Double.NEGATIVE_INFINITY
    private var state: Boolean? = null

    data class Detection(val state: Boolean?, val low: Double, val high: Double, val threshold: Double, val span: Double)

    fun reset() {
        low = Double.POSITIVE_INFINITY
        high = Double.NEGATIVE_INFINITY
        state = null
    }

    fun feed(value: Double): Detection {
        if (!value.isFinite()) return Detection(state, low, high, Double.NaN, Double.NaN)
        if (!low.isFinite()) low = value
        if (!high.isFinite()) high = value
        if (value < low) low = value else low += (value - low) * 0.003
        if (value > high) high = value else high += (value - high) * 0.003
        if (high < low) high = low
        val span = high - low
        val threshold = (high + low) / 2.0
        if (span >= minimumSpan) {
            val hysteresis = max(minimumSpan * 0.05, span * hysteresisFraction)
            state = when (state) {
                true -> value >= threshold - hysteresis
                false -> value > threshold + hysteresis
                null -> value > threshold
            }
        }
        return Detection(state, low, high, threshold, span)
    }
}

object SignalQrRenderer {
    fun bitmap(payload: String, sizePx: Int = 900): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.MARGIN to 2,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val matrix = QRCodeWriter().encode(payload, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
        val pixels = IntArray(sizePx * sizePx)
        val black = 0xFF000000.toInt()
        val white = 0xFFFFFFFF.toInt()
        for (y in 0 until sizePx) for (x in 0 until sizePx) pixels[y * sizePx + x] = if (matrix[x, y]) black else white
        return Bitmap.createBitmap(pixels, sizePx, sizePx, Bitmap.Config.ARGB_8888)
    }
}

@Composable
fun SignalQrScanner(
    modifier: Modifier = Modifier,
    onPayload: (String) -> Unit,
    onError: (String) -> Unit
) {
    val currentPayload by rememberUpdatedState(onPayload)
    val currentError by rememberUpdatedState(onError)
    val viewHolder = remember { arrayOfNulls<DecoratedBarcodeView>(1) }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { context ->
            DecoratedBarcodeView(context).apply {
                viewHolder[0] = this
                barcodeView.decoderFactory = DefaultDecoderFactory(listOf(BarcodeFormat.QR_CODE))
                statusView.text = "Collecting MethodMesh QR frames"
                decodeContinuous(object : BarcodeCallback {
                    override fun barcodeResult(result: BarcodeResult?) {
                        val text = result?.text.orEmpty()
                        if (text.isNotBlank()) currentPayload(text)
                    }
                    override fun possibleResultPoints(resultPoints: MutableList<com.google.zxing.ResultPoint>?) = Unit
                })
                runCatching { resume() }.onFailure { currentError(it.message ?: "QR receiver failed to start.") }
            }
        }
    )

    DisposableEffect(Unit) {
        onDispose { runCatching { viewHolder[0]?.pause() } }
    }
}

private fun Context.findLifecycleOwner(): LifecycleOwner? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is LifecycleOwner) return current
        current = current.baseContext
    }
    return current as? LifecycleOwner
}
