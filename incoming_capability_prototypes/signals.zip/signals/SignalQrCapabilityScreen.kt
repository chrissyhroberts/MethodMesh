package com.example.methodmesh.modules.signals

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONArray
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

object SignalQrTransmitCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalQrTransmitMethod.id
    override val title = "QR burst transmitter"
    override val description = "Cycle an MMS/1 message through independently recoverable QR frames."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val activity = remember(androidContext) { androidContext.signalActivity() }
        val settings = context.action.settings
        var payload by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("payload", "Hello from MethodMesh")) }
        var robustness by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("robustness", "robust")) }
        var shardBytes by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("shard_bytes", "96").toIntOrNull()?.coerceIn(24, 256) ?: 96) }
        var dwellMs by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("frame_duration_ms", "650").toIntOrNull()?.coerceIn(150, 3000) ?: 650) }
        var loop by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("loop", "true").toBooleanStrictOrNull() ?: true) }
        var messageId by rememberSaveable(context.action.canonicalId) { mutableStateOf(SignalPacketCodec.newMessageId()) }
        var active by remember { mutableStateOf(false) }
        var frameIndex by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var cycles by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Prepare a message, then start the burst.") }
        var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }

        val encodedAttempt = remember(payload, robustness, shardBytes, messageId) {
            runCatching {
                SignalPacketCodec.encodeText(
                    payload,
                    SignalPacketCodec.Robustness.from(robustness),
                    shardBytes,
                    messageId
                )
            }
        }
        val encoded = encodedAttempt.getOrNull()
        val encodeError = encodedAttempt.exceptionOrNull()?.message.orEmpty()
        val frames = encoded?.frames.orEmpty()
        if (frameIndex !in frames.indices && frames.isNotEmpty()) frameIndex = 0
        val currentFrame = frames.getOrNull(frameIndex).orEmpty()
        val qrBitmap = remember(currentFrame) { currentFrame.takeIf(String::isNotBlank)?.let { SignalQrRenderer.bitmap(it) } }

        LaunchedEffect(payload, robustness, shardBytes, dwellMs, loop) {
            context.onSettingsChanged(
                mapOf(
                    "payload" to payload,
                    "robustness" to robustness,
                    "shard_bytes" to shardBytes.toString(),
                    "frame_duration_ms" to dwellMs.toString(),
                    "loop" to loop.toString()
                )
            )
        }

        LaunchedEffect(Unit) {
            if (!active && status.startsWith("Burst running", ignoreCase = true)) {
                status = if (cycles > 0)
                    "QR burst paused after screen recreation; $cycles complete cycle(s) retained."
                else
                    "QR burst paused after screen recreation. Start again when ready."
            }
        }

        LaunchedEffect(active, frames, dwellMs, loop) {
            if (!active || frames.isEmpty()) return@LaunchedEffect
            while (active) {
                delay(dwellMs.toLong())
                if (!active) break
                if (frameIndex >= frames.lastIndex) {
                    cycles++
                    frameIndex = 0
                    status = "QR cycle $cycles complete${if (loop) " — looping" else ""}."
                    if (!loop) {
                        active = false
                        break
                    }
                } else {
                    frameIndex++
                }
            }
        }

        fun start() {
            error = encodeError
            if (encoded == null || frames.isEmpty()) {
                if (error.isBlank()) error = "Message could not be encoded."
                return
            }
            active = true
            frameIndex = 0
            cycles = 0
            status = "Burst running. A receiver can join at any point."
            error = ""
        }

        fun stop() {
            active = false
            status = if (cycles > 0) "Stopped after $cycles complete cycle(s)." else "Stopped before a complete cycle."
        }

        fun commit() {
            val packet = encoded
            if (packet == null || cycles <= 0) {
                error = "Complete at least one QR cycle before Commit."
                return
            }
            active = false
            val values = mapOf(
                SignalQrTransmitFields.RESULT to payload,
                SignalQrTransmitFields.PAYLOAD to payload,
                SignalQrTransmitFields.MESSAGE_ID to packet.messageId,
                SignalQrTransmitFields.DATA_SHARDS to packet.dataShardCount.toString(),
                SignalQrTransmitFields.PARITY_FRAMES to packet.parityFrameCount.toString(),
                SignalQrTransmitFields.FRAME_COUNT to packet.frames.size.toString(),
                SignalQrTransmitFields.MESSAGE_CRC32 to packet.messageCrc32Hex,
                SignalQrTransmitFields.ROBUSTNESS to robustness,
                SignalQrTransmitFields.CYCLES to cycles.toString(),
                SignalQrTransmitFields.STATUS to "sent",
                SignalQrTransmitFields.ERROR to ""
            )
            committedJson = fieldsJson(values)
            status = "Committed. The frozen record describes the message and completed burst cycles."
            val result = signalResult(As100SignalQrTransmitMethod, context, values)
            if (context.submitsImmediately) onConfirmed(result)
        }

        DisposableEffect(activity, active) {
            val window = activity?.window
            val previous = window?.attributes?.screenBrightness
            if (window != null && active) {
                val attrs = window.attributes
                attrs.screenBrightness = 1f
                window.attributes = attrs
            }
            onDispose {
                if (window != null && previous != null) {
                    val attrs = window.attributes
                    attrs.screenBrightness = previous
                    window.attributes = attrs
                }
            }
        }

        val committedFields = fieldsFromJson(committedJson)
        val committedResult = remember(committedJson) { committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(As100SignalQrTransmitMethod, context, it) } }
        val committedFullJson = remember(committedJson) { fullJson(committedResult) }

        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SignalInstrumentPanel(
                kicker = "MMS/1 OPTICAL MODEM",
                title = "QR burst transmitter",
                accent = SignalCyan,
                badge = if (active) "Transmitting" else "Standby"
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.28f)
                        .background(Color.White, RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "Current MMS/1 QR frame",
                            modifier = Modifier.fillMaxSize().padding(10.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text("BUILDING OPTICAL FRAME", color = SignalBlack, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("FRAME", if (frames.isEmpty()) "—" else "${frameIndex + 1}/${frames.size}", SignalCyan, Modifier.weight(1f))
                    SignalTelemetryTile("CYCLE", (cycles + if (active) 1 else 0).toString(), SignalCyan, Modifier.weight(1f))
                    SignalTelemetryTile("DWELL", "$dwellMs ms", SignalCyan, Modifier.weight(1f))
                }
                encoded?.let { packet ->
                    val total = (packet.dataShardCount + packet.parityFrameCount).coerceAtLeast(1)
                    Text(
                        "${packet.dataShardCount} source + ${packet.parityFrameCount} repair • ${robustness.uppercase()} • CRC ${packet.messageCrc32Hex}",
                        color = SignalMuted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.clickable { copySignalValue(androidContext, "message CRC", packet.messageCrc32Hex) }
                    )
                    SignalProgressTrack((frameIndex + 1f) / total.toFloat(), SignalCyan)
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (active) stop() else start() }, enabled = frames.isNotEmpty(), modifier = Modifier.weight(1f)) { Text(if (active) "Stop burst" else "Start burst") }
                Button(onClick = ::commit, enabled = cycles > 0, modifier = Modifier.weight(1f)) { Text(if (committedResult == null) "Commit" else "Recommit") }
            }

            if (committedResult != null && !context.submitsImmediately) {
                SignalCommittedCard(
                    title = "Committed QR burst",
                    primaryLabel = "message",
                    primaryValue = committedFields[SignalQrTransmitFields.RESULT].orEmpty(),
                    fields = listOf(
                        "Message ID" to committedFields[SignalQrTransmitFields.MESSAGE_ID].orEmpty(),
                        "Frames" to committedFields[SignalQrTransmitFields.FRAME_COUNT].orEmpty(),
                        "CRC32" to committedFields[SignalQrTransmitFields.MESSAGE_CRC32].orEmpty(),
                        "Reliability" to committedFields[SignalQrTransmitFields.ROBUSTNESS].orEmpty(),
                        "Cycles" to committedFields[SignalQrTransmitFields.CYCLES].orEmpty()
                    ),
                    status = exportStatus,
                    onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                    onShare = { exportStatus = shareSignalText(androidContext, "Share QR burst payload", committedFields[SignalQrTransmitFields.RESULT].orEmpty()) ?: "" },
                    onSave = { exportStatus = saveSignalText(androidContext, "qr_burst_transmission", committedFields[SignalQrTransmitFields.RESULT].orEmpty(), committedFullJson) },
                    onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, "qr_burst_transmission", committedFields[SignalQrTransmitFields.RESULT].orEmpty(), committedFullJson) } }
                )
            }

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Message & reliability", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (context.settingShouldBeShown("payload")) OutlinedTextField(payload, { payload = it; cycles = 0; messageId = SignalPacketCodec.newMessageId() }, enabled = !active, modifier = Modifier.fillMaxWidth(), label = { Text("Message") })
                    if (context.settingShouldBeShown("robustness")) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("fast", "robust", "extreme").forEach { item -> FilterChip(selected = robustness == item, enabled = !active, onClick = { robustness = item; cycles = 0; messageId = SignalPacketCodec.newMessageId() }, label = { Text(item.replaceFirstChar { it.uppercase() }) }) }
                        }
                    }
                    if (context.settingShouldBeShown("shard_bytes")) {
                        Text("Shard size: $shardBytes bytes")
                        Slider(shardBytes.toFloat(), { shardBytes = (it.roundToInt() / 8 * 8).coerceIn(24, 256); cycles = 0; messageId = SignalPacketCodec.newMessageId() }, enabled = !active, valueRange = 24f..256f)
                    }
                    if (context.settingShouldBeShown("frame_duration_ms")) {
                        Text("Frame dwell: $dwellMs ms")
                        Slider(dwellMs.toFloat(), { dwellMs = (it.roundToInt() / 50 * 50).coerceIn(150, 3000); cycles = 0 }, enabled = !active, valueRange = 150f..3000f)
                    }
                    if (context.settingShouldBeShown("loop")) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Loop continuously"); Text("Allows mid-stream receiver join", style = MaterialTheme.typography.bodySmall) }
                            Switch(loop, { loop = it; cycles = 0 }, enabled = !active)
                        }
                    }
                }
            }

            if (encodeError.isNotBlank()) Text(encodeError, color = MaterialTheme.colorScheme.error)
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (committedResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            }
        }

        if (active && qrBitmap != null) {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false,
                    usePlatformDefaultWidth = false,
                    decorFitsSystemWindows = false
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                        .navigationBarsPadding()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("MMS/1 OPTICAL TRANSMITTER", color = SignalCyan, fontWeight = FontWeight.Bold)
                            Text("Frame ${frameIndex + 1}/${frames.size} • cycle ${cycles + 1}", color = SignalMuted, fontFamily = FontFamily.Monospace)
                        }
                        SignalStatusPill("On air", SignalCyan)
                    }
                    Box(Modifier.fillMaxWidth().weight(1f).background(Color.White, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "Full-screen MMS/1 QR frame",
                            modifier = Modifier.fillMaxSize().padding(12.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                    Button(onClick = ::stop, modifier = Modifier.fillMaxWidth()) { Text("Stop transmission") }
                }
            }
        }
    }
}

object SignalQrReceiveCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalQrReceiveMethod.id
    override val title = "QR burst receiver"
    override val description = "Collect QR shards continuously and recover an MMS/1 message when enough independent frames arrive."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val androidContext = LocalContext.current
        val settings = context.action.settings
        var messageFilter by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("message_id_filter", "")) }
        var listening by remember { mutableStateOf(false) }
        var frameStoreJson by rememberSaveable(context.action.canonicalId) { mutableStateOf("[]") }
        var framesSeen by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var unrelatedFrames by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Start the camera receiver and point it at a MethodMesh QR burst.") }
        var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var cameraGranted by remember { mutableStateOf(qrHasPermission(androidContext, Manifest.permission.CAMERA)) }

        val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            cameraGranted = granted || qrHasPermission(androidContext, Manifest.permission.CAMERA)
            if (cameraGranted) listening = true else error = "Camera permission is required for the QR receiver."
        }

        fun storedFrames(raw: String = frameStoreJson): MutableList<String> = runCatching {
            val array = JSONArray(raw)
            MutableList(array.length()) { index -> array.optString(index) }
        }.getOrDefault(mutableListOf())

        fun collectorFrom(raw: String = frameStoreJson): SignalFrameCollector = SignalFrameCollector().also { collector ->
            storedFrames(raw).forEach(collector::offer)
        }

        val collectorState = remember(frameStoreJson) { collectorFrom().state() }

        LaunchedEffect(Unit) {
            if (!listening && status.startsWith("Scanning", ignoreCase = true)) {
                status = if (collectorState.requiredRank > 0)
                    "Camera paused after screen recreation; ${collectorState.rank} / ${collectorState.requiredRank} retained shards."
                else
                    "Camera paused after screen recreation. Start the receiver again."
            }
        }

        fun clearReception(preserveCommitted: Boolean = false) {
            listening = false
            frameStoreJson = "[]"
            framesSeen = 0
            unrelatedFrames = 0
            if (!preserveCommitted) {
                committedJson = null
                exportStatus = ""
            }
            status = if (preserveCommitted)
                "Receiver filter changed; working shards were cleared. Any committed result remains frozen."
            else
                "Receiver reset."
            error = ""
        }

        fun acceptQr(text: String) {
            if (!listening) return
            framesSeen++
            val parsed = SignalPacketCodec.parse(text)
            val frame = parsed.frame
            if (frame == null) {
                unrelatedFrames++
                status = "QR seen, but it is not a valid MMS/1 frame."
                return
            }
            if (messageFilter.isNotBlank() && frame.messageId != messageFilter.trim()) {
                unrelatedFrames++
                status = "Ignoring MMS/1 message ${frame.messageId}; filter is ${messageFilter.trim()}."
                return
            }
            val frames = storedFrames()
            if (text !in frames) frames += text
            val newJson = JSONArray().also { array -> frames.forEach(array::put) }.toString()
            frameStoreJson = newJson
            val state = collectorFrom(newJson).state()
            status = when {
                state.complete -> "Message recovered. CRC verified${if (state.recoveredMissingSources > 0) "; ${state.recoveredMissingSources} missing source shard(s) reconstructed" else ""}."
                state.requiredRank > 0 -> "Collecting ${state.rank} / ${state.requiredRank} independent shards."
                else -> "Acquiring message geometry…"
            }
            if (state.complete) listening = false
        }

        fun start() {
            error = ""
            if (!cameraGranted) {
                cameraPermission.launch(Manifest.permission.CAMERA)
                return
            }
            listening = true
            status = if (collectorState.requiredRank > 0) "Resuming ${collectorState.rank} / ${collectorState.requiredRank} shards." else "Scanning continuously…"
        }

        fun commit() {
            val state = collectorFrom().state()
            val text = state.text.orEmpty()
            if (!state.complete || text.isBlank()) {
                error = "The message is not yet recoverable. Keep collecting QR frames."
                return
            }
            listening = false
            val values = mapOf(
                SignalQrReceiveFields.RESULT to text,
                SignalQrReceiveFields.MESSAGE_ID to state.messageId.orEmpty(),
                SignalQrReceiveFields.FRAMES_SEEN to framesSeen.toString(),
                SignalQrReceiveFields.FRAMES_ACCEPTED to state.acceptedFrames.toString(),
                SignalQrReceiveFields.FRAMES_REJECTED to (state.rejectedFrames + unrelatedFrames).toString(),
                SignalQrReceiveFields.RECOVERED_MISSING to state.recoveredMissingSources.toString(),
                SignalQrReceiveFields.CRC_VERIFIED to state.messageCrcVerified.toString(),
                SignalQrReceiveFields.STATUS to "received",
                SignalQrReceiveFields.ERROR to ""
            )
            committedJson = fieldsJson(values)
            status = "Committed."
            val result = signalResult(As100SignalQrReceiveMethod, context, values)
            if (context.submitsImmediately) onConfirmed(result)
        }

        LaunchedEffect(messageFilter) { context.onSettingsChanged(mapOf("message_id_filter" to messageFilter)) }

        val committedFields = fieldsFromJson(committedJson)
        val committedResult = remember(committedJson) { committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(As100SignalQrReceiveMethod, context, it) } }
        val committedFullJson = remember(committedJson) { fullJson(committedResult) }

        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SignalInstrumentPanel(
                kicker = "MMS/1 OPTICAL COLLECTOR",
                title = "QR burst receiver",
                accent = SignalCyan,
                badge = when { collectorState.complete -> "Recovered"; listening -> "Scanning"; else -> "Paused" }
            ) {
                Text(
                    collectorState.text?.ifBlank { null } ?: if (collectorState.requiredRank > 0) "${collectorState.rank} / ${collectorState.requiredRank} SHARDS" else "WAITING FOR MMS/1",
                    color = if (collectorState.text.isNullOrBlank()) SignalMuted else SignalText,
                    style = MaterialTheme.typography.headlineSmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = collectorState.text?.isNotBlank() == true) { copySignalValue(androidContext, "received text", collectorState.text.orEmpty()) }
                )
                if (collectorState.requiredRank > 0) {
                    SignalProgressTrack(collectorState.rank.toFloat() / collectorState.requiredRank.toFloat(), SignalCyan)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("SEEN", framesSeen.toString(), SignalCyan, Modifier.weight(1f))
                    SignalTelemetryTile("ACCEPTED", collectorState.acceptedFrames.toString(), SignalCyan, Modifier.weight(1f))
                    SignalTelemetryTile("REJECTED", (collectorState.rejectedFrames + unrelatedFrames).toString(), SignalCyan, Modifier.weight(1f))
                }
                collectorState.messageId?.takeIf(String::isNotBlank)?.let { id ->
                    Text("MESSAGE $id", color = SignalMuted, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace, modifier = Modifier.clickable { copySignalValue(androidContext, "message ID", id) })
                }
            }

            if (listening && cameraGranted) {
                Card(Modifier.fillMaxWidth().height(300.dp), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SignalBlack)) {
                    SignalQrScanner(onPayload = ::acceptQr, onError = { error = it; listening = false })
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (listening) { listening = false; status = "Paused. Collected shards are retained." } else start() }, modifier = Modifier.weight(1f)) { Text(if (listening) "Pause" else "Start camera") }
                Button(onClick = ::commit, enabled = collectorState.complete, modifier = Modifier.weight(1f)) { Text(if (committedResult == null) "Commit" else "Recommit") }
                OutlinedButton(onClick = ::clearReception) { Text("Reset") }
            }

            if (committedResult != null && !context.submitsImmediately) {
                SignalCommittedCard(
                    title = "Committed QR reception",
                    primaryLabel = "received text",
                    primaryValue = committedFields[SignalQrReceiveFields.RESULT].orEmpty(),
                    fields = listOf(
                        "Message ID" to committedFields[SignalQrReceiveFields.MESSAGE_ID].orEmpty(),
                        "Frames seen" to committedFields[SignalQrReceiveFields.FRAMES_SEEN].orEmpty(),
                        "Recovered missing" to committedFields[SignalQrReceiveFields.RECOVERED_MISSING].orEmpty(),
                        "CRC verified" to committedFields[SignalQrReceiveFields.CRC_VERIFIED].orEmpty()
                    ),
                    status = exportStatus,
                    onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                    onShare = { exportStatus = shareSignalText(androidContext, "Share recovered message", committedFields[SignalQrReceiveFields.RESULT].orEmpty()) ?: "" },
                    onSave = { exportStatus = saveSignalText(androidContext, "qr_burst_reception", committedFields[SignalQrReceiveFields.RESULT].orEmpty(), committedFullJson) },
                    onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, "qr_burst_reception", committedFields[SignalQrReceiveFields.RESULT].orEmpty(), committedFullJson) } }
                )
            }

            if (context.settingShouldBeShown("message_id_filter")) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        OutlinedTextField(messageFilter, { next -> if (next != messageFilter) { messageFilter = next; clearReception(preserveCommitted = true) } }, enabled = !listening, modifier = Modifier.fillMaxWidth(), label = { Text("Optional message ID filter") }, supportingText = { Text("Leave blank to accept the first MMS/1 message encountered. Changing the filter resets collected frames.") })
                    }
                }
            }
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (committedResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            }
        }
    }
}

private fun qrHasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
