package com.example.methodmesh.modules.signals

import kotlin.math.roundToLong
import kotlin.random.Random

/**
 * Standalone JVM smoke test for the pure Signals codecs.
 *
 * Run from a MethodMesh checkout or beside these sources, for example:
 * kotlinc SignalPacketCodec.kt MorseCodec.kt FskPhysicalCodec.kt docs/SignalCodecSmoke.kt -include-runtime -d /tmp/signals-smoke.jar
 * java -jar /tmp/signals-smoke.jar
 */
fun main() {
    var assertions = 0
    fun requireSmoke(condition: Boolean, message: String) {
        assertions++
        if (!condition) error(message)
    }

    requireSmoke(MorseCodec.encode("SOS") == "... --- ...", "Morse encode")
    requireSmoke(MorseCodec.decode("... --- ...") == "SOS", "Morse decode")
    requireSmoke(MorseCodec.dotDurationMs(12) == 100L, "Morse PARIS dot")

    fun simulateMorse(text: String, actualDotMs: Long, initialDotMs: Long, jitter: Double = 0.0): MorseTimingDecoder.Snapshot {
        val random = Random(text.hashCode() xor actualDotMs.toInt() xor initialDotMs.toInt())
        val decoder = MorseTimingDecoder(initialDotMs, autoTiming = true)
        var now = 0L
        decoder.reset(now)
        fun duration(base: Long): Long {
            if (jitter <= 0.0) return base
            val scale = 1.0 + (random.nextDouble() * 2.0 - 1.0) * jitter
            return (base * scale).roundToLong().coerceAtLeast(1L)
        }
        MorseCodec.timeline(text, loopGapUnits = 0).forEach { element ->
            when (element) {
                is MorseCodec.Element.Mark -> {
                    now += 1
                    decoder.update(true, now)
                    now += duration(actualDotMs * element.units)
                    decoder.update(false, now)
                }
                is MorseCodec.Element.Gap -> now += duration(actualDotMs * element.units)
            }
        }
        return decoder.flush(now + actualDotMs * 7)
    }

    listOf(80L, 120L, 200L).forEach { actual ->
        listOf(0.7, 1.0, 1.4).forEach { factor ->
            val snapshot = simulateMorse("FIELD TEST 123", actual, (actual * factor).roundToLong(), jitter = 0.08)
            requireSmoke(snapshot.decodedText.trim() == "FIELD TEST 123", "Morse adaptive actual=$actual factor=$factor: $snapshot")
        }
    }
    listOf("OOO", "EEEE", "TTT", "SOS").forEach { text ->
        val snapshot = simulateMorse(text, 100, 100, jitter = 0.05)
        requireSmoke(snapshot.decodedText.trim() == text, "Morse edge traffic $text: $snapshot")
    }

    // Physical FSK frame parser: arbitrary leading bits and chunk boundaries.
    val physicalPayload = "MMS1|TEST|1|1|00000000|0|QQ|00000000"
    val physicalBits = FskPhysicalCodec.encodeFrame(physicalPayload)
    val parser = FskBitstreamParser()
    var parsedFrames = emptyList<String>()
    parsedFrames += parser.feed(listOf(true, false, true, true, false) + physicalBits.take(31))
    parsedFrames += parser.feed(physicalBits.drop(31).take(53).asIterable())
    parsedFrames += parser.feed(physicalBits.drop(84).asIterable())
    requireSmoke(parsedFrames == listOf(physicalPayload), "FSK chunked physical framing")

    // Tone-run decoder: simulate exact dominant-tone samples in 10 ms windows.
    listOf(20, 30, 40, 50, 60, 80, 100, 150).forEach { bitMs ->
        val sourceBits = listOf(true, true, false, true, false, false, false, true)
        val decoder = FskToneRunDecoder(bitMs)
        var now = 1_000L
        val emitted = mutableListOf<Boolean>()
        sourceBits.forEach { bit ->
            val samples = (bitMs / 10.0).roundToLong().coerceAtLeast(1L).toInt()
            repeat(samples) {
                emitted += decoder.feed(bit, now)
                now += 10L
            }
        }
        emitted += decoder.flush(now)
        requireSmoke(emitted == sourceBits, "FSK run decode bitMs=$bitMs emitted=$emitted")
    }

    val random = Random(0x51A1)
    val shardWidths = listOf(24, 32, 48, 64, 96, 128, 256)
    val profiles = SignalPacketCodec.Robustness.values()
    repeat(250) { trial ->
        val shardBytes = shardWidths[trial % shardWidths.size]
        val maxLength = SignalPacketCodec.MAX_DATA_SHARDS * shardBytes
        val length = when (trial % 9) {
            0 -> 0
            1 -> 1
            2 -> 23.coerceAtMost(maxLength)
            3 -> 24.coerceAtMost(maxLength)
            4 -> 95.coerceAtMost(maxLength)
            5 -> 96.coerceAtMost(maxLength)
            6 -> 511.coerceAtMost(maxLength)
            7 -> 1024.coerceAtMost(maxLength)
            else -> random.nextInt(2, minOf(1800, maxLength).coerceAtLeast(3))
        }
        val payload = ByteArray(length) { random.nextInt(0, 256).toByte() }
        val profile = profiles[trial % profiles.size]
        val encoded = SignalPacketCodec.encode(payload, profile, shardBytes, "T${trial.toString().padStart(5, '0')}")
        val k = encoded.dataShardCount
        val m = encoded.frames.size
        requireSmoke(m >= k, "MMS frame count")
        encoded.frames.forEach { requireSmoke(SignalPacketCodec.parse(it).valid, "Generated frame must parse") }

        // Systematic, parity-heavy, random, and every loop-aligned consecutive k-window.
        val subsets = mutableListOf<List<String>>()
        subsets += encoded.frames.take(k)
        subsets += encoded.frames.takeLast(k)
        repeat(6) { subsets += encoded.frames.shuffled(random).take(k) }
        for (start in encoded.frames.indices) {
            subsets += List(k) { offset -> encoded.frames[(start + offset) % m] }
        }
        subsets.forEachIndexed { subsetIndex, subset ->
            val collector = SignalFrameCollector()
            subset.shuffled(random).forEach(collector::offer)
            val state = collector.state()
            requireSmoke(state.complete, "RS recovery trial=$trial subset=$subsetIndex profile=$profile k=$k: $state")
            requireSmoke(state.payload!!.contentEquals(payload), "RS payload trial=$trial subset=$subsetIndex")
            requireSmoke(state.messageCrcVerified, "RS whole-message CRC trial=$trial subset=$subsetIndex")
        }

        val duplicateCollector = SignalFrameCollector()
        val first = encoded.frames.first()
        duplicateCollector.offer(first)
        duplicateCollector.offer(first)
        duplicateCollector.offer(first)
        encoded.frames.drop(1).take(k - 1).forEach(duplicateCollector::offer)
        requireSmoke(duplicateCollector.state().complete, "Duplicate frames must not block reconstruction")
        requireSmoke(duplicateCollector.state().redundantFrames >= 2, "Duplicate count")

        // Mutate frame body without updating frame CRC: parser must reject it before RS.
        val chars = first.toCharArray()
        val firstSeparator = first.indexOf('|')
        val secondSeparator = first.indexOf('|', firstSeparator + 1)
        val mutateAt = (firstSeparator + 1).coerceAtMost(secondSeparator - 1)
        chars[mutateAt] = if (chars[mutateAt] == 'X') 'Y' else 'X'
        requireSmoke(!SignalPacketCodec.parse(chars.concatToString()).valid, "Frame CRC rejection")
    }

    println("Signals codec smoke PASS: $assertions assertions")
}
