package com.example.methodmesh.modules.signals

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.platform.sensors.PhoneSensorRepository
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

object SignalMorseTransmitCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalMorseTransmitMethod.id
    override val title = "Morse transmitter"
    override val description = "Flash or sound a Morse message, once or as a repeating beacon."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val activity = remember(androidContext) { androidContext.findActivity() }
        val scope = rememberCoroutineScope()
        val torch = remember(androidContext) { SignalTorchController(androidContext) }
        val settings = context.action.settings

        var payload by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("payload", "SOS")) }
        var route by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("route", "screen")) }
        var wpm by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("wpm", "12").toIntOrNull()?.coerceIn(3, 30) ?: 12) }
        var toneHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("tone_frequency_hz", "700").toFloatOrNull()?.coerceIn(200f, 4000f) ?: 700f) }
        var loopMode by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("loop_mode", "once")) }
        var repeatCount by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("repeat_count", "3").toIntOrNull()?.coerceIn(1, 100) ?: 3) }
        var loopGap by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("loop_gap_units", "10").toIntOrNull()?.coerceIn(3, 60) ?: 10) }

        var sending by remember { mutableStateOf(false) }
        var screenOn by remember { mutableStateOf(false) }
        var currentMark by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var completedCycles by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Ready") }
        var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var cameraGranted by remember { mutableStateOf(hasPermission(androidContext, Manifest.permission.CAMERA)) }
        var transmitJob by remember { mutableStateOf<Job?>(null) }

        val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            cameraGranted = granted || hasPermission(androidContext, Manifest.permission.CAMERA)
            if (!cameraGranted) error = "Camera permission is required for the rear torch route."
        }

        val notation = remember(payload) { MorseCodec.encode(payload) }
        val dotMs = MorseCodec.dotDurationMs(wpm)
        val usesTorch = route in setOf("torch", "torch_sound", "all")
        val usesSound = route in setOf("sound", "screen_sound", "torch_sound", "all")
        val usesScreen = route in setOf("screen", "screen_sound", "all")

        LaunchedEffect(payload, route, wpm, toneHz, loopMode, repeatCount, loopGap) {
            context.onSettingsChanged(
                mapOf(
                    "payload" to payload,
                    "route" to route,
                    "wpm" to wpm.toString(),
                    "tone_frequency_hz" to toneHz.roundToInt().toString(),
                    "loop_mode" to loopMode,
                    "repeat_count" to repeatCount.toString(),
                    "loop_gap_units" to loopGap.toString()
                )
            )
        }

        LaunchedEffect(Unit) {
            // Physical transmission does not survive Activity recreation. Persist the
            // working configuration/cycle count, but never pretend the emitter is still on.
            screenOn = false
            if (!sending && status.startsWith("Transmitting", ignoreCase = true)) {
                status = if (completedCycles > 0)
                    "Transmission paused after screen recreation; $completedCycles complete cycle(s) retained."
                else
                    "Transmission paused after screen recreation. Start again when ready."
            }
        }

        fun stopTransmission(userRequested: Boolean = true) {
            transmitJob?.cancel()
            transmitJob = null
            torch.off()
            screenOn = false
            currentMark = ""
            sending = false
            if (userRequested) status = if (completedCycles > 0) "Stopped after $completedCycles complete cycle(s)." else "Stopped."
        }

        fun startTransmission() {
            if (payload.isBlank() || notation.isBlank()) {
                error = "Enter at least one Morse-supported character."
                return
            }
            if (usesTorch && !torch.available) {
                error = "No rear-camera flash unit is available on this device."
                return
            }
            if (usesTorch && !cameraGranted) {
                cameraPermission.launch(Manifest.permission.CAMERA)
                return
            }
            stopTransmission(userRequested = false)
            error = ""
            exportStatus = ""
            completedCycles = 0
            sending = true
            status = "Transmitting…"
            val timeline = MorseCodec.timeline(payload, loopGap)
            val maxCycles = when (loopMode) {
                "continuous" -> Int.MAX_VALUE
                "count" -> repeatCount
                else -> 1
            }
            transmitJob = scope.launch {
                try {
                    var cycle = 0
                    while (isActive && cycle < maxCycles) {
                        timeline.forEach { element ->
                            if (!isActive) return@forEach
                            when (element) {
                                is MorseCodec.Element.Mark -> {
                                    val duration = dotMs * element.units
                                    currentMark = element.symbol.toString()
                                    if (usesScreen) screenOn = true
                                    if (usesTorch) runCatching { torch.set(true) }.onFailure { error = it.message ?: "Torch failed." }
                                    if (usesSound) {
                                        withContext(Dispatchers.IO) {
                                            SignalAudioOutput.playToneBlocking(toneHz.toDouble(), duration)
                                        }
                                    } else {
                                        delay(duration)
                                    }
                                    if (usesTorch) runCatching { torch.set(false) }
                                    screenOn = false
                                }
                                is MorseCodec.Element.Gap -> {
                                    currentMark = ""
                                    if (usesTorch) runCatching { torch.set(false) }
                                    screenOn = false
                                    delay(dotMs * element.units)
                                }
                            }
                        }
                        cycle++
                        completedCycles = cycle
                        status = if (maxCycles == Int.MAX_VALUE) "Looping — $cycle cycle(s) sent" else "$cycle / $maxCycles cycle(s) sent"
                    }
                } catch (errorValue: Throwable) {
                    if (isActive) error = errorValue.message ?: "Transmission failed."
                } finally {
                    torch.off()
                    screenOn = false
                    currentMark = ""
                    sending = false
                    if (completedCycles > 0 && loopMode != "continuous") status = "Transmission complete."
                }
            }
        }

        fun commit() {
            if (completedCycles <= 0) {
                error = "Complete at least one transmission cycle before Commit."
                return
            }
            stopTransmission(userRequested = false)
            val values = mapOf(
                SignalMorseTransmitFields.RESULT to payload,
                SignalMorseTransmitFields.PAYLOAD to payload,
                SignalMorseTransmitFields.NOTATION to notation,
                SignalMorseTransmitFields.ROUTE to route,
                SignalMorseTransmitFields.WPM to wpm.toString(),
                SignalMorseTransmitFields.REPETITIONS to completedCycles.toString(),
                SignalMorseTransmitFields.STATUS to "sent",
                SignalMorseTransmitFields.ERROR to ""
            )
            committedJson = fieldsJson(values)
            status = "Committed. Live settings remain editable; recommit after another transmission to replace the frozen result."
            val result = signalResult(As100SignalMorseTransmitMethod, context, values)
            if (context.submitsImmediately) onConfirmed(result)
        }

        DisposableEffect(activity, sending, usesScreen) {
            val window = activity?.window
            val previous = window?.attributes?.screenBrightness
            if (window != null && sending && usesScreen) {
                val attributes = window.attributes
                attributes.screenBrightness = 1f
                window.attributes = attributes
            }
            onDispose {
                if (window != null && previous != null) {
                    val attributes = window.attributes
                    attributes.screenBrightness = previous
                    window.attributes = attributes
                }
            }
        }

        DisposableEffect(Unit) { onDispose { stopTransmission(userRequested = false) } }

        val committedFields = fieldsFromJson(committedJson)
        val committedResult = remember(committedJson) {
            committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(As100SignalMorseTransmitMethod, context, it) }
        }
        val committedFullJson = remember(committedJson) { fullJson(committedResult) }

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SignalInstrumentPanel(
                kicker = "OPTICAL / AUDIO TELEGRAPH",
                title = "Morse beacon",
                accent = SignalAmber,
                badge = if (sending) "On air" else "Standby"
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(2.55f)
                        .background(if (screenOn) Color(0xFFFFFDF5) else SignalBlack, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (sending) currentMark.ifBlank { "·" } else "READY",
                        color = if (screenOn) SignalBlack else SignalAmber,
                        style = MaterialTheme.typography.displayMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    notation.ifBlank { "—" },
                    color = SignalText,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = notation.isNotBlank()) {
                        copySignalValue(androidContext, "Morse", notation)
                    }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("DOT", "$dotMs ms", SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("SPEED", "$wpm WPM", SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("CYCLES", completedCycles.toString(), SignalAmber, Modifier.weight(1f))
                }
                Text(
                    if (sending) "${route.replace('_', '+')} • ${if (loopMode == "continuous") "continuous beacon" else "transmitting"}" else status,
                    color = SignalMuted,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (sending) stopTransmission() else startTransmission() }, modifier = Modifier.weight(1f)) {
                    Text(if (sending) "Stop" else if (loopMode == "continuous") "Start beacon" else "Transmit")
                }
                Button(onClick = ::commit, enabled = completedCycles > 0, modifier = Modifier.weight(1f)) {
                    Text(if (committedResult == null) "Commit" else "Recommit")
                }
            }

            if (committedResult != null && !context.submitsImmediately) {
                SignalCommittedCard(
                    title = "Committed transmission",
                    primaryLabel = "message",
                    primaryValue = committedFields[SignalMorseTransmitFields.RESULT].orEmpty(),
                    fields = listOf(
                        "Morse" to committedFields[SignalMorseTransmitFields.NOTATION].orEmpty(),
                        "Route" to committedFields[SignalMorseTransmitFields.ROUTE].orEmpty(),
                        "WPM" to committedFields[SignalMorseTransmitFields.WPM].orEmpty(),
                        "Cycles" to committedFields[SignalMorseTransmitFields.REPETITIONS].orEmpty()
                    ),
                    status = exportStatus,
                    onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                    onShare = { exportStatus = shareSignalText(androidContext, "Share Morse message", committedFields[SignalMorseTransmitFields.RESULT].orEmpty()) ?: "" },
                    onSave = { exportStatus = saveSignalText(androidContext, "morse_transmission", committedFields[SignalMorseTransmitFields.RESULT].orEmpty(), committedFullJson) },
                    onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, "morse_transmission", committedFields[SignalMorseTransmitFields.RESULT].orEmpty(), committedFullJson) } }
                )
            }

            MorseTransmitSettings(
                context = context,
                sending = sending,
                payload = payload,
                onPayload = { next -> if (next != payload) { payload = next; completedCycles = 0 } },
                route = route,
                onRoute = { next -> if (next != route) { route = next; completedCycles = 0 } },
                wpm = wpm,
                onWpm = { next -> if (next != wpm) { wpm = next; completedCycles = 0 } },
                toneHz = toneHz,
                onToneHz = { next -> if (next != toneHz) { toneHz = next; completedCycles = 0 } },
                loopMode = loopMode,
                onLoopMode = { next -> if (next != loopMode) { loopMode = next; completedCycles = 0 } },
                repeatCount = repeatCount,
                onRepeatCount = { next -> if (next != repeatCount) { repeatCount = next; completedCycles = 0 } },
                loopGap = loopGap,
                onLoopGap = { next -> if (next != loopGap) { loopGap = next; completedCycles = 0 } }
            )

            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (committedResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            }
        }

        if (usesScreen && sending) {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false,
                    usePlatformDefaultWidth = false,
                    decorFitsSystemWindows = false
                )
            ) {
                Box(
                    modifier = Modifier.fillMaxSize().background(if (screenOn) Color.White else Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        currentMark.ifBlank { " " },
                        color = if (screenOn) Color.Black else Color.White,
                        style = MaterialTheme.typography.displayLarge,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black
                    )
                    Button(
                        onClick = { stopTransmission() },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp)
                    ) { Text("Stop") }
                }
            }
        }
    }
}

@Composable
private fun MorseTransmitSettings(
    sending: Boolean,
    context: CapabilityScreenContext,
    payload: String,
    onPayload: (String) -> Unit,
    route: String,
    onRoute: (String) -> Unit,
    wpm: Int,
    onWpm: (Int) -> Unit,
    toneHz: Float,
    onToneHz: (Float) -> Unit,
    loopMode: String,
    onLoopMode: (String) -> Unit,
    repeatCount: Int,
    onRepeatCount: (Int) -> Unit,
    loopGap: Int,
    onLoopGap: (Int) -> Unit
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Message & channel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (context.settingShouldBeShown("payload")) {
                OutlinedTextField(payload, onPayload, enabled = !sending, modifier = Modifier.fillMaxWidth(), label = { Text("Message") }, supportingText = { Text("Unsupported characters are skipped by the Morse encoder.") })
            }
            if (context.settingShouldBeShown("route")) {
                Text("Output")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("screen", "torch", "sound").forEach { item ->
                        FilterChip(selected = route == item, enabled = !sending, onClick = { onRoute(item) }, label = { Text(item.replaceFirstChar { it.uppercase() }) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("screen_sound", "torch_sound", "all").forEach { item ->
                        FilterChip(selected = route == item, enabled = !sending, onClick = { onRoute(item) }, label = { Text(item.replace('_', '+')) })
                    }
                }
            }
            if (context.settingShouldBeShown("wpm")) {
                Text("Speed: $wpm WPM")
                Slider(wpm.toFloat(), { onWpm(it.roundToInt().coerceIn(3, 30)) }, enabled = !sending, valueRange = 3f..30f, steps = 26)
            }
            if (context.settingShouldBeShown("tone_frequency_hz") && route.contains("sound")) {
                Text("Tone: ${toneHz.roundToInt()} Hz")
                Slider(toneHz, { onToneHz((it / 10f).roundToInt() * 10f) }, enabled = !sending, valueRange = 200f..4000f)
            }
            if (context.settingShouldBeShown("loop_mode")) {
                Text("Repeat")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("once", "count", "continuous").forEach { item ->
                        FilterChip(selected = loopMode == item, enabled = !sending, onClick = { onLoopMode(item) }, label = { Text(item.replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
            if (loopMode == "count" && context.settingShouldBeShown("repeat_count")) {
                Text("Cycles: $repeatCount")
                Slider(repeatCount.toFloat(), { onRepeatCount(it.roundToInt().coerceIn(1, 100)) }, enabled = !sending, valueRange = 1f..100f, steps = 98)
            }
            if (context.settingShouldBeShown("loop_gap_units") && loopMode != "once") {
                Text("Gap between cycles: $loopGap units")
                Slider(loopGap.toFloat(), { onLoopGap(it.roundToInt().coerceIn(3, 60)) }, enabled = !sending, valueRange = 3f..60f)
            }
        }
    }
}

object SignalMorseReceiveCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalMorseReceiveMethod.id
    override val title = "Morse receiver"
    override val description = "Decode Morse from light, camera brightness or an audible tone."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val settings = context.action.settings
        var source by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("source", "light_sensor")) }
        var dotMsSetting by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("dot_ms", "100").toLongOrNull()?.coerceIn(30, 1000) ?: 100L) }
        var autoTiming by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("auto_timing", "true").toBooleanStrictOrNull() ?: true) }
        var toneHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("microphone_tone_hz", "700").toDoubleOrNull()?.coerceIn(100.0, 10000.0) ?: 700.0) }
        var toneTolerance by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("microphone_tolerance_hz", "120").toDoubleOrNull()?.coerceIn(10.0, 2000.0) ?: 120.0) }
        var minDbfs by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("microphone_min_dbfs", "-35").toDoubleOrNull()?.coerceIn(-90.0, 0.0) ?: -35.0) }
        var listening by remember { mutableStateOf(false) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Choose a receiver and start listening.") }
        var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var levelText by remember { mutableStateOf("—") }
        var levelOn by remember { mutableStateOf(false) }
        var decodedText by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var currentSymbols by remember { mutableStateOf("") }
        var effectiveDotMs by rememberSaveable(context.action.canonicalId) { mutableStateOf(dotMsSetting) }
        var pulsesSeen by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var cameraGranted by remember { mutableStateOf(hasPermission(androidContext, Manifest.permission.CAMERA)) }
        var audioGranted by remember { mutableStateOf(hasPermission(androidContext, Manifest.permission.RECORD_AUDIO)) }

        val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { cameraGranted = it || hasPermission(androidContext, Manifest.permission.CAMERA) }
        val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioGranted = it || hasPermission(androidContext, Manifest.permission.RECORD_AUDIO) }

        val decoder = remember(dotMsSetting, autoTiming) { MorseTimingDecoder(dotMsSetting, autoTiming) }
        val lightDetector = remember { AdaptiveLevelDetector(minimumSpan = 1.0) }
        val cameraDetector = remember { AdaptiveLevelDetector(minimumSpan = 14.0) }
        val microphoneEngine = remember(androidContext) { SignalToneReceiverEngine(androidContext) }

        fun acceptSignal(on: Boolean, timestampMs: Long) {
            if (!listening) return
            levelOn = on
            val snapshot = decoder.update(on, timestampMs)
            decodedText = snapshot.decodedText
            currentSymbols = snapshot.currentSymbols
            effectiveDotMs = snapshot.dotMs
            pulsesSeen = snapshot.pulsesSeen
            status = snapshot.quality
        }

        fun invalidateWorkingReception() {
            decodedText = ""
            currentSymbols = ""
            effectiveDotMs = dotMsSetting
            pulsesSeen = 0
            levelOn = false
            levelText = "—"
            status = "Receiver settings changed; working decode was cleared. Any committed result remains frozen."
            error = ""
        }

        fun startListening() {
            error = ""
            if (source == "camera" && !cameraGranted) {
                cameraPermission.launch(Manifest.permission.CAMERA)
                return
            }
            if (source == "microphone" && !audioGranted) {
                audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                return
            }
            decoder.reset(System.currentTimeMillis())
            lightDetector.reset()
            cameraDetector.reset()
            decodedText = ""
            currentSymbols = ""
            pulsesSeen = 0
            effectiveDotMs = dotMsSetting
            listening = true
            status = "Listening…"
            if (source == "microphone") {
                microphoneEngine.start(
                    toneHz = toneHz,
                    toleranceHz = toneTolerance,
                    minimumDbfs = minDbfs,
                    onWindow = { window ->
                        levelText = "${toneHz.roundToInt()} Hz  ${"%.1f".format(Locale.US, window.dbfs)} dBFS  ${window.audioSource}"
                        acceptSignal(window.isOn, window.timestampMs)
                    },
                    onError = { error = it; listening = false }
                )
            }
        }

        fun stopListening() {
            if (source == "microphone") microphoneEngine.stop()
            val snapshot = decoder.flush(System.currentTimeMillis())
            decodedText = snapshot.decodedText
            currentSymbols = snapshot.currentSymbols
            effectiveDotMs = snapshot.dotMs
            pulsesSeen = snapshot.pulsesSeen
            listening = false
            levelOn = false
            status = if (decodedText.isBlank()) "Stopped — no complete Morse text decoded." else "Stopped — decoded text is ready to Commit."
        }

        fun commit() {
            if (decodedText.isBlank()) {
                error = "Decode at least one complete Morse character before Commit."
                return
            }
            if (listening) stopListening()
            val notation = MorseCodec.encode(decodedText)
            val values = mapOf(
                SignalMorseReceiveFields.RESULT to decodedText,
                SignalMorseReceiveFields.NOTATION to notation,
                SignalMorseReceiveFields.SOURCE to source,
                SignalMorseReceiveFields.DOT_MS to effectiveDotMs.toString(),
                SignalMorseReceiveFields.TRANSITIONS to pulsesSeen.toString(),
                SignalMorseReceiveFields.STATUS to "received",
                SignalMorseReceiveFields.ERROR to ""
            )
            committedJson = fieldsJson(values)
            status = "Committed. Continue listening only after starting a new reception."
            val result = signalResult(As100SignalMorseReceiveMethod, context, values)
            if (context.submitsImmediately) onConfirmed(result)
        }

        LaunchedEffect(source, dotMsSetting, autoTiming, toneHz, toneTolerance, minDbfs) {
            context.onSettingsChanged(
                mapOf(
                    "source" to source,
                    "dot_ms" to dotMsSetting.toString(),
                    "auto_timing" to autoTiming.toString(),
                    "microphone_tone_hz" to toneHz.roundToInt().toString(),
                    "microphone_tolerance_hz" to toneTolerance.roundToInt().toString(),
                    "microphone_min_dbfs" to minDbfs.toString()
                )
            )
        }

        LaunchedEffect(Unit) {
            // Camera/microphone/listener registrations are process objects, not saved UI
            // state. Preserve decoded working text but require an explicit restart.
            if (!listening && (status.startsWith("Listening", ignoreCase = true) || status.startsWith("Tracking", ignoreCase = true))) {
                status = if (decodedText.isBlank())
                    "Reception paused after screen recreation. Start listening again."
                else
                    "Reception paused after screen recreation; decoded working text is retained."
            }
        }

        DisposableEffect(androidContext) {
            PhoneSensorRepository.start(androidContext)
            onDispose {
                microphoneEngine.stop()
                PhoneSensorRepository.stop()
            }
        }

        val lux = PhoneSensorRepository.readings["light"]?.values?.firstOrNull()?.toDouble()
        LaunchedEffect(lux, listening, source) {
            if (listening && source == "light_sensor" && lux != null) {
                val detection = lightDetector.feed(lux)
                levelText = "${"%.1f".format(Locale.US, lux)} lx • span ${"%.1f".format(Locale.US, detection.span.takeIf { it.isFinite() } ?: 0.0)}"
                detection.state?.let { acceptSignal(it, System.currentTimeMillis()) }
            }
        }

        val committedFields = fieldsFromJson(committedJson)
        val committedResult = remember(committedJson) { committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(As100SignalMorseReceiveMethod, context, it) } }
        val committedFullJson = remember(committedJson) { fullJson(committedResult) }

        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SignalInstrumentPanel(
                kicker = "ADAPTIVE TELEGRAPH DECODER",
                title = "Morse receiver",
                accent = SignalAmber,
                badge = if (levelOn) "Signal" else if (listening) "Listening" else "Quiet"
            ) {
                Text(
                    decodedText.ifBlank { "WAITING FOR MESSAGE" },
                    modifier = Modifier.fillMaxWidth().clickable(enabled = decodedText.isNotBlank()) {
                        copySignalValue(androidContext, "decoded Morse", decodedText)
                    },
                    color = if (decodedText.isBlank()) SignalMuted else SignalText,
                    style = MaterialTheme.typography.headlineMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    if (currentSymbols.isBlank()) "· · ·" else currentSymbols,
                    color = SignalAmber,
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Monospace
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("SOURCE", source.replace('_', ' '), SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("DOT", "~${effectiveDotMs} ms", SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("MARKS", pulsesSeen.toString(), SignalAmber, Modifier.weight(1f))
                }
                Text(levelText, color = SignalMuted, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            }

            if (source == "camera" && listening && cameraGranted) {
                Card(Modifier.fillMaxWidth().height(230.dp), shape = RoundedCornerShape(22.dp)) {
                    SignalCameraLumaPreview(
                        onSample = { sample ->
                            val detection = cameraDetector.feed(sample.luma)
                            levelText = "luma ${"%.0f".format(Locale.US, sample.luma)} • span ${"%.0f".format(Locale.US, detection.span.takeIf { it.isFinite() } ?: 0.0)}"
                            detection.state?.let { acceptSignal(it, sample.timestampMs) }
                        },
                        onError = { error = it; listening = false }
                    )
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (listening) stopListening() else startListening() }, modifier = Modifier.weight(1f)) { Text(if (listening) "Stop" else "Start listening") }
                Button(onClick = ::commit, enabled = decodedText.isNotBlank(), modifier = Modifier.weight(1f)) { Text(if (committedResult == null) "Commit" else "Recommit") }
            }

            if (committedResult != null && !context.submitsImmediately) {
                SignalCommittedCard(
                    title = "Committed reception",
                    primaryLabel = "decoded text",
                    primaryValue = committedFields[SignalMorseReceiveFields.RESULT].orEmpty(),
                    fields = listOf(
                        "Morse" to committedFields[SignalMorseReceiveFields.NOTATION].orEmpty(),
                        "Source" to committedFields[SignalMorseReceiveFields.SOURCE].orEmpty(),
                        "Dot ms" to committedFields[SignalMorseReceiveFields.DOT_MS].orEmpty(),
                        "Marks" to committedFields[SignalMorseReceiveFields.TRANSITIONS].orEmpty()
                    ),
                    status = exportStatus,
                    onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                    onShare = { exportStatus = shareSignalText(androidContext, "Share decoded Morse", committedFields[SignalMorseReceiveFields.RESULT].orEmpty()) ?: "" },
                    onSave = { exportStatus = saveSignalText(androidContext, "morse_reception", committedFields[SignalMorseReceiveFields.RESULT].orEmpty(), committedFullJson) },
                    onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, "morse_reception", committedFields[SignalMorseReceiveFields.RESULT].orEmpty(), committedFullJson) } }
                )
            }

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Receiver", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (context.settingShouldBeShown("source")) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("light_sensor" to "Lux", "camera" to "Camera", "microphone" to "Mic").forEach { (id, label) ->
                                FilterChip(selected = source == id, enabled = !listening, onClick = { if (source != id) { source = id; invalidateWorkingReception() } }, label = { Text(label) })
                            }
                        }
                    }
                    if (context.settingShouldBeShown("dot_ms")) {
                        Text("Expected dot: $dotMsSetting ms")
                        Slider(dotMsSetting.toFloat(), { next -> val snapped = ((next.roundToInt() / 10) * 10).coerceIn(30, 1000).toLong(); if (snapped != dotMsSetting) { dotMsSetting = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = 30f..1000f)
                    }
                    if (context.settingShouldBeShown("auto_timing")) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Auto timing"); Text("Adapt to sender speed", style = MaterialTheme.typography.bodySmall) }
                            Switch(autoTiming, { next -> if (next != autoTiming) { autoTiming = next; invalidateWorkingReception() } }, enabled = !listening)
                        }
                    }
                    if (source == "microphone") {
                        if (context.settingShouldBeShown("microphone_tone_hz")) {
                            Text("Tone: ${toneHz.roundToInt()} Hz")
                            Slider(toneHz.toFloat(), { next -> val snapped = ((next.roundToInt() / 10) * 10).coerceIn(100, 10000).toDouble(); if (snapped != toneHz) { toneHz = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = 100f..10000f)
                        }
                        if (context.settingShouldBeShown("microphone_tolerance_hz")) {
                            Text("Tolerance: ±${toneTolerance.roundToInt()} Hz")
                            Slider(toneTolerance.toFloat(), { next -> val snapped = ((next.roundToInt() / 10) * 10).coerceIn(10, 2000).toDouble(); if (snapped != toneTolerance) { toneTolerance = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = 10f..2000f)
                        }
                        if (context.settingShouldBeShown("microphone_min_dbfs")) {
                            Text("Minimum level: ${"%.0f".format(Locale.US, minDbfs)} dBFS")
                            Slider(minDbfs.toFloat(), { next -> val snapped = next.roundToInt().coerceIn(-90, 0).toDouble(); if (snapped != minDbfs) { minDbfs = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = -90f..0f)
                        }
                    }
                }
            }

            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (committedResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            }
        }
    }
}

private fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

private fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}
