# Network Tools manifest integration

The live dashboard can show active-network state with the permissions already present in MethodMesh. To expose **nearby Wi-Fi networks** and request a fresh scan, Android also requires these normal manifest permissions:

```xml
<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
<uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
```

`ACCESS_FINE_LOCATION` is already present in the current MethodMesh manifest and is requested at runtime by the Network Tools dashboard when the operator asks to expose nearby Wi-Fi scan results.

## Why this is not silently patched here

The canonical MethodMesh handoff is one self-contained module folder. This Development handoff therefore documents the two app-level permissions rather than modifying a shared `AndroidManifest.xml` outside the module folder without review.

After admission, add the two lines beside the other network/location permissions in:

```text
app/src/main/AndroidManifest.xml
```

Then exercise the physical-device checks in `VALIDATION.md`.

## Behaviour before integration

The dashboard still reports:

- active transport;
- validated/internet/captive-portal state;
- metered state;
- interface name;
- local addresses;
- gateway;
- DNS servers;
- Wi-Fi transport information available through `NetworkCapabilities`.

The Nearby Wi-Fi panel explicitly says that app integration is required and does not crash or attempt to bypass Android permission controls.
