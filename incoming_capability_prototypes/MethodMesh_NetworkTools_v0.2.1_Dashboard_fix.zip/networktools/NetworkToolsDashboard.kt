package com.example.methodmesh.modules.networktools

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
internal fun NetworkToolsDashboard(
    context: CapabilityScreenContext,
    onCancel: () -> Unit
) {
    val androidContext = LocalContext.current
    val scope = rememberCoroutineScope()

    var snapshot by remember { mutableStateOf(NetworkSnapshotRepository.current(androidContext)) }
    var wifiEnvironment by remember { mutableStateOf(NetworkSnapshotRepository.wifiEnvironment(androidContext, false)) }
    var wifiRefreshing by remember { mutableStateOf(false) }
    var host by rememberSaveable { mutableStateOf(context.action.setting("host") ?: "example.com") }
    var port by rememberSaveable { mutableStateOf(context.action.setting("port") ?: "443") }
    var cidr by rememberSaveable { mutableStateOf(context.action.setting("cidr") ?: "192.168.1.0/24") }
    var runningTool by rememberSaveable { mutableStateOf("") }
    var resultJson by rememberSaveable { mutableStateOf("") }
    var copyStatus by rememberSaveable { mutableStateOf("") }

    val result = remember(resultJson) { resultJson.toStringMap() }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        wifiEnvironment = NetworkSnapshotRepository.wifiEnvironment(androidContext, false)
    }

    fun refreshConnection() {
        snapshot = NetworkSnapshotRepository.current(androidContext)
        wifiEnvironment = NetworkSnapshotRepository.wifiEnvironment(androidContext, false)
    }

    fun refreshWifi() {
        if (wifiRefreshing) return
        wifiRefreshing = true
        scope.launch {
            val first = withContext(Dispatchers.IO) {
                NetworkSnapshotRepository.wifiEnvironment(androidContext, true)
            }
            wifiEnvironment = first
            if (first.scanStarted) {
                delay(1800)
                wifiEnvironment = withContext(Dispatchers.IO) {
                    NetworkSnapshotRepository.wifiEnvironment(androidContext, false)
                }
            }
            wifiRefreshing = false
        }
    }

    fun runTool(operation: NetworkOperation) {
        if (runningTool.isNotBlank()) return
        runningTool = operation.id
        copyStatus = ""
        scope.launch {
            val settings = mapOf(
                "operation" to operation.id,
                "host" to host.trim(),
                "port" to port,
                "timeout_ms" to "3000",
                "cidr" to cidr.trim(),
                "traceroute_max_hops" to "12"
            )
            val values = withContext(Dispatchers.IO) {
                NetworkToolsRunner.run(settings, androidContext.applicationContext)
            }
            resultJson = values.toJsonString()
            runningTool = ""
        }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            snapshot = NetworkSnapshotRepository.current(androidContext)
            delay(5000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text("Network tools", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Live connection dashboard", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = { refreshConnection() }) { Text("Refresh") }
        }

        ConnectionCard(snapshot)

        WifiEnvironmentCard(
            environment = wifiEnvironment,
            refreshing = wifiRefreshing,
            onRefresh = { refreshWifi() },
            onRequestLocation = {
                if (androidContext.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    locationLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }
            }
        )

        DiagnosticToolsCard(
            host = host,
            onHostChange = { host = it.take(253) },
            port = port,
            onPortChange = { port = it.filter(Char::isDigit).take(5) },
            runningTool = runningTool,
            onRun = ::runTool
        )

        CidrCard(
            cidr = cidr,
            onCidrChange = { cidr = it.take(32) },
            running = runningTool == NetworkOperation.CIDR.id,
            onCalculate = { runTool(NetworkOperation.CIDR) }
        )

        if (result.isNotEmpty()) {
            DashboardResultCard(
                values = result,
                copyStatus = copyStatus,
                onCopy = {
                    val text = result[NetworkToolsFields.VALUE].orEmpty().ifBlank {
                        result[NetworkToolsFields.SUMMARY].orEmpty()
                    }
                    if (text.isNotBlank()) {
                        androidContext.getSystemService(ClipboardManager::class.java)
                            .setPrimaryClip(ClipData.newPlainText("MethodMesh network result", text))
                        copyStatus = "Copied"
                    }
                },
                onShare = {
                    val text = result[NetworkToolsFields.VALUE].orEmpty().ifBlank {
                        result[NetworkToolsFields.SUMMARY].orEmpty()
                    }
                    if (text.isNotBlank()) {
                        androidContext.startActivity(
                            Intent.createChooser(
                                Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, text)
                                },
                                "Share network result"
                            )
                        )
                    }
                }
            )
        }

        Text(
            "Nearby Wi-Fi is passive/local information only. Diagnostic tools remain bounded to one host or one CIDR input; this module does not perform LAN sweeps or port-range scans.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Close") }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ConnectionCard(snapshot: NetworkSnapshot) {
    DashboardCard(title = "Current connection") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(snapshot.stateLabel, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(
                    buildString {
                        append(snapshot.transportLabel)
                        if (snapshot.ssid.isNotBlank()) append(" · ${snapshot.ssid}")
                    },
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            StatusPill(
                text = when {
                    snapshot.captivePortal -> "Sign-in"
                    snapshot.validated -> "Healthy"
                    snapshot.internetCapable -> "Unverified"
                    else -> "Offline"
                }
            )
        }
        Spacer(Modifier.height(12.dp))
        MetricGrid(
            listOf(
                "Local IP" to snapshot.localAddresses.joinToString("\n").ifBlank { "—" },
                "Gateway" to snapshot.gateway.ifBlank { "—" },
                "DNS" to snapshot.dnsServers.joinToString("\n").ifBlank { "—" },
                "Interface" to snapshot.interfaceName.ifBlank { "—" },
                "Metered" to if (snapshot.metered) "Yes" else "No",
                "Signal" to snapshot.rssi?.let { "$it dBm · ${signalLabel(it)}" }.orEmpty().ifBlank { "—" }
            )
        )
        if (snapshot.transportLabel == "Wi-Fi") {
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            val wifiDetail = listOfNotNull(
                snapshot.frequencyMhz?.let { "${wifiBand(it)} · ${it} MHz${wifiChannel(it)?.let { ch -> " · ch $ch" }.orEmpty()}" },
                snapshot.linkSpeedMbps?.let { "$it Mbps link" },
                snapshot.wifiStandard.takeIf { it.isNotBlank() }
            ).joinToString(" · ")
            if (wifiDetail.isNotBlank()) Text(wifiDetail, style = MaterialTheme.typography.bodyMedium)
            if (snapshot.bssid.isNotBlank()) {
                Text("BSSID ${snapshot.bssid}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            snapshot.wifiPermissionNote?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun WifiEnvironmentCard(
    environment: WifiEnvironmentSnapshot,
    refreshing: Boolean,
    onRefresh: () -> Unit,
    onRequestLocation: () -> Unit
) {
    DashboardCard(title = "Nearby Wi-Fi") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (environment.networks.isEmpty()) "No networks visible" else "${environment.networks.size} network${if (environment.networks.size == 1) "" else "s"}",
                style = MaterialTheme.typography.titleMedium
            )
            OutlinedButton(onClick = onRefresh, enabled = !refreshing) {
                Text(if (refreshing) "Scanning…" else "Refresh")
            }
        }
        environment.message?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (environment.needsLocationPermission) {
            Spacer(Modifier.height(8.dp))
            Button(onClick = onRequestLocation, modifier = Modifier.fillMaxWidth()) { Text("Allow Wi-Fi scan access") }
        }
        if (environment.missingManifestPermissions.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "App integration required: ${environment.missingManifestPermissions.joinToString()} must be declared before nearby Wi-Fi scanning can work.",
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
        environment.networks.take(12).forEachIndexed { index, network ->
            if (index == 0) Spacer(Modifier.height(8.dp)) else HorizontalDivider()
            WifiNetworkRowView(network)
        }
        if (environment.networks.size > 12) {
            Text(
                "+ ${environment.networks.size - 12} more networks",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun WifiNetworkRowView(network: WifiNetworkRow) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(network.ssid, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                if (network.connected) StatusPill("Connected")
            }
            Text(
                buildString {
                    append(network.security)
                    append(" · ${network.band}")
                    network.channel?.let { append(" · ch $it") }
                    if (network.accessPointCount > 1) append(" · ${network.accessPointCount} APs")
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Column {
            Text(signalBars(network.rssi), style = MaterialTheme.typography.bodyLarge)
            Text("${network.rssi} dBm", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DiagnosticToolsCard(
    host: String,
    onHostChange: (String) -> Unit,
    port: String,
    onPortChange: (String) -> Unit,
    runningTool: String,
    onRun: (NetworkOperation) -> Unit
) {
    DashboardCard(title = "Host diagnostics") {
        Text("Run one bounded check against a specific host.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = host,
            onValueChange = onHostChange,
            label = { Text("Host name or IP") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ToolButton("DNS", NetworkOperation.DNS_LOOKUP, runningTool, host.isNotBlank(), Modifier.weight(1f), onRun)
            ToolButton("Reachability", NetworkOperation.REACHABILITY, runningTool, host.isNotBlank(), Modifier.weight(1f), onRun)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = port,
                onValueChange = onPortChange,
                label = { Text("TCP port") },
                modifier = Modifier.weight(0.42f),
                singleLine = true
            )
            ToolButton("Test TCP", NetworkOperation.TCP_TEST, runningTool, host.isNotBlank() && port.isNotBlank(), Modifier.weight(0.58f), onRun)
        }
        Spacer(Modifier.height(8.dp))
        ToolButton("Traceroute", NetworkOperation.TRACEROUTE, runningTool, host.isNotBlank(), Modifier.fillMaxWidth(), onRun)
    }
}

@Composable
private fun CidrCard(
    cidr: String,
    onCidrChange: (String) -> Unit,
    running: Boolean,
    onCalculate: () -> Unit
) {
    DashboardCard(title = "IPv4 CIDR calculator") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = cidr,
                onValueChange = onCidrChange,
                label = { Text("CIDR") },
                placeholder = { Text("192.168.1.0/24") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            Button(onClick = onCalculate, enabled = !running && cidr.isNotBlank()) { Text(if (running) "…" else "Calculate") }
        }
    }
}

@Composable
private fun DashboardResultCard(
    values: Map<String, String>,
    copyStatus: String,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    DashboardCard(title = "Latest result") {
        Text(
            values[NetworkToolsFields.VALUE].orEmpty().ifBlank { values[NetworkToolsFields.SUMMARY].orEmpty() },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold
        )
        values[NetworkToolsFields.SUMMARY]?.takeIf { it.isNotBlank() && it != values[NetworkToolsFields.VALUE] }?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }
        values[NetworkToolsFields.DETAIL]?.takeIf { it.isNotBlank() }?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        val details = listOfNotNull(
            values[NetworkToolsFields.IP]?.takeIf { it.isNotBlank() }?.let { "IP $it" },
            values[NetworkToolsFields.LATENCY_MS]?.takeIf { it.isNotBlank() }?.let { "${it} ms" },
            values[NetworkToolsFields.STATUS]?.takeIf { it.isNotBlank() }
        )
        if (details.isNotEmpty()) {
            Text(details.joinToString(" · "), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onCopy, modifier = Modifier.weight(1f)) { Text(if (copyStatus.isBlank()) "Copy" else copyStatus) }
            Button(onClick = onShare, modifier = Modifier.weight(1f)) { Text("Share") }
        }
    }
}

@Composable
private fun ToolButton(
    label: String,
    operation: NetworkOperation,
    runningTool: String,
    enabled: Boolean,
    modifier: Modifier,
    onRun: (NetworkOperation) -> Unit
) {
    OutlinedButton(
        onClick = { onRun(operation) },
        enabled = enabled && runningTool.isBlank(),
        modifier = modifier
    ) {
        Text(if (runningTool == operation.id) "Running…" else label)
    }
}

@Composable
private fun DashboardCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.36f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun MetricGrid(items: List<Pair<String, String>>) {
    items.chunked(2).forEachIndexed { rowIndex, row ->
        if (rowIndex > 0) Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            row.forEach { (label, value) ->
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(value, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun StatusPill(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(50)
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall
        )
    }
}

private fun signalLabel(rssi: Int): String = when {
    rssi >= -50 -> "Excellent"
    rssi >= -60 -> "Good"
    rssi >= -70 -> "Fair"
    else -> "Weak"
}

private fun signalBars(rssi: Int): String = when {
    rssi >= -50 -> "▮▮▮▮"
    rssi >= -60 -> "▮▮▮▯"
    rssi >= -70 -> "▮▮▯▯"
    else -> "▮▯▯▯"
}

private fun wifiBand(frequency: Int): String = when (frequency) {
    in 2400..2500 -> "2.4 GHz"
    in 4900..5900 -> "5 GHz"
    in 5925..7125 -> "6 GHz"
    else -> "${frequency} MHz"
}

private fun wifiChannel(frequency: Int): Int? = when {
    frequency == 2484 -> 14
    frequency in 2412..2472 -> (frequency - 2407) / 5
    frequency in 5000..5895 -> (frequency - 5000) / 5
    frequency in 5955..7115 -> (frequency - 5950) / 5
    else -> null
}

private fun Map<String, String>.toJsonString(): String = JSONObject().apply {
    this@toJsonString.forEach { (key, value) -> put(key, value) }
}.toString()

private fun String.toStringMap(): Map<String, String> {
    if (isBlank()) return emptyMap()
    return runCatching {
        val json = JSONObject(this)
        linkedMapOf<String, String>().apply {
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                put(key, json.optString(key, ""))
            }
        }
    }.getOrDefault(emptyMap())
}

private fun com.example.methodmesh.transport.workflow.ExternalActionRequest.setting(key: String): String? =
    (settings[key] ?: settings["input_$key"])?.takeIf { it.isNotBlank() }
