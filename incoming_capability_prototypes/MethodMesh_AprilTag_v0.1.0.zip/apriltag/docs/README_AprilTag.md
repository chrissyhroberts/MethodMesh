# AprilTag — AprilTag metrology and tracking

**Module ID:** `apriltag`  
**Display name:** AprilTag  
**Version:** 0.1.0  
**Maturity:** Experimental  
**Connectivity:** Offline  
**MethodMesh target:** Master Book v1.08

This module turns printed AprilTags into physical experimental references. The public capabilities are **experimental operations**, not a generic AprilTag demo. Each operation is independently callable from direct native use, presets, protocols and ODK/XLSForm; the module dashboard is only an aggregate projection.

## Canonical capabilities

| Method ID | Purpose | Primary beef |
|---|---|---|
| `apriltag.detect` | Detect/identify tags and image-space geometry | ID, pixel geometry, detector evidence |
| `apriltag.calibrate_focal` | Approximate pinhole focal calibration from a known-distance tag | `fx/fy/cx/cy` calibration profile |
| `apriltag.range_pose` | Known-size tag range + 6-DoF pose | distance, XYZ, yaw/pitch/roll |
| `apriltag.relative_pose` | Target tag relative to fixed reference tag | relative XYZ/rotation |
| `apriltag.planar_measure` | Point/distance/area/manual trajectory on a tagged plane | millimetre coordinates/derived measures |
| `apriltag.track_pose` | Time-series motion of a tagged rigid object | trajectory, path, displacement, speed |

## Common experimental lifecycle

1. The live camera/detector is the **working result**.
2. Useful live values are tappable/copyable where presented.
3. Settings sit below the instrument and may be fixed by presets or exposed as runtime fields.
4. **Commit** freezes a canonical payload. Live camera changes never silently mutate committed data.
5. Direct/dashboard use then exposes MethodMesh result actions on the same capability flow.
6. Protocol/dependency/ODK external-roundtrip launches return immediately after Commit.
7. Cancel before Commit returns cleanly to the caller.

## Scientific validity model

The UI deliberately exposes geometry assumptions and quality evidence rather than presenting camera-derived millimetres as intrinsically authoritative.

- Metric pose requires a known AprilTag **detection-edge** size plus camera intrinsics.
- `tag_size_mm` means the physical distance between the four AprilTag detection corners, **not** the outside edge of the printed paper.
- Automatic camera intrinsics use Android factory metadata where available and are scaled to the CameraX analysis frame. The returned `apriltag_intrinsics_source` and warnings remain part of the result.
- The fallback physical-sensor estimate is explicitly labelled approximate.
- `apriltag.calibrate_focal` is a pragmatic field calibration, not a full lens-distortion calibration.
- Planar measurements are valid only when the tapped object lies on the same physical plane as the reference tag/layout.
- Camera-frame tracking requires the phone/camera to remain physically fixed. A simultaneously visible reference tag is preferable because it gives a stable external frame.
- AprilTag's pose error, Hamming distance, decision margin and camera-model source are retained as audit/quality evidence.

## Example experimental setups

### Snail/animal arena

Place one or more fixed tags on the arena plane. `apriltag.planar_measure` in `trajectory` mode lets the operator tap the animal repeatedly; the committed result contains timestamped millimetre coordinates, path length, duration and mean speed. An optional planar layout maps different visible tag IDs into one shared arena coordinate frame.

### Range target

Print a tag with a measured detection edge (for example 100.00 mm), calibrate/provide camera intrinsics, and use `apriltag.range_pose`. Range, camera-frame XYZ and tag orientation are returned together with camera-model and detector evidence.

### Moving apparatus

Attach a tag to a rigid moving object. Prefer a second fixed reference tag in view. `apriltag.track_pose` records the moving tag in the reference coordinate frame and returns the full time series plus derived path/displacement/speeds.

### Mapping fixed landmarks

`apriltag.relative_pose` measures one tag relative to another when both are visible. Repeated pairwise observations are useful building blocks for room/bench/arena landmark networks. Global graph optimisation / bundle adjustment is intentionally **not** claimed in v0.1; see `ROADMAP_NOTE.md`.

## Native detector dependency

MethodMesh currently provides CameraX but no AprilTag detector. `AprilTagNativeBridge.kt` therefore attempts to load `libmethodmesh_apriltag.so`; if absent, every camera screen fails closed. `native/apriltag_jni.cpp`, `native/CMakeLists.txt.example` and `native/README.md` define the integration boundary without modifying shared app files in this module handoff.

Default family is `tagStandard41h12`; supported families are configurable.

## Permissions and connectivity

- Camera: `android.permission.CAMERA` (already a MethodMesh app permission).
- Network: none.
- Location: none.
- Storage: no automatic persistent study-data storage.

Returned data remain transient unless the user explicitly saves/exports or the caller (for example ODK) owns persistence.

## Module contents

- `AprilTagModule.kt` — module declaration, RIL bindings and settings.
- `AprilTagMethods.kt` — six canonical method contracts and result construction.
- `AprilTagCapabilityScreens.kt` — task-specific live/Commit UI.
- `AprilTagCamera.kt` — CameraX analysis surface and camera model resolution.
- `AprilTagGeometry.kt` — pure geometry, transforms and measurement calculations.
- `AprilTagNativeBridge.kt` — fail-closed JNI boundary.
- `native/` — AprilTag JNI integration material.
- `docs/` — capability-addressable documentation and one-call XLSForm showcases.
