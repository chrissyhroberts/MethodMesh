package com.example.methodmesh.modules.apriltag

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.SizeF
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min

internal data class CameraSettings(
    val family: String,
    val tagSizeMm: Double,
    val targetTagId: Int,
    val intrinsicsMode: String,
    val fx: Double,
    val fy: Double,
    val cx: Double,
    val cy: Double,
    val intrinsicsWidth: Int,
    val intrinsicsHeight: Int,
    val threads: Int,
    val quadDecimate: Double,
    val refineEdges: Boolean
)

@Composable
internal fun AprilTagCameraSurface(
    settings: CameraSettings,
    modifier: Modifier = Modifier,
    onFrame: (AprilTagFrame) -> Unit,
    onImageTap: ((PixelPoint) -> Unit)? = null
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) permissionLauncher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant)) {
            Text("Camera permission is required for this experimental method.")
        }
        return
    }

    val controller = remember(context) {
        LifecycleCameraController(context.applicationContext).apply {
            cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
            imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
        }
    }
    val executor = remember(settings) { Executors.newSingleThreadExecutor() }
    val latestFrame = remember { mutableStateOf<AprilTagFrame?>(null) }
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    val lastProcessed = remember { AtomicLong(0L) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(controller, lifecycleOwner, executor, settings) {
        controller.setImageAnalysisAnalyzer(executor) { image ->
            val now = System.currentTimeMillis()
            if (now - lastProcessed.get() < 80L) {
                image.close()
                return@setImageAnalysisAnalyzer
            }
            lastProcessed.set(now)
            try {
                val rotated = RotatedLuma.from(image)
                val intrinsics = CameraIntrinsicsResolver.resolve(context, settings, rotated.width, rotated.height, image.imageInfo.rotationDegrees)
                val result = AprilTagNativeBridge.detect(
                    gray = rotated.bytes,
                    width = rotated.width,
                    height = rotated.height,
                    config = AprilTagNativeBridge.DetectorConfig(
                        family = settings.family,
                        threads = settings.threads,
                        quadDecimate = settings.quadDecimate,
                        refineEdges = settings.refineEdges,
                        tagSizeMeters = settings.tagSizeMm / 1000.0
                    ),
                    intrinsics = intrinsics
                )
                val frame = AprilTagFrame(
                    detections = result.getOrDefault(emptyList()),
                    width = rotated.width,
                    height = rotated.height,
                    rotationDegrees = image.imageInfo.rotationDegrees,
                    intrinsics = intrinsics,
                    error = result.exceptionOrNull()?.message.orEmpty()
                )
                mainHandler.post {
                    latestFrame.value = frame
                    onFrame(frame)
                }
            } finally {
                image.close()
            }
        }
        runCatching { controller.bindToLifecycle(lifecycleOwner) }
            .onFailure { error ->
                onFrame(AprilTagFrame(emptyList(), 0, 0, 0, null, error = error.message ?: "Camera unavailable."))
            }
        onDispose {
            controller.clearImageAnalysisAnalyzer()
            controller.unbind()
            executor.shutdown()
        }
    }

    Box(
        modifier = modifier
            .onSizeChanged { viewSize = it }
            .then(
                if (onImageTap == null) Modifier else Modifier.pointerInput(latestFrame.value?.timestampIso, viewSize) {
                    detectTapGestures { offset ->
                        latestFrame.value?.let { frame ->
                            fitCenterViewToImage(offset, viewSize, frame.width, frame.height)?.let(onImageTap)
                        }
                    }
                }
            )
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { viewContext ->
                PreviewView(viewContext).apply {
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    scaleType = PreviewView.ScaleType.FIT_CENTER
                    this.controller = controller
                }
            },
            update = { it.controller = controller }
        )
        val frame = latestFrame.value
        if (frame != null && frame.width > 0 && frame.height > 0) {
            Canvas(Modifier.fillMaxSize()) {
                val scale = min(size.width / frame.width, size.height / frame.height)
                val ox = (size.width - frame.width * scale) / 2f
                val oy = (size.height - frame.height * scale) / 2f
                frame.detections.forEach { det ->
                    val pts = det.corners.map { Offset(ox + (it.x * scale).toFloat(), oy + (it.y * scale).toFloat()) }
                    if (pts.size == 4) {
                        for (i in 0 until 4) drawLine(Color.White, pts[i], pts[(i + 1) % 4], strokeWidth = 4f)
                        drawCircle(Color.White, radius = 7f, center = Offset(ox + (det.center.x * scale).toFloat(), oy + (det.center.y * scale).toFloat()))
                    }
                }
            }
        }
    }
}

private data class RotatedLuma(val bytes: ByteArray, val width: Int, val height: Int) {
    companion object {
        fun from(image: ImageProxy): RotatedLuma {
            val plane = image.planes[0]
            val raw = ByteArray(image.width * image.height)
            val buffer = plane.buffer
            val base = buffer.position()
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            for (y in 0 until image.height) {
                for (x in 0 until image.width) {
                    raw[y * image.width + x] = buffer.get(base + y * rowStride + x * pixelStride)
                }
            }
            return rotate(raw, image.width, image.height, image.imageInfo.rotationDegrees)
        }

        private fun rotate(raw: ByteArray, width: Int, height: Int, degrees: Int): RotatedLuma = when ((degrees % 360 + 360) % 360) {
            90 -> {
                val out = ByteArray(raw.size)
                for (y in 0 until height) for (x in 0 until width) out[x * height + (height - 1 - y)] = raw[y * width + x]
                RotatedLuma(out, height, width)
            }
            180 -> {
                val out = ByteArray(raw.size)
                for (i in raw.indices) out[raw.lastIndex - i] = raw[i]
                RotatedLuma(out, width, height)
            }
            270 -> {
                val out = ByteArray(raw.size)
                for (y in 0 until height) for (x in 0 until width) out[(width - 1 - x) * height + y] = raw[y * width + x]
                RotatedLuma(out, height, width)
            }
            else -> RotatedLuma(raw, width, height)
        }
    }
}

private object CameraIntrinsicsResolver {
    fun resolve(context: Context, settings: CameraSettings, width: Int, height: Int, rotationDegrees: Int): CameraIntrinsics? {
        if (settings.intrinsicsMode == "manual" && settings.fx > 0 && settings.fy > 0) {
            val sx = if (settings.intrinsicsWidth > 0) width.toDouble() / settings.intrinsicsWidth else 1.0
            val sy = if (settings.intrinsicsHeight > 0) height.toDouble() / settings.intrinsicsHeight else 1.0
            return CameraIntrinsics(
                settings.fx * sx,
                settings.fy * sy,
                settings.cx * sx,
                settings.cy * sy,
                width,
                height,
                "manual",
                if (settings.intrinsicsWidth <= 0 || settings.intrinsicsHeight <= 0) "Manual intrinsics were not tied to a calibration image size." else ""
            )
        }
        return androidIntrinsics(context, width, height, rotationDegrees)
    }

    private fun androidIntrinsics(context: Context, width: Int, height: Int, rotationDegrees: Int): CameraIntrinsics? {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return null
        val c = manager.getCameraCharacteristics(cameraId)
        val rawWidth = if (rotationDegrees == 90 || rotationDegrees == 270) height else width
        val rawHeight = if (rotationDegrees == 90 || rotationDegrees == 270) width else height
        val active = c.get(CameraCharacteristics.SENSOR_INFO_PRE_CORRECTION_ACTIVE_ARRAY_SIZE)
            ?: c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        if (active == null) {
            val estimated = physicalEstimate(c, rawWidth, rawHeight) ?: return null
            return rotateIntrinsics(estimated, rotationDegrees)
        }
        val intrinsic = c.get(CameraCharacteristics.LENS_INTRINSIC_CALIBRATION)
        val raw = if (intrinsic != null && intrinsic.size >= 4) {
            CameraIntrinsics(
                fx = intrinsic[0] * rawWidth / active.width(),
                fy = intrinsic[1] * rawHeight / active.height(),
                cx = (intrinsic[2] - active.left) * rawWidth / active.width(),
                cy = (intrinsic[3] - active.top) * rawHeight / active.height(),
                width = rawWidth,
                height = rawHeight,
                source = "android_factory_scaled",
                warning = "Factory intrinsics are scaled to the CameraX analysis buffer; digital crop/distortion may add error."
            )
        } else {
            val estimated = physicalEstimate(c, rawWidth, rawHeight) ?: return null
            return rotateIntrinsics(estimated, rotationDegrees)
        }
        return rotateIntrinsics(raw, rotationDegrees)
    }

    private fun physicalEstimate(c: CameraCharacteristics, width: Int, height: Int): CameraIntrinsics? {
        val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()?.toDouble() ?: return null
        val sensor: SizeF = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return null
        if (sensor.width <= 0 || sensor.height <= 0) return null
        return CameraIntrinsics(
            fx = focal / sensor.width * width,
            fy = focal / sensor.height * height,
            cx = (width - 1) / 2.0,
            cy = (height - 1) / 2.0,
            width = width,
            height = height,
            source = "android_physical_estimate",
            warning = "Estimated from focal length and sensor size; calibrate for quantitative work."
        )
    }

    private fun rotateIntrinsics(raw: CameraIntrinsics, degrees: Int): CameraIntrinsics = when ((degrees % 360 + 360) % 360) {
        90 -> CameraIntrinsics(raw.fy, raw.fx, raw.height - 1.0 - raw.cy, raw.cx, raw.height, raw.width, raw.source, raw.warning)
        180 -> CameraIntrinsics(raw.fx, raw.fy, raw.width - 1.0 - raw.cx, raw.height - 1.0 - raw.cy, raw.width, raw.height, raw.source, raw.warning)
        270 -> CameraIntrinsics(raw.fy, raw.fx, raw.cy, raw.width - 1.0 - raw.cx, raw.height, raw.width, raw.source, raw.warning)
        else -> raw
    }
}

private fun fitCenterViewToImage(offset: Offset, view: IntSize, imageWidth: Int, imageHeight: Int): PixelPoint? {
    if (view.width <= 0 || view.height <= 0 || imageWidth <= 0 || imageHeight <= 0) return null
    val scale = min(view.width.toDouble() / imageWidth, view.height.toDouble() / imageHeight)
    val ox = (view.width - imageWidth * scale) / 2.0
    val oy = (view.height - imageHeight * scale) / 2.0
    val x = (offset.x - ox) / scale
    val y = (offset.y - oy) / scale
    return PixelPoint(x, y).takeIf { x in 0.0..imageWidth.toDouble() && y in 0.0..imageHeight.toDouble() }
}
