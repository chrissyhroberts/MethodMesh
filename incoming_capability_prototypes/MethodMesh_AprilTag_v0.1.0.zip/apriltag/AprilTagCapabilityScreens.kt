package com.example.methodmesh.modules.apriltag

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.transport.workflow.ui.CapabilityHostPresentation
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import org.json.JSONArray
import org.json.JSONObject

private val supportedFamilies = listOf(
    "tagStandard41h12", "tag36h11", "tag25h9", "tag16h5",
    "tagCircle21h7", "tagCircle49h12", "tagStandard52h13"
)

private class AprilTagCapabilityScreenSpec(
    override val capabilityId: String,
    override val title: String,
    override val description: String
) : CapabilityScreenSpec {
    override val hostPresentation = CapabilityHostPresentation.Standard

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val method = aprilTagMethod(capabilityId)
        var committedValuesJson by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        val committedValues = remember(committedValuesJson) { valuesFromJson(committedValuesJson) }
        val committedResult = remember(committedValuesJson) {
            if (committedValuesJson.isBlank()) null else method.result(
                request = method.request(
                    action = capabilityId,
                    context = context.request.invocationContext.asMap(capabilityId) + context.action.settings,
                    signals = emptyList(),
                    inputs = emptyList()
                ),
                rawValues = committedValues,
                invocation = context.request.invocationContext
            )
        }
        val preview = committedValues.filterKeys { it in primaryPreviewKeys(capabilityId) }

        CapabilityScreenScaffold(
            title = title,
            capabilityId = capabilityId,
            context = context,
            canGoBack = context.stepNumber > 1,
            capturedResult = committedResult,
            resultPreview = preview,
            onBack = onBack,
            onRetry = { committedValuesJson = "" },
            onConfirm = { committedResult?.let(onConfirmed) },
            onCancel = onCancel
        ) {
            when (capabilityId) {
                As100AprilTagDetectMethod.id -> DetectInstrument(context) { committedValuesJson = valuesToJson(it) }
                As100AprilTagCalibrateFocalMethod.id -> CalibrationInstrument(context) { committedValuesJson = valuesToJson(it) }
                As100AprilTagRangePoseMethod.id -> RangePoseInstrument(context) { committedValuesJson = valuesToJson(it) }
                As100AprilTagRelativePoseMethod.id -> RelativePoseInstrument(context) { committedValuesJson = valuesToJson(it) }
                As100AprilTagPlanarMeasureMethod.id -> PlanarMeasureInstrument(context) { committedValuesJson = valuesToJson(it) }
                As100AprilTagTrackPoseMethod.id -> TrackPoseInstrument(context) { committedValuesJson = valuesToJson(it) }
            }
        }
    }
}

object AprilTagDetectCapabilityScreen : CapabilityScreenSpec by AprilTagCapabilityScreenSpec(
    As100AprilTagDetectMethod.id, "Detect AprilTag tags", "Identify AprilTags and inspect image-space detection evidence."
)
object AprilTagCalibrateCapabilityScreen : CapabilityScreenSpec by AprilTagCapabilityScreenSpec(
    As100AprilTagCalibrateFocalMethod.id, "Calibrate AprilTag range", "Estimate a practical pinhole focal length from a known-distance tag."
)
object AprilTagRangePoseCapabilityScreen : CapabilityScreenSpec by AprilTagCapabilityScreenSpec(
    As100AprilTagRangePoseMethod.id, "Tag range and pose", "Measure range and six-degree-of-freedom pose from a known-size tag."
)
object AprilTagRelativePoseCapabilityScreen : CapabilityScreenSpec by AprilTagCapabilityScreenSpec(
    As100AprilTagRelativePoseMethod.id, "Relative tag pose", "Measure a target tag in the coordinate frame of a reference tag."
)
object AprilTagPlanarMeasureCapabilityScreen : CapabilityScreenSpec by AprilTagCapabilityScreenSpec(
    As100AprilTagPlanarMeasureMethod.id, "Planar AprilTag measurement", "Tap points on a tagged plane to capture metric positions, lengths, areas, or trajectories."
)
object AprilTagTrackPoseCapabilityScreen : CapabilityScreenSpec by AprilTagCapabilityScreenSpec(
    As100AprilTagTrackPoseMethod.id, "Track tagged object", "Record a tagged rigid object's movement through time."
)

private fun aprilTagMethod(id: String): AprilTagAs100Method = when (id) {
    As100AprilTagDetectMethod.id -> As100AprilTagDetectMethod
    As100AprilTagCalibrateFocalMethod.id -> As100AprilTagCalibrateFocalMethod
    As100AprilTagRangePoseMethod.id -> As100AprilTagRangePoseMethod
    As100AprilTagRelativePoseMethod.id -> As100AprilTagRelativePoseMethod
    As100AprilTagPlanarMeasureMethod.id -> As100AprilTagPlanarMeasureMethod
    As100AprilTagTrackPoseMethod.id -> As100AprilTagTrackPoseMethod
    else -> error("Unknown AprilTag capability $id")
}

private fun primaryPreviewKeys(id: String): Set<String> = when (id) {
    As100AprilTagDetectMethod.id -> setOf(AprilTagCommonFields.RESULT, "apriltag_selected_tag_id", "apriltag_apparent_edge_px", "apriltag_decision_margin", AprilTagCommonFields.WARNING)
    As100AprilTagCalibrateFocalMethod.id -> setOf(AprilTagCommonFields.RESULT, "apriltag_fx_px", "apriltag_fy_px", "apriltag_edge_cv", AprilTagCommonFields.GEOMETRY_VALID, AprilTagCommonFields.WARNING)
    As100AprilTagRangePoseMethod.id -> setOf(AprilTagCommonFields.RESULT, "apriltag_distance_m", "apriltag_x_right_m", "apriltag_y_down_m", "apriltag_z_forward_m", "apriltag_pose_error", AprilTagCommonFields.WARNING)
    As100AprilTagRelativePoseMethod.id -> setOf(AprilTagCommonFields.RESULT, "apriltag_relative_x_m", "apriltag_relative_y_m", "apriltag_relative_z_m", "apriltag_relative_distance_m", AprilTagCommonFields.WARNING)
    As100AprilTagPlanarMeasureMethod.id -> setOf(AprilTagCommonFields.RESULT, "apriltag_point_x_mm", "apriltag_point_y_mm", "apriltag_distance_mm", "apriltag_area_mm2", "apriltag_path_length_mm", AprilTagCommonFields.WARNING)
    else -> setOf(AprilTagCommonFields.RESULT, "apriltag_sample_count", "apriltag_path_length_m", "apriltag_displacement_m", "apriltag_mean_speed_m_s", AprilTagCommonFields.WARNING)
}

@Composable
private fun DetectInstrument(context: CapabilityScreenContext, onCommit: (Map<String, String>) -> Unit) {
    val state = rememberAprilTagSettings(context, includeIntrinsics = false)
    var frame by remember { mutableStateOf<AprilTagFrame?>(null) }
    CameraInstrument(state.cameraSettings(), frame, { frame = it })
    LiveDetectionSummary(frame, state.targetTagId.toIntOrNull() ?: -1)
    Button(
        onClick = { frame?.let { onCommit(As100AprilTagDetectMethod.capture(it, state.targetTagId.toIntOrNull() ?: -1, state.family)) } },
        enabled = frame?.selected(state.targetTagId.toIntOrNull() ?: -1) != null,
        modifier = Modifier.fillMaxWidth()
    ) { Text("Commit detection") }
    SettingsDivider()
    BasicDetectorSettings(state, showTagSize = false)
}

@Composable
private fun CalibrationInstrument(context: CapabilityScreenContext, onCommit: (Map<String, String>) -> Unit) {
    val state = rememberAprilTagSettings(context, includeIntrinsics = false)
    var knownDistance by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.KNOWN_DISTANCE_MM) ?: "1000") }
    var requiredSamples by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.CALIBRATION_SAMPLES) ?: "15") }
    var samplesJson by rememberSaveable { mutableStateOf("[]") }
    var collecting by rememberSaveable { mutableStateOf(false) }
    var lastAccepted by rememberSaveable { mutableStateOf(0L) }
    var frame by remember { mutableStateOf<AprilTagFrame?>(null) }
    var calibrationTagId by rememberSaveable { mutableStateOf(-1) }
    val samples = remember(samplesJson) { jsonDoubles(samplesJson) }
    val required = requiredSamples.toIntOrNull()?.coerceIn(3, 100) ?: 15
    val targetId = state.targetTagId.toIntOrNull() ?: -1

    CameraInstrument(state.cameraSettings(tagSizeMmOverride = 0.0), frame, { incoming ->
        frame = incoming
        if (collecting && samples.size < required) {
            val effectiveTarget = if (targetId >= 0) targetId else calibrationTagId
            val det = incoming.selected(effectiveTarget)
            val now = System.currentTimeMillis()
            if (det != null && det.hamming == 0 && det.meanEdgePx.isFinite() && edgeShapeCv(det) <= 0.08 && now - lastAccepted >= 100) {
                if (calibrationTagId < 0) calibrationTagId = det.id
                samplesJson = JSONArray(samples + det.meanEdgePx).toString()
                lastAccepted = now
                if (samples.size + 1 >= required) collecting = false
            }
        }
    })
    val cv = AprilTagGeometry.coefficientOfVariation(samples)
    Text("${samples.size} / $required samples", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (samples.isNotEmpty()) {
        CopyableValue("Mean detected edge", "${fmt(samples.average(), 1)} px")
        CopyableValue("Across-sample CV", fmt(cv, 4))
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!collecting) Button(onClick = { if (samples.size >= required) { samplesJson = "[]"; calibrationTagId = -1 }; collecting = true }, modifier = Modifier.weight(1f)) { Text(if (samples.isEmpty()) "Start sampling" else "Resume sampling") }
        else OutlinedButton(onClick = { collecting = false }, modifier = Modifier.weight(1f)) { Text("Pause") }
        OutlinedButton(onClick = { samplesJson = "[]"; collecting = false; calibrationTagId = -1 }, modifier = Modifier.weight(1f)) { Text("Clear") }
    }
    Button(
        onClick = {
            val f = frame ?: return@Button
            val effectiveTarget = if (targetId >= 0) targetId else calibrationTagId
            val det = f.selected(effectiveTarget) ?: return@Button
            onCommit(
                As100AprilTagCalibrateFocalMethod.capture(
                    tagId = det.id,
                    family = state.family,
                    tagSizeMm = state.tagSizeMm.toDoubleOrNull() ?: 100.0,
                    knownDistanceMm = knownDistance.toDoubleOrNull() ?: 1000.0,
                    edgeSamplesPx = samples,
                    imageWidth = f.width,
                    imageHeight = f.height,
                    requiredSamples = required
                )
            )
        },
        enabled = samples.size >= required && frame != null,
        modifier = Modifier.fillMaxWidth()
    ) { Text("Commit calibration") }
    SettingsDivider()
    Text("Keep the tag front-facing and measure camera optical centre to tag plane as accurately as practical.", style = MaterialTheme.typography.bodySmall)
    BasicDetectorSettings(state, showTagSize = true)
    NumericField("Known distance (mm)", knownDistance) { knownDistance = numeric(it) }
    NumericField("Samples", requiredSamples) { requiredSamples = integer(it) }
    LaunchedEffect(knownDistance, requiredSamples) {
        context.onSettingsChanged(mapOf(AprilTagInputs.KNOWN_DISTANCE_MM to knownDistance, AprilTagInputs.CALIBRATION_SAMPLES to requiredSamples))
    }
}

@Composable
private fun RangePoseInstrument(context: CapabilityScreenContext, onCommit: (Map<String, String>) -> Unit) {
    val state = rememberAprilTagSettings(context, includeIntrinsics = true)
    var frame by remember { mutableStateOf<AprilTagFrame?>(null) }
    val targetId = state.targetTagId.toIntOrNull() ?: -1
    CameraInstrument(state.cameraSettings(), frame, { frame = it })
    val det = frame?.selected(targetId)
    val pose = det?.pose
    if (pose != null) {
        CopyableValue("Range", "${fmt(AprilTagGeometry.distanceFromCamera(pose), 3)} m")
        CopyableValue("X / Y / Z", "${fmt(pose.translation.x, 3)} / ${fmt(pose.translation.y, 3)} / ${fmt(pose.translation.z, 3)} m")
        CopyableValue("Pose error", pose.error?.let { fmt(it, 8) }.orEmpty())
        Text("Camera frame: +x right, +y down, +z forward.", style = MaterialTheme.typography.bodySmall)
    } else {
        Text(frame?.error?.ifBlank { "Show the configured tag to the camera." } ?: "Waiting for camera…")
    }
    Button(
        onClick = { frame?.let { onCommit(As100AprilTagRangePoseMethod.capture(it, targetId, state.tagSizeMm.toDoubleOrNull() ?: 100.0, state.family)) } },
        enabled = pose != null,
        modifier = Modifier.fillMaxWidth()
    ) { Text("Commit range and pose") }
    SettingsDivider()
    BasicDetectorSettings(state, showTagSize = true)
    IntrinsicsSettings(state)
}

@Composable
private fun RelativePoseInstrument(context: CapabilityScreenContext, onCommit: (Map<String, String>) -> Unit) {
    val state = rememberAprilTagSettings(context, includeIntrinsics = true)
    var referenceId by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.REFERENCE_TAG_ID) ?: "0") }
    var targetId by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.TARGET_TAG_ID) ?: "1") }
    var frame by remember { mutableStateOf<AprilTagFrame?>(null) }
    CameraInstrument(state.cameraSettings(), frame, { frame = it })
    val ref = frame?.detections?.firstOrNull { it.id == referenceId.toIntOrNull() }
    val target = frame?.detections?.firstOrNull { it.id == targetId.toIntOrNull() }
    val relative = if (ref?.pose != null && target?.pose != null) AprilTagGeometry.relativePose(ref.pose, target.pose) else null
    if (relative != null) {
        CopyableValue("Separation", "${fmt(AprilTagGeometry.distanceFromCamera(relative), 3)} m")
        CopyableValue("Target in reference frame", "${fmt(relative.translation.x, 3)}, ${fmt(relative.translation.y, 3)}, ${fmt(relative.translation.z, 3)} m")
    } else Text("Keep both configured tags visible in the same frame.")
    Button(
        onClick = {
            frame?.let {
                onCommit(As100AprilTagRelativePoseMethod.capture(it, referenceId.toIntOrNull() ?: 0, targetId.toIntOrNull() ?: 1, state.tagSizeMm.toDoubleOrNull() ?: 100.0, state.family))
            }
        },
        enabled = relative != null && referenceId != targetId,
        modifier = Modifier.fillMaxWidth()
    ) { Text("Commit relative pose") }
    SettingsDivider()
    NumericField("Reference tag ID", referenceId) { referenceId = integer(it) }
    NumericField("Target tag ID", targetId) { targetId = integer(it) }
    BasicDetectorSettings(state, showTagSize = true, showTargetId = false)
    IntrinsicsSettings(state)
    LaunchedEffect(referenceId, targetId) { context.onSettingsChanged(mapOf(AprilTagInputs.REFERENCE_TAG_ID to referenceId, AprilTagInputs.TARGET_TAG_ID to targetId)) }
}

@Composable
private fun PlanarMeasureInstrument(context: CapabilityScreenContext, onCommit: (Map<String, String>) -> Unit) {
    val state = rememberAprilTagSettings(context, includeIntrinsics = false)
    var mode by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.MEASUREMENT_MODE) ?: "point") }
    var layoutJson by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.ANCHOR_LAYOUT_JSON) ?: "") }
    var pointsJson by rememberSaveable { mutableStateOf("[]") }
    var frame by remember { mutableStateOf<AprilTagFrame?>(null) }
    var referenceFrame by rememberSaveable { mutableStateOf("") }
    var activeReferenceTagId by rememberSaveable { mutableStateOf(-1) }
    val points = remember(pointsJson) { planarPoints(pointsJson) }
    val targetId = state.targetTagId.toIntOrNull() ?: -1
    val effectiveReferenceTagId = if (targetId >= 0) targetId else activeReferenceTagId

    CameraInstrument(
        state.cameraSettings(tagSizeMmOverride = 0.0),
        frame,
        { frame = it },
        onTap = { imagePoint ->
            val det = frame?.selected(effectiveReferenceTagId) ?: return@CameraInstrument
            if (activeReferenceTagId < 0) activeReferenceTagId = det.id
            val local = AprilTagGeometry.imageToTagPlane(imagePoint, det, state.tagSizeMm.toDoubleOrNull() ?: 100.0) ?: return@CameraInstrument
            val (world, frameName) = AprilTagGeometry.tagToWorld(local, det.id, layoutJson)
            referenceFrame = frameName
            val candidate = PlanarPoint(world.x, world.y, System.currentTimeMillis())
            val updated = when (mode) {
                "point" -> listOf(candidate)
                "distance" -> (points + candidate).takeLast(2)
                else -> points + candidate
            }
            pointsJson = JSONArray().apply { updated.forEach { put(it.toJson()) } }.toString()
        }
    )
    Text("Tap the object/point in the camera image.", style = MaterialTheme.typography.bodyMedium)
    if (points.isNotEmpty()) {
        val committedTagId = if (targetId >= 0) targetId else activeReferenceTagId
        val working = As100AprilTagPlanarMeasureMethod.capture(committedTagId, state.family, state.tagSizeMm.toDoubleOrNull() ?: 100.0, mode, referenceFrame.ifBlank { "tag:$committedTagId" }, points)
        CopyableValue("Working result", working[AprilTagCommonFields.RESULT].orEmpty())
        Text("${points.size} point${if (points.size == 1) "" else "s"} · frame ${referenceFrame.ifBlank { "tag-local" }}", style = MaterialTheme.typography.bodySmall)
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            pointsJson = JSONArray(points.dropLast(1).map { it.toJson() }).toString()
        }, enabled = points.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Undo") }
        OutlinedButton(onClick = { pointsJson = "[]"; referenceFrame = ""; activeReferenceTagId = -1 }, enabled = points.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("Clear") }
    }
    Button(
        onClick = {
            val committedTagId = if (targetId >= 0) targetId else activeReferenceTagId
            onCommit(As100AprilTagPlanarMeasureMethod.capture(committedTagId, state.family, state.tagSizeMm.toDoubleOrNull() ?: 100.0, mode, referenceFrame.ifBlank { "tag:$committedTagId" }, points, if (layoutJson.isBlank()) "Coordinates use the locked reference tag as the local origin." else ""))
        },
        enabled = planarEnough(mode, points.size),
        modifier = Modifier.fillMaxWidth()
    ) { Text("Commit ${mode.replace('_', ' ')}") }
    SettingsDivider()
    ChoiceField("Measurement", mode, listOf("point", "distance", "area", "trajectory")) { mode = it; pointsJson = "[]"; referenceFrame = ""; activeReferenceTagId = -1 }
    BasicDetectorSettings(state, showTagSize = true)
    OutlinedTextField(value = layoutJson, onValueChange = { layoutJson = it }, label = { Text("Optional planar tag layout JSON") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
    Text("Validity assumption: tapped objects lie on the same physical plane as the reference tag/layout. With target ID -1, the first detected tag is locked until Clear.", style = MaterialTheme.typography.bodySmall)
    LaunchedEffect(mode, layoutJson) { context.onSettingsChanged(mapOf(AprilTagInputs.MEASUREMENT_MODE to mode, AprilTagInputs.ANCHOR_LAYOUT_JSON to layoutJson)) }
}

@Composable
private fun TrackPoseInstrument(context: CapabilityScreenContext, onCommit: (Map<String, String>) -> Unit) {
    val state = rememberAprilTagSettings(context, includeIntrinsics = true)
    var movingId by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.MOVING_TAG_ID) ?: "1") }
    var referenceId by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.REFERENCE_TAG_ID) ?: "-1") }
    var intervalMs by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.SAMPLE_INTERVAL_MS) ?: "200") }
    var maxSamples by rememberSaveable { mutableStateOf(context.value(AprilTagInputs.MAX_SAMPLES) ?: "3000") }
    var samplesJson by rememberSaveable { mutableStateOf("[]") }
    var recording by rememberSaveable { mutableStateOf(false) }
    var frame by remember { mutableStateOf<AprilTagFrame?>(null) }
    val samples = remember(samplesJson) { poseSamples(samplesJson) }
    val moving = movingId.toIntOrNull() ?: 1
    val reference = referenceId.toIntOrNull() ?: -1
    val interval = intervalMs.toLongOrNull()?.coerceAtLeast(50L) ?: 200L
    val cap = maxSamples.toIntOrNull()?.coerceIn(2, 100000) ?: 3000

    CameraInstrument(state.cameraSettings(), frame, { incoming ->
        frame = incoming
        if (recording && samples.size < cap) {
            val now = System.currentTimeMillis()
            val previousTime = samples.lastOrNull()?.timeMs ?: Long.MIN_VALUE
            if (now - previousTime >= interval) {
                val movingPose = incoming.detections.firstOrNull { it.id == moving }?.pose
                val position = if (movingPose == null) null else if (reference >= 0) {
                    incoming.detections.firstOrNull { it.id == reference }?.pose?.let { refPose ->
                        AprilTagGeometry.relativePose(refPose, movingPose).translation
                    }
                } else movingPose.translation
                if (position != null) {
                    val error = incoming.detections.firstOrNull { it.id == moving }?.pose?.error
                    val updated = samples + PoseSample(now, position, error)
                    samplesJson = JSONArray().apply { updated.forEach { put(it.toJson()) } }.toString()
                    if (updated.size >= cap) recording = false
                }
            }
        }
    })
    val path = AprilTagGeometry.pathLength3d(samples)
    val duration = if (samples.size >= 2) (samples.last().timeMs - samples.first().timeMs) / 1000.0 else 0.0
    Text(if (recording) "Recording" else "Ready", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    CopyableValue("Samples", samples.size.toString())
    if (samples.size >= 2) {
        CopyableValue("Path", "${fmt(path, 3)} m")
        CopyableValue("Duration", "${fmt(duration, 2)} s")
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!recording) Button(onClick = { if (samples.isNotEmpty()) samplesJson = "[]"; recording = true }, modifier = Modifier.weight(1f)) { Text("Start") }
        else Button(onClick = { recording = false }, modifier = Modifier.weight(1f)) { Text("Stop") }
        OutlinedButton(onClick = { samplesJson = "[]"; recording = false }, modifier = Modifier.weight(1f)) { Text("Clear") }
    }
    Button(
        onClick = {
            val intrinsicsSource = frame?.intrinsics?.source.orEmpty()
            val referenceFrame = if (reference >= 0) "tag:$reference" else "camera_fixed"
            val warning = buildList {
                frame?.intrinsics?.warning?.takeIf { it.isNotBlank() }?.let(::add)
                if (reference < 0) add("Camera-frame trajectories are interpretable only if the camera remains physically fixed throughout recording.")
            }.joinToString(" ")
            onCommit(As100AprilTagTrackPoseMethod.capture(moving, reference, state.family, state.tagSizeMm.toDoubleOrNull() ?: 100.0, referenceFrame, intrinsicsSource, samples, warning))
        },
        enabled = !recording && samples.size >= 2,
        modifier = Modifier.fillMaxWidth()
    ) { Text("Commit trajectory") }
    SettingsDivider()
    NumericField("Moving tag ID", movingId) { movingId = integer(it) }
    NumericField("Reference tag ID (-1 = fixed camera)", referenceId) { referenceId = signedInteger(it) }
    NumericField("Sample interval (ms)", intervalMs) { intervalMs = integer(it) }
    NumericField("Maximum samples", maxSamples) { maxSamples = integer(it) }
    BasicDetectorSettings(state, showTagSize = true, showTargetId = false)
    IntrinsicsSettings(state)
    LaunchedEffect(movingId, referenceId, intervalMs, maxSamples) {
        context.onSettingsChanged(mapOf(
            AprilTagInputs.MOVING_TAG_ID to movingId,
            AprilTagInputs.REFERENCE_TAG_ID to referenceId,
            AprilTagInputs.SAMPLE_INTERVAL_MS to intervalMs,
            AprilTagInputs.MAX_SAMPLES to maxSamples
        ))
    }
}

@Composable
private fun CameraInstrument(
    settings: CameraSettings,
    frame: AprilTagFrame?,
    onFrame: (AprilTagFrame) -> Unit,
    onTap: ((PixelPoint) -> Unit)? = null
) {
    Box(Modifier.fillMaxWidth().height(390.dp)) {
        AprilTagCameraSurface(settings = settings, modifier = Modifier.fillMaxWidth().height(390.dp), onFrame = onFrame, onImageTap = onTap)
    }
    if (!AprilTagNativeBridge.isAvailable) {
        Text(
            "AprilTag native backend not installed. This module fails closed until libmethodmesh_apriltag is integrated; see native/README.md.",
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodySmall
        )
    } else if (!frame?.error.isNullOrBlank()) {
        Text(frame?.error.orEmpty(), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun LiveDetectionSummary(frame: AprilTagFrame?, targetId: Int) {
    val det = frame?.selected(targetId)
    if (det == null) Text("Waiting for a tag…") else {
        Text("Tag ${det.id}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        CopyableValue("Apparent edge", "${fmt(det.meanEdgePx, 1)} px")
        CopyableValue("Decision margin", fmt(det.decisionMargin, 2))
        CopyableValue("Hamming", det.hamming.toString())
    }
}

private class AprilTagSettingsState(
    val context: CapabilityScreenContext,
    private val familyState: MutableState<String>,
    private val tagSizeState: MutableState<String>,
    private val targetIdState: MutableState<String>,
    private val threadsState: MutableState<String>,
    private val decimateState: MutableState<String>,
    private val refineState: MutableState<Boolean>,
    private val intrinsicsModeState: MutableState<String>,
    private val fxState: MutableState<String>,
    private val fyState: MutableState<String>,
    private val cxState: MutableState<String>,
    private val cyState: MutableState<String>,
    private val intrinsicsWidthState: MutableState<String>,
    private val intrinsicsHeightState: MutableState<String>
) {
    var family by familyState
    var tagSizeMm by tagSizeState
    var targetTagId by targetIdState
    var threads by threadsState
    var quadDecimate by decimateState
    var refineEdges by refineState
    var intrinsicsMode by intrinsicsModeState
    var fx by fxState
    var fy by fyState
    var cx by cxState
    var cy by cyState
    var intrinsicsWidth by intrinsicsWidthState
    var intrinsicsHeight by intrinsicsHeightState

    fun cameraSettings(tagSizeMmOverride: Double? = null) = CameraSettings(
        family = family,
        tagSizeMm = tagSizeMmOverride ?: (tagSizeMm.toDoubleOrNull() ?: 100.0),
        targetTagId = targetTagId.toIntOrNull() ?: -1,
        intrinsicsMode = intrinsicsMode,
        fx = fx.toDoubleOrNull() ?: 0.0,
        fy = fy.toDoubleOrNull() ?: 0.0,
        cx = cx.toDoubleOrNull() ?: 0.0,
        cy = cy.toDoubleOrNull() ?: 0.0,
        intrinsicsWidth = intrinsicsWidth.toIntOrNull() ?: 0,
        intrinsicsHeight = intrinsicsHeight.toIntOrNull() ?: 0,
        threads = threads.toIntOrNull() ?: 2,
        quadDecimate = quadDecimate.toDoubleOrNull() ?: 2.0,
        refineEdges = refineEdges
    )

    fun settingsMap() = mapOf(
        AprilTagInputs.TAG_FAMILY to family,
        AprilTagInputs.TAG_SIZE_MM to tagSizeMm,
        AprilTagInputs.TARGET_TAG_ID to targetTagId,
        AprilTagInputs.THREADS to threads,
        AprilTagInputs.QUAD_DECIMATE to quadDecimate,
        AprilTagInputs.REFINE_EDGES to refineEdges.toString(),
        AprilTagInputs.INTRINSICS_MODE to intrinsicsMode,
        AprilTagInputs.FX_PX to fx,
        AprilTagInputs.FY_PX to fy,
        AprilTagInputs.CX_PX to cx,
        AprilTagInputs.CY_PX to cy,
        AprilTagInputs.INTRINSICS_WIDTH_PX to intrinsicsWidth,
        AprilTagInputs.INTRINSICS_HEIGHT_PX to intrinsicsHeight
    )
}

@Composable
private fun rememberAprilTagSettings(context: CapabilityScreenContext, includeIntrinsics: Boolean): AprilTagSettingsState {
    val family = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.TAG_FAMILY) ?: AprilTagContractMetadata.DEFAULT_FAMILY) }
    val tagSize = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.TAG_SIZE_MM) ?: "100") }
    val targetId = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.TARGET_TAG_ID) ?: "-1") }
    val threads = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.THREADS) ?: "2") }
    val decimate = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.QUAD_DECIMATE) ?: "2.0") }
    val refine = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.REFINE_EDGES)?.toBooleanStrictOrNull() ?: true) }
    val mode = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.INTRINSICS_MODE) ?: "auto") }
    val fx = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.FX_PX) ?: "0") }
    val fy = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.FY_PX) ?: "0") }
    val cx = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.CX_PX) ?: "0") }
    val cy = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.CY_PX) ?: "0") }
    val iw = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.INTRINSICS_WIDTH_PX) ?: "0") }
    val ih = rememberSaveable { mutableStateOf(context.value(AprilTagInputs.INTRINSICS_HEIGHT_PX) ?: "0") }

    val state = remember(context.action.canonicalId) {
        AprilTagSettingsState(context, family, tagSize, targetId, threads, decimate, refine, mode, fx, fy, cx, cy, iw, ih)
    }
    LaunchedEffect(state.family, state.tagSizeMm, state.targetTagId, state.threads, state.quadDecimate, state.refineEdges, state.intrinsicsMode, state.fx, state.fy, state.cx, state.cy, state.intrinsicsWidth, state.intrinsicsHeight) {
        context.onSettingsChanged(state.settingsMap())
    }
    return state
}

@Composable
private fun BasicDetectorSettings(state: AprilTagSettingsState, showTagSize: Boolean, showTargetId: Boolean = true) {
    FamilyPicker(state.family) { state.family = it }
    if (showTagSize) NumericField("Tag detection-edge size (mm)", state.tagSizeMm) { state.tagSizeMm = numeric(it) }
    if (showTargetId) NumericField("Target tag ID (-1 = strongest)", state.targetTagId) { state.targetTagId = signedInteger(it) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        NumericField("Threads", state.threads, Modifier.weight(1f)) { state.threads = integer(it) }
        NumericField("Quad decimate", state.quadDecimate, Modifier.weight(1f)) { state.quadDecimate = numeric(it) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Edge refinement", style = MaterialTheme.typography.bodyMedium)
        TextButton(onClick = { state.refineEdges = !state.refineEdges }) { Text(if (state.refineEdges) "On" else "Off") }
    }
}

@Composable
private fun IntrinsicsSettings(state: AprilTagSettingsState) {
    ChoiceField("Camera model", state.intrinsicsMode, listOf("auto", "manual")) { state.intrinsicsMode = it }
    if (state.intrinsicsMode == "manual") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumericField("fx (px)", state.fx, Modifier.weight(1f)) { state.fx = numeric(it) }
            NumericField("fy (px)", state.fy, Modifier.weight(1f)) { state.fy = numeric(it) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumericField("cx (px)", state.cx, Modifier.weight(1f)) { state.cx = numeric(it) }
            NumericField("cy (px)", state.cy, Modifier.weight(1f)) { state.cy = numeric(it) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumericField("Calibration width", state.intrinsicsWidth, Modifier.weight(1f)) { state.intrinsicsWidth = integer(it) }
            NumericField("Calibration height", state.intrinsicsHeight, Modifier.weight(1f)) { state.intrinsicsHeight = integer(it) }
        }
    }
}

@Composable
private fun FamilyPicker(value: String, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Tag family · $value") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            supportedFamilies.forEach { family -> DropdownMenuItem(text = { Text(family) }, onClick = { onChange(family); expanded = false }) }
        }
    }
}

@Composable
private fun ChoiceField(label: String, value: String, choices: List<String>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("$label · $value") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            choices.forEach { choice -> DropdownMenuItem(text = { Text(choice.replace('_', ' ')) }, onClick = { onChange(choice); expanded = false }) }
        }
    }
}

@Composable
private fun NumericField(label: String, value: String, modifier: Modifier = Modifier.fillMaxWidth(), onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, modifier = modifier)
}

@Composable
private fun CopyableValue(label: String, value: String) {
    val context = LocalContext.current
    OutlinedButton(
        onClick = {
            (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, value))
        },
        enabled = value.isNotBlank(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingsDivider() {
    Spacer(Modifier.height(12.dp)); HorizontalDivider(); Spacer(Modifier.height(12.dp)); Text("Settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

private fun numeric(value: String): String = value.filter { it.isDigit() || it == '.' }
private fun integer(value: String): String = value.filter(Char::isDigit)
private fun signedInteger(value: String): String = value.filterIndexed { index, c -> c.isDigit() || (c == '-' && index == 0) }

private fun edgeShapeCv(det: AprilTagDetection): Double {
    if (det.corners.size != 4) return Double.POSITIVE_INFINITY
    val edges = det.corners.indices.map { i ->
        val a = det.corners[i]; val b = det.corners[(i + 1) % 4]
        kotlin.math.hypot(a.x - b.x, a.y - b.y)
    }
    return AprilTagGeometry.coefficientOfVariation(edges)
}

private fun jsonDoubles(json: String): List<Double> = runCatching {
    val a = JSONArray(json); (0 until a.length()).map { a.getDouble(it) }
}.getOrDefault(emptyList())

private fun planarPoints(json: String): List<PlanarPoint> = runCatching {
    val a = JSONArray(json); (0 until a.length()).map { i ->
        val o = a.getJSONObject(i); PlanarPoint(o.getDouble("x_mm"), o.getDouble("y_mm"), o.getLong("time_ms"))
    }
}.getOrDefault(emptyList())

private fun poseSamples(json: String): List<PoseSample> = runCatching {
    val a = JSONArray(json); (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        PoseSample(o.getLong("time_ms"), Vec3(o.getDouble("x_m"), o.getDouble("y_m"), o.getDouble("z_m")), if (o.isNull("pose_error")) null else o.getDouble("pose_error"))
    }
}.getOrDefault(emptyList())

private fun planarEnough(mode: String, count: Int): Boolean = when (mode) {
    "point" -> count >= 1
    "distance" -> count >= 2
    "area" -> count >= 3
    "trajectory" -> count >= 2
    else -> false
}

private fun CapabilityScreenContext.value(key: String): String? =
    (action.settings[key] ?: action.settings["input_$key"] ?: request.settings[key] ?: request.settings["input_$key"])
        ?.takeIf { it.isNotBlank() }
