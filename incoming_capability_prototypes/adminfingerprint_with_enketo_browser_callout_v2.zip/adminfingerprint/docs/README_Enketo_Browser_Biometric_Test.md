# Enketo browser biometric call-out test

This is a deliberately small integration probe for **stock Enketo**. It does not require custom JavaScript or changes to the Enketo deployment.

## Main-app integration checked

The current MethodMesh `main/AndroidManifest.xml` already exposes `IntentRouterActivity` as a browser-safe deep-link target:

```xml
<intent-filter>
    <action android:name="android.intent.action.VIEW" />
    <category android:name="android.intent.category.DEFAULT" />
    <category android:name="android.intent.category.BROWSABLE" />
    <data android:scheme="methodmesh" />
</intent-filter>
```

Therefore **no manifest change is required for the Enketo/browser call-out**. The browser should use this existing `methodmesh://` route. The separate `com.example.methodmesh.EXECUTE_METHOD` action remains the ODK/Android-intent route and does not need to be made BROWSABLE.

## What the test proves

- Enketo renders an `appearance=url` question containing an Android `intent:` URI.
- A user tap can leave the browser and resolve the existing MethodMesh `methodmesh://` deep link.
- MethodMesh can start the `admin_browser_biometric_callout` capability immediately.
- Android can show the biometric prompt.
- When the MethodMesh external workflow finishes, Android returns to the still-open browser/Enketo task.

It does **not** test automatic return of `confirmed=true` into an Enketo field. Stock Enketo has no general browser-to-native activity-result bridge for this.

## Test procedure

1. Install a MethodMesh build containing `admin_browser_biometric_callout` on an Android device with an enrolled biometric.
2. Upload `example_enketo_browser_biometric_callout.xlsx` to the form server and open it in **Chrome on the same Android device**.
3. Tap **Open MethodMesh biometric confirmation**.
4. Expected result: Chrome resolves the existing `methodmesh://` BROWSABLE deep link to MethodMesh; MethodMesh immediately opens the biometric prompt.
5. Complete the biometric prompt.
6. MethodMesh should finish the external workflow automatically and reveal the still-open Chrome/Enketo form.
7. Answer the diagnostic questions.

## Browser URI used by the XLSForm

```text
intent://execute?method_id=admin_browser_biometric_callout&input_caller=enketo&input_confirmation_reason=enketo_browser_test#Intent;scheme=methodmesh;end
```

Chrome converts this to an Android `ACTION_VIEW` request whose data URI is effectively:

```text
methodmesh://execute?method_id=admin_browser_biometric_callout&input_caller=enketo&input_confirmation_reason=enketo_browser_test
```

`IntentRouterActivity` already accepts that scheme, and `LaunchConfigParser` reads the query parameters from `intent.dataString`.

## Expected limitations

- Desktop browsers cannot perform this Android app call-out.
- iOS requires a separate iOS deep-link/app implementation.
- Some Enketo deployments may reject or neutralise non-HTTP URL schemes. The current test has already shown that this deployment allows an Android `intent:` URI to leave Enketo, so the remaining issue was Android intent resolution rather than Enketo security.
- The diagnostic yes/no fields are test instrumentation only; they are not security evidence.
