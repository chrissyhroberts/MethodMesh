package com.example.methodmesh.modules.star_spectrum

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.Dialog
import java.util.Locale
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

internal data class TraceSelection(val startX: Float, val startY: Float, val endX: Float, val endY: Float) {
    val length: Float get() = hypot(endX - startX, endY - startY)
}

@Composable
internal fun SpectrumToolHeader(
    title: String,
    subtitle: String,
    committed: Boolean,
    canGoBack: Boolean,
    onBack: () -> Unit,
    onCancel: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Surface(
            shape = RoundedCornerShape(50),
            color = if (committed) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer
        ) {
            Text(
                if (committed) "Committed" else "Working",
                modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (canGoBack) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
        OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
    }
}

@Composable
internal fun SpectrumSection(
    title: String,
    hint: String? = null,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            hint?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
            }
            content()
        }
    }
}

@Composable
internal fun MetricTile(label: String, value: String, copyValue: String = value, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Surface(
        modifier = modifier.clickable(enabled = copyValue.isNotBlank()) { copyToClipboard(context, label, copyValue) },
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value.ifBlank { "—" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
internal fun SpectrumImageSurface(
    bitmap: Bitmap,
    trace: TraceSelection?,
    onSelectEndpoints: () -> Unit,
    ribbonHalfWidthPx: Int,
    extraction: SpectrumExtraction? = null,
    modifier: Modifier = Modifier
) {
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var viewScale by rememberSaveable { mutableFloatStateOf(1f) }
    var panX by rememberSaveable { mutableFloatStateOf(0f) }
    var panY by rememberSaveable { mutableFloatStateOf(0f) }
    val primaryColor = MaterialTheme.colorScheme.primary

    Column(modifier) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(360.dp)
                .background(Color(0xFF05070B), RoundedCornerShape(18.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                .onSizeChanged { boxSize = it }
                .pointerInput(boxSize, viewScale, panX, panY) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        viewScale = (viewScale * zoom).coerceIn(1f, 8f)
                        panX += pan.x
                        panY += pan.y
                    }
                }
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Stellar spectrum image",
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = viewScale
                        scaleY = viewScale
                        translationX = panX
                        translationY = panY
                    },
                contentScale = ContentScale.Fit
            )
            Canvas(Modifier.fillMaxSize()) {
                if (boxSize.width <= 0 || boxSize.height <= 0) return@Canvas
                trace?.let { user ->
                    val a = imageToScreen(Offset(user.startX, user.startY), boxSize, bitmap, viewScale, Offset(panX, panY))
                    val b = imageToScreen(Offset(user.endX, user.endY), boxSize, bitmap, viewScale, Offset(panX, panY))
                    if (a != null && b != null) {
                        val d = b - a
                        val len = hypot(d.x, d.y).coerceAtLeast(1f)
                        val nx = -d.y / len
                        val ny = d.x / len
                        val fitScale = fittedRect(boxSize, bitmap).width / bitmap.width.toFloat()
                        val ribbon = ribbonHalfWidthPx * fitScale * viewScale
                        drawLine(Color.White.copy(alpha = 0.9f), a, b, strokeWidth = 3f)
                        drawLine(primaryColor.copy(alpha = 0.65f), a + Offset(nx * ribbon, ny * ribbon), b + Offset(nx * ribbon, ny * ribbon), strokeWidth = 1.5f)
                        drawLine(primaryColor.copy(alpha = 0.65f), a - Offset(nx * ribbon, ny * ribbon), b - Offset(nx * ribbon, ny * ribbon), strokeWidth = 1.5f)
                        drawCircle(primaryColor, radius = 7f, center = a)
                        drawCircle(Color.White, radius = 7f, center = b, style = Stroke(3f))
                    }
                }
                extraction?.let { result ->
                    val stride = max(1, result.trace.sampleX.size / 800)
                    var previous: Offset? = null
                    for (i in result.trace.sampleX.indices step stride) {
                        val p = imageToScreen(
                            Offset(result.trace.sampleX[i].toFloat(), result.trace.sampleY[i].toFloat()),
                            boxSize, bitmap, viewScale, Offset(panX, panY)
                        ) ?: continue
                        previous?.let { drawLine(Color(0xFF55E0C2), it, p, strokeWidth = 3f) }
                        previous = p
                        if (result.contaminationProbability[i] >= 0.5) {
                            drawCircle(Color(0xFFFF765E).copy(alpha = 0.85f), 3f + 4f * result.contaminationProbability[i].toFloat(), p)
                        }
                    }
                    result.features.filter { it.confidence >= 0.35 }.take(30).forEach { feature ->
                        val i = feature.index.coerceIn(0, result.trace.sampleX.lastIndex)
                        imageToScreen(
                            Offset(result.trace.sampleX[i].toFloat(), result.trace.sampleY[i].toFloat()),
                            boxSize, bitmap, viewScale, Offset(panX, panY)
                        )?.let { drawCircle(Color(0xFFFFD95A), 6f, it, style = Stroke(2f)) }
                    }
                }
            }
            Surface(
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp),
                shape = RoundedCornerShape(10.dp),
                color = Color.Black.copy(alpha = 0.68f)
            ) {
                Text(
                    if (trace == null) "No endpoints selected" else "RED → VIOLET selected",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onSelectEndpoints, modifier = Modifier.weight(1f)) {
                Text(if (trace == null) "Select RED & VIOLET" else "Edit RED & VIOLET")
            }
            OutlinedButton(
                onClick = { viewScale = 1f; panX = 0f; panY = 0f },
                modifier = Modifier.weight(1f)
            ) { Text("Reset view") }
        }
    }
}

@Composable
internal fun SpectrumEndpointPickerDialog(
    bitmap: Bitmap,
    initialTrace: TraceSelection?,
    onDismiss: () -> Unit,
    onSelected: (TraceSelection) -> Unit
) {
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var viewScale by rememberSaveable { mutableFloatStateOf(1f) }
    var panX by rememberSaveable { mutableFloatStateOf(0f) }
    var panY by rememberSaveable { mutableFloatStateOf(0f) }

    var redPoint by remember(initialTrace) {
        mutableStateOf(initialTrace?.let { Offset(it.startX, it.startY) })
    }
    var violetPoint by remember(initialTrace) {
        mutableStateOf(initialTrace?.let { Offset(it.endX, it.endY) })
    }
    var activeEndpoint by rememberSaveable { mutableStateOf(if (initialTrace == null) "red" else "red") }

    var magnifierPoint by remember { mutableStateOf<Offset?>(null) }
    var stableHoldPoint by remember { mutableStateOf<Offset?>(null) }
    var magnifying by remember { mutableStateOf(false) }
    var holdConfirmed by remember { mutableStateOf(false) }
    var stabilityToken by remember { mutableStateOf(0) }
    var lockProgress by remember { mutableFloatStateOf(0f) }
    var lockFeedback by remember { mutableStateOf<String?>(null) }
    var navigationMode by rememberSaveable { mutableStateOf(initialTrace != null) }

    var redXText by remember(initialTrace) {
        mutableStateOf(initialTrace?.startX?.let { String.format(Locale.US, "%.1f", it) } ?: "")
    }
    var redYText by remember(initialTrace) {
        mutableStateOf(initialTrace?.startY?.let { String.format(Locale.US, "%.1f", it) } ?: "")
    }
    var violetXText by remember(initialTrace) {
        mutableStateOf(initialTrace?.endX?.let { String.format(Locale.US, "%.1f", it) } ?: "")
    }
    var violetYText by remember(initialTrace) {
        mutableStateOf(initialTrace?.endY?.let { String.format(Locale.US, "%.1f", it) } ?: "")
    }

    val redColor = Color(0xFFFF5E62)
    val violetColor = Color(0xFFB78CFF)

    fun clampToImage(point: Offset): Offset = Offset(
        point.x.coerceIn(0f, (bitmap.width - 1).coerceAtLeast(0).toFloat()),
        point.y.coerceIn(0f, (bitmap.height - 1).coerceAtLeast(0).toFloat())
    )

    fun updateEndpoint(endpoint: String, point: Offset) {
        val p = clampToImage(point)
        if (endpoint == "red") {
            redPoint = p
            redXText = String.format(Locale.US, "%.1f", p.x)
            redYText = String.format(Locale.US, "%.1f", p.y)
        } else {
            violetPoint = p
            violetXText = String.format(Locale.US, "%.1f", p.x)
            violetYText = String.format(Locale.US, "%.1f", p.y)
        }
    }

    fun applyManual(endpoint: String) {
        val xText = if (endpoint == "red") redXText else violetXText
        val yText = if (endpoint == "red") redYText else violetYText
        val x = xText.toFloatOrNull() ?: return
        val y = yText.toFloatOrNull() ?: return
        updateEndpoint(endpoint, Offset(x, y))
    }

    val canFinish = redPoint != null &&
        violetPoint != null &&
        hypot(
            (violetPoint?.x ?: 0f) - (redPoint?.x ?: 0f),
            (violetPoint?.y ?: 0f) - (redPoint?.y ?: 0f)
        ) >= 12f

    LaunchedEffect(magnifying, stabilityToken, activeEndpoint, navigationMode) {
        val candidate = stableHoldPoint
        val endpoint = activeEndpoint
        val token = stabilityToken

        if (magnifying && !navigationMode && candidate != null) {
            lockProgress = 0f
            lockFeedback = null

            for (step in 1..30) {
                delay(100)
                if (
                    !magnifying ||
                    navigationMode ||
                    stabilityToken != token ||
                    activeEndpoint != endpoint
                ) {
                    return@LaunchedEffect
                }
                lockProgress = step / 30f
            }

            if (
                magnifying &&
                !navigationMode &&
                stabilityToken == token &&
                activeEndpoint == endpoint
            ) {
                updateEndpoint(endpoint, candidate)
                holdConfirmed = true
                lockProgress = 1f
                lockFeedback = "${endpoint.uppercase(Locale.US)} LOCKED ✓"
            }
        }
    }

    val endpointGestureModifier =
        if (navigationMode) {
            Modifier.pointerInput(boxSize, bitmap, viewScale, panX, panY) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (boxSize.width <= 0 || boxSize.height <= 0) return@detectTransformGestures

                    val newScale = (viewScale * zoom).coerceIn(1f, 12f)
                    val fitted = fittedRect(boxSize, bitmap)
                    val scaledWidth = fitted.width * newScale
                    val scaledHeight = fitted.height * newScale
                    val maxPanX = max(0f, (scaledWidth - boxSize.width) / 2f + 24f)
                    val maxPanY = max(0f, (scaledHeight - boxSize.height) / 2f + 24f)

                    viewScale = newScale
                    panX = (panX + pan.x).coerceIn(-maxPanX, maxPanX)
                    panY = (panY + pan.y).coerceIn(-maxPanY, maxPanY)
                }
            }
        } else {
            Modifier.pointerInput(
                boxSize,
                bitmap,
                viewScale,
                panX,
                panY,
                activeEndpoint,
                stabilityToken,
                holdConfirmed
            ) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { point ->
                        val imagePoint = screenToImage(
                            point,
                            boxSize,
                            bitmap,
                            viewScale,
                            Offset(panX, panY)
                        ) ?: return@detectDragGesturesAfterLongPress

                        magnifying = true
                        holdConfirmed = false
                        stableHoldPoint = imagePoint
                        magnifierPoint = imagePoint
                        stabilityToken += 1
                        lockProgress = 0f
                        lockFeedback = null
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        if (holdConfirmed) return@detectDragGesturesAfterLongPress

                        val imagePoint = screenToImage(
                            change.position,
                            boxSize,
                            bitmap,
                            viewScale,
                            Offset(panX, panY)
                        ) ?: return@detectDragGesturesAfterLongPress

                        val stable = stableHoldPoint
                        if (
                            stable == null ||
                            hypot(imagePoint.x - stable.x, imagePoint.y - stable.y) > 3f
                        ) {
                            // Ignore normal finger tremor within a 3-image-pixel radius.
                            stableHoldPoint = imagePoint
                            magnifierPoint = imagePoint
                            stabilityToken += 1
                            lockProgress = 0f
                            lockFeedback = null
                        }
                    },
                    onDragEnd = {
                        magnifying = false
                        stableHoldPoint = null
                        magnifierPoint = null
                        lockProgress = if (holdConfirmed) 1f else 0f

                        if (holdConfirmed) {
                            if (activeEndpoint == "red" && violetPoint == null) {
                                activeEndpoint = "violet"
                                navigationMode = false
                            } else if (activeEndpoint == "violet") {
                                navigationMode = true
                            }
                        }
                        holdConfirmed = false
                    },
                    onDragCancel = {
                        magnifying = false
                        stableHoldPoint = null
                        magnifierPoint = null
                        lockProgress = 0f
                        holdConfirmed = false
                    }
                )
            }
        }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF020305)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { boxSize = it }
                    .then(endpointGestureModifier)
            ) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Full-screen stellar spectrum",
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = viewScale
                            scaleY = viewScale
                            translationX = panX
                            translationY = panY
                        },
                    contentScale = ContentScale.Fit
                )

                Canvas(Modifier.fillMaxSize()) {
                    val red = redPoint?.let {
                        imageToScreen(it, boxSize, bitmap, viewScale, Offset(panX, panY))
                    }
                    val violet = violetPoint?.let {
                        imageToScreen(it, boxSize, bitmap, viewScale, Offset(panX, panY))
                    }

                    if (red != null && violet != null) {
                        drawLine(Color.White.copy(alpha = 0.88f), red, violet, strokeWidth = 3f)
                    }

                    red?.let {
                        drawCircle(Color.Black.copy(alpha = 0.68f), radius = 17f, center = it)
                        drawCircle(redColor, radius = 11f, center = it)
                        drawCircle(Color.White, radius = 4f, center = it)
                    }

                    violet?.let {
                        drawCircle(Color.Black.copy(alpha = 0.68f), radius = 17f, center = it)
                        drawCircle(violetColor, radius = 11f, center = it)
                        drawCircle(Color.White, radius = 4f, center = it)
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 18.dp, vertical = 18.dp),
                    shape = RoundedCornerShape(18.dp),
                    color = Color.Black.copy(alpha = 0.78f)
                ) {
                    Column(
                        Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val instruction = when {
                            navigationMode -> "PAN / ZOOM"
                            activeEndpoint == "red" && redPoint == null -> "Place RED · hold, position, keep still"
                            activeEndpoint == "violet" && violetPoint == null -> "Place VIOLET · hold, position, keep still"
                            activeEndpoint == "red" -> "Edit RED · hold, position, keep still"
                            else -> "Edit VIOLET · hold, position, keep still"
                        }
                        Text(
                            instruction,
                            color = if (activeEndpoint == "red") redColor else violetColor,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            if (navigationMode)
                                "Drag to pan · pinch to zoom · choose RED or VIOLET to place"
                            else
                                "3 px tremor deadband · stationary for 3 seconds locks the coordinate",
                            color = Color.White.copy(alpha = 0.74f),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (magnifying) {
                    magnifierPoint?.let { point ->
                        SpectrumMagnifier(
                            bitmap = bitmap,
                            point = point,
                            accent = if (activeEndpoint == "red") redColor else violetColor,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 92.dp, end = 16.dp)
                        )
                    }
                }

                if (!navigationMode && (magnifying || lockFeedback != null)) {
                    val remaining = (3.0 * (1.0 - lockProgress.coerceIn(0f, 1f))).coerceAtLeast(0.0)
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 274.dp, end = 16.dp)
                            .width(172.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = Color.Black.copy(alpha = 0.86f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (lockFeedback != null) Color(0xFF66D19E)
                            else if (activeEndpoint == "red") redColor else violetColor
                        )
                    ) {
                        Column(
                            Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                lockFeedback ?: "Hold steady  ${"%.1f".format(Locale.US, remaining)} s",
                                color = if (lockFeedback != null) Color(0xFF8EE6B8) else Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(2.dp))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(lockProgress.coerceIn(0f, 1f))
                                        .height(4.dp)
                                        .background(
                                            if (lockFeedback != null) Color(0xFF66D19E)
                                            else if (activeEndpoint == "red") redColor else violetColor,
                                            RoundedCornerShape(2.dp)
                                        )
                                )
                            }
                        }
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth(),
                    color = Color.Black.copy(alpha = 0.84f)
                ) {
                    Column(
                        Modifier
                            .navigationBarsPadding()
                            .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 30.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (navigationMode) {
                                Button(
                                    onClick = { navigationMode = true },
                                    modifier = Modifier.weight(1f)
                                ) { Text("PAN / ZOOM") }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        navigationMode = true
                                        magnifying = false
                                        stableHoldPoint = null
                                        magnifierPoint = null
                                        lockProgress = 0f
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("PAN / ZOOM") }
                            }

                            if (!navigationMode && activeEndpoint == "red") {
                                Button(
                                    onClick = { activeEndpoint = "red" },
                                    modifier = Modifier.weight(1f)
                                ) { Text("RED") }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        navigationMode = false
                                        activeEndpoint = "red"
                                        lockFeedback = null
                                        lockProgress = 0f
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("RED") }
                            }

                            if (!navigationMode && activeEndpoint == "violet") {
                                Button(
                                    onClick = { activeEndpoint = "violet" },
                                    modifier = Modifier.weight(1f)
                                ) { Text("VIOLET") }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        navigationMode = false
                                        activeEndpoint = "violet"
                                        lockFeedback = null
                                        lockProgress = 0f
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("VIOLET") }
                            }
                        }

                        Text(
                            "Image coordinates — x 0–${bitmap.width - 1}, y 0–${bitmap.height - 1}",
                            color = Color.White.copy(alpha = 0.62f),
                            style = MaterialTheme.typography.labelSmall
                        )

                        CoordinateEditorRow(
                            label = "RED",
                            labelColor = redColor,
                            xText = redXText,
                            yText = redYText,
                            onXChange = { redXText = it },
                            onYChange = { redYText = it },
                            onApply = { applyManual("red") }
                        )

                        CoordinateEditorRow(
                            label = "VIOLET",
                            labelColor = violetColor,
                            xText = violetXText,
                            yText = violetYText,
                            onXChange = { violetXText = it },
                            onYChange = { violetYText = it },
                            onApply = { applyManual("violet") }
                        )

                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier.weight(1f)
                            ) { Text("Cancel") }

                            OutlinedButton(
                                onClick = {
                                    redPoint = null
                                    violetPoint = null
                                    redXText = ""
                                    redYText = ""
                                    violetXText = ""
                                    violetYText = ""
                                    activeEndpoint = "red"
                                    viewScale = 1f
                                    panX = 0f
                                    panY = 0f
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Reset") }

                            Button(
                                enabled = canFinish,
                                onClick = {
                                    val red = redPoint ?: return@Button
                                    val violet = violetPoint ?: return@Button
                                    onSelected(
                                        TraceSelection(
                                            startX = red.x,
                                            startY = red.y,
                                            endX = violet.x,
                                            endY = violet.y
                                        )
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) { Text("Done") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CoordinateEditorRow(
    label: String,
    labelColor: Color,
    xText: String,
    yText: String,
    onXChange: (String) -> Unit,
    onYChange: (String) -> Unit,
    onApply: () -> Unit
) {
    val valid = xText.toFloatOrNull() != null && yText.toFloatOrNull() != null
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            modifier = Modifier.width(54.dp),
            color = labelColor,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold
        )
        OutlinedTextField(
            value = xText,
            onValueChange = onXChange,
            modifier = Modifier.weight(1f),
            singleLine = true,
            label = { Text("x") }
        )
        OutlinedTextField(
            value = yText,
            onValueChange = onYChange,
            modifier = Modifier.weight(1f),
            singleLine = true,
            label = { Text("y") }
        )
        OutlinedButton(
            onClick = onApply,
            enabled = valid
        ) { Text("Apply") }
    }
}

@Composable
private fun SpectrumMagnifier(
    bitmap: Bitmap,
    point: Offset,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val image = remember(bitmap) { bitmap.asImageBitmap() }
    Surface(
        modifier = modifier
            .width(172.dp)
            .height(172.dp),
        shape = RoundedCornerShape(18.dp),
        color = Color.Black.copy(alpha = 0.92f),
        border = androidx.compose.foundation.BorderStroke(2.dp, accent)
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cropSize = 44
            val half = cropSize / 2
            val maxX = (bitmap.width - cropSize).coerceAtLeast(0)
            val maxY = (bitmap.height - cropSize).coerceAtLeast(0)
            val left = (point.x.toInt() - half).coerceIn(0, maxX)
            val top = (point.y.toInt() - half).coerceIn(0, maxY)
            val srcW = cropSize.coerceAtMost(bitmap.width)
            val srcH = cropSize.coerceAtMost(bitmap.height)

            drawImage(
                image = image,
                srcOffset = IntOffset(left, top),
                srcSize = IntSize(srcW, srcH),
                dstOffset = IntOffset.Zero,
                dstSize = IntSize(size.width.toInt(), size.height.toInt())
            )

            val cx = size.width / 2f
            val cy = size.height / 2f
            drawLine(Color.Black.copy(alpha = 0.75f), Offset(cx - 24f, cy), Offset(cx + 24f, cy), 5f)
            drawLine(Color.Black.copy(alpha = 0.75f), Offset(cx, cy - 24f), Offset(cx, cy + 24f), 5f)
            drawLine(accent, Offset(cx - 24f, cy), Offset(cx + 24f, cy), 2f)
            drawLine(accent, Offset(cx, cy - 24f), Offset(cx, cy + 24f), 2f)
            drawCircle(Color.White, radius = 4f, center = Offset(cx, cy), style = Stroke(2f))
        }
    }
}

private fun buildExtractedSpectrumStrip(
    bitmap: Bitmap,
    extraction: SpectrumExtraction,
    apertureHalfWidthPx: Int,
    reverseForDisplay: Boolean = true
): Bitmap {
    val sampleCount = extraction.trace.sampleX.size.coerceAtLeast(1)
    val outHeight = 28
    val strip = Bitmap.createBitmap(sampleCount, outHeight, Bitmap.Config.ARGB_8888)

    fun sampleColour(i: Int): Int {
        val x0 = extraction.trace.sampleX[i].toFloat()
        val y0 = extraction.trace.sampleY[i].toFloat()

        val i0 = (i - 1).coerceAtLeast(0)
        val i1 = (i + 1).coerceAtMost(extraction.trace.sampleX.lastIndex)
        val tx = extraction.trace.sampleX[i1] - extraction.trace.sampleX[i0]
        val ty = extraction.trace.sampleY[i1] - extraction.trace.sampleY[i0]
        val len = hypot(tx.toFloat(), ty.toFloat()).coerceAtLeast(1f)
        val nx = -ty.toFloat() / len
        val ny = tx.toFloat() / len

        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0

        for (offset in -apertureHalfWidthPx..apertureHalfWidthPx) {
            val x = (x0 + nx * offset).toInt().coerceIn(0, bitmap.width - 1)
            val y = (y0 + ny * offset).toInt().coerceIn(0, bitmap.height - 1)
            val c = bitmap.getPixel(x, y)
            r += AndroidColor.red(c)
            g += AndroidColor.green(c)
            b += AndroidColor.blue(c)
            n++
        }

        val rr = (r / n.coerceAtLeast(1)).toInt().coerceIn(0, 255)
        val gg = (g / n.coerceAtLeast(1)).toInt().coerceIn(0, 255)
        val bb = (b / n.coerceAtLeast(1)).toInt().coerceIn(0, 255)
        return AndroidColor.rgb(rr, gg, bb)
    }

    for (displayX in 0 until sampleCount) {
        val sourceIndex = if (reverseForDisplay) sampleCount - 1 - displayX else displayX
        val colour = sampleColour(sourceIndex.coerceIn(0, extraction.trace.sampleX.lastIndex))
        for (y in 0 until outHeight) strip.setPixel(displayX, y, colour)
    }
    return strip
}

@Composable
internal fun ExtractedSpectrumStrip(
    bitmap: Bitmap,
    extraction: SpectrumExtraction,
    apertureHalfWidthPx: Int,
    modifier: Modifier = Modifier
) {
    val stripBitmap = remember(bitmap, extraction, apertureHalfWidthPx) {
        buildExtractedSpectrumStrip(
            bitmap = bitmap,
            extraction = extraction,
            apertureHalfWidthPx = apertureHalfWidthPx,
            reverseForDisplay = true
        )
    }

    Column(modifier) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "VIOLET",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFB78CFF)
            )
            Text(
                "Extracted spectrum",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                "RED",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFF5E62)
            )
        }

        Spacer(Modifier.height(6.dp))

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(10.dp),
            color = Color.Black,
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant
            )
        ) {
            Image(
                bitmap = stripBitmap.asImageBitmap(),
                contentDescription = "Extracted stellar spectrum from violet to red",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        }

        Spacer(Modifier.height(4.dp))
        Text(
            "Photographic appearance sampled across the extracted aperture. Displayed VIOLET → RED; colour is from the source image and is not radiometrically calibrated.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
internal fun SpectrumChart(
    extraction: SpectrumExtraction,
    modifier: Modifier = Modifier,
    selectedIndex: Int? = null,
    onTapIndex: ((Int) -> Unit)? = null
) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    val signal = extraction.corrected
    val validValues = signal.indices.filter { extraction.valid[it] }.map { signal[it] }
    val minValue = validValues.minOrNull() ?: signal.minOrNull() ?: 0.0
    val maxValue = validValues.maxOrNull() ?: signal.maxOrNull() ?: 1.0
    val range = (maxValue - minValue).coerceAtLeast(1e-6)
    val paddingX = 18f
    val paddingTop = 18f
    val paddingBottom = 34f

    Box(
        modifier
            .fillMaxWidth()
            .height(260.dp)
            .background(Color(0xFF090D13), RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .onSizeChanged { size = it }
            .pointerInput(extraction, onTapIndex, size) {
                if (onTapIndex != null) {
                    detectTapGestures { point ->
                        if (size.width > paddingX * 2 && extraction.distancesPx.isNotEmpty()) {
                            val f = ((point.x - paddingX) / (size.width - paddingX * 2)).coerceIn(0f, 1f)
                            onTapIndex((f * extraction.distancesPx.lastIndex).toInt().coerceIn(0, extraction.distancesPx.lastIndex))
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val plotW = (this.size.width - paddingX * 2).coerceAtLeast(1f)
            val plotH = (this.size.height - paddingTop - paddingBottom).coerceAtLeast(1f)
            for (g in 0..4) {
                val y = paddingTop + plotH * g / 4f
                drawLine(Color.White.copy(alpha = 0.09f), Offset(paddingX, y), Offset(paddingX + plotW, y), 1f)
            }
            var previous: Offset? = null
            signal.indices.forEach { i ->
                val x = paddingX + plotW * i / max(1, signal.lastIndex).toFloat()
                val y = paddingTop + plotH * (1f - ((signal[i] - minValue) / range).toFloat().coerceIn(0f, 1f))
                val point = Offset(x, y)
                previous?.let { drawLine(Color(0xFF67E4CB), it, point, 2.2f) }
                previous = point
                if (extraction.contaminationProbability[i] >= 0.6) {
                    drawLine(Color(0xFFFF765E).copy(alpha = 0.35f), Offset(x, paddingTop), Offset(x, paddingTop + plotH), 2f)
                }
            }
            extraction.features.forEach { feature ->
                val i = feature.index
                val x = paddingX + plotW * i / max(1, signal.lastIndex).toFloat()
                val y = paddingTop + plotH * (1f - ((signal[i] - minValue) / range).toFloat().coerceIn(0f, 1f))
                drawCircle(
                    if (feature.type == FeatureType.Emission) Color(0xFFFFD95A) else Color(0xFFCAB7FF),
                    radius = 4.8f,
                    center = Offset(x, y),
                    style = Stroke(2f)
                )
            }
            selectedIndex?.coerceIn(0, signal.lastIndex)?.let { i ->
                val x = paddingX + plotW * i / max(1, signal.lastIndex).toFloat()
                drawLine(Color.White.copy(alpha = 0.8f), Offset(x, paddingTop), Offset(x, paddingTop + plotH), 2f)
            }
            if (extraction.calibration != null) {
                val gradient = Brush.horizontalGradient(
                    listOf(
                        Color(0xFF5E4BFF), Color(0xFF2678FF), Color(0xFF29C98A),
                        Color(0xFFE2D64D), Color(0xFFFF9B42), Color(0xFFFF4D55)
                    ),
                    startX = paddingX,
                    endX = paddingX + plotW
                )
                drawRect(gradient, topLeft = Offset(paddingX, this.size.height - 17f), size = Size(plotW, 5f))
            }
        }
        val leftLabel = extraction.wavelengthAt(0)?.let { "%.0f nm".format(Locale.US, it) } ?: "0 px"
        val rightLabel = extraction.wavelengthAt(extraction.distancesPx.lastIndex)?.let { "%.0f nm".format(Locale.US, it) }
            ?: "%.0f px".format(Locale.US, extraction.distancesPx.lastOrNull() ?: 0.0)
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(leftLabel, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
            Text(if (extraction.calibration != null) "wavelength" else "distance along trace", color = Color.White.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
            Text(rightLabel, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelSmall)
        }
    }
}


private fun spectrumMovingAverage(values: DoubleArray, radius: Int): DoubleArray {
    if (values.isEmpty()) return values
    val r = radius.coerceAtLeast(0)
    if (r == 0) return values.copyOf()

    val result = DoubleArray(values.size)
    var sum = 0.0
    var count = 0

    for (i in values.indices) {
        val add = i + r
        if (add < values.size && values[add].isFinite()) {
            sum += values[add]
            count++
        }
        val remove = i - r - 1
        if (remove >= 0 && values[remove].isFinite()) {
            sum -= values[remove]
            count--
        }
        result[i] = if (count > 0) sum / count else Double.NaN
    }

    return result
}

private fun spectrumRollingMedian(values: DoubleArray, window: Int): DoubleArray {
    if (values.isEmpty()) return values
    val half = (window.coerceAtLeast(3) / 2).coerceAtLeast(1)
    return DoubleArray(values.size) { i ->
        val start = (i - half).coerceAtLeast(0)
        val end = (i + half).coerceAtMost(values.lastIndex)
        val local = values.sliceArray(start..end)
            .filter { it.isFinite() }
            .sorted()
        if (local.isEmpty()) {
            Double.NaN
        } else if (local.size % 2 == 1) {
            local[local.size / 2]
        } else {
            (local[local.size / 2 - 1] + local[local.size / 2]) / 2.0
        }
    }
}

private fun calibrationNormalisedSignal(extraction: SpectrumExtraction): DoubleArray {
    if (extraction.corrected.isEmpty()) return DoubleArray(0)

    // A small amount of display smoothing suppresses single-pixel JPEG/demosaic
    // noise without changing the sample coordinates used for calibration.
    val smoothed = spectrumMovingAverage(extraction.corrected, radius = 2)

    // Use a broad continuum for A-star Balmer troughs. The default engine
    // continuum is also now broader, but the calibration view deliberately
    // uses at least ~1/8 of the spectrum so broad absorption is not fitted away.
    val wanted = max(101, extraction.corrected.size / 8)
    val continuumWindow = if (wanted % 2 == 0) wanted + 1 else wanted
    val continuum = spectrumRollingMedian(smoothed, continuumWindow.coerceAtMost(301))

    val finiteContinuum = continuum.filter { it.isFinite() && it > 0.0 }
    val maxContinuum = finiteContinuum.maxOrNull() ?: 0.0

    // Below 3% of the useful continuum the JPEG is dominated by background and
    // channel noise. Do not turn division-by-near-zero into fake spectral lines.
    val reliabilityFloor = max(maxContinuum * 0.03, 1e-12)

    return DoubleArray(smoothed.size) { i ->
        val c = continuum[i]
        val v = smoothed[i]
        if (
            !v.isFinite() ||
            !c.isFinite() ||
            c <= reliabilityFloor ||
            !extraction.valid[i]
        ) {
            Double.NaN
        } else {
            (v / c).coerceIn(0.25, 1.75)
        }
    }
}

@Composable
internal fun BalmerAnchorChart(
    extraction: SpectrumExtraction,
    anchors: List<CalibrationAnchor>,
    activeLabel: String,
    onPlaceIndex: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var size by remember { mutableStateOf(IntSize.Zero) }
    var zoomX by rememberSaveable { mutableFloatStateOf(1f) }
    var centreFraction by rememberSaveable { mutableFloatStateOf(0.5f) }
    var fineIndex by rememberSaveable { mutableStateOf(-1) }
    var magnifying by remember { mutableStateOf(false) }
    var showRaw by rememberSaveable { mutableStateOf(false) }
    var chartNavigationMode by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(activeLabel) {
        chartNavigationMode = false
    }

    val rawSignal = extraction.corrected
    val signal = remember(extraction, showRaw) {
        if (showRaw) rawSignal.copyOf() else calibrationNormalisedSignal(extraction)
    }

    val paddingX = 18f
    val paddingTop = 26f
    val paddingBottom = 38f

    fun nearestIndex(distancePx: Double): Int {
        if (extraction.distancesPx.isEmpty()) return 0
        var best = 0
        var bestDiff = Double.POSITIVE_INFINITY
        extraction.distancesPx.forEachIndexed { i, value ->
            val diff = kotlin.math.abs(value - distancePx)
            if (diff < bestDiff) {
                best = i
                bestDiff = diff
            }
        }
        return best
    }

    fun visibleBounds(): Pair<Float, Float> {
        val width = (1f / zoomX).coerceIn(0.05f, 1f)
        val minCentre = width / 2f
        val maxCentre = 1f - width / 2f
        val centre = centreFraction.coerceIn(minCentre, maxCentre)
        return (centre - width / 2f) to (centre + width / 2f)
    }

    // Display fraction is conventional spectroscopy order:
    // 0 = VIOLET, 1 = RED.
    // The extraction engine internally stores 0 = RED, last = VIOLET.
    fun sourceIndexFromDisplayFraction(displayFraction: Float): Int {
        if (signal.isEmpty()) return 0
        return ((1f - displayFraction.coerceIn(0f, 1f)) * signal.lastIndex)
            .toInt()
            .coerceIn(0, signal.lastIndex)
    }

    fun displayFractionFromSourceIndex(index: Int): Float {
        if (signal.size <= 1) return 0f
        return 1f - index.coerceIn(0, signal.lastIndex).toFloat() / signal.lastIndex.toFloat()
    }

    fun indexFromScreenX(x: Float): Int {
        if (signal.isEmpty() || size.width <= paddingX * 2) return 0
        val (startF, endF) = visibleBounds()
        val local = ((x - paddingX) / (size.width - paddingX * 2)).coerceIn(0f, 1f)
        val displayFraction = startF + local * (endF - startF)
        return sourceIndexFromDisplayFraction(displayFraction)
    }

    fun lineColor(label: String): Color = when (label) {
        "Hα" -> Color(0xFFFF6B6B)
        "Hβ" -> Color(0xFF6FD7FF)
        "Hγ" -> Color(0xFFD29BFF)
        "Hδ" -> Color(0xFFFFC56B)
        else -> Color.White
    }

    val activeIndex = anchors.firstOrNull { it.label == activeLabel }
        ?.let { nearestIndex(it.distancePx) }
        ?: -1

    Column(modifier) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !showRaw,
                onClick = { showRaw = false },
                label = { Text("Continuum-normalised") }
            )
            FilterChip(
                selected = showRaw,
                onClick = { showRaw = true },
                label = { Text("Raw extracted signal") }
            )
        }

        Spacer(Modifier.height(8.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (chartNavigationMode) {
                Button(
                    onClick = { chartNavigationMode = true },
                    modifier = Modifier.weight(1f)
                ) { Text("PAN / ZOOM") }
            } else {
                OutlinedButton(
                    onClick = { chartNavigationMode = true },
                    modifier = Modifier.weight(1f)
                ) { Text("PAN / ZOOM") }
            }

            if (!chartNavigationMode) {
                Button(
                    onClick = { chartNavigationMode = false },
                    modifier = Modifier.weight(1f)
                ) { Text("PLACE $activeLabel") }
            } else {
                OutlinedButton(
                    onClick = { chartNavigationMode = false },
                    modifier = Modifier.weight(1f)
                ) { Text("PLACE $activeLabel") }
            }
        }

        Spacer(Modifier.height(8.dp))

        val chartGestureModifier =
            if (chartNavigationMode) {
                Modifier.pointerInput(extraction, zoomX, centreFraction, showRaw, size) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        if (size.width <= paddingX * 2) return@detectTransformGestures

                        val plotWidth = (size.width - paddingX * 2).coerceAtLeast(1f)
                        val oldZoom = zoomX
                        val newZoom = (oldZoom * zoom).coerceIn(1f, 16f)
                        val oldWidth = 1f / oldZoom
                        val newWidth = 1f / newZoom
                        val oldStart = (centreFraction - oldWidth / 2f)
                            .coerceIn(0f, 1f - oldWidth)
                        val touchLocal = ((centroid.x - paddingX) / plotWidth).coerceIn(0f, 1f)
                        val touchedGlobal = oldStart + touchLocal * oldWidth

                        var newStart = touchedGlobal - touchLocal * newWidth
                        newStart -= (pan.x / plotWidth) * newWidth
                        newStart = newStart.coerceIn(0f, 1f - newWidth)

                        zoomX = newZoom
                        centreFraction = newStart + newWidth / 2f
                    }
                }
            } else {
                Modifier
                    .pointerInput(extraction, zoomX, centreFraction, activeLabel, showRaw, size) {
                        detectTapGestures { point ->
                            val index = indexFromScreenX(point.x)
                            fineIndex = index
                            onPlaceIndex(index)
                        }
                    }
                    .pointerInput(extraction, zoomX, centreFraction, activeLabel, showRaw, size) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { point ->
                                magnifying = true
                                val index = indexFromScreenX(point.x)
                                fineIndex = index
                                onPlaceIndex(index)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                val index = indexFromScreenX(change.position.x)
                                fineIndex = index
                                onPlaceIndex(index)
                            },
                            onDragEnd = { magnifying = false },
                            onDragCancel = { magnifying = false }
                        )
                    }
            }

        Box(
            Modifier
                .fillMaxWidth()
                .height(330.dp)
                .background(Color(0xFF090D13), RoundedCornerShape(16.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                .onSizeChanged { size = it }
                .then(chartGestureModifier)
        ) {
            Canvas(Modifier.fillMaxSize()) {
                if (signal.isEmpty()) return@Canvas

                val plotW = (this.size.width - paddingX * 2).coerceAtLeast(1f)
                val plotH = (this.size.height - paddingTop - paddingBottom).coerceAtLeast(1f)
                val (startF, endF) = visibleBounds()

                val firstSource = sourceIndexFromDisplayFraction(startF)
                val lastSource = sourceIndexFromDisplayFraction(endF)
                val sourceHigh = max(firstSource, lastSource)
                val sourceLow = min(firstSource, lastSource)

                val visibleValues = (sourceLow..sourceHigh)
                    .filter { extraction.valid[it] && signal[it].isFinite() }
                    .map { signal[it] }

                var localMin = visibleValues.minOrNull() ?: if (showRaw) 0.0 else 0.90
                var localMax = visibleValues.maxOrNull() ?: if (showRaw) 1.0 else 1.10

                if (!showRaw) {
                    localMin = min(localMin, 0.97)
                    localMax = max(localMax, 1.03)
                }

                val initialRange = (localMax - localMin).coerceAtLeast(if (showRaw) 1e-6 else 0.02)
                val verticalPad = initialRange * 0.10
                localMin -= verticalPad
                localMax += verticalPad
                val localRange = (localMax - localMin).coerceAtLeast(1e-6)

                for (g in 0..4) {
                    val y = paddingTop + plotH * g / 4f
                    drawLine(
                        Color.White.copy(alpha = 0.09f),
                        Offset(paddingX, y),
                        Offset(paddingX + plotW, y),
                        1f
                    )
                }

                if (!showRaw && 1.0 in localMin..localMax) {
                    val baselineY =
                        paddingTop + plotH * (1f - ((1.0 - localMin) / localRange).toFloat())
                    drawLine(
                        Color.White.copy(alpha = 0.28f),
                        Offset(paddingX, baselineY),
                        Offset(paddingX + plotW, baselineY),
                        1.5f
                    )
                }

                var previous: Offset? = null
                for (i in sourceHigh downTo sourceLow) {
                    val value = signal[i]
                    if (!value.isFinite()) {
                        previous = null
                        continue
                    }

                    val displayFraction = displayFractionFromSourceIndex(i)
                    if (displayFraction < startF || displayFraction > endF) continue
                    val localF = ((displayFraction - startF) / (endF - startF)).coerceIn(0f, 1f)
                    val x = paddingX + plotW * localF
                    val y = paddingTop + plotH *
                        (1f - ((value - localMin) / localRange).toFloat().coerceIn(0f, 1f))
                    val point = Offset(x, y)
                    previous?.let { drawLine(Color(0xFF67E4CB), it, point, 2.2f) }
                    previous = point
                }

                anchors.forEach { anchor ->
                    val i = nearestIndex(anchor.distancePx)
                    val displayFraction = displayFractionFromSourceIndex(i)
                    if (displayFraction in startF..endF) {
                        val localF = ((displayFraction - startF) / (endF - startF)).coerceIn(0f, 1f)
                        val x = paddingX + plotW * localF
                        val color = lineColor(anchor.label)
                        drawLine(
                            color.copy(alpha = if (anchor.label == activeLabel) 0.98f else 0.78f),
                            Offset(x, paddingTop),
                            Offset(x, paddingTop + plotH),
                            if (anchor.label == activeLabel) 4f else 2.5f
                        )
                        drawCircle(color, 5f, Offset(x, paddingTop + 4f))
                    }
                }

                if (magnifying && fineIndex >= 0) {
                    val displayFraction = displayFractionFromSourceIndex(fineIndex)
                    if (displayFraction in startF..endF) {
                        val localF = ((displayFraction - startF) / (endF - startF)).coerceIn(0f, 1f)
                        val x = paddingX + plotW * localF
                        drawLine(
                            Color.White,
                            Offset(x, paddingTop),
                            Offset(x, paddingTop + plotH),
                            2f
                        )
                    }
                }
            }

            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "VIOLET",
                    color = Color(0xFFB78CFF),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    if (showRaw) "raw signal" else "linear RGB · normalised continuum ≈ 1",
                    color = Color.White.copy(alpha = 0.58f),
                    style = MaterialTheme.typography.labelSmall
                )
                Text(
                    "RED",
                    color = Color(0xFFFF6B6B),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            if (magnifying && fineIndex >= 0) {
                SpectrumLineMagnifier(
                    signal = signal,
                    centreIndex = fineIndex.coerceIn(0, signal.lastIndex),
                    accent = lineColor(activeLabel),
                    normalised = !showRaw,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 40.dp, end = 14.dp)
                )
            }

            val (startF, endF) = visibleBounds()
            val totalDistance = extraction.distancesPx.lastOrNull()?.coerceAtLeast(0.0) ?: 0.0
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "%.0f px".format(Locale.US, totalDistance * startF),
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelSmall
                )
                Text(
                    if (zoomX > 1.01f)
                        "×%.1f · local y-scale · hold-drag for fine placement".format(Locale.US, zoomX)
                    else
                        "pinch to zoom · local y-scale",
                    color = Color.White.copy(alpha = 0.55f),
                    style = MaterialTheme.typography.labelSmall
                )
                Text(
                    "%.0f px".format(Locale.US, totalDistance * endF),
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Nudge controls follow the displayed VIOLET -> RED direction.
            OutlinedButton(
                onClick = {
                    val base = if (activeIndex >= 0) activeIndex else signal.lastIndex / 2
                    onPlaceIndex((base + 5).coerceIn(0, signal.lastIndex))
                },
                modifier = Modifier.weight(1f)
            ) { Text("−5") }
            OutlinedButton(
                onClick = {
                    val base = if (activeIndex >= 0) activeIndex else signal.lastIndex / 2
                    onPlaceIndex((base + 1).coerceIn(0, signal.lastIndex))
                },
                modifier = Modifier.weight(1f)
            ) { Text("−1") }
            OutlinedButton(
                onClick = {
                    val base = if (activeIndex >= 0) activeIndex else signal.lastIndex / 2
                    onPlaceIndex((base - 1).coerceIn(0, signal.lastIndex))
                },
                modifier = Modifier.weight(1f)
            ) { Text("+1") }
            OutlinedButton(
                onClick = {
                    val base = if (activeIndex >= 0) activeIndex else signal.lastIndex / 2
                    onPlaceIndex((base - 5).coerceIn(0, signal.lastIndex))
                },
                modifier = Modifier.weight(1f)
            ) { Text("+5") }
        }

        Spacer(Modifier.height(6.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                enabled = activeIndex >= 0,
                onClick = {
                    if (activeIndex >= 0) {
                        val displayFraction = displayFractionFromSourceIndex(activeIndex)
                        zoomX = 6f
                        val width = 1f / zoomX
                        centreFraction = displayFraction.coerceIn(width / 2f, 1f - width / 2f)
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Zoom to active line") }

            OutlinedButton(
                onClick = {
                    zoomX = 1f
                    centreFraction = 0.5f
                },
                modifier = Modifier.weight(1f)
            ) { Text("Fit whole spectrum") }
        }

        Spacer(Modifier.height(6.dp))
        Text(
            if (showRaw)
                "Raw image-derived signal. Use the normalised view for locating absorption troughs."
            else
                "Calibration view uses lightly smoothed linear-light RGB signal, a broad robust continuum, and suppresses regions where the source signal is too weak for reliable normalisation. Vertical scale expands locally as you zoom.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SpectrumLineMagnifier(
    signal: DoubleArray,
    centreIndex: Int,
    accent: Color,
    normalised: Boolean,
    modifier: Modifier = Modifier
) {
    if (signal.isEmpty()) return

    val start = (centreIndex - 24).coerceAtLeast(0)
    val end = (centreIndex + 24).coerceAtMost(signal.lastIndex)
    val values = if (start <= end) signal.slice(start..end) else emptyList()
    val finiteValues = values.filter { it.isFinite() }

    var localMin = finiteValues.minOrNull() ?: if (normalised) 0.90 else 0.0
    var localMax = finiteValues.maxOrNull() ?: if (normalised) 1.10 else 1.0
    if (normalised) {
        localMin = min(localMin, 0.98)
        localMax = max(localMax, 1.02)
    }
    val initialRange = (localMax - localMin).coerceAtLeast(if (normalised) 0.02 else 1e-6)
    localMin -= initialRange * 0.10
    localMax += initialRange * 0.10
    val localRange = (localMax - localMin).coerceAtLeast(1e-6)

    Surface(
        modifier = modifier
            .width(210.dp)
            .height(165.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF05080D).copy(alpha = 0.97f),
        border = androidx.compose.foundation.BorderStroke(2.dp, accent)
    ) {
        Canvas(Modifier.fillMaxSize().padding(10.dp)) {
            if (values.isEmpty()) return@Canvas
            val w = size.width.coerceAtLeast(1f)
            val h = size.height.coerceAtLeast(1f)

            if (normalised && 1.0 in localMin..localMax) {
                val y = h * (1f - ((1.0 - localMin) / localRange).toFloat())
                drawLine(
                    Color.White.copy(alpha = 0.25f),
                    Offset(0f, y),
                    Offset(w, y),
                    1f
                )
            }

            var previous: Offset? = null
            values.forEachIndexed { local, value ->
                if (!value.isFinite()) {
                    previous = null
                    return@forEachIndexed
                }
                val x = w * local / max(1, values.lastIndex).toFloat()
                val y = h *
                    (1f - ((value - localMin) / localRange).toFloat().coerceIn(0f, 1f))
                val p = Offset(x, y)
                previous?.let { drawLine(Color(0xFF67E4CB), it, p, 2.4f) }
                previous = p
            }

            val centreLocal = (centreIndex - start).coerceIn(0, values.lastIndex)
            val cx = w * centreLocal / max(1, values.lastIndex).toFloat()
            drawLine(Color.Black.copy(alpha = 0.8f), Offset(cx, 0f), Offset(cx, h), 5f)
            drawLine(accent, Offset(cx, 0f), Offset(cx, h), 2f)
        }
    }
}

@Composable
internal fun FeatureList(features: List<SpectralFeature>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    if (features.isEmpty()) {
        Text("No features reached the current robust significance threshold.", style = MaterialTheme.typography.bodyMedium)
        return
    }
    features.take(40).forEach { feature ->
        val location = feature.wavelengthNm?.let { "%.2f nm".format(Locale.US, it) }
            ?: "%.1f px".format(Locale.US, feature.distancePx)
        val line = "$location · ${feature.type.wireValue} · S/N %.1f · confidence %.2f".format(Locale.US, feature.snr, feature.confidence)
        Surface(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { copyToClipboard(context, "Spectral feature", line) },
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(location, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "${feature.type.wireValue} · S/N %.1f · stability %.2f".format(Locale.US, feature.snr, feature.stability),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text("%.0f%%".format(Locale.US, feature.confidence * 100.0), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
internal fun ReferenceChips(
    references: List<SpectrumReference>,
    selectedId: String,
    onSelected: (String) -> Unit
) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = selectedId.isBlank(), onClick = { onSelected("") }, label = { Text("Pixels only") })
        references.forEach { reference ->
            FilterChip(
                selected = selectedId == reference.id,
                onClick = { onSelected(reference.id) },
                label = { Text(reference.name.ifBlank { reference.starName.ifBlank { reference.id.take(8) } }) }
            )
        }
    }
}

internal fun fittedRect(box: IntSize, bitmap: Bitmap): Rect {
    if (box.width <= 0 || box.height <= 0 || bitmap.width <= 0 || bitmap.height <= 0) return Rect.Zero
    val scale = min(box.width.toFloat() / bitmap.width, box.height.toFloat() / bitmap.height)
    val width = bitmap.width * scale
    val height = bitmap.height * scale
    val left = (box.width - width) / 2f
    val top = (box.height - height) / 2f
    return Rect(left, top, left + width, top + height)
}

private fun imageToScreen(point: Offset, box: IntSize, bitmap: Bitmap, zoom: Float, pan: Offset): Offset? {
    val fit = fittedRect(box, bitmap)
    if (fit == Rect.Zero) return null
    val base = Offset(
        fit.left + point.x * fit.width / bitmap.width,
        fit.top + point.y * fit.height / bitmap.height
    )
    val centre = Offset(box.width / 2f, box.height / 2f)
    return centre + (base - centre) * zoom + pan
}

private fun screenToImage(point: Offset, box: IntSize, bitmap: Bitmap, zoom: Float, pan: Offset): Offset? {
    val fit = fittedRect(box, bitmap)
    if (fit == Rect.Zero) return null
    val centre = Offset(box.width / 2f, box.height / 2f)
    val base = centre + (point - pan - centre) / zoom
    if (base.x < fit.left || base.x > fit.right || base.y < fit.top || base.y > fit.bottom) return null
    return Offset(
        ((base.x - fit.left) / fit.width * bitmap.width).coerceIn(0f, bitmap.width - 1f),
        ((base.y - fit.top) / fit.height * bitmap.height).coerceIn(0f, bitmap.height - 1f)
    )
}

internal fun copyToClipboard(context: Context, label: String, text: String) {
    if (text.isBlank()) return
    context.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(label, text))
    android.widget.Toast.makeText(context, "Copied", android.widget.Toast.LENGTH_SHORT).show()
}

internal fun shareSpectrumArtifacts(context: Context, label: String, uris: List<String>, text: String = "") {
    val parsed = ArrayList<android.net.Uri>(uris.filter { it.isNotBlank() }.map(android.net.Uri::parse))
    val intent = android.content.Intent(
        if (parsed.size > 1) android.content.Intent.ACTION_SEND_MULTIPLE else android.content.Intent.ACTION_SEND
    ).apply {
        type = "*/*"
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        putExtra(android.content.Intent.EXTRA_SUBJECT, label)
        if (text.isNotBlank()) putExtra(android.content.Intent.EXTRA_TEXT, text)
        if (parsed.size > 1) putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, parsed)
        else parsed.firstOrNull()?.let { putExtra(android.content.Intent.EXTRA_STREAM, it) }
        clipData = parsed.firstOrNull()?.let { first ->
            android.content.ClipData.newUri(context.contentResolver, label, first).also { clip ->
                parsed.drop(1).forEach { clip.addItem(android.content.ClipData.Item(it)) }
            }
        }
    }
    context.startActivity(android.content.Intent.createChooser(intent, "Share $label"))
}

internal fun saveSpectrumArtifactsToDownloads(context: Context, label: String, uris: List<String>, summary: String, fullJson: String = ""): String {
    val saved = com.example.methodmesh.transport.OutputExportRepository.saveToDownloads(
        context = context,
        label = label,
        text = summary,
        mediaUris = uris.filter { it.isNotBlank() },
        jsonText = fullJson
    )
    return saved.summary
}

internal fun contextInput(context: com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext, key: String): String {
    return context.action.settings[key]
        ?: context.action.settings["input_$key"]
        ?: context.request.settings[key]
        ?: context.request.settings["input_$key"]
        ?: ""
}

internal fun initialiseSpectrumSettings(
    state: com.example.methodmesh.settings.SettingsState,
    definitions: List<com.example.methodmesh.settings.MethodSetting>,
    context: com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
) {
    val byId = definitions.associateBy { it.id }
    byId.forEach { (id, definition) ->
        val raw = contextInput(context, id)
        if (raw.isBlank()) return@forEach
        when (definition) {
            is com.example.methodmesh.settings.MethodSetting.BooleanSetting -> state.setBoolean(id, raw.equals("true", true))
            is com.example.methodmesh.settings.MethodSetting.IntSetting -> raw.toIntOrNull()?.let { state.setInt(id, it) }
            is com.example.methodmesh.settings.MethodSetting.FloatSetting -> raw.toFloatOrNull()?.let { state.setFloat(id, it) }
            else -> state.setString(id, raw)
        }
    }
}
