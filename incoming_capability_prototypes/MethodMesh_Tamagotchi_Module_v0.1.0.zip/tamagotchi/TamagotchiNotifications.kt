package com.example.methodmesh.modules.tamagotchi

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.concurrent.TimeUnit

object TamagotchiReminderScheduler {
    private const val REQUEST_CODE = 41871
    private const val CHECK_INTERVAL_MINUTES = 90L

    fun schedule(context: Context, session: TamagotchiSession) {
        if (!session.attentionPolicy.enabled || session.ended) {
            cancel(context, session.id)
            return
        }
        val alarm = context.getSystemService(AlarmManager::class.java)
        val pending = pending(context, session.id)
        val trigger = android.os.SystemClock.elapsedRealtime() + TimeUnit.MINUTES.toMillis(CHECK_INTERVAL_MINUTES)
        alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending)
    }

    fun cancel(context: Context, sessionId: String) {
        context.getSystemService(AlarmManager::class.java).cancel(pending(context, sessionId))
    }

    private fun pending(context: Context, sessionId: String): PendingIntent = PendingIntent.getBroadcast(
        context,
        sessionId.hashCode(),
        Intent(context, TamagotchiReminderReceiver::class.java).putExtra("session_id", sessionId),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

class TamagotchiReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val store = TamagotchiStore(context.applicationContext)
        val id = intent?.getStringExtra("session_id") ?: store.activeSessionId() ?: return
        var session = store.loadAndAdvance(id) ?: return
        val (eligible, reason) = TamagotchiEngine.notificationDecision(session)
        session = store.recordNotificationCandidate(session, eligible, reason)
        if (eligible) showNotification(context, session)
        TamagotchiReminderScheduler.schedule(context, session)
    }

    private fun showNotification(context: Context, session: TamagotchiSession) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val channelId = "tamagotchi_care"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(
                channelId,
                "Tamagotchi care",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Gentle, rate-limited care reminders from Tamagotchi Lab"
                setShowBadge(true)
            })
        }
        val scenario = TamagotchiCatalog.scenario(session.scenarioId)
        val creature = TamagotchiCatalog.creature(session.creatureId)
        val phenotype = TamagotchiEngine.phenotype(session, scenario, creature)
        val open = PendingIntent.getActivity(
            context,
            41872,
            Intent(context, TamagotchiCompanionActivity::class.java)
                .putExtra("session_id", session.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = when {
            phenotype.unwell -> "Something changed with ${session.creatureName}"
            phenotype.energy < 40 -> "${session.creatureName} is having a quiet moment"
            else -> "${session.creatureName} is awake"
        }
        val body = when {
            phenotype.unwell -> "You might want to check on them when you have a moment."
            phenotype.energy < 40 -> "A deliberate observation could be useful later."
            else -> "They look like they could use a little attention when you have time."
        }
        manager.notify(
            session.id.hashCode(),
            NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.btn_star_big_on)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
        )
    }
}
