# Tamagotchi Lab validation notes

## Completed checks

- Reviewed against the current MethodMesh `MethodMeshModule` self-contained module contract.
- Canonical capability IDs are unique within this module.
- Dashboard composition is separate from canonical capability exposure.
- Persistent session history uses the current MethodMesh appendable persistent artifact boundary.
- Pure Kotlin model/catalog/simulation engine compiled successfully with minimal `org.json` stubs on 2026-09-08; this catches Kotlin/JVM syntax/type errors in the deterministic simulation core.
- Procedural generation uses a stored numeric seed and records generated option parameters to latent history.
- Care-visible state and latent state are separated.
- `analyse` and latent export remain locked until the care period is ended.
- Notification suppression reasons are represented as explicit ledger events.
- Companion Mode is optional and has no effect on core session persistence.
- XLSForm workbook was created with `survey`, `choices`, and `settings` sheets and checked for workbook formula-error tokens.

## Host integration not executable in this isolated module package

A complete `:app:compileDebugKotlin` was not run here because the full MethodMesh Android source/dependency tree is not mounted in this execution environment and outbound Git clone is unavailable. The module was therefore checked against current repository interfaces retrieved from the linked GitHub repository plus the pure-engine Kotlin compile above.

Before release, run at app root:

```text
./gradlew :app:compileDebugKotlin
./gradlew test
```

Also validate the XLSForm with the project's normal ODK/XLSForm validation path.

## Required app-level integration

`docs/AndroidManifest.fragment.xml` must be merged for:

- `TamagotchiCompanionActivity`
- `TamagotchiCompanionService`
- `TamagotchiReminderReceiver`
- overlay / notification / foreground-service permissions

If the build's `methodmesh_module_index` is generated separately, include the line from `docs/module_index_entry.txt`.
