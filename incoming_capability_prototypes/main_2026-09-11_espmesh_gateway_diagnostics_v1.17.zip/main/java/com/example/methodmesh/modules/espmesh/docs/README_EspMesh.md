# ESP mesh field network

The ESP mesh module is the MethodMesh-owned integration point for a delay-tolerant field network. It uses the generic core transport substrate for envelopes, durable queues, deduplication and consumer dispatch.

The Android provider currently exposes the gateway boundary and queues messages safely while no gateway is provisioned. BLE framing, provisioning, ESP-NOW forwarding and node-specific state belong in this module and its firmware support, never in `core/transport`.

## Message path

```text
capability / protocol / ODK
            │ generic envelope
            ▼
core durable outbox + dispatcher
            │ provider contract
            ▼
ESP mesh Android gateway adapter
            │ versioned bridge frames
            ▼
ESP-NOW nodes and relays
```

The gateway bridge carries the MethodMesh envelope as opaque JSON. The current reference node implements TTL, duplicate suppression, bounded store-and-forward, authenticated ESP-NOW packets and basic mesh acknowledgements. Android requests a large BLE MTU and keeps unfragmented phone↔gateway bridge frames within a conservative 500-byte application bound; larger BLE payloads are rejected until deliberate BLE fragmentation is added. The ESP-NOW radio side fragments the compact MethodMesh envelope into authenticated packets no larger than the runtime `espnow.MAX_DATA_LEN` (250 bytes on the bundled MicroPython 1.28 image), reassembles them before delivery, and rejects incomplete or integrity-failing messages rather than silently truncating them.

For the normal field workflow, explicit ESP-NOW peer MAC addresses are not required. When no peer list is supplied, a provisioned node registers the ESP-NOW broadcast peer. Nodes sharing the same network ID/key can therefore exchange authenticated MethodMesh envelopes automatically; the existing message ID/TTL deduplication prevents rebroadcast loops. Explicit peer lists remain a future optimisation for constrained topologies.

`EspMeshBridgeFrame` currently defines the Android-side frame shape (`methodmesh.gateway`, version 1) and bounds decoded bridge frames. It deliberately does not encode ESP-NOW packet headers, radio addresses or cryptographic membership state; those are firmware and gateway concerns.

No keys, MAC addresses or radio-specific routing values are exposed as MethodMesh identity.

## End-to-end phone bridge

The bench/field path is now:

```text
Phone A → BLE → ESP node A → ESP-NOW → ESP node B → BLE → Phone B
```

Each phone selects its own nearby ESP node through **ESP mesh gateway**. Provision both nodes with the same network ID and network key. **ESP mesh message** sends a transport envelope through the locally selected node and shows recently received envelopes delivered back from that node, which provides a direct two-phone bench test without exposing ESP-NOW addressing to the user.

## Provisioning and background operation

The gateway capability scans for the module GATT service, provisions a selected device, and can send a network ID, network key, peer list and device provisioning token. The reference firmware derives a per-device default token from its hardware identity; production provisioning should deliver that token through a physical or NFC-assisted enrolment step rather than exposing it in the radio protocol.

After a gateway is selected, MethodMesh can run the `connectedDevice` foreground service. The service restarts the generic transport runtime so queued outbound messages and inbound envelopes continue to work while the dashboard or capability screen is closed. The diagnostics capability reports provider state and bounded inbox/outbox counts without showing keys or payloads.

The current firmware is MicroPython and is bundled as the full ESP32-C3 `espnow_mesh` image installed through the ESP32 sensor framework. Firmware version `methodmesh-espmesh-0.2.0` fixes BLE advertising by splitting the 128-bit service UUID and device name between advertisement and scan-response data, and defaults peerless provisioned nodes to ESP-NOW broadcast transport. It is suitable for protocol and bench/field testing. Encrypted payloads, stronger authenticated multi-node enrolment, deliberate fragmentation for large bridge/radio payloads and route discovery remain explicit follow-up work.
## Gateway frame diagnostics

If Android rejects a BLE notification as an invalid gateway frame, the ESP mesh gateway screen exposes a bounded diagnostic containing the downlink characteristic UUID, byte length, UTF-8 payload, hexadecimal payload and exact parser exception. The same rejection is emitted to logcat under the `MethodMeshEspMesh` tag. Diagnostics are transport evidence only and do not change or reinterpret the frame.

