# MethodMesh ESP mesh firmware boundary

The ESP mesh module owns the runtime transport protocol and Android↔node bridge. Firmware installation itself is consolidated into the **ESP32 sensor framework** Workbench installer.

Required firmware responsibilities include:

- stable node identity separate from radio addresses;
- BLE discovery/provisioning of network identity and key;
- ESP-NOW frame forwarding with bounded TTL and duplicate suppression;
- durable store-and-forward queues;
- BLE gateway bridge using the module protocol;
- sensor/other MethodMesh observations carried as opaque transport payloads where applicable.

`methodmesh_gateway_protocol.h` remains the shared bridge constant header for a future ESP-IDF implementation.

The canonical current MicroPython mesh-node runtime is no longer duplicated in this module folder. It is bundled at:

`main/assets/firmware/esp32c3_espnow_mesh/main.py`

and installed as the full image:

`main/assets/firmware/esp32c3_images/methodmesh_esp32c3_espnow_mesh.bin`

Select **ESP-NOW mesh node** inside **Install ESP32 image**. After flashing and resetting the board, use **ESP mesh gateway** to scan and provision it over BLE.

The firmware must never be required by the generic Android core to compile or run.
