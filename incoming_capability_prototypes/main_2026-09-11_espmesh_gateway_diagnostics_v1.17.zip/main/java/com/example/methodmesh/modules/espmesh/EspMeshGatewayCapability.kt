package com.example.methodmesh.modules.espmesh

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startForegroundService
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec

object EspMeshGatewayCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100EspMeshGatewayMethod.ID
    override val title = "ESP mesh gateway"
    override val description = "Discover and provision a nearby MethodMesh BLE gateway."

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        val app = LocalContext.current.applicationContext
        val provider = remember { EspMeshTransportProvider.get(app) }
        val status by provider.status.collectAsState()
        val gatewayInfo by provider.gatewayInfo.collectAsState()
        val lastInvalidFrame by provider.lastInvalidFrame.collectAsState()
        val candidates = remember { mutableStateListOf<EspMeshGatewayCandidate>() }
        var scanning by rememberSaveable { mutableStateOf(false) }
        var networkId by rememberSaveable { mutableStateOf("") }
        var networkKey by rememberSaveable { mutableStateOf("") }
        var provisioningToken by rememberSaveable { mutableStateOf("") }
        var configStatus by rememberSaveable { mutableStateOf("") }
        var showGatewayDiagnostics by rememberSaveable { mutableStateOf(false) }
        var result by remember { mutableStateOf<ExecutionResult?>(null) }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (it.values.all { granted -> granted }) {
                candidates.clear(); scanning = true
                provider.scan({ candidate -> if (candidates.none { it.address == candidate.address }) candidates += candidate }, { scanning = false })
            }
        }
        fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        fun scan() {
            val missing = requiredPermissions().filter { ContextCompat.checkSelfPermission(app, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
            else { candidates.clear(); scanning = true; provider.scan({ candidate -> if (candidates.none { it.address == candidate.address }) candidates += candidate }, { scanning = false }) }
        }
        fun provision(candidate: EspMeshGatewayCandidate) {
            provider.provision(candidate)
            startForegroundService(app, Intent(app, EspMeshGatewayService::class.java))
            val request = As100EspMeshGatewayMethod.request(capabilityId, emptyMap(), emptyList(), emptyList())
            result = As100EspMeshGatewayMethod.execute(request, null, "espmesh")
            if (context.submitsImmediately) result?.let(onConfirmed)
        }
        CapabilityScreenScaffold(
            title = title, capabilityId = capabilityId, context = context, canGoBack = context.stepNumber > 1,
            capturedResult = result, resultPreview = result?.let { OutputFormatter.fields(it, false) }.orEmpty(),
            onBack = onBack, onRetry = { scan() }, onConfirm = { result?.let(onConfirmed) }, onCancel = onCancel
        ) {
            Text("Choose a nearby gateway. Bluetooth addresses remain transport details; MethodMesh uses the gateway identity reported by the protocol.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text("${status.detail} · ${if (status.connected) "connected" else "not connected"}", style = MaterialTheme.typography.bodyMedium)
            if (gatewayInfo.nodeId.isNotBlank()) {
                Text("Node ${gatewayInfo.nodeId} · ${if (gatewayInfo.provisioned) "network ${gatewayInfo.networkId}" else "not network-provisioned"}", style = MaterialTheme.typography.bodySmall)
            }
            lastInvalidFrame?.let { diagnostic ->
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { showGatewayDiagnostics = !showGatewayDiagnostics }) {
                    Text(if (showGatewayDiagnostics) "Hide gateway diagnostics" else "Gateway diagnostics")
                }
                if (showGatewayDiagnostics) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Rejected BLE notification", style = MaterialTheme.typography.titleSmall)
                            Text("Characteristic: ${diagnostic.characteristicUuid}", style = MaterialTheme.typography.bodySmall)
                            Text("Length: ${diagnostic.byteLength} bytes", style = MaterialTheme.typography.bodySmall)
                            Text("Parser: ${diagnostic.parserError}", style = MaterialTheme.typography.bodySmall)
                            Text("UTF-8", style = MaterialTheme.typography.labelMedium)
                            Text(diagnostic.utf8.ifBlank { "<empty>" }, style = MaterialTheme.typography.bodySmall)
                            Text("Hex", style = MaterialTheme.typography.labelMedium)
                            Text(diagnostic.hex.ifBlank { "<empty>" }, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { scan() }, enabled = !scanning, modifier = Modifier.fillMaxWidth()) { Text(if (scanning) "Scanning…" else "Scan for gateways") }
            Spacer(Modifier.height(8.dp))
            Text("Network provisioning", style = MaterialTheme.typography.titleMedium)
            Text("Nodes with the same network ID and key discover each other over ESP-NOW automatically; no radio MAC entry is required for the normal field workflow.", style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(networkId, { networkId = it }, label = { Text("Network ID") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(networkKey, { networkKey = it }, label = { Text("Network key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
            OutlinedTextField(provisioningToken, { provisioningToken = it }, label = { Text("Node provisioning token (optional for a new node)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Button(
                onClick = {
                    val sent = provider.configureNetwork(networkId, networkKey, provisioningToken)
                    configStatus = sent.detail
                },
                enabled = status.connected && networkId.isNotBlank() && networkKey.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Provision network") }
            if (configStatus.isNotBlank()) Text(configStatus, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            // The host owns vertical scrolling; do not nest an unbounded lazy list.
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                candidates.forEach { candidate ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(Modifier.weight(1f)) {
                                Text(candidate.name, style = MaterialTheme.typography.titleMedium)
                                Text("${candidate.address} · RSSI ${candidate.rssi}", style = MaterialTheme.typography.bodySmall)
                            }
                            OutlinedButton(onClick = { provision(candidate) }) { Text("Use") }
                        }
                    }
                }
            }
        }
    }
}
