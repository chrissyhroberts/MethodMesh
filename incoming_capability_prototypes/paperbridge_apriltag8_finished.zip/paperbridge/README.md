# PaperBridge — eight-tag registration update

[Installation, board coordinates and registration behaviour](docs/README_AprilTag_Registration.md)

[Build/test results and host-project compilation note](docs/BUILD_TEST_RESULTS.md)

New designs use eight unique tag36h11 AprilTags, robust corner-based registration and one canonical image transform. Existing MethodMesh contracts and legacy manifest readers are preserved.

Current examples: `docs/example_apriltag_manifest.json`, `docs/example_apriltag_blank.png`, `docs/example_apriltag_filled.png`, `docs/example_perspective_scan.png`, `docs/example_registration_overlay.png`.

Apply `paperbridge-dependencies.gradle.kts` from the app's Gradle file after copying this folder into the project's modules directory. The Android test is shipped as `tests/PaperAprilTagRegistrationTest.kt.txt`; copy it into `src/androidTest` and remove `.txt` to run it.
