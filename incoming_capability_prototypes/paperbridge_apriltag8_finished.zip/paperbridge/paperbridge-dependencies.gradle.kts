// Apply from app/build.gradle.kts after installing this folder under modules/paperbridge.
dependencies { add("implementation", "org.opencv:opencv:4.12.0") }
