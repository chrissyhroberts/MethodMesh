package com.example.methodmesh.modules.paperbridge

import android.graphics.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.calib3d.Calib3d
import org.opencv.core.*
import org.opencv.core.Point
import org.opencv.imgproc.Imgproc
import org.opencv.objdetect.ArucoDetector
import org.opencv.objdetect.DetectorParameters
import org.opencv.objdetect.Objdetect
import kotlin.math.*

/** Residual observations are retained independently of rasterization for a future mesh model. */
internal data class PaperRegistrationPoint(val id: Int, val corner: Int, val source: PointF,
    val canonical: PointF, val projected: PointF, val inlier: Boolean) {
    val error: Double get() = hypot((canonical.x - projected.x).toDouble(), (canonical.y - projected.y).toDouble())
}
internal data class PaperRegistrationDiagnostics(
    val detected: List<Int>, val accepted: List<Int>, val points: List<PaperRegistrationPoint>,
    val rms: Double?, val maximum: Double?, val quality: String, val reason: String = ""
) {
    fun summary() = "AprilTags ${detected.size}/8 · ${accepted.size} accepted · ${detected.size * 4} points · " +
        "RMS ${rms?.let { "%.2f".format(it) } ?: "n/a"} px · max ${maximum?.let { "%.2f".format(it) } ?: "n/a"} px · $quality $reason"
    fun json() = JSONObject().apply {
        put("expected_ids", JSONArray((0..7).toList())); put("detected_ids", JSONArray(detected))
        put("accepted_ids", JSONArray(accepted)); put("point_count", detected.size * 4)
        put("inlier_point_count", points.count { it.inlier }); put("rms_px", rms ?: JSONObject.NULL)
        put("max_px", maximum ?: JSONObject.NULL); put("quality", quality); put("pass", quality != "fail")
        put("reason", reason); put("error_frame", "canonical_content_pixels")
        put("all_point_max_px", points.maxOfOrNull { it.error } ?: JSONObject.NULL)
        put("observations", JSONArray().apply { points.forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("corner", p.corner); put("inlier", p.inlier)
            put("source", JSONArray().put(p.source.x.toDouble()).put(p.source.y.toDouble()))
            put("canonical", JSONArray().put(p.canonical.x.toDouble()).put(p.canonical.y.toDouble()))
            put("projected", JSONArray().put(p.projected.x.toDouble()).put(p.projected.y.toDouble()))
            put("residual_px", p.error)
        }) } })
    }
}
internal class PaperRegistrationFailure(val diagnostics: PaperRegistrationDiagnostics) :
    IllegalArgumentException(diagnostics.summary())

/** Fixed A4-relative board v1. Artwork occupies [0.14,0.12,0.86,0.88] of the sheet.
 * The template's width/height describe that artwork, not the perimeter band.
 * AprilTag corners can therefore have negative canonical coordinates. ROI coordinates do not.
 */
internal object PaperAprilTagRegistration {
    val names = listOf("TL", "TC", "TR", "LC", "RC", "BL", "BC", "BR")
    val centres = listOf(.07f to .05f, .5f to .05f, .93f to .05f, .07f to .5f,
        .93f to .5f, .07f to .95f, .5f to .95f, .93f to .95f)
    const val SIZE = 14f / 210f
    private val loaded by lazy { OpenCVLoader.initLocal() }
    private fun ready() { check(loaded) { "OpenCV 4.12.0 could not load. Install the module's Gradle dependency." } }
    fun defaultRegistration(key: String) = PaperRegistrationSpec(PaperRegistrationType.APRILTAG8, key.uppercase(), SIZE, centres)
    fun validateManifest(json: JSONObject) {
        require(json.optString("family", "tag36h11") == "tag36h11") { "Only tag36h11 is supported." }
        require(json.optInt("board_version", 1) == 1) { "Unsupported AprilTag board version." }
        require(abs(json.optDouble("marker_size_fraction", SIZE.toDouble()) - SIZE) < 1e-6) { "Board v1 has fixed 14/210 black-tag size." }
        json.optJSONArray("centres")?.let { a ->
            require(a.length() == 8 && centres.indices.all { i ->
                abs(a.getJSONArray(i).getDouble(0) - centres[i].first) < 1e-6 &&
                abs(a.getJSONArray(i).getDouble(1) - centres[i].second) < 1e-6
            }) { "Board v1 tag centres are fixed." }
        }
        json.optJSONArray("content_bounds")?.let { a -> require(a.length() == 4 && listOf(.14,.12,.86,.88).indices.all { abs(a.getDouble(it)-listOf(.14,.12,.86,.88)[it]) < 1e-6 }) { "Board v1 content bounds are fixed." } }
        json.optJSONArray("tag_ids")?.let { a -> require(a.length() == 8 && (0..7).all { a.getInt(it) == it }) { "Board v1 IDs must be 0 through 7 in TL/TC/TR/LC/RC/BL/BC/BR order." } }
    }
    private fun content(w: Int, h: Int) = RectF(.14f*w, .12f*h, .86f*w, .88f*h)
    private fun box(id: Int, w: Int, h: Int): android.graphics.Rect {
        val size = (min(w,h)*SIZE).roundToInt().coerceAtLeast(8)
        val x = (centres[id].first*w-size/2f).roundToInt()
        val y = (centres[id].second*h-size/2f).roundToInt()
        return android.graphics.Rect(x,y,x+size,y+size)
    }
    fun canonicalCorners(id: Int, w: Int, h: Int): List<PointF> {
        val b = box(id,w,h); val c = content(w,h)
        // Refined corners represent the physical outer black border, halfway between pixels.
        return listOf(b.left-.5f to b.top-.5f, b.right-.5f to b.top-.5f, b.right-.5f to b.bottom-.5f, b.left-.5f to b.bottom-.5f).map { (x,y) ->
            PointF((x+.5f-c.left)*w/c.width()-.5f, (y+.5f-c.top)*h/c.height()-.5f)
        }
    }
    fun manifest(spec: PaperRegistrationSpec, w: Int? = null, h: Int? = null) = JSONObject().apply {
        put("type", "apriltag8"); put("family", "tag36h11"); put("board_version", 1)
        put("schema_key", spec.schemaKey); put("marker_size_fraction", SIZE.toDouble())
        put("tag_ids", JSONArray((0..7).toList())); put("positions", JSONArray(names))
        put("centres", JSONArray().apply { centres.forEach { (x,y) -> put(JSONArray().put(x.toDouble()).put(y.toDouble())) } })
        put("content_bounds", JSONArray(listOf(.14,.12,.86,.88)))
        if (w != null && h != null) put("canonical_tag_corners_px", JSONArray().apply {
            (0..7).forEach { id -> put(JSONObject().put("id",id).put("position",names[id]).put("corners", JSONArray().apply {
                canonicalCorners(id,w,h).forEach { put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) }
            })) }
        })
    }
    fun preparePage(source: Bitmap, spec: PaperRegistrationSpec): Bitmap {
        ready()
        require(source.height.toFloat()/source.width in 1.2f..1.6f) { "AprilTag board v1 requires a portrait page (aspect 1.2–1.6); print at A4 size." }
        val out = Bitmap.createBitmap(source.width,source.height,Bitmap.Config.ARGB_8888)
        val c = Canvas(out); c.drawColor(Color.WHITE)
        c.drawBitmap(source,null,content(out.width,out.height),Paint(Paint.FILTER_BITMAP_FLAG))
        val dictionary = Objdetect.getPredefinedDictionary(Objdetect.DICT_APRILTAG_36h11)
        for (id in 0..7) {
            val b = box(id,out.width,out.height); val m = Mat()
            try {
                Objdetect.generateImageMarker(dictionary,id, b.width(),m,1)
                val tag = Bitmap.createBitmap(b.width(),b.height(),Bitmap.Config.ARGB_8888)
                try { Utils.matToBitmap(m,tag); c.drawBitmap(tag,b.left.toFloat(),b.top.toFloat(),null) }
                finally { tag.recycle() }
            } finally { m.release() }
        }
        // Identity only: this ordinary QR is never a geometric observation.
        PaperQrFiducial.drawQr(c,PaperQrFiducial.payload(spec.schemaKey,"ID"),out.width*.29f,out.height*.05f,
            (min(out.width,out.height)*.08f).roundToInt())
        return out
    }
    data class Detection(val id: Int, val corners: List<PointF>)
    fun detect(source: Bitmap): List<Detection> {
        ready()
        val rgba = Mat(); val gray = Mat(); val ids = Mat(); val corners = mutableListOf<Mat>()
        val detector = ArucoDetector(Objdetect.getPredefinedDictionary(Objdetect.DICT_APRILTAG_36h11),
            DetectorParameters().apply {
                set_cornerRefinementMethod(Objdetect.CORNER_REFINE_SUBPIX)
                set_cornerRefinementWinSize(3); set_cornerRefinementMaxIterations(40)
                set_cornerRefinementMinAccuracy(.01)
            })
        try {
            Utils.bitmapToMat(source,rgba); Imgproc.cvtColor(rgba,gray,Imgproc.COLOR_RGBA2GRAY)
            detector.detectMarkers(gray,corners,ids)
            val found = (0 until ids.rows()).mapNotNull { i ->
                val id = ids.get(i,0)[0].toInt()
                if (id !in 0..7) null else Detection(id,(0..3).map { k ->
                    val p = corners[i].get(0,k); PointF(p[0].toFloat(),p[1].toFloat())
                })
            }
            if (found.map { it.id }.distinct().size != found.size) throw PaperRegistrationFailure(
                PaperRegistrationDiagnostics(found.map { it.id }, emptyList(), emptyList(), null, null, "fail", "Duplicate expected IDs: use one complete sheet"))
            return found.sortedBy { it.id }
        } finally { rgba.release(); gray.release(); ids.release(); corners.forEach { it.release() }; detector.clear() }
    }
    suspend fun rectify(source: Bitmap, template: PaperTemplate): PaperRectification {
        val detections = withContext(Dispatchers.Default) { detect(source) }
        val fit = withContext(Dispatchers.Default) { fit(detections,template.pageWidthPx,template.pageHeightPx) }
        try {
            // An unreadable identity QR is allowed with the explicitly selected template.
            // A readable conflicting identity is never ignored.
            val identities = PaperQrFiducial.recognise(source).mapNotNull { it.rawValue }
                .filter { it.startsWith("PB:") && it.endsWith(":ID") }
            require(identities.all { it == PaperQrFiducial.payload(template.registration.schemaKey,"ID") }) { "Identity QR belongs to a different template." }
            val matrix = Matrix().apply { setValues(fit.first.map { it.toFloat() }.toFloatArray()) }
            val out = Bitmap.createBitmap(template.pageWidthPx,template.pageHeightPx,Bitmap.Config.ARGB_8888)
            Canvas(out).apply { drawColor(Color.WHITE); drawBitmap(source,matrix,Paint(Paint.FILTER_BITMAP_FLAG)) }
            val anchors = detections.map { d ->
                PaperAnchorEvidence(names[d.id], PointF(d.corners.map { it.x }.average().toFloat(),d.corners.map { it.y }.average().toFloat()),
                    if (d.id in fit.second.accepted) 1f else 0f,0,0,0)
            }
            return PaperRectification(out,anchors,source.width,source.height,"apriltag8_robust_homography",fit.second)
        } catch (e: PaperRegistrationFailure) { throw e }
    }
    /** Tag-atomic outlier rejection: final least-squares fit uses all four corners of each accepted tag. */
    fun fit(detections: List<Detection>, w: Int, h: Int): Pair<DoubleArray,PaperRegistrationDiagnostics> {
        ready()
        val detected = detections.map { it.id }
        fun fail(reason: String, points: List<PaperRegistrationPoint> = emptyList(), accepted: List<Int> = emptyList(), rms: Double? = null, maximum: Double? = null): Nothing =
            throw PaperRegistrationFailure(PaperRegistrationDiagnostics(detected,accepted,points,rms,maximum,"fail",reason))
        if (detected.distinct().size != detected.size || detected.any { it !in 0..7 } || detections.any { it.corners.size != 4 || it.corners.any { p -> !p.x.isFinite() || !p.y.isFinite() } }) fail("Invalid or duplicate tag observations")
        if (!distributed(detected)) fail("Insufficient or clustered tags")
        val src = detections.flatMap { it.corners }; val dst = detections.flatMap { canonicalCorners(it.id,w,h) }
        val a = MatOfPoint2f(*src.map { Point(it.x.toDouble(),it.y.toDouble()) }.toTypedArray())
        val b = MatOfPoint2f(*dst.map { Point(it.x.toDouble(),it.y.toDouble()) }.toTypedArray())
        val mask = Mat(); var matrix = Mat()
        val threshold = 2.5 * min(w,h)/1600.0
        try {
            matrix.release(); matrix = Calib3d.findHomography(a,b,Calib3d.RANSAC,threshold,mask,4000,.999)
            if (matrix.empty()) fail("Homography could not be estimated")
            var accepted = detections.indices.filter { i -> (0..3).all { k -> mask.get(i*4+k,0)[0] != 0.0 } }.map { detections[it].id }
            if (!distributed(accepted)) fail("Outlier rejection leaves insufficient spatial coverage", accepted=accepted)
            fun refit() {
                val indices = src.indices.filter { detections[it/4].id in accepted }
                val sa = MatOfPoint2f(*indices.map { Point(src[it].x.toDouble(),src[it].y.toDouble()) }.toTypedArray())
                val sb = MatOfPoint2f(*indices.map { Point(dst[it].x.toDouble(),dst[it].y.toDouble()) }.toTypedArray())
                try { matrix.release(); matrix = Calib3d.findHomography(sa,sb,0) } finally { sa.release(); sb.release() }
            }
            refit()
            if (matrix.empty()) fail("Degenerate final homography", accepted=accepted)
            val values = DoubleArray(9); matrix.get(0,0,values)
            fun project(p: PointF): PointF {
                val z = values[6]*p.x + values[7]*p.y + values[8]
                return PointF(((values[0]*p.x+values[1]*p.y+values[2])/z).toFloat(),((values[3]*p.x+values[4]*p.y+values[5])/z).toFloat())
            }
            val points = src.indices.map { i -> PaperRegistrationPoint(detections[i/4].id,i%4,src[i],dst[i],project(src[i]),detections[i/4].id in accepted) }
            if (points.any { !it.error.isFinite() }) fail("Non-finite transform",accepted=accepted)
            val inliers = points.filter { it.inlier }; val rms = sqrt(inliers.sumOf { it.error*it.error }/inliers.size)
            val maximum = inliers.maxOf { it.error }
            if (maximum > threshold || rms > threshold*.65) fail("Excessive residual error; flatten/rescan the page",points,accepted,rms,maximum)
            // Validate the inverse across the whole content rectangle (no pole/fold-over).
            val inverse = Mat()
            try {
                if (Core.invert(matrix,inverse) == 0.0) fail("Singular transform",points,accepted,rms,maximum)
                val v = DoubleArray(9); inverse.get(0,0,v)
                val denominators = listOf(0.0 to 0.0,w.toDouble() to 0.0,w.toDouble() to h.toDouble(),0.0 to h.toDouble()).map { (x,y) -> v[6]*x+v[7]*y+v[8] }
                if (denominators.any { !it.isFinite() || abs(it)<1e-9 } || denominators.any { it*denominators[0]<=0 }) fail("Projective pole crosses content",points,accepted,rms,maximum)
            } finally { inverse.release() }
            val quality = when (accepted.size) { 8 -> "ideal"; 6,7 -> "strong"; else -> "adequate" }
            return values to PaperRegistrationDiagnostics(detected,accepted,points,rms,maximum,quality)
        } finally { a.release(); b.release(); mask.release(); matrix.release() }
    }
    /** Both axis span and convex hull area are required after outlier rejection. */
    fun distributed(ids: List<Int>): Boolean {
        if (ids.distinct().size < 4 || ids.any { it !in 0..7 }) return false
        val p = ids.distinct().map { centres[it] }.sortedWith(compareBy<Pair<Float,Float>> { it.first }.thenBy { it.second })
        if (p.maxOf { it.first }-p.minOf { it.first } < .8 || p.maxOf { it.second }-p.minOf { it.second } < .85) return false
        fun cross(a: Pair<Float,Float>,b: Pair<Float,Float>,c: Pair<Float,Float>) = (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first)
        fun half(ps: List<Pair<Float,Float>>): List<Pair<Float,Float>> {
            val out = mutableListOf<Pair<Float,Float>>()
            for (q in ps) { while(out.size>=2 && cross(out[out.size-2],out.last(),q)<=0) out.removeAt(out.lastIndex); out.add(q) }
            return out.dropLast(1)
        }
        val hull = half(p)+half(p.reversed())
        val area = abs(hull.indices.sumOf { i -> val a=hull[i];val b=hull[(i+1)%hull.size]; (a.first*b.second-a.second*b.first).toDouble() })/2
        return area >= .38
    }
    /** Source-space overlay: blue expected positions, green/red detections, residual vectors and ROI boundaries. */
    fun debugOverlay(source: Bitmap, template: PaperTemplate, result: PaperRectification): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888,true); val canvas=Canvas(out)
        val d = result.diagnostics ?: return out
        val fit = fit(d.points.groupBy { it.id }.map { (id,ps) -> Detection(id,ps.sortedBy { it.corner }.map { it.source }) },template.pageWidthPx,template.pageHeightPx)
        val transform = Matrix().apply { setValues(fit.first.map { it.toFloat() }.toFloatArray()) }; val inverse=Matrix()
        check(transform.invert(inverse))
        fun sourcePoint(p: PointF): PointF { val a=floatArrayOf(p.x,p.y); inverse.mapPoints(a);return PointF(a[0],a[1]) }
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth=2f; style=Paint.Style.STROKE }
        (0..7).forEach { id ->
            val ps=canonicalCorners(id,template.pageWidthPx,template.pageHeightPx).map(::sourcePoint)
            paint.color=Color.BLUE
            ps.indices.forEach { i -> val a=ps[i];val b=ps[(i+1)%4];canvas.drawLine(a.x,a.y,b.x,b.y,paint) }
        }
        d.points.forEach { p -> val expected=sourcePoint(p.canonical);paint.color=if(p.inlier) Color.GREEN else Color.RED
            canvas.drawCircle(p.source.x,p.source.y,4f,paint);canvas.drawLine(p.source.x,p.source.y,expected.x,expected.y,paint) }
        paint.color=Color.MAGENTA
        template.fields.flatMap { listOfNotNull(it.roi)+it.options.map { o -> o.roi } }.forEach { r ->
            val ps=listOf(PointF(r.left*template.pageWidthPx,r.top*template.pageHeightPx),PointF(r.right*template.pageWidthPx,r.top*template.pageHeightPx),PointF(r.right*template.pageWidthPx,r.bottom*template.pageHeightPx),PointF(r.left*template.pageWidthPx,r.bottom*template.pageHeightPx)).map(::sourcePoint)
            ps.indices.forEach { i -> val a=ps[i];val b=ps[(i+1)%4];canvas.drawLine(a.x,a.y,b.x,b.y,paint) }
        }
        return out
    }
}

/** Compatibility dispatch for legacy QR4 templates; new templates use AprilTags. */
internal object PaperFiducial {
    fun preparePage(source: Bitmap,spec: PaperRegistrationSpec) = if(spec.type==PaperRegistrationType.APRILTAG8) PaperAprilTagRegistration.preparePage(source,spec) else PaperQrFiducial.preparePage(source,spec)
    suspend fun hasExpectedMarkers(source: Bitmap,spec: PaperRegistrationSpec) = if(spec.type==PaperRegistrationType.APRILTAG8) withContext(Dispatchers.Default) { PaperAprilTagRegistration.detect(source).isNotEmpty() } else PaperQrFiducial.hasExpectedMarkers(source,spec)
    suspend fun rectify(source: Bitmap,template: PaperTemplate,mlKitPreprocessed: Boolean) = if(template.registration.type==PaperRegistrationType.APRILTAG8) PaperAprilTagRegistration.rectify(source,template) else PaperQrFiducial.rectify(source,template,mlKitPreprocessed)
    fun canonicalFromPrepared(source: Bitmap,spec: PaperRegistrationSpec,w: Int,h: Int): Bitmap {
        if(spec.type!=PaperRegistrationType.APRILTAG8) return PaperQrFiducial.canonicalFromPrepared(source,spec,w,h)
        val out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(source,android.graphics.Rect((source.width*.14f).roundToInt(),(source.height*.12f).roundToInt(),(source.width*.86f).roundToInt(),(source.height*.88f).roundToInt()),android.graphics.Rect(0,0,w,h),Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }
}
