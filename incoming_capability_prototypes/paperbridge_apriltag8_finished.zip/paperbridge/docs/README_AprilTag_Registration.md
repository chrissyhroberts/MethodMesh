# PaperBridge AprilTag registration

New designs default to `apriltag8`, board version 1, OpenCV `DICT_APRILTAG_36h11` (tag36h11). Existing `methodmesh.paper.v1` manifests, field names, extraction/review/commit contracts and portable bundle entries are retained. QR4 and bullseye4 remain explicit legacy readers/exporters; changing an old manifest's type without regenerating its form is not a migration.

## Installation

Copy this folder into `app/src/main/java/com/example/methodmesh/modules/paperbridge` and add to `app/build.gradle.kts`:

```kotlin
apply(from = "src/main/java/com/example/methodmesh/modules/paperbridge/paperbridge-dependencies.gradle.kts")
```

The script adds `org.opencv:opencv:4.12.0` from Maven Central. Existing ML Kit and Compose dependencies remain required. The test source is shipped with a `.kt.txt` suffix so it is not compiled into the app. Copy it to the corresponding `app/src/androidTest/java/.../paperbridge` package and remove the `.txt` suffix to run it. Native OpenCV must load successfully; there is no silent fallback to QR geometry.

## Board geometry and printing

Use a portrait page, height/width 1.2–1.6, printed at A4 size without clipping. Black tag size is `round(min(width,height) * 14/210)` pixels, approximately 14 mm on A4. The white surround is supplied by the reserved perimeter band. Black edges are roughly 7–8 mm inside the sheet edge, with at least one white module outside them. All tags have the dictionary's upright orientation; no marker is rotated on the generated sheet.

| Position | ID | Sheet centre (x/width, y/height) |
|---|---:|---|
| TL | 0 | (0.07, 0.05) |
| TC | 1 | (0.50, 0.05) |
| TR | 2 | (0.93, 0.05) |
| LC | 3 | (0.07, 0.50) |
| RC | 4 | (0.93, 0.50) |
| BL | 5 | (0.07, 0.95) |
| BC | 6 | (0.50, 0.95) |
| BR | 7 | (0.93, 0.95) |

The canonical artwork is scaled into sheet bounds `[0.14,0.12,0.86,0.88]`. The stored `page.width_px/height_px` describe canonical artwork dimensions and also the generated sheet raster dimensions. Artwork is never shifted separately for individual fields. Tags lie outside the canonical content rectangle; their canonical corner coordinates can be negative or exceed the content size. Every parsed/exported AprilTag manifest includes exact `canonical_tag_corners_px`, ordered tag-local TL/TR/BR/BL, calculated by the same function used by registration. These are derived values, not a second editable board definition.

For width W, height H, tag size S, integer left L=`round(cx*W-S/2)` and top T=`round(cy*H-S/2)`, the four physical outer black-border corners in pixel-centre coordinates are `(L-0.5,T-0.5),(L+S-0.5,T-0.5),(L+S-0.5,T+S-0.5),(L-0.5,T+S-0.5)`. Their canonical coordinates are `x=(sheetX+0.5-0.14W)/0.72-0.5`, `y=(sheetY+0.5-0.12H)/0.76-0.5`. Pixel-centre offsets account for raster sampling, not ROI corrections. `canonicalCorners` is authoritative for Float rounding.

One ordinary QR at `(0.29W,0.05H)` carries `PB:<schema_key>:ID`. It contributes zero geometric correspondences. A readable conflicting identity rejects the scan. If the identity is absent/unreadable, the operator's selected template controls extraction; fixed tag IDs alone cannot identify the template.

## Registration and quality

Detection examines the full original scan at its native resolution. OpenCV returns oriented tag corners and refines them with `CORNER_REFINE_SUBPIX` (3-pixel window, 40 iterations, 0.01-pixel tolerance). Unknown IDs are ignored; duplicate expected IDs reject the sheet.

All four corners per detected expected tag enter RANSAC. The destination frame is canonical content pixels, with a threshold of `2.5 * min(W,H)/1600`. A tag survives only if all four corners are inliers. A final least-squares homography uses every corner of each surviving tag. No single-tag or centre-only solution is accepted. RMS must be at most 65% of the RANSAC threshold and maximum retained-point error must be at most the threshold. Non-finite and singular solutions and projective poles crossing the content rectangle are rejected.

Coverage checks apply before and after rejection: at least four distinct tags; sheet-centre spans at least 0.80 horizontally and 0.85 vertically; convex-hull area at least 0.38 of the sheet. This rejects clustered four-tag configurations. Eight accepted tags are ideal, six/seven strong, and four/five adequate only after all checks pass.

The original acquisition image is drawn through the accepted homography once into the canonical bitmap, including for ML Kit acquisitions. ML Kit may itself have flattened the sheet before passing it to PaperBridge; PaperBridge does not then use a separate axis-aligned crop path. OCR, OMR and barcode routines crop their existing tight preset ROIs from this bitmap. Review previews alone expand by 6% per side, clamped to the image. Existing analysis-specific border/ink handling remains unchanged.

Diagnostics are attached to `PaperRectification`, emitted under `registration_diagnostics` in extraction/commit metadata, and shown in technical details and designer tests. They include expected/detected/accepted IDs, observed and inlier point counts, canonical-pixel RMS/max, all-point max (including rejected observations), quality/pass/fail and per-corner source/canonical/projected/residual data. Geometry failures throw `PaperRegistrationFailure` with diagnostics; the displayed error includes the failure reason. A failure before fitting reports unavailable RMS/max rather than misleading zero errors.

## Debug and future correction

`PaperAprilTagRegistration.debugOverlay(source, template, result)` returns a separate source-space diagnostic bitmap. Blue outlines are expected tag corners projected back to the source; green/red points are accepted/rejected detections with residual vectors; magenta outlines are ROIs. The source must be the same oriented acquisition supplied to registration. The example overlay is generated by the native test. It never changes extraction pixels.

Non-projective correction is deliberately deferred. Perimeter observations do not reliably constrain a page's interior curvature. Applying an interpolated mesh now could move response boxes without supporting measurements. `PaperRegistrationPoint` retains the distributed correspondences and residuals separately from rasterization for a future validated mapping model. Excessive retained residuals currently require flattening/rescanning.

## Validation

The Android instrumentation suite covers generated tag detection, real raster rectification and ROI position, half-resolution images, 90-degree rotation, perspective distortion, missing tags, distributed 4/5/6/7/8-tag sets, clustered rejection, displaced-tag rejection, duplicate observations, identity mismatch, manifest roundtrip and legacy parsing. See `BUILD_TEST_RESULTS.md` for the actual run outcome. The `example_apriltag_*` files are the current examples. Older demo files and historical manuals remain for the legacy tutorial and compatibility testing.

API references: [OpenCV ArucoDetector](https://docs.opencv.org/4.12.0/javadoc/org/opencv/objdetect/ArucoDetector.html), [DetectorParameters](https://docs.opencv.org/4.12.0/javadoc/org/opencv/objdetect/DetectorParameters.html), [Calib3d](https://docs.opencv.org/4.12.0/javadoc/org/opencv/calib3d/Calib3d.html).
