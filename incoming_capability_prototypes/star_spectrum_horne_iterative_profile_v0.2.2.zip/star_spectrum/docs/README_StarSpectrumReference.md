# Spectrum reference creator

**Module:** `star_spectrum`  
**Capability:** `astronomy.spectrum.reference.create`  
**Version:** `0.2.0`  
**Maturity:** `DEVELOPMENT`  
**Connectivity:** `OFFLINE`

## Purpose

Create a reusable wavelength calibration from the user's own reference-star observation, with A-type stars as the intended first-class workflow.

The reference is tied to the user's actual camera/grating/image geometry rather than pretending that a generic dispersion value is sufficient for every device.

## Native workflow

1. Load an A-star reference image.
2. Name the reference and optionally record star name/spectral type.
3. Select an approximate line along the dispersed spectrum.
4. Extract the reference spectrum using the same two-dimensional trace/background model as the analyser.
5. Choose a known Balmer line and tap its trough on the extracted spectrum.
6. Repeat for at least two anchors (linear) or three anchors (quadratic).
7. Inspect fit RMS and polynomial.
8. **Commit reference**.
9. On Commit, MethodMesh freezes the canonical output and persists the reusable reference in the module-owned local reference library.

The reference does not become persistent before Commit.

## Built-in A-star anchor helpers

The UI exposes these convenience anchors:

| Label | Wavelength |
|---|---:|
| Hδ | 410.17 nm |
| Hγ | 434.05 nm |
| Hβ | 486.13 nm |
| Hα | 656.28 nm |

These are convenience values for the initial A-star workflow. The canonical data model stores arbitrary distance/wavelength anchors, so the module can later expose other calibration sources without changing the reference schema.

## Calibration model

The stored relation is:

```text
wavelength_nm = a0 + a1 * distance_px [+ a2 * distance_px^2]
```

The user chooses:

- linear (`order=1`) — minimum 2 anchors;
- quadratic (`order=2`) — minimum 3 anchors.

The fit is ordinary least squares over the placed anchors. Calibration RMS is stored in nanometres and is reused as one component of later target-observation calibration confidence.

## Persistent reference schema

A committed reference stores:

- stable reference UUID;
- reference name;
- star name;
- spectral type;
- creation time;
- source analysis dimensions;
- trace start/end convention;
- polynomial order and coefficients;
- calibration RMS;
- all calibration anchors;
- valid calibrated distance range.

The source astronomical image is **not** silently archived into the reference library. The reference library stores the calibration model and provenance required for reuse.

When this capability was invoked by ODK and MethodMesh itself acquired the source image, the source is returned to ODK as a conditional attachment, in accordance with MethodMesh source-return semantics.

## Settings / runtime inputs

| Key | Type | Default | Meaning |
|---|---|---:|---|
| `source_image_uri` | text | blank | Optional caller-supplied image; blank uses native picker. |
| `reference_name` | text | `A-star reference` | Human reference-library label. |
| `star_name` | text | blank | Reference-star name. |
| `spectral_type` | text | `A0V` | Recorded reference spectral type. |
| `polynomial_order` | choice | `2` | `1` linear or `2` quadratic. |
| `calibration_anchors_json` | text | blank | Advanced pre-supplied anchor array; native UI normally places anchors graphically. |
| `ribbon_half_width_px` | int | 28 | Trace-search half-width. |
| `aperture_half_width_px` | int | 5 | Reference-star extraction half-width. |
| `background_gap_px` | int | 4 | Background-sideband gap. |

## Canonical outputs

| Field | Description |
|---|---|
| `spectrum_reference_status` | `succeeded` / `failed`. |
| `spectrum_reference_id` | Persistent reference UUID. |
| `spectrum_reference_source_image_uri` | Conditional source attachment when MethodMesh acquired the source on caller's behalf. |
| `spectrum_reference_source_image_sha256` | SHA-256 of the conditional source attachment. |
| `spectrum_reference_name` | Human name. |
| `spectrum_reference_star_name` | Star name. |
| `spectrum_reference_spectral_type` | Recorded spectral type. |
| `spectrum_reference_anchor_count` | Number of wavelength anchors. |
| `spectrum_reference_polynomial_order` | 1 or 2. |
| `spectrum_reference_coefficients_json` | Polynomial coefficients `[a0,a1(,a2)]`. |
| `spectrum_reference_rms_nm` | Fit RMS in nm. |
| `spectrum_reference_dispersion_nm_per_px` | Polynomial derivative at the midpoint of the calibrated anchor range. |
| `spectrum_reference_wavelength_min_nm` / `spectrum_reference_wavelength_max_nm` | Wavelength range spanned by the calibration anchors/model. |
| `spectrum_reference_trace_quality` | Reference extraction trace-quality score. |
| `spectrum_reference_created_time_iso` | Commit time. |
| `spectrum_reference_json` | Complete reusable reference object. |
| `spectrum_reference_error` | Failure diagnostic. |

Shared FULL transport adds `methodmesh_full_json`.

## ODK Integration Card

### Method

`astronomy.spectrum.reference.create`

### Canonical showcase call

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='astronomy.spectrum.reference.create',
  input_reference_name=${reference_name},
  input_star_name=${star_name},
  input_spectral_type=${spectral_type},
  input_payload_mode='FULL',
  return_mode='flat'
)
```

The operator selects the source image and places anchors inside MethodMesh. The ODK showcase therefore receives `spectrum_reference_source_image_uri` as the source attachment acquired on ODK's behalf.

### Return semantics

The showcase captures canonical reference fields, `methodmesh_status`, `methodmesh_full_json`, and the conditional source image attachment.

### Workbook

`docs/example_odk_showcase_astronomy_spectrum_reference_create.xlsx`

Exactly one MethodMesh invocation is present. It uses unprefixed canonical return names and no return namespace.

## Presets / protocols

This capability remains independently selectable for presets and protocols.

A preset can fix an instrument-specific reference name, A-star spectral type, extraction aperture and polynomial order while leaving `source_image_uri` as a runtime input. A protocol can create/reference-calibrate before a later `astronomy.spectrum.analyse` run.

The persistent reference itself is referred to later by `spectrum_reference_id` / `reference_id`; the analysis capability does not need to know how the reference was created.

## Offline / privacy

Fully offline. Reference images, star names and calibration solutions remain on the device unless explicitly returned/shared by the invoking surface.

## Dependencies

No new third-party library. Uses the existing MethodMesh runtime, Android raster/file APIs, Jetpack Compose and module-owned JSON persistence.

## Limitations

- v0.2 does not automatically recognise Balmer features; the operator places known anchors.
- The supplied Balmer shortcuts are not a claim that every visible trough in an A-star exposure is one of those lines.
- A saved reference is only scientifically transferable while the relevant optical/camera geometry remains sufficiently stable.

See `VALIDATION.md`.


### Balmer anchor placement UX

Placed Hα, Hβ, Hγ and Hδ anchors remain visible simultaneously on the spectrum chart. The active anchor can be reselected at any time. The chart supports horizontal pinch zoom/pan, press-and-hold magnified drag placement, and ±1/±5 sample nudging for fine control.

### Reference picker display

The calibration picker displays spectra in conventional VIOLET → RED order even though the internal trace coordinate remains RED-origin for stable storage and calibration. The default calibration view is continuum-normalised (`corrected signal / rolling-median continuum`) with a local vertical scale that expands as the user zooms. A raw extracted-signal view remains available. This is intended to make broad Balmer absorption troughs visible despite camera-response and continuum slope.

Endpoint placement uses a magnified candidate position. A coordinate is committed only after the candidate remains stationary for three seconds, so lifting the finger cannot jitter the stored point. Full-screen controls apply Android navigation-bar padding.

### v0.2 calibration-trace refinement

The image extractor no longer uses BT.709 perceptual luminance. JPEG/sRGB channel values are approximately linearised and the three linear-light channels are combined for relative spectral signal. This avoids imposing a strong green perceptual weighting on a spectrum whose hue varies systematically with wavelength.

The calibration display applies a small five-sample display smoothing, estimates a broad robust continuum, and masks regions where the local continuum is below 3% of the usable maximum rather than dividing near-zero image signal into large false spikes. These operations affect the calibration display only; anchor coordinates remain tied to the underlying extraction samples.

Endpoint placement now has explicit PAN / ZOOM and RED / VIOLET placement modes so navigation and long-press precision gestures do not compete. Movement within a three-image-pixel radius is treated as finger tremor and does not restart the three-second lock countdown.

### Calibration display signal

Balmer placement is now based on the **Horne-style optimally extracted 1-D signal**. If an optimal column is invalid, the simple background-subtracted boxcar value is used only as a fallback so the chart remains inspectable.

The calibration chart keeps three display modes:

- **Relative flux** — preserves the broad image-derived envelope.
- **Line finder** — divides by a broad continuum estimate to make local absorption troughs easier to position.
- **Direct** — shows the optimally extracted relative signal without display normalisation.

The displayed amplitude remains image-derived relative signal for JPEG/PNG input; it is not a radiometrically calibrated stellar flux.


### Calibration chart display modes

The wavelength-anchor chart now opens in **Relative flux** mode. This preserves the broad image-derived spectral envelope with zero at the bottom of the plot and overlays a smoothed broad continuum, so the trace does not artificially oscillate around a central line. **Line finder** is the continuum-normalised view used to locate local absorption troughs precisely. **Direct** exposes the background-subtracted aperture signal without display normalisation.

Relative flux is deliberately described as image-derived relative signal: a processed colour JPEG cannot provide a radiometrically calibrated stellar spectral energy distribution without camera-response calibration.

## Optimal extraction and visible QA

The primary 1-D science signal now comes from a Horne-style optimal extraction rather than the earlier experimental template-amplitude correction.

The native UI deliberately exposes the intermediate products used to construct that spectrum:

1. **Rectified trace** — fitted spectrum transformed to a horizontal dispersion axis.
2. **Two-sided background** — sigma-clipped local background estimated outside the target aperture.
3. **Background subtracted** — target ribbon after local-background removal.
4. **Spatial profile weights** — current unit-normalized empirical cross-dispersion profile.
5. **Fitted target model** — optimal 1-D flux multiplied by the current spatial profile.
6. **Data − fitted model residual** — signed raw mismatch.
7. **Standardized residual z-map** — mismatch divided by the local variance proxy; this is the rejection statistic.
8. **Cleaned optimal aperture** — rejected pixels highlighted and replaced only for the QA display.
9. **Boxcar versus optimal** — simple aperture sum compared with Horne-style optimal flux.

The spectrum CSV preserves both boxcar and optimal signals. For JPEG/PNG input, the variance used for optimal weighting is an empirical relative proxy because detector gain/read noise are not available. This limitation is explicit in metadata.

Balmer wavelength anchors are placed on the optimally extracted 1-D spectrum.


### Extraction residual QA

The extraction QA sequence now distinguishes the empirical unit-normalized spatial profile from the fitted 2-D target model. The residual panel shows `background-subtracted data − fitted target model` with a zero-centred greyscale and overlays rejected pixels in orange. The current iterative outlier rule is shown explicitly in the UI (`> 5.0σ residual` by default).


### Iterative profile refinement

The optimal extractor now alternates between flux extraction, standardized-residual rejection and **re-estimation of the empirical spatial profile from surviving pixels**. The profile is therefore not held fixed while the rejection loop proceeds.

At each pass MethodMesh:

1. extracts optimal 1-D flux with the current spatial profile;
2. calculates per-pixel standardized residuals;
3. rejects at most the strongest `|z| > 5σ` outlier in each dispersion column;
4. rebuilds the empirical spatial profile from the surviving pixels;
5. re-extracts using the revised profile.

The rejection threshold is deliberately not lowered merely because coherent residual structure remains. The QA panel exposes `% |z| > 3σ`, `% |z| > 5σ`, maximum `|z|` and the number of profile-update passes so model inadequacy remains visible rather than being converted automatically into contamination.
