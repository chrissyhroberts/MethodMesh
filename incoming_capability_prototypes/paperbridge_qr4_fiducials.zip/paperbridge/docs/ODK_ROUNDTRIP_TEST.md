# Paper Bridge ODK round-trip test

Use `example_odk_showcase_paper_form_transcribe.xlsx` as the canonical integration fixture.

## Registration fixture

The current bundled schema uses QR4 registration. Its prepared blank/filled forms contain four `PB:DEMO01:<corner>` fiducials; their centres define the runtime analysis frame. A wrong schema key must fail closed. Legacy bullseye registration is not the primary integration fixture.

## Expected flow

1. Load the XLSForm into ODK Collect.
2. Enter the `scan_paper` group. Its `body::intent` launches `paper.form.transcribe` with `return_mode='flat'` and `input_payload_mode='FULL'`.
3. Scan and review a completed paper form in Paper Bridge.
4. Commit once all review items are resolved.
5. Paper Bridge returns through the canonical Android/MethodMesh result path; it does **not** create a standalone result ZIP for an external/ODK launch.
6. ODK resumes the same form instance. The final note shows a short value summary so the operator can see that the round trip occurred.
7. The form instance also owns the hidden source image, registered image, image-ROI attachment, hashes and audit/metadata fields.

## Demo data nodes

- `participant_id`
- `visit_number`
- `eaten_today`
- `symptoms`
- `temperature_c`
- `specimen_barcode`
- `site_sketch` (`image`)

## Stable Paper Bridge nodes

- `paper_status`
- `paper_template_id`
- `paper_template_version`
- `paper_values_json`
- `paper_dynamic_fields_json`
- `paper_field_count`
- `paper_auto_accepted_count`
- `paper_reviewed_count`
- `paper_unresolved_count`
- `paper_source_image` (`image`)
- `paper_rectified_image` (`image`)
- `paper_template_sha256`
- `paper_source_sha256`
- `paper_rectified_sha256`
- `paper_extraction_audit_json`
- `paper_attachment_metadata_json`
- `paper_scan_time_iso`
- `paper_error`
- `methodmesh_full_json`

## Media expectation

The three demo media returns are `site_sketch`, `paper_source_image` and `paper_rectified_image`. They are returned as `content://` URIs and the shared MethodMesh Android result transport is responsible for read grants/ClipData so ODK can take ownership.

## Barcode expectation

A clean single barcode decode returns its decoded text directly. If a barcode ROI visibly contains a label but ML Kit cannot decode it after retry processing, the field must remain in Review rather than silently returning blank. OCR of human-readable text in the barcode ROI may be shown as a suggested value, but requires operator confirmation.

## Validation status

The workbook has been structurally inspected and contains no spreadsheet formula errors. A true ODK Collect device round trip remains the acceptance test; do not promote this Development module on workbook inspection alone.
