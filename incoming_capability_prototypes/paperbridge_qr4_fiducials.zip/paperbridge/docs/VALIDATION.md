# Paper Bridge validation plan

`paper.form.transcribe` and `paper.form.design` are **Development** until the image/extraction and ODK roundtrip validation below have been completed on representative devices and paper stock.

## Contract / architecture checks

- [x] One canonical method: `paper.form.transcribe`.
- [x] Module entry point is self-contained and auto-discoverable by the existing `*Module.kt` index rule.
- [x] No shared UI special case or central registration change required.
- [x] Existing MethodMesh ML Kit and Android dependencies are sufficient.
- [x] Dashboard/direct/preset/protocol/ODK all use the same method contract.
- [x] Working scan is mutable; Commit is the finalisation boundary.
- [x] External/ODK invocation returns only after Commit.
- [x] Dynamic paper keys are validated manifest field names and are the flat projection of `paper_values_json`.
- [x] ODK owns persistence and Central submission.
- [x] No automatic MethodMesh archive save is performed during ODK roundtrip.
- [x] Scalar results are tap-to-copy in native committed/working surfaces.
- [x] Native MethodMesh dashboard launch opens the Paper Bridge control surface; external/ODK/preset launch still enters the canonical scan workflow directly.
- [x] Dashboard template/activity workspace stores no questionnaire values, participant identifiers or page images.
- [x] A working scan can be left for the dashboard and resumed without creating a Commit.

## Designer validation

Using the staged colour tutorial and its matching survey/choices workbook:

1. open **Paper Bridge → Schemas → Example — learn Paper Bridge** and verify the colour-authored template opens unresolved;
2. verify the example uses QR4 registration and all four `PB:DEMO01:<corner>` markers can be decoded from the prepared source;
3. verify the workbook exposes seven compatible fields with exact names/choice return values, including `barcode` and `image`;
4. press **AUTO DETECT** and verify colour question envelopes, black response regions and blue select labels produce proposed mappings rather than a pre-completed schema;
5. verify `visit_number` imports 1–12 bounds, `temperature_c` imports 34–43, and `participant_id` imports its regex;
6. leave or create an unresolved region and confirm Save remains blocked while a structural mapping error remains;
7. deliberately overlap two response regions substantially and verify a blocking error;
8. verify valid target-centre-frame ROIs are not rejected merely for being near a canvas corner;
9. create duplicate/reserved/invalid manual variable names and verify they are rejected;
10. **SAVE SCHEMA** and verify a QR-prepared printable form is generated;
11. **TEST EMPTY** on the blank production fixture, then **TEST DATA** on the filled fixture;
12. **FINALISE**, reopen the schema from the library and verify its definition/source configuration persists without storing completed participant data.

XLSForm reader regression cases should include inline strings, shared strings, multilingual label columns, missing choices sheets, unsupported survey types and complex constraints. Unsupported constructs must produce warnings/skip behaviour rather than silent remapping.

## Manifest negative tests

Expect hard rejection for:

1. blank manifest;
2. unsupported schema;
3. missing `template_id`;
4. empty `fields`;
5. duplicate field names;
6. invalid XLSForm node name;
7. field name beginning `paper_` or `methodmesh_`;
8. ROI outside `[0,1]` or inverted ROI;
9. OMR field without options;
10. OCR/barcode field without ROI;
11. duplicate OMR option values;
12. malformed regex;
13. page dimensions outside declared bounds.

## Anchor / rectification corpus

Create a labelled corpus for each supported paper layout with at minimum:

- flat scanner image;
- hand-held portrait photographs at ±5°, ±10°, ±20° perspective;
- portrait/landscape device rotations;
- uneven indoor light;
- strong side shadow;
- low contrast photocopy;
- slightly cropped page but all anchors present;
- each single missing anchor;
- one false dark object placed in each corner zone;
- wrinkled page;
- old `OMR_LSHTM`-style anchor form where compatible.

For each image record expected anchor centres in canonical source pixels and compute rectification error at known control points. Production acceptance should be defined in pixels/mm before promotion; do not promote on visual impression alone.

Any missing/implausible anchor set must stop extraction rather than continue with guessed geometry.

## OMR labelled tests

For every mark ROI capture labelled examples of:

- empty box;
- tick;
- cross;
- filled box;
- faint pencil;
- partially erased mark;
- pen outside box;
- two marks in a single-select question;
- mark close to threshold;
- photocopy artefacts.

Estimate false-positive and false-negative rates separately. Tune manifest thresholds against held-out pages, not the same pages used to choose thresholds.

Required invariant: a single-select multimark must enter review; code must never pick the darkest of two marked responses.

## OCR validation

For each intended OCR field type test:

- clean printed text;
- block capitals;
- digits;
- decimal values;
- common ambiguous glyph pairs (`O/0`, `I/1`, `S/5`);
- invalid range;
- invalid regex;
- blank required field;
- multiple lines within ROI;
- text crossing ROI edge.

Because OCR is manual-review by default, measure both candidate accuracy and final post-review accuracy. If any field/template enables `auto_accept_ocr`, validate that combination independently and document its acceptable error bound.

## State / lifecycle tests

- native dashboard opens with the active template and does not trigger camera/file acquisition until requested;
- camera/file-picker cancellation returns cleanly to the dashboard when no working scan exists;
- import a valid manifest, switch templates, relaunch Paper Bridge and verify the active native template persists;
- reject an invalid imported/edited manifest without replacing the current active template;
- remove a custom template and verify the bundled demo remains available;
- open a working scan, return to dashboard, resume it and verify review state remains intact;
- after Commit, recent activity contains only template/time/count metadata and no field values/images/participant IDs;
- clearing recent activity does not delete ODK/MethodMesh committed outputs or templates;
- rotate Android device after capture: source URI survives and extraction can be reconstructed;
- rotate after manual corrections: override values survive and are re-applied;
- rescan clears manual overrides;
- manual Rotate 90° clears overrides and recomputes extraction;
- Cancel from ODK returns cancellation without committed data;
- Commit is disabled while any required/review field is unresolved;
- after Commit, external origin immediately returns; native origin shows committed state/actions.

## ODK roundtrip

Using `example_odk_showcase_paper_form_transcribe.xlsx`:

1. validate XLSForm;
2. install in ODK Collect;
3. open group and launch MethodMesh;
4. scan the matching demo paper layout;
5. review forced OCR fields;
6. Commit;
7. verify `participant_id`, `visit_number`, `eaten_today`, `symptoms`, `temperature_c`, `specimen_barcode` and `site_sketch` are populated with exact values;
8. verify `paper_values_json` matches those flat fields;
9. verify `paper_source_image` and `paper_rectified_image` become real ODK media attachments rather than unusable URI text;
10. verify `paper_source_sha256` and `paper_rectified_sha256` hash the attachment bytes;
11. verify `methodmesh_full_json` exists when FULL payload mode is requested;
12. save/finalise/send via normal ODK workflow and confirm Central contains both data and media.

## Batch truth-set recommendation

Before Production, build a study-neutral benchmark with at least several hundred independently double-entered paper pages across multiple Android camera models. The truth set should include intentional edge cases and preserve raw images. Report field-level sensitivity/specificity for OMR, exact-match for OCR candidates, review rate, final post-review disagreement rate, anchor failure rate and rescan rate.

The production claim should be based on those observed rates. “No margin for error” is implemented operationally as fail-closed ambiguity plus review, not as an untestable claim that computer vision cannot be wrong.

## Host scrolling regression guard

- Paper Bridge capability roots MUST NOT apply `verticalScroll`/`LazyColumn` as an outer viewport.
- MethodMesh dashboard and external workflow hosts already own vertical scrolling; nesting another vertical scroll at the capability root can throw an infinite-height Compose measurement exception at runtime.
- Verify both dashboard and scan/review surfaces by launching from MethodMesh Dashboard and from an external/ODK intent.

## Designer viewport / gesture regression

- Blank-form canvas opens fitted at 1×.
- NAV mode supports one-finger pan and two-finger pinch zoom from 1× to 48×; + / − controls must reach the same bounded zoom state.
- Pan is clamped so the page cannot be lost completely beyond the viewport.
- Fit resets zoom to 1× and pan to the page centre.
- **Place box** is enabled whenever a source page is loaded; it does not depend on first selecting an ODK field.
- Placed rectangles are converted through the current viewport transform into normalized page coordinates; zoom/pan must never alter saved ROI geometry.
- Newly placed boxes are unlinked and remain visible until explicitly linked or deleted.
- A tap on a region selects it without requiring drag slop; where regions overlap, the smallest region containing the tap is selected. In **EDIT**, dragging inside the selected box moves it without changing size; dragging any of the four corner handles resizes it.
- Repositioning/resizing must update the existing region rather than creating duplicate ROIs.
- Every linked region remains visibly annotated on the page with its ODK variable and, for OMR, return value.
- Drawing equivalent boxes at different zoom levels must produce the same normalized coordinates within pointer-placement tolerance.

## Built-in example availability

1. Clear Paper Bridge workspace preferences / install cleanly.
2. Open **Paper Bridge → Schemas** without importing any files.
3. Confirm **Example — learn Paper Bridge** is present and labelled as a staged built-in tutorial / needs setup.
4. Open it and verify the QR4 colour-authoring PNG renders without a file picker.
5. Confirm the matching `survey`/`choices` workbook loads without a picker and reports seven compatible fields.
6. Confirm no response ROI is pre-wired before **AUTO DETECT**.
7. Press **AUTO DETECT** and verify proposed mappings/queries appear.
8. Confirm editing the tutorial creates/uses a working copy and does not alter the immutable seed; Reset Example restores the staged seed.
9. Verify materialised colour, blank-production, filled-production and workbook hashes match the canonical `docs/` copies recorded in `PaperBridgeBuiltInExamples.kt`.

### Built-in example visibility

- [ ] On a clean app install, the Paper Bridge **Schema Library** visibly contains **Example — learn Paper Bridge** without importing files.
- [ ] The built-in demo card exposes **Open in Designer** and **Use for scan** actions.
- [ ] Launching `paper.form.design` directly opens the built-in example as an editable copy, with its bundled colour-authoring PNG and standard `survey`/`choices` workbook loaded automatically.
- [ ] The built-in example remains available after custom forms are created or removed.


## Designer full-screen / export regression

- `paper.form.design` opens as a platform-width full-screen dialog and is not constrained by the dashboard capability card.
- The full-screen dialog uses a fixed split: paper viewport = 2/3 of available workspace, survey-field linkage = 1/3. Only the lower linkage pane scrolls; the full-screen root and paper viewport do not.
- The navigation rail is confined to the paper viewport and contains NAV, + BOX, EDIT, +, − and FIT controls.
- Survey-field linkage content is confined to the lower pane and never paints over the paper viewport.
- Selecting a mapped box shows variable name, Paper Bridge/workbook type, required state and the imported regex/range or select choice return values.
- Saving writes a `.paperbridge.json` and marked-up `.mapping.png` under app-private design exports.
- `paper_template_json_uri` resolves through MethodMesh FileProvider and byte content matches `paper_template_json`.
- `paper_design_markup_image` resolves to a PNG showing all linked boxes and mapping labels at source-page coordinates.
- No completed-page image or participant response may be written to the design export directory.

## Legacy bullseye registration regression

- `example_paper_form_for_designer.pdf` remains a legacy bullseye compatibility fixture.
- Legacy target scoring checks dark centre + light annulus + dark outer ring.
- Existing solid-dot/bullseye paper forms remain detectable for backwards compatibility.
- QR4, not bullseye4, is the required default for newly created schemas.

### ML Kit first-stage acquisition

- Normal **Scan page** opens Google ML Kit Document Scanner rather than the raw `TakePicture` camera contract.
- Scanner is constrained to one page, returns JPEG, permits gallery import and uses full scanner mode.
- The returned scanner JPEG is copied into Paper Bridge cache before extraction.
- Schema registration runs on the ML Kit-cropped/deskewed page; for QR4 all four exact schema/corner payloads must decode before OMR/OCR/barcode/image extraction begins.
- If the normal target search fails after ML Kit preprocessing, a wider target-structure-scored corner search is attempted exactly once before returning a registration error.
- The extraction audit records `acquisition_mode=mlkit_document_scanner` for the ML Kit path.
- Cancelling the ML Kit scanner returns cleanly without creating a scan result.
- Failure to launch ML Kit falls back to the basic camera/gallery acquisition path.
- Source/rectified attachment hashing and Commit semantics remain unchanged.

### ML Kit registration separation

- A page returned by ML Kit Document Scanner must not pass through `setPolyToPoly` or any other second perspective warp.
- Detect the four registration target centres, derive the axis-aligned rectangle bounded by the four target centres, crop exactly to that rectangle, and resize to the template dimensions.
- Verify that known control points remain rectangular after ML Kit acquisition; compare against the former double-transform path for visible shear/keystone distortion.
- Do not use the physical paper edge in registration. Content outside the rectangle bounded by the four target centres must be discarded.
- Audit must report `registration_mode=mlkit_anchor_centre_crop_resize` for the ML Kit path and `four_anchor_perspective` for raw/fallback acquisition.


### Anchor-centre coordinate-frame regression
- Scan through ML Kit and verify the rectified preview begins/ends at the four registration-target centres rather than at the physical paper edges.
- Confirm there is no page-edge extrapolation and no `setPolyToPoly` on the ML Kit path.
- Confirm the fallback/raw path maps the four detected target centres to the four canonical output corners.
- Rotate after ML Kit acquisition and verify re-analysis remains in `mlkit_anchor_centre_crop_resize`; it must never switch to the raw four-point path.
- While rotation re-analysis runs, keep the last good preview and mapped ROI overlay visible; replace it only after successful re-registration.
- Confirm the visual designer crops its blank source to the same target-centre rectangle before any ROI is drawn.
- Confirm persisted pre-frame workspace templates are migrated once to `coordinate_frame=anchor_centres`.


## Automatic printed-box detection regression

- Loading a registered blank paper source automatically runs rectangle detection on the **target-centre canonical canvas**, never on the physical page-edge image.
- The bundled blank questionnaire must produce the intended response rectangles, including the image capture ROI: participant ID, visit number, four `eaten_today` boxes, four `symptoms` boxes, temperature, specimen barcode and site-sketch/image capture. Registration targets and ordinary text must not be returned as answer boxes.
- Newly detected boxes without semantic mappings render as numbered `BOX nn · UNLINKED` overlays and remain visible during pan/zoom.
- Importing a survey/choices workbook does not invent geometry. With a plain monochrome authoring form, detected boxes remain unlinked until the operator maps them. With the fixed colour-authoring profile, OCR may propose/high-confidence wire semantics from `survey.label` and `choices.label`.
- Re-running generic box detection must never move or rewrite an existing linked ROI. Geometry changes to an established mapping require explicit EDIT interaction or an explicit colour-analysis pass.
- **AUTO** re-runs detection. It may replace unlinked auto-detected geometry, but must not delete a linked field merely because detection fails.
- **+ BOX** remains available as an explicit manual fallback for non-rectangular/unusual answer regions.
- Box detection must be offline and dependency-free; it must not require network/object-detection model downloads.

## Designer NAV pointer regression

- In **NAV**, only the transform gesture handler receives page pointer gestures. Tap-selection must not run in NAV because `detectTapGestures` can consume the same stream and break pinch/pan.
- Pinch zoom and pan must work immediately after automatic box detection and with many visible overlays.
- **EDIT** owns box tap/move/resize interaction; changing a box never changes the underlying bitmap coordinate frame.

## Colour-authoring validation

- Verify the fixed palette in `README_Colour_Authoring.md` detects each question envelope independently.
- Verify black question text is OCR-matched against `survey.label`, never primarily against the variable `name`.
- Verify blue select-option text is matched against `choices.label` and stores the corresponding `choices.name` return value.
- Verify incompatible types are never auto-matched (for example an orange `select_multiple` envelope to a text field).
- Verify ambiguous label matches remain manual rather than silently selecting a field.
- Verify the production completed form can be monochrome or use unrelated colours: runtime extraction must use only saved ROIs.
- Verify free-text OCR cannot auto-accept even if the general OCR auto-accept setting is enabled.
- Verify the free-text review card displays the cropped registered ROI beside the editable OCR candidate.
- Verify every successful Commit contains nonblank `paper_source_image`, `paper_rectified_image`, their SHA-256 hashes, `paper_attachment_metadata_json`, and `paper_extraction_audit_json`.
- Export a `.paperbridge.zip`, import it on a clean workspace, and confirm the same template ID/version/ROIs/constraints are restored.

## Schema library / tutorial / media checks

- Native Paper Bridge opens with the schema library exposed rather than hiding schemas behind a random active form.
- User schemas are stored as named `.paperbridge.json` files under the module-owned Files area and support new/edit/rename/duplicate/delete workflows; delete requires confirmation.
- The built-in example opens as a staged tutorial: workbook semantics are loaded but response ROIs are initially unresolved; the user must press `AUTO` / `AUTO DETECT + GUESS` to see detections and proposed linkages.
- `image` is accepted in the standard `survey.type` column.
- A `barcode` ROI returns decoded barcode text; an optional blank barcode ROI resolves cleanly as blank, while a required missing or multiply-detected barcode requires review.
- An `image` ROI returns a cropped image attachment URI and does not run OCR/barcode recognition.
- Source scan and registered page remain mandatory attachments on every successful commit.
- `paper_attachment_metadata_json` contains metadata for any field-level image attachments.

- After colour AUTO, unresolved/low-confidence question envelopes render a visible `QUERY n` highlight and their unresolved black response ROIs remain tappable/editable.

## Designer interaction regression checks

- Toolbox is a single minimalist horizontal strip at the top of the canvas; the old left-side vertical palette must not appear.
- Panning/zooming moves an ROI and its label together. Labels must not freeze against a viewport edge or stack because of screen-edge clamping.
- The tutorial `Site sketch / drawing` image field is detected from the lime envelope and can be matched to the workbook image field.
- Designer always exposes the lifecycle bar `SAVE SCHEMA → TEST EMPTY → TEST DATA → FINALISE`; SAVE does not close the editor, tests are gated by the current saved design, and FINALISE is enabled only after both tests for that unchanged design.
- Form Data Linkage shows blocking issue messages directly; canonical `anchor_centres` schemas must not reject an otherwise valid ROI merely for being close to a corner.


## Result delivery / barcode regression checks

- Standalone Commit creates a Paper Bridge ZIP and exports it to the MethodMesh Files/output area; the UI names the saved archive and offers **Open saved files**.
- A failed standalone export leaves the committed result available and offers **Save result ZIP** retry.
- Automatic/external Commit returns through the canonical `onConfirmed` path rather than additionally archiving a standalone copy.
- Result ZIP contains JSON, CSV, schema, audit, attachment metadata, source image, registered image and every nonblank `image` ROI.
- Barcode extraction attempts original ROI, enlargement, high-contrast view and dense transition band before declaring decode failure.
- A visibly nonblank optional barcode ROI must never auto-resolve as blank solely because ML Kit found no code; it becomes a review item with OCR suggestion where possible.
- `example_odk_showcase_paper_form_transcribe.xlsx` declares all seven demo data nodes, `site_sketch`, both full-page images, every stable Paper Bridge metadata/hash/audit field and `methodmesh_full_json`.

## QR4 registration acceptance (current default)

QR4 is the required default for newly created Paper Bridge schemas. Before promotion:

- create a new schema from a blank PNG/PDF that contains no registration marks and verify Paper Bridge generates a distinct 4–11 character schema key plus a `prepared-form.png` containing four QR fiducials;
- verify exact payloads `PB:<key>:TL`, `TR`, `BR`, `BL` are decodable from the four prepared-form corners and include a complete quiet zone;
- verify the imported source artwork remains unchanged and the QR markers exist only on the generated prepared form;
- scan the prepared blank form through ML Kit and verify all four QR markers decode, the audit reports `registration_type=qr4`, and the registered image is the QR-centre-to-centre crop resized once to canonical dimensions;
- scan a completed prepared form at rotation/skew/uneven-light conditions representative of field use and measure ROI alignment error at known control points;
- present a prepared sheet from another Paper Bridge schema and verify the schema-key mismatch fails closed rather than using geometrically plausible wrong markers;
- obscure each QR in turn and verify extraction stops with an explicit missing-corner message;
- duplicate a QR4 schema and verify the duplicate gets a fresh schema key and its prepared form has four new payloads;
- restore a portable bundle and verify its canonical `template.png` is not registered/cropped a second time;
- verify legacy bullseye4 schemas still open and transcribe through the compatibility path.

The bundled colour, blank-production and filled-production tutorial images must use QR4 markers and should be decoded by the same per-corner runtime strategy used on-device.
