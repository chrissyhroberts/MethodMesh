package com.example.methodmesh.modules.signals

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.platform.sensors.PhoneSensorRepository
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

object SignalMorseTransmitCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalMorseTransmitMethod.id
    override val title = "Morse transmitter"
    override val description = "Loop a self-framed Morse beacon over screen, torch or sound so repeated cycles can refine reception."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val activity = remember(androidContext) { androidContext.findActivity() }
        val scope = rememberCoroutineScope()
        val torch = remember(androidContext) { SignalTorchController(androidContext) }
        val settings = context.action.settings

        var payload by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("payload", "SOS")) }
        var route by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("route", "screen")) }
        var wpm by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("wpm", "5").toIntOrNull()?.coerceIn(3, 40) ?: 5) }
        var toneHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("tone_frequency_hz", "700").toFloatOrNull()?.coerceIn(200f, 4000f) ?: 700f) }
        var loopMode by rememberSaveable(context.action.canonicalId) {
            val stored = settings.signalSetting("loop_mode", "continuous")
            mutableStateOf(if (stored == "once") "count" else stored)
        }
        var repeatCount by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("repeat_count", "3").toIntOrNull()?.coerceIn(2, 100) ?: 3) }
        var loopGap by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("loop_gap_units", "10").toIntOrNull()?.coerceIn(3, 60) ?: 10) }

        var sending by remember { mutableStateOf(false) }
        var screenOn by remember { mutableStateOf(false) }
        var currentMark by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var completedCycles by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Ready") }
        var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var cameraGranted by remember { mutableStateOf(hasPermission(androidContext, Manifest.permission.CAMERA)) }
        var transmitJob by remember { mutableStateOf<Job?>(null) }

        val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            cameraGranted = granted || hasPermission(androidContext, Manifest.permission.CAMERA)
            if (!cameraGranted) error = "Camera permission is required for the rear torch route."
        }

        val notation = remember(payload) { MorseCodec.encode(payload) }
        val dotMs = MorseCodec.dotDurationMs(wpm)
        val usesTorch = route in setOf("torch", "torch_sound", "all")
        val usesSound = route in setOf("sound", "screen_sound", "torch_sound", "all")
        val usesScreen = route in setOf("screen", "screen_sound", "all")

        LaunchedEffect(route, wpm) {
            val maxForRoute = if (route == "sound") 40 else 10
            if (wpm > maxForRoute) wpm = maxForRoute
        }

        LaunchedEffect(payload, route, wpm, toneHz, loopMode, repeatCount, loopGap) {
            context.onSettingsChanged(
                mapOf(
                    "payload" to payload,
                    "route" to route,
                    "wpm" to wpm.toString(),
                    "tone_frequency_hz" to toneHz.roundToInt().toString(),
                    "loop_mode" to loopMode,
                    "repeat_count" to repeatCount.toString(),
                    "loop_gap_units" to loopGap.toString()
                )
            )
        }

        LaunchedEffect(Unit) {
            // Physical transmission does not survive Activity recreation. Persist the
            // working configuration/cycle count, but never pretend the emitter is still on.
            screenOn = false
            if (!sending && status.startsWith("Transmitting", ignoreCase = true)) {
                status = if (completedCycles > 0)
                    "Transmission paused after screen recreation; $completedCycles complete cycle(s) retained."
                else
                    "Transmission paused after screen recreation. Start again when ready."
            }
        }

        fun stopTransmission(userRequested: Boolean = true) {
            transmitJob?.cancel()
            transmitJob = null
            torch.off()
            screenOn = false
            currentMark = ""
            sending = false
            if (userRequested) status = if (completedCycles > 0) "Stopped after $completedCycles complete cycle(s)." else "Stopped."
        }

        fun startTransmission() {
            if (payload.isBlank() || notation.isBlank()) {
                error = "Enter at least one Morse-supported character."
                return
            }
            if (usesTorch && !torch.available) {
                error = "No rear-camera flash unit is available on this device."
                return
            }
            if (usesTorch && !cameraGranted) {
                cameraPermission.launch(Manifest.permission.CAMERA)
                return
            }
            stopTransmission(userRequested = false)
            error = ""
            exportStatus = ""
            completedCycles = 0
            sending = true
            status = "Transmitting…"
            val timeline = MorseCodec.timeline(payload, loopGap)
            val maxCycles = if (loopMode == "count") repeatCount.coerceAtLeast(2) else Int.MAX_VALUE
            transmitJob = scope.launch {
                val audioSession = if (usesSound) withContext(Dispatchers.IO) {
                    SignalAudioOutput.openToneSession(toneHz.toDouble())
                } else null
                try {
                    var cycle = 0
                    while (isActive && cycle < maxCycles) {
                        timeline.forEach { element ->
                            if (!isActive) return@forEach
                            when (element) {
                                is MorseCodec.Element.Mark -> {
                                    val duration = dotMs * element.units
                                    currentMark = when (element.kind) {
                                        MorseCodec.MarkKind.PREAMBLE -> "ACQUIRE"
                                        MorseCodec.MarkKind.START -> "START"
                                        MorseCodec.MarkKind.END -> "END"
                                        MorseCodec.MarkKind.DATA -> element.symbol.toString()
                                    }
                                    if (usesScreen) screenOn = true
                                    if (usesTorch) runCatching { torch.set(true) }.onFailure { error = it.message ?: "Torch failed." }
                                    if (audioSession != null) withContext(Dispatchers.IO) { audioSession.mark(duration) } else delay(duration)
                                    if (usesTorch) runCatching { torch.set(false) }
                                    screenOn = false
                                }
                                is MorseCodec.Element.Gap -> {
                                    currentMark = ""
                                    if (usesTorch) runCatching { torch.set(false) }
                                    screenOn = false
                                    val opticalTiming = usesScreen || usesTorch
                                    val gapMultiplier = if (!opticalTiming) 1.0 else when (element.kind) {
                                        MorseCodec.GapKind.ELEMENT -> if (usesTorch) 1.35 else 1.20
                                        MorseCodec.GapKind.LETTER -> if (usesTorch) 1.25 else 1.12
                                        MorseCodec.GapKind.WORD -> if (usesTorch) 1.15 else 1.08
                                        MorseCodec.GapKind.LOOP -> 1.0
                                    }
                                    val duration = (dotMs * element.units * gapMultiplier).roundToInt().toLong().coerceAtLeast(1L)
                                    if (audioSession != null) withContext(Dispatchers.IO) { audioSession.gap(duration) } else delay(duration)
                                }
                            }
                        }
                        cycle++
                        completedCycles = cycle
                        status = if (maxCycles == Int.MAX_VALUE) "Looping — $cycle cycle(s) sent" else "$cycle / $maxCycles cycle(s) sent"
                    }
                } catch (errorValue: Throwable) {
                    if (isActive) error = errorValue.message ?: "Transmission failed."
                } finally {
                    withContext(Dispatchers.IO) { runCatching { audioSession?.close() } }
                    torch.off()
                    screenOn = false
                    currentMark = ""
                    sending = false
                    if (completedCycles > 0 && loopMode != "continuous") status = "Transmission complete."
                }
            }
        }

        fun commit() {
            if (completedCycles <= 0) {
                error = "Complete at least one transmission cycle before Commit."
                return
            }
            stopTransmission(userRequested = false)
            val values = mapOf(
                SignalMorseTransmitFields.RESULT to payload,
                SignalMorseTransmitFields.PAYLOAD to payload,
                SignalMorseTransmitFields.NOTATION to notation,
                SignalMorseTransmitFields.ROUTE to route,
                SignalMorseTransmitFields.WPM to wpm.toString(),
                SignalMorseTransmitFields.REPETITIONS to completedCycles.toString(),
                SignalMorseTransmitFields.STATUS to "sent",
                SignalMorseTransmitFields.ERROR to ""
            )
            committedJson = fieldsJson(values)
            status = "Committed. Live settings remain editable; recommit after another transmission to replace the frozen result."
            val result = signalResult(As100SignalMorseTransmitMethod, context, values)
            if (context.submitsImmediately) onConfirmed(result)
        }

        DisposableEffect(activity, sending, usesScreen) {
            val window = activity?.window
            val previous = window?.attributes?.screenBrightness
            if (window != null && sending && usesScreen) {
                val attributes = window.attributes
                attributes.screenBrightness = 1f
                window.attributes = attributes
            }
            onDispose {
                if (window != null && previous != null) {
                    val attributes = window.attributes
                    attributes.screenBrightness = previous
                    window.attributes = attributes
                }
            }
        }

        DisposableEffect(Unit) { onDispose { stopTransmission(userRequested = false) } }

        val committedFields = fieldsFromJson(committedJson)
        val committedResult = remember(committedJson) {
            committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(As100SignalMorseTransmitMethod, context, it) }
        }
        val committedFullJson = remember(committedJson) { fullJson(committedResult) }

        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SignalInstrumentPanel(
                kicker = "OPTICAL / AUDIO TELEGRAPH",
                title = "Morse beacon",
                accent = SignalAmber,
                badge = if (sending) "On air" else "Standby"
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(2.55f)
                        .background(if (screenOn) Color(0xFFFFFDF5) else SignalBlack, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (sending) currentMark.ifBlank { "·" } else "READY",
                        color = if (screenOn) SignalBlack else SignalAmber,
                        style = MaterialTheme.typography.displayMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    notation.ifBlank { "—" },
                    color = SignalText,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().clickable(enabled = notation.isNotBlank()) {
                        copySignalValue(androidContext, "Morse", notation)
                    }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("DOT", "$dotMs ms", SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("SPEED", "$wpm WPM", SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("CYCLES", completedCycles.toString(), SignalAmber, Modifier.weight(1f))
                }
                Text("Every cycle is self-framing: three acquisition flashes → START → message → END → repeat. Partial pre-START text is quarantined until a bounded cycle proves its alignment.", color = SignalMuted, style = MaterialTheme.typography.labelSmall)
                Text(
                    if (sending) "${route.replace('_', '+')} • ${if (loopMode == "continuous") "continuous beacon" else "transmitting"}" else status,
                    color = SignalMuted,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (sending) stopTransmission() else startTransmission() }, modifier = Modifier.weight(1f)) {
                    Text(if (sending) "Stop" else "Start looping beacon")
                }
                Button(onClick = ::commit, enabled = completedCycles > 0, modifier = Modifier.weight(1f)) {
                    Text(if (committedResult == null) "Commit" else "Recommit")
                }
            }

            if (committedResult != null && !context.submitsImmediately) {
                SignalCommittedCard(
                    title = "Committed transmission",
                    primaryLabel = "message",
                    primaryValue = committedFields[SignalMorseTransmitFields.RESULT].orEmpty(),
                    fields = listOf(
                        "Morse" to committedFields[SignalMorseTransmitFields.NOTATION].orEmpty(),
                        "Route" to committedFields[SignalMorseTransmitFields.ROUTE].orEmpty(),
                        "WPM" to committedFields[SignalMorseTransmitFields.WPM].orEmpty(),
                        "Cycles" to committedFields[SignalMorseTransmitFields.REPETITIONS].orEmpty()
                    ),
                    status = exportStatus,
                    onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                    onShare = { exportStatus = shareSignalText(androidContext, "Share Morse message", committedFields[SignalMorseTransmitFields.RESULT].orEmpty()) ?: "" },
                    onSave = { exportStatus = saveSignalText(androidContext, "morse_transmission", committedFields[SignalMorseTransmitFields.RESULT].orEmpty(), committedFullJson) },
                    onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, "morse_transmission", committedFields[SignalMorseTransmitFields.RESULT].orEmpty(), committedFullJson) } }
                )
            }

            MorseTransmitSettings(
                context = context,
                sending = sending,
                payload = payload,
                onPayload = { next -> if (next != payload) { payload = next; completedCycles = 0 } },
                route = route,
                onRoute = { next ->
                    if (next != route) {
                        route = next
                        val maxForRoute = if (next == "sound") 40 else 10
                        if (wpm > maxForRoute) wpm = maxForRoute
                        completedCycles = 0
                    }
                },
                wpm = wpm,
                onWpm = { next -> if (next != wpm) { wpm = next; completedCycles = 0 } },
                toneHz = toneHz,
                onToneHz = { next -> if (next != toneHz) { toneHz = next; completedCycles = 0 } },
                loopMode = loopMode,
                onLoopMode = { next -> if (next != loopMode) { loopMode = next; completedCycles = 0 } },
                repeatCount = repeatCount,
                onRepeatCount = { next -> if (next != repeatCount) { repeatCount = next; completedCycles = 0 } },
                loopGap = loopGap,
                onLoopGap = { next -> if (next != loopGap) { loopGap = next; completedCycles = 0 } }
            )

            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (committedResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            }
        }

        if (usesScreen && sending) {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false,
                    usePlatformDefaultWidth = false,
                    decorFitsSystemWindows = false
                )
            ) {
                Box(
                    modifier = Modifier.fillMaxSize().background(if (screenOn) Color.White else Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        currentMark.ifBlank { " " },
                        color = if (screenOn) Color.Black else Color.White,
                        style = MaterialTheme.typography.displayLarge,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black
                    )
                    Button(
                        onClick = { stopTransmission() },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp)
                    ) { Text("Stop") }
                }
            }
        }
    }
}

@Composable
private fun MorseTransmitSettings(
    sending: Boolean,
    context: CapabilityScreenContext,
    payload: String,
    onPayload: (String) -> Unit,
    route: String,
    onRoute: (String) -> Unit,
    wpm: Int,
    onWpm: (Int) -> Unit,
    toneHz: Float,
    onToneHz: (Float) -> Unit,
    loopMode: String,
    onLoopMode: (String) -> Unit,
    repeatCount: Int,
    onRepeatCount: (Int) -> Unit,
    loopGap: Int,
    onLoopGap: (Int) -> Unit
) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Message & channel", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (context.settingShouldBeShown("payload")) {
                OutlinedTextField(payload, onPayload, enabled = !sending, modifier = Modifier.fillMaxWidth(), label = { Text("Message") }, supportingText = { Text("Unsupported characters are skipped by the Morse encoder.") })
            }
            if (context.settingShouldBeShown("route")) {
                Text("Output")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("screen", "torch", "sound").forEach { item ->
                        FilterChip(selected = route == item, enabled = !sending, onClick = { onRoute(item) }, label = { Text(item.replaceFirstChar { it.uppercase() }) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("screen_sound", "torch_sound", "all").forEach { item ->
                        FilterChip(selected = route == item, enabled = !sending, onClick = { onRoute(item) }, label = { Text(item.replace('_', '+')) })
                    }
                }
            }
            if (context.settingShouldBeShown("wpm")) {
                val opticalOutput = route != "sound"
                val maxWpm = if (opticalOutput) 10 else 40
                Text("Speed: $wpm WPM")
                Text(
                    if (opticalOutput) "Optical routes are capped at 10 WPM; 5 WPM is the reliable starting point for camera decoding."
                    else "Audio can run faster because the microphone detector has much finer timing than camera frames.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    (if (opticalOutput) listOf(5, 8, 10) else listOf(12, 20, 30, 40)).forEach { preset ->
                        FilterChip(selected = wpm == preset, enabled = !sending, onClick = { onWpm(preset) }, label = { Text("$preset") })
                    }
                }
                Slider(
                    wpm.coerceAtMost(maxWpm).toFloat(),
                    { onWpm(it.roundToInt().coerceIn(3, maxWpm)) },
                    enabled = !sending,
                    valueRange = 3f..maxWpm.toFloat(),
                    steps = (maxWpm - 4).coerceAtLeast(0)
                )
            }
            if (context.settingShouldBeShown("tone_frequency_hz") && route.contains("sound")) {
                Text("Tone: ${toneHz.roundToInt()} Hz")
                Slider(toneHz, { onToneHz((it / 10f).roundToInt() * 10f) }, enabled = !sending, valueRange = 200f..4000f)
            }
            if (context.settingShouldBeShown("loop_mode")) {
                Text("Repeat")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("count", "continuous").forEach { item ->
                        FilterChip(selected = loopMode == item, enabled = !sending, onClick = { onLoopMode(item) }, label = { Text(item.replaceFirstChar { it.uppercase() }) })
                    }
                }
            }
            if (loopMode == "count" && context.settingShouldBeShown("repeat_count")) {
                Text("Cycles: $repeatCount")
                Slider(repeatCount.coerceAtLeast(2).toFloat(), { onRepeatCount(it.roundToInt().coerceIn(2, 100)) }, enabled = !sending, valueRange = 2f..100f, steps = 97)
            }
            if (context.settingShouldBeShown("loop_gap_units")) {
                Text("Gap between cycles: $loopGap units")
                Slider(loopGap.toFloat(), { onLoopGap(it.roundToInt().coerceIn(3, 60)) }, enabled = !sending, valueRange = 3f..60f)
            }
        }
    }
}

object SignalMorseReceiveCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100SignalMorseReceiveMethod.id
    override val title = "Morse receiver"
    override val description = "Decode Morse from light, camera brightness or an audible tone."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val androidContext = LocalContext.current
        val settings = context.action.settings
        var source by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("source", "camera")) }
        var dotMsSetting by rememberSaveable(context.action.canonicalId) {
            val defaultDot = if (source == "microphone") 60L else 240L
            mutableStateOf(settings.signalSetting("dot_ms", defaultDot.toString()).toLongOrNull()?.coerceIn(30, 1000) ?: defaultDot)
        }
        var autoTiming by rememberSaveable(context.action.canonicalId) {
            val defaultAuto = if (source == "microphone") "true" else "false"
            mutableStateOf(settings.signalSetting("auto_timing", defaultAuto).toBooleanStrictOrNull() ?: (source == "microphone"))
        }
        var opticalProfile by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("optical_profile", "screen")) }
        var toneHz by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("microphone_tone_hz", "700").toDoubleOrNull()?.coerceIn(100.0, 10000.0) ?: 700.0) }
        var toneTolerance by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("microphone_tolerance_hz", "120").toDoubleOrNull()?.coerceIn(10.0, 2000.0) ?: 120.0) }
        var minDbfs by rememberSaveable(context.action.canonicalId) { mutableStateOf(settings.signalSetting("microphone_min_dbfs", "-35").toDoubleOrNull()?.coerceIn(-90.0, 0.0) ?: -35.0) }
        var listening by remember { mutableStateOf(false) }
        var status by rememberSaveable(context.action.canonicalId) { mutableStateOf("Choose a receiver and start listening.") }
        var error by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var levelText by remember { mutableStateOf("—") }
        var levelOn by remember { mutableStateOf(false) }
        var decodedText by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var currentSymbols by remember { mutableStateOf("") }
        var effectiveDotMs by rememberSaveable(context.action.canonicalId) { mutableStateOf(dotMsSetting) }
        var pulsesSeen by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var consensusCopies by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var consensusConfidence by rememberSaveable(context.action.canonicalId) { mutableStateOf(0.0) }
        var framedSignal by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var frameState by remember { mutableStateOf(MorseTimingDecoder.FrameState.SEEKING_START) }
        var orphanObservations by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var unanimousCharacters by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var consensusCharacters by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var committedJson by rememberSaveable(context.action.canonicalId) { mutableStateOf<String?>(null) }
        var exportStatus by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
        var cameraGranted by remember { mutableStateOf(hasPermission(androidContext, Manifest.permission.CAMERA)) }
        var audioGranted by remember { mutableStateOf(hasPermission(androidContext, Manifest.permission.RECORD_AUDIO)) }
        var cameraZoom by rememberSaveable(context.action.canonicalId) { mutableStateOf(1f) }
        var cameraActualZoom by remember { mutableStateOf(1f) }
        var cameraMaxZoom by remember { mutableStateOf(4f) }
        var cameraRoiMode by rememberSaveable(context.action.canonicalId) { mutableStateOf(SignalCameraRoiMode.FOCUS.name) }
        var cameraRoiX by rememberSaveable(context.action.canonicalId) { mutableStateOf(0.5f) }
        var cameraRoiY by rememberSaveable(context.action.canonicalId) { mutableStateOf(0.5f) }
        var cameraAutoLock by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
        var cameraSearchGeneration by rememberSaveable(context.action.canonicalId) { mutableStateOf(0) }
        var cameraLockState by remember { mutableStateOf(SignalCameraLockState.MANUAL) }
        var cameraLockConfidence by remember { mutableStateOf(0.0) }

        val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { cameraGranted = it || hasPermission(androidContext, Manifest.permission.CAMERA) }
        val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioGranted = it || hasPermission(androidContext, Manifest.permission.RECORD_AUDIO) }

        val decoder = remember(dotMsSetting, autoTiming, source) {
            val optical = source != "microphone"
            MorseTimingDecoder(
                initialDotMs = dotMsSetting,
                autoTiming = autoTiming,
                minimumDotMs = if (optical) 120L else 30L,
                maximumDotMs = 1000L
            )
        }
        val lightDetector = remember { AdaptiveLevelDetector(minimumSpan = 1.0) }
        val cameraDetector = remember { AdaptiveLevelDetector(minimumSpan = 14.0) }
        val cameraStableGate = remember(opticalProfile) { MorseStableSignalGate(if (opticalProfile == "torch") 3 else 2) }
        val microphoneEngine = remember(androidContext) { SignalToneReceiverEngine(androidContext) }

        fun acceptSignal(on: Boolean, timestampMs: Long) {
            if (!listening) return
            levelOn = on
            val snapshot = decoder.update(on, timestampMs)
            decodedText = snapshot.decodedText
            currentSymbols = snapshot.currentSymbols
            effectiveDotMs = snapshot.dotMs
            pulsesSeen = snapshot.pulsesSeen
            consensusCopies = snapshot.completedCopies
            consensusConfidence = snapshot.consensusConfidence
            framedSignal = snapshot.framed
            frameState = snapshot.frameState
            orphanObservations = snapshot.orphanObservations
            unanimousCharacters = snapshot.unanimousCharacters
            consensusCharacters = snapshot.characterCount
            status = snapshot.quality
        }

        fun invalidateWorkingReception() {
            decodedText = ""
            currentSymbols = ""
            effectiveDotMs = dotMsSetting
            pulsesSeen = 0
            consensusCopies = 0
            consensusConfidence = 0.0
            framedSignal = false
            frameState = MorseTimingDecoder.FrameState.SEEKING_START
            orphanObservations = 0
            unanimousCharacters = 0
            consensusCharacters = 0
            cameraStableGate.reset()
            levelOn = false
            levelText = "—"
            status = "Receiver settings changed; working decode was cleared. Any committed result remains frozen."
            error = ""
        }

        fun restartCameraWorkingReception(message: String) {
            cameraDetector.reset()
            decoder.reset(System.currentTimeMillis())
            decodedText = ""
            currentSymbols = ""
            effectiveDotMs = dotMsSetting
            pulsesSeen = 0
            consensusCopies = 0
            consensusConfidence = 0.0
            framedSignal = false
            frameState = MorseTimingDecoder.FrameState.SEEKING_START
            orphanObservations = 0
            unanimousCharacters = 0
            consensusCharacters = 0
            cameraStableGate.reset()
            levelOn = false
            levelText = "—"
            if (listening && source == "camera") status = message
            error = ""
        }

        fun startCameraSearch() {
            cameraAutoLock = true
            cameraSearchGeneration += 1
            cameraLockState = SignalCameraLockState.SEARCHING
            cameraLockConfidence = 0.0
            restartCameraWorkingReception("Searching the frame for a flashing source…")
        }

        fun setManualCameraRoi(x: Float, y: Float) {
            cameraAutoLock = false
            cameraLockState = SignalCameraLockState.MANUAL
            cameraRoiX = x.coerceIn(0f, 1f)
            cameraRoiY = y.coerceIn(0f, 1f)
            restartCameraWorkingReception("ROI moved. Listening restarted at the selected point.")
        }

        fun startListening() {
            error = ""
            if (source == "camera" && !cameraGranted) {
                cameraPermission.launch(Manifest.permission.CAMERA)
                return
            }
            if (source == "microphone" && !audioGranted) {
                audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                return
            }
            decoder.reset(System.currentTimeMillis())
            lightDetector.reset()
            cameraDetector.reset()
            decodedText = ""
            currentSymbols = ""
            pulsesSeen = 0
            consensusCopies = 0
            consensusConfidence = 0.0
            framedSignal = false
            frameState = MorseTimingDecoder.FrameState.SEEKING_START
            orphanObservations = 0
            unanimousCharacters = 0
            consensusCharacters = 0
            cameraStableGate.reset()
            effectiveDotMs = dotMsSetting
            listening = true
            status = "Listening…"
            if (source == "microphone") {
                microphoneEngine.start(
                    toneHz = toneHz,
                    toleranceHz = toneTolerance,
                    minimumDbfs = minDbfs,
                    onWindow = { window ->
                        levelText = "${toneHz.roundToInt()} Hz  ${"%.1f".format(Locale.US, window.dbfs)} dBFS  ${window.audioSource}"
                        acceptSignal(window.isOn, window.timestampMs)
                    },
                    onError = { error = it; listening = false }
                )
            }
        }

        fun stopListening() {
            if (source == "microphone") microphoneEngine.stop()
            val snapshot = decoder.flush(System.currentTimeMillis())
            decodedText = snapshot.decodedText
            currentSymbols = snapshot.currentSymbols
            effectiveDotMs = snapshot.dotMs
            pulsesSeen = snapshot.pulsesSeen
            consensusCopies = snapshot.completedCopies
            consensusConfidence = snapshot.consensusConfidence
            framedSignal = snapshot.framed
            frameState = snapshot.frameState
            orphanObservations = snapshot.orphanObservations
            unanimousCharacters = snapshot.unanimousCharacters
            consensusCharacters = snapshot.characterCount
            listening = false
            levelOn = false
            status = when {
                consensusCopies > 0 -> "Stopped — bounded consensus is ready to Commit."
                decodedText.isNotBlank() -> "Stopped — only an incomplete START-anchored copy was seen; no canonical result yet."
                else -> "Stopped — no complete START→END Morse cycle decoded."
            }
        }

        fun commit() {
            if (decodedText.isBlank() || consensusCopies <= 0) {
                error = "Wait for at least one complete START→END cycle before Commit. Partial/orphan text is deliberately not committable."
                return
            }
            if (listening) stopListening()
            val notation = MorseCodec.encode(decodedText)
            val values = mapOf(
                SignalMorseReceiveFields.RESULT to decodedText,
                SignalMorseReceiveFields.NOTATION to notation,
                SignalMorseReceiveFields.SOURCE to source,
                SignalMorseReceiveFields.DOT_MS to effectiveDotMs.toString(),
                SignalMorseReceiveFields.TRANSITIONS to pulsesSeen.toString(),
                SignalMorseReceiveFields.COPIES to consensusCopies.toString(),
                SignalMorseReceiveFields.CONSENSUS_CONFIDENCE to String.format(Locale.US, "%.4f", consensusConfidence),
                SignalMorseReceiveFields.STATUS to "received",
                SignalMorseReceiveFields.ERROR to ""
            )
            committedJson = fieldsJson(values)
            status = "Committed. Continue listening only after starting a new reception."
            val result = signalResult(As100SignalMorseReceiveMethod, context, values)
            if (context.submitsImmediately) onConfirmed(result)
        }

        LaunchedEffect(source, dotMsSetting) {
            if (source != "microphone" && dotMsSetting < 120L) dotMsSetting = 120L
        }

        LaunchedEffect(source, dotMsSetting, autoTiming, opticalProfile, toneHz, toneTolerance, minDbfs) {
            context.onSettingsChanged(
                mapOf(
                    "source" to source,
                    "dot_ms" to dotMsSetting.toString(),
                    "auto_timing" to autoTiming.toString(),
                    "optical_profile" to opticalProfile,
                    "microphone_tone_hz" to toneHz.roundToInt().toString(),
                    "microphone_tolerance_hz" to toneTolerance.roundToInt().toString(),
                    "microphone_min_dbfs" to minDbfs.toString()
                )
            )
        }

        LaunchedEffect(Unit) {
            // Camera/microphone/listener registrations are process objects, not saved UI
            // state. Preserve decoded working text but require an explicit restart.
            if (!listening && (status.startsWith("Listening", ignoreCase = true) || status.startsWith("Tracking", ignoreCase = true))) {
                status = if (decodedText.isBlank())
                    "Reception paused after screen recreation. Start listening again."
                else
                    "Reception paused after screen recreation; decoded working text is retained."
            }
        }

        DisposableEffect(androidContext) {
            PhoneSensorRepository.start(androidContext)
            onDispose {
                microphoneEngine.stop()
                PhoneSensorRepository.stop()
            }
        }

        val lux = PhoneSensorRepository.readings["light"]?.values?.firstOrNull()?.toDouble()
        LaunchedEffect(lux, listening, source) {
            if (listening && source == "light_sensor" && lux != null) {
                val detection = lightDetector.feed(lux)
                levelText = "${"%.1f".format(Locale.US, lux)} lx • span ${"%.1f".format(Locale.US, detection.span.takeIf { it.isFinite() } ?: 0.0)}"
                detection.state?.let { acceptSignal(it, System.currentTimeMillis()) }
            }
        }

        val committedFields = fieldsFromJson(committedJson)
        val committedResult = remember(committedJson) { committedFields.takeIf { it.isNotEmpty() }?.let { signalResult(As100SignalMorseReceiveMethod, context, it) } }
        val committedFullJson = remember(committedJson) { fullJson(committedResult) }

        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SignalInstrumentPanel(
                kicker = "ADAPTIVE TELEGRAPH DECODER",
                title = "Morse receiver",
                accent = SignalAmber,
                badge = if (levelOn) "Signal" else if (listening) "Listening" else "Quiet"
            ) {
                Text(
                    decodedText.ifBlank { "WAITING FOR MESSAGE" },
                    modifier = Modifier.fillMaxWidth().clickable(enabled = decodedText.isNotBlank()) {
                        copySignalValue(androidContext, "decoded Morse", decodedText)
                    },
                    color = if (decodedText.isBlank()) SignalMuted else SignalText,
                    style = MaterialTheme.typography.headlineMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    if (currentSymbols.isBlank()) "· · ·" else currentSymbols,
                    color = SignalAmber,
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Monospace
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("SOURCE", source.replace('_', ' '), SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("DOT", "~${effectiveDotMs} ms", SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("CYCLES", consensusCopies.toString(), SignalAmber, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SignalTelemetryTile("BEST GUESS", if (consensusCopies > 0) "${(consensusConfidence * 100).roundToInt()}%" else "acquiring", SignalGreen, Modifier.weight(1f))
                    SignalTelemetryTile("FRAME", when (frameState) {
                        MorseTimingDecoder.FrameState.SEEKING_START -> "seeking"
                        MorseTimingDecoder.FrameState.IN_FRAME -> "START→…"
                        MorseTimingDecoder.FrameState.HAVE_COMPLETE_FRAME -> "bounded"
                    }, SignalAmber, Modifier.weight(1f))
                    SignalTelemetryTile("MARKS", pulsesSeen.toString(), SignalAmber, Modifier.weight(1f))
                }
                Text(levelText, color = SignalMuted, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                if (consensusCopies > 0) {
                    Text("$unanimousCharacters/$consensusCharacters characters unanimous • $orphanObservations END-anchored orphan observation(s)", color = SignalMuted, style = MaterialTheme.typography.labelSmall)
                } else if (orphanObservations > 0) {
                    Text("Orphan suffix buffered but excluded from the best guess until a complete START→END cycle is seen.", color = SignalMuted, style = MaterialTheme.typography.labelSmall)
                }
            }

            if (source == "camera" && listening && cameraGranted) {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = SignalBlack)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(Modifier.fillMaxWidth().height(290.dp)) {
                            SignalCameraLumaPreview(
                                zoomRatio = cameraZoom,
                                roiMode = runCatching { SignalCameraRoiMode.valueOf(cameraRoiMode) }.getOrDefault(SignalCameraRoiMode.FOCUS),
                                roiCenterX = cameraRoiX,
                                roiCenterY = cameraRoiY,
                                autoLock = cameraAutoLock,
                                lockState = cameraLockState,
                                searchGeneration = cameraSearchGeneration,
                                exposureReduction = if (opticalProfile == "torch") 0.55f else 0.25f,
                                opticalProfile = opticalProfile,
                                onRoiMoved = { x, y -> setManualCameraRoi(x, y) },
                                onCameraInfo = { info ->
                                    cameraActualZoom = info.actualZoomRatio
                                    cameraMaxZoom = info.maxZoomRatio.coerceAtLeast(1f)
                                },
                                onSample = sampleLoop@ { sample ->
                                    val previousLock = cameraLockState
                                    cameraLockState = sample.lockState
                                    cameraLockConfidence = sample.lockConfidence
                                    if (cameraAutoLock && sample.lockState == SignalCameraLockState.LOCKED) {
                                        cameraRoiX = sample.roiCenterX
                                        cameraRoiY = sample.roiCenterY
                                    }
                                    if (cameraAutoLock && sample.lockState != SignalCameraLockState.LOCKED) {
                                        levelOn = false
                                        levelText = when (sample.lockState) {
                                            SignalCameraLockState.LOST -> "lock lost • reacquiring"
                                            else -> "searching • modulation ${"%.1f".format(Locale.US, sample.modulationScore)}"
                                        }
                                        return@sampleLoop
                                    }
                                    if (cameraAutoLock && previousLock != SignalCameraLockState.LOCKED && sample.lockState == SignalCameraLockState.LOCKED) {
                                        cameraDetector.reset()
                                        cameraStableGate.reset()
                                        decoder.reset(sample.timestampMs)
                                        decodedText = ""
                                        currentSymbols = ""
                                        pulsesSeen = 0
                                        effectiveDotMs = dotMsSetting
                                    }
                                    val detection = cameraDetector.feed(sample.luma)
                                    levelText = "luma ${"%.0f".format(Locale.US, sample.luma)} • span ${"%.0f".format(Locale.US, detection.span.takeIf { it.isFinite() } ?: 0.0)}"
                                    detection.state?.let { rawState ->
                                        cameraStableGate.feed(rawState)?.let { stableState -> acceptSignal(stableState, sample.timestampMs) }
                                    }
                                },
                                onError = { error = it; listening = false }
                            )
                        }

                        Column(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("OPTICAL FRONT END", color = SignalAmber, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                Text("${"%.1f".format(Locale.US, cameraActualZoom)}×", color = SignalText, fontFamily = FontFamily.Monospace)
                            }
                            if (context.settingShouldBeShown("optical_profile")) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf("screen" to "Screen", "torch" to "Torch / point").forEach { (id, label) ->
                                        FilterChip(
                                            selected = opticalProfile == id,
                                            onClick = {
                                                if (opticalProfile != id) {
                                                    opticalProfile = id
                                                    if (id == "torch") cameraRoiMode = SignalCameraRoiMode.PINPOINT.name
                                                    cameraStableGate.reset()
                                                    restartCameraWorkingReception("$label optical profile selected. Exposure and edge filtering restarted.")
                                                }
                                            },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }
                            Text(
                                if (opticalProfile == "screen") "Screen mode underexposes slightly and requires 2 stable frames, rejecting rolling-shutter swipe transitions."
                                else "Torch mode underexposes more, uses a small ROI and requires 3 stable frames so flare decay does not become extra edges.",
                                color = SignalMuted,
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(1f to "1×", 2f to "2×", 4f to "4×", cameraMaxZoom to "Max").forEach { (target, label) ->
                                    val effective = target.coerceAtMost(cameraMaxZoom).coerceAtLeast(1f)
                                    FilterChip(
                                        selected = abs(cameraZoom - effective) < 0.15f,
                                        onClick = {
                                            cameraZoom = effective
                                            restartCameraWorkingReception("Zoom changed. Camera decode restarted.")
                                        },
                                        enabled = cameraMaxZoom > 1.01f,
                                        label = { Text(label) }
                                    )
                                }
                            }
                            Text("Analysis ROI", color = SignalMuted, style = MaterialTheme.typography.labelMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                SignalCameraRoiMode.values().forEach { mode ->
                                    FilterChip(
                                        selected = cameraRoiMode == mode.name,
                                        onClick = {
                                            cameraRoiMode = mode.name
                                            restartCameraWorkingReception("${mode.label} ROI selected. Camera decode restarted.")
                                        },
                                        label = { Text(mode.label) }
                                    )
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = ::startCameraSearch, modifier = Modifier.weight(1f)) {
                                    Text(if (cameraAutoLock && cameraLockState == SignalCameraLockState.LOCKED) "Reacquire" else "Find signal")
                                }
                                OutlinedButton(
                                    onClick = {
                                        cameraAutoLock = false
                                        cameraLockState = SignalCameraLockState.MANUAL
                                        restartCameraWorkingReception("Manual ROI active. Tap the preview to move it.")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) { Text("Manual ROI") }
                            }
                            val lockLabel = when (cameraLockState) {
                                SignalCameraLockState.LOCKED -> "LOCKED  ${"%.2f".format(Locale.US, cameraLockConfidence)}× contrast over next candidate"
                                SignalCameraLockState.SEARCHING -> "SEARCHING FOR TEMPORAL MODULATION"
                                SignalCameraLockState.LOST -> "LOCK LOST • LOCAL REACQUISITION"
                                SignalCameraLockState.MANUAL -> "MANUAL ROI • TAP PREVIEW TO POSITION"
                            }
                            Text(lockLabel, color = when (cameraLockState) {
                                SignalCameraLockState.LOCKED -> SignalGreen
                                SignalCameraLockState.LOST -> SignalRed
                                else -> SignalAmber
                            }, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (listening) stopListening() else startListening() }, modifier = Modifier.weight(1f)) { Text(if (listening) "Stop" else "Start listening") }
                Button(onClick = ::commit, enabled = decodedText.isNotBlank() && consensusCopies > 0, modifier = Modifier.weight(1f)) { Text(if (committedResult == null) "Commit" else "Recommit") }
            }

            if (committedResult != null && !context.submitsImmediately) {
                SignalCommittedCard(
                    title = "Committed reception",
                    primaryLabel = "decoded text",
                    primaryValue = committedFields[SignalMorseReceiveFields.RESULT].orEmpty(),
                    fields = listOf(
                        "Morse" to committedFields[SignalMorseReceiveFields.NOTATION].orEmpty(),
                        "Source" to committedFields[SignalMorseReceiveFields.SOURCE].orEmpty(),
                        "Dot ms" to committedFields[SignalMorseReceiveFields.DOT_MS].orEmpty(),
                        "Marks" to committedFields[SignalMorseReceiveFields.TRANSITIONS].orEmpty()
                    ),
                    status = exportStatus,
                    onCopy = { label, value -> copySignalValue(androidContext, label, value) },
                    onShare = { exportStatus = shareSignalText(androidContext, "Share decoded Morse", committedFields[SignalMorseReceiveFields.RESULT].orEmpty()) ?: "" },
                    onSave = { exportStatus = saveSignalText(androidContext, "morse_reception", committedFields[SignalMorseReceiveFields.RESULT].orEmpty(), committedFullJson) },
                    onDone = { finishSignalResult(context, androidContext, committedResult, onConfirmed) { saveSignalText(androidContext, "morse_reception", committedFields[SignalMorseReceiveFields.RESULT].orEmpty(), committedFullJson) } }
                )
            }

            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Receiver", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (context.settingShouldBeShown("source")) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val nativeSources = buildList {
                                if (source == "light_sensor") add("light_sensor" to "Lux · legacy")
                                add("camera" to "Camera")
                                add("microphone" to "Mic")
                            }
                            nativeSources.forEach { (id, label) ->
                                FilterChip(selected = source == id, enabled = !listening, onClick = {
                                    if (source != id) {
                                        source = id
                                        if (id != "microphone" && dotMsSetting < 120L) dotMsSetting = 240L
                                        autoTiming = id == "microphone"
                                        invalidateWorkingReception()
                                    }
                                }, label = { Text(label) })
                            }
                        }
                    }
                    if (context.settingShouldBeShown("dot_ms")) {
                        val startingWpm = (1200.0 / dotMsSetting.toDouble()).roundToInt().coerceAtLeast(1)
                        Text("Starting speed: ~$startingWpm WPM  ·  $dotMsSetting ms dot")
                        Text("PARIS timing uses dot = 1200 / WPM. With Auto timing on, this is only the starting estimate.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val opticalSource = source != "microphone"
                        val minimumDot = if (opticalSource) 120L else 30L
                        Text(
                            if (opticalSource) "Camera/light timing is capped at 10 WPM (≥120 ms dot); 5 WPM is recommended."
                            else "Audio timing supports up to 40 WPM (30 ms dot).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (if (opticalSource) listOf(5, 8, 10) else listOf(12, 20, 30, 40)).forEach { wpm ->
                                val ms = (1200.0 / wpm).roundToInt().toLong()
                                FilterChip(selected = kotlin.math.abs(dotMsSetting - ms) <= 5, enabled = !listening, onClick = { if (dotMsSetting != ms) { dotMsSetting = ms; invalidateWorkingReception() } }, label = { Text("$wpm WPM") })
                            }
                        }
                        Slider(dotMsSetting.coerceAtLeast(minimumDot).toFloat(), { next -> val snapped = ((next.roundToInt() / 10) * 10).coerceIn(minimumDot.toInt(), 1000).toLong(); if (snapped != dotMsSetting) { dotMsSetting = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = minimumDot.toFloat()..1000f)
                    }
                    if (source == "camera") {
                        Text("Optical timing is most reliable locked to the sender speed; 5 WPM is the default test profile. Auto timing is optional because rolling shutter and torch decay bias ON and OFF durations differently.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (context.settingShouldBeShown("auto_timing")) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Auto timing"); Text("Adapt to sender speed", style = MaterialTheme.typography.bodySmall) }
                            Switch(autoTiming, { next -> if (next != autoTiming) { autoTiming = next; invalidateWorkingReception() } }, enabled = !listening)
                        }
                    }
                    if (source == "microphone") {
                        if (context.settingShouldBeShown("microphone_tone_hz")) {
                            Text("Tone: ${toneHz.roundToInt()} Hz")
                            Slider(toneHz.toFloat(), { next -> val snapped = ((next.roundToInt() / 10) * 10).coerceIn(100, 10000).toDouble(); if (snapped != toneHz) { toneHz = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = 100f..10000f)
                        }
                        if (context.settingShouldBeShown("microphone_tolerance_hz")) {
                            Text("Tolerance: ±${toneTolerance.roundToInt()} Hz")
                            Slider(toneTolerance.toFloat(), { next -> val snapped = ((next.roundToInt() / 10) * 10).coerceIn(10, 2000).toDouble(); if (snapped != toneTolerance) { toneTolerance = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = 10f..2000f)
                        }
                        if (context.settingShouldBeShown("microphone_min_dbfs")) {
                            Text("Minimum level: ${"%.0f".format(Locale.US, minDbfs)} dBFS")
                            Slider(minDbfs.toFloat(), { next -> val snapped = next.roundToInt().coerceIn(-90, 0).toDouble(); if (snapped != minDbfs) { minDbfs = snapped; invalidateWorkingReception() } }, enabled = !listening, valueRange = -90f..0f)
                        }
                    }
                }
            }

            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (committedResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (context.stepNumber > 1) OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Back") }
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) { Text("Cancel") }
                }
            }
        }
    }
}

private fun hasPermission(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

private fun Context.findActivity(): Activity? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}
