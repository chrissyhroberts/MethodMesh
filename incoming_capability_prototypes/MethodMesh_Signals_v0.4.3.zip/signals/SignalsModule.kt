package com.example.methodmesh.modules.signals

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object SignalsModule : MethodMeshModule {
    override val moduleId = "signals"
    override val displayName = "Signals"
    override val summary = "Observe, encode, transmit and recover checksum-verified messages and files over optical, acoustic and shared-surface links, with live diagnostics for lossy physical channels."
    override val iconKey = "hardware"


    override fun as100Methods() = listOf(
        As100SignalMorseTransmitMethod,
        As100SignalMorseReceiveMethod,
        As100SignalQrTransmitMethod,
        As100SignalQrReceiveMethod,
        As100SignalFskTransmitMethod,
        As100SignalFskReceiveMethod,
        As100SignalUltrasonicTransmitMethod,
        As100SignalUltrasonicReceiveMethod,
        As100SignalSurfaceTransmitMethod,
        As100SignalSurfaceReceiveMethod,
        As100SignalSensorScopeMethod
    )

    override fun rilBindings() = listOf(
        RilBinding("transmit morse", As100SignalMorseTransmitMethod.id, "Send text as Morse over screen, torch and/or sound"),
        RilBinding("receive morse", As100SignalMorseReceiveMethod.id, "Decode Morse from light, camera or microphone"),
        RilBinding("transmit qr burst", As100SignalQrTransmitMethod.id, "Loop an error-corrected message as QR frames"),
        RilBinding("receive qr burst", As100SignalQrReceiveMethod.id, "Recover an error-corrected message from QR frames"),
        RilBinding("transmit audio fsk", As100SignalFskTransmitMethod.id, "Send a small error-corrected packet through sound or a radio audio path"),
        RilBinding("receive audio fsk", As100SignalFskReceiveMethod.id, "Decode a packet from audible FSK"),
        RilBinding("transmit near ultrasonic", As100SignalUltrasonicTransmitMethod.id, "Experimentally send data using high-frequency phone audio"),
        RilBinding("receive near ultrasonic", As100SignalUltrasonicReceiveMethod.id, "Experimentally receive high-frequency phone audio data"),
        RilBinding("transmit tabletop signal", As100SignalSurfaceTransmitMethod.id, "Send a packet through a shared table, box or rail"),
        RilBinding("receive tabletop signal", As100SignalSurfaceReceiveMethod.id, "Recover a packet from shared-surface vibration"),
        RilBinding("inspect signal sensor", As100SignalSensorScopeMethod.id, "Inspect light, magnetic, motion, pressure and proximity sensors")
    )

    override fun capabilityScreens() = listOf(
        SignalMorseTransmitCapabilityScreen,
        SignalMorseReceiveCapabilityScreen,
        SignalQrTransmitCapabilityScreen,
        SignalQrReceiveCapabilityScreen,
        SignalFskTransmitCapabilityScreen,
        SignalFskReceiveCapabilityScreen,
        SignalUltrasonicTransmitCapabilityScreen,
        SignalUltrasonicReceiveCapabilityScreen,
        SignalSurfaceTransmitCapabilityScreen,
        SignalSurfaceReceiveCapabilityScreen,
        SignalSensorScopeCapabilityScreen
    )

    override fun capabilitySettings(): Map<String, List<MethodSetting>> = mapOf(
        As100SignalMorseTransmitMethod.id to listOf(
            MethodSetting.TextSetting("payload", "Message", "Text to encode. Make this a runtime input in reusable presets unless a fixed beacon message is intentional.", "Message", "SOS"),
            MethodSetting.ChoiceSetting("route", "Output route", "Front screen, rear torch, audible tone, or a combined route.", "Channel", "screen", listOf("screen", "torch", "sound", "screen_sound", "torch_sound", "all")),
            MethodSetting.IntSetting("wpm", "Morse speed", "PARIS-standard dot duration is derived from WPM. Screen/torch routes are capped at 10 WPM in native use; sound-only supports up to 40 WPM.", "Timing", 5, 3, 40, 1, "WPM"),
            MethodSetting.FloatSetting("tone_frequency_hz", "Tone frequency", "Used when sound is part of the route.", "Channel", 700f, 200f, 4000f, 10f, "Hz", 0),
            MethodSetting.ChoiceSetting("loop_mode", "Loop", "Morse is a cyclic framed beacon: send a fixed number of complete START→END cycles or continue until stopped.", "Timing", "continuous", listOf("count", "continuous")),
            MethodSetting.IntSetting("repeat_count", "Repeat count", "Used when Loop is count; at least two cycles are required so the receiver can refine a bounded message.", "Timing", 3, 2, 100, 1, null),
            MethodSetting.IntSetting("loop_gap_units", "Loop gap", "Quiet Morse units inserted between repeated messages.", "Timing", 10, 3, 60, 1, "units")
        ),
        As100SignalMorseReceiveMethod.id to listOf(
            MethodSetting.ChoiceSetting("source", "Receiver", "Rear camera luminance or microphone tone envelope. Legacy light_sensor values remain handled if supplied by an old preset, but are no longer offered for new configuration.", "Channel", "camera", listOf("camera", "microphone")),
            MethodSetting.IntSetting("dot_ms", "Expected dot", "Starting dot duration. Camera/light reception enforces at least 120 ms (10 WPM max); microphone reception supports 30 ms (40 WPM).", "Timing", 240, 30, 1000, 10, "ms"),
            MethodSetting.BooleanSetting("auto_timing", "Auto timing", "Estimate the base Morse unit from acquisition/marker and Morse observations. Locked timing is recommended for camera reception.", "Timing", false),
            MethodSetting.ChoiceSetting("optical_profile", "Optical profile", "Screen suppresses rolling-shutter swipe transitions; Torch/point uses stronger underexposure and edge stability for flare decay.", "Camera", "screen", listOf("screen", "torch")),
            MethodSetting.FloatSetting("microphone_tone_hz", "Tone frequency", "Target carrier for microphone reception.", "Microphone", 700f, 100f, 10000f, 10f, "Hz", 0),
            MethodSetting.FloatSetting("microphone_tolerance_hz", "Tone tolerance", "Accepted frequency window around the target tone.", "Microphone", 120f, 10f, 2000f, 10f, "Hz", 0),
            MethodSetting.FloatSetting("microphone_min_dbfs", "Minimum level", "Frames quieter than this are treated as signal off.", "Microphone", -35f, -90f, 0f, 1f, "dBFS", 0)
        ),
        As100SignalQrTransmitMethod.id to listOf(
            MethodSetting.ChoiceSetting("content_mode", "Content", "Send text or a file up to 1 MiB. Content is wrapped with SHA-256 before segmented MMS/1 coding.", "Payload", "text", listOf("text", "file")),
            MethodSetting.TextSetting("payload", "Message", "Text payload when Content is text.", "Payload", "MethodMesh QR Blast demonstration. This deliberately longer sample shows that the optical link can move more than a token message. It contains enough text to require several error-corrected QR frames, so you can start the receiving phone part-way through a cycle, lose some frames, and still watch Reed-Solomon recovery complete. The reconstructed text is then checked against the SHA-256 digest broadcast by the sender before MethodMesh marks the result VERIFIED."),
            MethodSetting.TextSetting("file_uri", "File URI", "Optional caller-supplied file URI. Direct native use provides a file picker.", "Payload", ""),
            MethodSetting.TextSetting("file_name", "File name", "Optional file-name override for externally supplied URIs.", "Payload", ""),
            MethodSetting.TextSetting("file_mime", "File MIME", "Optional MIME override for externally supplied URIs.", "Payload", ""),
            robustnessSetting(),
            MethodSetting.IntSetting("shard_bytes", "Shard size", "Smaller shards produce simpler QR frames but more of them.", "Reliability", 96, 24, 384, 8, "bytes"),
            MethodSetting.IntSetting("frame_duration_ms", "Frame dwell", "How long each QR frame remains visible.", "Timing", 650, 150, 3000, 50, "ms"),
            MethodSetting.BooleanSetting("loop", "Loop continuously", "Keep cycling frames so a receiver can join at any point.", "Timing", true)
        ),
        As100SignalQrReceiveMethod.id to listOf(
            MethodSetting.TextSetting("message_id_filter", "Message ID filter", "Optional MMS/1 message ID to accept; blank accepts the first active message.", "Filter", "")
        ),
        As100SignalFskTransmitMethod.id to listOf(
            MethodSetting.TextSetting("payload", "Message", "Small text payload to transmit.", "Message", "Hello from MethodMesh"),
            robustnessSetting(),
            MethodSetting.FloatSetting("mark_hz", "Mark frequency", null, "Carrier", 1200f, 200f, 8000f, 10f, "Hz", 0),
            MethodSetting.FloatSetting("space_hz", "Space frequency", null, "Carrier", 2200f, 200f, 8000f, 10f, "Hz", 0),
            MethodSetting.IntSetting("bit_ms", "Bit duration", "10 ms-aligned bit period. Longer bits are slower but easier to recover through poor acoustic/radio paths.", "Timing", 60, 20, 250, 10, "ms"),
            MethodSetting.IntSetting("ptt_lead_ms", "PTT / squelch lead-in", "Unmodulated lead time before each frame for walkie-talkie or VOX paths.", "Radio", 120, 0, 5000, 100, "ms"),
            MethodSetting.IntSetting("repeat_count", "Cycles", "Number of complete MMS/1 frame cycles to send.", "Reliability", 2, 1, 20, 1, null)
        ),
        As100SignalFskReceiveMethod.id to listOf(
            MethodSetting.FloatSetting("mark_hz", "Mark frequency", null, "Carrier", 1200f, 200f, 8000f, 10f, "Hz", 0),
            MethodSetting.FloatSetting("space_hz", "Space frequency", null, "Carrier", 2200f, 200f, 8000f, 10f, "Hz", 0),
            MethodSetting.IntSetting("bit_ms", "Bit duration", "Use 10 ms increments to match the receiver analysis window.", "Timing", 60, 20, 250, 10, "ms"),
            MethodSetting.FloatSetting("minimum_dbfs", "Minimum level", "Frames below this level are treated as silence.", "Receiver", -50f, -90f, 0f, 1f, "dBFS", 0)
        ),
        As100SignalUltrasonicTransmitMethod.id to listOf(
            MethodSetting.TextSetting("payload", "Message", "Small text payload to transmit.", "Message", "Hello from MethodMesh"),
            robustnessSetting(),
            MethodSetting.FloatSetting("mark_hz", "Mark frequency", "Not guaranteed inaudible and not guaranteed supported by the phone speaker. Profiles start lower after handset testing showed steep roll-off above 15–16 kHz.", "Carrier", 12000f, 11000f, 17000f, 50f, "Hz", 0),
            MethodSetting.FloatSetting("space_hz", "Space frequency", "Keep the two carriers separated enough for the receiver.", "Carrier", 13000f, 11000f, 17000f, 50f, "Hz", 0),
            MethodSetting.IntSetting("bit_ms", "Bit duration", "Use 10 ms increments to match the receiver analysis window.", "Timing", 100, 20, 250, 10, "ms"),
            MethodSetting.IntSetting("repeat_count", "Cycles", null, "Reliability", 2, 1, 20, 1, null)
        ),
        As100SignalUltrasonicReceiveMethod.id to listOf(
            MethodSetting.FloatSetting("mark_hz", "Mark frequency", null, "Carrier", 12000f, 11000f, 17000f, 50f, "Hz", 0),
            MethodSetting.FloatSetting("space_hz", "Space frequency", null, "Carrier", 13000f, 11000f, 17000f, 50f, "Hz", 0),
            MethodSetting.IntSetting("bit_ms", "Bit duration", "Use 10 ms increments to match the receiver analysis window.", "Timing", 100, 20, 250, 10, "ms"),
            MethodSetting.FloatSetting("minimum_dbfs", "Minimum level", "Frames below this level are treated as silence.", "Receiver", -60f, -90f, 0f, 1f, "dBFS", 0)
        ),
        As100SignalSurfaceTransmitMethod.id to listOf(
            MethodSetting.TextSetting("payload", "Message", "Small text payload to send through the shared surface.", "Message", "HELLO TABLE"),
            robustnessSetting(),
            MethodSetting.FloatSetting("carrier_hz", "Surface carrier", "Low-frequency speaker tone coupled into the table/chassis.", "Carrier", 180f, 70f, 500f, 5f, "Hz", 0),
            MethodSetting.IntSetting("bit_ms", "Bit duration", "OOK timing for accelerometer envelope recovery. Native default is 60 ms with live bit progress.", "Timing", 60, 40, 300, 10, "ms"),
            MethodSetting.IntSetting("repeat_count", "Cycles", "Number of complete MMS/1 cycles to send.", "Reliability", 2, 1, 20, 1, null)
        ),
        As100SignalSurfaceReceiveMethod.id to listOf(
            MethodSetting.FloatSetting("carrier_hz", "Expected carrier", "Shown for operator parity; the accelerometer receiver detects the vibration envelope rather than estimating pitch.", "Carrier", 180f, 70f, 500f, 5f, "Hz", 0),
            MethodSetting.IntSetting("bit_ms", "Bit duration", "Must match the transmitter; 10 ms increments.", "Timing", 60, 40, 300, 10, "ms"),
            MethodSetting.IntSetting("calibration_ms", "Rest calibration", "Measure the resting vibration floor before packet acquisition.", "Receiver", 1500, 500, 5000, 100, "ms"),
            MethodSetting.FloatSetting("sensitivity", "Sensitivity", "Threshold = resting mean + this multiplier × resting standard deviation.", "Receiver", 2.5f, 1.2f, 6f, 0.1f, "×", 1)
        ),
        As100SignalSensorScopeMethod.id to listOf(
            MethodSetting.ChoiceSetting("sensor", "Sensor", "Choose a phone sensor to inspect and capture.", "Sensor", "light", listOf("light", "magnetometer", "accelerometer", "gyroscope", "pressure", "proximity"))
        )
    )

    private fun robustnessSetting() = MethodSetting.ChoiceSetting(
        "robustness",
        "Reliability",
        "Fast = light parity; robust = parity approximately equal to source shards; extreme = heavy redundancy.",
        "Reliability",
        "robust",
        listOf("fast", "robust", "extreme")
    )
}
