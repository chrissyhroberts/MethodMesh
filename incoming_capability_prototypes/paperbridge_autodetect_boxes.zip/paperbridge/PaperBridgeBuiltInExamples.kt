package com.example.methodmesh.modules.paperbridge

import android.content.Context
import android.util.Base64
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.GZIPInputStream
import java.security.MessageDigest

/**
 * Runtime copies of the canonical demo assets kept in this module's docs/ folder.
 *
 * Module documentation files are not guaranteed to be packaged as Android assets.
 * To keep the shipped example usable without a manual import step, the exact docs
 * PDF/XLSX bytes are embedded here in compressed form and materialised into the
 * app's private files directory on demand. The docs copies remain the human-facing
 * source artifacts in the module handoff.
 */
internal object PaperBridgeBuiltInExamples {
    const val DEMO_TEMPLATE_ID = "paperbridge_designer_demo"
    const val DEMO_TEMPLATE_VERSION = "1"
    const val PAPER_FILENAME = "example_paper_form_for_designer.pdf"
    const val XLSFORM_FILENAME = "example_odk_showcase_paper_form_transcribe.xlsx"
    const val PAPER_SHA256 = "bce47af494812361fe443c6d7fdd7bd7c265a06c35755cf221396d51fd6b9a3e"
    const val XLSFORM_SHA256 = "4304b2f16db37f27dacc1416d08abf5fb227ac8cbc484501ee7616e3d16137ca"

    fun isDemo(template: PaperTemplate): Boolean =
        template.templateId == DEMO_TEMPLATE_ID && template.version == DEMO_TEMPLATE_VERSION

    fun paperSource(context: Context): PaperDesignSource {
        val file = materialise(context, PAPER_FILENAME, PAPER_GZIP_BASE64, PAPER_SHA256)
        return PaperDesignSource(
            path = file.absolutePath,
            mimeType = "application/pdf",
            displayName = "Paper Bridge example questionnaire"
        )
    }

    fun odkSchema(): PaperOdkSchema = PaperXlsFormReader.readBytes(decodeGzip(XLSFORM_GZIP_BASE64))

    fun xlsFormFile(context: Context): File = materialise(context, XLSFORM_FILENAME, XLSFORM_GZIP_BASE64, XLSFORM_SHA256)

    private fun materialise(context: Context, filename: String, encoded: String, expectedSha256: String): File {
        val dir = File(context.filesDir, "paperbridge/builtin").apply { mkdirs() }
        val file = File(dir, filename)
        val expected = decodeGzip(encoded)
        val currentMatches = file.exists() &&
            file.length() == expected.size.toLong() &&
            runCatching { sha256(file) == expectedSha256 }.getOrDefault(false)
        if (!currentMatches) {
            val temporary = File(dir, ".$filename.tmp")
            temporary.outputStream().use { it.write(expected) }
            require(sha256(temporary) == expectedSha256) { "Built-in Paper Bridge example '$filename' failed integrity check." }
            if (file.exists()) file.delete()
            require(temporary.renameTo(file)) { "Could not install Paper Bridge built-in example '$filename'." }
        }
        return file
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun decodeGzip(encoded: String): ByteArray {
        val compressed = Base64.decode(encoded, Base64.DEFAULT)
        return GZIPInputStream(ByteArrayInputStream(compressed)).use { it.readBytes() }
    }

    private val PAPER_GZIP_BASE64 =
            "H4sIALvioWoC/71a23LcuBF951fgxVX2lo0hbiSQ2tqUrrEqvkWaZCsV7wM1A424niFnOZRXyk/mIX+Q/EgaJNHAkCOt7VStVeuZPWo2+jRwGg3Qzz6cnr9i" +
            "VCbP/vPff/07YSQl9fXPyfffJ7MPTb28W9iGPN8+bJc3L5IffkhstXS/5pHZ/GFryexDsbK7ZHZS31UtYcnsz+VyR/5BJBhekp+iR8Xk0ZOiLdb1Kul9EOf7" +
            "MnpARg+c1FVrq3ZHVGc0e2uXZXFc38NIKfwooyjPVUa0ZFRro2Hk2aXd1XfNAjw7D+fgof/CSNY7OWevUpLjd0b08J0T42NxyVhc2RYGml1sIM7j4fNk+LyA" +
            "FJyek9nc3rc939ll3RatJSnwbIqqG97BIV/J7Kiq6tbl6SfHvgFqE/oqov/GVqv2luSaa2exaxtbbJJf4Id1/Pu/FxtCjufEMWSczG8Ik1SS+RtyNgc799Os" +
            "kuqRhDWW3HyXpN1vnVkiNM0zkWuiU005k5xsIowJyrTMiZA0F1JIQPLeihu0GZBFwsHKCM4jq3TsKSB+PHguYIJyKTKCnnJjRuMhskgwKsQiNoOnKb9FAhmo" +
            "EpVLqhjbIx4wH67KUyo1j4irTHkbJK6ylCrJIuJKZWNPiIRAImwIFz0hJRwvIo5RBavAxnua8BsTF4JmuVImJg7pymTGVCAu+WCFgSASEQ9WnlLwhIgIz3mM" +
            "w/SkKhWBOEz9aDxEIuLBykcePE34DcRxKUTEA+bDxUWFlHDpRcRxgQardOwpICEQxDBc9ISUcLyIOEaFGEaOnqb8OuIo9q5ocMKyrmjAwhmKBuC+vrh6IWVq" +
            "SJ6DM6nJfEOefyi2sEscN+VyZcnSbmryy53dtWVdVUXZ2Bdk/jOZfzd4cmVJU9UNkeIQlBvppoSK7g98as2FGqKajp5xmivOuuGP10X1iWy7ID7bZgfjkpsa" +
            "vpe7u2JNNsV2W1YrUlRLslsUVQVmrQuvWkWRjZNghgD1UzkQGc0UROmiuDg9eze/OL84OZpfvH835czSzuOTOeWwERujhqQ2bbkotwXsCRenkb8KXOWUSZOR" +
            "TMNEMulWEqfCCKjDjBrDNHN1/CoeRBhNtZDZ/iB/K3dlS6q7zbVt9oaQsGiU0TIMoQxV3VYxGeJL05UJRTOe9Wtm/v706O/flKUMSihLFe/cvC4+W/JQ3xEL" +
            "W21F2npZPPyRzMvFJ/L+3Rk9nDaVK6oVz9zGqDXTnTZ56mZynDYGUnF5VZpTpfO8G/Rd3d7ur57YOQiegeFX+JaaGjYs5iOyLtt2bR9xDqVapUx+jXcGiRNZ" +
            "P99X9eYRzxKKouZKf4VnqRmFqmyGuG/u1iA2W6y/aVYlFDWRiX5xXD1stm292e3N59GbN6S9LVoCel4/PDK1UDYoYzDSl9MQBkxlJrqRz+3nkRJECgtfCvE1" +
            "rgUUBiHSkW/ojVe3j4StQFSpMV8TtnLbSD+tp2XRNLe1LR6J/Mu9h8gj969tsSwWt5NC/mWyF7AA81T30nl7dnT118uzt1Arr8iMXH04O7mA//mmJcMN7PVD" +
            "HZjbDZT/or0DQh+fn3x8cTjPXBiamiyPostpKiHESSagI4JNycC2C42H0apfmSf7kWLaXFGVGnZWGIm7Prpbxlu7KDdQlq6LZlEv95WHj/A0oxyWCIMdFcpM" +
            "Dr04NIRDL371xJYpmclS2DKlhO3dEFcYTMZGW6aATX/oHsDtsGEf3dyU9z4qsi6u7bqT7wMpq10JENS3Hbmu7w9tkFQP42qhYNeGT6Vdx3X5J2CFeWWw5pRM" +
            "oWmGopXS1KUYsXXEy7EyNPu2PoAJWAKG9yXoHPb8boOH2vwH8snaLSmgJN3A6Y9crwsoIYu6cbv/pmg+7Vx7UF6vLSWnNYFTGPm1KeG0Vn927cGt3bOlh2c9" +
            "hAE9fKZUX8FP7a5cVXYJxYvYe9ssyp0l708uoem4b19Chlu7ss1LaJRgcRTrl2QH8a7tq8VtXS7A8u3lS7K5W7fldg/s+hc/ZYti65Y6PTQ/JEn+ksCREJJO" +
            "3H+HznjJj9Du7p8ZgdhwFO4OjclwaEziQ2P/xU10IvPpsTBgDEqlUlB5oFNNpYFp5tn4WOiRRQKtpuYctijEGBt7Ckg4rSCWQ3PDc0HQUQ6lYXwqTPFU6INC" +
            "DAP3jqbsok4Z+EMdJb+6LHBqJllADAqfguLS1RgFWwHwA82PsjAg0PlzKqGj5AFjcAba9xSQKAsBg0Lljj7eUQ4zn46yMCCQBR8UYhGZ3tGU3SK52rsbEFP6" +
            "AYNapaD8QKWjqXZfNONj+h4B+jkUMsliK4X0B08Bie4GAgZdnYEON3hK5Yg/IsAfo/JYxGbwNOXXLQPezX00h9KTj7DhgTVkLLLNDZ/Y5nrPVqoDyjJjrLeF" +
            "ujOxPWh6SMIKWvvJBQdiXniuWYZd1gRxhguOIGGlAMuhbwhWoKGRJ0SiCw6PeeWhIxRndL+RhvuNIahg5QNHRxN2hyWs3EF2cs3jMS88lXOq00ibURJQwQp6" +
            "Js5ZHlkpOJftO0IkvuVBrBceOkJtRklABfuYglGgMviZcBsJWGVmSh4xLzuV5bDZMxmkGd1xoYBBhZSZ7nIPrZhnj57YlH3ABtkFT16aYbwg4BBVsEI26MlM" +
            "EoACjqZQBvKI7Qktyj+f2I4ErNy5aKIrNcIGW1D2xFYesn1SwfFNncekO7hnOQ8KhvZrdHOGSKTgYOW1GTx5JL6p8xgX7gaqu8gcPMGaH42HSCThYOUjD54m" +
            "/H5Dw3s3lgMmQQsZjIYalhnVowtLj0QaDlZencGRR/YuLAcM6p/QqlP64AkOW3J0YemRIOJg5OMOjibsHlNxTB8xRY1RzAQVw84/4o9IpOLIatBn5IlN+SMG" +
            "nwCZoGLY6Mb8TeDvo4qsfOTBk5kkYKpiUFIg79e3f2CkYpZPbdnI1qt4T1tqhI1UHNvKQ7ZPttLR04ih9rBrRX1iAxGpGDtgxLBJRk+IROlEDLWHnlCfOF6k" +
            "YowKMYwcPU35/UYzHefBYyg+7FtRoOH6PcgYe2DEsE1GT4jEefAYqg89oULD9XuQMUaFGEaOnqb8Hmun4/cPiHn1YeOKCsWAIh1jExysfKOMngISvX9AzKsP" +
            "PaFCQwKCjjEqxELk3tOU36F2OtJxWOH7egsrMZ/ajnSM7XS8qswYG7XTke1BUzhg/1+HbPbEIbtKDGgUujdh4EF3MdWphXIFI3ENfwnZ34fg62rw1F+hJN0F" +
            "RRIuKMCRu/JJ9i5HPqZQBfbvRxq7KndtU7iXNqQtmpVt8YbkYwq8Dl+SDJbOwl1FJPPvXAQuO7ZaDq+nh/fYWfQe+7jY2e5F/Oy1XX+2bbkoktlZtaiX7kXN" +
            "7MeyOqp2pQeS2btiY91tUTK7urtuu/fn7i068y/Tna/olXn++w2lf7+hzNNDvTqu18svGY9/4Xj3jb2B6sTSJMU/JFPu1viGIAYLtP9NFTAlJxhjYopBUR1j" +
            "EvqlEaa5mWIynYyhYbedYBnULcRgfZdr23QZvCr/aR232WUNy1r0/+LjorqpO61e9v+8omjaLgs6F2ny7NnZ+/Pkfx0Wr7EwIwAA"

    private val XLSFORM_GZIP_BASE64 =
            "H4sIAAAAAAAC/41ZBVhUW7QehlRa6RxKwAGGkC4J6Q5pJGaoAQYYUlJQUkJpHFCkGynpFJCUDkFCupFOeXjve88n7973vTnfOefbc/b6z97//tfa+6ytoYyO" +
            "QQIAAHAASk3sJpEpr/L3r0uSQACA8PruaQ/xQLjALRAIOJeng33l0AfHVm4irDm9D46IzZiHqaHNrUOViLkJawviqVdf0tem9LJ0H6bWlqb+nB9nvfwoyeUH" +
            "1VNZtFh9x4HBjSdCRd5P2zvZqCBEd6R8TjycFf2jlUwSyy6RIBiVk4AcQn/66BGKm8OvgscrPi90rddWKRcPP3Qy2ofpU5T3EtDn+JuWIYQsrpPARk3vAsO9" +
            "Z0YFm6V0RGS4xTtDNSvFlL+MA56BeaE05M88aJjzg+Rwk2eRXqlVE0aOju/IaHZR8ohw0DYTu9eqvX5MaeLr7ckkB5Oe9TWKVpSJkKRdvi7TYr8Ce+Hai8KP" +
            "0pJSbTsRP875aBoBGn/wU2Kv5n+CBgBEEAAA+H/zg3T1sochf7GzpKeJmAIR/QSHHrffsx1jyzfK0o05Gko8Mi/51EEwhEYW0ztZ8hbQeSQCg+ezOOg0nWz3" +
            "+vqgJHdPl4tfBVRN66frBnextYcWGJNL61LOVO/14M1+m3mA3HBvfjuGEh1R0HCfgXpuGYur33lTUgN1z4QXU93KEngtLDqUrWTvIAQuVI+NeTl8AGdM1phg" +
            "SjAUjnBp0ORqW+AiuXceVoXHq4IjF0bIds8LT5wbvXWNSP3s5aUvaecVWgx8ACvZLt78q2lJkCM+9T1iAO2CLZQDcNFg1e+ckQt4WHRZX+AVHP+4XsYe+4ov" +
            "j9devmM4Y78QS1PWdLTNqf252tqoRbTg5yv1kx7KVI7EnLaccVcpa/9ORORu9uOvJNP1Gnp4HR9nphQFRVafo4t55flD6uzvlL25kxeZOeQL5kVZLOp+EMR8" +
            "CJfLHQtblfl8SSJzsPGxVRAm+eUHAApoXqdyj6au+R4c/I2aLoRt1G71VsBMHaFZiz/nix/p/Kgk4CkHSWATQJO9y/tHmS/gkrvQb1n1eTjQoTta3bsn8m6N" +
            "ZBaymEbw5OQFjdY8peCv6v3Z0i4t98U80/ybz96ugF2Uvsb2FB4t8hb4uiWPSswn+GjHJjRqL9Uuj+oVb5ljb8FtrJ8cdJrQnErm40k+jdr1ThTZDHZwOp/t" +
            "nnryp0TOjNEM0NEBgK/X+rj7t0RcbWAOsL+vPL+E0qA35fKGm+SCVG4HXxC5/xx6p9ORfsg2p4vwM+hhJBGdYlRq0w7IEfhy4YH7JrayxZfJRyulreMfz1E2" +
            "JaHOxgNESXpYA0SR4RTDDzCMXvnst2z18aMi8JYUMrjlGfShGj5Xl3gVvmpsb9uIoNL2y7X9GXhLMU9IqWWPhRVvJ8i0lNxOWOcJElUZRq0mmFc/JeDBdJhh" +
            "kRJ+H5iIS2yuPohWtmd4YZEgeREJwRk2ZbjVQjBcPSGe0QCgembMgYP7jEHy4TCi+FAgPDTMjMWJRVLVjJa4SZ83JmtDYEjf8GfvJgVzYCiP01riLFeGbDOb" +
            "dEVCRqBqJ79PARo4184T5D2XfAR6aF7aiffMG9F3hnZHF996gdoEswc7hx6kOTpAiTlNOeZrdozOnE9VmxEwuddfnnAJCOvGyYZYVm+cNk41G6loxdBj/3i2" +
            "QTUjE7RjVjtkpwu8/zTyGKzo9Bw6u7SLaHmMSVrWrWGWH/YRX8lMR4CN2bOv9Ch0WEWBTkh+l/bhp2jgAZp11FodMEqDnsFhTQTL5BteDX9Nkg/zXZXPsZ5M" +
            "q6+UnetBQqbm0ouycpVZE1DcVqpWOm5YKfW+iG53pWqLjFlAl/GQFDfpaMoGv7o4KtbhZ3noRragkWgAkuCRR4sTyVsbykWOpfzgOx5lBF/SBgYH8d0mWNdj" +
            "PFzKiGYvSmPmcolM2AlbdIKW2Od77eqWiJnZuHAfs67GH3KwEFhpe0B93eHqbDxfzF6m1HfEvc6z2qjdxXv0ONPzpzmLFDdD5nS+MokB/RRa+mVyFfi0YXn7" +
            "Zw+HwMsI7M/lt1khlStgXRtg2ymQqmA6uWdwtU1cVjGQkefDkCp9TW45Tf2FgaswexXwQw7HjC28DOZvRgPs5KNFt+FZfs8eQGY5Vvnl5PK9UQg0tuVrlzeh" +
            "w4vEhQRtYvASXtbxSuV3t1qRHudDv5HmyuzNsTd+dyBOEljdNZkn8nP+I9rgArHjD3nrGkuqVEXiDF8aYwbdTU7dgkXsJ4cs34zzCFNfPLN77PgT7U+fwaer" +
            "WYVdl5DXJ8l/hlUbcxcYVNvVxdbR+q/oitmiebsNhAcYKFD4aT0t0RHzNe3R14rb98hi8aObjhMcXJCSVIZ1zJ5ngCjojnw8uGW8vxO7yi1Zc3R68R6VdaCF" +
            "u7zsN1znx7OI111bm0HleTsL0g3YSzK4r5zb9HAQi8aYNMX+fzZr2Y+e9OAWABDICQBQ/J4NkTYwmCsS8tftL3/OMoQjFgTILsEYmg+0HzpzKPtVpbWooE74" +
            "h8n2JzjdY0gpwqomlDKVtLxcY64aQSyiWiou3+0bP31fEq5dFPcx1mqqr+nhcwqqAb1US59dkw6w7b0j/VFbv7tvDafR67Ln22LCjybZ8A8YHl5y7YuOt7XZ" +
            "I7omk0O1UUyD5pjZHl5V5mLyWq4Us2lhgZZxNvppqYe131oMonBehGskmq53NyFj5vDv852++sbFPZntcvtSAsM636KXV/MKW1hTTTomQ/TyKoGZN7XVFEdK" +
            "6TXGMPumNFGidNnFbHyff2beXAPVjDelWO58C5OPK4ZY4fw8HR3N/pEf/s7O/E8eBP3IbgtTvTeGj35bCCQo2u5kFWYiWDy/kNgSXxDvWAthnsDd0fS63LmD" +
            "Er+vr+wXzKxFiPoGLL6/5pH7FuGL85ygCCXNUFM1XZ9wjPmYQ5B0vPFMFOkW7mJ5iEQe4pks9Or4WxW/vXNfdRTSO6qpafaJODJSwiRFiubK5E7U3btQx6B3" +
            "zwc3ZzAMkhh4MqRdoLZf9rzfsXVKvyv6YALmq05bVAmtpHTue33e9Vwj7K2nVzbmyIBmSXpG2rIWLwIcpFgew3GIq2Pm16dY1k6c/povo5BjbpaUon7YJmZu" +
            "GifNoPmtNmMz/Y5k3hLaokIHO9nDbArjxAddTsBiPtkr4Fep3fPNO6CUAArNAN6WZn4sZghFohDacyUsw8beUpBRuFdn7nf0kHXhhwWjMFTdS9xE5zXeYuOO" +
            "ykFPUCQAWPnu6GndqW3TJ4EHd5OYGH6kapbscBy6KTCG7TPK3JH3vy0XmX+Lpi+l5iV5Arle7C77++9kyAXjBYtUI/2dD9z9bFzFWT3V+ZFBrJAzrAIHElQz" +
            "TU8cizCZrfyx1UpHCN20B7viHIZAiJUWrohWBt7T0pnellsjQox8eKy7XZ6FoKdm0oRkNhHzi9QjEYY60y1hkqvu4kl26auBpggiMU+iQSGYcW43kIkuZzA4" +
            "Q3/92E20YSCId0k/k0P5faHO1o9zE8Ll56/re5mI+aLc+gaDsAUxrMMCYktm3xlWutZVM/OwE8Xnp9ON9MS6+yMAPcl2477pAI7HdnWxA0EoYqHTr1sn6Wf7" +
            "tbSz9MfYviVTa8cjb+9Tusq3gQm3ySiEXtV/WveK2JnD8PP1PqN3PVM/dqVJNfXdbzA9AYgrjN7jZ5JuUHd5LUP4XqsMp52Hixllr3FvN+gj4hM+saxcRW8J" +
            "D+LB/JN8is0IanyN/fPH5NtfucVs2nJnd46xowQWn7eG7bTQ5O0eRnlQM4XZMhsEblObQgbwsY4LMb7iVZyqtl2i5AMHHILn05W92XNDz5m2LJmdngl9Zc8W" +
            "3QWBR7Szgqjj4sMTecOpTS+6oUqrYyRLM9wU58/Wk8xpl+aUKu0644jz5JqZxo1KISIgXJ/2MUbcICchO57bCYKnErrRIcb3NTjzB82m6atyBWAJlcbamKBO" +
            "Nj6e4G/cOPKq3dyrwVJX6/PdQWw9E5xqjKpFIsjZkLqxMb8ND1N+IGR7X7rM+MGUDrnuD8cQUQifYjgr2rjFnhmtccc8BvDEn90sCGHYtlLmJ7Ea3yiJU2te" +
            "rndmDqE4L4qKMqhRpbZfOdyPcpB8tDl55sunLU20wt6W2yIAj6M9y8ExAm5Fd/gZZbLL3Qofzi4ki34UorbNBmYFi2RguTdUw/2Hzy+V31hobOAtKyTQyDu3" +
            "pX6JXpobPVXfusXRwtPVl0JrMwg+3EHR56ORTliVgjZdNxQ58Ea+WObwaLJZc0cWE0cbDFHlVd4SS1mXEyPbPH86G9DCRpMvJUhFEHLW6SR0EGJegBZ/Vy//" +
            "LaU6ji7uYbAega6yFYnlfWGy3ZbqS8K0ylhtVkyX2+fpcFbyxzoNOXkYM3eoHITBuAvB/cC7PO9fzThSHDuTjbBWUpZUrfgn6ucOqhLPdxxYWs17RitR5Wz1" +
            "1X1dQXIoq7mJgD7TftYNTw6wg5jPjBiZvmPIoSTuoN1eQsuveeJKSc61MAQzrnkJV+azSPDYpe2OwPOg8u6MkOTqb/JpDJUw9jG9EPDWNWB8raKeb5IlkrOh" +
            "EJUbKlzTwUqX/oidqQ3L76xNUGZNBp+ocJEnyiVhbk3xpUvvYFQBjxpTwv5aGNWKnGVvDutTvK1C3RiPRWZ5o+ngcVKhKJZJIlTSOsmqhCVbnm/dxd7PyzC9" +
            "hfz3qsGLXerbn2pnKQwv7wPnkbHMypdHXONCxRyfjwQmhFIIYvoWu6TPLxe7gBWL8vsL+RCO0cOqC91OdNYr/s1ef887Nd8A5TG+xBQnOQ1EUH2l3hd6iPYX" +
            "2EopZsXad5uFFHYiSLQXVMpc3La/2ogNDL9Lz3k2OSpCz63UDbRdppGTMnDqy/zElvNMWS0osdvWCYWKKmgs1dkJoP+4t8K+e8g7hCZpdZZnrfPqxUKgUi8a" +
            "UDDSD52632UOvStglm+jYzRio6Xclc9+1crGXW0Or5PXgiRIjpd8tA6egeJQwa/WVCVL4jF40G23+np0N6uMio614LoPxhIQk474nmo6CfBFhtyJfP/uzh5f" +
            "ac8GCljqPKpvecCZ5D5kg3f+mfRoULlt2yI1Ogq3LAL+V6A9XDWQohMMFBM4N8kx7NA3BBXF9VNo4O4q9lu/XJ0gHfyhzCQi4Qii1/PlcS8hlJowBLU2Vz8U" +
            "y/iyp6XgRu0cucTZ4SpPgzU3Xa9SLYIU90t4fuG4L/0B7l6m5hHJWGaetjwqxzDZrM6HyIgjaFHlnMxtgtxj3ZnugN+NjnVYqyhGjVVOPqWYH4v/4A9VskDX" +
            "oUyLUUhYVpzFsl9acb/YJJoNL776vlrruSJgCnc1sVfOcVuqKO4ba1sVgLjoFiNUiHSK4QSIL5QzciIOBGWYflG3+TNY3lkA1ls/0yyl8XU3kMtPtot+/GGY" +
            "sWlhJFIEznFzqKKTE7aRExYS6X4G7lbvl+19VsXtM21Oy0CAYiAwpbEg/9U8/A8Rv5v3vZTy++7nDTfquR8BEK1joSNcd+oWbNVdtIiKWrih79mWHjKJEMfQ" +
            "vGpAkqmXa6YmcpzKinxqyNZEuAhefsjd27cvddj3vstb5W5nVx3+oecBnbmdxD2x5wJNGU6GENTYda+2K7hQY1nDtS6G41Yb5hopIfbrRhEZEiFlaIb0Jtx2" +
            "yfqcc3ZvKkQR47eEQ5NFKgS9ecqJfUewJ4TQRlno5/R9tXBDa4kZgBcCRuhuFYQ4pFq+Hsfl90VErZNFaACbCbdfMIc1Bhw2B2vEvfI/iO1X6x8VJ+0OYCtB" +
            "Mo4kMi8rx8tcGe45G6yobbTamvwnTduLyKNFXNVKoN9DH+VcAOXMZ/ZN92Ci3fVu1auEwoGmMyJjPnaDRm8tj4KkghxAIL6ly5VGg9OV8OHG1Y0FLNbCpf8R" +
            "GgBQiP2vK0XeXyvF1PhBx+svv4f+7Xvn0tJKr+VYdMfy13uybb1XLRdbMQsnGz83Kq7Oqsc8gHWsPUgrbRNeBij6eMzatBOYpcrG7k1CuymT8JC23XE7eSdl" +
            "34/f1Fn5yp5P6QI+URW9NBJkLwlddyOpKQRyTmPAuSMfYxpyflYdSHhVwBlaP1wR/n3NldiWAR9Bvinhuz5Hn7CkEdrw/q2nD5bB47g9g1aDkUDK+x4SvJxT" +
            "Cv0VNrULmss6WWJqQgXQtCDF07hy+x2cw5616U3L5Fi6t4eeKAnJjf2rgYzoulXHc80YG1ay6N4qDY8X7tWpzstaaU5y7B7QOr6QyNdR7nI2NokiKLJ6oSdt" +
            "/fwX890sn8C5TSe5uJtuHQ39E8NSREm05lwz7vqxsguBRY3WA8/BvruiWiyqp17z9XpC9Aar3kp38pwyoh0NAHSyMweMCDm5s7Q2MGQK2/90DgRZW2Jh2vcp" +
            "mQCT9u63cMI1s6UuFuqqV3W5LkJ+ZMOltyRUD7KABGZBkRKnD0DYbj2m31xUUiGwakiBWaq6BN5nqW/5eh+ptFeUa0jGHuMw6q8OR0s91fCaKqin1V5TJg01" +
            "huqeeHxv+8Jw0sCz97MTrtkqaK5sS6OtodGdE8tifVQR62bZWkvNgmpgJF4/NjDCrErtEwYTrfEKO9AkRnrsY/+pFS30ZpH8a63cx/hXrfD9pZVYTfgUN1Fn" +
            "U7czXpkUNataebxGDgenJSSoNFGcql1kyiIBmqlsQXG5LVP2xr2DulC9Nnb7+OPPleFvvjnUQq/2u1PwEvcxgcmtSrB8vGhj09nvl0fFU6ii8zU4Y7CaYAei" +
            "Fg++7B7L3JiriCv5kTNZTTDLzbD0rZEeS6MbM/STa2xmRHunLC6MG6fjG+SD585DLfYofP+PKyWZ+Sl8xsXErzX0JzoIwTakXGHvHpGPl782tk6aYRxRUuKl" +
            "5CIKz7Au8D+w7iFPplPHFvOlbqTaHZ3afYPWdEoo5mUrvfk1w4z4jvWXOWnNC2kcSQixTzAco3+gPII1x+GEVRjsyGaT+rQdt+IcO3OR5Ae3Kp7lg0diane7" +
            "Pcmy303jXK58e22zE99zEN/jylxOzik8IcwCBiqa6ga3qtiKrnm8/IgmKSvin73fNEho+VR4zcNYV18bx09yaqfYWm93Ww9MUyBd2epUvDhM2nt2GbsXjkSO" +
            "YLuo098zev2y4x0pqe/dYq0OGRkW6+okf2mnS9FwnikBOfjzIFjVmXCBooILgxFD3Ngey9rK9t7mx6b/jgWAv8b3+VRjMNv1+P46ca//e+ICs0dCuH5dd+qa" +
            "xCSvhxbkDnNB2iIcxRl5uLgZQTBHSwT0+jtXnNHN1YpTiFFSQkwLZm/uel0DaWPrhARdmzgixRltXF2dRCAQpKUNzMEcyYVwgjleP7FCuDiYu14XXawhTuaW" +
            "cHNrGISXm/t6/vifGIx/YoJ0vJxg/x9EhJWVrSVMFmHp5gBzdP0H4Bs1GEE65i7WMFdxRsiN5DEjSBEqzqjFDYPxcwsICQhY8Qs84OfnYwRBJMQgf/RX4k+H" +
            "IZjefcV7TSb3tcNQ/e0wf3P6P9H/4rdvmMexDUSBOVegv8k/0UGh51zmupayDKTwswdjcYCKkFUE4lolGvxF9+vWB1i0yIJDDg5+MM88mRWom3zZxXfCLTT1" +
            "joOFDQ2cSmU//k57xINmq+qN+EtGgv5gvyRp3jeDwViHPGrHFNiTQcQMbncnJl9+9WKyUEjd2WVe1HQNQEpTHPUQVGyrEKzc+jm8WkHHLCbkxWu2QN8u9Gkf" +
            "B40Fe140FL91/yQ1q5xScy+XqmKck0k2Pp6tPMGuQyOwBCtcnELfm2twPJlThwO+D1SKiavUWRnl100npxvRPgja8iuprDeM6iCFg/PCpYmUFH1VZyL2OwfQ" +
            "P/Fvsf70ATw0LtZT1g2tJeX/wpvPXINm2jinq0Okyj9feZ99qR1/Nxwz2ilbiNWw8vnw68+4hCU/L4/Q/2Ta9w1eBP010zCMv3OXRjIIR9frQX3ySy1Ik188" +
            "98W1KKHzEAU/gXXpCkwWgRjrtqQa8t9BiMrK69K7mKHZbuf2dD7MT6RSlIiJlT5gQpJ7Fq8ar3jpETt9FnvF+jKM1KWklYWyaDbS1s427eHne4Ycy30994Ck" +
            "sR4KRRTJC5FaULndFGhoQKyHr4IpX1cMFmmlwTraSGF+cdytzwHGewIyvW9EVw+7nZ0leeYIRL1Yw6e+zZCN3qbNKJcrx88dm7gMiEvfKXrGlRSPDVXkebZt" +
            "g2G2A00bgkeQC+tfdqvMrQqt6oGTm5doqRwyxb8747NPEoSzpp5Iedu8SEExzgiBvL4HCx8QpcjvlnpvSOIuJgXB5FPfeS9DnYW8VnYmQ2RNZQyXozP3ctU5" +
            "yr9IPoYePZHl+sL1fm8wyR+ooYwGJEH/9w2V//plPgP87+2Vm8Y3dxt+G4PQbuw93DS9mYX+bSqD/o856ZsAN1NyvwE8sP45QXcT4Wb27DcCAfa/59Juotxc" +
            "Wf1GESL+93XWTZSbc+5vFOjdf5+Bf6P8c2T/jSJL+kecv/n6mxHst2E82f8Vz27i3PTP3zhX5P/orRrKmFi/Kty+PqKvJahO+av0H0BHfXn0GwAA"
}
