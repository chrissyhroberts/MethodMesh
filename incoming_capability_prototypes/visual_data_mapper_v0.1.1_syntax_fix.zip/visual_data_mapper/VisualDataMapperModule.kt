package com.example.methodmesh.modules.visualdatamapper

import com.example.methodmesh.modules.MethodMeshModule
import com.example.methodmesh.modules.RilBinding
import com.example.methodmesh.settings.MethodSetting

object VisualDataMapperModule:MethodMeshModule{
    override val moduleId="visualdatamapper"
    override val displayName="Visual Data Mapper"
    override val summary="Make parts of a picture meaningful: define regions, record structured data, and render state visually."
    override val iconKey="visual"
    override fun as100Methods()=VisualDataMapperMethods.all
    override fun capabilityScreens()=VisualDataMapperCapabilityScreens.all
    override fun rilBindings()=listOf(
        RilBinding("design visual regions",VisualDataMapperMethods.Design.id,"Create a reusable region design from an image"),
        RilBinding("browse visual designs",VisualDataMapperMethods.Library.id,"Browse reusable visual designs"),
        RilBinding("select visual regions",VisualDataMapperMethods.Binary.id,"Tap regions to record binary state"),
        RilBinding("score visual regions",VisualDataMapperMethods.Intensity.id,"Record region intensity"),
        RilBinding("record visual region data",VisualDataMapperMethods.Record.id,"Record multiple variables against regions"),
        RilBinding("update persistent visual map",VisualDataMapperMethods.Persistent.id,"Update a named persistent visual map")
    )
    override fun capabilitySettings():Map<String,List<MethodSetting>>{
        val common=listOf(
            MethodSetting.TextSetting("design_id","Visual design","Stored visual design ID","Input","demo_world"),
            MethodSetting.TextSetting("state_key","Persistent state key","Named state for persistent maps","Input",""),
            MethodSetting.BooleanSetting("show_labels","Show labels","Show region labels when practical","Display",false),
            MethodSetting.BooleanSetting("haptic_feedback","Haptic feedback","Confirm successful region touches","Display",true)
        )
        return mapOf(
            VisualDataMapperMethods.Binary.id to common,
            VisualDataMapperMethods.Intensity.id to common+listOf(MethodSetting.IntSetting("intensity_max","Maximum intensity",defaultValue=5,minimum=1,maximum=10)),
            VisualDataMapperMethods.Record.id to common,
            VisualDataMapperMethods.Persistent.id to common,
            VisualDataMapperMethods.Design.id to emptyList(), VisualDataMapperMethods.Library.id to emptyList()
        )
    }
}
