package com.example.methodmesh.modules.visualdatamapper

import com.example.methodmesh.core.methodmesh.*
import com.example.methodmesh.core.methodmesh.runtime.As100ExecutionEngine
import com.example.methodmesh.core.methodmesh.runtime.As100Method
import com.example.methodmesh.settings.SettingsState
import org.json.JSONArray
import org.json.JSONObject

object VisualDataMapperFields {
    const val STATUS="visual_status"; const val DESIGN_ID="visual_design_id"; const val DESIGN_VERSION="visual_design_version"
    const val MODE="visual_mode"; const val REGION_COUNT="visual_region_count"; const val COMPLETED_COUNT="visual_completed_count"
    const val RECORDS_JSON="visual_records_json"; const val LONG_TABLE_JSON="visual_long_table_json"; const val RENDERED_IMAGE_URI="visual_rendered_image_uri"
    const val STATE_KEY="visual_state_key"; const val FULL_JSON="visual_full_json"; const val ERROR="visual_error"
    val outputs=listOf(STATUS,DESIGN_ID,DESIGN_VERSION,MODE,REGION_COUNT,COMPLETED_COUNT,RECORDS_JSON,LONG_TABLE_JSON,RENDERED_IMAGE_URI,STATE_KEY,FULL_JSON,ERROR)
}

class VisualDataMapperMethod(
    override val id:String,
    name:String,
    description:String,
    val mode:RegionInteractionMode
):As100Method{
    private val version="0.1.0"
    override val ref=ArchitectureRef(ArchitectureId(id),"Method",name)
    override val descriptor=MethodDescriptor(
        id=ArchitectureId(id), methodType=MethodObjectType.SignalInterpreter, name=name, version=version,
        description=description, outputs=VisualDataMapperFields.outputs, graphOutputs=listOf("visual.region.records"),
        parameters=mapOf("category" to "Visual data", "status" to "Experimental", "connectivity" to "Offline")
    )
    override val contract=MethodContract(method=ref,producedKnowledgeTypes=listOf(KnowledgeObjectType.Observation),producedFields=descriptor.outputs,producedGraphOutputs=descriptor.graphOutputs)
    override fun request(action:String,context:Map<String,String>,signals:List<Signal>,inputs:List<ArchitectureRef>)=As100ExecutionEngine.request(action=action,method=ref,context=context,signals=signals,inputs=inputs)
    override fun execute(request:ExecutionRequest,settingsState:SettingsState?,transport:String?):ExecutionResult{
        val c=request.context; val records=c[VisualDataMapperFields.RECORDS_JSON].orEmpty()
        if(records.isBlank()) return As100ExecutionEngine.complete(request,TransformationStatus.Unsupported,diagnostics=mapOf("reason" to "Interactive visual result required."))
        return result(request,c)
    }
    fun result(request:ExecutionRequest, values:Map<String,String>):ExecutionResult{
        val records=values[VisualDataMapperFields.RECORDS_JSON].orEmpty().ifBlank{"[]"}
        val designId=values[VisualDataMapperFields.DESIGN_ID].orEmpty()
        val complete=countRecords(records)
        val full=JSONObject().put("method",id).put("design_id",designId).put("mode",mode.name.lowercase()).put("records",JSONArray(records)).toString()
        val out=linkedMapOf(
            VisualDataMapperFields.STATUS to "succeeded", VisualDataMapperFields.DESIGN_ID to designId,
            VisualDataMapperFields.DESIGN_VERSION to values[VisualDataMapperFields.DESIGN_VERSION].orEmpty().ifBlank{"1"},
            VisualDataMapperFields.MODE to mode.name.lowercase(), VisualDataMapperFields.REGION_COUNT to values[VisualDataMapperFields.REGION_COUNT].orEmpty(),
            VisualDataMapperFields.COMPLETED_COUNT to complete.toString(), VisualDataMapperFields.RECORDS_JSON to records,
            VisualDataMapperFields.LONG_TABLE_JSON to longTable(records), VisualDataMapperFields.RENDERED_IMAGE_URI to values[VisualDataMapperFields.RENDERED_IMAGE_URI].orEmpty(),
            VisualDataMapperFields.STATE_KEY to values[VisualDataMapperFields.STATE_KEY].orEmpty(), VisualDataMapperFields.FULL_JSON to full, VisualDataMapperFields.ERROR to ""
        )
        val provenance=ProvenanceContext("methodmesh.visualdatamapper",id,version,request.context["operator_id"])
        val entity=Entity(ArchitectureId("visual-design:$designId"),"VisualDesign",temporalContext=request.temporalContext)
        val observation=Observation(phenomenon="visual.region.records",subject=InvocationContext.from(request.context)?.subjectRef(),values=out,temporalContext=request.temporalContext,provenance=provenance)
        return As100ExecutionEngine.complete(request,TransformationStatus.Succeeded,entities=listOf(entity),observations=listOf(observation))
    }
    private fun countRecords(json:String)=runCatching{JSONArray(json).length()}.getOrDefault(0)
    private fun longTable(json:String):String=runCatching{
        val src=JSONArray(json); val out=JSONArray()
        for(i in 0 until src.length()){
            val r=src.getJSONObject(i); val rid=r.optString("region_id"); val vals=r.optJSONObject("values")?:JSONObject()
            if(vals.length()==0) out.put(JSONObject().put("region_id",rid).put("variable_id","selected").put("value","true"))
            else vals.keys().forEach { k -> out.put(JSONObject().put("region_id",rid).put("variable_id",k).put("value",vals.optString(k))) }
        };out.toString()
    }.getOrDefault("[]")
}

object VisualDataMapperMethods {
    val Design=VisualDataMapperMethod("visualmapper.design","Region Design Studio","Teach MethodMesh meaningful regions from an image.",RegionInteractionMode.Record)
    val Library=VisualDataMapperMethod("visualmapper.library","Region Design Library","Browse and inspect reusable visual designs.",RegionInteractionMode.Record)
    val Binary=VisualDataMapperMethod("visualmapper.binary","Binary region selector","Tap visual entities to record selected/not selected state.",RegionInteractionMode.Binary)
    val Intensity=VisualDataMapperMethod("visualmapper.intensity","Region intensity scorer","Record an ordinal intensity against visual entities.",RegionInteractionMode.Intensity)
    val Record=VisualDataMapperMethod("visualmapper.record","Region record editor","Record multiple typed variables against visual entities.",RegionInteractionMode.Record)
    val Persistent=VisualDataMapperMethod("visualmapper.persistent","Persistent region map","Maintain named visual state over time.",RegionInteractionMode.Persistent)
    val all=listOf(Design,Library,Binary,Intensity,Record,Persistent)
    fun byId(id:String)=all.firstOrNull{it.id==id}
}
