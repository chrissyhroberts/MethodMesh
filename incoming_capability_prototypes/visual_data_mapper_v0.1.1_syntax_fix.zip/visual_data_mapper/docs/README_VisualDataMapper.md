# Visual Data Mapper — first implementation

Status: **Experimental**  
Connectivity: **Offline**  
Implementation version: **0.1.0**

Visual Data Mapper makes parts of a picture meaningful. The first implementation establishes the canonical module, design model, local raster authoring primitive, reusable design library, binary/intensity/multi-variable runtime interaction and named persistent state.

## Canonical methods

| Method ID | Purpose |
|---|---|
| `visualmapper.design` | Region Design Studio |
| `visualmapper.library` | Browse local visual designs |
| `visualmapper.binary` | Binary region selection |
| `visualmapper.intensity` | Region intensity scoring |
| `visualmapper.record` | Multi-variable region records |
| `visualmapper.persistent` | Named persistent visual map |

These IDs should be treated as public once admitted to the main tree.

## First-version authoring flow

1. Open **Region Design Studio**.
2. Choose a PNG/JPEG training image.
3. Press **Find regions** to create a local Sobel edge map.
4. Tap inside an enclosed area.
5. Name the region.
6. If a fill leaks, Undo/ignore it, enable **Draw boundary**, draw a short closing line, turn the boundary tool off and tap again.
7. Save the design.

The accepted region is stored as run-length encoded raster spans. Runtime does not re-run edge detection.

## Geometry model

The model already distinguishes canonical `geometry`, optional `hitGeometry`, optional `displayGeometry`, and authoring boundaries. v0.1 authoring initially creates one accepted geometry and allows the other geometries to fall back to it.

## Runtime

`visualmapper.binary` and `visualmapper.persistent` are immediate one-tap interactions. `visualmapper.intensity` opens a compact intensity editor. `visualmapper.record` opens a region record editor; if the design does not yet declare variables it provides a note field rather than failing.

Persistent state is stored under `filesDir/visual_data_mapper/states/<state_key>.json` and is explicit structured state. Ordinary bounded methods remain transient until Commit.

## Data outputs

All data-bearing methods declare:

- `visual_status`
- `visual_design_id`
- `visual_design_version`
- `visual_mode`
- `visual_region_count`
- `visual_completed_count`
- `visual_records_json`
- `visual_long_table_json`
- `visual_rendered_image_uri`
- `visual_state_key`
- `visual_full_json`
- `visual_error`

`visual_records_json` is the canonical region-record payload. `visual_long_table_json` projects records into `region_id / variable_id / value` rows.

## ODK

The canonical XLSForm examples in this folder are deliberately one invocation per workbook. They use canonical unprefixed return fields and include `methodmesh_full_json`.

This prototype does not yet implement rendered PNG/SVG attachment generation, so `visual_rendered_image_uri` is currently empty. It is declared now to stabilise the intended contract but must not be represented as working media output until implemented and validated.

## Known first-version limitations

- No presentation-artwork replacement/alignment UI yet; the training image is also the presentation image.
- No SVG import bridge yet.
- No import/export `.mmregion` package yet.
- No rendered PNG/SVG result generation yet.
- No search-to-region, semantic zoom or hierarchical interaction layers yet.
- No independent hit-geometry editor yet.
- No design-schema editor yet; the model supports variables but the first Design Studio does not expose variable construction.
- Completion view control is present as an interaction placeholder but v0.1 rendering does not yet recolour missing/incomplete states separately.
- Region authoring is raster-first; vector contour extraction is not yet implemented.
- No automatic registration-landmark checking yet.

These are intentionally not faked. The first version establishes the working primitive and public boundaries before adding the second-wave UX.

## Validation required before promotion

1. Place this folder at `app/src/main/java/com/example/methodmesh/modules/visualdatamapper/` in the current MethodMesh checkout.
2. Run `./gradlew :app:testDebugUnitTest` and `./gradlew :app:assembleDebug`.
3. Verify module discovery without central registration edits.
4. Create a design from a clean black-and-white image and verify leak repair with Draw boundary.
5. Reopen the saved design and verify stable IDs/hit testing.
6. Verify binary, intensity, record and persistent capability screens.
7. Rotate/recreate the activity during a working result and check state behaviour.
8. Verify preset/protocol invocation and origin-aware closeout.
9. Validate each canonical XLSForm with MethodMesh linter plus pyxform/ODK Validate where available.
10. Test ODK round-trip on device before changing maturity from Experimental.

## Normative parent

This module follows MethodMesh Master Book v1.22. The accompanying v0.04 module specification is module-local and cannot override the Master Book.
