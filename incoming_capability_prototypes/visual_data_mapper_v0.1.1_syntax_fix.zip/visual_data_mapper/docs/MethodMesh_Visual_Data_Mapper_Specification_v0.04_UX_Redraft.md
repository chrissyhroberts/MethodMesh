# MethodMesh Visual Data Mapper

## Module Specification --- UX Redraft v0.04

**Status:** First redraft, cross-referenced and reconciled against
MethodMesh Master Book v1.22\
**Date:** 2026-09-20\
**Working name:** Visual Data Mapper **Normative parent:** MethodMesh
Master Book v1.22 (2026-09-15)\
**Purpose:** Define, use, persist, exchange and analyse structured data
attached to meaningful regions of an image without requiring the visible
artwork itself to expose the underlying region geometry.

------------------------------------------------------------------------

## 1. Product idea

Visual Data Mapper makes parts of a picture meaningful.

Its central interaction model is deliberately simple:

> **Define things → describe things → see patterns.**

During authoring:

> **That area. That is a thing. Call it this.**

During use:

> **That thing. Record this about it.**

During review:

> **Show me this property across all the things.**

The module must preserve this directness even when the underlying
instrument is sophisticated.

It is not primarily a GIS, drawing package, form builder or
image-annotation package. Those systems may provide useful
implementation ideas, but the intended experience is closer to touching
an object in an illustration and immediately recording or viewing
information about it.

The simplest capability must remain almost trivial: show an image, tap a
region, and its state changes.

The same engine must also support serious structured instruments in
which one region represents an entity with multiple typed variables,
validation, persistence, provenance and graphical plus tabular outputs.

------------------------------------------------------------------------

## 1A. UX invariants

Two statements govern the user experience:

> **The picture is not an illustration of the control. The picture is
> the control.**

and, for authoring:

> **Teach MethodMesh what the picture means; do not make the user
> construct a geometry model.**

These are product invariants rather than slogans. Any implementation
that makes ordinary users reason about polygons, masks, coordinate
systems, schemas, computer-vision parameters or storage structures has
leaked implementation detail into the interaction.

The module supports three distinct human experiences which share an
engine but should not be forced into one interface:

1.  **Make** --- create/teach a visual instrument.
2.  **Use** --- touch visual entities to record or change state.
3.  **Read** --- inspect, navigate and understand recorded state.

The Make surface may expose specialist controls progressively. The Use
surface must remain task-first and visually direct. The Read surface
should default to non-destructive exploration.

### 1A.1 Interaction grammar

Unless a capability has a compelling domain-specific reason to differ:

-   **tap** performs the primary action on the visual entity;
-   **long press** inspects details/history or exposes a secondary
    action;
-   **pinch** zooms;
-   **drag** pans when zoomed;
-   **tap-to-copy** applies to useful exposed scalar/text results;
-   destructive actions require deliberate affordances and must not be
    adjacent to high-frequency actions.

For binary interaction, tap itself sets/toggles the state. The user must
not first select a region and then press a redundant "mark" button.

For rich records, tap opens the region's record editor while preserving
spatial context.

### 1A.2 Touch acknowledgement

Because selectable geometry may be invisible, every successful region
hit must acknowledge **which entity MethodMesh resolved** before or as
the action completes.

The acknowledgement should be restrained and fast: for example a brief
outline, halo, pulse, highlight or haptic tick.

Interaction feedback is rendered separately from data visualisation. A
region that is already red because of its data must still have an
unambiguous selected/touched state.

Conceptual render order:

``` text
presentation artwork
        ↓
data visualisation
        ↓
interaction feedback
        ↓
transient controls / labels
```

### 1A.3 Progressive disclosure

The simplest valid interaction must remain the simplest UI.

A binary traveller map must not expose schema configuration merely
because the engine supports multi-variable clinical records.

Advanced controls appear only when the task requires them or the user
explicitly asks for them.

------------------------------------------------------------------------

## 2. Core architectural model

The module separates five concerns that must never be conflated:

1.  **Geometry** --- where selectable regions exist.
2.  **Presentation** --- what the user sees.
3.  **Schema** --- what data may be attached to a region.
4.  **State / observations** --- what has actually been recorded.
5.  **Visualisation** --- how recorded data are projected back onto the
    presentation.

A visible image is therefore not the data model and is not required to
expose region boundaries.

A design may be authored from a simple black-and-white training image
and subsequently presented using elaborate full-colour artwork. Once
regions have been defined, runtime hit-testing uses stored geometry
rather than attempting to rediscover regions from the presentation
pixels.

This permits a polished interface while keeping the underlying polygons
or masks entirely invisible.

------------------------------------------------------------------------

## 3. Relationship to the MethodMesh Master Book

This specification is **module-local**. It defines Visual Data
Mapper-specific behaviour and does not create a second project-wide
architectural authority.

The normative parent is **MethodMesh Master Book v1.22**. Where this
specification and the Master Book conflict, the Master Book wins.

The module follows the Master Book's scientific model:

``` text
Entity
  <- described by Assertion
  <- may be supported by Observation
  <- produced by Method

Intent -> requests Method
Policy -> constrains Method
Provenance -> explains Observation / Assertion lineage
Signal -> communicates change
```

For this module:

-   a selectable visual region normally identifies or resolves an
    **Entity**;
-   values recorded against that region are **Observations** and/or
    support later **Assertions**;
-   binary selection, categorical assignment, intensity scoring,
    region-record editing, rendering and related operations are
    canonical **Methods/capabilities**;
-   a user's request, preset, protocol step or ODK call supplies the
    **Intent** and runtime inputs;
-   validation, allowed values, active layers, persistence policy and
    similar constraints are **Policy/configuration**;
-   committed results retain ordinary MethodMesh **Provenance** and
    audit context.

The geometry, presentation, schema, state and visualisation separation
defined here is an implementation design inside that model. It does not
replace the Master Book's Entity/Observation/Assertion/Method
distinctions.

### 3.1 Golden-rule compliance

The shared MethodMesh shell must not learn Visual Data Mapper-specific
concepts such as teeth, country maps, flood-fill, edge sensitivity,
region layers or choropleth controls. Those remain module-owned.

Shared framework changes are justified only where genuinely generic
across capabilities. This follows **MM-ARCH-001** and **MM-CAP-004**.

### 3.2 One canonical contract, many surfaces

Each independently invokable capability is defined once and projected
through all applicable surfaces: direct native use, dashboard, presets,
protocols, ODK/XLSForm, and schedules/widgets where genuinely
applicable.

The dashboard may aggregate and expose quick actions, but it is never
the implementation boundary. This implements **MM-CAP-001**,
**MM-CAP-003** and **MM-SURF-001**.

### 3.3 Offline-first position

Core design authoring, design-library browsing, region interaction,
persistent local state, rendering and structured export should operate
offline. No cloud computer-vision service is required for edge detection
or region creation.

Any future online catalogue, design source or model-assisted feature
must be additive and must not make core visual interaction dependent on
connectivity.

## 4. Design object

A reusable Visual Data Mapper design contains:

``` text
VisualDesign
├── manifest
├── coordinate_space
├── geometry
│   ├── regions
│   ├── interaction_layers
│   ├── hierarchy
│   └── optional authoring_reference
├── presentation
│   ├── one or more presentation variants
│   └── registration metadata
├── schema
│   ├── region/entity types
│   └── variables
├── visualisation
│   ├── palettes
│   ├── encodings
│   └── legends
└── metadata
    ├── name
    ├── description
    ├── tags
    ├── provenance
    └── version
```

Designs are reusable assets. They do not contain the user's actual
observation state except when explicitly exported together with a state
snapshot.

------------------------------------------------------------------------

## 5. Coordinate space and registration

Geometry is stored in a normalised canonical coordinate space rather
than being tied to a particular raster resolution.

A presentation image may therefore be 1000 × 750 while a high-resolution
replacement is 4000 × 3000, provided both are correctly registered to
the same coordinate space.

Matching aspect ratio alone is not sufficient. A replacement
illustration could preserve dimensions while moving an object.

Each presentation variant must therefore have a registration contract.

The authoring environment must provide:

-   geometry overlay preview;
-   presentation/geometry toggle;
-   registration validation;
-   optional registration landmarks;
-   warning when replacement artwork appears misaligned;
-   explicit confirmation before accepting materially altered artwork.

The design may include an authoring/training image that is never shown
during ordinary use and may optionally be omitted from a runtime-only
export.

------------------------------------------------------------------------

## 6. Region model

A region is a selectable spatial entity, not merely a polygon and not
merely a variable.

A region has at minimum:

-   stable ID;
-   human-readable label;
-   geometry;
-   entity/region type;
-   optional aliases;
-   optional group membership;
-   optional parent/child relationships;
-   interaction priority;
-   metadata.

A logical region may contain multiple disconnected shapes.

Regions may overlap.

Visible artwork and hit geometry may differ deliberately. Tiny regions
may have larger invisible hit targets.

A region may also have a runtime availability state such as:

-   active;
-   absent;
-   disabled;
-   not applicable;
-   unknown.

Availability state is distinct from variables recorded about the entity.

------------------------------------------------------------------------

### 6.1 Four related geometries

The implementation must not assume that one polygon is sufficient for
every purpose.

A region may distinguish:

1.  **Region geometry** --- the canonical spatial extent represented by
    the entity.
2.  **Hit geometry** --- where touch/input resolves to the entity.
3.  **Display geometry** --- where visual overlays are rendered.
4.  **Authoring boundary geometry** --- boundaries used during
    flood-fill/training.

These default to the same geometry and should not be duplicated
unnecessarily.

They may diverge where UX requires it. For example, a small island state
may retain geographically meaningful region/display geometry while using
an enlarged invisible hit target. A simplified black-and-white training
image may use different authoring boundaries from the polished
presentation artwork.

Design Studio Test mode must be able to reveal hit geometry
independently through **Show touch areas**.

## 7. Hierarchical and layered regions

The region model must not assume a single flat non-overlapping
segmentation.

A design may contain multiple **interaction layers**.

Example vehicle design:

-   exterior components;
-   damage panels;
-   mechanical systems.

Example dental design:

-   whole teeth;
-   tooth surfaces.

Example anatomical design:

-   external body areas;
-   deeper anatomical structures.

A region may contain child regions. Runtime behaviour may allow
drill-down from parent to child, particularly after zooming or
explicitly changing interaction layer.

Where multiple selectable regions genuinely occupy the tapped
coordinate, the runtime may present a compact disambiguation chooser.
This should occur only where ambiguity cannot be resolved through
interaction priority, active layer or context.

------------------------------------------------------------------------

## 7A. Navigation, search and semantic zoom

Precise tapping must not be the only route to a region.

Runtime should provide **search-to-region** where appropriate. Searching
for `Barbados`, `tooth 26`, `left ankle` or `valve 4` navigates the
visual surface to the corresponding entity, highlights it and permits
the ordinary interaction to continue.

Search is therefore navigation into the picture, not a competing
list-based data-entry system.

Zoom may alter presentation detail, labels, callouts and practical hit
targets.

Designs may support hierarchical drill-down such as:

``` text
tooth
  ↓ deliberate drill-down / close zoom
tooth surface
```

However, zoom alone must not silently change the meaning of a tap where
that could cause accidental data entry. A change in active interaction
layer requires an obvious visual cue or explicit action.

## 8. Authoring: Design Studio

Design Studio is intentionally separate from ordinary runtime use.

Its purpose is to turn an ordinary image into a reusable structured
visual design with minimal geometric labour.

### 8.1 Primary authoring flow

``` text
Import training image
        ↓
Detect edges
        ↓
Repair boundaries
        ↓
Tap/fill candidate regions
        ↓
Name and identify regions
        ↓
Attach schema
        ↓
Add presentation artwork
        ↓
Configure visualisation
        ↓
Test
        ↓
Validate
        ↓
Save to library
```

### 8.2 Edge-assisted region creation

For simple black-and-white source images, the system should offer
automatic boundary extraction using a pipeline conceptually equivalent
to:

``` text
grayscale
→ smoothing
→ edge detection
→ gap repair / morphological closing
→ candidate enclosed regions
```

The algorithm is an authoring accelerator only. It must never become a
requirement that source images contain automatically detectable closed
shapes.

### 8.3 Manual boundary tools

The essential repair workflow is:

> Tap region → fill leaks → undo → draw short closing boundary → tap
> again.

Required tools:

-   draw boundary freehand;
-   draw straight boundary;
-   erase boundary;
-   undo;
-   redo;
-   pan;
-   zoom;
-   flood-fill/select enclosed region;
-   merge regions;
-   split region;
-   paint/add region;
-   remove region.

A future lasso or brush-selection tool may be added where useful.

The editor should not attempt to become a general-purpose graphics
application.

### 8.4 Region labelling

Selecting a candidate region opens a compact inspector:

``` text
Region
Name        Upper left first molar
ID          tooth_26
Type        Tooth
Group       Upper arch
Schema      Dental examination
```

Stable IDs must not silently change when labels are edited.

Bulk labelling, duplicate-pattern workflows and sequential naming should
be supported for designs with many similar regions.

### 8.5 Edit/Test mode

Rapid switching between **Edit** and **Test** is a core interaction.

Edit shows authoring scaffolding.

Test hides authoring geometry, loads the chosen presentation artwork and
behaves as the eventual runtime instrument.

Authors should be able to discover bad hit areas, ambiguous selection
and registration errors without exporting or leaving the studio.

------------------------------------------------------------------------

## 9. Presentation layer

Presentation artwork is independent of geometry.

A design may contain multiple registered presentation variants, for
example:

-   full-colour;
-   simplified;
-   high contrast;
-   clinical;
-   child-friendly;
-   language-specific;
-   branded;
-   respondent-facing;
-   assessor-facing;
-   blinded/unblinded.

The preset or calling workflow may choose the presentation variant.

The visible artwork need not reveal the boundaries, number or structure
of the underlying selectable regions.

This separation is intentional and supports both aesthetic design and
workflows in which exposing the segmentation would distract, bias or
otherwise alter the user's interaction.

------------------------------------------------------------------------

### 9.1 Presentation replacement and alignment

Adding polished artwork should feel like placing a presentation skin
over a trained stencil.

After selecting presentation artwork, Design Studio overlays the
canonical geometry and asks the author to verify alignment in visual
language such as:

> **Does this line up?**

The author may compare training and presentation images using opacity,
overlay or a draggable before/after divider.

Only if alignment fails should controls such as **Align artwork** or
registration landmarks become prominent.

The user-facing workflow should not require understanding coordinate
registration even though the underlying contract remains rigorous.

## 10. Region schemas and multiple variables

A region may have zero, one or many variables.

The same schema may apply to all regions, to a region type, to a group,
or to an individual region where justified.

Supported field semantics should reuse MethodMesh/ResearchOS conventions
rather than create an isolated forms system.

Expected types include:

-   binary;
-   categorical single select;
-   categorical multi-select;
-   ordinal;
-   integer;
-   decimal;
-   free text;
-   date;
-   time;
-   date-time;
-   counter;
-   sequence/order;
-   duration where appropriate;
-   image/media attachment;
-   calculated value.

Variables may define:

-   choices;
-   units;
-   range;
-   required status;
-   constraints;
-   relevance/conditional visibility;
-   calculations;
-   default values;
-   help text;
-   visualisation rules.

### 10.1 Dental example

Tapping tooth 26 may expose:

``` text
Tooth 26

Caries        None / Present
Enamel        Sound / Mild / Moderate / Severe
Restoration   None / Amalgam / Composite / Crown / Other
Pain          0–10
Notes         …
```

Saving returns to the chart without losing spatial context.

The tooth is the entity. Caries, enamel condition and restoration are
observations/attributes associated with that entity.

------------------------------------------------------------------------

## 10A. MethodMesh working-result and Commit lifecycle

Visual Data Mapper uses the ordinary MethodMesh native lifecycle rather
than a private save/finalise model.

During an interactive run, edits create a **live working result**. The
visual surface updates immediately as the user works. Meaningful working
state must survive ordinary Android lifecycle changes where feasible.

**Commit** is the finalisation boundary:

-   Commit freezes the canonical payload for that execution;
-   editing after Commit must not silently mutate the committed payload;
-   post-Commit actions may expose Return, Share, Save/Export and
    audit/full-JSON actions as appropriate;
-   no arbitrary generic result screen is inserted merely for framework
    convenience;
-   Done/Home/closeout returns to the correct launch origin.

This implements **MM-UX-002**, **MM-UX-004**, **MM-UX-005**,
**MM-UX-006**, **MM-UX-007** and **MM-UX-008**.

For persistent-state presets, state changes still require a clearly
defined confirmation/commit and correction model. Persistence must not
arise accidentally merely because the screen is stateful.

## 11. Runtime interaction principles

The picture is the primary interface.

The default screen must not look like a form with an illustration
attached.

For simple binary use:

> **See it → tap it → it changes.**

For richer schemas:

> **See it → tap it → describe it → return.**

Complexity appears only when required.

### 11.0 Runtime visual hierarchy

The artwork normally owns the screen.

A simple capability should require little more than navigation, title,
dominant visual, a compact result/progress indicator and optional
legend/view selector.

No authoring controls, polygon vocabulary or schema controls appear
during ordinary use.

Phone and larger-screen layouts use the same capability contract but
different composition:

-   **phone portrait:** visual surface above; contextual sheet rises
    from the bottom;
-   **phone landscape:** visual and editor share space where practical;
-   **tablet/foldable/large screen:** visual surface and record
    inspector may sit side-by-side.

Layouts must be recomposed rather than merely stretched.

### 11.1 Simple mode

A world-travel map may show:

-   artwork;
-   current filled state;
-   concise progress indicator;
-   optional legend.

Tapping a country toggles or sets its state.

No schema controls are exposed unless requested.

### 11.2 Rich region mode

Tapping a region with multiple variables opens a compact bottom sheet on
phones and an adjacent panel where screen space permits.

The image remains visible.

Any visible scalar or textual result that is meaningfully returnable
should support tap-to-copy of the useful value, following **MM-UX-003**.
Region IDs, counts, scores and other exposed values should copy the
value rather than decorative labels unless the capability contract
explicitly defines otherwise.

The panel must not navigate the user away from the visual context.

It may provide:

-   region name;
-   region status;
-   fields;
-   previous/next region;
-   done/close;
-   undo where relevant.

For systematic examinations, the user may advance sequentially through
regions without repeatedly reopening the panel.

### 11.3 Long press / secondary action

Long press or an explicit details affordance may expose richer history
or metadata without burdening the normal tap interaction.

For a traveller map this could show:

-   visited;
-   first visit;
-   most recent visit;
-   visit count;
-   purpose;
-   notes.

------------------------------------------------------------------------

### 11.4 Read / Explore behaviour

The same visual instrument may be opened for non-destructive review.

In **Read/Explore** context:

-   tapping inspects rather than mutates;
-   the active visualisation remains visible;
-   history/details may be opened;
-   search navigates to regions;
-   editing requires an explicit transition or an editing launch
    context.

The preset/launch context should normally establish this behaviour
rather than forcing users to manage a prominent global mode switch.

## 12. Interaction modes

The same geometry can support multiple methods/presets.

Core modes include:

-   binary selection;
-   categorical assignment;
-   multi-category recording;
-   sequence/order capture;
-   intensity scoring;
-   numeric entry;
-   choropleth numeric mapping;
-   counter/increment;
-   timestamp/event marking;
-   multi-variable region record;
-   persistent region state.

These are runtime behaviours over a common design model, not separate
geometry formats.

------------------------------------------------------------------------

## 12A. Completion as a spatial view

For structured/professional workflows, **Completion** is a first-class
visualisation.

The visual surface should answer:

> What have I not dealt with yet?

The rendering must distinguish at least where relevant:

-   no record / unexamined;
-   started but incomplete;
-   complete with negative/zero result;
-   complete with positive/non-zero result;
-   absent/not applicable/disabled;
-   validation problem.

A negative finding must never be visually indistinguishable from missing
data.

When Commit is attempted with incomplete required data, the preferred
response is to switch/highlight the relevant regions spatially and offer
direct navigation to them, rather than presenting only a detached
validation-error list.

Policy determines whether incomplete Commit is prohibited, warned or
allowed.

## 13. Visual encoding

Recorded data and graphical appearance must remain separate.

A design may define default encodings; a preset may override them
without modifying the master design.

Supported encodings should include:

-   fill;
-   opacity;
-   outline;
-   line weight;
-   pattern;
-   icon/badge;
-   text/label;
-   marker;
-   combinations of the above.

Colour must never be the only available information channel.

### 13.1 Configurable colours

Designers may configure:

-   unselected appearance;
-   selected appearance;
-   missing/unknown appearance;
-   disabled appearance;
-   categorical palettes;
-   ordinal palettes;
-   numeric gradients;
-   choropleth breaks;
-   outlines;
-   label colours;
-   overlay opacity.

Numeric visualisations may use continuous gradients or discrete
breakpoints.

The numeric value remains authoritative regardless of how it is
rendered.

### 13.2 Variable views

Where regions contain multiple variables, the runtime should provide a
compact **View** selector.

For a dental chart:

-   Caries;
-   Enamel;
-   Restoration;
-   Pain;
-   Completion.

For a traveller map:

-   Visited;
-   Number of visits;
-   First visit;
-   Work;
-   Holiday.

The same stored data can therefore be projected through several visual
views.

A completion view is especially useful in professional data collection
because the visual instrument doubles as a live completeness check.

------------------------------------------------------------------------

## 14. Persistent state and ordinary observations

Two broad usage patterns must be supported.

### 14.1 Observation mode

An invocation creates a bounded result.

Examples:

-   dental examination;
-   body pain assessment;
-   machine inspection;
-   crop assessment.

The user reviews and commits the result through the normal MethodMesh
lifecycle.

### 14.2 Persistent-state mode

A named state evolves over time.

Examples:

-   countries visited;
-   football grounds visited;
-   bird sightings;
-   renovation progress;
-   collection completion;
-   long-running equipment status.

Persistent state is still explicit structured state. UI colour is never
the source of truth.

Changes must be represented through appropriate
Transformations/provenance rather than silently inferred from the latest
rendering.

------------------------------------------------------------------------

## 15. Undo, correction and auditability

Mistakes are inevitable and correction must be exceptionally easy.

Runtime should provide immediate undo after changes.

The state engine should retain sufficient change history to support
robust correction.

For casual use, this may appear simply as Undo.

For governed/professional use, the same mechanism can contribute to an
audit trail recording:

-   original value;
-   corrected value;
-   region;
-   variable;
-   timestamp;
-   execution;
-   method;
-   relevant identity/context where required.

Authoring operations also require undo/redo.

------------------------------------------------------------------------

## 16. Design Library

Visual designs are inherently recognisable by appearance, so the library
should be visually led rather than a purely textual file list.

Each item should show:

-   preview thumbnail;
-   name;
-   short description;
-   category/tags;
-   region count;
-   supported interaction/schema summary;
-   version where relevant.

Example library items:

``` text
World Countries
195 regions
Geography · Binary · Numeric · Choropleth

Dental Chart
32 teeth
Clinical · Multi-variable

Body Map
48 regions
Clinical · Binary · Intensity

Vehicle Inspection
27 regions
Inspection · Multi-variable
```

Actions should include:

-   Use;
-   Edit;
-   Duplicate;
-   Create preset;
-   Export;
-   Delete/archive where permitted.

Search, filters and categories remain available, but visual recognition
should be prominent.

### 16.1 Creating a design

The entry points should be concise:

-   Start from image;
-   Import design;
-   Start from SVG.

The existing SVG route and raster-assisted route must converge on the
same canonical region model.

------------------------------------------------------------------------

### 16.2 Designs versus saved maps/state

The library must not conflate reusable designs with instances of
persistent user state.

**Designs** are reusable instruments/templates, such as
`World Countries`, `Dental Chart` or `Vehicle Inspection`.

**Saved maps/state** are named persistent instances, such as `My World`
or `House renovation`.

Professional observations/executions ordinarily remain in the normal
research/data flow rather than being mixed into the design library.

The UI should make this distinction visually obvious while allowing a
design to create a new persistent instance where appropriate.

### 16.3 First-run demonstrations

An empty visual library is a poor introduction.

Where bundled examples are appropriate, the module should offer a very
small set demonstrating qualitatively different interactions, for
example:

-   **My World demo** --- binary persistent interaction;
-   **Body Map demo** --- intensity scoring;
-   **Dental demo** --- multi-variable region records.

The purpose is to teach the interaction model by use rather than
documentation.

## 17. Import and export

Designs must be portable.

A lossless MethodMesh design package should contain everything required
to reconstruct the design.

Illustrative package:

``` text
world_countries.mmregion
├── manifest.json
├── geometry/
│   ├── regions.json
│   └── geometry.svg
├── presentation/
│   ├── default.png
│   └── high_contrast.png
├── authoring/
│   └── training_reference.png
├── schema/
│   └── variables.json
├── visualisation/
│   └── styles.json
└── preview.png
```

The exact internal filenames may evolve, but the package contract must
be versioned.

Import should support at minimum:

-   MethodMesh region-design package;
-   SVG;
-   PNG;
-   JPEG.

PNG/JPEG imports create a new design and enter authoring.

SVG imports should preserve usable paths where possible and avoid
unnecessary rasterisation.

Imported completed design packages become library items rather than
temporary open files.

Export options should include:

-   complete editable design package;
-   runtime-only design package where appropriate;
-   standalone SVG geometry;
-   presentation/rendered PNG;
-   region definition table;
-   optional state snapshot when explicitly requested.

------------------------------------------------------------------------

## 18. SVG interoperability

The existing SVG picker should not become a competing architecture.

SVG-native authoring and raster-assisted authoring must produce the same
canonical region representation.

Raster-derived regions should be traceable to vector contours/paths
where practical.

This allows:

``` text
ordinary image
→ edge-assisted region definition
→ canonical region geometry
→ optional SVG export
```

and:

``` text
SVG
→ canonical region geometry
→ same runtime
```

Existing stable method IDs and contracts should be preserved where
integration permits.

------------------------------------------------------------------------

## 19. Outputs

Every data-bearing invocation should be capable of producing structured
and graphical outputs.

### 19.1 Structured output

The authoritative result is structured data.

Long form example:

  region_id   region_label   variable_id   value
  ----------- -------------- ------------- -----------
  tooth_26    Tooth 26       caries        present
  tooth_26    Tooth 26       enamel        moderate
  tooth_26    Tooth 26       restoration   composite

Wide representations may also be generated where appropriate:

  region_id   caries    enamel     restoration
  ----------- --------- ---------- -------------
  tooth_26    present   moderate   composite

### 19.2 Graphical output

The module should generate an annotated/rendered image reflecting a
selected visualisation.

Expected formats:

-   PNG;
-   SVG where practical.

The output may include:

-   title;
-   legend;
-   labels;
-   selected variable/view;
-   timestamp/context where appropriate.

The graphical output is a rendering, not the authoritative data store.

### 19.3 Analytical outputs

Because data remain structured, downstream methods can produce ordinary
charts, summaries, counts, distributions and tables without image
parsing.

------------------------------------------------------------------------

## 19A. Commit and validation UX

Commit must remain recognisably MethodMesh while fitting the visual
instrument.

For bounded professional collection, a compact completion/Commit
affordance may sit below or alongside the visual surface, for example:

``` text
28 / 32 complete                         Commit
```

When all required regions are complete:

``` text
32 / 32 complete                         Commit
```

If Commit is requested while required data are missing, the system
should prefer a spatial response:

> **4 areas still need data**

and switch to/highlight Completion view, with actions such as **Review
missing** and, only where policy allows, **Commit anyway**.

For casual persistent-state presets, forcing a global Commit after every
one-tap change would violate the direct interaction model. Such presets
may define immediate confirmed persistence with Undo/history, while
still using explicit MethodMesh state/provenance semantics underneath.

## 20. ODK and external round trip

ODK parity is mandatory.

Every independently callable Visual Data Mapper capability remains
addressable through the same canonical MethodMesh contract used
natively. The ODK projection must not invent a second schema or omit
declared outputs merely because they are uncommon.

A calling form/workflow should be able to:

1.  launch a specific visual method/preset;
2.  provide canonical initial values/context where permitted;
3.  request direct or interactive acquisition as supported;
4.  allow visual interaction where required;
5.  receive canonical structured result fields;
6.  receive rendered image/SVG artefacts where declared;
7.  receive `methodmesh_full_json` on every handled ODK/external round
    trip;
8.  resume the originating workflow after Commit or Cancel according to
    the shared transport contract.

For multi-variable regions, external output preserves stable region IDs
and variable IDs. ODK receives conventional structured values plus
optional binary artefacts; it does not need to understand geometry.

### 20.1 Binary outputs

Rendered PNG/SVG or other media returned to ODK must be real submission
attachments through the shared transport contract, not private
MethodMesh filesystem paths or opaque local URIs presented as the useful
payload.

Temporary `content://` transport URIs may be used internally with
required Android grants, but they are plumbing rather than the ODK
result.

An ODK/external invocation must not create an additional MethodMesh
archive copy merely "just in case". The caller owns persistence of the
returned submission attachment unless another explicit user-selected
persistence policy applies.

### 20.2 Canonical XLSForm examples

The module's `docs/` directory contains focused canonical showcase
XLSForms.

Each canonical workbook:

-   demonstrates exactly **one** MethodMesh capability invocation;
-   uses `example_odk_showcase_<purpose>.xlsx`;
-   uses canonical unprefixed return fields;
-   does not require `methodmesh_return_namespace`;
-   captures declared returns relevant to that invocation plus
    `methodmesh_full_json`;
-   does not invent success, timestamp or capability-specific JSON
    fields not declared by the runtime contract.

Where genuinely different invocation modes need separate demonstrations,
provide separate single-invocation workbooks.

## 21. Presets and protocols

A design is not a preset.

A **design** defines spatial entities, presentation and available
schema.

A **preset** defines how that design is being used, including:

-   active interaction layer;
-   active schema;
-   interaction mode;
-   presentation variant;
-   palette/style overrides;
-   allowed values;
-   defaults;
-   validation;
-   output configuration;
-   persistence behaviour.

A **protocol** may compose visual methods with other MethodMesh methods.

Example:

``` text
Dental examination protocol
→ open Dental Chart preset
→ require completion of specified teeth
→ calculate summary
→ capture photograph if indicated
→ commit result
```

All canonical capabilities must remain available independently of
dashboard access so they can participate in presets, protocols and
external invocation.

------------------------------------------------------------------------

## 22. Casual-use examples

The module should deliberately support low-friction personal uses
because these are strong tests of whether the interaction has remained
direct.

Examples include:

-   countries visited;
-   countries worked in;
-   football grounds visited;
-   birds seen;
-   museums visited;
-   hiking sections completed;
-   garden planting plan;
-   rooms decorated;
-   renovation progress;
-   collection completion;
-   board-game campaign state;
-   body areas exercised;
-   vehicle maintenance history.

A casual design should not expose professional data-management concepts
unless the user asks for them.

A traveller map should feel like a beautiful persistent map, not like a
database editor.

------------------------------------------------------------------------

## 23. Professional-use examples

Potential uses include:

-   dental examination;
-   anatomical symptom mapping;
-   wound/injury mapping;
-   equipment inspection;
-   vehicle inspection;
-   specimen annotation;
-   pathology diagrams;
-   crop/plot assessment;
-   laboratory rack or plate position recording;
-   storage layout;
-   household/facility diagrams;
-   participatory visual assessment;
-   structured image-based case report forms.

The module should not hard-code any of these domains. They are
applications of the generic region/entity model.

------------------------------------------------------------------------

## 24. UI character

The desired runtime feeling is:

-   direct;
-   tactile;
-   calm;
-   visually rich where the design warrants it;
-   minimal chrome;
-   native;
-   forgiving;
-   immediately reversible.

The artwork should normally dominate the screen.

Runtime should avoid permanent toolbars full of authoring controls.

A simple capability may need little more than:

``` text
Back      Title                 ⋮

        [ dominant artwork ]

           47 / 195

       [optional legend]
```

A multi-variable capability adds a bottom sheet or side inspector only
when a region is selected.

Animations should be restrained and functional: a soft fill, outline or
state transition confirming the tap rather than decorative motion.

The module should inherit MethodMesh's restrained visual language while
allowing individual designs to be colourful or illustrative.

------------------------------------------------------------------------

### 24.1 Field and one-handed use

The runtime must assume that some users will operate it standing,
walking between stations, wearing gloves, holding equipment or using
only one hand.

Therefore:

-   routine targets are generous;
-   precision tapping is avoided where alternatives exist;
-   high-frequency controls remain thumb-accessible;
-   Previous/Next and Undo are easy to reach;
-   zoom/pan gestures do not accidentally record values;
-   destructive actions are separated from routine actions;
-   no hover interaction is required;
-   portrait is first-class;
-   landscape/large screens recompose intelligently.

### 24.2 Motion and haptics

Animation is functional rather than decorative.

Useful motion includes:

-   touch acknowledgement;
-   a restrained state transition after recording;
-   map/diagram movement after search;
-   bottom-sheet/inspector transitions;
-   completion highlighting.

Haptics may confirm a successful region action where device/platform
settings permit. Neither motion nor haptics may be the sole feedback
channel.

## 25. Accessibility and difficult geometry

The design must work without relying solely on precise tapping or colour
perception.

Required considerations:

-   zoom/pan;
-   minimum practical hit areas;
-   enlarged invisible hit targets;
-   region search/list fallback;
-   keyboard/switch-access compatible selection where platform support
    allows;
-   colour-independent state encodings;
-   high-contrast presentation variants;
-   optional labels;
-   accessible descriptions for regions;
-   disambiguation for overlaps.

Tiny geographic areas such as island states must remain selectable even
when their literal geometry would be impractical at screen scale.

A design may use a callout/inset or enlarged hit target while preserving
the same region identity.

------------------------------------------------------------------------

## 26. Failure modes and defensive design

### 26.1 Leaking flood fill

Cause: incomplete boundaries.

Response: immediate undo plus manual boundary closure.

### 26.2 Excess internal detail

Cause: text, shading or decorative lines create unwanted regions.

Response: sensitivity controls, ignore-small-region filtering,
merge/paint tools and the ability to use a deliberately simplified
training image.

### 26.3 Presentation misregistration

Cause: artwork replaced without preserving object positions.

Response: overlay validation, landmarks and warning before acceptance.

### 26.4 Ambiguous overlap

Cause: multiple active regions share a coordinate.

Response: active interaction layers, priority rules and compact
disambiguation when necessary.

### 26.5 Tiny regions

Cause: literal geometry is smaller than a reliable touch target.

Response: invisible expanded hit geometry, zoom, inset or searchable
fallback.

### 26.6 Changed labels breaking data

Cause: human-readable name edited.

Response: immutable/stable region IDs independent of labels.

### 26.7 Design revision breaking historical state

Cause: geometry/schema changes after data have been collected.

Response: version designs and schemas; retain the design version
associated with observations.

### 26.8 Appearance mistaken for state

Cause: UI rendering treated as authoritative.

Response: state remains explicit structured Knowledge; appearance is
always derived.

### 26.9 Over-engineering simple uses

Cause: exposing schemas and forms for binary maps.

Response: progressive disclosure and mode-specific runtime surfaces.

### 26.10 Incomplete professional records

Cause: visually plausible chart hides unvisited regions.

Response: optional completion visualisation, validation and explicit
commit checks.

------------------------------------------------------------------------

## 27. Design versioning

Published/used designs must be versionable.

Changes fall broadly into:

-   presentation-only changes;
-   metadata changes;
-   geometry changes;
-   schema changes;
-   interaction changes.

Presentation-only revisions may remain compatible with existing state if
registration and identifiers are unchanged.

Geometry or schema changes require explicit compatibility assessment.

Historical observations must retain enough information to identify the
design/schema version under which they were created.

------------------------------------------------------------------------

## 28. Validation before publication

Design Studio should provide a validation step covering at minimum:

-   duplicate region IDs;
-   unlabeled regions;
-   invalid geometry;
-   unreachable/tiny hit regions;
-   ambiguous overlaps;
-   presentation registration;
-   missing schema references;
-   invalid visualisation references;
-   unsupported palette values;
-   broken hierarchy;
-   missing required assets.

A test mode should allow the author to tap every region and inspect the
resolved identity.

For larger designs, an automated region coverage report is desirable.

------------------------------------------------------------------------

## 29. Initial canonical capabilities

The first implementation should expose individual capabilities rather
than only a dashboard.

Proposed capability set:

1.  **Region Design Studio** --- create/edit region designs.
2.  **Region Design Library** --- browse/use/import/export designs.
3.  **Binary Region Selector** --- one-tap selected/unselected
    recording.
4.  **Categorical Region Selector** --- assign categories.
5.  **Sequential Region Selector** --- record order.
6.  **Region Intensity Scorer** --- ordinal/intensity values.
7.  **Numeric Region Mapper** --- numeric values and choropleth
    rendering.
8.  **Region Record Editor** --- multi-variable records attached to
    regions.
9.  **Persistent Region Map** --- long-lived named state.
10. **Region Renderer** --- render structured state to PNG/SVG.
11. **Region Data Exporter** --- structured table/result generation.

A later implementation may consolidate UI entry points while preserving
these independently addressable method contracts.

------------------------------------------------------------------------

## 30. Reference implementations

The first release should include at least two deliberately contrasting
reference designs.

### 30.1 World Traveller

Purpose: prove the casual persistent-state path.

Requirements:

-   world-country regions;
-   attractive full-colour or restrained presentation artwork;
-   invisible canonical hit regions;
-   binary `visited`;
-   optional richer fields such as first visit, most recent visit, visit
    count, purpose and notes;
-   persistent preset state;
-   visited-count summary;
-   alternate variable views;
-   PNG/SVG and table output.

### 30.2 Dental Chart

Purpose: prove multi-variable professional region records.

Requirements:

-   adult dentition design;
-   tooth IDs/labels;
-   polished presentation separate from authoring geometry;
-   multi-variable schema including example caries, enamel and
    restoration fields;
-   region status including absent/not applicable where appropriate;
-   completion view;
-   previous/next workflow;
-   structured long/wide output;
-   rendered examination image;
-   ODK round trip.

These two examples intentionally stress opposite ends of the same
architecture.

------------------------------------------------------------------------

## 30A. Module ownership and handoff structure

Implementation is admitted/returned as one clean module folder under the
normal MethodMesh module contract.

Conceptually:

``` text
visual_data_mapper/
├── VisualDataMapperModule.kt
├── <Capability>Method.kt
├── <Capability>CapabilityScreen.kt
├── module-owned geometry/rendering/editor helpers
├── module-owned persistence/repository code where justified
└── docs/
    ├── README.md
    ├── this module specification
    ├── validation/implementation notes
    └── example_odk_showcase_<purpose>.xlsx
```

The exact Kotlin decomposition follows implementation needs rather than
creating ornamental service/repository layers.

Each independently invokable capability requires a clearly identifiable
canonical method implementation. A rich Design Library or dashboard must
not collapse those capabilities into private UI actions.

This follows **MM-MOD-001**, **MM-CAP-004** and the Master Book
module-local ownership rules.

## 31. Recommended first implementation boundary

The first build should prioritise the architectural primitive and
interaction quality over sophisticated computer vision.

Required for first usable implementation:

-   import raster image;
-   basic edge detection;
-   sensitivity control;
-   flood-fill region creation;
-   manual line closure;
-   erase;
-   merge;
-   stable region IDs and labels;
-   canonical normalised geometry;
-   separate presentation artwork;
-   geometry overlay/test mode;
-   binary interaction;
-   multi-variable region interaction;
-   configurable colours;
-   persistent state;
-   structured output;
-   rendered PNG output;
-   design library;
-   import/export package;
-   preset compatibility;
-   ODK/external result contract.

Can follow after the primitive is proven:

-   sophisticated automatic gap repair;
-   automatic artwork registration;
-   advanced lasso tools;
-   complex nested region authoring;
-   multiple simultaneous interaction layers;
-   automatic contour simplification tuning;
-   advanced SVG optimisation;
-   elaborate analytical visualisations.

The first version should nevertheless choose data structures that do not
preclude these extensions.

------------------------------------------------------------------------

## 32. Acceptance principles

The module is succeeding when all of the following are true:

1.  A non-specialist can turn a clean black-and-white diagram into
    selectable labelled regions without manually tracing every polygon.
2.  A designer can replace that training diagram with polished
    registered artwork without changing region identities.
3.  A user can operate a binary map without encountering authoring or
    schema concepts.
4.  A user can tap a region and efficiently record several variables
    without losing visual context.
5.  The same region geometry can support several methods/presets and
    several visual views.
6.  Persistent personal state survives normal app lifecycle and remains
    explicit/queryable.
7.  Professional observations produce conventional structured data.
8.  Every data-bearing workflow can produce a graphical rendering as
    well as structured output.
9.  Designs can be imported, exported, versioned and reused from a
    visual library.
10. SVG-native and raster-assisted designs use one underlying model.
11. ODK/external workflows receive stable structured values rather than
    needing to interpret the image.
12. Runtime remains visually calm and direct despite the sophistication
    of the underlying engine.

------------------------------------------------------------------------

## 32A. UX-redraft review decisions

The v0.03 cross-referenced specification was reviewed specifically for
interaction failure rather than architecture.

The review identified and corrected the following risks:

-   **The image could have remained an illustration beside conventional
    controls.** The picture is now explicitly the primary control.
-   **Invisible polygons could feel uncertain.** Touch acknowledgement
    is now normative.
-   **Selection feedback could conflict with data colours.** Interaction
    feedback is a separate render layer.
-   **Tiny regions could remain technically selectable but practically
    miserable.** Hit geometry is now distinct from region/display
    geometry and search-to-region is included.
-   **One geometry object was doing too many jobs.** Region, hit,
    display and authoring geometries are explicitly separable.
-   **Rich region editing could become repeated mini-form navigation.**
    Spatial context, live working state and Previous/Next traversal are
    required.
-   **Completion could remain a detached validation concept.**
    Completion is now a first-class spatial visualisation.
-   **Authoring could open with computer-vision configuration.** It now
    starts with image → Find regions and progressively discloses tuning.
-   **Boundary repair could become topology editing.** The required
    mental model is leak → Undo → draw line → fill again.
-   **Presentation registration could be technically correct but
    opaque.** It is expressed as visual alignment/testing.
-   **Design and persistent state could become mixed in one library.**
    Designs and saved maps/state are explicitly distinct.
-   **Read-only review could accidentally mutate data.** Read/Explore
    behaviour is explicit.
-   **Professional negative findings could look like missingness.**
    Completion semantics explicitly distinguish them.
-   **Responsive behaviour could mean simple stretching.** Phone/tablet
    composition is now specified.
-   **Casual persistent use could feel sterile.** Optional restrained
    milestone feedback is permitted at preset level without
    contaminating the scientific model.

## 33. First-redraft review decisions

The initial concept was reviewed immediately before this redraft. The
following issues were identified and incorporated rather than deferred:

-   **Aspect ratio alone was too weak.** Presentation assets now require
    registration validation.
-   **A flat polygon list was too restrictive.** The model now allows
    disconnected, overlapping, hierarchical and layered regions.
-   **Edge detection was at risk of becoming the architecture.** It is
    now explicitly only an authoring accelerator.
-   **Region values and entity availability were conflated.** Region
    status is now separate from attached variables.
-   **Colour-only rendering was too fragile.** Multiple visual channels
    are required.
-   **Persistent colour could have become implicit state.** Structured
    state and explicit Transformations remain authoritative.
-   **Replacing artwork could silently invalidate hit testing.** Design
    versioning and registration checks are required.
-   **Professional completeness was insufficiently visible.** Completion
    is now a first-class visualisation.
-   **Simple personal logging risked inheriting form-builder
    complexity.** Progressive disclosure is now an explicit runtime
    principle.
-   **SVG and raster workflows risked diverging.** They now converge on
    one canonical region model.
-   **Tiny and overlapping targets were under-specified.** Enlarged hit
    geometry, zoom, layers and disambiguation are included.
-   **Correction/audit behaviour was under-specified.** Undo and change
    history are now explicit.
-   **The library was initially treated too much like file storage.** It
    is now specified as a visual, reusable design library.
-   **Multi-variable regions needed a stronger runtime model.**
    Bottom-sheet/side-panel editing preserves spatial context and
    supports sequential examination.

This first redraft therefore treats the module not as an image-filling
utility but as a general visual entity interface: geometry defines *what
can be touched*, schema defines *what can be known about it*,
presentation defines *what is seen*, and visualisation defines *how
state is shown back to the user*.

------------------------------------------------------------------------

## 33A. MethodMesh Master Book v1.22 conformance cross-reference

This table is a navigation aid. The Master Book prose remains normative.

  ---------------------------------------------------------------------
  Master Book requirement / doctrine Visual Data Mapper application
  ---------------------------------- ----------------------------------
  **MM-DOC-001--003**                This is module-local documentation
                                     and belongs with the module's
                                     `docs/` material.

  **MM-ARCH-001**                    Edge detection, region geometry,
                                     schemas, visual layers and
                                     specialised UI remain
                                     module-owned.

  **MM-ARCH-002--004**               Regions resolve Entities; recorded
                                     values are Observations/support
                                     Assertions; capabilities are
                                     Methods; structured state remains
                                     separate from
                                     rendering/orchestration.

  **MM-ARCH-005**                    Module/capability discovery is
                                     metadata driven, not a central
                                     special-case list.

  **MM-ARCH-006**                    Stable region IDs, variable IDs
                                     and public method contracts are
                                     versioned and extended rather than
                                     casually broken.

  **MM-CAP-001**                     One canonical method contract
                                     serves native, dashboard, preset,
                                     protocol and ODK surfaces.

  **MM-CAP-002**                     Once admitted, method IDs and
                                     declared input/output semantics
                                     are stable.

  **MM-CAP-003**                     Library/dashboard aggregation
                                     cannot replace independent
                                     capability invocation.

  **MM-CAP-004**                     UI, algorithms, designs, docs and
                                     examples specific to this module
                                     stay module-owned.

  **MM-CAP-005**                     Module/capabilities declare
                                     explicit maturity and connectivity
                                     metadata; core operation is
                                     expected to be Offline.

  **MM-SURF-001**                    Every applicable capability
                                     remains discoverable for direct
                                     use, presets, protocols and ODK.

  **MM-UX-001**                      Runtime is a purpose-built visual
                                     surface, not a generated
                                     debug/settings form.

  **MM-UX-002**                      Working visual state and current
                                     values update in place.

  **MM-UX-003**                      Exposed useful scalar/text outputs
                                     are tap-to-copy.

  **MM-UX-004--005**                 Commit freezes the execution
                                     payload; later edits do not
                                     silently rewrite it.

  **MM-UX-006**                      Meaningful authoring/runtime
                                     working state survives ordinary
                                     lifecycle changes.

  **MM-UX-007**                      Done/closeout returns to
                                     dashboard/app, widget, ODK,
                                     protocol or schedule origin as
                                     appropriate.

  **MM-UX-008**                      Results remain on the polished
                                     visual surface; image/SVG outputs
                                     expose suitable Save/Share/Export
                                     actions.

  **MM-PRESET-001--004**             Presets preserve separate
                                     configuration, run behaviour,
                                     completion and returned-data
                                     scope.

  **MM-PROT-001--002**               Protocols invoke canonical visual
                                     capabilities/presets, retain step
                                     outcomes and use typed dataflow.

  **ODK parity/review doctrine**     Every declared capability/output
                                     is available through ODK;
                                     canonical examples are
                                     single-invocation; full JSON is
                                     returned externally.

  **Binary artefact doctrine**       PNG/SVG returned to ODK becomes a
                                     real caller attachment; private
                                     URIs/paths are not the useful
                                     result.

  **Output contract**                Structured region data are
                                     authoritative core results;
                                     rendered images are declared media
                                     outputs; audit/provenance/full
                                     JSON remain available without
                                     dominating native UI.

  **Persistent-state review**        Traveller maps and similar tools
                                     persist only by explicit policy
                                     and do not become accidental
                                     duplicate storage.

  **Offline-first doctrine**         Core authoring, library,
                                     interaction, state and rendering
                                     operate without network
                                     dependency.

  **MM-MOD-001--003**                Handoff is one clean module root;
                                     maturity/connectivity are
                                     explicit; module
                                     assets/docs/examples remain local.

  **MM-REV-001--004**                Review inventories capabilities,
                                     preserves contracts, verifies
                                     surface parity and treats XLSForms
                                     as part of completeness.

  **MM-TEST-001--002**               Tests cover canonical contract
                                     parity plus representative
                                     native/preset/protocol/ODK flows
                                     and state/media semantics.
  ---------------------------------------------------------------------

### 33B. Cross-reference findings incorporated into v0.03

Cross-referencing against v1.22 changed the specification rather than
merely adding citations:

1.  The earlier generic architecture wording is replaced by explicit
    Entity / Observation / Assertion / Method / Intent / Policy /
    Provenance mapping.
2.  The working-result → **Commit** boundary is explicit.
3.  Tap-to-copy is explicit for useful visible scalar/text results.
4.  Launch-origin-aware closeout is explicit.
5.  Preset run behaviour, completion action and returned-data scope are
    kept separate from Visual Data Mapper settings.
6.  ODK output explicitly includes `methodmesh_full_json`.
7.  PNG/SVG ODK returns are real caller attachments, not raw local URIs.
8.  ODK invocation does not create unnecessary MethodMesh archive
    copies.
9.  Canonical XLSForms are one invocation per workbook using
    `example_odk_showcase_<purpose>.xlsx`.
10. Module-local documentation/handoff location is explicit.
11. Persistence is opt-in/operationally justified rather than assumed.
12. Implementation review must verify cross-surface parity, not merely
    native UX.

## 34. Product invariant

If implementation complexity begins to leak into ordinary use, return to
this invariant:

> **The user should feel that they are interacting with the thing in the
> picture, not operating a database underneath it.**

That invariant applies equally to a traveller casually colouring
countries and to a clinician completing a structured dental examination.
