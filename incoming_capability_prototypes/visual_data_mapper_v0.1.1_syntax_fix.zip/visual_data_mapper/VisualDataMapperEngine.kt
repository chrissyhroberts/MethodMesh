package com.example.methodmesh.modules.visualdatamapper

import android.graphics.Bitmap
import android.graphics.Color
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.sqrt

object VisualDataMapperEngine {
    /** Local/offline edge map. White = traversable interior; black = boundary. */
    fun edgeMap(source: Bitmap, threshold: Int = 70): Bitmap {
        val w = source.width; val h = source.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        fun grey(x: Int, y: Int): Int {
            val c = source.getPixel(x.coerceIn(0,w-1), y.coerceIn(0,h-1))
            return (Color.red(c) * 30 + Color.green(c) * 59 + Color.blue(c) * 11) / 100
        }
        for (y in 0 until h) for (x in 0 until w) {
            if (x == 0 || y == 0 || x == w-1 || y == h-1) { out.setPixel(x,y,Color.BLACK); continue }
            val gx = -grey(x-1,y-1) - 2*grey(x-1,y) - grey(x-1,y+1) + grey(x+1,y-1) + 2*grey(x+1,y) + grey(x+1,y+1)
            val gy = -grey(x-1,y-1) - 2*grey(x,y-1) - grey(x+1,y-1) + grey(x-1,y+1) + 2*grey(x,y+1) + grey(x+1,y+1)
            val mag = sqrt((gx*gx + gy*gy).toDouble()).toInt()
            out.setPixel(x,y, if (mag >= threshold) Color.BLACK else Color.WHITE)
        }
        return out
    }

    /** Paint an impermeable authoring boundary directly into the binary edge map. */
    fun drawBoundary(bitmap: Bitmap, x0: Int, y0: Int, x1: Int, y1: Int, radius: Int = 2) {
        var x=x0; var y=y0
        val dx=abs(x1-x0); val sx=if(x0<x1)1 else -1; val dy=-abs(y1-y0); val sy=if(y0<y1)1 else -1
        var err=dx+dy
        while(true){
            for(yy in y-radius..y+radius) for(xx in x-radius..x+radius) if(xx in 0 until bitmap.width && yy in 0 until bitmap.height) bitmap.setPixel(xx,yy,Color.BLACK)
            if(x==x1 && y==y1) break
            val e2=2*err; if(e2>=dy){err+=dy;x+=sx}; if(e2<=dx){err+=dx;y+=sy}
        }
    }

    fun floodRegion(boundaries: Bitmap, seedX: Int, seedY: Int, maxFraction: Float = .60f): RegionGeometry? {
        val w=boundaries.width; val h=boundaries.height
        if(seedX !in 0 until w || seedY !in 0 until h || isBoundary(boundaries.getPixel(seedX,seedY))) return null
        val seen=BooleanArray(w*h); val q=ArrayDeque<Int>(); val points=ArrayList<Int>()
        fun add(x:Int,y:Int){ if(x !in 0 until w || y !in 0 until h) return; val i=y*w+x; if(seen[i]||isBoundary(boundaries.getPixel(x,y))) return; seen[i]=true;q.add(i) }
        add(seedX,seedY)
        val max=(w*h*maxFraction).toInt().coerceAtLeast(1)
        while(q.isNotEmpty()){
            val i=q.removeFirst(); points.add(i); if(points.size>max) return null
            val x=i%w; val y=i/w; add(x-1,y);add(x+1,y);add(x,y-1);add(x,y+1)
        }
        val byY=points.groupBy { it/w }
        val spans=buildList {
            byY.toSortedMap().forEach { (y,row) ->
                val xs=row.map { it%w }.sorted(); if(xs.isEmpty()) return@forEach
                var start=xs[0]; var prev=xs[0]
                for(i in 1 until xs.size){ val x=xs[i]; if(x>prev+1){add(RasterSpan(y,start,prev));start=x};prev=x }
                add(RasterSpan(y,start,prev))
            }
        }
        return RegionGeometry(w,h,spans)
    }

    private fun isBoundary(c:Int):Boolean = Color.red(c)<80 && Color.green(c)<80 && Color.blue(c)<80
}
