package com.example.methodmesh.modules.visualdatamapper

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.File

class VisualDataMapperRepository(private val context: Context) {
    private val root = File(context.filesDir, "visual_data_mapper").apply { mkdirs() }
    private val designs = File(root, "designs").apply { mkdirs() }
    private val images = File(root, "images").apply { mkdirs() }
    private val states = File(root, "states").apply { mkdirs() }

    fun designIds(): List<String> = designs.listFiles().orEmpty().filter { it.extension=="json" }.map { it.nameWithoutExtension }.sorted()
    fun loadDesign(id:String):VisualDesign? = runCatching { VisualDesign.fromJson(JSONObject(File(designs,"$id.json").readText())) }.getOrNull()
    fun saveDesign(design:VisualDesign){ File(designs,"${safe(design.id)}.json").writeText(design.toJson().toString(2)) }
    fun deleteDesign(id:String){ File(designs,"${safe(id)}.json").delete() }
    fun saveImage(name:String, bitmap:Bitmap):String { val n=safe(name)+".png"; File(images,n).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG,100,it) }; return n }
    fun loadImage(name:String?):Bitmap? = name?.let { File(images,it) }?.takeIf(File::isFile)?.let { BitmapFactory.decodeFile(it.absolutePath) }
    fun imageFile(name:String?):File? = name?.let { File(images,it) }?.takeIf(File::isFile)
    fun saveState(key:String,json:String){ File(states,"${safe(key)}.json").writeText(json) }
    fun loadState(key:String):String? = File(states,"${safe(key)}.json").takeIf(File::isFile)?.readText()
    private fun safe(v:String)=v.replace(Regex("[^A-Za-z0-9._-]"),"_").ifBlank{"visual_design"}
}
