package com.example.methodmesh.modules.visualdatamapper

import org.json.JSONArray
import org.json.JSONObject

enum class RegionVariableType { Binary, SingleSelect, MultiSelect, Ordinal, Integer, Decimal, Text }
enum class RegionAvailability { Active, Absent, Disabled, NotApplicable, Unknown }
enum class RegionInteractionMode { Binary, Categorical, Sequence, Intensity, Numeric, Record, Persistent }

data class RasterSpan(val y: Int, val x0: Int, val x1: Int) {
    fun contains(x: Int, yy: Int) = yy == y && x in x0..x1
}

data class RegionGeometry(
    val width: Int,
    val height: Int,
    val spans: List<RasterSpan>
) {
    fun contains(nx: Float, ny: Float): Boolean {
        if (width <= 0 || height <= 0) return false
        val x = (nx.coerceIn(0f, .999999f) * width).toInt()
        val y = (ny.coerceIn(0f, .999999f) * height).toInt()
        return spans.any { it.contains(x, y) }
    }

    fun toJson() = JSONObject()
        .put("width", width).put("height", height)
        .put("spans", JSONArray().apply { spans.forEach { put(JSONArray(listOf(it.y, it.x0, it.x1))) } })

    companion object {
        fun fromJson(o: JSONObject): RegionGeometry {
            val a = o.optJSONArray("spans") ?: JSONArray()
            return RegionGeometry(o.optInt("width"), o.optInt("height"), buildList {
                for (i in 0 until a.length()) {
                    val s = a.optJSONArray(i) ?: continue
                    add(RasterSpan(s.optInt(0), s.optInt(1), s.optInt(2)))
                }
            })
        }
    }
}

data class RegionVariable(
    val id: String,
    val label: String,
    val type: RegionVariableType,
    val choices: List<String> = emptyList(),
    val required: Boolean = false,
    val minimum: Double? = null,
    val maximum: Double? = null
) {
    fun toJson() = JSONObject().put("id", id).put("label", label).put("type", type.name)
        .put("choices", JSONArray(choices)).put("required", required)
        .also { minimum?.let { v -> it.put("minimum", v) }; maximum?.let { v -> it.put("maximum", v) } }

    companion object {
        fun fromJson(o: JSONObject) = RegionVariable(
            id = o.optString("id"), label = o.optString("label"),
            type = runCatching { RegionVariableType.valueOf(o.optString("type")) }.getOrDefault(RegionVariableType.Text),
            choices = o.optJSONArray("choices")?.let { a -> List(a.length()) { a.optString(it) } }.orEmpty(),
            required = o.optBoolean("required"),
            minimum = if (o.has("minimum")) o.optDouble("minimum") else null,
            maximum = if (o.has("maximum")) o.optDouble("maximum") else null
        )
    }
}

data class VisualRegion(
    val id: String,
    val label: String,
    val regionType: String = "region",
    val geometry: RegionGeometry,
    val hitGeometry: RegionGeometry? = null,
    val displayGeometry: RegionGeometry? = null,
    val variables: List<RegionVariable> = emptyList()
) {
    fun hit(nx: Float, ny: Float) = (hitGeometry ?: geometry).contains(nx, ny)
    fun toJson() = JSONObject().put("id", id).put("label", label).put("region_type", regionType)
        .put("geometry", geometry.toJson())
        .also { hitGeometry?.let { g -> it.put("hit_geometry", g.toJson()) }; displayGeometry?.let { g -> it.put("display_geometry", g.toJson()) } }
        .put("variables", JSONArray().apply { variables.forEach { put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): VisualRegion = VisualRegion(
            id = o.optString("id"), label = o.optString("label"), regionType = o.optString("region_type", "region"),
            geometry = RegionGeometry.fromJson(o.getJSONObject("geometry")),
            hitGeometry = o.optJSONObject("hit_geometry")?.let(RegionGeometry::fromJson),
            displayGeometry = o.optJSONObject("display_geometry")?.let(RegionGeometry::fromJson),
            variables = o.optJSONArray("variables")?.let { a -> List(a.length()) { RegionVariable.fromJson(a.getJSONObject(it)) } }.orEmpty()
        )
    }
}

data class VisualDesign(
    val id: String,
    val name: String,
    val version: Int = 1,
    val sourceWidth: Int,
    val sourceHeight: Int,
    val trainingImage: String? = null,
    val presentationImage: String? = null,
    val regions: List<VisualRegion> = emptyList()
) {
    fun regionAt(nx: Float, ny: Float): VisualRegion? = regions.asReversed().firstOrNull { it.hit(nx, ny) }
    fun toJson() = JSONObject().put("format", "methodmesh.visual-region-design").put("format_version", 1)
        .put("id", id).put("name", name).put("version", version)
        .put("source_width", sourceWidth).put("source_height", sourceHeight)
        .put("training_image", trainingImage).put("presentation_image", presentationImage)
        .put("regions", JSONArray().apply { regions.forEach { put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): VisualDesign = VisualDesign(
            id = o.optString("id"), name = o.optString("name"), version = o.optInt("version", 1),
            sourceWidth = o.optInt("source_width"), sourceHeight = o.optInt("source_height"),
            trainingImage = o.optString("training_image").takeIf { it.isNotBlank() && it != "null" },
            presentationImage = o.optString("presentation_image").takeIf { it.isNotBlank() && it != "null" },
            regions = o.optJSONArray("regions")?.let { a -> List(a.length()) { VisualRegion.fromJson(a.getJSONObject(it)) } }.orEmpty()
        )
    }
}

data class RegionRecord(
    val regionId: String,
    val availability: RegionAvailability = RegionAvailability.Active,
    val values: Map<String, String> = emptyMap(),
    val sequenceIndex: Int? = null
) {
    fun toJson() = JSONObject().put("region_id", regionId).put("availability", availability.name)
        .put("values", JSONObject(values)).also { sequenceIndex?.let { i -> it.put("sequence_index", i) } }
}
