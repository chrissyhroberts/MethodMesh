# Text documents

**Module:** `textdocuments`  
**Release:** v0.05  
**Capability:** `document.text.open`  
**Maturity:** **Development**  
**Connectivity:** **Offline**  
**Icon:** `document`

Text documents is MethodMesh's local text-document workspace. It creates, opens, edits and saves plain text, Markdown, JSON and JSON Lines without silently rewriting content.

Supported filename forms are `.txt`, `.md`, `.markdown`, `.json`, `.jsonl` and `.ndjson`.

## Canonical capability

`document.text.open` is the single canonical contract. The same capability is discoverable for:

- direct native use from **Capabilities**;
- preset creation/execution;
- protocol composition;
- ODK/XLSForm interactive or supplied-text use.

The Android `VIEW` / `EDIT` `DocumentActivity` is an additional file-launch origin using the same module-owned editor surface. It is not a second capability implementation.

### Inputs

| Key | Type | Required | Meaning |
|---|---|---:|---|
| `document_text` | text | no | Caller-supplied text. If absent, the native surface can acquire/create a document interactively. |
| `document_title` | text | no | Suggested human-facing filename/title. |
| `document_format` | choice | no | `text`, `markdown`, `json`, `jsonl`. |

### Outputs

| Key | Type | Meaning |
|---|---|---|
| `document_status` | text | `succeeded` or `failed`. |
| `document_text` | text | The text frozen at Commit. |
| `document_title` | text | Human-facing title at Commit. |
| `document_format` | text | `text`, `markdown`, `json`, or `jsonl`. |
| `document_error` | text | Failure diagnostic; blank on success. |

Shared transport adds `methodmesh_status` and, for ODK/FULL projection, `methodmesh_full_json`.

## Native UX

The native workspace is the capability UI, not a settings form.

The workspace offers:

- **New document** — Plain text, Markdown, JSON or JSON Lines;
- **Open file** — Android Storage Access Framework;
- **Create from clipboard**;
- **Recent** — recently opened document URIs where access remains available.

The editor keeps the document itself dominant. Markdown has source/preview modes. JSON and JSON Lines are edited as lossless text: opening or saving never automatically pretty-prints, minifies, parses or rewrites the body.

**Save** persists the working file. **Commit** is a different MethodMesh boundary: it freezes the canonical return payload. Editing after Commit is explicitly shown as changed-since-Commit and does not silently mutate the committed result. **Done** returns the committed result to the native launch origin. ODK/protocol automatic-return callers return immediately after Commit.

Useful text can be copied directly. The editor menu also provides Copy all and Find.

No internal document copy is auto-saved by MethodMesh. The Recent list stores URI/title/MIME metadata only.

## External Android file opening

`DocumentActivity` accepts Android `VIEW` / `EDIT` launches and returns to the originating app on Close/Back. Unreadable or absent content URIs produce an in-app error surface rather than a process crash.

The app manifest is shared Android integration rather than module-owned code. For external association the host manifest should expose `DocumentActivity` for:

- `text/plain`
- `text/markdown`
- `application/json`
- `application/x-ndjson`
- optionally `application/jsonl`

The module itself does not add capability-specific branches to shared UI or core infrastructure.

# ODK INTEGRATION

## Capability

Text documents  
`document.text.open`

## Tags

Maturity: **Development**  
Connectivity: **Offline**

## ODK INPUTS

| Canonical input | ODK type | Required | Meaning |
|---|---|---:|---|
| `document_text` | text | optional | Source text supplied by the form. |
| `document_title` | text | optional | Suggested title/filename. |
| `document_format` | select/text | optional | `text`, `markdown`, `json`, `jsonl`. |

Interactive acquisition: when `document_text` is absent, the MethodMesh UI can create a new document, open a local document, or start from clipboard text before Commit.

## INTENT CALL

```text
com.example.methodmesh.EXECUTE_METHOD(method_id='document.text.open',input_document_text=${source_text},input_document_title=${source_title},input_document_format=${source_format},input_payload_mode='FULL',return_mode='flat')
```

## MODIFIERS

None.

## CANONICAL RETURNS

| Canonical return | ODK type | Presence | Meaning |
|---|---|---|---|
| `methodmesh_status` | text | always | Shared MethodMesh execution status. |
| `document_status` | text | always | Capability status. |
| `document_text` | text | success | Committed edited text. |
| `document_title` | text | always | Committed title. |
| `document_format` | text | always | Committed format. |
| `document_error` | text | failure/blank on success | Failure diagnostic. |
| `methodmesh_full_json` | text/JSON | always on handled ODK roundtrip | Shared metadata/audit payload. |

## RETURN FIELD PLACEMENT

Canonical showcase: `example_odk_showcase_document_text_open.xlsx`

The workbook contains exactly one MethodMesh invocation, uses canonical unprefixed return keys and does not set `methodmesh_return_namespace`.

## FILE RETURN SEMANTICS

None in v0.05. The canonical ODK beef is committed text. Local file persistence is an operator-side native action and the module does not return an obscure Android URI/path to ODK.

## RUNTIME

Inputs: optional supplied text, title and format; otherwise interactive acquisition.  
Beef: committed document text plus human title/format.  
Metadata: shared full JSON is secondary in native runtime and always available on handled ODK FULL roundtrip.

## Presets and protocols

All three canonical inputs are declared through `MethodSetting`. A preset can fix title/format and ask for text at runtime, or launch the interactive workspace. Protocols invoke the same `document.text.open` method; there is no private dashboard implementation.

The method's non-interactive execution path succeeds only when `document_text` is supplied. If it is absent, it fails clearly with an interactive-acquisition-required diagnostic rather than pretending a background edit occurred.

## Permissions, privacy and persistence

Core editing is offline. No network service receives document contents.

Storage uses Android content URIs selected or supplied by the user. Persistable URI access is retained where the provider grants it. MethodMesh does not automatically archive document contents.

No credentials or secrets are required.

## Dependencies and attribution

The module uses Android/Jetpack Compose APIs, the existing MethodMesh runtime, and the project's existing Markwon dependency for Markdown rendering. No online provider is used.

## Validation status

v0.05 was reviewed against MethodMesh Master Book v1.22. The module folder was statically checked in this chat against the supplied `app/src/main` interfaces. A complete Gradle project was not supplied here, so `:app:assembleDebug` could not be run in this environment. Promotion remains **Development** until build and representative native/preset/protocol/ODK validation are completed.
