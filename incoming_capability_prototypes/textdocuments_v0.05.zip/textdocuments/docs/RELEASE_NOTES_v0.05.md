# Text documents v0.05

Master Book v1.22 conformance refresh.

- restores a canonical `document.text.open` AS100 capability so the module is discoverable through Capabilities, presets and protocols;
- adds explicit Development / Offline capability metadata;
- replaces the external-file-only slice with a native document workspace;
- adds TXT, Markdown, JSON and JSON Lines/NDJSON editing without automatic rewriting;
- separates file Save from MethodMesh Commit;
- preserves a frozen committed payload when editing continues;
- adds origin-aware native/ODK completion behaviour;
- retains recent URI metadata without auto-saving document contents;
- hardens external Android VIEW/EDIT handling with a visible error state;
- adds module-owned ODK Integration documentation and a canonical single-call XLSForm showcase;
- keeps all capability-specific implementation under `modules/textdocuments`.
