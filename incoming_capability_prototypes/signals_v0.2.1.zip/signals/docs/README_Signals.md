# MethodMesh Signals

Version: **0.2.1**  
Module status: **Development**  
Connectivity: **Offline**

Signals is MethodMesh's physical-signal toolkit: observe a signal, encode a small payload, transmit it over a locally available physical channel, receive it again, and return the useful result through the same canonical capability contract used by direct native runs, presets, protocols and ODK/XLSForm.

The first pass deliberately favours channels that can be implemented entirely on an ordinary Android phone. ESP32 radio/magnetic extensions are documented in `ROADMAP_NOTE.md` but are not advertised as working MethodMesh capabilities until a real hardware execution boundary exists.

The module is not a replacement for conventional networking, secure messaging or safety-critical radio systems. It is intended for small, explicit, local transfers and signal diagnostics where ordinary networking is absent, undesirable or simply not the channel being studied.

## Capability inventory

| Method ID | Native capability | Maturity | Connectivity | Primary channel |
|---|---|---|---|---|
| `signal.morse.transmit` | Morse transmitter | Development | Offline | front screen / rear torch / speaker |
| `signal.morse.receive` | Morse receiver | Development | Offline | light sensor / camera luminance / microphone |
| `signal.qr.transmit` | QR burst transmitter | Development | Offline | screen -> camera |
| `signal.qr.receive` | QR burst receiver | Development | Offline | camera |
| `signal.audio_fsk.transmit` | Audio FSK transmitter | Development | Offline | speaker -> microphone/radio audio path |
| `signal.audio_fsk.receive` | Audio FSK receiver | Development | Offline | microphone |
| `signal.ultrasonic.transmit` | Near-ultrasonic transmitter | Experimental | Offline | high-frequency phone audio |
| `signal.ultrasonic.receive` | Near-ultrasonic receiver | Experimental | Offline | microphone |
| `signal.sensor.scope` | Signal sensor scope | Development | Offline | phone sensors |

Every method above is independently registered by `SignalsModule`; the dashboard is only a generic discovery/launch projection. No capability is dashboard-only.


## Native instrument design

The 0.2 quality pass gives the module one coherent instrument family without making every capability look identical. v0.2.1 adds long-range camera optics without changing canonical method IDs or ODK contracts. The live tool remains visually dominant and configuration remains below it.

- **Morse** uses an amber telegraph/beacon language: large current mark, notation, dot timing, speed and completed-cycle telemetry. Camera reception now supports real camera zoom, Full/Focus/Pinpoint analysis ROIs, tap-to-position manual ROI and temporal-modulation auto-lock/tracking for distant flashing sources.
- **QR burst** uses a cyan optical-modem language: current coded frame, frame/cycle/dwell telemetry, Reed-Solomon geometry and recovery progress. Active transmission expands to a full-screen maximum-brightness optical surface with an explicit Stop control. QR receive exposes actual hardware optical zoom (1x / 2x / 4x / device maximum) to extend scan distance.
- **Audible FSK** uses a cyan radio-modem language with MARK/SPACE carrier rail, bit period, packet/cycle telemetry and receiver shard progress. The full declared 200–8000 Hz and radio PTT-lead ranges remain available natively.
- **Near-ultrasonic FSK** uses the same modem grammar with a violet experimental treatment so high-frequency mode is visibly distinct and never implied to be universally inaudible.
- **Sensor scope** uses a live oscilloscope trace, large current magnitude/value and axis telemetry rather than a table-only sensor readout.
- **Committed results** use a separate green frozen-record treatment. This is deliberately different from live instrumentation so the Commit boundary is visually obvious.

The custom dark instrument chassis is confined to the live/frozen instrument surfaces. Ordinary configuration controls remain Material-theme native for accessibility and consistency with the host application.

### Commit-integrity rails added in 0.2

The visual review also tightened working-state semantics. Changing any transmission setting that affects the actual emitted Morse/QR/FSK signal invalidates completed-cycle evidence before another Commit. Changing Morse/FSK receiver tuning or the QR message filter clears only the **working** decode/shard collection. An already committed result remains frozen and its displayed carrier/timing values come from committed fields rather than current live controls.

Native sliders now expose the same canonical limits/steps declared by `SignalsModule`; the polished UI does not silently narrow preset/ODK capability.

## Working-result -> Commit lifecycle

The physical instrument is at the top of each native surface. Settings live below it. Useful live scalar/text values are tappable to copy.

For transactional capabilities the lifecycle is:

```text
configure / listen / transmit
    -> live working result
    -> Commit
    -> frozen canonical result
    -> copy / share / save / origin-aware Done
```

Commit freezes the canonical return payload. Editing settings or continuing live sensor activity after Commit does not silently mutate the committed record. Automatic-return origins such as ODK return the committed result at the Commit boundary.

Active sound/light emission and live microphone capture are deliberately stopped when their Compose screen leaves the Activity. Settings, completed-cycle counts, decoded text and complete received MMS/1 frames are retained across ordinary recreation; the operator explicitly restarts the physical channel. This avoids an apparently live transmitter/receiver whose underlying Android hardware session has actually been destroyed.

---

# MMS/1: MethodMesh Signal Protocol v1

QR, audible FSK and near-ultrasonic FSK carry the same transport-independent **MMS/1** frames.

MMS/1 is designed for lossy physical links where a receiver may:

- miss whole frames;
- start listening halfway through a loop;
- receive frames out of order;
- receive the same frame repeatedly;
- reject frames corrupted by a noisy physical channel.

## Integrity and erasure recovery

For a payload split into `k` source shards, MMS/1 creates systematic Reed-Solomon coded shards over GF(256). The first `k` coding rows are the unmodified source shards; additional rows are parity shards from a systematic Vandermonde generator matrix.

Any `k` **distinct valid** coded rows are sufficient to reconstruct the original `k` source shards, provided the advertised message geometry is consistent. This is erasure recovery: an analogue demodulator either yields a complete frame whose CRC passes, or that frame is discarded rather than silently fed into reconstruction.

Each ASCII MMS/1 frame contains:

```text
MMS1 | message_id | data_shards | payload_length | message_crc32 |
       coding_row | base64url_shard | frame_crc32
```

Two CRC layers are used:

1. **frame CRC32** rejects a damaged transport frame before it reaches Reed-Solomon reconstruction;
2. **whole-message CRC32** verifies the reconstructed original byte payload.

MMS/1 CRC is error detection, **not authentication**. A malicious party can deliberately construct a new valid CRC. Sensitive/authenticated messaging needs a cryptographic layer above MMS/1.

## Reliability profiles

| Profile | Parity rows generated | Intended use |
|---|---:|---|
| Fast | `max(1, ceil(k/4))` | cleaner short links where speed matters |
| Robust | `max(2, k)` | default; parity roughly equals the source-shard count |
| Extreme | `max(4, 2k)` | very lossy channels where transmission time is acceptable |

A looping sender cycles all coded frames. A receiver can therefore join mid-stream and accumulate independent rows until reconstruction succeeds.

Morse currently remains the deliberately human-readable signalling route rather than wrapping every character in MMS/1. Its first-pass robustness comes from configurable looping/repetition and adaptive receive timing. `MMS/1-over-Morse` is on the roadmap for machine-to-machine Morse where a longer coded transmission is acceptable.

---

# Morse transmitter — `signal.morse.transmit`

Transmit ordinary text as International Morse timing using any supported combination of:

- **front screen flash** — a full-screen black/white emitter surface with the live window brightness request raised to maximum and restored when transmission stops;
- rear-camera torch;
- audible tone.

The full-screen emitter keeps an explicit **Stop** control available and channel/timing controls remain locked while a physical transmission is active.

Unsupported characters are skipped by the Morse encoder. The visible Morse notation updates immediately from the working message and is tap-to-copy.

## Inputs

| Key | Type | Default | Meaning |
|---|---|---|---|
| `payload` | text | `SOS` | Text to encode. |
| `route` | choice | `screen` | `screen`, `torch`, `sound`, `screen_sound`, `torch_sound`, `all`. |
| `wpm` | integer | `12` | Morse speed. Dot duration follows `1200 / WPM` ms. |
| `tone_frequency_hz` | decimal | `700` | Audible carrier when sound is enabled. |
| `loop_mode` | choice | `once` | `once`, `count`, `continuous`. |
| `repeat_count` | integer | `3` | Used for counted looping. |
| `loop_gap_units` | integer | `10` | Quiet Morse units between repeated messages. |

## Declared outputs

`signal_morse_result`, `signal_morse_payload`, `signal_morse_notation`, `signal_morse_route`, `signal_morse_wpm`, `signal_morse_repetitions`, `signal_morse_status`, `signal_morse_error`.

## ODK Integration Card — `signal.morse.transmit`

**Tags** — Development / Offline  
**Interactive acquisition** — yes: MethodMesh performs the observable physical transmission and the operator commits after at least one complete cycle.

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.morse.transmit',
  input_payload=${morse_tx_payload},
  input_route=${morse_tx_route},
  input_wpm=${morse_tx_wpm},
  input_tone_frequency_hz=${morse_tx_tone_hz},
  input_loop_mode=${morse_tx_loop_mode},
  input_repeat_count=${morse_tx_repeat_count},
  input_loop_gap_units=${morse_tx_loop_gap},
  input_payload_mode='FULL',return_mode='flat')
```

Canonical returns are the declared fields above plus shared `methodmesh_status` and `methodmesh_full_json`. The showcase uses one intent group, direct group children, unprefixed canonical return keys and no `methodmesh_return_namespace`.

---

# Morse receiver — `signal.morse.receive`

Decode an on/off Morse envelope from:

- Android ambient-light sensor (`light_sensor`);
- centre-of-frame CameraX luminance (`camera`);
- a configured microphone carrier (`microphone`).

Camera luminance is a relative signal metric, not calibrated photometry. The ambient-light sensor is device-dependent and may update too slowly for fast Morse; use a slower sender when necessary. Microphone detection uses a module-local Goertzel carrier detector and prefers an unprocessed/MIC input path where Android exposes one.

Auto timing normalises dots and dashes back to an estimated one-unit dot duration before adapting, so dash-only traffic does not teach the receiver that a three-unit dash is the new dot.

## Inputs

| Key | Type | Default | Meaning |
|---|---|---|---|
| `source` | choice | `light_sensor` | `light_sensor`, `camera`, `microphone`. |
| `dot_ms` | integer | `100` | Initial expected dot duration. |
| `auto_timing` | boolean | `true` | Adapt the base Morse unit from observed marks. |
| `microphone_tone_hz` | decimal | `700` | Target microphone carrier. |
| `microphone_tolerance_hz` | decimal | `120` | Guard spacing/tolerance used by the tone detector. |
| `microphone_min_dbfs` | decimal | `-35` | Frames quieter than this are treated as off. |

## Declared outputs

`signal_morse_received_text`, `signal_morse_received_notation`, `signal_morse_source`, `signal_morse_dot_ms`, `signal_morse_transitions`, `signal_morse_status`, `signal_morse_error`.

## ODK Integration Card — `signal.morse.receive`

**Tags** — Development / Offline  
**Interactive acquisition** — required. MethodMesh listens until the operator has a useful decoded working result and presses Commit.

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.morse.receive',
  input_source=${morse_rx_source},
  input_dot_ms=${morse_rx_dot_ms},
  input_auto_timing=${morse_rx_auto_timing},
  input_microphone_tone_hz=${morse_rx_tone_hz},
  input_microphone_tolerance_hz=${morse_rx_tolerance_hz},
  input_microphone_min_dbfs=${morse_rx_min_dbfs},
  input_payload_mode='FULL',return_mode='flat')
```

Canonical returns are the declared fields above plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# QR burst transmitter — `signal.qr.transmit`

Split a small UTF-8 payload into MMS/1 source/parity shards and display each complete ASCII MMS/1 frame as a QR code. QR itself supplies per-symbol error correction; MMS/1 supplies recovery **between** QR frames.

The message ID is saved as working state so Activity recreation cannot silently change the identity of a burst whose completed-cycle count is being retained. Changing payload, shard geometry or reliability intentionally creates a new message ID.

## Inputs

`payload`, `robustness`, `shard_bytes`, `frame_duration_ms`, `loop`.

## Declared outputs

`signal_qr_result`, `signal_qr_payload`, `signal_qr_message_id`, `signal_qr_data_shards`, `signal_qr_parity_frames`, `signal_qr_frame_count`, `signal_qr_message_crc32`, `signal_qr_robustness`, `signal_qr_cycles`, `signal_qr_status`, `signal_qr_error`.

## ODK Integration Card — `signal.qr.transmit`

**Tags** — Development / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.qr.transmit',
  input_payload=${qr_tx_payload},
  input_robustness=${qr_tx_robustness},
  input_shard_bytes=${qr_tx_shard_bytes},
  input_frame_duration_ms=${qr_tx_frame_ms},
  input_loop=${qr_tx_loop},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive acquisition is required because the screen must actually display at least one complete QR cycle before Commit. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# QR burst receiver — `signal.qr.receive`

Continuously scan QR codes, reject non-MMS/1 or CRC-invalid frames, retain unique complete frames, and reconstruct once enough independent Reed-Solomon rows are available. Complete received MMS/1 frames are persisted as temporary working state across ordinary Activity recreation; no archive is created unless the caller/preset explicitly requests persistence through shared MethodMesh mechanisms.

## Inputs

`message_id_filter` — optional MMS/1 message ID. Blank accepts the first compatible message geometry encountered.

## Declared outputs

`signal_qr_received_text`, `signal_qr_message_id`, `signal_qr_frames_seen`, `signal_qr_frames_accepted`, `signal_qr_frames_rejected`, `signal_qr_recovered_missing_shards`, `signal_qr_crc_verified`, `signal_qr_status`, `signal_qr_error`.

## ODK Integration Card — `signal.qr.receive`

**Tags** — Development / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.qr.receive',
  input_message_id_filter=${qr_rx_message_id_filter},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive camera acquisition is required. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# Audio FSK transmitter — `signal.audio_fsk.transmit`

Send complete MMS/1 ASCII frames through binary frequency-shift keying. Defaults are 1200 Hz MARK and 2200 Hz SPACE. This is intentionally conservative rather than a high-throughput modem. The receiver analyses dominant tone in 10 ms windows, so the canonical bit period is constrained to 20–250 ms in 10 ms increments; the default is 30 ms.

A configurable `ptt_lead_ms` steady MARK carrier precedes every framed burst. It is useful for:

- manually keyed walkie-talkies whose PTT/squelch path needs settling time;
- VOX radios that need an audible carrier before framed data begins.

The receiver scans for its own physical sync word, so lead carrier audio is outside the MMS/1 payload.

## Inputs

`payload`, `robustness`, `mark_hz`, `space_hz`, `bit_ms`, `ptt_lead_ms`, `repeat_count`.

## Declared outputs

`signal_fsk_result`, `signal_fsk_payload`, `signal_fsk_message_id`, `signal_fsk_frame_count`, `signal_fsk_mark_hz`, `signal_fsk_space_hz`, `signal_fsk_bit_ms`, `signal_fsk_ptt_lead_ms`, `signal_fsk_robustness`, `signal_fsk_cycles`, `signal_fsk_status`, `signal_fsk_error`.

## ODK Integration Card — `signal.audio_fsk.transmit`

**Tags** — Development / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.audio_fsk.transmit',
  input_payload=${fsk_tx_payload},
  input_robustness=${fsk_tx_robustness},
  input_mark_hz=${fsk_tx_mark_hz},
  input_space_hz=${fsk_tx_space_hz},
  input_bit_ms=${fsk_tx_bit_ms},
  input_ptt_lead_ms=${fsk_tx_ptt_lead_ms},
  input_repeat_count=${fsk_tx_repeat_count},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive transmission and Commit are required. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# Audio FSK receiver — `signal.audio_fsk.receive`

Use 10 ms microphone analysis windows and two Goertzel detectors to classify MARK/SPACE/silence. Consecutive equal classifications are converted back into configured bit-length runs; the bitstream parser searches for its sync word and extracts complete MMS/1 ASCII frames. Frame CRC and whole-message CRC remain authoritative above the physical detector.

Complete frames are retained when listening is paused or the Activity is recreated. Partial physical bit runs are intentionally discarded on restart rather than pretending they are trustworthy.

## Inputs

`mark_hz`, `space_hz`, `bit_ms`, `minimum_dbfs`.

## Declared outputs

`signal_fsk_received_text`, `signal_fsk_message_id`, `signal_fsk_frames_accepted`, `signal_fsk_frames_rejected`, `signal_fsk_recovered_missing_shards`, `signal_fsk_crc_verified`, `signal_fsk_mark_hz`, `signal_fsk_space_hz`, `signal_fsk_bit_ms`, `signal_fsk_status`, `signal_fsk_error`.

## ODK Integration Card — `signal.audio_fsk.receive`

**Tags** — Development / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.audio_fsk.receive',
  input_mark_hz=${fsk_rx_mark_hz},
  input_space_hz=${fsk_rx_space_hz},
  input_bit_ms=${fsk_rx_bit_ms},
  input_minimum_dbfs=${fsk_rx_min_dbfs},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive microphone acquisition is required. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# Near-ultrasonic transmitter — `signal.ultrasonic.transmit`

The default near-ultrasonic bit period is 40 ms and uses the same 10 ms-aligned timing rule as audible FSK.

This is an **Experimental** MMS/1 FSK channel using high-frequency phone audio, defaulting to 18 kHz / 19 kHz carriers.

“Near-ultrasonic” does **not** mean guaranteed inaudible. Some people and animals can hear frequencies in this region. Phone speakers, microphones, codecs, acoustic processing and cases vary substantially; a nominal 48 kHz sample path does not guarantee useful acoustic response near Nyquist.

## Inputs

`payload`, `robustness`, `mark_hz`, `space_hz`, `bit_ms`, `repeat_count`.

## Declared outputs

`signal_ultrasonic_result`, `signal_ultrasonic_payload`, `signal_ultrasonic_message_id`, `signal_ultrasonic_frame_count`, `signal_ultrasonic_mark_hz`, `signal_ultrasonic_space_hz`, `signal_ultrasonic_bit_ms`, `signal_ultrasonic_robustness`, `signal_ultrasonic_cycles`, `signal_ultrasonic_status`, `signal_ultrasonic_error`.

## ODK Integration Card — `signal.ultrasonic.transmit`

**Tags** — Experimental / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.ultrasonic.transmit',
  input_payload=${ultra_tx_payload},
  input_robustness=${ultra_tx_robustness},
  input_mark_hz=${ultra_tx_mark_hz},
  input_space_hz=${ultra_tx_space_hz},
  input_bit_ms=${ultra_tx_bit_ms},
  input_repeat_count=${ultra_tx_repeat_count},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive transmission and Commit are required. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# Near-ultrasonic receiver — `signal.ultrasonic.receive`

Experimental high-frequency two-tone receiver. The module prefers Android `UNPROCESSED` input where advertised, then `MIC`, before falling back to speech-oriented input. This preference is specifically to avoid treating speech-band processing as a trustworthy high-frequency measurement path.

## Inputs

`mark_hz`, `space_hz`, `bit_ms`, `minimum_dbfs`.

## Declared outputs

`signal_ultrasonic_received_text`, `signal_ultrasonic_message_id`, `signal_ultrasonic_frames_accepted`, `signal_ultrasonic_frames_rejected`, `signal_ultrasonic_recovered_missing_shards`, `signal_ultrasonic_crc_verified`, `signal_ultrasonic_mark_hz`, `signal_ultrasonic_space_hz`, `signal_ultrasonic_bit_ms`, `signal_ultrasonic_status`, `signal_ultrasonic_error`.

## ODK Integration Card — `signal.ultrasonic.receive`

**Tags** — Experimental / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.ultrasonic.receive',
  input_mark_hz=${ultra_rx_mark_hz},
  input_space_hz=${ultra_rx_space_hz},
  input_bit_ms=${ultra_rx_bit_ms},
  input_minimum_dbfs=${ultra_rx_min_dbfs},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive microphone acquisition is required. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# Signal sensor scope — `signal.sensor.scope`

A compact live scope over phone sensors already exposed by MethodMesh's shared `PhoneSensorRepository`:

- ambient light — lux;
- magnetic field — X/Y/Z µT and magnitude;
- acceleration — X/Y/Z m/s² and magnitude;
- gyroscope — X/Y/Z rad/s and magnitude;
- pressure — hPa;
- proximity — device-specific proximity distance/unit as reported by Android.

The scope is diagnostic. It does not claim laboratory calibration. It can be used to characterise a prospective signal channel before a future decoder is enabled.

## Input

`sensor` — `light`, `magnetometer`, `accelerometer`, `gyroscope`, `pressure`, `proximity`.

## Declared outputs

`signal_sensor_result`, `signal_sensor_id`, `signal_sensor_value_0`, `signal_sensor_value_1`, `signal_sensor_value_2`, `signal_sensor_magnitude`, `signal_sensor_unit`, `signal_sensor_accuracy`, `signal_sensor_values_json`, `signal_sensor_status`, `signal_sensor_error`.

## ODK Integration Card — `signal.sensor.scope`

**Tags** — Development / Offline

```text
com.example.methodmesh.EXECUTE_METHOD(
  method_id='signal.sensor.scope',
  input_sensor=${signal_scope_sensor},
  input_payload_mode='FULL',return_mode='flat')
```

Interactive capture is required because Commit freezes the currently visible sensor snapshot. Returns are the declared fields plus shared `methodmesh_status` and `methodmesh_full_json`.

---

# ODK/XLSForm examples

The module owns one v1.08 canonical single-invocation showcase per independently callable capability:

- `example_odk_showcase_signal_morse_transmit.xlsx`
- `example_odk_showcase_signal_morse_receive.xlsx`
- `example_odk_showcase_signal_qr_transmit.xlsx`
- `example_odk_showcase_signal_qr_receive.xlsx`
- `example_odk_showcase_signal_audio_fsk_transmit.xlsx`
- `example_odk_showcase_signal_audio_fsk_receive.xlsx`
- `example_odk_showcase_signal_ultrasonic_transmit.xlsx`
- `example_odk_showcase_signal_ultrasonic_receive.xlsx`
- `example_odk_showcase_signal_sensor_scope.xlsx`

Each workbook contains exactly one `com.example.methodmesh.EXECUTE_METHOD` intent call, uses the canonical method ID, requests `input_payload_mode='FULL'`, uses `return_mode='flat'`, captures shared `methodmesh_status` and `methodmesh_full_json`, uses canonical unprefixed return fields, and does not set a return namespace.

# Permissions and platform dependencies

The current MethodMesh host already declares the permissions used by this first pass:

- `CAMERA` — QR receive, camera-luminance Morse receive, rear torch;
- `RECORD_AUDIO` — Morse microphone receive, audible FSK receive, near-ultrasonic receive.

No network connection is required for the module's declared core work.

The host already resolves CameraX and JourneyApps/ZXing. Signals uses those existing host dependencies for local camera analysis and QR rendering/scanning; it does not add a cloud service or a new remote dependency. See `ATTRIBUTION.md` and `THIRD_PARTY_NOTICES.md`.

# Relationship to the existing Acoustics module

The existing `acoustic.analyse`, `acoustic.tune`, `acoustic.level` and `acoustic.compare` contracts remain owned by the Acoustics module and are not renamed, duplicated or silently migrated by this first pass.

Signals owns its low-latency carrier demodulation because the communication receiver needs continuous MARK/SPACE/on-off windows rather than a completed Acoustics observation. A future unified Signals/Acoustics presentation can be considered without breaking the established `acoustic.*` method IDs. Moving ownership should only happen as an explicit repository migration that simultaneously removes duplicate registration risk.

# Storage and privacy

Signals is transient by default:

- raw microphone audio is not persisted;
- camera frames are analysed in memory;
- QR/MMS complete frames are held as temporary working state only;
- no signal payload is uploaded by the module;
- ordinary Commit returns the canonical result to the caller rather than creating an extra local archive.

Shared MethodMesh preset-log behaviour remains available when a preset explicitly opts into persistence.

# Validation

See `VALIDATION.md` for codec smoke tests, v1.08 review passes, XLSForm checks, limitations of this execution environment and the receiving-repository/device test matrix.
