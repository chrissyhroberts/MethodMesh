# Signals v0.2.1 validation

Status: **Development**  
Near-ultrasonic capabilities: **Experimental**

Review basis: current `docs/METHODMESH_MASTER_BOOK.md` on MethodMesh `master`, **v1.08 FINAL, updated 2026-09-08**.

## Pass A — contract correctness

- Module ID is `signals`; the handoff root is one self-contained `signals/` folder.
- Nine independently callable methods are registered by `SignalsModule.as100Methods()`.
- All nine have matching `CapabilityScreenSpec` entries and module-owned settings.
- Every method declares exactly one maturity value through descriptor `maturity` metadata and exactly one `OFFLINE` connectivity value.
- Development: Morse TX/RX, QR TX/RX, audio FSK TX/RX, sensor scope.
- Experimental: near-ultrasonic TX/RX.
- No ESP32/ESP-NOW/magnetic-coil method is registered without a real Android/hardware execution path.
- Existing Acoustics IDs/contracts are not moved or duplicated.
- No shared MethodMesh UI/source modification is required for the module handoff.
- Physical methods intentionally return `Unsupported` from headless `execute()` because the observable camera/audio/torch/sensor operation must run through the canonical interactive capability screen. The method contract itself remains the same across direct, preset, protocol and ODK surfaces.

## Pass B — interaction quality

- Tool/instrument surface appears before settings.
- Working result and committed result are distinct.
- Commit freezes the canonical payload.
- Automatic-return origins return only at Commit.
- Displayed useful scalar/text results are tap-to-copy.
- Committed text results expose Share, Save and Done on the same capability surface rather than detouring through a generic result page.
- Fixed preset settings use `CapabilityScreenContext.settingShouldBeShown()`.
- Walkie-talkie audio FSK exposes an explicit PTT/squelch lead-in and explains the manual PTT/VOX use case.
- Near-ultrasonic UI explicitly states that high-frequency audio is device-specific and not guaranteed inaudible.
- Morse front-screen transmission uses a full-screen black/white emitter surface, raises the activity brightness request to maximum for the live transmission, restores the prior brightness on exit, and retains an explicit Stop control.
- Physical TX/RX channel/timing controls are disabled while active so the visible configuration cannot drift from the running hardware session.
- The 0.2 instrument redesign uses capability-specific live surfaces: amber telegraph Morse, cyan optical QR modem, cyan audible FSK modem, violet near-ultrasonic modem and channel-accented sensor oscilloscope. Settings remain subordinate/theme-native.
- QR transmission expands to a full-screen optical surface and requests maximum activity brightness while active; Stop remains explicitly available.
- Morse camera receive uses the same visible ROI that drives luminance analysis, now with Full/Focus/Pinpoint sizes, tap-to-position manual placement, real CameraX zoom and temporal-modulation auto-lock. The lock scores frame-to-frame modulation after removing frame-wide exposure change, then tracks locally around the acquired source.
- Auto-lock deliberately withholds Morse transitions until a source is locked; acquiring/reacquiring the ROI resets the working decoder boundary so search motion cannot be mistaken for Morse.
- QR receive exposes real camera optical zoom through JourneyApps camera parameters (1x / 2x / 4x / device maximum) without changing the QR/MMS contract.
- Sensor scope presents a bounded rolling live trace plus large magnitude/value and axis telemetry.
- Committed result cards use a separate green frozen-record treatment to make live-versus-committed state visually explicit.
- Native control ranges were reconciled to canonical settings: Morse repeat 1–100; Morse microphone 100–10000 Hz / ±10–2000 Hz / -90–0 dBFS; audible FSK 200–8000 Hz; PTT lead 0–5000 ms; FSK repeat 1–20; near-ultrasonic 14000–22000 Hz; bit periods 20–250 ms in 10 ms increments.

## Pass C — field robustness

- Transmitter message IDs are saved working state; Activity recreation cannot silently generate a new QR/FSK MMS/1 identity while retaining completed-cycle state.
- Active audio/light emission and microphone capture stop with the screen; retained settings/complete cycles/decoded text/complete MMS frames remain available after recreation and physical operation restarts explicitly.
- QR receive retains complete distinct MMS/1 frames across recreation while the physical camera-listening flag is deliberately not restored as live.
- Changing a QR receiver message filter clears working shards without deleting an already committed result.
- Changing Morse receiver source/timing/tone thresholds clears working decode evidence without deleting an already committed result.
- Changing FSK receiver carriers/bit period/noise threshold clears working shards and partial physical framing while preserving any committed result.
- FSK transmit/receive committed cards read MARK/SPACE/bit values from frozen canonical fields, not current live controls.
- FSK receive retains complete MMS/1 frames but discards partial physical bit runs on restart.
- Morse microphone reception is module-local and does not depend on another module's private capture implementation.
- Near-ultrasonic receive prefers `UNPROCESSED` where Android advertises it, then `MIC`, before speech-oriented input.
- Raw microphone audio and camera frames are not persisted.
- No network service is used.

## MMS/1 / pure Kotlin smoke tests

The pure codec sources were compiled with the installed Kotlin compiler and exercised outside Android.

### Reed-Solomon recovery

`SignalPacketCodec` smoke test passed for:

- empty, short, multi-shard and UTF-8 text payloads;
- Fast, Robust and Extreme profiles;
- corrupted frame CRC rejection;
- shuffled selection of exactly `k` frames from the coded set, repeated across multiple random selections;
- every consecutive `k`-frame rotation through a looping coded frame set;
- whole-message CRC verification after reconstruction.

Result: **PASS**. The final standalone smoke run completed **20,597 assertions** across MMS/1, Morse and FSK checks, and was rerun unchanged after the v0.2.1 long-range camera/auto-lock pass.

The generator is systematic GF(256) Reed-Solomon based on a Vandermonde matrix transformed so the first `k` rows are identity rows. The test verified the intended first-pass invariant that any `k` distinct generated rows reconstruct the original payload for the tested geometry.

### Morse

Smoke tests passed for:

- text -> Morse notation -> text;
- exact timing simulation;
- adaptive timing with jitter;
- dot durations 80/120/200 ms with initial timing estimates at approximately 0.7x/1.0x/1.4x actual;
- mixed traffic and dash-only `OOO`, dot-only `EEEE`, and `TTT`.

The first adaptive implementation drifted on dash-only traffic. It was changed to normalise a decoded dash to `duration / 3` before updating the dot estimate. Retest: **PASS**.

### FSK physical framing

Smoke tests passed for:

- MMS/1 ASCII frame -> physical FSK bit frame -> arbitrary bitstream sync scan -> exact original MMS/1 frame;
- FSK run decoding sampled at 10 ms intervals for supported 10 ms-aligned bit durations 20, 30, 40, 50, 60, 80, 100 and 150 ms.

Result: **PASS**.

These are codec/unit smoke tests, not evidence that every phone/radio acoustic path will demodulate successfully.

### FSK timing alignment correction

A deeper receiver smoke test identified that the first draft allowed 25 ms and 35 ms bit periods while the dominant-tone receiver emits decisions in 10 ms windows. That quantisation can over/under-count a run. The module contract/UI was tightened before handoff to 20–250 ms in 10 ms steps, with defaults 30 ms (audible FSK) and 40 ms (near-ultrasonic).

## Kotlin static compile-oriented review

The sandbox does not contain a network-clonable MethodMesh repository or the full Android/Compose dependency graph, so a true `:app:compileDebugKotlin` run could not be executed here.

Current MethodMesh `master` interfaces were inspected directly before finalising the module, including:

- `MethodMeshModule` / auto-discovery contract;
- `MethodSetting` constructors;
- `CapabilityScreenSpec`, `CapabilityScreenContext` and preset setting visibility;
- current CameraX/ZXing host dependencies;
- current manifest `CAMERA` and `RECORD_AUDIO` permissions;
- current `PhoneSensorRepository` sensor IDs/units.

A standalone Kotlin parse/compile attempt over the complete module reported the expected unresolved Android/Compose/MethodMesh references in the stripped sandbox; no Kotlin parser `expecting ...` syntax error was identified. A final lexical delimiter/TODO hygiene pass covered all 12 Kotlin source files. Pure non-Android sources compile and run as described above.

## ODK/XLSForm review

Canonical v1.08 showcase workbooks:

- `example_odk_showcase_signal_morse_transmit.xlsx`
- `example_odk_showcase_signal_morse_receive.xlsx`
- `example_odk_showcase_signal_qr_transmit.xlsx`
- `example_odk_showcase_signal_qr_receive.xlsx`
- `example_odk_showcase_signal_audio_fsk_transmit.xlsx`
- `example_odk_showcase_signal_audio_fsk_receive.xlsx`
- `example_odk_showcase_signal_ultrasonic_transmit.xlsx`
- `example_odk_showcase_signal_ultrasonic_receive.xlsx`
- `example_odk_showcase_signal_sensor_scope.xlsx`

All nine generated workbooks were re-imported with `artifact_tool` and inspected during final packaging. The audit found, for every workbook:

- exactly one MethodMesh intent invocation;
- the expected canonical method ID;
- `input_payload_mode='FULL'`;
- `return_mode='flat'`;
- no `methodmesh_return_namespace`;
- direct group-child canonical return names;
- shared `methodmesh_status` and `methodmesh_full_json`;
- no duplicate survey node names;
- human-readable title, lower-snake-case `form_id`, and `2026090901` version;
- no spreadsheet formula-error tokens in the inspected workbook.

Cell/formula error search matched 0 entries across the nine canonical workbooks.

The capability-return inventory had already been cross-checked against the declared method outputs when the workbooks were generated; no XLSForm-only capability return field was added.

`pyxform` is **not installed in this packaging environment** (`ModuleNotFoundError`), so pyxform/ODK Validate and actual ODK Central/Kobo import are explicitly still receiving-environment checks. The structural audit is not presented as provider validation.

## Receiving-repository checks required before Production promotion

Run at least:

```text
./gradlew :app:compileDebugKotlin
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
./gradlew generateMethodMeshOdkTemplateAssets
```

Then run the MethodMesh XLSForm batch validator and, where available, pyxform/ODK Validate plus provider upload checks.

## Physical-device smoke matrix

1. **Morse screen TX -> camera RX**: test 5, 8, 12 WPM; different brightness/ambient-light conditions.
2. **Morse torch TX -> camera RX**: verify torch control and camera exposure behaviour on at least two manufacturers.
3. **Morse screen/torch -> lux RX**: use slow timing; record actual device sensor update rate and minimum reliable WPM.
4. **Morse audio TX -> microphone RX**: verify 700 Hz default and several noise levels.
5. **QR burst**: start receiver mid-loop; obstruct/miss several QR frames; confirm Reed-Solomon recovery and CRC status.
6. **Audio FSK phone-to-phone**: verify default 1200/2200 Hz, several bit durations and Fast/Robust profiles.
7. **Walkie-talkie FSK**: phone speaker -> radio mic -> radio speaker -> phone mic; test squelch/VOX/PTT lead values and clipping.
8. **Near-ultrasonic**: first inspect device response; verify whether 18/19 kHz are physically emitted/received; do not promote based on one phone pair.
9. **Rotation/recreation**: rotate during each TX/RX; confirm active physical operation stops or is visibly paused while meaningful working state is retained.
10. **Preset**: mark message/settings fixed/runtime in several combinations; ensure fixed settings do not reappear.
11. **Protocol**: execute each capability as a protocol step and verify prior result/next-step rails in the shared runtime.
12. **ODK**: exercise all nine single-call showcase forms ODK -> MethodMesh -> ODK and verify committed beef plus `methodmesh_full_json`.
13. **Kobo**: import the canonical workbooks unchanged where external-app intent behaviour is supported by the collector build; provider limitations must be reported separately from XLSForm syntax.

## Known limitations / intentionally non-Production items

- Near-ultrasonic behaviour is hardware-specific and remains Experimental.
- MMS/1 is error detection/recovery, not cryptographic authentication/encryption.
- First-pass audio FSK serialises the human-readable ASCII MMS/1 frame; it is deliberately robust/simple rather than bandwidth-efficient.
- Ordinary Morse uses repetition/looping and adaptive timing, not MMS/1 Reed-Solomon packet mode yet.
- Ambient-light sensors may be too slow for ordinary Morse speeds on some phones.
- ESP-NOW, ESP32-LR, magnetic coil and surface/vibration modems are roadmap work, not registered capabilities.
- Full Android Gradle compilation and physical hardware validation must be completed in the receiving repository/device environment before Production promotion.

## v0.2.1 long-range camera optics device checks

1. **Morse manual ROI**: start camera reception, choose Pinpoint, tap a small flashing source near each edge/corner, and verify only the selected region drives SIGNAL/QUIET state.
2. **Morse optical zoom**: repeat at 1x / 2x / 4x / device maximum and confirm the preview and analysis remain aligned.
3. **Morse auto-lock**: with at least one static bright distractor in frame, tap Find signal and verify the reticle locks to the modulating source rather than the brightest region; move the transmitter slowly and verify local tracking.
4. **Morse lock loss**: occlude the source for >0.5 s, verify LOCK LOST / reacquisition behaviour, and confirm no spurious characters are appended during search.
5. **QR zoom**: receive the existing QR burst at increasing range using 1x / 2x / 4x / Max and verify shard acceptance remains unchanged apart from optical acquisition.

These are physical-device checks; the standalone handoff environment cannot validate camera optics or autofocus/zoom behaviour across handset models.
