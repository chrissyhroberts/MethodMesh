package com.example.methodmesh.modules.display

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenScaffold
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.delay
import java.time.Instant

internal class DisplayCapabilityScreen(private val method: DisplayMethod) : CapabilityScreenSpec {
    override val capabilityId = method.id
    override val title = method.title
    override val description = method.help

    @Composable
    override fun Render(context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
        DisplayUi(method, context, onBack, onConfirmed, onCancel)
    }
}

@Composable
private fun DisplayUi(method: DisplayMethod, context: CapabilityScreenContext, onBack: () -> Unit, onConfirmed: (ExecutionResult) -> Unit, onCancel: () -> Unit) {
    fun initial(key: String, fallback: String) = context.action.settings[key] ?: context.action.settings["input_$key"] ?: fallback
    var text by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("text", method.defaultText)) }
    var alignment by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("alignment", "center")) }
    var rotation by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("content_rotation", "0").toIntOrNull() ?: 0) }
    var textScale by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("text_scale", "1.0").toFloatOrNull() ?: 1f) }
    var speed by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("speed", "1.0").toFloatOrNull() ?: 1f) }
    var direction by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("direction", "left")) }
    var durationSeconds by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("duration_seconds", "3").toIntOrNull() ?: 3) }
    var highBrightness by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("high_brightness", "true").toBoolean()) }
    var loop by rememberSaveable(context.action.canonicalId) { mutableStateOf(initial("loop", "true").toBoolean()) }
    var showing by rememberSaveable(context.action.canonicalId) { mutableStateOf(false) }
    var startedIso by rememberSaveable(context.action.canonicalId) { mutableStateOf("") }
    var startedElapsed by rememberSaveable(context.action.canonicalId) { mutableStateOf(0L) }
    var committed by remember { mutableStateOf<ExecutionResult?>(null) }

    fun settings() = context.action.settings + mapOf("text" to text, "alignment" to alignment, "content_rotation" to rotation.toString(), "text_scale" to textScale.toString(),
        "speed" to speed.toString(), "direction" to direction, "duration_seconds" to durationSeconds.toString(), "loop" to loop.toString(), "high_brightness" to highBrightness.toString())

    fun finishDisplay(commit: Boolean) {
        showing = false
        if (!commit || startedIso.isBlank()) return
        val stopped = Instant.now().toString()
        val elapsed = (android.os.SystemClock.elapsedRealtime() - startedElapsed).coerceAtLeast(0L)
        val values = method.values(settings(), startedIso, stopped, elapsed)
        val request = method.request(method.id, context.request.invocationContext.asMap(method.id) + settings() + values, emptyList(), emptyList())
        val result = method.result(request, values, context.request.invocationContext)
        committed = result
        if (context.submitsImmediately) onConfirmed(result)
    }

    CapabilityScreenScaffold(title = method.title, capabilityId = method.id, context = context, canGoBack = context.stepNumber > 1,
        capturedResult = committed, resultPreview = emptyMap(), onBack = onBack, onRetry = { committed = null },
        onConfirm = { committed?.let(onConfirmed) }, onCancel = { if (showing) finishDisplay(false); onCancel() }) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (committed == null) {
                if (context.settingShouldBeShown("text")) OutlinedTextField(text, { text = it }, label = { Text(if (method == SequenceDisplayMethod) "Messages — one per line" else "Message") }, modifier = Modifier.fillMaxWidth(), minLines = if (method == BoardDisplayMethod || method == SequenceDisplayMethod) 3 else 1)
                Card(Modifier.fillMaxWidth()) { Box(Modifier.fillMaxWidth().padding(18.dp), contentAlignment = Alignment.Center) { Text(text.ifBlank { "Your message" }, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, maxLines = 4) } }
                if (context.settingShouldBeShown("high_brightness")) ChoiceRow("Brightness", highBrightness.toString(), listOf("true", "false")) { highBrightness = it.toBoolean() }
                if (context.settingShouldBeShown("alignment")) ChoiceRow("Alignment", alignment, listOf("start", "center", "end")) { alignment = it }
                if (method == MarqueeDisplayMethod) {
                    if (context.settingShouldBeShown("direction")) ChoiceRow("Direction", direction, listOf("left", "right")) { direction = it }
                    if (context.settingShouldBeShown("speed")) Stepper("Speed", speed, { speed = (speed - .25f).coerceAtLeast(.25f) }, { speed = (speed + .25f).coerceAtMost(4f) })
                }
                if (method == SequenceDisplayMethod) {
                    Stepper("Seconds per message", durationSeconds.toFloat(), { durationSeconds = (durationSeconds - 1).coerceAtLeast(1) }, { durationSeconds = (durationSeconds + 1).coerceAtMost(300) })
                    ChoiceRow("Loop", loop.toString(), listOf("true", "false")) { loop = it.toBoolean() }
                }
                Button(enabled = text.isNotBlank(), onClick = { startedIso = Instant.now().toString(); startedElapsed = android.os.SystemClock.elapsedRealtime(); showing = true }, modifier = Modifier.fillMaxWidth()) { Text("SHOW") }
            } else {
                Text("Display committed.", style = MaterialTheme.typography.titleMedium)
                Text("The displayed message and final live presentation settings are frozen in the canonical result.")
                Button(onClick = { committed?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
                OutlinedButton(onClick = { committed = null }, modifier = Modifier.fillMaxWidth()) { Text("New display") }
            }
        }
    }

    if (showing) FullScreenDisplay(method, text, alignment, rotation, textScale, speed, direction, durationSeconds, loop,
        highBrightness = highBrightness, onScale = { textScale = it }, onRotation = { rotation = it }, onSpeed = { speed = it }, onStop = { finishDisplay(true) }, onCancel = { finishDisplay(false) })
}

@Composable
private fun FullScreenDisplay(method: DisplayMethod, text: String, alignment: String, rotation: Int, textScale: Float, speed: Float, direction: String,
    durationSeconds: Int, loop: Boolean, highBrightness: Boolean, onScale: (Float) -> Unit, onRotation: (Int) -> Unit, onSpeed: (Float) -> Unit, onStop: () -> Unit, onCancel: () -> Unit) {
    val view = LocalView.current
    val activity = LocalContext.current.findActivity()
    var controls by rememberSaveable { mutableStateOf(true) }
    var paused by rememberSaveable { mutableStateOf(false) }
    var sequenceIndex by rememberSaveable { mutableStateOf(0) }
    val messages = remember(text) { text.lines().map(String::trim).filter(String::isNotBlank).ifEmpty { listOf(text) } }

    DisposableEffect(activity, view) {
        val window = activity?.window
        val oldBrightness = window?.attributes?.screenBrightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        view.keepScreenOn = true
        if (highBrightness) window?.attributes = window?.attributes?.also { it.screenBrightness = 1f }
        window?.decorView?.systemUiVisibility = (android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        onDispose {
            view.keepScreenOn = false
            window?.attributes = window?.attributes?.also { it.screenBrightness = oldBrightness }
            window?.decorView?.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_VISIBLE
        }
    }
    BackHandler { onCancel() }
    LaunchedEffect(method.id, paused, durationSeconds, loop, messages.size) {
        if (method != SequenceDisplayMethod) return@LaunchedEffect
        while (!paused && messages.size > 1) {
            delay(durationSeconds.coerceAtLeast(1) * 1000L)
            if (sequenceIndex == messages.lastIndex && !loop) { paused = true; break }
            sequenceIndex = (sequenceIndex + 1) % messages.size
        }
    }

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize().clipToBounds().pointerInput(Unit) { detectTapGestures { controls = !controls } }
                .pointerInput(Unit) { detectTransformGestures { _, _, zoom, _ -> onScale((textScale * zoom).coerceIn(.25f, 4f)) } }) {
                val shownText = if (method == SequenceDisplayMethod) messages[sequenceIndex.coerceIn(0, messages.lastIndex)] else text
                DisplayMessage(method, shownText, alignment, rotation, textScale, speed, direction, paused)
                if (controls) LiveControls(method, textScale, rotation, speed, paused, onScale, onRotation, onSpeed, { paused = !paused }, onStop, Modifier.align(Alignment.BottomCenter))
            }
        }
    }
}

@Composable
private fun DisplayMessage(method: DisplayMethod, text: String, alignment: String, rotation: Int, textScale: Float, speed: Float, direction: String, paused: Boolean) {
    var boxWidth by remember { mutableStateOf(1000) }
    val baseSp = when (method) { CodeDisplayMethod -> 150f; BoardDisplayMethod -> 64f; else -> 92f }
    val align = when (alignment) { "start" -> TextAlign.Start; "end" -> TextAlign.End; else -> TextAlign.Center }
    val common = Modifier.fillMaxSize().onGloballyPositioned { boxWidth = it.size.width }.graphicsLayer(rotationZ = rotation.toFloat())
    if (method == MarqueeDisplayMethod) {
        val transition = rememberInfiniteTransition(label = "marquee")
        val x by transition.animateFloat(initialValue = if (direction == "left") boxWidth.toFloat() else -boxWidth.toFloat(), targetValue = if (direction == "left") -boxWidth.toFloat() else boxWidth.toFloat(),
            animationSpec = infiniteRepeatable(tween((9000 / speed.coerceAtLeast(.25f)).toInt(), easing = LinearEasing), RepeatMode.Restart), label = "marquee-x")
        Box(common, contentAlignment = Alignment.CenterStart) {
            BasicText(text, style = TextStyle(color = Color.White, fontSize = (baseSp * textScale).sp, fontWeight = FontWeight.Bold), maxLines = 1,
                modifier = Modifier.graphicsLayer(translationX = if (paused) 0f else x))
        }
    } else {
        Box(common.padding(18.dp), contentAlignment = Alignment.Center) {
            BasicText(text, style = TextStyle(color = Color.White, fontSize = (baseSp * textScale).sp, fontWeight = FontWeight.Bold, textAlign = align), modifier = Modifier.widthIn(max = 1200.dp))
        }
    }
}

@Composable
private fun LiveControls(method: DisplayMethod, scale: Float, rotation: Int, speed: Float, paused: Boolean, onScale: (Float) -> Unit, onRotation: (Int) -> Unit, onSpeed: (Float) -> Unit, onPause: () -> Unit, onStop: () -> Unit, modifier: Modifier = Modifier) {
    Surface(modifier.fillMaxWidth(), color = Color.Black.copy(alpha = .72f)) {
        Row(Modifier.padding(10.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { onScale((scale - .15f).coerceAtLeast(.25f)) }) { Text("A−") }
            OutlinedButton(onClick = { onScale((scale + .15f).coerceAtMost(4f)) }) { Text("A+") }
            OutlinedButton(onClick = { onScale(1f) }) { Text("Fit") }
            OutlinedButton(onClick = { onRotation((rotation + 90) % 360) }) { Text("Rotate") }
            if (method == MarqueeDisplayMethod) {
                OutlinedButton(onClick = { onSpeed((speed - .25f).coerceAtLeast(.25f)) }) { Text("Slower") }
                OutlinedButton(onClick = { onSpeed((speed + .25f).coerceAtMost(4f)) }) { Text("Faster") }
            }
            if (method == MarqueeDisplayMethod || method == SequenceDisplayMethod) OutlinedButton(onClick = onPause) { Text(if (paused) "Resume" else "Pause") }
            Button(onClick = onStop) { Text("STOP") }
        }
    }
}

@Composable private fun ChoiceRow(label: String, selected: String, choices: List<String>, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(label, style = MaterialTheme.typography.labelLarge); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { choices.forEach { if (it == selected) Button(onClick = { onSelect(it) }) { Text(it) } else OutlinedButton(onClick = { onSelect(it) }) { Text(it) } } } }
}
@Composable private fun Stepper(label: String, value: Float, down: () -> Unit, up: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("$label: ${if (value % 1f == 0f) value.toInt() else value}"); Row { OutlinedButton(onClick = down) { Text("−") }; OutlinedButton(onClick = up) { Text("+") } } }
}
private tailrec fun Context.findActivity(): Activity? = when (this) { is Activity -> this; is ContextWrapper -> baseContext.findActivity(); else -> null }
