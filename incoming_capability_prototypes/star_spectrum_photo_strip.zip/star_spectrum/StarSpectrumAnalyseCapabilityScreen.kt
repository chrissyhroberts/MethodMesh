package com.example.methodmesh.modules.star_spectrum

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.example.methodmesh.core.crypto.Digests
import com.example.methodmesh.core.methodmesh.ExecutionResult
import com.example.methodmesh.settings.SettingsState
import com.example.methodmesh.transport.OutputFormatter
import com.example.methodmesh.transport.ReturnMode
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenContext
import com.example.methodmesh.transport.workflow.ui.CapabilityScreenSpec
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale

object StarSpectrumAnalyseCapabilityScreen : CapabilityScreenSpec {
    override val capabilityId = As100StarSpectrumAnalyseMethod.ID
    override val title = "Star spectrum analyser"
    override val description = "Draw roughly along a slitless stellar spectrum; MethodMesh refines the trace, rejects spatial contamination, calibrates against an optional saved reference star, detects features and exports analysis-ready data."

    @Composable
    override fun Render(
        context: CapabilityScreenContext,
        onBack: () -> Unit,
        onConfirmed: (ExecutionResult) -> Unit,
        onCancel: () -> Unit
    ) {
        val appContext = LocalContext.current
        val scope = rememberCoroutineScope()
        val definitions = remember { StarSpectrumModule.capabilitySettings()[capabilityId].orEmpty() }
        val settings = remember(context.action.settings) {
            SettingsState(definitions) { key, value -> context.onSettingsChanged(mapOf(key to value.toString())) }
                .also { initialiseSpectrumSettings(it, definitions, context) }
        }

        val initialSourceUri = contextInput(context, "source_image_uri")
        var sourceUri by rememberSaveable { mutableStateOf(initialSourceUri) }
        var sourceOrigin by rememberSaveable { mutableStateOf(if (initialSourceUri.isBlank()) "methodmesh" else "caller") }
        var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
        var sourceError by rememberSaveable { mutableStateOf<String?>(null) }
        var traceStartX by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var traceStartY by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var traceEndX by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var traceEndY by rememberSaveable { mutableFloatStateOf(Float.NaN) }
        var showEndpointPicker by rememberSaveable { mutableStateOf(false) }
        var openPickerWhenImageLoads by rememberSaveable { mutableStateOf(false) }
        var extraction by remember { mutableStateOf<SpectrumExtraction?>(null) }
        var workingValuesJson by rememberSaveable { mutableStateOf("") }
        var committedValuesJson by rememberSaveable { mutableStateOf("") }
        var shouldRestoreAnalysis by rememberSaveable { mutableStateOf(false) }
        var analysisError by rememberSaveable { mutableStateOf<String?>(null) }
        var isAnalysing by rememberSaveable { mutableStateOf(false) }
        var showAdvanced by rememberSaveable { mutableStateOf(false) }
        var exportStatus by rememberSaveable { mutableStateOf<String?>(null) }
        var includeFullJson by rememberSaveable { mutableStateOf(false) }
        var selectedReferenceId by rememberSaveable {
            mutableStateOf(settings.getString("reference_id").ifBlank { contextInput(context, "reference_id") })
        }
        var registrationOffset by rememberSaveable { mutableFloatStateOf(settings.getFloat("registration_offset_px")) }
        var ribbonWidth by rememberSaveable { mutableIntStateOf(settings.getInt("ribbon_half_width_px").coerceAtLeast(6)) }
        var apertureWidth by rememberSaveable { mutableIntStateOf(settings.getInt("aperture_half_width_px").coerceAtLeast(1)) }
        var backgroundGap by rememberSaveable { mutableIntStateOf(settings.getInt("background_gap_px").coerceAtLeast(1)) }
        var continuumWindow by rememberSaveable { mutableIntStateOf(settings.getInt("continuum_window").coerceAtLeast(9)) }
        var detectionSigma by rememberSaveable { mutableFloatStateOf(settings.getFloat("detection_sigma").coerceAtLeast(2f)) }
        var detectionMode by rememberSaveable { mutableStateOf(settings.getString("detection_mode").ifBlank { "both" }) }

        val references = remember { SpectrumReferenceRepository.list(appContext) }
        val selectedReference = references.firstOrNull { it.id == selectedReferenceId }
        val trace = if (traceStartX.isFinite() && traceStartY.isFinite() && traceEndX.isFinite() && traceEndY.isFinite()) {
            TraceSelection(traceStartX, traceStartY, traceEndX, traceEndY)
        } else null

        fun updateTrace(value: TraceSelection?) {
            if (value == null) {
                traceStartX = Float.NaN; traceStartY = Float.NaN; traceEndX = Float.NaN; traceEndY = Float.NaN
            } else {
                traceStartX = value.startX; traceStartY = value.startY; traceEndX = value.endX; traceEndY = value.endY
            }
            extraction = null
            workingValuesJson = ""
            committedValuesJson = ""
            shouldRestoreAnalysis = false
        }

        fun valuesMap(json: String): Map<String, String> = runCatching {
            val obj = JSONObject(json)
            buildMap { obj.keys().forEach { key -> put(key, obj.optString(key, "")) } }
        }.getOrDefault(emptyMap())

        fun executionFor(json: String): ExecutionResult? {
            if (json.isBlank()) return null
            val values = valuesMap(json)
            val request = As100StarSpectrumAnalyseMethod.request(
                action = capabilityId,
                context = context.request.invocationContext.asMap(capabilityId) + values,
                signals = emptyList(),
                inputs = emptyList()
            )
            return As100StarSpectrumAnalyseMethod.result(request, values, context.request.invocationContext)
        }

        val workingResult = remember(workingValuesJson, context.request.invocationContext) { executionFor(workingValuesJson) }
        val committedResult = remember(committedValuesJson, context.request.invocationContext) { executionFor(committedValuesJson) }
        val isCommitted = committedResult != null

        fun invalidateWorking() {
            if (!isCommitted) {
                extraction = null
                workingValuesJson = ""
                shouldRestoreAnalysis = false
                analysisError = null
            }
        }

        val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                SpectrumImageIO.takePersistableReadPermission(appContext, uri)
                sourceUri = uri.toString()
                sourceOrigin = "methodmesh"
                context.onSettingsChanged(mapOf("source_image_uri" to sourceUri))
                updateTrace(null)
                openPickerWhenImageLoads = true
                sourceError = null
            }
        }

        LaunchedEffect(sourceUri) {
            sourceBitmap = null
            if (sourceUri.isBlank()) return@LaunchedEffect
            sourceError = null
            runCatching { withContext(Dispatchers.IO) { SpectrumImageIO.decode(appContext, sourceUri) } }
                .onSuccess { sourceBitmap = it }
                .onFailure { sourceError = it.message ?: "Could not open the spectrum image." }
        }

        DisposableEffect(sourceBitmap) {
            val bitmap = sourceBitmap
            onDispose { bitmap?.takeUnless { it.isRecycled }?.recycle() }
        }

        LaunchedEffect(sourceBitmap, openPickerWhenImageLoads) {
            if (sourceBitmap != null && openPickerWhenImageLoads) {
                showEndpointPicker = true
                openPickerWhenImageLoads = false
            }
        }

        sourceBitmap?.let { bitmap ->
            if (showEndpointPicker) {
                SpectrumEndpointPickerDialog(
                    bitmap = bitmap,
                    initialTrace = trace,
                    onDismiss = { showEndpointPicker = false },
                    onSelected = { selected ->
                        updateTrace(selected)
                        showEndpointPicker = false
                    }
                )
            }
        }

        fun currentAnalysisSettings() = SpectrumAnalysisSettings(
            ribbonHalfWidthPx = ribbonWidth,
            apertureHalfWidthPx = minOf(apertureWidth, maxOf(1, ribbonWidth - 2)),
            backgroundGapPx = minOf(backgroundGap, maxOf(1, ribbonWidth - apertureWidth - 1)),
            continuumWindow = continuumWindow,
            detectionSigma = detectionSigma.toDouble(),
            detectionMode = detectionMode
        )

        fun analyseNow(restoring: Boolean = false) {
            val bitmap = sourceBitmap ?: run {
                analysisError = "Choose a spectrum image first."
                return
            }
            val line = trace ?: run {
                analysisError = "Select the RED and VIOLET endpoints first."
                return
            }
            if (line.length < 24f) {
                analysisError = "The selected endpoints are too close together. Select the origin and far end of the visible spectrum."
                return
            }
            if (isAnalysing) return
            isAnalysing = true
            analysisError = null
            if (!restoring) committedValuesJson = ""
            val analysisSettings = currentAnalysisSettings()
            scope.launch {
                runCatching {
                    withContext(Dispatchers.Default) {
                        val calibration = selectedReference?.let {
                            SpectrumEngine.calibrationForTarget(it, bitmap.width, bitmap.height, registrationOffset.toDouble())
                        }
                        val result = SpectrumEngine.analyse(
                            bitmap = bitmap,
                            startX = line.startX.toDouble(), startY = line.startY.toDouble(),
                            endX = line.endX.toDouble(), endY = line.endY.toDouble(),
                            settings = analysisSettings,
                            calibration = calibration
                        )
                        val artifacts = SpectrumExport.writeAnalysisArtifacts(
                            appContext, bitmap, result, sourceUri.substringAfterLast('/'), analysisSettings
                        )
                        val sourceReturnFile = if (sourceOrigin == "methodmesh") {
                            SpectrumImageIO.copyOriginalToCache(appContext, sourceUri, "methodmesh_star_spectrum_source")
                        } else null
                        Triple(result, artifacts, sourceReturnFile)
                    }
                }.onSuccess { (result, artifacts, sourceReturnFile) ->
                    extraction = result
                    val authority = "${appContext.packageName}.fileprovider"
                    val sourceReturnUri = sourceReturnFile?.let { FileProvider.getUriForFile(appContext, authority, it).toString() }.orEmpty()
                    val annotatedUri = FileProvider.getUriForFile(appContext, authority, artifacts.annotatedImage).toString()
                    val dataUri = FileProvider.getUriForFile(appContext, authority, artifacts.dataCsv).toString()
                    val featuresUri = FileProvider.getUriForFile(appContext, authority, artifacts.peaksCsv).toString()
                    val metadataUri = FileProvider.getUriForFile(appContext, authority, artifacts.metadataJson).toString()
                    val wavelengths = result.distancesPx.indices.mapNotNull { result.wavelengthAt(it) }
                    val values = linkedMapOf(
                        StarSpectrumAnalyseFields.STATUS to "succeeded",
                        StarSpectrumAnalyseFields.SOURCE_IMAGE_URI to sourceReturnUri,
                        StarSpectrumAnalyseFields.SOURCE_IMAGE_SHA256 to sourceReturnFile?.let { Digests.sha256Hex(it.readBytes()) }.orEmpty(),
                        StarSpectrumAnalyseFields.ANNOTATED_IMAGE_URI to annotatedUri,
                        StarSpectrumAnalyseFields.DATA_URI to dataUri,
                        StarSpectrumAnalyseFields.FEATURES_URI to featuresUri,
                        StarSpectrumAnalyseFields.METADATA_URI to metadataUri,
                        StarSpectrumAnalyseFields.ANNOTATED_IMAGE_SHA256 to Digests.sha256Hex(artifacts.annotatedImage.readBytes()),
                        StarSpectrumAnalyseFields.DATA_SHA256 to Digests.sha256Hex(artifacts.dataCsv.readBytes()),
                        StarSpectrumAnalyseFields.FEATURES_SHA256 to Digests.sha256Hex(artifacts.peaksCsv.readBytes()),
                        StarSpectrumAnalyseFields.FEATURES_JSON to SpectrumExport.featuresJson(result.features),
                        StarSpectrumAnalyseFields.FEATURES_TEXT to SpectrumExport.featuresText(result.features),
                        StarSpectrumAnalyseFields.FEATURE_COUNT to result.features.size.toString(),
                        StarSpectrumAnalyseFields.REFERENCE_ID to result.calibration?.reference?.id.orEmpty(),
                        StarSpectrumAnalyseFields.REFERENCE_NAME to result.calibration?.reference?.name.orEmpty(),
                        StarSpectrumAnalyseFields.CALIBRATION_RMS_NM to result.calibration?.reference?.rmsNm?.toString().orEmpty(),
                        StarSpectrumAnalyseFields.CALIBRATION_CONFIDENCE to result.calibration?.confidence?.toString().orEmpty(),
                        StarSpectrumAnalyseFields.CALIBRATION_WARNING to result.calibration?.warning.orEmpty(),
                        StarSpectrumAnalyseFields.WAVELENGTH_MIN_NM to wavelengths.minOrNull()?.toString().orEmpty(),
                        StarSpectrumAnalyseFields.WAVELENGTH_MAX_NM to wavelengths.maxOrNull()?.toString().orEmpty(),
                        StarSpectrumAnalyseFields.TRACE_QUALITY to result.trace.traceQuality.toString(),
                        StarSpectrumAnalyseFields.TRACE_MEAN_CORRECTION_PX to result.trace.meanAbsoluteCorrectionPx.toString(),
                        StarSpectrumAnalyseFields.MEAN_SNR to result.meanSnr.toString(),
                        StarSpectrumAnalyseFields.CONTAMINATED_FRACTION to result.contaminatedFraction.toString(),
                        StarSpectrumAnalyseFields.SOURCE_WIDTH_PX to bitmap.width.toString(),
                        StarSpectrumAnalyseFields.SOURCE_HEIGHT_PX to bitmap.height.toString(),
                        StarSpectrumAnalyseFields.INTENSITY_SEMANTICS to "relative detector/image signal; not calibrated photon counts unless the source image is radiometrically linear and calibrated",
                        StarSpectrumAnalyseFields.METADATA_JSON to SpectrumExport.metadataJson(result, sourceUri.substringAfterLast('/'), analysisSettings).toString(),
                        StarSpectrumAnalyseFields.ERROR to ""
                    )
                    workingValuesJson = JSONObject(values as Map<*, *>).toString()
                    shouldRestoreAnalysis = true
                }.onFailure {
                    analysisError = it.message ?: "Spectrum analysis failed."
                    if (!restoring) shouldRestoreAnalysis = false
                }
                isAnalysing = false
            }
        }

        LaunchedEffect(sourceBitmap, shouldRestoreAnalysis, extraction, committedValuesJson) {
            if (sourceBitmap != null && shouldRestoreAnalysis && extraction == null && trace != null && !isAnalysing) {
                analyseNow(restoring = true)
            }
        }

        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SpectrumToolHeader(
                title = title,
                subtitle = "2-D trace optimisation · contamination rejection · reusable wavelength calibration",
                committed = isCommitted,
                canGoBack = context.stepNumber > 1,
                onBack = onBack,
                onCancel = onCancel
            )

            if (!isCommitted) {
                SpectrumSection(
                    "1 · Observation",
                    "Load the star-field or slitless-spectrum image. Raster images work offline; FITS import is deliberately deferred from this first version."
                ) {
                    if (context.settingShouldBeShown("source_image_uri")) {
                        Button(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (sourceUri.isBlank()) "Upload spectrum photo" else "Replace spectrum photo")
                        }
                    }
                    if (sourceUri.isNotBlank()) {
                        Text(sourceUri.substringAfterLast('/'), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    sourceError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }

                SpectrumSection(
                    "2 · Wavelength reference",
                    "Use one of your stored A-star calibrations, or stay in pixel coordinates. A small registration offset handles repeat-observation shifts."
                ) {
                    if (references.isEmpty()) {
                        Text("No saved reference stars yet. This run can still be analysed in pixel coordinates.")
                    } else if (context.settingShouldBeShown("reference_id")) {
                        ReferenceChips(references, selectedReferenceId) { id ->
                            selectedReferenceId = id
                            settings.setString("reference_id", id)
                            context.onSettingsChanged(mapOf("reference_id" to id))
                            invalidateWorking()
                        }
                    } else {
                        Text(selectedReference?.name ?: "Pixels only", fontWeight = FontWeight.SemiBold)
                    }
                    if (selectedReference != null && context.settingShouldBeShown("registration_offset_px")) {
                        Spacer(Modifier.padding(top = 3.dp))
                        Text("Registration offset  %.1f px".format(Locale.US, registrationOffset), style = MaterialTheme.typography.labelLarge)
                        Slider(
                            value = registrationOffset,
                            onValueChange = {
                                registrationOffset = it
                                settings.setFloat("registration_offset_px", it)
                                context.onSettingsChanged(mapOf("registration_offset_px" to it.toString()))
                                invalidateWorking()
                            },
                            valueRange = -100f..100f
                        )
                        selectedReference?.let {
                            Text("${it.starName.ifBlank { it.name }} · ${it.spectralType} · RMS %.3f nm".format(Locale.US, it.rmsNm), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                sourceBitmap?.let { bitmap ->
                    SpectrumSection(
                        "3 · Spectrum endpoints",
                        "The uploaded image opens full screen. Tap the RED end, then tap the VIOLET end. MethodMesh uses those two points only to define the search corridor; the extraction engine still refines the actual trace inside it."
                    ) {
                        SpectrumImageSurface(
                            bitmap = bitmap,
                            trace = trace,
                            onSelectEndpoints = { showEndpointPicker = true },
                            ribbonHalfWidthPx = ribbonWidth,
                            extraction = extraction
                        )
                    }
                }

                SpectrumSection("4 · Extraction and feature detection") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showAdvanced = !showAdvanced }, modifier = Modifier.weight(1f)) {
                            Text(if (showAdvanced) "Hide controls" else "Tune controls")
                        }
                        Button(
                            onClick = { analyseNow(false) },
                            enabled = sourceBitmap != null && trace != null && !isAnalysing,
                            modifier = Modifier.weight(1f)
                        ) { Text(if (isAnalysing) "Analysing…" else "Analyse") }
                    }
                    if (showAdvanced) {
                        Text("Search ribbon  $ribbonWidth px", style = MaterialTheme.typography.labelLarge)
                        Slider(value = ribbonWidth.toFloat(), onValueChange = {
                            ribbonWidth = it.toInt().coerceIn(6, 120); settings.setInt("ribbon_half_width_px", ribbonWidth); context.onSettingsChanged(mapOf("ribbon_half_width_px" to ribbonWidth.toString())); invalidateWorking()
                        }, valueRange = 6f..120f)
                        Text("Extraction aperture  ±$apertureWidth px", style = MaterialTheme.typography.labelLarge)
                        Slider(value = apertureWidth.toFloat(), onValueChange = {
                            apertureWidth = it.toInt().coerceIn(1, maxOf(1, ribbonWidth - 2)); settings.setInt("aperture_half_width_px", apertureWidth); context.onSettingsChanged(mapOf("aperture_half_width_px" to apertureWidth.toString())); invalidateWorking()
                        }, valueRange = 1f..minOf(30f, maxOf(2f, ribbonWidth - 2f)))
                        Text("Background gap  $backgroundGap px", style = MaterialTheme.typography.labelLarge)
                        Slider(value = backgroundGap.toFloat(), onValueChange = {
                            backgroundGap = it.toInt().coerceIn(1, 30); settings.setInt("background_gap_px", backgroundGap); context.onSettingsChanged(mapOf("background_gap_px" to backgroundGap.toString())); invalidateWorking()
                        }, valueRange = 1f..30f)
                        Text("Continuum window  $continuumWindow samples", style = MaterialTheme.typography.labelLarge)
                        Slider(value = continuumWindow.toFloat(), onValueChange = {
                            continuumWindow = it.toInt().coerceIn(9, 301); settings.setInt("continuum_window", continuumWindow); context.onSettingsChanged(mapOf("continuum_window" to continuumWindow.toString())); invalidateWorking()
                        }, valueRange = 9f..301f)
                        Text("Feature threshold  %.2fσ".format(Locale.US, detectionSigma), style = MaterialTheme.typography.labelLarge)
                        Slider(value = detectionSigma, onValueChange = {
                            detectionSigma = it; settings.setFloat("detection_sigma", it); context.onSettingsChanged(mapOf("detection_sigma" to it.toString())); invalidateWorking()
                        }, valueRange = 2f..8f)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("both", "emission", "absorption").forEach { option ->
                                FilterChip(selected = detectionMode == option, onClick = {
                                    detectionMode = option; settings.setString("detection_mode", option); context.onSettingsChanged(mapOf("detection_mode" to option)); invalidateWorking()
                                }, label = { Text(option.replaceFirstChar { it.uppercase() }) })
                            }
                        }
                    }
                    analysisError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }

                extraction?.let { result ->
                    SpectrumSection("Live result", "Orange marks are likely 2-D contaminants; high-contamination samples remain flagged in the exported table rather than being silently trusted.") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricTile("Trace quality", "%.0f%%".format(Locale.US, result.trace.traceQuality * 100), modifier = Modifier.weight(1f))
                            MetricTile("Features", result.features.size.toString(), modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.padding(top = 4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricTile("Contaminated", "%.1f%%".format(Locale.US, result.contaminatedFraction * 100), modifier = Modifier.weight(1f))
                            MetricTile("Calibration", result.calibration?.let { "%.0f%%".format(Locale.US, it.confidence * 100) } ?: "pixels", modifier = Modifier.weight(1f))
                        }
                        result.calibration?.warning?.takeIf { it.isNotBlank() }?.let { Text(it, color = MaterialTheme.colorScheme.tertiary) }
                        Spacer(Modifier.padding(top = 4.dp))
                        SpectrumChart(result)
                    }
                    SpectrumSection("Detected spectral features", "Tap any row to copy it. Confidence combines local significance, prominence, multi-threshold stability and contamination evidence; it is not an elemental identification probability.") {
                    SpectrumSection(
                        "Extracted spectrum appearance",
                        "Horizontal photographic appearance of the optimised extraction, shown VIOLET → RED."
                    ) {
                        ExtractedSpectrumStrip(
                            bitmap = bitmap,
                            extraction = spectrum,
                            apertureHalfWidthPx = apertureWidth
                        )
                    }

                        FeatureList(result.features)
                    }
                    Button(
                        onClick = {
                            val resultExecution = workingResult ?: return@Button
                            committedValuesJson = workingValuesJson
                            if (context.submitsImmediately) onConfirmed(resultExecution)
                        },
                        enabled = workingResult != null,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Commit analysis") }
                }
            } else {
                val values = valuesMap(committedValuesJson)
                SpectrumSection("Committed analysis", "The canonical result is frozen. Save or share the artefacts, copy the detected-feature list, then finish.") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile("Features", values[StarSpectrumAnalyseFields.FEATURE_COUNT].orEmpty(), modifier = Modifier.weight(1f))
                        MetricTile("Trace quality", values[StarSpectrumAnalyseFields.TRACE_QUALITY]?.toDoubleOrNull()?.let { "%.0f%%".format(Locale.US, it * 100) }.orEmpty(), modifier = Modifier.weight(1f))
                    }
                    Text("Artefacts", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Text("Annotated spectrum image · analysis-ready spectrum CSV · detected-features CSV · metadata JSON", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val shareUris = listOf(
                        StarSpectrumAnalyseFields.ANNOTATED_IMAGE_URI,
                        StarSpectrumAnalyseFields.DATA_URI,
                        StarSpectrumAnalyseFields.FEATURES_URI
                    ).mapNotNull { values[it]?.takeIf(String::isNotBlank) }
                    val saveUris = shareUris + listOfNotNull(values[StarSpectrumAnalyseFields.METADATA_URI]?.takeIf(String::isNotBlank))
                    val summary = values[StarSpectrumAnalyseFields.FEATURES_TEXT].orEmpty().ifBlank { "Star spectrum analysis: ${values[StarSpectrumAnalyseFields.FEATURE_COUNT].orEmpty()} detected features" }
                    val fullJson = committedResult?.let {
                        OutputFormatter.format(it, ReturnMode.Json, includeProvenance = true, payloadMode = OutputFormatter.PayloadMode.FULL)
                    }.orEmpty()
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Include full JSON", style = MaterialTheme.typography.labelLarge)
                            Text("Advanced provenance/audit payload", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = includeFullJson, onCheckedChange = { includeFullJson = it })
                    }
                    Button(onClick = {
                        val shareText = if (includeFullJson && fullJson.isNotBlank()) "$summary\n\n$fullJson" else summary
                        runCatching { shareSpectrumArtifacts(appContext, "Star spectrum analysis", shareUris, shareText) }
                            .onFailure { exportStatus = "Share failed: ${it.message ?: "no sharing app"}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Share image + CSVs") }
                    OutlinedButton(onClick = {
                        runCatching { saveSpectrumArtifactsToDownloads(appContext, "Star spectrum analysis", saveUris, summary, if (includeFullJson) fullJson else "") }
                            .onSuccess { exportStatus = "Saved $it" }
                            .onFailure { exportStatus = "Save failed: ${it.message ?: "storage error"}" }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save complete bundle") }
                    OutlinedButton(onClick = { copyToClipboard(appContext, "Spectral features", values[StarSpectrumAnalyseFields.FEATURES_TEXT].orEmpty()) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Copy feature list")
                    }
                    exportStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
                    Button(onClick = { committedResult?.let(onConfirmed) }, modifier = Modifier.fillMaxWidth()) { Text("Done") }
                    OutlinedButton(onClick = { committedValuesJson = "" }, modifier = Modifier.fillMaxWidth()) { Text("Revise analysis") }
                }
            }
        }
    }
}
