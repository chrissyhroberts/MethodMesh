# Validation and self-review — Star spectrum analyser v0.2.0

Date: 2026-09-17

Status: **Development**. This handoff remains a Development module and must not be presented as a validated scientific pipeline.

## MethodMesh contract review

- [x] One module entry point: `StarSpectrumModule`.
- [x] Two independently callable capabilities remain explicit:
  - `astronomy.spectrum.analyse`
  - `astronomy.spectrum.reference.create`
- [x] Both capabilities remain exposed through module-owned methods, screens, settings and RIL bindings.
- [x] Working results remain editable until Commit.
- [x] Commit remains the finalisation boundary.
- [x] Analysis exports annotated PNG, spectrum CSV, detected-feature CSV and metadata JSON.
- [x] Canonical ODK showcases remain single-invocation examples using FULL payload.
- [x] Reference persistence remains local/offline and occurs only at explicit reference Commit.

## Extraction-method revision

The original experimental template-amplitude extractor has been replaced as the primary science path.

The current engine follows the standard astronomical sequence used by Horne-style optimal-extraction packages:

1. refine the user-provided RED → VIOLET geometry with a robust quadratic trace fit;
2. rectify a 2-D ribbon around that fitted trace;
3. estimate a sigma-clipped two-sided local background independently at each dispersion sample;
4. retain a simple background-subtracted boxcar extraction;
5. estimate an empirical cross-dispersion spatial profile in dispersion bins and interpolate it smoothly;
6. run iterative variance-weighted Horne-style optimal extraction;
7. reject the strongest spatial-profile outlier in each column per iteration when it exceeds the residual threshold;
8. preserve rejection fractions, optimal variance proxy, boxcar flux and optimal flux in outputs.

For processed JPEG/PNG input, the uncertainty image cannot be detector-calibrated. The engine therefore uses an explicitly documented empirical relative variance proxy. The resulting spectrum is image-derived relative signal, not calibrated photon flux.

## Visual quality audit

Both native capabilities now expose the intermediate 2-D products after extraction:

1. rectified trace;
2. two-sided background model;
3. background-subtracted ribbon;
4. unit-normalized empirical spatial-profile weights;
5. fitted 2-D target model (`optimal flux × spatial profile`);
6. signed `data − fitted model` residual with rejected pixels overlaid;
7. cleaned/rejected-pixel view;
8. boxcar-versus-optimal 1-D comparison.

This is intended to make extraction failure visible rather than hiding all processing behind one final curve.

## Local implementation checks completed in this handoff

- [x] `SpectrumEngine.kt` and `SpectrumModels.kt` compile with a minimal Kotlin/JVM stub harness for Android Bitmap and JSON classes.
- [x] New extraction diagnostics are wired into the analysis model.
- [x] CSV export now preserves boxcar signal, optimal signal, optimal variance and per-column rejection fraction.
- [x] Metadata records extraction method, trace-fit RMS, rejected-pixel fraction, iteration count and variance semantics.
- [x] Reference calibration uses the Horne-optimally extracted 1-D spectrum as the primary Balmer placement surface.
- [x] Existing RED/VIOLET endpoint picker and horizontal photographic spectrum strip are retained.

## Required Android admission checks

A full Android Gradle build cannot be completed in this isolated handoff environment. Before merge or scientific use:

1. replace the module folder and run `./gradlew :app:compileDebugKotlin :app:assembleDebug`;
2. exercise reference extraction on the supplied stellar JPEG and inspect every QA stage;
3. confirm the rectified target is horizontal and centred;
4. confirm side-band stars are absent from the background model after clipping;
5. confirm rejected pixels correspond to visibly inconsistent crossings/hot pixels rather than the target core;
6. compare boxcar and optimal traces;
7. verify RED/VIOLET pan/zoom and three-second lock behaviour is unchanged;
8. place Balmer anchors on the optimal-extraction Line finder view;
9. compare wavelength calibration against BASS or another trusted spectroscopy workflow;
10. repeat with an uncompressed/raw source before judging absolute spectral shape;
11. validate both XLSForms and ODK round trips;
12. only then consider promotion beyond Development.

## Deliberate boundaries

- no FITS/raw-linear decoder yet;
- no detector gain/read-noise calibration for JPEG/PNG;
- no automatic elemental/species identification;
- no atmospheric or instrument-response correction;
- no HST-style forward contamination model requiring direct imaging and instrument calibration files;
- no claim that processed raster intensity is calibrated stellar flux;
- no network dependency.

- [x] QA UI exposes the iterative residual rejection threshold used by the extractor.
