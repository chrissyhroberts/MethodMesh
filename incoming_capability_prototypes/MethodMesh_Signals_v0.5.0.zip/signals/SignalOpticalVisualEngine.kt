package com.example.methodmesh.modules.signals

import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import androidx.camera.core.Camera as CameraXCamera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** One camera observation of a spatial optical grid. */
data class SignalGridCameraSample(
    val timestampMs: Long,
    val luma: DoubleArray,
    val decoded: OpticalGridCodec.State?
)

/**
 * Samples a square target ROI into an N×N luminance matrix. The pure grid codec
 * resolves 90-degree rotations from four fixed corner pilots and derives the
 * four amplitude levels from those same pilots, so exposure need not be calibrated
 * to an absolute camera value.
 */
class SignalCameraGridAnalyzer(
    private val onSample: (SignalGridCameraSample) -> Unit
) : ImageAnalysis.Analyzer {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var gridSize = 4
    @Volatile private var roiMode = SignalCameraRoiMode.FOCUS
    @Volatile private var centerX = 0.5f
    @Volatile private var centerY = 0.5f
    @Volatile private var generation = 0
    private var handledGeneration = -1
    private var stableGate = OpticalGridStableGate(2)

    fun updateConfiguration(size: Int, roi: SignalCameraRoiMode, x: Float, y: Float, generation: Int) {
        gridSize = size.coerceIn(4, 10)
        roiMode = roi
        centerX = x.coerceIn(0f, 1f)
        centerY = y.coerceIn(0f, 1f)
        this.generation = generation
    }

    override fun analyze(image: ImageProxy) {
        try {
            if (handledGeneration != generation) {
                handledGeneration = generation
                stableGate = OpticalGridStableGate(2)
            }
            val plane = image.planes.firstOrNull() ?: return
            val width = image.width
            val height = image.height
            if (width <= 0 || height <= 0) return
            val buffer = plane.buffer
            val rotation = ((image.imageInfo.rotationDegrees % 360) + 360) % 360
            val size = gridSize
            val fraction = roiMode.fraction.toFloat()
            val values = DoubleArray(size * size)

            for (row in 0 until size) {
                for (column in 0 until size) {
                    val displayX = (centerX - fraction / 2f + fraction * (column + 0.5f) / size.toFloat()).coerceIn(0f, 1f)
                    val displayY = (centerY - fraction / 2f + fraction * (row + 0.5f) / size.toFloat()).coerceIn(0f, 1f)
                    val raw = displayToRaw(displayX, displayY, rotation)
                    values[row * size + column] = localMedian(
                        bufferLimit = buffer.limit(),
                        getter = { index -> buffer.get(index).toInt() and 0xff },
                        rowStride = plane.rowStride,
                        pixelStride = plane.pixelStride,
                        width = width,
                        height = height,
                        x = raw.first,
                        y = raw.second,
                        normalizedCell = fraction / size.toFloat()
                    )
                }
            }

            val decoded = OpticalGridCodec.decodeLuma(values, size)
            val stable = stableGate.feed(decoded)
            main.post { onSample(SignalGridCameraSample(System.currentTimeMillis(), values, stable)) }
        } finally {
            image.close()
        }
    }

    private fun localMedian(
        bufferLimit: Int,
        getter: (Int) -> Int,
        rowStride: Int,
        pixelStride: Int,
        width: Int,
        height: Int,
        x: Float,
        y: Float,
        normalizedCell: Float
    ): Double {
        val cx = (x * width).roundToInt().coerceIn(0, width - 1)
        val cy = (y * height).roundToInt().coerceIn(0, height - 1)
        val rx = max(1, (width * normalizedCell * 0.22f).roundToInt())
        val ry = max(1, (height * normalizedCell * 0.22f).roundToInt())
        val samples = ArrayList<Int>(49)
        val stepX = max(1, rx / 3)
        val stepY = max(1, ry / 3)
        for (py in max(0, cy - ry)..min(height - 1, cy + ry) step stepY) {
            for (px in max(0, cx - rx)..min(width - 1, cx + rx) step stepX) {
                val at = py * rowStride + px * pixelStride
                if (at in 0 until bufferLimit) samples += getter(at)
            }
        }
        if (samples.isEmpty()) return 0.0
        samples.sort()
        return samples[samples.size / 2].toDouble()
    }

    private fun displayToRaw(x: Float, y: Float, rotation: Int): Pair<Float, Float> = when (rotation) {
        90 -> y to (1f - x)
        180 -> (1f - x) to (1f - y)
        270 -> (1f - y) to x
        else -> x to y
    }
}

/** Camera preview and target lattice for Screen Grid reception. */
@Composable
fun SignalCameraGridPreview(
    modifier: Modifier = Modifier,
    gridSize: Int,
    zoomRatio: Float = 1f,
    roiMode: SignalCameraRoiMode = SignalCameraRoiMode.FOCUS,
    roiCenterX: Float = 0.5f,
    roiCenterY: Float = 0.5f,
    searchGeneration: Int = 0,
    exposureReduction: Float = 0.55f,
    onRoiMoved: (Float, Float) -> Unit = { _, _ -> },
    onCameraInfo: (SignalCameraInfo) -> Unit = {},
    onSample: (SignalGridCameraSample) -> Unit,
    onError: (String) -> Unit
) {
    val currentSample = rememberUpdatedState(onSample)
    val currentError = rememberUpdatedState(onError)
    val currentCameraInfo = rememberUpdatedState(onCameraInfo)
    val currentRoiMoved = rememberUpdatedState(onRoiMoved)
    val analysisExecutor: ExecutorService = remember { Executors.newSingleThreadExecutor() }
    val providerHolder = remember { arrayOfNulls<ProcessCameraProvider>(1) }
    val cameraHolder = remember { arrayOfNulls<CameraXCamera>(1) }
    val lastAppliedZoom = remember { floatArrayOf(Float.NaN) }
    val lastAppliedExposure = remember { intArrayOf(Int.MIN_VALUE) }
    val analyzer = remember { SignalCameraGridAnalyzer { sample -> currentSample.value(sample) } }
    analyzer.updateConfiguration(gridSize, roiMode, roiCenterX, roiCenterY, searchGeneration)

    Box(
        modifier = modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures { offset ->
                if (size.width > 0 && size.height > 0) currentRoiMoved.value(
                    (offset.x / size.width.toFloat()).coerceIn(0f, 1f),
                    (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                )
            }
        }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PreviewView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    scaleType = PreviewView.ScaleType.FIT_CENTER
                    val owner = context.findLifecycleOwner()
                    if (owner == null) currentError.value("Camera preview could not find an Android lifecycle owner.")
                    else {
                        val future = ProcessCameraProvider.getInstance(context)
                        future.addListener({
                            runCatching {
                                val provider = future.get()
                                providerHolder[0] = provider
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(surfaceProvider) }
                                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                                    .also { it.setAnalyzer(analysisExecutor, analyzer) }
                                provider.unbindAll()
                                val camera = provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                                cameraHolder[0] = camera
                                val zoom = camera.cameraInfo.zoomState.value
                                val minZoom = zoom?.minZoomRatio ?: 1f
                                val maxZoom = zoom?.maxZoomRatio ?: 1f
                                val target = zoomRatio.coerceIn(minZoom, maxZoom)
                                camera.cameraControl.setZoomRatio(target)
                                lastAppliedZoom[0] = target
                                val exposureRange = camera.cameraInfo.exposureState.exposureCompensationRange
                                val exposureTarget = if (exposureRange.lower < 0) (exposureRange.lower * exposureReduction.coerceIn(0f, 1f)).roundToInt().coerceIn(exposureRange.lower, exposureRange.upper) else 0
                                camera.cameraControl.setExposureCompensationIndex(exposureTarget)
                                lastAppliedExposure[0] = exposureTarget
                                currentCameraInfo.value(SignalCameraInfo(target, maxZoom))
                            }.onFailure { currentError.value(it.message ?: "Optical grid camera failed to start.") }
                        }, ContextCompat.getMainExecutor(context))
                    }
                }
            },
            update = {
                cameraHolder[0]?.let { camera ->
                    val zoom = camera.cameraInfo.zoomState.value
                    val minZoom = zoom?.minZoomRatio ?: 1f
                    val maxZoom = zoom?.maxZoomRatio ?: 1f
                    val target = zoomRatio.coerceIn(minZoom, maxZoom)
                    if (!lastAppliedZoom[0].isFinite() || abs(lastAppliedZoom[0] - target) >= 0.01f) {
                        camera.cameraControl.setZoomRatio(target); lastAppliedZoom[0] = target
                        currentCameraInfo.value(SignalCameraInfo(target, maxZoom))
                    }
                    val exposureRange = camera.cameraInfo.exposureState.exposureCompensationRange
                    val exposureTarget = if (exposureRange.lower < 0) (exposureRange.lower * exposureReduction.coerceIn(0f, 1f)).roundToInt().coerceIn(exposureRange.lower, exposureRange.upper) else 0
                    if (lastAppliedExposure[0] != exposureTarget) {
                        camera.cameraControl.setExposureCompensationIndex(exposureTarget); lastAppliedExposure[0] = exposureTarget
                    }
                }
            }
        )

        val fraction = roiMode.fraction.toFloat()
        Canvas(Modifier.fillMaxSize()) {
            val sideW = size.width * fraction
            val sideH = size.height * fraction
            val side = min(sideW, sideH)
            val left = (size.width * roiCenterX - side / 2f).coerceIn(0f, max(0f, size.width - side))
            val top = (size.height * roiCenterY - side / 2f).coerceIn(0f, max(0f, size.height - side))
            drawRect(SignalCyan, Offset(left, top), Size(side, side), style = Stroke(width = 3f))
            for (i in 1 until gridSize) {
                val x = left + side * i / gridSize.toFloat()
                val y = top + side * i / gridSize.toFloat()
                drawLine(SignalCyan.copy(alpha = 0.38f), Offset(x, top), Offset(x, top + side), strokeWidth = 1f)
                drawLine(SignalCyan.copy(alpha = 0.38f), Offset(left, y), Offset(left + side, y), strokeWidth = 1f)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { providerHolder[0]?.unbindAll() }
            analysisExecutor.shutdownNow()
        }
    }
}
