package com.example.researchos.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.researchos.calibration.CalibrationScreen
import com.example.researchos.core.MethodCategory
import com.example.researchos.core.MethodRegistry
import com.example.researchos.core.researchos.runtime.As100MethodRegistry
import com.example.researchos.modules.ModuleCapabilitySummary
import com.example.researchos.modules.ResearchOSModule
import com.example.researchos.modules.ResearchOSModuleRegistry
import com.example.researchos.ui.components.MethodCard
import com.example.researchos.ui.sensors.SensorDashboard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ResearchOS Runtime") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            item { RuntimeSummaryCard() }
            item { ModuleInventoryCard() }
            item { CalibrationCard() }
            item { SensorDashboardCard() }

            items(MethodRegistry.categoriesInUse()) { category ->
                MethodCategoryCard(category = category)
            }
        }
    }
}

@Composable
private fun RuntimeSummaryCard() {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        elevation = CardDefaults.elevatedCardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ResearchOS runtime",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "ODK remains the canonical form engine. ResearchOS methods now return AS-native graph results: observations, states, transformations and provenance.",
                modifier = Modifier.padding(top = 4.dp),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Installed AS methods: ${As100MethodRegistry.all().size} • legacy UI shells: ${MethodRegistry.all().size}",
                modifier = Modifier.padding(top = 8.dp),
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}


@Composable
private fun ModuleInventoryCard() {
    val modules = ResearchOSModuleRegistry.all()
    var expanded by remember { mutableStateOf(true) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        elevation = CardDefaults.elevatedCardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Text(
                    text = if (expanded) "▼ Installed capability modules" else "▶ Installed capability modules",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = modules.size.toString(),
                    style = MaterialTheme.typography.titleMedium
                )
            }

            Text(
                text = "Modules are discovered from com.example.researchos.modules.* and contribute methods, RIL bindings, screens and examples without dashboard-specific code.",
                modifier = Modifier.padding(top = 6.dp),
                style = MaterialTheme.typography.bodySmall
            )

            if (expanded) {
                Spacer(Modifier.height(12.dp))
                if (modules.isEmpty()) {
                    Text("No modules discovered.")
                }
                modules.forEach { module ->
                    ModuleDebugCard(module = module)
                }
            }
        }
    }
}

@Composable
private fun ModuleDebugCard(module: ResearchOSModule) {
    var expanded by remember(module.moduleId) { mutableStateOf(module.moduleId == "choiceexperiment") }
    val capabilities = module.debugCapabilities()
    val rilBindings = module.rilBindings()
    val examples = module.examples()

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
        elevation = CardDefaults.elevatedCardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Text(
                    text = if (expanded) "▼ ${module.displayName}" else "▶ ${module.displayName}",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${capabilities.size} capabilities",
                    style = MaterialTheme.typography.labelMedium
                )
            }
            Text(
                text = module.moduleId,
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                text = module.summary,
                modifier = Modifier.padding(top = 4.dp),
                style = MaterialTheme.typography.bodySmall
            )

            if (expanded) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Capabilities",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                capabilities.forEach { capability ->
                    CapabilityDebugSummary(capability)
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    text = "RIL bindings",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                if (rilBindings.isEmpty()) {
                    Text("No RIL bindings declared.", style = MaterialTheme.typography.bodySmall)
                } else {
                    rilBindings.take(12).forEach { binding ->
                        Text(
                            text = "${binding.phrase} → ${binding.actionId}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (rilBindings.size > 12) {
                        Text("… ${rilBindings.size - 12} more bindings", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Examples",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                if (examples.isEmpty()) {
                    Text("No examples declared.", style = MaterialTheme.typography.bodySmall)
                } else {
                    examples.forEach { example ->
                        Text(
                            text = example.title,
                            modifier = Modifier.padding(top = 6.dp),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = example.ril,
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (example.notes.isNotBlank()) {
                            Text(
                                text = example.notes,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilityDebugSummary(capability: ModuleCapabilitySummary) {
    Column(modifier = Modifier.padding(top = 8.dp)) {
        Text(
            text = capability.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = capability.id,
            style = MaterialTheme.typography.labelSmall
        )
        if (capability.description.isNotBlank()) {
            Text(
                text = capability.description,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Text(
            text = "Screen: ${if (capability.screenAvailable) "yes" else "no"} • Outputs: ${capability.outputFields.size} • Graph outputs: ${capability.graphOutputs.joinToString().ifBlank { "none" }}",
            style = MaterialTheme.typography.labelSmall
        )
        if (capability.rilPhrases.isNotEmpty()) {
            Text(
                text = "RIL: ${capability.rilPhrases.take(4).joinToString(", ")}${if (capability.rilPhrases.size > 4) " …" else ""}",
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

@Composable
private fun CalibrationCard() {
    var expanded by remember { mutableStateOf(false) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        elevation = CardDefaults.elevatedCardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Text(
                    text = if (expanded) "▼ Device calibration" else "▶ Device calibration",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (expanded) {
                Spacer(Modifier.height(12.dp))
                CalibrationScreen()
            }
        }
    }
}

@Composable
private fun SensorDashboardCard() {
    var expanded by remember { mutableStateOf(false) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        elevation = CardDefaults.elevatedCardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Text(
                    text = if (expanded) "▼ Device signals" else "▶ Device signals",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (expanded) {
                Spacer(Modifier.height(12.dp))
                SensorDashboard()
            }
        }
    }
}

@Composable
private fun MethodCategoryCard(category: MethodCategory) {
    val methods = MethodRegistry.byCategory(category)
    var expanded by remember { mutableStateOf(true) }

    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        elevation = CardDefaults.elevatedCardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
            ) {
                Text(
                    text = if (expanded) "▼ ${category.name}" else "▶ ${category.name}",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = methods.size.toString(),
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (expanded) {
                Spacer(Modifier.height(12.dp))

                if (methods.isEmpty()) {
                    Text("No methods installed.")
                }

                methods.forEach { method ->
                    MethodCard(
                        method = method,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }
    }
}
