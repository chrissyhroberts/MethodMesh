package com.example.researchos.core

class ResearchSession {

    private val graph = ResearchGraph()

    // Legacy compatibility collections. Prefer AS collections for new code.
    val entities: Collection<Entity>
        get() = graph.entities.values

    val observations: Collection<Observation>
        get() = graph.observations.values

    val asEntities: Collection<com.example.researchos.core.researchos.Entity>
        get() = graph.asEntities.values

    val asObservations: Collection<com.example.researchos.core.researchos.Observation>
        get() = graph.asObservations.values

    val asStates: Collection<com.example.researchos.core.researchos.State>
        get() = graph.asStates.values

    val transformations: Collection<com.example.researchos.core.researchos.Transformation>
        get() = graph.transformations.values

    val executionResults: Collection<com.example.researchos.core.researchos.ExecutionResult>
        get() = graph.executionResults.values

    fun graph(): ResearchGraph = graph

    fun add(entity: Entity) {
        graph.add(entity)
    }

    fun add(observation: Observation) {
        graph.add(observation)
    }

    fun add(entity: com.example.researchos.core.researchos.Entity) {
        graph.add(entity)
    }

    fun add(observation: com.example.researchos.core.researchos.Observation) {
        graph.add(observation)
    }

    fun record(result: com.example.researchos.core.researchos.ExecutionResult): com.example.researchos.core.researchos.ExecutionResult =
        graph.record(result)

    fun relate(
        source: ObjectRef,
        type: RelationshipType,
        target: ObjectRef
    ) {
        graph.connect(source, type, target)
    }

    fun observationsFor(entity: Entity): List<Observation> =
        graph.observationsForEntity(entity.id)

    fun clear() {
        graph.clear()
    }
}
