package com.example.researchos.modules.nfc

import com.example.researchos.core.MethodOutput
import com.example.researchos.core.Observation
import com.example.researchos.core.Provenance

object NfcObservationMapper {

    /**
     * Creates a canonical ResearchOS Observation from
     * a set of NFC output fields.
     */
    fun fromFields(
        fields: Map<String, Any?>,
        methodId: String = "method:nfc-read",
        methodVersion: String = "1.0.0"
    ): Observation {

        return Observation(
            output = MethodOutput(fields),
            provenance = Provenance(
                methodId = methodId,
                methodVersion = methodVersion
            )
        )
    }

    /**
     * Converts an existing legacy NFC evidence bundle into
     * a canonical ResearchOS Observation.
     */
    fun fromBundle(
        bundle: NfcReadEvidenceBundle
    ): Observation {

        return fromFields(
            bundle.toRecord()
        )
    }
}