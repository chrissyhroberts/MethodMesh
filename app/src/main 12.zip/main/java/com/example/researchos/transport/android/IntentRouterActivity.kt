package com.example.researchos.transport.android

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.example.researchos.core.ResearchRuntime
import com.example.researchos.core.researchos.ExecutionResult
import com.example.researchos.core.researchos.InvocationContext
import com.example.researchos.core.researchos.TransformationStatus
import com.example.researchos.core.researchos.runtime.As100LegacyMethodAdapter
import com.example.researchos.core.researchos.runtime.As100MethodRegistry
import com.example.researchos.core.researchos.withInvocationContext
import com.example.researchos.settings.MethodSetting
import com.example.researchos.settings.SettingsState
import com.example.researchos.transport.LaunchConfigParser
import com.example.researchos.transport.OutputFormatter
import com.example.researchos.transport.ParsedLaunchConfig
import com.example.researchos.transport.ReturnMode

/**
 * ODK / Android intent adapter for ResearchOS capabilities.
 *
 * This is deliberately a transport boundary: it parses ODK-style launch data,
 * builds an InvocationContext, executes the canonical AS/ResearchOS method
 * runtime, records the resulting graph mutation in the live ResearchRuntime
 * session, and returns a flat payload to the caller.
 *
 * Research logic should not be added here. Add new capability behaviour to an
 * As100Method implementation and let this activity route to it.
 */
class IntentRouterActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        route(intent)
    }

    private fun route(intent: Intent) {
        val parsed = intent.dataString
            ?.let { LaunchConfigParser.parse(it) }
            ?: parseExtras(intent)

        val methodId = parsed.methodId
        if (methodId == null) {
            finishWithError("No method id supplied.")
            return
        }

        val method = As100MethodRegistry.find(methodId)
        if (method == null) {
            finishWithError("Unknown method: $methodId")
            return
        }

        val invocationContext = invocationContextFrom(parsed, methodId)
        ResearchRuntime.session.setInvocationContext(invocationContext)

        val settingsState = settingsStateFor(method)
        settingsState?.let { state ->
            applyParameters(state, legacySettingsFor(method), parsed.settings)
        }

        val requestContext = invocationContext.asMap(requestedCapability = methodId) +
            parsed.context +
            parsed.settings

        val executionResult = try {
            method.execute(
                request = method.request(
                    action = methodId,
                    context = requestContext
                ),
                settingsState = settingsState,
                transport = parsed.source ?: "android_intent"
            ).withInvocationContext(invocationContext)
        } catch (t: Throwable) {
            finishWithError(t.message ?: "Method execution failed.")
            return
        }

        val recorded = ResearchRuntime.session.record(executionResult)

        if (recorded.status == TransformationStatus.Failed || recorded.status == TransformationStatus.Cancelled) {
            finishWithError(recorded.diagnostics["error"] ?: "Method execution failed.")
            return
        }

        val returnMode = parsed.returnMode ?: ReturnMode.Json
        val fields = OutputFormatter.fields(recorded, includeProvenance = true)
        val output = OutputFormatter.format(
            result = recorded,
            returnMode = returnMode,
            includeProvenance = true
        )

        val data = Intent().apply {
            putExtra("value", output)
            putExtra("return_mode", returnMode.id)
            putExtra("researchos_execution_id", recorded.request.id.value)
            putExtra("researchos_status", recorded.status.name)
            putExtra("context_entity_id", invocationContext.canonicalEntityId)
            fields.forEach { (key, value) ->
                putExtra(key, value?.toString())
            }
        }

        setResult(RESULT_OK, data)
        finish()
    }

    private fun parseExtras(intent: Intent): ParsedLaunchConfig {
        val values = mutableMapOf<String, String>()
        val extras = intent.extras
        extras?.keySet()?.forEach { key ->
            values[key] = extras.get(key)?.toString().orEmpty()
        }
        intent.action?.let { values.putIfAbsent("action", it) }

        val methodId = values["method"]
            ?: values["method_id"]
            ?: values["module"]
            ?: values["module_id"]
            ?: values["capability"]
            ?: values["capability_id"]

        val returnMode = values["return_mode"]
            ?: values["return"]
            ?: values["mode"]

        val reserved = setOf(
            "method", "method_id", "module", "module_id", "capability", "capability_id",
            "return_mode", "return", "mode", "action"
        )

        val contextKeys = setOf(
            "caller", "entity_type", "entity_id", "subject_id", "participant_id",
            "specimen_id", "visit_id", "form_id", "operator_id",
            "context_entity_type", "context_entity_id"
        )

        val context = values
            .filterKeys { key -> key.startsWith("context_") || key in contextKeys }
            .mapKeys { (key, _) -> key.removePrefix("context_") }

        val settings = values
            .filterKeys { key -> key !in reserved && key !in contextKeys && !key.startsWith("context_") }

        return ParsedLaunchConfig(
            methodId = methodId,
            returnMode = returnMode?.let { ReturnMode.fromId(it) },
            settings = settings,
            context = context,
            source = "android_extras"
        )
    }

    private fun invocationContextFrom(parsed: ParsedLaunchConfig, methodId: String): InvocationContext {
        val merged = parsed.settings + parsed.context
        val entityType = merged["entity_type"]
            ?: merged["context_entity_type"]
            ?: when {
                merged["specimen_id"] != null -> "specimen"
                else -> "participant"
            }
        val entityId = merged["entity_id"]
            ?: merged["context_entity_id"]
            ?: merged["subject_id"]
            ?: merged["participant_id"]
            ?: merged["specimen_id"]
            ?: "P001"

        return InvocationContext(
            caller = merged["caller"] ?: parsed.source ?: "odk",
            entityType = entityType,
            entityId = entityId,
            visitId = merged["visit_id"].orEmpty(),
            formId = merged["form_id"].orEmpty(),
            operatorId = merged["operator_id"].orEmpty()
        ).also {
            // Keep requested capability materialised in the request context via asMap(methodId).
        }
    }

    private fun settingsStateFor(method: com.example.researchos.core.researchos.runtime.As100Method): SettingsState? {
        val legacySettings = legacySettingsFor(method)
        return if (legacySettings.isEmpty()) null else SettingsState(legacySettings)
    }

    private fun legacySettingsFor(method: com.example.researchos.core.researchos.runtime.As100Method): List<MethodSetting> =
        (method as? As100LegacyMethodAdapter)?.method?.settings
            ?: As100MethodRegistry.legacyFind(method.id)?.settings
            ?: emptyList()

    private fun applyParameters(
        settingsState: SettingsState,
        settings: List<MethodSetting>,
        parameters: Map<String, String>
    ) {
        settings.forEach { setting ->
            val raw = parameters[setting.id] ?: return@forEach
            when (setting) {
                is MethodSetting.BooleanSetting -> settingsState.setBoolean(setting.id, raw.toBooleanStrictOrNull() ?: raw == "1")
                is MethodSetting.IntSetting -> raw.toIntOrNull()?.let { settingsState.setInt(setting.id, it) }
                is MethodSetting.FloatSetting -> raw.toFloatOrNull()?.let { settingsState.setFloat(setting.id, it) }
                is MethodSetting.TextSetting -> settingsState.setString(setting.id, raw)
                is MethodSetting.ChoiceSetting -> settingsState.setString(setting.id, raw)
            }
        }
    }

    private fun finishWithError(message: String) {
        setResult(
            RESULT_CANCELED,
            Intent().apply { putExtra("error", message) }
        )
        finish()
    }
}
