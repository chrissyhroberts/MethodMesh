package com.example.researchos.modules.gpstargetnavigator

import com.example.researchos.core.Observation
import com.example.researchos.core.ResearchRuntime
import com.example.researchos.settings.SettingsState

/**
 * Records GPS capability outputs into the live ResearchOS session.
 *
 * The legacy GPS UI still owns permissions and live device interaction.
 * This recorder bridges the capability output into the canonical ResearchOS
 * runtime by creating an Observation and inserting it into ResearchRuntime.
 */
object GpsResearchSessionRecorder {

    fun recordFromSettings(settingsState: SettingsState): Observation {
        val observation = As100LocateTargetMethod.buildObservation(settingsState)
        ResearchRuntime.session.add(observation)
        return observation
    }
}
