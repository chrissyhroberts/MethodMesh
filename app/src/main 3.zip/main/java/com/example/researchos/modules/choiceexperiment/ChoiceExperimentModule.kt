package com.example.researchos.modules.choiceexperiment

import com.example.researchos.modules.ResearchOSModule
import com.example.researchos.modules.RilBinding
import com.example.researchos.transport.workflow.ui.CapabilityScreenSpec

object ChoiceExperimentModule : ResearchOSModule {
    override val moduleId: String = "choiceexperiment"
    override val displayName: String = "Discrete choice experiments"

    override fun as100Methods() = listOf(
        DceResultFactory.method(DceMethod.Pairwise),
        DceResultFactory.method(DceMethod.MaxDiff),
        DceResultFactory.method(DceMethod.Ranking),
        DceResultFactory.method(DceMethod.Points),
        DceResultFactory.method(DceMethod.Conjoint)
    )

    override fun rilBindings() = listOf(
        RilBinding("run pairwise", DceMethod.Pairwise.id, "Run a pairwise comparison task"),
        RilBinding("pairwise choice", DceMethod.Pairwise.id, "Run a pairwise comparison task"),
        RilBinding("pairwise comparison", DceMethod.Pairwise.id, "Run a pairwise comparison task"),
        RilBinding("org.lshtm.choice.PAIRWISE", DceMethod.Pairwise.id, "Compatibility alias for the original DCE Choice Lab pairwise action"),
        RilBinding("run maxdiff", DceMethod.MaxDiff.id, "Run a MaxDiff / best-worst task"),
        RilBinding("maxdiff", DceMethod.MaxDiff.id, "Run a MaxDiff / best-worst task"),
        RilBinding("best worst", DceMethod.MaxDiff.id, "Run a best-worst scaling task"),
        RilBinding("best worst scaling", DceMethod.MaxDiff.id, "Run a best-worst scaling task"),
        RilBinding("org.lshtm.choice.MAXDIFF", DceMethod.MaxDiff.id, "Compatibility alias for the original DCE Choice Lab MaxDiff action"),
        RilBinding("run ranking", DceMethod.Ranking.id, "Run a ranking task"),
        RilBinding("rank options", DceMethod.Ranking.id, "Run a ranking task"),
        RilBinding("ranking", DceMethod.Ranking.id, "Run a ranking task"),
        RilBinding("org.lshtm.choice.RANKING", DceMethod.Ranking.id, "Compatibility alias for the original DCE Choice Lab ranking action"),
        RilBinding("allocate points", DceMethod.Points.id, "Run a points-allocation task"),
        RilBinding("points allocation", DceMethod.Points.id, "Run a points-allocation task"),
        RilBinding("run points", DceMethod.Points.id, "Run a points-allocation task"),
        RilBinding("org.lshtm.choice.POINTS", DceMethod.Points.id, "Compatibility alias for the original DCE Choice Lab points action"),
        RilBinding("run conjoint", DceMethod.Conjoint.id, "Run a conjoint selection task"),
        RilBinding("conjoint", DceMethod.Conjoint.id, "Run a conjoint selection task"),
        RilBinding("conjoint selection", DceMethod.Conjoint.id, "Run a conjoint selection task"),
        RilBinding("org.lshtm.choice.CONJOINT", DceMethod.Conjoint.id, "Compatibility alias for the original DCE Choice Lab conjoint action")
    )

    override fun capabilityScreens(): List<CapabilityScreenSpec> = listOf(
        PairwiseChoiceScreen,
        MaxDiffChoiceScreen,
        RankingChoiceScreen,
        PointsChoiceScreen,
        ConjointChoiceScreen
    )
}
