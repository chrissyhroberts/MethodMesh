package com.example.researchos.modules.nfc

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.researchos.core.ResearchRuntime

@Composable
internal fun KeyValueSection(
    title: String,
    values: Map<String, String>,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Divider(Modifier.padding(top = 10.dp, bottom = 10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        if (values.isEmpty()) {
            Text("No values.")
        } else {
            values.forEach { (key, value) ->
                Text(
                    text = "$key = ${value.ifBlank { "" }}",
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

internal fun Map<String, String>.filterForDisplay(keys: List<String>): Map<String, String> =
    keys.associateWith { this[it].orEmpty() }


@Composable
internal fun ResearchSessionPreview(
    title: String = "ResearchOS session preview",
    modifier: Modifier = Modifier
) {
    val session = ResearchRuntime.session
    val observations = session.observations.toList()
    val latest = observations.lastOrNull()

    Column(modifier = modifier.fillMaxWidth()) {
        Divider(Modifier.padding(top = 14.dp, bottom = 10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Entities: ${session.entities.size}")
        Text("Observations: ${observations.size}")

        if (latest == null) {
            Spacer(Modifier.height(4.dp))
            Text("No ResearchOS observations recorded in this session yet.")
        } else {
            Spacer(Modifier.height(8.dp))
            Text("Latest observation", fontWeight = FontWeight.Bold)
            Text("Method: ${latest.provenance.methodId}", fontFamily = FontFamily.Monospace)
            Text("Version: ${latest.provenance.methodVersion}", fontFamily = FontFamily.Monospace)

            val previewFields = latest.output.fields.entries.take(6)
            if (previewFields.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                previewFields.forEach { (key, value) ->
                    Text(
                        text = "• $key = ${value?.toString().orEmpty()}",
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
