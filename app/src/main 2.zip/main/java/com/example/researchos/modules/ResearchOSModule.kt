package com.example.researchos.modules

import android.content.Context
import com.example.researchos.core.Method
import com.example.researchos.core.researchos.runtime.As100Method
import com.example.researchos.transport.workflow.ui.CapabilityScreenSpec
import dalvik.system.DexFile

/**
 * Self-contained module contract.
 *
 * A capability module should expose one object implementing this interface from
 * inside its own modules/<module-name>/ folder. The runtime discovers these
 * module objects and uses them to build the method registry, RIL bindings and
 * external workflow screens. Adding a new capability should therefore not
 * require edits to central transport, workflow or registry files.
 */
interface ResearchOSModule {
    val moduleId: String
    val displayName: String

    fun legacyMethods(): List<Method> = emptyList()
    fun as100Methods(): List<As100Method> = emptyList()
    fun rilBindings(): List<RilBinding> = emptyList()
    fun capabilityScreens(): List<CapabilityScreenSpec> = emptyList()
}

data class RilBinding(
    val phrase: String,
    val actionId: String,
    val description: String = ""
)

/** Runtime module discovery with a fallback for non-Android/unit-test contexts. */
object ResearchOSModuleRegistry {
    private const val MODULE_PACKAGE_PREFIX = "com.example.researchos.modules."
    private val fallbackModules: List<ResearchOSModule> by lazy {
        listOf(
            com.example.researchos.modules.nfc.NfcModule,
            com.example.researchos.modules.adminfingerprint.AdminFingerprintModule,
            com.example.researchos.modules.gpstargetnavigator.GpsTargetNavigatorModule,
            com.example.researchos.modules.calibratedscale.CalibratedScaleModule
        )
    }

    @Volatile
    private var discoveredModules: List<ResearchOSModule>? = null

    fun initialise(context: Context) {
        if (discoveredModules != null) return
        discoveredModules = discoverFromDex(context).ifEmpty { fallbackModules }
    }

    fun all(): List<ResearchOSModule> = discoveredModules ?: fallbackModules

    fun as100Methods(): List<As100Method> = all().flatMap { it.as100Methods() }
    fun legacyMethods(): List<Method> = all().flatMap { it.legacyMethods() }
    fun rilBindings(): List<RilBinding> = all().flatMap { it.rilBindings() }
    fun capabilityScreens(): List<CapabilityScreenSpec> = all().flatMap { it.capabilityScreens() }

    fun canonicalAction(raw: String): String? {
        val value = raw.trim()
        if (value.isBlank()) return null
        val lower = value.lowercase()
        return rilBindings().firstOrNull { it.phrase.lowercase() == lower }?.actionId
            ?: rilBindings().firstOrNull { it.actionId.lowercase() == lower }?.actionId
            ?: as100Methods().firstOrNull { it.id.lowercase() == lower }?.id
    }

    fun screenFor(actionId: String): CapabilityScreenSpec? =
        capabilityScreens().firstOrNull { it.capabilityId == actionId }

    private fun discoverFromDex(context: Context): List<ResearchOSModule> = runCatching {
        val dexFile = DexFile(context.packageCodePath)
        dexFile.entries().asSequence()
            .filter { className ->
                className.startsWith(MODULE_PACKAGE_PREFIX) &&
                    className.endsWith("Module") &&
                    className != ResearchOSModule::class.java.name &&
                    className != ResearchOSModuleRegistry::class.java.name
            }
            .mapNotNull { className -> instantiateModule(className) }
            .distinctBy { it.moduleId }
            .sortedBy { it.moduleId }
            .toList()
    }.getOrElse { emptyList() }

    private fun instantiateModule(className: String): ResearchOSModule? = runCatching {
        val clazz = Class.forName(className)
        val instance = runCatching { clazz.getField("INSTANCE").get(null) }.getOrNull()
            ?: runCatching { clazz.getDeclaredConstructor().newInstance() }.getOrNull()
        instance as? ResearchOSModule
    }.getOrNull()
}
