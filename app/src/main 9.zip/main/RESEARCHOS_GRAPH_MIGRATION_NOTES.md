# ResearchOS graph migration notes

This patch moves the Android prototype further away from legacy flat Method outputs and toward the AS/ResearchOS graph model.

## Implemented

- Added AS-native storage to `ResearchGraph`:
  - entities
  - attributes
  - observations
  - relationships
  - classifications
  - states
  - transformations
  - execution results
- Added `ResearchSession.record(ExecutionResult)` as the canonical recording entry point.
- Preserved legacy `Entity`, `Observation` and relationship storage for the current Compose UI and transport previews.
- Updated the graph screen to show AS observations and transformations before legacy records.
- Updated NFC read/write recording so NFC bundles record their AS `ExecutionResult` into the live session.
- Updated canonical NFC read/write helper methods to return AS-native observations rather than legacy observations.
- Added NFC tag entities (`entityType = NfcTag`) and links from NFC observations to tag subjects.
- Updated GPS recording so settings-based capture also records the AS `ExecutionResult`.
- Added GPS spatial target entities (`entityType = SpatialTarget`), WGS84 spatial context and navigation state records.
- Updated biometric verification so successful/failed authentication signals are recorded as AS execution results.
- Extended `As100ExecutionEngine.complete(...)` to accept all AS knowledge object families, not just observations/entities/states.
- Removed packaged source artefacts (`modules.zip`, `gpstargetnavigator.zip`) and `.DS_Store` files from the source tree.

## Deliberately retained

- Legacy `Method`, `MethodOutput`, `core.Observation`, `MethodRegistry` and `MethodCard` remain as compatibility shells.
- ODK/transport preview generation remains untouched and still consumes flat `MethodOutput`.

## Remaining risks / next slice

- The project upload did not include a Gradle wrapper/project root, so this patch was not Android-built end-to-end.
- Core non-Android graph/session classes were compiled with `kotlinc` successfully.
- The next clean slice should make `MethodCard` call AS methods directly and render `ExecutionResult` previews, using flat `MethodOutput` only as a transport projection.

## v0.4 schema refactor notes

This pass refactors declared output schemas so they are no longer only flat transport field lists.

Changes:
- `MethodOutputSchema` now carries `graphOutputs` alongside legacy `fields`.
- `GraphOutput` declares the ResearchOS knowledge object produced by a capability: Entity, Observation, State, etc.
- `GraphField` maps a transport/display field back to a graph path such as `Observation.values.distance_m` or `State.values.arrived`.
- `RequiredWhen` replaces the misleading required/optional-only UI wording with lifecycle-aware requirements:
  - `Always`
  - `OnSuccessfulCapture`
  - `IfAvailable`
  - `PreviewOnly`
  - `TransportOnly`
- The UI now shows graph outputs first, then flat transport fields.
- The validator only enforces fields that are genuinely required for deterministic preview/runtime validation. Interactive NFC fields are no longer treated as missing during preview.

Capability-specific fixes:
- GPS now declares target entity, target-navigation observation, arrival state, and navigation-outcome observation.
- GPS navigation-outcome fields are included in the flat schema so saved/aborted sessions are not undeclared outputs.
- GPS `update_count` is now emitted as an integer rather than a float-shaped counter.
- Calibrated scale now declares `use_range`, matching the actual output returned by `buildOutput()`.
- NFC read/write schemas now mark tag/envelope fields as `OnSuccessfulCapture` rather than required during preview.
- Admin fingerprint now declares its biometric verification as an `attestation.biometric_verification` observation.

Known limitation:
- The schema layer is now graph-aware for knowledge objects, but `Transformation` remains represented through graph paths and execution results rather than as its own `GraphOutput.objectType`, because the current `KnowledgeObjectType` enum intentionally excludes transient transformation records.
