# ADR-0002: Transport Independence

## Status

Accepted

## Decision

ODK, JSON, Android intents and future integrations are transports, not core architecture.

## Rationale

The same evidence should be deliverable to multiple backend systems.

## Consequence

Capabilities produce evidence/artifacts; transport adapters encode them.
