# ADR-0001: Research Activities as Core Primitive

## Status

Accepted

## Decision

MethodMesh is organised around research activities expressed as verbs.

## Rationale

Researchers think in terms of activities such as locate, measure, ask, annotate, verify and track. These concepts are more stable than sensors, APIs or transports.

## Consequence

Capabilities are treated as implementations of research activities rather than as isolated widgets.
