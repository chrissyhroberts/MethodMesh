# 10. Implementation Notes

XLSForm Lab is the first Android implementation.

Current implementation concepts:

- Capability registry
- Settings renderer
- Output schema
- Transport builders
- Intent parser
- DataStore persistence
- Device calibration
- Sensor dashboard
- Biometric authentication
- GPS target navigator
- Calibrated scale

Implementation SHOULD progressively migrate toward the specification model:

```text
Capabilities -> Activities
Outputs -> Evidence/Artifacts
Sensors -> Signals
Capture UI -> Capture Engine
ODK generation -> Transport adapter
```

The current codebase does not need to be renamed all at once. Specification language can be adopted gradually.
