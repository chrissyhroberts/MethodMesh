# 06. Validation and Quality

Validation and quality are related but distinct.

Validation asks: **Is this allowed?**

Quality asks: **How good is it?**

A value can be valid but low quality.

Example:

```text
GPS coordinate present -> valid
GPS accuracy ±35 m -> poor quality
```

## Validation categories

- required
- type
- range
- regex
- allowed value
- cross-field rule
- protocol rule
- role rule
- capture rule

## Quality categories

- accuracy
- precision
- stability
- completeness
- timeliness
- provider reliability
- override status

## Override

Override MUST be explicit when validation or quality rules are not met but evidence is accepted.

Override metadata SHOULD include:

- rule not met
- actual value
- target value
- operator
- reason
- timestamp

## Normative rules

1. Validation MUST run before transport.
2. Failed validation MUST block transport unless override is allowed and recorded.
3. Quality SHOULD be recorded even when validation passes.
4. Override SHOULD be role-governed.
