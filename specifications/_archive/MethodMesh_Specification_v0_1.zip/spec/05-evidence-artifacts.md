# 05. Evidence and Artifacts

Research activities generate evidence. Artifacts are the portable representation of that evidence.

## Evidence classes

- Observation
- Interaction Event
- Media
- Annotation
- Calibration
- Randomisation record
- Authentication record
- Chain-of-custody record
- Protocol completion record
- Audit log

## Evidence identity

Evidence SHOULD include:

- evidence ID
- protocol ID
- workflow ID
- activity ID
- session ID
- participant/context ID where applicable
- timestamp
- producer capability
- producer version

## Artifact reuse

Artifacts MAY be consumed by later activities.

Examples:

```text
GPS household location -> navigation activity
Body map SVG -> lesion progression comparison
Randomisation record -> treatment allocation workflow
Sample ID artifact -> chain-of-custody workflow
```

## Normative rules

1. Evidence MUST be distinguishable from transport payloads.
2. Artifacts SHOULD be immutable once finalised.
3. Corrections SHOULD create new artifacts or audit entries rather than silently modifying prior evidence.
