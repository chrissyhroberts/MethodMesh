# 00. Preface

MethodMesh is not primarily an Android specification, an ODK specification, or a sensor abstraction. It is a specification for modelling and executing research activities.

The central premise is that research work is best represented not as forms, screens, sensors, or APIs, but as activities that generate evidence under defined contextual, relevance, validation, quality and provenance rules.

ODK, REDCap, SQL, FHIR, JSON APIs and local files are transport targets. They are not the architecture.

Android sensors, USB devices, BLE devices, cameras and microphones are implementation resources. They are not the architecture.

The stable domain concepts are:

- Protocol
- Workflow
- Activity
- Session
- Context
- Relevance
- Resource
- Signal
- Observation
- Interaction Event
- Evidence
- Artifact
- Validation
- Quality
- Provenance
- Transport

The specification exists to keep implementations anchored to those domain concepts.
