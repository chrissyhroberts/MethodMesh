# 04. Context and Relevance

Relevance determines whether an activity should be available in a given context.

It generalises XLSForm `relevant` from fields to whole activities, sessions and workflows.

## Context examples

- participant age
- participant sex
- visit type
- sample collected
- consent status
- previous activity completed
- operator role
- device capability
- GPS proximity
- network status

## Relevance rule examples

```text
show pregnancy module if sex = female AND age between 10 and 55
```

```text
show lesion map if rash_present = true
```

```text
require GPS arrival if visit_type = household
```

```text
show chain of custody if sample_collected = true
```

## Normative rules

1. A workflow engine MUST evaluate relevance before starting an activity.
2. An irrelevant activity SHOULD be skipped or hidden.
3. Relevance decisions SHOULD be auditable where they affect protocol completion.
4. Relevance MUST be re-evaluable when context changes.
