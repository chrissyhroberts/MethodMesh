# Example: Discrete Choice Experiment

Activity: Ask

Task family: preference elicitation

Capability: discrete choice experiment

Evidence:

```json
{
  "task_id": "B02_T04",
  "choice": "B",
  "alternative_id": "B",
  "response_time_ms": 5231,
  "attention_check_passed": true
}
```
