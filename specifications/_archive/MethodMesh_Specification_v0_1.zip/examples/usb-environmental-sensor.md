# Example: USB Environmental Sensor

Activity: Measure

Provider: USB serial temperature/humidity probe.

Signals:

```text
usb.temperature_c
usb.humidity_percent
usb.connected
usb.last_update_ms
```

Capture:

```text
average temperature and humidity for 30s once stability.sd < 0.2
```
